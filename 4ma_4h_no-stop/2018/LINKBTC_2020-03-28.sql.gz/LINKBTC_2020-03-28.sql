-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-07 19:59:59','2018-04-12 19:59:59','LINKBTC','4h','0.000043290000000','0.000048320000000','0.001467500000000','0.001638013398013','33.8992838992839','33.899283899283901','test'),('2018-04-13 15:59:59','2018-04-13 23:59:59','LINKBTC','4h','0.000050510000000','0.000048250000000','0.001510128349503','0.001442559747842','29.897611354251634','29.897611354251634','test'),('2018-04-14 07:59:59','2018-04-15 03:59:59','LINKBTC','4h','0.000050960000000','0.000049160000000','0.001510128349503','0.001456787866200','29.63360183483124','29.633601834831239','test'),('2018-04-15 07:59:59','2018-04-21 07:59:59','LINKBTC','4h','0.000050140000000','0.000054200000000','0.001510128349503','0.001632408387377','30.11823592945752','30.118235929457519','test'),('2018-04-22 07:59:59','2018-04-24 07:59:59','LINKBTC','4h','0.000056660000000','0.000055300000000','0.001510471087731','0.001474215516264','26.65850843153459','26.658508431534589','test'),('2018-04-30 07:59:59','2018-05-03 23:59:59','LINKBTC','4h','0.000055590000000','0.000058350000000','0.001510471087731','0.001585464795271','27.17163316659471','27.171633166594710','test'),('2018-05-05 07:59:59','2018-05-05 11:59:59','LINKBTC','4h','0.000060580000000','0.000059080000000','0.001520155621749','0.001482515584895','25.093357902756686','25.093357902756686','test'),('2018-05-07 23:59:59','2018-05-09 03:59:59','LINKBTC','4h','0.000061310000000','0.000057760000000','0.001520155621749','0.001432134867268','24.794578726945037','24.794578726945037','test'),('2018-05-09 07:59:59','2018-05-09 11:59:59','LINKBTC','4h','0.000058550000000','0.000059180000000','0.001520155621749','0.001536512548166','25.963375264713918','25.963375264713918','test'),('2018-05-09 15:59:59','2018-05-09 23:59:59','LINKBTC','4h','0.000060160000000','0.000057970000000','0.001520155621749','0.001464817509854','25.268544244498006','25.268544244498006','test'),('2018-05-10 11:59:59','2018-05-10 23:59:59','LINKBTC','4h','0.000060820000000','0.000058700000000','0.001520155621749','0.001467167625726','24.994337746612956','24.994337746612956','test'),('2018-05-11 03:59:59','2018-05-11 07:59:59','LINKBTC','4h','0.000059510000000','0.000055730000000','0.001520155621749','0.001423597257605','25.544540778843892','25.544540778843892','test'),('2018-05-15 11:59:59','2018-05-16 15:59:59','LINKBTC','4h','0.000060690000000','0.000058540000000','0.001520155621749','0.001466302687382','25.04787644997528','25.047876449975281','test'),('2018-06-30 23:59:59','2018-07-04 23:59:59','LINKBTC','4h','0.000035590000000','0.000035210000000','0.001520155621749','0.001503924682264','42.712998644254','42.712998644254000','test'),('2018-07-07 11:59:59','2018-07-09 15:59:59','LINKBTC','4h','0.000037450000000','0.000036010000000','0.001520155621749','0.001461703709991','40.59160538715621','40.591605387156207','test'),('2018-07-27 03:59:59','2018-07-31 11:59:59','LINKBTC','4h','0.000034810000000','0.000034310000000','0.001520155621749','0.001498320579782','43.67008393418558','43.670083934185577','test'),('2018-08-01 15:59:59','2018-08-04 03:59:59','LINKBTC','4h','0.000038890000000','0.000037560000000','0.001520155621749','0.001468167784852','39.088599170712264','39.088599170712264','test'),('2018-08-09 07:59:59','2018-08-11 15:59:59','LINKBTC','4h','0.000041910000000','0.000042130000000','0.001520155621749','0.001528135441286','36.27190698518254','36.271906985182540','test'),('2018-08-11 19:59:59','2018-08-13 23:59:59','LINKBTC','4h','0.000042210000000','0.000041260000000','0.001520155621749','0.001485942216379','36.01411091563611','36.014110915636110','test'),('2018-08-17 07:59:59','2018-08-18 19:59:59','LINKBTC','4h','0.000042830000000','0.000041450000000','0.001520155621749','0.001471175590042','35.4927765993229','35.492776599322902','test'),('2018-08-18 23:59:59','2018-08-23 19:59:59','LINKBTC','4h','0.000043020000000','0.000047470000000','0.001520155621749','0.001677400915026','35.3360209611576','35.336020961157601','test'),('2018-08-23 23:59:59','2018-08-25 19:59:59','LINKBTC','4h','0.000049370000000','0.000048600000000','0.001520155621749','0.001496446490115','30.791080043528456','30.791080043528456','test'),('2018-08-26 23:59:59','2018-08-27 23:59:59','LINKBTC','4h','0.000049320000000','0.000048520000000','0.001520155621749','0.001495497785224','30.82229565590024','30.822295655900241','test'),('2018-09-14 19:59:59','2018-09-15 23:59:59','LINKBTC','4h','0.000041560000000','0.000041310000000','0.001520155621749','0.001511011278500','36.57737299684793','36.577372996847927','test'),('2018-09-16 11:59:59','2018-09-22 03:59:59','LINKBTC','4h','0.000042300000000','0.000050710000000','0.001520155621749','0.001822389871841','35.9374851477305','35.937485147730499','test'),('2018-09-25 03:59:59','2018-09-25 15:59:59','LINKBTC','4h','0.000052510000000','0.000050950000000','0.001520155621749','0.001474993885510','28.94983092266235','28.949830922662350','test'),('2018-09-26 23:59:59','2018-09-28 11:59:59','LINKBTC','4h','0.000053590000000','0.000050040000000','0.001520155621749','0.001419454885470','28.366404585724947','28.366404585724947','test'),('2018-10-05 23:59:59','2018-10-09 03:59:59','LINKBTC','4h','0.000053770000000','0.000050940000000','0.001520155621749','0.001440147431131','28.27144544818672','28.271445448186721','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','LINKBTC','4h','0.000053620000000','0.000051180000000','0.001520155621749','0.001450980319305','28.3505337886796','28.350533788679599','test'),('2018-10-14 19:59:59','2018-10-15 07:59:59','LINKBTC','4h','0.000053180000000','0.000049990000000','0.001520155621749','0.001428969152524','28.585100070496427','28.585100070496427','test'),('2018-10-15 11:59:59','2018-10-15 15:59:59','LINKBTC','4h','0.000050070000000','0.000051370000000','0.001520155621749','0.001559624411609','30.360607584361894','30.360607584361894','test'),('2018-10-15 23:59:59','2018-10-20 11:59:59','LINKBTC','4h','0.000051410000000','0.000055980000000','0.001520155621749','0.001655287136851','29.56925932209687','29.569259322096869','test'),('2018-10-20 15:59:59','2018-10-22 07:59:59','LINKBTC','4h','0.000056750000000','0.000055730000000','0.001520155621749','0.001492833000882','26.786883202625553','26.786883202625553','test'),('2018-10-22 15:59:59','2018-10-25 11:59:59','LINKBTC','4h','0.000059000000000','0.000062560000000','0.001520155621749','0.001611880266044','25.765349521169494','25.765349521169494','test'),('2018-10-25 23:59:59','2018-10-29 11:59:59','LINKBTC','4h','0.000067830000000','0.000065010000000','0.001520155621749','0.001456955874538','22.41125787629367','22.411257876293671','test'),('2018-10-30 03:59:59','2018-11-04 19:59:59','LINKBTC','4h','0.000068750000000','0.000077740000000','0.001520155621749','0.001718936698688','22.11135449816727','22.111354498167270','test'),('2018-11-08 19:59:59','2018-11-09 03:59:59','LINKBTC','4h','0.000079260000000','0.000075850000000','0.001520155621749','0.001454754023589','19.179354299129447','19.179354299129447','test'),('2018-11-09 07:59:59','2018-11-09 11:59:59','LINKBTC','4h','0.000076290000000','0.000076500000000','0.001520155621749','0.001524340084727','19.92601417943374','19.926014179433739','test'),('2018-11-09 15:59:59','2018-11-17 03:59:59','LINKBTC','4h','0.000077910000000','0.000088350000000','0.001520155621749','0.001723857645765','19.511688124104733','19.511688124104733','test'),('2018-11-18 23:59:59','2018-11-19 07:59:59','LINKBTC','4h','0.000093490000000','0.000087630000000','0.001520155621749','0.001424871506406','16.260087942550005','16.260087942550005','test'),('2018-11-29 19:59:59','2018-11-30 23:59:59','LINKBTC','4h','0.000086690000000','0.000080230000000','0.001520155621749','0.001406876058749','17.53553606816242','17.535536068162418','test'),('2018-12-01 07:59:59','2018-12-01 15:59:59','LINKBTC','4h','0.000080910000000','0.000081080000000','0.001520155621749','0.001523349620707','18.78822916510938','18.788229165109382','test'),('2018-12-18 19:59:59','2018-12-22 03:59:59','LINKBTC','4h','0.000069600000000','0.000074100000000','0.001520155621749','0.001618441545569','21.841316404439656','21.841316404439656','test'),('2018-12-23 03:59:59','2018-12-23 19:59:59','LINKBTC','4h','0.000078400000000','0.000075830000000','0.001520155621749','0.001470323989761','19.389740073329083','19.389740073329083','test'),('2018-12-25 15:59:59','2018-12-27 11:59:59','LINKBTC','4h','0.000078060000000','0.000078050000000','0.001520155621749','0.001519960879804','19.474194488201384','19.474194488201384','test'),('2018-12-30 03:59:59','2018-12-31 11:59:59','LINKBTC','4h','0.000079310000000','0.000077650000000','0.001520155621749','0.001488337965311','19.167262914500064','19.167262914500064','test'),('2019-01-01 03:59:59','2019-01-02 03:59:59','LINKBTC','4h','0.000079090000000','0.000077820000000','0.001520155621749','0.001495745485959','19.22057936210646','19.220579362106459','test'),('2019-01-02 07:59:59','2019-01-06 11:59:59','LINKBTC','4h','0.000078250000000','0.000097710000000','0.001520155621749','0.001898203269024','19.426908904140575','19.426908904140575','test'),('2019-01-08 23:59:59','2019-01-10 07:59:59','LINKBTC','4h','0.000106210000000','0.000097250000000','0.001546593984415','0.001416121504419','14.561660713819322','14.561660713819322','test'),('2019-01-11 07:59:59','2019-01-17 19:59:59','LINKBTC','4h','0.000102490000000','0.000131350000000','0.001546593984415','0.001982096983637','15.0901940132208','15.090194013220801','test'),('2019-01-20 15:59:59','2019-01-24 03:59:59','LINKBTC','4h','0.000138990000000','0.000136850000000','0.001622851614221','0.001597864906872','11.676031471481764','11.676031471481764','test'),('2019-02-09 15:59:59','2019-02-10 23:59:59','LINKBTC','4h','0.000131900000000','0.000122400000000','0.001622851614221','0.001505966926313','12.303651358764215','12.303651358764215','test'),('2019-02-16 23:59:59','2019-02-17 03:59:59','LINKBTC','4h','0.000121120000000','0.000119510000000','0.001622851614221','0.001601279692995','13.398708836038638','13.398708836038638','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','LINKBTC','4h','0.000120140000000','0.000123660000000','0.001622851614221','0.001670399788701','13.508004113709006','13.508004113709006','test'),('2019-02-17 19:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000124140000000','0.000121060000000','0.001622851614221','0.001582587533572','13.072753457555987','13.072753457555987','test'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120250000000','0.001622851614221','0.001601805028401','13.320623936805385','13.320623936805385','test'),('2019-03-08 03:59:59','2019-03-11 19:59:59','LINKBTC','4h','0.000125860000000','0.000119490000000','0.001622851614221','0.001540716187695','12.894101495479106','12.894101495479106','test'),('2019-03-12 11:59:59','2019-03-13 11:59:59','LINKBTC','4h','0.000127550000000','0.000122070000000','0.001622851614221','0.001553128157961','12.723258441560171','12.723258441560171','test'),('2019-03-14 03:59:59','2019-03-15 19:59:59','LINKBTC','4h','0.000126720000000','0.000124770000000','0.001622851614221','0.001597878755574','12.806594177880365','12.806594177880365','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:25:13
