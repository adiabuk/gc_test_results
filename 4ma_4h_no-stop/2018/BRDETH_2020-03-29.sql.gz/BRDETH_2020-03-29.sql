-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-16 03:59:59','2018-06-19 23:59:59','BRDETH','4h','0.000893200000000','0.000906200000000','0.072144500000000','0.073194520712047','80.77082400358262','80.770824003582618','test'),('2018-06-26 15:59:59','2018-07-05 11:59:59','BRDETH','4h','0.000914600000000','0.001020000000000','0.072407005178012','0.080751306889976','79.16794793134895','79.167947931348948','test'),('2018-08-02 19:59:59','2018-08-03 03:59:59','BRDETH','4h','0.000906500000000','0.000882300000000','0.074493080606003','0.072504407080724','82.176591953671','82.176591953670993','test'),('2018-08-03 15:59:59','2018-08-03 19:59:59','BRDETH','4h','0.000858200000000','0.000863900000000','0.074493080606003','0.074987849377215','86.80153880913889','86.801538809138890','test'),('2018-08-04 03:59:59','2018-08-04 11:59:59','BRDETH','4h','0.000861000000000','0.000854200000000','0.074493080606003','0.073904749655805','86.5192573821173','86.519257382117303','test'),('2018-08-07 03:59:59','2018-08-12 07:59:59','BRDETH','4h','0.000905700000000','0.000962200000000','0.074493080606003','0.079140159168705','82.24917810091974','82.249178100919735','test'),('2018-08-12 19:59:59','2018-08-14 15:59:59','BRDETH','4h','0.001084300000000','0.001006100000000','0.075134291320612','0.069715586551386','69.29289986222632','69.292899862226321','test'),('2018-08-15 19:59:59','2018-08-25 11:59:59','BRDETH','4h','0.001149800000000','0.001282600000000','0.075134291320612','0.083812177811634','65.34553080588972','65.345530805889723','test'),('2018-08-27 11:59:59','2018-08-27 19:59:59','BRDETH','4h','0.001295000000000','0.001279700000000','0.075949086751061','0.075051773216473','58.64794343711275','58.647943437112751','test'),('2018-08-28 15:59:59','2018-08-28 23:59:59','BRDETH','4h','0.001306900000000','0.001259300000000','0.075949086751061','0.073182863987766','58.11392359863877','58.113923598638770','test'),('2018-09-04 19:59:59','2018-09-04 23:59:59','BRDETH','4h','0.001274400000000','0.001259000000000','0.075949086751061','0.075031309023529','59.595956333224265','59.595956333224265','test'),('2018-09-05 03:59:59','2018-09-05 07:59:59','BRDETH','4h','0.001267100000000','0.001267900000000','0.075949086751061','0.075997038190885','59.93929977986031','59.939299779860313','test'),('2018-09-05 19:59:59','2018-09-06 03:59:59','BRDETH','4h','0.001289300000000','0.001250100000000','0.075949086751061','0.073639923483674','58.907226208842786','58.907226208842786','test'),('2018-09-06 07:59:59','2018-09-06 11:59:59','BRDETH','4h','0.001260600000000','0.001313900000000','0.075949086751061','0.079160324513897','60.24836328023243','60.248363280232432','test'),('2018-09-06 15:59:59','2018-09-07 11:59:59','BRDETH','4h','0.001319600000000','0.001299200000000','0.075949086751061','0.074774972345391','57.55462772890346','57.554627728903462','test'),('2018-09-07 15:59:59','2018-09-13 15:59:59','BRDETH','4h','0.001449400000000','0.001602200000000','0.075949086751061','0.083955862282703','52.40036342697737','52.400363426977371','test'),('2018-09-18 07:59:59','2018-09-19 03:59:59','BRDETH','4h','0.001573000000000','0.001542000000000','0.076749430010018','0.075236885616941','48.79175461539637','48.791754615396371','test'),('2018-09-19 07:59:59','2018-09-21 19:59:59','BRDETH','4h','0.001588400000000','0.001539000000000','0.076749430010018','0.074362486014491','48.31870436289221','48.318704362892213','test'),('2018-10-02 15:59:59','2018-10-03 07:59:59','BRDETH','4h','0.001724800000000','0.001544600000000','0.076749430010018','0.068730965673396','44.49758233419411','44.497582334194107','test'),('2018-10-03 15:59:59','2018-10-07 19:59:59','BRDETH','4h','0.001560500000000','0.001615000000000','0.076749430010018','0.079429881106170','49.182588920229406','49.182588920229406','test'),('2018-10-08 11:59:59','2018-10-15 07:59:59','BRDETH','4h','0.001633100000000','0.001738700000000','0.076749430010018','0.081712224578053','46.99616068214928','46.996160682149281','test'),('2018-10-16 23:59:59','2018-10-17 23:59:59','BRDETH','4h','0.001832900000000','0.001805000000000','0.076749430010018','0.075581167094813','41.87322276720934','41.873222767209342','test'),('2018-10-19 19:59:59','2018-10-20 15:59:59','BRDETH','4h','0.001842400000000','0.001825600000000','0.076749430010018','0.076049587183179','41.657311121373205','41.657311121373205','test'),('2018-10-20 19:59:59','2018-10-23 15:59:59','BRDETH','4h','0.001857000000000','0.001863800000000','0.076749430010018','0.077030472618563','41.32979537426925','41.329795374269253','test'),('2018-10-24 19:59:59','2018-10-25 19:59:59','BRDETH','4h','0.001955200000000','0.001886200000000','0.076749430010018','0.074040903684992','39.254004710524754','39.254004710524754','test'),('2018-10-31 03:59:59','2018-10-31 11:59:59','BRDETH','4h','0.001870500000000','0.001836600000000','0.076749430010018','0.075358461992194','41.031504950557604','41.031504950557604','test'),('2018-11-16 23:59:59','2018-11-17 07:59:59','BRDETH','4h','0.001695300000000','0.001657700000000','0.076749430010018','0.075047207059286','45.271886987564436','45.271886987564436','test'),('2018-11-17 11:59:59','2018-11-19 19:59:59','BRDETH','4h','0.001718100000000','0.001679300000000','0.076749430010018','0.075016191034179','44.67110762471218','44.671107624712178','test'),('2018-11-20 15:59:59','2018-11-21 03:59:59','BRDETH','4h','0.001833400000000','0.001889400000000','0.076749430010018','0.079093690989925','41.861803212620266','41.861803212620266','test'),('2018-11-21 07:59:59','2018-11-24 23:59:59','BRDETH','4h','0.001910000000000','0.002042400000000','0.076749430010018','0.082069652278775','40.18294764922408','40.182947649224083','test'),('2018-11-29 19:59:59','2018-11-30 11:59:59','BRDETH','4h','0.002067300000000','0.001973900000000','0.076749430010018','0.073281913557188','37.125443820450826','37.125443820450826','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','BRDETH','4h','0.002140800000000','0.001990400000000','0.076749430010018','0.071357467064621','35.850817456099584','35.850817456099584','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','BRDETH','4h','0.002004300000000','0.002025000000000','0.076749430010018','0.077542082407966','38.29238637430424','38.292386374304243','test'),('2018-12-01 11:59:59','2018-12-02 03:59:59','BRDETH','4h','0.002055200000000','0.002053800000000','0.076749430010018','0.076697148381946','37.34402005158524','37.344020051585240','test'),('2018-12-02 07:59:59','2018-12-02 11:59:59','BRDETH','4h','0.002054300000000','0.002038400000000','0.076749430010018','0.076155399957368','37.3603806698233','37.360380669823300','test'),('2018-12-02 15:59:59','2018-12-06 15:59:59','BRDETH','4h','0.002084500000000','0.002074000000000','0.076749430010018','0.076362829379121','36.81910770449412','36.819107704494122','test'),('2018-12-09 23:59:59','2018-12-10 15:59:59','BRDETH','4h','0.002135200000000','0.002047900000000','0.076749430010018','0.073611445165566','35.944843579064255','35.944843579064255','test'),('2018-12-13 19:59:59','2018-12-14 03:59:59','BRDETH','4h','0.002150000000000','0.002025200000000','0.076749430010018','0.072294393328506','35.697409306985115','35.697409306985115','test'),('2019-01-11 11:59:59','2019-01-15 03:59:59','BRDETH','4h','0.001538000000000','0.001506600000000','0.076749430010018','0.075182504065730','49.90210013655266','49.902100136552662','test'),('2019-01-15 23:59:59','2019-01-20 23:59:59','BRDETH','4h','0.001595100000000','0.001674600000000','0.076749430010018','0.080574631994719','48.11574823523165','48.115748235231649','test'),('2019-01-21 19:59:59','2019-01-24 03:59:59','BRDETH','4h','0.001715400000000','0.001709400000000','0.076749430010018','0.076480981496517','44.741418916881194','44.741418916881194','test'),('2019-01-24 07:59:59','2019-01-30 23:59:59','BRDETH','4h','0.001741300000000','0.001857400000000','0.076749430010018','0.081866646356519','44.07593752369953','44.075937523699530','test'),('2019-02-27 15:59:59','2019-03-01 15:59:59','BRDETH','4h','0.001687700000000','0.001601800000000','0.076749430010018','0.072843062742221','45.475753990648805','45.475753990648805','test'),('2019-03-02 15:59:59','2019-03-03 03:59:59','BRDETH','4h','0.001646300000000','0.001607900000000','0.076749430010018','0.074959247107519','46.61934641925408','46.619346419254079','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','BRDETH','4h','0.001651800000000','0.001649100000000','0.076749430010018','0.076623976891585','46.46411793801792','46.464117938017921','test'),('2019-03-04 19:59:59','2019-03-05 15:59:59','BRDETH','4h','0.001645100000000','0.001645700000000','0.076749430010018','0.076777422021450','46.65335238588413','46.653352385884133','test'),('2019-03-08 23:59:59','2019-03-09 03:59:59','BRDETH','4h','0.001648600000000','0.001764200000000','0.076749430010018','0.082131107863444','46.55430669053621','46.554306690536208','test'),('2019-03-09 19:59:59','2019-03-11 15:59:59','BRDETH','4h','0.001697700000000','0.001671800000000','0.076749430010018','0.075578545732902','45.20788714732756','45.207887147327561','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','BRDETH','4h','0.001715400000000','0.002512400000000','0.076749430010018','0.112408340886772','44.741418916881194','44.741418916881194','test'),('2019-03-12 11:59:59','2019-03-17 07:59:59','BRDETH','4h','0.001750300000000','0.001871400000000','0.081438863259024','0.087073466664536','46.528516973675536','46.528516973675536','test'),('2019-03-17 11:59:59','2019-03-18 03:59:59','BRDETH','4h','0.001881300000000','0.001856300000000','0.082847514110402','0.081746579728453','44.03737527794731','44.037375277947312','test'),('2019-03-22 07:59:59','2019-03-23 15:59:59','BRDETH','4h','0.001859600000000','0.001859100000000','0.082847514110402','0.082825238482818','44.55125516799419','44.551255167994192','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','BRDETH','4h','0.001890500000000','0.001866600000000','0.082847514110402','0.081800142733920','43.82307014567681','43.823070145676809','test'),('2019-03-24 15:59:59','2019-03-24 23:59:59','BRDETH','4h','0.001876900000000','0.001855800000000','0.082847514110402','0.081916147203412','44.14061170568598','44.140611705685977','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','BRDETH','4h','0.001963400000000','0.001856000000000','0.082847514110402','0.078315669852759','42.195942808598346','42.195942808598346','test'),('2019-03-26 07:59:59','2019-03-26 11:59:59','BRDETH','4h','0.001864700000000','0.001899800000000','0.082847514110402','0.084406986274973','44.42940639802757','44.429406398027567','test'),('2019-03-26 15:59:59','2019-03-30 03:59:59','BRDETH','4h','0.001925200000000','0.002002700000000','0.082847514110402','0.086182587008572','43.033198686059634','43.033198686059634','test'),('2019-03-31 19:59:59','2019-04-01 15:59:59','BRDETH','4h','0.002108800000000','0.002044900000000','0.082847514110402','0.080337102429989','39.28656776858972','39.286567768589720','test'),('2019-04-01 19:59:59','2019-04-02 07:59:59','BRDETH','4h','0.002070100000000','0.002068900000000','0.082847514110402','0.082799488886049','40.02102029389981','40.021020293899809','test'),('2019-04-05 15:59:59','2019-04-06 15:59:59','BRDETH','4h','0.002042200000000','0.001990200000000','0.082847514110402','0.080737989708414','40.56777696131721','40.567776961317207','test'),('2019-04-06 19:59:59','2019-04-06 23:59:59','BRDETH','4h','0.001993500000000','0.002039100000000','0.082847514110402','0.084742596449722','41.55882323070078','41.558823230700781','test'),('2019-04-07 07:59:59','2019-04-07 23:59:59','BRDETH','4h','0.002026600000000','0.001958200000000','0.082847514110402','0.080051318529058','40.880052358828586','40.880052358828586','test'),('2019-04-20 19:59:59','2019-04-21 03:59:59','BRDETH','4h','0.001913500000000','0.001866100000000','0.082847514110402','0.080795268398966','43.296323026078916','43.296323026078916','test'),('2019-04-21 07:59:59','2019-04-21 11:59:59','BRDETH','4h','0.001868800000000','0.001879700000000','0.082847514110402','0.083330732166804','44.33193177996682','44.331931779966823','test'),('2019-04-21 15:59:59','2019-04-21 23:59:59','BRDETH','4h','0.001885400000000','0.001882500000000','0.082847514110402','0.082720083437378','43.941611387717195','43.941611387717195','test'),('2019-04-22 15:59:59','2019-04-22 19:59:59','BRDETH','4h','0.001915400000000','0.001873300000000','0.082847514110402','0.081026547030916','43.25337480964916','43.253374809649159','test'),('2019-04-28 19:59:59','2019-05-03 23:59:59','BRDETH','4h','0.001878600000000','0.002070500000000','0.082847514110402','0.091310432218454','44.100667577132974','44.100667577132974','test'),('2019-05-04 03:59:59','2019-05-06 23:59:59','BRDETH','4h','0.002165000000000','0.002181900000000','0.082847514110402','0.083494222188215','38.26675016646744','38.266750166467439','test'),('2019-05-08 19:59:59','2019-05-10 07:59:59','BRDETH','4h','0.002267900000000','0.002285000000000','0.082847514110402','0.083472185608831','36.53049698417126','36.530496984171258','test'),('2019-05-10 11:59:59','2019-05-11 11:59:59','BRDETH','4h','0.002315600000000','0.002248200000000','0.082847514110402','0.080436077570826','35.777990201417346','35.777990201417346','test'),('2019-05-11 15:59:59','2019-05-11 19:59:59','BRDETH','4h','0.002309100000000','0.002240300000000','0.082847514110402','0.080379059313816','35.87870343874323','35.878703438743230','test'),('2019-05-11 23:59:59','2019-05-14 03:59:59','BRDETH','4h','0.002388800000000','0.002265100000000','0.082847514110402','0.078557394596229','34.68164522371149','34.681645223711492','test'),('2019-06-09 19:59:59','2019-06-10 23:59:59','BRDETH','4h','0.001860500000000','0.001831600000000','0.082847514110402','0.081560605667623','44.52970390239291','44.529703902392910','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:18:05
