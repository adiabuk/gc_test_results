-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-29 23:59:59','2018-05-01 07:59:59','ENJETH','4h','0.000234010000000','0.000230920000000','0.072144500000000','0.071191863339174','308.2966539891458','308.296653989145796','test'),('2018-05-01 11:59:59','2018-05-02 03:59:59','ENJETH','4h','0.000232550000000','0.000229850000000','0.072144500000000','0.071306873038056','310.2322081272845','310.232208127284480','test'),('2018-05-21 23:59:59','2018-05-22 11:59:59','ENJETH','4h','0.000202890000000','0.000203190000000','0.072144500000000','0.072251175292030','355.5843067672138','355.584306767213775','test'),('2018-05-22 15:59:59','2018-05-23 03:59:59','ENJETH','4h','0.000203990000000','0.000203550000000','0.072144500000000','0.071988886587578','353.6668464140399','353.666846414039924','test'),('2018-05-23 07:59:59','2018-05-23 11:59:59','ENJETH','4h','0.000203760000000','0.000201950000000','0.072144500000000','0.071503640434825','354.0660581075776','354.066058107577589','test'),('2018-05-23 15:59:59','2018-05-23 19:59:59','ENJETH','4h','0.000202810000000','0.000195690000000','0.072144500000000','0.069611741063064','355.72456979438886','355.724569794388856','test'),('2018-07-03 11:59:59','2018-07-04 11:59:59','ENJETH','4h','0.000130580000000','0.000133000000000','0.072144500000000','0.073481532393935','552.4927247664267','552.492724766426704','test'),('2018-07-04 15:59:59','2018-07-06 07:59:59','ENJETH','4h','0.000138870000000','0.000131280000000','0.072144500000000','0.068201411103910','519.5110535032765','519.511053503276457','test'),('2018-07-08 03:59:59','2018-07-08 11:59:59','ENJETH','4h','0.000137240000000','0.000132050000000','0.072144500000000','0.069416214113961','525.6812882541533','525.681288254153287','test'),('2018-07-08 15:59:59','2018-07-08 19:59:59','ENJETH','4h','0.000132780000000','0.000132850000000','0.072144500000000','0.072182533702365','543.3386052116282','543.338605211628192','test'),('2018-07-09 15:59:59','2018-07-12 07:59:59','ENJETH','4h','0.000137760000000','0.000133540000000','0.072144500000000','0.069934498620790','523.6970092915215','523.697009291521454','test'),('2018-07-26 03:59:59','2018-07-26 19:59:59','ENJETH','4h','0.000134600000000','0.000131330000000','0.072144500000000','0.070391806723626','535.9918276374443','535.991827637444317','test'),('2018-07-28 11:59:59','2018-07-29 07:59:59','ENJETH','4h','0.000134610000000','0.000130630000000','0.072144500000000','0.070011411002154','535.9520095089518','535.952009508951846','test'),('2018-07-29 15:59:59','2018-07-30 19:59:59','ENJETH','4h','0.000134810000000','0.000131640000000','0.072144500000000','0.070448052666716','535.1568874712559','535.156887471255914','test'),('2018-07-30 23:59:59','2018-07-31 19:59:59','ENJETH','4h','0.000132990000000','0.000129590000000','0.072144500000000','0.070300065832017','542.480637641928','542.480637641927956','test'),('2018-08-12 11:59:59','2018-08-14 03:59:59','ENJETH','4h','0.000125510000000','0.000119950000000','0.072144500000000','0.068948552107402','574.8107720500358','574.810772050035780','test'),('2018-08-14 07:59:59','2018-08-14 11:59:59','ENJETH','4h','0.000126120000000','0.000129760000000','0.072144500000000','0.074226691405011','572.0306057722804','572.030605772280410','test'),('2018-08-14 19:59:59','2018-08-15 03:59:59','ENJETH','4h','0.000128480000000','0.000131850000000','0.072144500000000','0.074036833164695','561.523194271482','561.523194271481998','test'),('2018-08-15 07:59:59','2018-08-15 23:59:59','ENJETH','4h','0.000136490000000','0.000129030000000','0.072144500000000','0.068201368854861','528.5698585976995','528.569858597699522','test'),('2018-08-16 11:59:59','2018-08-18 19:59:59','ENJETH','4h','0.000128970000000','0.000132180000000','0.072144500000000','0.073940141195627','559.3897805691246','559.389780569124582','test'),('2018-08-18 23:59:59','2018-08-19 07:59:59','ENJETH','4h','0.000133250000000','0.000132150000000','0.072144500000000','0.071548935647280','541.4221388367729','541.422138836772888','test'),('2018-08-21 23:59:59','2018-08-22 03:59:59','ENJETH','4h','0.000133140000000','0.000133780000000','0.072144500000000','0.072491296454860','541.8694607180412','541.869460718041182','test'),('2018-08-22 07:59:59','2018-08-22 11:59:59','ENJETH','4h','0.000134220000000','0.000134220000000','0.072144500000000','0.072144500000000','537.5093130680972','537.509313068097185','test'),('2018-08-24 19:59:59','2018-08-24 23:59:59','ENJETH','4h','0.000136120000000','0.000133520000000','0.072144500000000','0.070766482809286','530.0066118131061','530.006611813106133','test'),('2018-08-25 03:59:59','2018-08-25 07:59:59','ENJETH','4h','0.000133620000000','0.000134800000000','0.072144500000000','0.072781609040563','539.9229157311779','539.922915731177909','test'),('2018-08-25 11:59:59','2018-08-25 19:59:59','ENJETH','4h','0.000136440000000','0.000134510000000','0.072144500000000','0.071123986330988','528.7635590735855','528.763559073585498','test'),('2018-08-25 23:59:59','2018-08-26 07:59:59','ENJETH','4h','0.000135600000000','0.000132800000000','0.072144500000000','0.070654790560472','532.0390855457227','532.039085545722742','test'),('2018-08-26 11:59:59','2018-09-09 15:59:59','ENJETH','4h','0.000134040000000','0.000202110000000','0.072144500000000','0.108781892681289','538.2311250373023','538.231125037302263','test'),('2018-09-11 07:59:59','2018-09-12 23:59:59','ENJETH','4h','0.000209730000000','0.000199570000000','0.075100196541634','0.071462099956200','358.0803725820519','358.080372582051893','test'),('2018-09-13 07:59:59','2018-09-13 15:59:59','ENJETH','4h','0.000206880000000','0.000196310000000','0.075100196541634','0.071263145703249','363.01332435051233','363.013324350512335','test'),('2018-09-17 23:59:59','2018-09-18 15:59:59','ENJETH','4h','0.000201500000000','0.000193510000000','0.075100196541634','0.072122278078271','372.7056900329231','372.705690032923087','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','ENJETH','4h','0.000194470000000','0.000199110000000','0.075100196541634','0.076892066300225','386.178827282532','386.178827282531984','test'),('2018-09-20 19:59:59','2018-09-20 23:59:59','ENJETH','4h','0.000197160000000','0.000188110000000','0.075100196541634','0.071652961916447','380.9099033355346','380.909903335534580','test'),('2018-09-27 07:59:59','2018-09-27 23:59:59','ENJETH','4h','0.000194500000000','0.000190760000000','0.075100196541634','0.073656110500165','386.11926242485345','386.119262424853446','test'),('2018-09-28 03:59:59','2018-09-30 19:59:59','ENJETH','4h','0.000253010000000','0.000249170000000','0.075100196541634','0.073960380903043','296.82698921637086','296.826989216370862','test'),('2018-10-11 03:59:59','2018-10-11 07:59:59','ENJETH','4h','0.000249640000000','0.000239640000000','0.075100196541634','0.072091856670554','300.8339871079715','300.833987107971495','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','ENJETH','4h','0.000243220000000','0.000242580000000','0.075100196541634','0.074902580696775','308.77475759244305','308.774757592443052','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','ENJETH','4h','0.000239550000000','0.000243770000000','0.075100196541634','0.076423188941574','313.50530804272177','313.505308042721765','test'),('2018-10-12 23:59:59','2018-10-13 11:59:59','ENJETH','4h','0.000245740000000','0.000240430000000','0.075100196541634','0.073477416189896','305.608352493017','305.608352493016980','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','ENJETH','4h','0.000245680000000','0.000241750000000','0.075100196541634','0.073898862397997','305.68298820267825','305.682988202678246','test'),('2018-10-13 23:59:59','2018-10-14 03:59:59','ENJETH','4h','0.000243510000000','0.000245220000000','0.075100196541634','0.075627572567613','308.4070327363722','308.407032736372173','test'),('2018-10-14 07:59:59','2018-10-15 03:59:59','ENJETH','4h','0.000249150000000','0.000242750000000','0.075100196541634','0.073171072488387','301.42563331982336','301.425633319823362','test'),('2018-10-20 15:59:59','2018-10-21 23:59:59','ENJETH','4h','0.000254300000000','0.000242970000000','0.075100196541634','0.071754206660326','295.3212604861738','295.321260486173799','test'),('2018-10-22 03:59:59','2018-10-22 07:59:59','ENJETH','4h','0.000245590000000','0.000246200000000','0.075100196541634','0.075286731497823','305.79501014550266','305.795010145502658','test'),('2018-10-22 11:59:59','2018-10-22 15:59:59','ENJETH','4h','0.000246900000000','0.000250580000000','0.075100196541634','0.076219551435410','304.17252548251923','304.172525482519234','test'),('2018-10-22 19:59:59','2018-10-26 03:59:59','ENJETH','4h','0.000252500000000','0.000248350000000','0.075100196541634','0.073865876479663','297.4265209569663','297.426520956966328','test'),('2018-11-01 07:59:59','2018-11-02 15:59:59','ENJETH','4h','0.000254530000000','0.000250200000000','0.075100196541634','0.073822610987769','295.05440043073116','295.054400430731164','test'),('2018-11-12 11:59:59','2018-11-12 15:59:59','ENJETH','4h','0.000250210000000','0.000241380000000','0.075100196541634','0.072449883862434','300.1486612910515','300.148661291051496','test'),('2018-11-12 23:59:59','2018-11-13 03:59:59','ENJETH','4h','0.000239970000000','0.000239740000000','0.075100196541634','0.075028216522446','312.9566051657874','312.956605165787380','test'),('2018-11-13 07:59:59','2018-11-13 11:59:59','ENJETH','4h','0.000241900000000','0.000237660000000','0.075100196541634','0.073783847499317','310.45967979179','310.459679791789995','test'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ENJETH','4h','0.000239800000000','0.000240530000000','0.075100196541634','0.075328816823016','313.17846764651375','313.178467646513752','test'),('2018-11-28 23:59:59','2018-11-29 07:59:59','ENJETH','4h','0.000222320000000','0.000220960000000','0.075100196541634','0.074640785479666','337.8022514467164','337.802251446716411','test'),('2018-11-29 11:59:59','2018-12-13 15:59:59','ENJETH','4h','0.000234460000000','0.000318650000000','0.075100196541634','0.102067208171934','320.31133899869485','320.311338998694850','test'),('2018-12-13 19:59:59','2018-12-14 15:59:59','ENJETH','4h','0.000324230000000','0.000319030000000','0.075100196541634','0.073895739760903','231.62630398678098','231.626303986780982','test'),('2018-12-14 23:59:59','2018-12-18 03:59:59','ENJETH','4h','0.000338810000000','0.000349540000000','0.075100196541634','0.077478594785168','221.65873658284585','221.658736582845847','test'),('2018-12-20 11:59:59','2018-12-20 19:59:59','ENJETH','4h','0.000362550000000','0.000357530000000','0.075100196541634','0.074060331732259','207.14438433770238','207.144384337702377','test'),('2018-12-20 23:59:59','2018-12-23 03:59:59','ENJETH','4h','0.000359500000000','0.000338000000000','0.075100196541634','0.070608807875027','208.90179844682612','208.901798446826120','test'),('2019-01-12 07:59:59','2019-01-13 07:59:59','ENJETH','4h','0.000297960000000','0.000277070000000','0.075100196541634','0.069834915612131','252.0479142892804','252.047914289280413','test'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ENJETH','4h','0.000287220000000','0.000263880000000','0.075100196541634','0.068997423102174','261.4727266263979','261.472726626397900','test'),('2019-01-16 15:59:59','2019-01-17 07:59:59','ENJETH','4h','0.000277550000000','0.000277400000000','0.075100196541634','0.075059609153844','270.58258526980364','270.582585269803644','test'),('2019-01-17 15:59:59','2019-01-17 19:59:59','ENJETH','4h','0.000277070000000','0.000275680000000','0.075100196541634','0.074723435170165','271.05134638045985','271.051346380459847','test'),('2019-01-17 23:59:59','2019-01-18 15:59:59','ENJETH','4h','0.000276180000000','0.000274320000000','0.075100196541634','0.074594416378091','271.92481910939966','271.924819109399664','test'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ENJETH','4h','0.000278140000000','0.000281100000000','0.075100196541634','0.075899422045924','270.00861631420867','270.008616314208666','test'),('2019-01-19 19:59:59','2019-01-19 23:59:59','ENJETH','4h','0.000281080000000','0.000276320000000','0.075100196541634','0.073828398706362','267.18441917473314','267.184419174733137','test'),('2019-01-21 03:59:59','2019-01-21 07:59:59','ENJETH','4h','0.000283480000000','0.000280830000000','0.075100196541634','0.074398152232211','264.9223809144701','264.922380914470125','test'),('2019-01-21 15:59:59','2019-01-21 23:59:59','ENJETH','4h','0.000285220000000','0.000288000000000','0.075100196541634','0.075832187798859','263.30620763492743','263.306207634927432','test'),('2019-01-22 03:59:59','2019-01-26 19:59:59','ENJETH','4h','0.000288640000000','0.000291460000000','0.075100196541634','0.075833922131460','260.18637937096037','260.186379370960367','test'),('2019-01-29 23:59:59','2019-01-30 15:59:59','ENJETH','4h','0.000305720000000','0.000289590000000','0.075100196541634','0.071137857897723','245.6502569070849','245.650256907084895','test'),('2019-01-30 23:59:59','2019-01-31 03:59:59','ENJETH','4h','0.000291930000000','0.000286570000000','0.075100196541634','0.073721314434748','257.254124418984','257.254124418984020','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','ENJETH','4h','0.000287220000000','0.000279920000000','0.075100196541634','0.073191445637261','261.4727266263979','261.472726626397900','test'),('2019-02-16 03:59:59','2019-02-16 11:59:59','ENJETH','4h','0.000257180000000','0.000254780000000','0.075100196541634','0.074399362605481','292.01414006390075','292.014140063900754','test'),('2019-02-21 15:59:59','2019-02-23 19:59:59','ENJETH','4h','0.000257720000000','0.000252060000000','0.075100196541634','0.073450859616189','291.4022836475011','291.402283647501122','test'),('2019-02-24 23:59:59','2019-03-02 07:59:59','ENJETH','4h','0.000271470000000','0.000560000000000','0.075100196541634','0.154919917719509','276.64271021340846','276.642710213408463','test'),('2019-03-02 19:59:59','2019-03-11 23:59:59','ENJETH','4h','0.000637530000000','0.001232090000000','0.087901846229674','0.169879042117420','137.87876057546083','137.878760575460831','test'),('2019-03-18 11:59:59','2019-03-23 11:59:59','ENJETH','4h','0.001470060000000','0.001347880000000','0.108396145201610','0.099387097257490','73.73586465968059','73.735864659680587','test'),('2019-04-14 03:59:59','2019-04-15 03:59:59','ENJETH','4h','0.001057820000000','0.000942080000000','0.108396145201610','0.096536121903096','102.47125711520866','102.471257115208658','test'),('2019-04-15 07:59:59','2019-04-15 15:59:59','ENJETH','4h','0.000976060000000','0.000930770000000','0.108396145201610','0.103366473443541','111.054797042815','111.054797042814997','test'),('2019-04-17 11:59:59','2019-04-20 11:59:59','ENJETH','4h','0.000989480000000','0.001156600000000','0.108396145201610','0.126703906638014','109.54859643611796','109.548596436117961','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:36:42
