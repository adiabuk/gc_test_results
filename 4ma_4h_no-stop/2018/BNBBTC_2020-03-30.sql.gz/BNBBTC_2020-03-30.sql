-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-01 19:59:59','2018-01-02 19:59:59','BNBBTC','4h','0.000613980000000','0.000602640000000','0.001467500000000','0.001440395778364','2.3901430014006975','2.390143001400697','test'),('2018-01-04 11:59:59','2018-01-10 15:59:59','BNBBTC','4h','0.000616890000000','0.001122400000000','0.001467500000000','0.002670041660588','2.3788681936812073','2.378868193681207','test'),('2018-01-11 07:59:59','2018-01-14 19:59:59','BNBBTC','4h','0.001233700000000','0.001516400000000','0.001761359359738','0.002164971494777','1.4277047578325364','1.427704757832536','test'),('2018-01-15 03:59:59','2018-01-15 15:59:59','BNBBTC','4h','0.001635000000000','0.001493700000000','0.001862262393498','0.001701321918757','1.1389984058090215','1.138998405809021','test'),('2018-02-10 15:59:59','2018-02-10 23:59:59','BNBBTC','4h','0.001108400000000','0.001083900000000','0.001862262393498','0.001821099069210','1.680135685220137','1.680135685220137','test'),('2018-02-15 07:59:59','2018-02-15 23:59:59','BNBBTC','4h','0.001114800000000','0.001085700000000','0.001862262393498','0.001813651130804','1.670490126926803','1.670490126926803','test'),('2018-02-16 11:59:59','2018-02-16 23:59:59','BNBBTC','4h','0.001082600000000','0.001103900000000','0.001862262393498','0.001898902139463','1.7201758668926659','1.720175866892666','test'),('2018-02-17 03:59:59','2018-02-17 11:59:59','BNBBTC','4h','0.001104500000000','0.001080600000000','0.001862262393498','0.001821965362077','1.686068260296967','1.686068260296967','test'),('2018-02-27 19:59:59','2018-03-01 15:59:59','BNBBTC','4h','0.001014300000000','0.000973800000000','0.001862262393498','0.001787904090297','1.836007486441881','1.836007486441881','test'),('2018-03-13 19:59:59','2018-03-18 15:59:59','BNBBTC','4h','0.001091500000000','0.001079400000000','0.001862262393498','0.001841617982173','1.7061496962876774','1.706149696287677','test'),('2018-03-21 23:59:59','2018-03-27 07:59:59','BNBBTC','4h','0.001119900000000','0.001420300000000','0.001862262393498','0.002361792372074','1.662882751583177','1.662882751583177','test'),('2018-03-27 11:59:59','2018-03-29 15:59:59','BNBBTC','4h','0.001471900000000','0.001448500000000','0.001899801122716','0.001869598428055','1.2907134470517698','1.290713447051770','test'),('2018-03-30 19:59:59','2018-04-07 15:59:59','BNBBTC','4h','0.001478800000000','0.001787700000000','0.001899801122716','0.002296642187638','1.2846910486313228','1.284691048631323','test'),('2018-04-26 07:59:59','2018-04-29 11:59:59','BNBBTC','4h','0.001613700000000','0.001587900000000','0.001991460715281','0.001959621038480','1.2340960000500403','1.234096000050040','test'),('2018-04-29 19:59:59','2018-04-30 03:59:59','BNBBTC','4h','0.001589500000000','0.001576000000000','0.001991460715281','0.001974546767715','1.25288500489525','1.252885004895250','test'),('2018-05-10 15:59:59','2018-05-11 07:59:59','BNBBTC','4h','0.001538200000000','0.001506700000000','0.001991460715281','0.001950678624180','1.2946695587576387','1.294669558757639','test'),('2018-05-11 23:59:59','2018-05-12 03:59:59','BNBBTC','4h','0.001547500000000','0.001499700000000','0.001991460715281','0.001929947421458','1.2868889921040385','1.286888992104039','test'),('2018-05-12 11:59:59','2018-05-12 15:59:59','BNBBTC','4h','0.001524200000000','0.001508000000000','0.001991460715281','0.001970294422414','1.3065612880730872','1.306561288073087','test'),('2018-05-12 19:59:59','2018-05-12 23:59:59','BNBBTC','4h','0.001518500000000','0.001530900000000','0.001991460715281','0.002007722890368','1.3114657328159365','1.311465732815936','test'),('2018-05-13 03:59:59','2018-05-13 19:59:59','BNBBTC','4h','0.001536000000000','0.001499500000000','0.001991460715281','0.001944137592815','1.2965239031777342','1.296523903177734','test'),('2018-05-13 23:59:59','2018-05-14 03:59:59','BNBBTC','4h','0.001517500000000','0.001484700000000','0.001991460715281','0.001948416292572','1.3123299606464578','1.312329960646458','test'),('2018-05-18 03:59:59','2018-05-20 15:59:59','BNBBTC','4h','0.001537200000000','0.001648500000000','0.001991460715281','0.002135651176907','1.2955117845960185','1.295511784596018','test'),('2018-05-21 23:59:59','2018-05-23 07:59:59','BNBBTC','4h','0.001751100000000','0.001652500000000','0.001991460715281','0.001879326612987','1.1372627007486722','1.137262700748672','test'),('2018-05-24 23:59:59','2018-05-27 19:59:59','BNBBTC','4h','0.001717700000000','0.001697400000000','0.001991460715281','0.001967925375862','1.1593763260645047','1.159376326064505','test'),('2018-05-31 07:59:59','2018-06-04 07:59:59','BNBBTC','4h','0.001835400000000','0.001848100000000','0.001991460715281','0.002005240573123','1.0850281765724092','1.085028176572409','test'),('2018-06-05 03:59:59','2018-06-10 03:59:59','BNBBTC','4h','0.001933800000000','0.002104900000000','0.001991460715281','0.002167662457128','1.0298173106220911','1.029817310622091','test'),('2018-06-11 11:59:59','2018-06-14 11:59:59','BNBBTC','4h','0.002211200000000','0.002223800000000','0.001991460715281','0.002002808582960','0.9006244189946635','0.900624418994664','test'),('2018-06-15 15:59:59','2018-06-19 11:59:59','BNBBTC','4h','0.002345100000000','0.002455800000000','0.001991460715281','0.002085467240027','0.8492007655456056','0.849200765545606','test'),('2018-06-21 23:59:59','2018-06-24 03:59:59','BNBBTC','4h','0.002542600000000','0.002412200000000','0.002005844800226','0.001902972873085','0.7888951467891138','0.788895146789114','test'),('2018-07-28 15:59:59','2018-07-29 15:59:59','BNBBTC','4h','0.001834000000000','0.001672500000000','0.002005844800226','0.001829212338265','1.0936994548669576','1.093699454866958','test'),('2018-07-29 19:59:59','2018-07-29 23:59:59','BNBBTC','4h','0.001711700000000','0.001700700000000','0.002005844800226','0.001992954519918','1.1718436643255243','1.171843664325524','test'),('2018-07-31 23:59:59','2018-08-08 07:59:59','BNBBTC','4h','0.001789800000000','0.001918700000000','0.002005844800226','0.002150304178229','1.1207089061492905','1.120708906149291','test'),('2018-08-09 11:59:59','2018-08-11 11:59:59','BNBBTC','4h','0.001969500000000','0.001922000000000','0.002005844800226','0.001957468243734','1.0184538208814422','1.018453820881442','test'),('2018-08-28 07:59:59','2018-08-29 03:59:59','BNBBTC','4h','0.001599500000000','0.001557300000000','0.002005844800226','0.001952924105903','1.2540448891691154','1.254044889169115','test'),('2018-08-29 07:59:59','2018-08-29 15:59:59','BNBBTC','4h','0.001567100000000','0.001554600000000','0.002005844800226','0.001989845144810','1.2799724333010019','1.279972433301002','test'),('2018-08-29 19:59:59','2018-08-30 07:59:59','BNBBTC','4h','0.001570400000000','0.001559600000000','0.002005844800226','0.001992050146735','1.2772827306584311','1.277282730658431','test'),('2018-09-01 03:59:59','2018-09-02 03:59:59','BNBBTC','4h','0.001600800000000','0.001583100000000','0.002005844800226','0.001983666231408','1.2530264868978012','1.253026486897801','test'),('2018-09-15 19:59:59','2018-09-16 07:59:59','BNBBTC','4h','0.001555700000000','0.001527000000000','0.002005844800226','0.001968840399785','1.2893519317516233','1.289351931751623','test'),('2018-09-16 11:59:59','2018-09-16 19:59:59','BNBBTC','4h','0.001529300000000','0.001515200000000','0.002005844800226','0.001987351102663','1.3116097562453413','1.311609756245341','test'),('2018-09-16 23:59:59','2018-09-17 15:59:59','BNBBTC','4h','0.001528700000000','0.001510900000000','0.002005844800226','0.001982488983229','1.3121245504193106','1.312124550419311','test'),('2018-09-20 23:59:59','2018-09-21 11:59:59','BNBBTC','4h','0.001546200000000','0.001528100000000','0.002005844800226','0.001982364143853','1.2972738327680766','1.297273832768077','test'),('2018-09-21 19:59:59','2018-09-22 03:59:59','BNBBTC','4h','0.001534800000000','0.001531500000000','0.002005844800226','0.002001531998662','1.306909564911389','1.306909564911389','test'),('2018-09-22 07:59:59','2018-09-22 11:59:59','BNBBTC','4h','0.001531900000000','0.001507700000000','0.002005844800226','0.001974157716105','1.3093836413773745','1.309383641377375','test'),('2018-09-22 15:59:59','2018-09-22 19:59:59','BNBBTC','4h','0.001531900000000','0.001523400000000','0.002005844800226','0.001994715039274','1.3093836413773745','1.309383641377375','test'),('2018-09-22 23:59:59','2018-09-23 07:59:59','BNBBTC','4h','0.001529600000000','0.001517400000000','0.002005844800226','0.001989846299597','1.3113525106080022','1.311352510608002','test'),('2018-09-23 11:59:59','2018-09-23 15:59:59','BNBBTC','4h','0.001534500000000','0.001523500000000','0.002005844800226','0.001991465984454','1.307165070202672','1.307165070202672','test'),('2018-09-23 19:59:59','2018-09-24 07:59:59','BNBBTC','4h','0.001528500000000','0.001518500000000','0.002005844800226','0.001992721837843','1.3122962382898269','1.312296238289827','test'),('2018-10-02 23:59:59','2018-10-07 07:59:59','BNBBTC','4h','0.001580000000000','0.001580200000000','0.002005844800226','0.002006098704631','1.2695220254594937','1.269522025459494','test'),('2018-10-07 15:59:59','2018-10-09 07:59:59','BNBBTC','4h','0.001588200000000','0.001582200000000','0.002005844800226','0.001998266995918','1.262967384602695','1.262967384602695','test'),('2018-11-04 11:59:59','2018-11-04 15:59:59','BNBBTC','4h','0.001503300000000','0.001497100000000','0.002005844800226','0.001997572174828','1.3342944190953239','1.334294419095324','test'),('2018-11-04 19:59:59','2018-11-06 03:59:59','BNBBTC','4h','0.001515800000000','0.001503300000000','0.002005844800226','0.001989303660232','1.3232911995157672','1.323291199515767','test'),('2018-11-06 07:59:59','2018-11-06 19:59:59','BNBBTC','4h','0.001506600000000','0.001501600000000','0.002005844800226','0.001999187941072','1.3313718307619806','1.331371830761981','test'),('2018-11-06 23:59:59','2018-11-07 03:59:59','BNBBTC','4h','0.001513300000000','0.001510900000000','0.002005844800226','0.002002663654703','1.325477301411485','1.325477301411485','test'),('2018-11-07 11:59:59','2018-11-07 15:59:59','BNBBTC','4h','0.001503400000000','0.001501200000000','0.002005844800226','0.002002909547758','1.334205667304776','1.334205667304776','test'),('2018-12-04 03:59:59','2018-12-06 15:59:59','BNBBTC','4h','0.001363400000000','0.001427200000000','0.002005844800226','0.002099707861877','1.4712078628619627','1.471207862861963','test'),('2018-12-11 23:59:59','2018-12-13 23:59:59','BNBBTC','4h','0.001449500000000','0.001406100000000','0.002005844800226','0.001945787080785','1.3838184203007935','1.383818420300793','test'),('2018-12-14 11:59:59','2018-12-14 19:59:59','BNBBTC','4h','0.001413000000000','0.001391500000000','0.002005844800226','0.001975324161015','1.419564614455768','1.419564614455768','test'),('2018-12-15 11:59:59','2018-12-15 15:59:59','BNBBTC','4h','0.001420400000000','0.001407600000000','0.002005844800226','0.001987769037453','1.4121689666474233','1.412168966647423','test'),('2018-12-15 19:59:59','2018-12-20 11:59:59','BNBBTC','4h','0.001412100000000','0.001429100000000','0.002005844800226','0.002029992779550','1.4204693720175627','1.420469372017563','test'),('2018-12-22 19:59:59','2018-12-25 03:59:59','BNBBTC','4h','0.001493700000000','0.001445500000000','0.002005844800226','0.001941118470059','1.3428699204833636','1.342869920483364','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','BNBBTC','4h','0.001473800000000','0.001460900000000','0.002005844800226','0.001988287873965','1.3610020357076946','1.361002035707695','test'),('2018-12-28 19:59:59','2019-01-02 07:59:59','BNBBTC','4h','0.001513200000000','0.001563700000000','0.002005844800226','0.002072785827461','1.3255648957348667','1.325564895734867','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  1:28:50
