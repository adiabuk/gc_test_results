-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 15:59:59','2019-01-10 07:59:59','VETUSDT','4h','0.004308000000000','0.004230000000000','15.000000000000000','14.728412256267410','3481.894150417827','3481.894150417826950','test'),('2019-01-18 07:59:59','2019-01-18 19:59:59','VETUSDT','4h','0.004059000000000','0.003988000000000','15.000000000000000','14.737620103473763','3695.491500369549','3695.491500369549158','test'),('2019-01-18 23:59:59','2019-01-20 11:59:59','VETUSDT','4h','0.004014000000000','0.003983000000000','15.000000000000000','14.884155455904335','3736.9207772795216','3736.920777279521644','test'),('2019-01-21 15:59:59','2019-01-21 23:59:59','VETUSDT','4h','0.004061000000000','0.004066000000000','15.000000000000000','15.018468357547400','3693.671509480423','3693.671509480423083','test'),('2019-01-22 03:59:59','2019-01-25 19:59:59','VETUSDT','4h','0.004117000000000','0.004279000000000','15.000000000000000','15.590235608452756','3643.429681807141','3643.429681807141151','test'),('2019-01-26 03:59:59','2019-01-27 03:59:59','VETUSDT','4h','0.004371000000000','0.004243000000000','15.000000000000000','14.560741249142074','3431.7089910775567','3431.708991077556675','test'),('2019-02-09 23:59:59','2019-02-11 19:59:59','VETUSDT','4h','0.004018000000000','0.003921000000000','15.000000000000000','14.637879542060727','3733.200597312096','3733.200597312095852','test'),('2019-02-16 03:59:59','2019-02-24 15:59:59','VETUSDT','4h','0.004040000000000','0.004338000000000','15.000000000000000','16.106435643564353','3712.8712871287125','3712.871287128712538','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','VETUSDT','4h','0.004512000000000','0.004397000000000','15.065987054103203','14.681991373424596','3339.0928754661354','3339.092875466135411','test'),('2019-03-09 07:59:59','2019-03-11 11:59:59','VETUSDT','4h','0.004568000000000','0.004529000000000','15.065987054103203','14.937358880917996','3298.158286800176','3298.158286800176029','test'),('2019-03-12 11:59:59','2019-03-17 23:59:59','VETUSDT','4h','0.005169000000000','0.005196000000000','15.065987054103203','15.144683446144368','2914.6811867098477','2914.681186709847680','test'),('2019-03-19 19:59:59','2019-03-21 15:59:59','VETUSDT','4h','0.005340000000000','0.005486000000000','15.065987054103203','15.477903554084302','2821.3458902814987','2821.345890281498669','test'),('2019-03-21 19:59:59','2019-03-24 19:59:59','VETUSDT','4h','0.005517000000000','0.005715000000000','15.065987054103203','15.606691320318978','2730.829627352402','2730.829627352401985','test'),('2019-03-28 15:59:59','2019-04-08 07:59:59','VETUSDT','4h','0.005768000000000','0.007348000000000','15.195660380196760','19.358133230528050','2634.4764875514493','2634.476487551449281','test'),('2019-04-17 23:59:59','2019-04-20 03:59:59','VETUSDT','4h','0.007044000000000','0.007090000000000','16.236278592779584','16.342307669336634','2304.979925153263','2304.979925153263139','test'),('2019-05-03 03:59:59','2019-05-04 15:59:59','VETUSDT','4h','0.006565000000000','0.006419000000000','16.262785861918847','15.901115376642359','2477.195104633488','2477.195104633487972','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','VETUSDT','4h','0.006462000000000','0.006474000000000','16.262785861918847','16.292986021365309','2516.6799538716878','2516.679953871687758','test'),('2019-05-14 03:59:59','2019-05-17 19:59:59','VETUSDT','4h','0.006688000000000','0.007173000000000','16.262785861918847','17.442129633305004','2431.63664203332','2431.636642033320186','test'),('2019-05-18 03:59:59','2019-05-20 15:59:59','VETUSDT','4h','0.007618000000000','0.007700000000000','16.474754223307880','16.652088149051021','2162.6088505261064','2162.608850526106380','test'),('2019-05-21 07:59:59','2019-05-22 03:59:59','VETUSDT','4h','0.007884000000000','0.007722000000000','16.519087704743665','16.179654395742080','2095.267339515939','2095.267339515939057','test'),('2019-05-27 07:59:59','2019-05-27 19:59:59','VETUSDT','4h','0.007651000000000','0.007473000000000','16.519087704743665','16.134772241216758','2159.0756377916173','2159.075637791617282','test'),('2019-05-27 23:59:59','2019-05-29 07:59:59','VETUSDT','4h','0.007970000000000','0.007640000000000','16.519087704743665','15.835110422113125','2072.6584322137596','2072.658432213759625','test'),('2019-05-29 11:59:59','2019-05-30 23:59:59','VETUSDT','4h','0.007698000000000','0.007470000000000','16.519087704743665','16.029824000316339','2145.893440470728','2145.893440470727910','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','VETUSDT','4h','0.007648000000000','0.007473000000000','16.519087704743665','16.141101257524763','2159.922555536567','2159.922555536566961','test'),('2019-06-06 11:59:59','2019-06-06 19:59:59','VETUSDT','4h','0.008017000000000','0.007418000000000','16.519087704743665','15.284843781188538','2060.5073849000455','2060.507384900045508','test'),('2019-06-06 23:59:59','2019-06-07 11:59:59','VETUSDT','4h','0.007680000000000','0.007622000000000','16.519087704743665','16.394334177806797','2150.9228782218315','2150.922878221831525','test'),('2019-06-07 15:59:59','2019-06-08 07:59:59','VETUSDT','4h','0.007635000000000','0.007570000000000','16.519087704743665','16.378453690230458','2163.6002232801134','2163.600223280113369','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','VETUSDT','4h','0.007598000000000','0.007630000000000','16.519087704743665','16.588660066753640','2174.1363128117487','2174.136312811748667','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','VETUSDT','4h','0.007636000000000','0.007378000000000','16.519087704743665','15.960951949397428','2163.316881186965','2163.316881186965020','test'),('2019-06-13 07:59:59','2019-06-13 11:59:59','VETUSDT','4h','0.007587000000000','0.007497000000000','16.519087704743665','16.323131741460823','2177.288480920478','2177.288480920477923','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','VETUSDT','4h','0.007606000000000','0.007651000000000','16.519087704743665','16.616820934656030','2171.84955360816','2171.849553608160022','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','VETUSDT','4h','0.007596000000000','0.007491000000000','16.519087704743665','16.290743285444286','2174.708755232183','2174.708755232183194','test'),('2019-06-25 03:59:59','2019-06-26 19:59:59','VETUSDT','4h','0.010700000000000','0.008544000000000','16.519087704743665','13.190568724236437','1543.83997240595','1543.839972405949993','test'),('2019-06-27 03:59:59','2019-06-27 07:59:59','VETUSDT','4h','0.008390000000000','0.008198000000000','16.519087704743665','16.141058522465862','1968.9019910302343','1968.901991030234285','test'),('2019-06-29 19:59:59','2019-06-30 19:59:59','VETUSDT','4h','0.008746000000000','0.008510000000000','16.519087704743665','16.073340540517790','1888.759170448624','1888.759170448623991','test'),('2019-07-01 03:59:59','2019-07-01 11:59:59','VETUSDT','4h','0.008482000000000','0.008378000000000','16.519087704743665','16.316542889689039','1947.5462986021769','1947.546298602176876','test'),('2019-08-24 23:59:59','2019-08-25 15:59:59','VETUSDT','4h','0.004905000000000','0.004638000000000','16.519087704743665','15.619883542222450','3367.8058521393814','3367.805852139381386','test'),('2019-09-17 03:59:59','2019-09-19 15:59:59','VETUSDT','4h','0.004049000000000','0.004118000000000','16.519087704743665','16.800593521396497','4079.7944442439284','4079.794444243928410','test'),('2019-09-19 19:59:59','2019-09-21 15:59:59','VETUSDT','4h','0.004188000000000','0.004150000000000','16.519087704743665','16.369201044576460','3944.3857938738456','3944.385793873845614','test'),('2019-10-08 19:59:59','2019-10-11 11:59:59','VETUSDT','4h','0.003581000000000','0.003715000000000','16.519087704743665','17.137227261413770','4612.981766194825','4612.981766194824559','test'),('2019-10-12 07:59:59','2019-10-13 07:59:59','VETUSDT','4h','0.003727000000000','0.003619000000000','16.519087704743665','16.040402040103924','4432.274672590197','4432.274672590197042','test'),('2019-10-27 11:59:59','2019-11-01 07:59:59','VETUSDT','4h','0.003541000000000','0.003970000000000','16.519087704743665','18.520411801138760','4665.091133788101','4665.091133788100706','test'),('2019-11-02 15:59:59','2019-11-09 11:59:59','VETUSDT','4h','0.004158000000000','0.005222000000000','16.519087704743665','20.746194322792547','3972.844565835417','3972.844565835417143','test'),('2019-11-10 15:59:59','2019-11-18 19:59:59','VETUSDT','4h','0.005430000000000','0.007251000000000','16.519087704743665','22.058914354898032','3042.189264225353','3042.189264225352872','test'),('2019-11-18 23:59:59','2019-11-19 03:59:59','VETUSDT','4h','0.007388000000000','0.007222000000000','17.067974677421414','16.684476599937394','2310.2293824338676','2310.229382433867613','test'),('2019-11-27 19:59:59','2019-11-30 07:59:59','VETUSDT','4h','0.006555000000000','0.006284000000000','17.067974677421414','16.362342162153496','2603.810019438812','2603.810019438812105','test'),('2019-12-01 15:59:59','2019-12-04 03:59:59','VETUSDT','4h','0.006579000000000','0.006808000000000','17.067974677421414','17.662071987214620','2594.311396476883','2594.311396476883147','test'),('2019-12-04 15:59:59','2019-12-05 03:59:59','VETUSDT','4h','0.007440000000000','0.006748000000000','17.067974677421414','15.480469505811786','2294.0826179329856','2294.082617932985613','test'),('2019-12-07 07:59:59','2019-12-08 03:59:59','VETUSDT','4h','0.007100000000000','0.006708000000000','17.067974677421414','16.125630160020119','2403.9400954114667','2403.940095411466700','test'),('2019-12-08 23:59:59','2019-12-09 19:59:59','VETUSDT','4h','0.007127000000000','0.006829000000000','17.067974677421414','16.354314448170456','2394.8329840636193','2394.832984063619278','test'),('2019-12-24 03:59:59','2019-12-26 03:59:59','VETUSDT','4h','0.006206000000000','0.005582000000000','17.067974677421414','15.351826401767054','2750.2376212409627','2750.237621240962653','test'),('2019-12-29 03:59:59','2019-12-29 11:59:59','VETUSDT','4h','0.005787000000000','0.005647000000000','17.067974677421414','16.655063591394285','2949.364900193782','2949.364900193781978','test'),('2019-12-29 15:59:59','2019-12-29 19:59:59','VETUSDT','4h','0.005686000000000','0.005680000000000','17.067974677421414','17.049964151908835','3001.754252096626','3001.754252096625805','test'),('2020-01-06 03:59:59','2020-01-06 07:59:59','VETUSDT','4h','0.005527000000000','0.005458000000000','17.067974677421414','16.854895203431532','3088.108318693942','3088.108318693941783','test'),('2020-01-06 11:59:59','2020-01-07 15:59:59','VETUSDT','4h','0.005577000000000','0.005474000000000','17.067974677421414','16.752751189565146','3060.422212196775','3060.422212196775035','test'),('2020-01-07 19:59:59','2020-01-07 23:59:59','VETUSDT','4h','0.005585000000000','0.005578000000000','17.067974677421414','17.046582408353920','3056.0384382133243','3056.038438213324298','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:58:37
