-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-05 03:59:59','2018-07-05 15:59:59','RLCBTC','4h','0.000127900000000','0.000122600000000','0.001467500000000','0.001406688819390','11.473807662236123','11.473807662236123','test'),('2018-07-07 15:59:59','2018-07-08 07:59:59','RLCBTC','4h','0.000124800000000','0.000122100000000','0.001467500000000','0.001435751201923','11.758814102564104','11.758814102564104','test'),('2018-07-08 11:59:59','2018-07-08 15:59:59','RLCBTC','4h','0.000122400000000','0.000121200000000','0.001467500000000','0.001453112745098','11.989379084967322','11.989379084967322','test'),('2018-07-09 19:59:59','2018-07-09 23:59:59','RLCBTC','4h','0.000121900000000','0.000119600000000','0.001467500000000','0.001439811320755','12.038556193601314','12.038556193601314','test'),('2018-08-23 03:59:59','2018-08-27 03:59:59','RLCBTC','4h','0.000057000000000','0.000064300000000','0.001467500000000','0.001655442982456','25.74561403508772','25.745614035087719','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','RLCBTC','4h','0.000057000000000','0.000054400000000','0.001480826767406','0.001413280283279','25.979416972026314','25.979416972026314','test'),('2018-09-18 15:59:59','2018-09-19 19:59:59','RLCBTC','4h','0.000058200000000','0.000056500000000','0.001480826767406','0.001437572377293','25.44375889013746','25.443758890137460','test'),('2018-09-19 23:59:59','2018-09-20 23:59:59','RLCBTC','4h','0.000056900000000','0.000057300000000','0.001480826767406','0.001491236797405','26.02507499834798','26.025074998347979','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','RLCBTC','4h','0.000056800000000','0.000056600000000','0.001480826767406','0.001475612588648','26.070893792359158','26.070893792359158','test'),('2018-09-21 23:59:59','2018-09-22 15:59:59','RLCBTC','4h','0.000060900000000','0.000057200000000','0.001480826767406','0.001390858638680','24.31571046643678','24.315710466436780','test'),('2018-09-22 19:59:59','2018-09-24 11:59:59','RLCBTC','4h','0.000059700000000','0.000056600000000','0.001480826767406','0.001403932915162','24.804468465762145','24.804468465762145','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','RLCBTC','4h','0.000058100000000','0.000057800000000','0.001480826767406','0.001473180501826','25.487551934698796','25.487551934698796','test'),('2018-09-28 03:59:59','2018-09-29 03:59:59','RLCBTC','4h','0.000057700000000','0.000057800000000','0.001480826767406','0.001483393191613','25.664242069428077','25.664242069428077','test'),('2018-09-29 07:59:59','2018-10-04 11:59:59','RLCBTC','4h','0.000058000000000','0.000060600000000','0.001480826767406','0.001547208656979','25.53149598975862','25.531495989758621','test'),('2018-10-07 07:59:59','2018-10-07 11:59:59','RLCBTC','4h','0.000061100000000','0.000061200000000','0.001480826767406','0.001483250379137','24.23611730615385','24.236117306153851','test'),('2018-10-08 07:59:59','2018-10-11 03:59:59','RLCBTC','4h','0.000062700000000','0.000060600000000','0.001480826767406','0.001431229698641','23.61765179275917','23.617651792759169','test'),('2018-10-13 15:59:59','2018-10-14 23:59:59','RLCBTC','4h','0.000065600000000','0.000062200000000','0.001480826767406','0.001404076599583','22.573578771432928','22.573578771432928','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','RLCBTC','4h','0.000064000000000','0.000061900000000','0.001480826767406','0.001432237139100','23.13791824071875','23.137918240718751','test'),('2018-10-16 23:59:59','2018-10-17 03:59:59','RLCBTC','4h','0.000063800000000','0.000062900000000','0.001480826767406','0.001459937361596','23.210450899780565','23.210450899780565','test'),('2018-10-17 07:59:59','2018-10-26 23:59:59','RLCBTC','4h','0.000063700000000','0.000075300000000','0.001480826767406','0.001750490668535','23.24688802835165','23.246888028351648','test'),('2018-11-02 03:59:59','2018-11-03 03:59:59','RLCBTC','4h','0.000075600000000','0.000073700000000','0.001480826767406','0.001443610221664','19.58765565351852','19.587655653518521','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','RLCBTC','4h','0.000082100000000','0.000061500000000','0.001480826767406','0.001109267310542','18.036866838075518','18.036866838075518','test'),('2018-11-29 03:59:59','2018-11-29 23:59:59','RLCBTC','4h','0.000060900000000','0.000058400000000','0.001480826767406','0.001420037491240','24.31571046643678','24.315710466436780','test'),('2018-12-23 19:59:59','2018-12-25 03:59:59','RLCBTC','4h','0.000051100000000','0.000049600000000','0.001480826767406','0.001437358271298','28.97899740520548','28.978997405205480','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','RLCBTC','4h','0.000050100000000','0.000050700000000','0.001480826767406','0.001498561219710','29.55742050710579','29.557420507105789','test'),('2018-12-29 11:59:59','2018-12-29 19:59:59','RLCBTC','4h','0.000051800000000','0.000050400000000','0.001480826767406','0.001440804422341','28.587389332162164','28.587389332162164','test'),('2018-12-30 03:59:59','2018-12-30 07:59:59','RLCBTC','4h','0.000050100000000','0.000050500000000','0.001480826767406','0.001492649735609','29.55742050710579','29.557420507105789','test'),('2018-12-30 19:59:59','2018-12-30 23:59:59','RLCBTC','4h','0.000050600000000','0.000050500000000','0.001480826767406','0.001477900232293','29.26535113450593','29.265351134505931','test'),('2019-01-02 15:59:59','2019-01-02 23:59:59','RLCBTC','4h','0.000051800000000','0.000050800000000','0.001480826767406','0.001452239378074','28.587389332162164','28.587389332162164','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','RLCBTC','4h','0.000050100000000','0.000050400000000','0.001480826767406','0.001489693993558','29.55742050710579','29.557420507105789','test'),('2019-01-05 07:59:59','2019-01-08 11:59:59','RLCBTC','4h','0.000050700000000','0.000051600000000','0.001480826767406','0.001507113633100','29.207628548441814','29.207628548441814','test'),('2019-01-08 15:59:59','2019-01-08 23:59:59','RLCBTC','4h','0.000052200000000','0.000051800000000','0.001480826767406','0.001469479435855','28.36832887750958','28.368328877509580','test'),('2019-01-09 11:59:59','2019-01-10 07:59:59','RLCBTC','4h','0.000053100000000','0.000051100000000','0.001480826767406','0.001425051747918','27.887509743992467','27.887509743992467','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','RLCBTC','4h','0.000053500000000','0.000051500000000','0.001480826767406','0.001425468757410','27.67900499824299','27.679004998242991','test'),('2019-01-15 15:59:59','2019-01-18 03:59:59','RLCBTC','4h','0.000058200000000','0.000056800000000','0.001480826767406','0.001445205504960','25.44375889013746','25.443758890137460','test'),('2019-01-22 19:59:59','2019-01-23 11:59:59','RLCBTC','4h','0.000056000000000','0.000055600000000','0.001480826767406','0.001470249433353','26.443335132250002','26.443335132250002','test'),('2019-01-23 15:59:59','2019-01-29 03:59:59','RLCBTC','4h','0.000055900000000','0.000065400000000','0.001480826767406','0.001732487845945','26.490639846261182','26.490639846261182','test'),('2019-01-29 23:59:59','2019-02-01 03:59:59','RLCBTC','4h','0.000070800000000','0.000069000000000','0.001480826767406','0.001443178629252','20.91563230799435','20.915632307994350','test'),('2019-02-03 07:59:59','2019-02-04 19:59:59','RLCBTC','4h','0.000072600000000','0.000072000000000','0.001480826767406','0.001468588529659','20.397062911928373','20.397062911928373','test'),('2019-02-17 11:59:59','2019-02-17 15:59:59','RLCBTC','4h','0.000070500000000','0.000069200000000','0.001480826767406','0.001453520741908','21.004634998666667','21.004634998666667','test'),('2019-02-17 19:59:59','2019-02-18 07:59:59','RLCBTC','4h','0.000070100000000','0.000067700000000','0.001480826767406','0.001430127990776','21.12449026256776','21.124490262567761','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','RLCBTC','4h','0.000068200000000','0.000067800000000','0.001480826767406','0.001472141566424','21.71300245463343','21.713002454633429','test'),('2019-02-20 11:59:59','2019-02-21 11:59:59','RLCBTC','4h','0.000069200000000','0.000067600000000','0.001480826767406','0.001446587998217','21.39923074286127','21.399230742861270','test'),('2019-02-21 15:59:59','2019-02-21 19:59:59','RLCBTC','4h','0.000069400000000','0.000068700000000','0.001480826767406','0.001465890474363','21.33756149','21.337561489999999','test'),('2019-02-21 23:59:59','2019-02-24 15:59:59','RLCBTC','4h','0.000068900000000','0.000071200000000','0.001480826767406','0.001530259301006','21.492405913004358','21.492405913004358','test'),('2019-02-25 11:59:59','2019-02-28 15:59:59','RLCBTC','4h','0.000086100000000','0.000079300000000','0.001480826767406','0.001363874130724','17.19891715918699','17.198917159186990','test'),('2019-02-28 19:59:59','2019-03-06 11:59:59','RLCBTC','4h','0.000085700000000','0.000086500000000','0.001480826767406','0.001494650121127','17.27919215176196','17.279192151761961','test'),('2019-03-12 19:59:59','2019-03-13 23:59:59','RLCBTC','4h','0.000134600000000','0.000107100000000','0.001480826767406','0.001178280436770','11.001684750416048','11.001684750416048','test'),('2019-03-14 07:59:59','2019-03-16 19:59:59','RLCBTC','4h','0.000103100000000','0.000103900000000','0.001480826767406','0.001492317178792','14.363014232841902','14.363014232841902','test'),('2019-03-23 15:59:59','2019-03-23 19:59:59','RLCBTC','4h','0.000099900000000','0.000098300000000','0.001480826767406','0.001457109822182','14.823090764824824','14.823090764824824','test'),('2019-03-26 11:59:59','2019-03-30 03:59:59','RLCBTC','4h','0.000111200000000','0.000103100000000','0.001480826767406','0.001372960788845','13.316787476672662','13.316787476672662','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','RLCBTC','4h','0.000106800000000','0.000111300000000','0.001480826767406','0.001543221153673','13.865419170468167','13.865419170468167','test'),('2019-04-02 19:59:59','2019-04-02 23:59:59','RLCBTC','4h','0.000111600000000','0.000108900000000','0.001480826767406','0.001445000313356','13.26905705560932','13.269057055609320','test'),('2019-04-05 23:59:59','2019-04-06 03:59:59','RLCBTC','4h','0.000108900000000','0.000107200000000','0.001480826767406','0.001457710096106','13.598041941285583','13.598041941285583','test'),('2019-04-06 07:59:59','2019-04-06 11:59:59','RLCBTC','4h','0.000107900000000','0.000109800000000','0.001480826767406','0.001506902493616','13.724066426376275','13.724066426376275','test'),('2019-04-06 19:59:59','2019-04-07 15:59:59','RLCBTC','4h','0.000110000000000','0.000106100000000','0.001480826767406','0.001428324727471','13.462061521872727','13.462061521872727','test'),('2019-04-20 07:59:59','2019-04-21 11:59:59','RLCBTC','4h','0.000098500000000','0.000101500000000','0.001480826767406','0.001525928090271','15.033774288385787','15.033774288385787','test'),('2019-04-21 15:59:59','2019-04-23 07:59:59','RLCBTC','4h','0.000104400000000','0.000098600000000','0.001480826767406','0.001398558613661','14.18416443875479','14.184164438754790','test'),('2019-05-02 23:59:59','2019-05-03 03:59:59','RLCBTC','4h','0.000095000000000','0.000090000000000','0.001480826767406','0.001402888516490','15.587650183221053','15.587650183221053','test'),('2019-05-03 15:59:59','2019-05-03 19:59:59','RLCBTC','4h','0.000091000000000','0.000092800000000','0.001480826767406','0.001510117846322','16.272821619846155','16.272821619846155','test'),('2019-05-03 23:59:59','2019-05-10 03:59:59','RLCBTC','4h','0.000096500000000','0.000098700000000','0.001480826767406','0.001514586548632','15.34535510265285','15.345355102652849','test'),('2019-06-10 07:59:59','2019-06-12 15:59:59','RLCBTC','4h','0.000057200000000','0.000056500000000','0.001480826767406','0.001462704761511','25.888579849755246','25.888579849755246','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:22:45
