-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-10 07:59:59','2018-04-12 11:59:59','OAXBTC','4h','0.000071170000000','0.000070990000000','0.001467500000000','0.001463788464241','20.619643108051147','20.619643108051147','test'),('2018-04-12 15:59:59','2018-04-12 19:59:59','OAXBTC','4h','0.000072730000000','0.000072750000000','0.001467500000000','0.001467903547367','20.177368348686922','20.177368348686922','test'),('2018-04-13 15:59:59','2018-04-14 15:59:59','OAXBTC','4h','0.000077180000000','0.000072540000000','0.001467500000000','0.001379275071262','19.013993262503238','19.013993262503238','test'),('2018-04-15 15:59:59','2018-04-21 11:59:59','OAXBTC','4h','0.000077400000000','0.000074090000000','0.001467500000000','0.001404742571059','18.95994832041344','18.959948320413439','test'),('2018-04-21 23:59:59','2018-04-22 03:59:59','OAXBTC','4h','0.000085560000000','0.000076040000000','0.001467500000000','0.001304215755026','17.151706404862086','17.151706404862086','test'),('2018-04-22 11:59:59','2018-04-25 03:59:59','OAXBTC','4h','0.000079550000000','0.000077590000000','0.001467500000000','0.001431342866122','18.44751728472659','18.447517284726590','test'),('2018-04-26 23:59:59','2018-05-03 19:59:59','OAXBTC','4h','0.000082320000000','0.000094540000000','0.001467500000000','0.001685343172983','17.826773566569486','17.826773566569486','test'),('2018-06-01 15:59:59','2018-06-04 11:59:59','OAXBTC','4h','0.000077660000000','0.000074100000000','0.001467500000000','0.001400228560391','18.896471800154522','18.896471800154522','test'),('2018-06-07 11:59:59','2018-06-07 15:59:59','OAXBTC','4h','0.000076450000000','0.000075040000000','0.001467500000000','0.001440434270765','19.19555264879006','19.195552648790059','test'),('2018-07-02 19:59:59','2018-07-03 23:59:59','OAXBTC','4h','0.000055680000000','0.000053470000000','0.001467500000000','0.001409253322557','26.35596264367816','26.355962643678161','test'),('2018-07-04 11:59:59','2018-07-06 11:59:59','OAXBTC','4h','0.000054860000000','0.000054270000000','0.001467500000000','0.001451717553773','26.7499088589136','26.749908858913599','test'),('2018-07-06 15:59:59','2018-07-08 15:59:59','OAXBTC','4h','0.000058370000000','0.000055740000000','0.001467500000000','0.001401378276512','25.141339729313003','25.141339729313003','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','OAXBTC','4h','0.000057790000000','0.000055170000000','0.001467500000000','0.001400968593182','25.393666724346772','25.393666724346772','test'),('2018-07-17 03:59:59','2018-07-17 19:59:59','OAXBTC','4h','0.000053070000000','0.000051950000000','0.001467500000000','0.001436529583569','27.65215752779348','27.652157527793481','test'),('2018-07-18 15:59:59','2018-07-18 19:59:59','OAXBTC','4h','0.000052670000000','0.000051170000000','0.001467500000000','0.001425706759066','27.862160622745396','27.862160622745396','test'),('2018-08-26 03:59:59','2018-08-28 23:59:59','OAXBTC','4h','0.000025320000000','0.000025580000000','0.001467500000000','0.001482569115324','57.95813586097946','57.958135860979461','test'),('2018-09-01 15:59:59','2018-09-02 11:59:59','OAXBTC','4h','0.000025540000000','0.000025000000000','0.001467500000000','0.001436472200470','57.45888801879405','57.458888018794049','test'),('2018-09-03 15:59:59','2018-09-05 11:59:59','OAXBTC','4h','0.000026500000000','0.000022990000000','0.001467500000000','0.001273125471698','55.37735849056604','55.377358490566039','test'),('2018-09-16 11:59:59','2018-09-16 19:59:59','OAXBTC','4h','0.000022740000000','0.000022750000000','0.001467500000000','0.001468145338610','64.53386103781882','64.533861037818824','test'),('2018-09-16 23:59:59','2018-09-18 03:59:59','OAXBTC','4h','0.000023730000000','0.000022860000000','0.001467500000000','0.001413697850822','61.84155077960388','61.841550779603878','test'),('2018-09-18 07:59:59','2018-09-18 11:59:59','OAXBTC','4h','0.000022970000000','0.000022660000000','0.001467500000000','0.001447694819330','63.88767958206357','63.887679582063569','test'),('2018-09-18 15:59:59','2018-09-22 03:59:59','OAXBTC','4h','0.000023580000000','0.000027310000000','0.001467500000000','0.001699636344360','62.23494486853265','62.234944868532651','test'),('2018-09-26 11:59:59','2018-09-28 15:59:59','OAXBTC','4h','0.000028990000000','0.000029010000000','0.001467500000000','0.001468512418075','50.62090375991722','50.620903759917219','test'),('2018-10-04 23:59:59','2018-10-13 07:59:59','OAXBTC','4h','0.000029470000000','0.000038180000000','0.001467500000000','0.001901226671191','49.7964031218188','49.796403121818798','test'),('2018-10-17 19:59:59','2018-10-18 19:59:59','OAXBTC','4h','0.000039420000000','0.000036980000000','0.001467500000000','0.001376665398275','37.22729578893963','37.227295788939628','test'),('2018-10-18 23:59:59','2018-10-19 03:59:59','OAXBTC','4h','0.000037090000000','0.000037380000000','0.001467500000000','0.001478974117013','39.56592073335131','39.565920733351312','test'),('2018-10-19 05:59:59','2018-10-19 19:59:59','OAXBTC','4h','0.000037600000000','0.000037560000000','0.001467500000000','0.001465938829787','39.02925531914894','39.029255319148938','test'),('2018-10-20 07:59:59','2018-10-25 19:59:59','OAXBTC','4h','0.000038560000000','0.000040830000000','0.001467500000000','0.001553890689834','38.05757261410789','38.057572614107890','test'),('2018-10-26 03:59:59','2018-10-26 11:59:59','OAXBTC','4h','0.000042560000000','0.000041640000000','0.001467500000000','0.001435777725564','34.48073308270677','34.480733082706770','test'),('2018-10-26 15:59:59','2018-10-27 03:59:59','OAXBTC','4h','0.000042240000000','0.000041240000000','0.001467500000000','0.001432758049242','34.74195075757576','34.741950757575758','test'),('2018-10-29 03:59:59','2018-10-30 03:59:59','OAXBTC','4h','0.000042850000000','0.000041070000000','0.001467500000000','0.001406539673279','34.247374562427076','34.247374562427076','test'),('2018-10-30 07:59:59','2018-10-30 11:59:59','OAXBTC','4h','0.000042040000000','0.000043410000000','0.001467500000000','0.001515322906755','34.907231208372984','34.907231208372984','test'),('2018-10-30 23:59:59','2018-10-31 11:59:59','OAXBTC','4h','0.000042010000000','0.000041880000000','0.001467500000000','0.001462958819329','34.93215900975958','34.932159009759580','test'),('2018-11-07 15:59:59','2018-11-12 11:59:59','OAXBTC','4h','0.000043460000000','0.000046270000000','0.001467500000000','0.001562384376438','33.76668200644271','33.766682006442707','test'),('2018-12-17 23:59:59','2018-12-18 19:59:59','OAXBTC','4h','0.000025990000000','0.000024450000000','0.001467500000000','0.001380545402078','56.46402462485572','56.464024624855718','test'),('2018-12-19 03:59:59','2018-12-20 03:59:59','OAXBTC','4h','0.000024920000000','0.000023350000000','0.001467500000000','0.001375045144462','58.888443017656506','58.888443017656506','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','OAXBTC','4h','0.000024590000000','0.000024220000000','0.001467500000000','0.001445418869459','59.67873119154128','59.678731191541281','test'),('2018-12-24 07:59:59','2018-12-25 03:59:59','OAXBTC','4h','0.000024780000000','0.000024280000000','0.001467500000000','0.001437889426957','59.22114608555287','59.221146085552867','test'),('2018-12-25 11:59:59','2018-12-25 15:59:59','OAXBTC','4h','0.000024320000000','0.000023240000000','0.001467500000000','0.001402331414474','60.34128289473684','60.341282894736842','test'),('2019-01-02 23:59:59','2019-01-07 11:59:59','OAXBTC','4h','0.000024540000000','0.000024190000000','0.001467500000000','0.001446569885901','59.80032599837001','59.800325998370013','test'),('2019-01-15 15:59:59','2019-01-22 23:59:59','OAXBTC','4h','0.000025410000000','0.000047690000000','0.001467500000000','0.002754233569461','57.752853207398665','57.752853207398665','test'),('2019-02-13 15:59:59','2019-02-15 15:59:59','OAXBTC','4h','0.000036040000000','0.000036110000000','0.001682413224016','0.001685680952254','46.68183196492091','46.681831964920910','test'),('2019-03-03 15:59:59','2019-03-04 03:59:59','OAXBTC','4h','0.000033980000000','0.000033010000000','0.001683230156075','0.001635180325251','49.53590806578132','49.535908065781321','test'),('2019-03-05 23:59:59','2019-03-06 15:59:59','OAXBTC','4h','0.000033400000000','0.000033750000000','0.001683230156075','0.001700868795435','50.39611245733533','50.396112457335327','test'),('2019-03-06 19:59:59','2019-03-11 11:59:59','OAXBTC','4h','0.000033860000000','0.000033840000000','0.001683230156075','0.001682235926804','49.71146355803308','49.711463558033081','test'),('2019-03-12 19:59:59','2019-03-16 19:59:59','OAXBTC','4h','0.000037000000000','0.000038090000000','0.001683230156075','0.001732817206619','45.49270692094595','45.492706920945949','test'),('2019-03-18 11:59:59','2019-03-19 19:59:59','OAXBTC','4h','0.000040500000000','0.000039730000000','0.001687775563527','0.001655686991085','41.6734707043827','41.673470704382702','test'),('2019-03-19 23:59:59','2019-03-20 23:59:59','OAXBTC','4h','0.000039810000000','0.000038660000000','0.001687775563527','0.001639020429187','42.39576899088169','42.395768990881692','test'),('2019-03-26 15:59:59','2019-03-27 15:59:59','OAXBTC','4h','0.000088340000000','0.000068150000000','0.001687775563527','0.001302036502766','19.10545125115463','19.105451251154630','test'),('2019-03-27 19:59:59','2019-03-28 23:59:59','OAXBTC','4h','0.000068490000000','0.000060780000000','0.001687775563527','0.001497780679678','24.64265678970653','24.642656789706528','test'),('2019-03-29 03:59:59','2019-03-29 07:59:59','OAXBTC','4h','0.000068190000000','0.000062110000000','0.001687775563527','0.001537289048990','24.751071469819625','24.751071469819625','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  8:54:46
