-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-30 19:59:59','2018-05-04 03:59:59','BATBNB','4h','0.034510000000000','0.034500000000000','0.711908500000000','0.711702209504492','20.629049550854827','20.629049550854827','test'),('2018-05-14 23:59:59','2018-05-15 19:59:59','BATBNB','4h','0.031700000000000','0.029260000000000','0.711908500000000','0.657111757413249','22.45768138801262','22.457681388012620','test'),('2018-05-15 23:59:59','2018-05-16 03:59:59','BATBNB','4h','0.029960000000000','0.029490000000000','0.711908500000000','0.700740376001335','23.761965954606143','23.761965954606143','test'),('2018-05-16 07:59:59','2018-05-17 19:59:59','BATBNB','4h','0.030680000000000','0.028960000000000','0.711908500000000','0.671997071707953','23.204318774445895','23.204318774445895','test'),('2018-06-21 03:59:59','2018-06-22 11:59:59','BATBNB','4h','0.017090000000000','0.016070000000000','0.711908500000000','0.669418934757168','41.656436512580456','41.656436512580456','test'),('2018-06-22 15:59:59','2018-06-22 23:59:59','BATBNB','4h','0.016350000000000','0.016080000000000','0.711908500000000','0.700152212844037','43.54180428134557','43.541804281345570','test'),('2018-06-23 07:59:59','2018-06-25 23:59:59','BATBNB','4h','0.017100000000000','0.016890000000000','0.711908500000000','0.703165764035088','41.63207602339182','41.632076023391818','test'),('2018-07-01 15:59:59','2018-07-05 15:59:59','BATBNB','4h','0.017390000000000','0.017820000000000','0.711908500000000','0.729511757906843','40.93780908568143','40.937809085681430','test'),('2018-07-06 19:59:59','2018-07-10 11:59:59','BATBNB','4h','0.018630000000000','0.018800000000000','0.711908500000000','0.718404712828771','38.21301663982823','38.213016639828233','test'),('2018-07-11 03:59:59','2018-07-19 23:59:59','BATBNB','4h','0.020380000000000','0.026300000000000','0.711908500000000','0.918704295878312','34.93172227674191','34.931722276741908','test'),('2018-07-21 15:59:59','2018-07-25 03:59:59','BATBNB','4h','0.027480000000000','0.025410000000000','0.727364523219312','0.672573964155848','26.468869112784276','26.468869112784276','test'),('2018-08-15 19:59:59','2018-08-16 03:59:59','BATBNB','4h','0.020260000000000','0.019520000000000','0.727364523219312','0.700797408353454','35.901506575484305','35.901506575484305','test'),('2018-08-16 07:59:59','2018-08-20 23:59:59','BATBNB','4h','0.019610000000000','0.020040000000000','0.727364523219312','0.743313872785059','37.09151061801693','37.091510618016933','test'),('2018-08-21 19:59:59','2018-08-22 23:59:59','BATBNB','4h','0.021890000000000','0.020720000000000','0.727364523219312','0.688487570630614','33.22816460572462','33.228164605724622','test'),('2018-08-23 19:59:59','2018-08-24 11:59:59','BATBNB','4h','0.021600000000000','0.021000000000000','0.727364523219312','0.707159953129887','33.67428348237555','33.674283482375550','test'),('2018-09-05 07:59:59','2018-09-05 11:59:59','BATBNB','4h','0.021040000000000','0.019760000000000','0.727364523219312','0.683114210019658','34.57055718722966','34.570557187229660','test'),('2018-09-21 19:59:59','2018-09-22 03:59:59','BATBNB','4h','0.016900000000000','0.016380000000000','0.727364523219312','0.704984076351025','43.03932090055101','43.039320900551012','test'),('2018-09-22 07:59:59','2018-09-24 11:59:59','BATBNB','4h','0.016900000000000','0.016670000000000','0.727364523219312','0.717465479412185','43.03932090055101','43.039320900551012','test'),('2018-09-26 15:59:59','2018-09-27 11:59:59','BATBNB','4h','0.017000000000000','0.016840000000000','0.727364523219312','0.720518739471366','42.786148424665406','42.786148424665406','test'),('2018-09-27 15:59:59','2018-09-28 15:59:59','BATBNB','4h','0.016950000000000','0.017000000000000','0.727364523219312','0.729510141281906','42.91236125187682','42.912361251876817','test'),('2018-09-28 23:59:59','2018-09-29 03:59:59','BATBNB','4h','0.016890000000000','0.016600000000000','0.727364523219312','0.714875730339880','43.06480303252292','43.064803032522917','test'),('2018-09-30 03:59:59','2018-10-02 23:59:59','BATBNB','4h','0.017080000000000','0.016370000000000','0.727364523219312','0.697128644326706','42.58574491916346','42.585744919163460','test'),('2018-10-06 07:59:59','2018-10-06 19:59:59','BATBNB','4h','0.017430000000000','0.016620000000000','0.727364523219312','0.693562729541306','41.73060947901962','41.730609479019620','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','BATBNB','4h','0.016760000000000','0.016790000000000','0.727364523219312','0.728666488356339','43.398837900913605','43.398837900913605','test'),('2018-10-09 07:59:59','2018-10-10 07:59:59','BATBNB','4h','0.017230000000000','0.016860000000000','0.727364523219312','0.711744971646988','42.21500424952478','42.215004249524782','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','BATBNB','4h','0.017120000000000','0.016640000000000','0.727364523219312','0.706971125372041','42.48624551514673','42.486245515146727','test'),('2018-10-11 19:59:59','2018-10-14 23:59:59','BATBNB','4h','0.017720000000000','0.018180000000000','0.727364523219312','0.746246446508301','41.04765932388894','41.047659323888936','test'),('2018-10-16 23:59:59','2018-10-27 03:59:59','BATBNB','4h','0.018840000000000','0.027210000000000','0.727364523219312','1.050508953120885','38.60745876960255','38.607458769602552','test'),('2018-10-31 19:59:59','2018-11-01 07:59:59','BATBNB','4h','0.026240000000000','0.025960000000000','0.733631794933270','0.725803406877580','27.95852877032279','27.958528770322790','test'),('2018-11-01 11:59:59','2018-11-07 19:59:59','BATBNB','4h','0.026280000000000','0.033880000000000','0.733631794933270','0.945793196816560','27.915973932011795','27.915973932011795','test'),('2018-11-07 23:59:59','2018-11-09 07:59:59','BATBNB','4h','0.034380000000000','0.030540000000000','0.784715048390170','0.697067992374514','22.824754170743745','22.824754170743745','test'),('2018-11-22 03:59:59','2018-11-25 03:59:59','BATBNB','4h','0.029290000000000','0.027780000000000','0.784715048390170','0.744260295127310','26.791227326397063','26.791227326397063','test'),('2018-11-28 03:59:59','2018-12-03 23:59:59','BATBNB','4h','0.029680000000000','0.032690000000000','0.784715048390170','0.864296999052381','26.43918626651516','26.439186266515161','test'),('2018-12-10 07:59:59','2018-12-10 11:59:59','BATBNB','4h','0.030200000000000','0.029730000000000','0.784715048390170','0.772502595650323','25.983941999674503','25.983941999674503','test'),('2018-12-10 19:59:59','2018-12-10 23:59:59','BATBNB','4h','0.029470000000000','0.029300000000000','0.784715048390170','0.780188358256939','26.627589019008145','26.627589019008145','test'),('2018-12-11 03:59:59','2018-12-11 11:59:59','BATBNB','4h','0.029480000000000','0.029380000000000','0.784715048390170','0.782053192730773','26.618556593967778','26.618556593967778','test'),('2019-02-17 07:59:59','2019-02-19 03:59:59','BATBNB','4h','0.014840000000000','0.014340000000000','0.784715048390170','0.758275862123655','52.87837253303032','52.878372533030323','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','BATBNB','4h','0.014540000000000','0.014560000000000','0.784715048390170','0.785794436352192','53.969398101112105','53.969398101112105','test'),('2019-02-26 07:59:59','2019-02-28 07:59:59','BATBNB','4h','0.018900000000000','0.016190000000000','0.784715048390170','0.672197705472849','41.51931472963862','41.519314729638623','test'),('2019-03-02 11:59:59','2019-03-02 23:59:59','BATBNB','4h','0.016850000000000','0.015210000000000','0.784715048390170','0.708339221721928','46.570626017220775','46.570626017220775','test'),('2019-03-22 07:59:59','2019-03-23 07:59:59','BATBNB','4h','0.013390000000000','0.012930000000000','0.784715048390170','0.757756951134048','58.60455925243988','58.604559252439877','test'),('2019-03-23 11:59:59','2019-03-24 11:59:59','BATBNB','4h','0.013280000000000','0.012520000000000','0.784715048390170','0.739806657066636','59.08998858359714','59.089988583597140','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','BATBNB','4h','0.012920000000000','0.012490000000000','0.784715048390170','0.758598371083067','60.73645885372834','60.736458853728337','test'),('2019-03-27 11:59:59','2019-04-02 19:59:59','BATBNB','4h','0.013100000000000','0.015390000000000','0.784715048390170','0.921890427078223','59.90191209085267','59.901912090852669','test'),('2019-04-06 15:59:59','2019-04-09 15:59:59','BATBNB','4h','0.015810000000000','0.015730000000000','0.784715048390170','0.780744320757582','49.63409540734788','49.634095407347878','test'),('2019-04-10 23:59:59','2019-04-11 03:59:59','BATBNB','4h','0.016020000000000','0.015650000000000','0.784715048390170','0.766591167746951','48.98346119788827','48.983461197888268','test'),('2019-04-13 11:59:59','2019-04-14 15:59:59','BATBNB','4h','0.016250000000000','0.015890000000000','0.784715048390170','0.767330591933526','48.29015682401046','48.290156824010460','test'),('2019-04-16 23:59:59','2019-04-18 15:59:59','BATBNB','4h','0.016380000000000','0.016790000000000','0.784715048390170','0.804356878050730','47.9069016111215','47.906901611121498','test'),('2019-04-19 03:59:59','2019-04-19 11:59:59','BATBNB','4h','0.017060000000000','0.016360000000000','0.784715048390170','0.752516892829026','45.997365087348776','45.997365087348776','test'),('2019-04-20 19:59:59','2019-04-21 03:59:59','BATBNB','4h','0.017420000000000','0.019010000000000','0.784715048390170','0.856339441440708','45.04678808209931','45.046788082099312','test'),('2019-04-21 07:59:59','2019-04-22 11:59:59','BATBNB','4h','0.019350000000000','0.017490000000000','0.784715048390170','0.709285074746464','40.553749270809824','40.553749270809824','test'),('2019-04-23 23:59:59','2019-04-25 07:59:59','BATBNB','4h','0.018410000000000','0.018580000000000','0.784715048390170','0.791961194953251','42.624391547537755','42.624391547537755','test'),('2019-04-25 11:59:59','2019-04-25 23:59:59','BATBNB','4h','0.018670000000000','0.017320000000000','0.784715048390170','0.727973467494255','42.030800663640605','42.030800663640605','test'),('2019-04-28 19:59:59','2019-04-29 07:59:59','BATBNB','4h','0.018160000000000','0.017320000000000','0.784715048390170','0.748417656284017','43.21118107875386','43.211181078753860','test'),('2019-04-29 11:59:59','2019-04-29 19:59:59','BATBNB','4h','0.017530000000000','0.017550000000000','0.784715048390170','0.785610330818453','44.764121414156875','44.764121414156875','test'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BATBNB','4h','0.017660000000000','0.017670000000000','0.784715048390170','0.785159394397186','44.43460070159514','44.434600701595137','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 20:59:32
