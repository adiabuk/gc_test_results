-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 03:59:59','2018-03-24 23:59:59','KNCETH','4h','0.002260100000000','0.002767300000000','0.072144500000000','0.088334797066501','31.920932702092827','31.920932702092827','test'),('2018-03-25 07:59:59','2018-03-26 19:59:59','KNCETH','4h','0.002741000000000','0.002480000000000','0.076192074266625','0.068937009916538','27.797181417958864','27.797181417958864','test'),('2018-03-27 19:59:59','2018-03-29 23:59:59','KNCETH','4h','0.002654100000000','0.002560000000000','0.076192074266625','0.073490716296507','28.70731105332316','28.707311053323160','test'),('2018-03-30 19:59:59','2018-03-30 23:59:59','KNCETH','4h','0.002660400000000','0.002593400000000','0.076192074266625','0.074273239138124','28.63933027613329','28.639330276133290','test'),('2018-04-09 07:59:59','2018-04-09 11:59:59','KNCETH','4h','0.002492800000000','0.002450300000000','0.076192074266625','0.074893067865658','30.564856493350852','30.564856493350852','test'),('2018-04-10 19:59:59','2018-04-12 23:59:59','KNCETH','4h','0.002522400000000','0.002543700000000','0.076192074266625','0.076835465949895','30.2061823131244','30.206182313124401','test'),('2018-04-13 03:59:59','2018-04-13 11:59:59','KNCETH','4h','0.002662000000000','0.002534900000000','0.076192074266625','0.072554203252617','28.622116553953795','28.622116553953795','test'),('2018-04-13 15:59:59','2018-04-14 19:59:59','KNCETH','4h','0.002571600000000','0.002551400000000','0.076192074266625','0.075593583093742','29.62827588529515','29.628275885295150','test'),('2018-04-14 23:59:59','2018-04-15 07:59:59','KNCETH','4h','0.002645700000000','0.002573900000000','0.076192074266625','0.074124345146791','28.798455707988435','28.798455707988435','test'),('2018-04-15 15:59:59','2018-04-16 03:59:59','KNCETH','4h','0.002627000000000','0.002570800000000','0.076192074266625','0.074562080138805','29.003454231680625','29.003454231680625','test'),('2018-04-16 11:59:59','2018-04-20 11:59:59','KNCETH','4h','0.002707900000000','0.002712700000000','0.076192074266625','0.076327131675126','28.136960104370544','28.136960104370544','test'),('2018-04-23 11:59:59','2018-04-25 07:59:59','KNCETH','4h','0.002958500000000','0.003000000000000','0.076192074266625','0.077260849349290','25.753616449763392','25.753616449763392','test'),('2018-04-25 15:59:59','2018-04-30 11:59:59','KNCETH','4h','0.003008400000000','0.003863900000000','0.076192074266625','0.097858847147591','25.326444045547465','25.326444045547465','test'),('2018-04-30 15:59:59','2018-05-01 03:59:59','KNCETH','4h','0.004028700000000','0.003906800000000','0.076793486209421','0.074469876616022','19.061604539782376','19.061604539782376','test'),('2018-06-02 03:59:59','2018-06-04 03:59:59','KNCETH','4h','0.002670700000000','0.002469800000000','0.076793486209421','0.071016794188800','28.754066802494105','28.754066802494105','test'),('2018-07-01 07:59:59','2018-07-01 11:59:59','KNCETH','4h','0.001920200000000','0.001872900000000','0.076793486209421','0.074901843725458','39.99244152141496','39.992441521414960','test'),('2018-07-01 19:59:59','2018-07-04 00:22:25','KNCETH','4h','0.001897100000000','0.001927700000000','0.076793486209421','0.078032156115071','40.47940868136682','40.479408681366820','test'),('2018-07-04 11:59:59','2018-07-07 23:59:59','KNCETH','4h','0.002005500000000','0.002050500000000','0.076793486209421','0.078516601083230','38.291441640199956','38.291441640199956','test'),('2018-07-14 07:59:59','2018-07-14 19:59:59','KNCETH','4h','0.002058800000000','0.002002100000000','0.076793486209421','0.074678569428736','37.30011958879979','37.300119588799788','test'),('2018-07-14 23:59:59','2018-07-15 03:59:59','KNCETH','4h','0.002017400000000','0.002010500000000','0.076793486209421','0.076530833758323','38.065572622891345','38.065572622891345','test'),('2018-07-18 03:59:59','2018-07-20 15:59:59','KNCETH','4h','0.002111000000000','0.002075400000000','0.076793486209421','0.075498437365719','36.37777650848934','36.377776508489340','test'),('2018-08-20 15:59:59','2018-08-21 03:59:59','KNCETH','4h','0.001570000000000','0.001550000000000','0.076793486209421','0.075815225238600','48.91304854103249','48.913048541032488','test'),('2018-08-21 11:59:59','2018-08-29 19:59:59','KNCETH','4h','0.001596100000000','0.001923800000000','0.076793486209421','0.092560183428159','48.1132048176311','48.113204817631100','test'),('2018-09-07 03:59:59','2018-09-10 19:59:59','KNCETH','4h','0.001911000000000','0.001924500000000','0.077814900922898','0.078364613723766','40.71946673097763','40.719466730977629','test'),('2018-10-03 03:59:59','2018-10-04 03:59:59','KNCETH','4h','0.001757500000000','0.001706700000000','0.077952329123115','0.075699140890140','44.35409907431878','44.354099074318782','test'),('2018-10-04 07:59:59','2018-10-04 15:59:59','KNCETH','4h','0.001725300000000','0.001716600000000','0.077952329123115','0.077559246607975','45.18189829195793','45.181898291957928','test'),('2018-10-04 19:59:59','2018-10-04 23:59:59','KNCETH','4h','0.001729600000000','0.001705100000000','0.077952329123115','0.076848124646059','45.06957049208777','45.069570492087770','test'),('2018-10-05 11:59:59','2018-10-05 15:59:59','KNCETH','4h','0.001721300000000','0.001698900000000','0.077952329123115','0.076937902717283','45.28689311747807','45.286893117478073','test'),('2018-10-06 15:59:59','2018-10-12 23:59:59','KNCETH','4h','0.001717700000000','0.001802800000000','0.077952329123115','0.081814320861123','45.38180655709088','45.381806557090883','test'),('2018-10-14 15:59:59','2018-10-15 07:59:59','KNCETH','4h','0.001863500000000','0.001824400000000','0.077952329123115','0.076316731554715','41.83113985678294','41.831139856782940','test'),('2018-10-15 11:59:59','2018-10-22 07:59:59','KNCETH','4h','0.001986000000000','0.002031200000000','0.077952329123115','0.079726470752705','39.25092100861783','39.250921008617830','test'),('2018-10-23 03:59:59','2018-10-27 23:59:59','KNCETH','4h','0.002096300000000','0.002251600000000','0.077952329123115','0.083727264348426','37.18567434199065','37.185674341990648','test'),('2018-11-29 11:59:59','2018-11-30 11:59:59','KNCETH','4h','0.001593900000000','0.001522100000000','0.079204971471492','0.075637045659551','49.692560054891615','49.692560054891615','test'),('2018-11-30 15:59:59','2018-11-30 23:59:59','KNCETH','4h','0.001549300000000','0.001575600000000','0.079204971471492','0.080549508197562','51.12306943231911','51.123069432319113','test'),('2018-12-01 03:59:59','2018-12-03 03:59:59','KNCETH','4h','0.001901900000000','0.001608300000000','0.079204971471492','0.066977946063200','41.645181908350594','41.645181908350594','test'),('2018-12-20 15:59:59','2018-12-21 07:59:59','KNCETH','4h','0.001588100000000','0.001441900000000','0.079204971471492','0.071913386036613','49.87404538221271','49.874045382212707','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','KNCETH','4h','0.001448800000000','0.001463700000000','0.079204971471492','0.080019544963296','54.66936186602153','54.669361866021532','test'),('2019-01-12 15:59:59','2019-01-13 23:59:59','KNCETH','4h','0.001136200000000','0.001128200000000','0.079204971471492','0.078647288165937','69.71041319441295','69.710413194412951','test'),('2019-01-14 07:59:59','2019-01-14 15:59:59','KNCETH','4h','0.001133000000000','0.001078400000000','0.079204971471492','0.075388032863951','69.90730050440601','69.907300504406010','test'),('2019-01-17 19:59:59','2019-01-18 11:59:59','KNCETH','4h','0.001137300000000','0.001121800000000','0.079204971471492','0.078125505140877','69.6429890719177','69.642989071917697','test'),('2019-01-18 19:59:59','2019-01-20 15:59:59','KNCETH','4h','0.001137200000000','0.001142800000000','0.079204971471492','0.079595006505119','69.64911314763629','69.649113147636285','test'),('2019-01-20 19:59:59','2019-01-20 23:59:59','KNCETH','4h','0.001147600000000','0.001151700000000','0.079204971471492','0.079487944966641','69.01792564612408','69.017925646124084','test'),('2019-01-21 03:59:59','2019-01-22 11:59:59','KNCETH','4h','0.001170400000000','0.001149100000000','0.079204971471492','0.077763527612689','67.67342060106971','67.673420601069708','test'),('2019-01-23 11:59:59','2019-01-27 03:59:59','KNCETH','4h','0.001158800000000','0.001170600000000','0.079204971471492','0.080011511567595','68.35085560190888','68.350855601908876','test'),('2019-02-07 15:59:59','2019-02-08 19:59:59','KNCETH','4h','0.001160900000000','0.001073800000000','0.079204971471492','0.073262381226710','68.22721291368076','68.227212913680759','test'),('2019-02-10 11:59:59','2019-02-11 03:59:59','KNCETH','4h','0.001270400000000','0.001137300000000','0.079204971471492','0.070906654639899','62.3464825814641','62.346482581464102','test'),('2019-02-11 11:59:59','2019-02-11 15:59:59','KNCETH','4h','0.001126400000000','0.001123800000000','0.079204971471492','0.079022147496149','70.316913593299','70.316913593299006','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','KNCETH','4h','0.001130900000000','0.001127800000000','0.079204971471492','0.078987856420151','70.03711333583163','70.037113335831634','test'),('2019-02-16 19:59:59','2019-02-17 11:59:59','KNCETH','4h','0.001168600000000','0.001105700000000','0.079204971471492','0.074941756765385','67.77765828469279','67.777658284692791','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','KNCETH','4h','0.001117600000000','0.001082600000000','0.079204971471492','0.076724500818752','70.8705900782856','70.870590078285602','test'),('2019-02-26 11:59:59','2019-03-04 07:59:59','KNCETH','4h','0.001123400000000','0.001274400000000','0.079204971471492','0.089851180027835','70.50469242611001','70.504692426110012','test'),('2019-03-08 07:59:59','2019-03-11 19:59:59','KNCETH','4h','0.001388900000000','0.001915900000000','0.079204971471492','0.109258265420283','57.0271232424883','57.027123242488301','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:55:19
