-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-16 15:59:59','2018-02-17 23:59:59','WTCETH','4h','0.029471000000000','0.027349000000000','0.072144500000000','0.066949880577517','2.44798276271589','2.447982762715890','test'),('2018-03-06 19:59:59','2018-03-07 15:59:59','WTCETH','4h','0.029636000000000','0.024232000000000','0.072144500000000','0.058989253745445','2.4343534889998653','2.434353488999865','test'),('2018-03-07 19:59:59','2018-03-07 23:59:59','WTCETH','4h','0.025300000000000','0.024730000000000','0.072144500000000','0.070519110079051','2.8515612648221342','2.851561264822134','test'),('2018-03-20 03:59:59','2018-03-22 23:59:59','WTCETH','4h','0.024000000000000','0.024098000000000','0.072144500000000','0.072439090041667','3.0060208333333334','3.006020833333333','test'),('2018-03-23 19:59:59','2018-03-29 23:59:59','WTCETH','4h','0.025046000000000','0.028499000000000','0.072144500000000','0.082090797153238','2.880479916952807','2.880479916952807','test'),('2018-04-19 07:59:59','2018-04-19 19:59:59','WTCETH','4h','0.023231000000000','0.022361000000000','0.072144500000000','0.069442691425251','3.1055270974129394','3.105527097412939','test'),('2018-04-27 15:59:59','2018-05-01 03:59:59','WTCETH','4h','0.022167000000000','0.022849000000000','0.072144500000000','0.074364130486760','3.2545901565389994','3.254590156538999','test'),('2018-05-25 03:59:59','2018-05-31 03:59:59','WTCETH','4h','0.018600000000000','0.019229000000000','0.072144500000000','0.074584225295699','3.878736559139785','3.878736559139785','test'),('2018-05-31 15:59:59','2018-05-31 23:59:59','WTCETH','4h','0.019778000000000','0.019371000000000','0.072144500000000','0.070659880144605','3.6477146324198606','3.647714632419861','test'),('2018-06-05 19:59:59','2018-06-08 03:59:59','WTCETH','4h','0.020151000000000','0.019483000000000','0.072144500000000','0.069752930053099','3.58019453128877','3.580194531288770','test'),('2018-06-08 07:59:59','2018-06-08 11:59:59','WTCETH','4h','0.020417000000000','0.019846000000000','0.072144500000000','0.070126842680120','3.533550472645344','3.533550472645344','test'),('2018-07-03 07:59:59','2018-07-03 11:59:59','WTCETH','4h','0.015500000000000','0.015073000000000','0.072144500000000','0.070157035387097','4.654483870967742','4.654483870967742','test'),('2018-07-05 03:59:59','2018-07-05 15:59:59','WTCETH','4h','0.015357000000000','0.014808000000000','0.072144500000000','0.069565394022270','4.697825096047405','4.697825096047405','test'),('2018-07-06 23:59:59','2018-07-07 15:59:59','WTCETH','4h','0.015092000000000','0.014971000000000','0.072144500000000','0.071566081997085','4.780314073681421','4.780314073681421','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','WTCETH','4h','0.015084000000000','0.014945000000000','0.072144500000000','0.071479683936622','4.7828493768231235','4.782849376823123','test'),('2018-07-09 03:59:59','2018-07-09 23:59:59','WTCETH','4h','0.015378000000000','0.015038000000000','0.072144500000000','0.070549420665886','4.691409806216673','4.691409806216673','test'),('2018-07-10 03:59:59','2018-07-10 07:59:59','WTCETH','4h','0.015138000000000','0.014842000000000','0.072144500000000','0.070733826727441','4.765788082970009','4.765788082970009','test'),('2018-07-11 11:59:59','2018-07-12 19:59:59','WTCETH','4h','0.015623000000000','0.015007000000000','0.072144500000000','0.069299911124624','4.617839083402676','4.617839083402676','test'),('2018-07-12 23:59:59','2018-07-13 03:59:59','WTCETH','4h','0.015658000000000','0.016965000000000','0.072144500000000','0.078166524620003','4.607516924255972','4.607516924255972','test'),('2018-07-13 23:59:59','2018-07-14 03:59:59','WTCETH','4h','0.015858000000000','0.015723000000000','0.072144500000000','0.071530330022701','4.549407239248329','4.549407239248329','test'),('2018-08-18 11:59:59','2018-08-29 03:59:59','WTCETH','4h','0.008947000000000','0.013670000000000','0.072144500000000','0.110228603442495','8.063540851682127','8.063540851682127','test'),('2018-08-30 03:59:59','2018-09-02 07:59:59','WTCETH','4h','0.015336000000000','0.015944000000000','0.076684785907169','0.079724975645794','5.000312070107523','5.000312070107523','test'),('2018-09-04 03:59:59','2018-09-06 03:59:59','WTCETH','4h','0.016681000000000','0.016359000000000','0.077444833341825','0.075949884817392','4.642697280847985','4.642697280847985','test'),('2018-09-06 23:59:59','2018-09-10 03:59:59','WTCETH','4h','0.017533000000000','0.017452000000000','0.077444833341825','0.077087049077826','4.417089678995323','4.417089678995323','test'),('2018-10-08 03:59:59','2018-10-11 19:59:59','WTCETH','4h','0.013009000000000','0.013865000000000','0.077444833341825','0.082540749810470','5.953173444678685','5.953173444678685','test'),('2018-10-14 03:59:59','2018-10-14 19:59:59','WTCETH','4h','0.013970000000000','0.013712000000000','0.078255629261878','0.076810392873219','5.6016914289104145','5.601691428910414','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','WTCETH','4h','0.013946000000000','0.013506000000000','0.078255629261878','0.075786643396739','5.611331511679191','5.611331511679191','test'),('2018-10-16 03:59:59','2018-10-16 07:59:59','WTCETH','4h','0.013975000000000','0.013738000000000','0.078255629261878','0.076928503384592','5.599687245930447','5.599687245930447','test'),('2018-10-17 07:59:59','2018-10-20 03:59:59','WTCETH','4h','0.014066000000000','0.014140000000000','0.078255629261878','0.078667325306623','5.563460064117589','5.563460064117589','test'),('2018-10-22 23:59:59','2018-10-28 03:59:59','WTCETH','4h','0.014745000000000','0.014936000000000','0.078255629261878','0.079269316965440','5.30726546367433','5.307265463674330','test'),('2018-10-28 11:59:59','2018-11-02 23:59:59','WTCETH','4h','0.016030000000000','0.016496000000000','0.078255629261878','0.080530558970926','4.881823409973674','4.881823409973674','test'),('2018-12-05 03:59:59','2018-12-06 03:59:59','WTCETH','4h','0.011532000000000','0.010911000000000','0.078255629261878','0.074041551411407','6.785954670644988','6.785954670644988','test'),('2018-12-06 07:59:59','2018-12-06 11:59:59','WTCETH','4h','0.011016000000000','0.010820000000000','0.078255629261878','0.076863281464553','7.103815292472586','7.103815292472586','test'),('2018-12-14 11:59:59','2018-12-16 03:59:59','WTCETH','4h','0.011030000000000','0.010549000000000','0.078255629261878','0.074843031104583','7.094798663814869','7.094798663814869','test'),('2018-12-18 15:59:59','2018-12-18 19:59:59','WTCETH','4h','0.010597000000000','0.010707000000000','0.078255629261878','0.079067945881563','7.3846965425948845','7.384696542594885','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','WTCETH','4h','0.010623000000000','0.010582000000000','0.078255629261878','0.077953597745382','7.3666223535609525','7.366622353560953','test'),('2018-12-19 11:59:59','2018-12-19 23:59:59','WTCETH','4h','0.011494000000000','0.010740000000000','0.078255629261878','0.073122103555992','6.808389530353053','6.808389530353053','test'),('2018-12-20 07:59:59','2018-12-20 15:59:59','WTCETH','4h','0.011430000000000','0.010783000000000','0.078255629261878','0.073825936161927','6.846511746446019','6.846511746446019','test'),('2019-01-09 07:59:59','2019-01-10 19:59:59','WTCETH','4h','0.008590000000000','0.008418000000000','0.078255629261878','0.076688694659661','9.110084896609779','9.110084896609779','test'),('2019-01-11 11:59:59','2019-01-15 07:59:59','WTCETH','4h','0.008483000000000','0.008719000000000','0.078255629261878','0.080432727989428','9.224994608260992','9.224994608260992','test'),('2019-01-15 11:59:59','2019-01-18 15:59:59','WTCETH','4h','0.008956000000000','0.009384000000000','0.078255629261878','0.081995402522718','8.737787992617015','8.737787992617015','test'),('2019-01-19 23:59:59','2019-01-20 15:59:59','WTCETH','4h','0.009934000000000','0.009347000000000','0.078255629261878','0.073631504601447','7.877554787787195','7.877554787787195','test'),('2019-01-25 11:59:59','2019-01-26 19:59:59','WTCETH','4h','0.009655000000000','0.009580000000000','0.078255629261878','0.077647739857979','8.105192051981149','8.105192051981149','test'),('2019-01-26 23:59:59','2019-01-27 11:59:59','WTCETH','4h','0.009597000000000','0.009387000000000','0.078255629261878','0.076543252253959','8.1541762281836','8.154176228183600','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:50:21
