-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-04 07:59:59','2018-09-05 07:59:59','QTUMUSDT','4h','4.799000000000000','4.710000000000000','15.000000000000000','14.721817045217753','3.12565117732861','3.125651177328610','test'),('2018-09-21 11:59:59','2018-09-24 23:59:59','QTUMUSDT','4h','4.054000000000000','3.800000000000000','15.000000000000000','14.060187469166255','3.7000493339911196','3.700049333991120','test'),('2018-09-27 19:59:59','2018-09-29 03:59:59','QTUMUSDT','4h','4.068000000000000','3.758000000000000','15.000000000000000','13.856932153392332','3.6873156342182893','3.687315634218289','test'),('2018-09-29 07:59:59','2018-10-01 15:59:59','QTUMUSDT','4h','3.759000000000000','3.778000000000000','15.000000000000000','15.075818036711890','3.9904229848363926','3.990422984836393','test'),('2018-10-02 03:59:59','2018-10-02 23:59:59','QTUMUSDT','4h','3.911000000000000','3.815000000000000','15.000000000000000','14.631807721810279','3.83533623114293','3.835336231142930','test'),('2018-10-07 23:59:59','2018-10-09 15:59:59','QTUMUSDT','4h','3.853000000000000','3.825000000000000','15.000000000000000','14.890994030625487','3.8930703348040487','3.893070334804049','test'),('2018-10-09 19:59:59','2018-10-10 03:59:59','QTUMUSDT','4h','3.870000000000000','3.816000000000000','15.000000000000000','14.790697674418604','3.875968992248062','3.875968992248062','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','QTUMUSDT','4h','3.918000000000000','3.650000000000000','15.000000000000000','13.973966309341501','3.8284839203675345','3.828483920367534','test'),('2018-10-17 07:59:59','2018-10-23 19:59:59','QTUMUSDT','4h','3.746000000000000','4.200000000000000','15.000000000000000','16.817939135077417','4.00427122263748','4.004271222637480','test'),('2018-11-06 23:59:59','2018-11-08 03:59:59','QTUMUSDT','4h','4.073000000000000','3.990000000000000','15.000000000000000','14.694328504787626','3.6827890989442666','3.682789098944267','test'),('2018-11-08 07:59:59','2018-11-08 23:59:59','QTUMUSDT','4h','4.020000000000000','3.983000000000000','15.000000000000000','14.861940298507465','3.73134328358209','3.731343283582090','test'),('2018-12-17 15:59:59','2018-12-25 11:59:59','QTUMUSDT','4h','1.946000000000000','2.387000000000000','15.000000000000000','18.399280575539567','7.708119218910586','7.708119218910586','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','QTUMUSDT','4h','2.294000000000000','2.261000000000000','15.193927238649044','14.975357230420876','6.623333582671772','6.623333582671772','test'),('2019-01-08 11:59:59','2019-01-08 19:59:59','QTUMUSDT','4h','2.283000000000000','2.249000000000000','15.193927238649044','14.967648865405915','6.655246271856787','6.655246271856787','test'),('2019-01-09 03:59:59','2019-01-10 07:59:59','QTUMUSDT','4h','2.295000000000000','2.282000000000000','15.193927238649044','15.107861419868026','6.620447598539888','6.620447598539888','test'),('2019-02-09 11:59:59','2019-02-12 11:59:59','QTUMUSDT','4h','1.956000000000000','1.898000000000000','15.193927238649044','14.743391563883376','7.767856461477017','7.767856461477017','test'),('2019-02-12 15:59:59','2019-02-14 07:59:59','QTUMUSDT','4h','1.907000000000000','1.897000000000000','15.193927238649044','15.114252738184183','7.967450046486126','7.967450046486126','test'),('2019-02-16 03:59:59','2019-02-21 19:59:59','QTUMUSDT','4h','1.975000000000000','2.066000000000000','15.193927238649044','15.894001860784266','7.693127715771667','7.693127715771667','test'),('2019-02-22 19:59:59','2019-02-24 15:59:59','QTUMUSDT','4h','2.124000000000000','2.037000000000000','15.193927238649044','14.571577111642233','7.153449735710472','7.153449735710472','test'),('2019-03-01 15:59:59','2019-03-02 07:59:59','QTUMUSDT','4h','2.124000000000000','2.070000000000000','15.193927238649044','14.807640952920677','7.153449735710472','7.153449735710472','test'),('2019-03-02 11:59:59','2019-03-02 15:59:59','QTUMUSDT','4h','2.080000000000000','2.074000000000000','15.193927238649044','15.150098602383709','7.3047727108889635','7.304772710888964','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','QTUMUSDT','4h','2.102000000000000','2.097000000000000','15.193927238649044','15.157785641982420','7.22831933332495','7.228319333324950','test'),('2019-03-09 03:59:59','2019-03-11 07:59:59','QTUMUSDT','4h','2.152000000000000','2.090000000000000','15.193927238649044','14.756183981773466','7.060375110896396','7.060375110896396','test'),('2019-03-12 19:59:59','2019-03-13 11:59:59','QTUMUSDT','4h','2.151000000000000','2.123000000000000','15.193927238649044','14.996144829219864','7.063657479613689','7.063657479613689','test'),('2019-03-13 15:59:59','2019-03-14 03:59:59','QTUMUSDT','4h','2.131000000000000','2.120000000000000','15.193927238649044','15.115497769092435','7.1299517778737895','7.129951777873790','test'),('2019-03-14 15:59:59','2019-03-19 03:59:59','QTUMUSDT','4h','2.705000000000000','2.465000000000000','15.193927238649044','13.845852363500885','5.616978646450663','5.616978646450663','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','QTUMUSDT','4h','2.491000000000000','2.448000000000000','15.193927238649044','14.931647483024030','6.099529200581712','6.099529200581712','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','QTUMUSDT','4h','2.557000000000000','2.431000000000000','15.193927238649044','14.445223745465713','5.942091215740729','5.942091215740729','test'),('2019-03-22 19:59:59','2019-03-25 11:59:59','QTUMUSDT','4h','2.525000000000000','2.528000000000000','15.193927238649044','15.211979429427638','6.017396926197641','6.017396926197641','test'),('2019-03-27 19:59:59','2019-04-05 03:59:59','QTUMUSDT','4h','2.581000000000000','3.175000000000000','15.193927238649044','18.690708633363315','5.886837364838839','5.886837364838839','test'),('2019-04-05 07:59:59','2019-04-09 03:59:59','QTUMUSDT','4h','3.312000000000000','3.282000000000000','15.193927238649044','15.056301086125050','4.587538417466499','4.587538417466499','test'),('2019-05-03 11:59:59','2019-05-04 11:59:59','QTUMUSDT','4h','2.656000000000000','2.535000000000000','15.193927238649044','14.501734017309989','5.720605135033526','5.720605135033526','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','QTUMUSDT','4h','2.590000000000000','2.435000000000000','15.193927238649044','14.284638156799392','5.866381173223569','5.866381173223569','test'),('2019-05-13 11:59:59','2019-05-17 15:59:59','QTUMUSDT','4h','2.474000000000000','2.783000000000000','15.193927238649044','17.091632783007391','6.141441891127341','6.141441891127341','test'),('2019-05-19 07:59:59','2019-05-20 15:59:59','QTUMUSDT','4h','3.031000000000000','3.123000000000000','15.193927238649044','15.655108797855810','5.012843034856167','5.012843034856167','test'),('2019-05-20 23:59:59','2019-05-22 23:59:59','QTUMUSDT','4h','3.090000000000000','2.853000000000000','15.193927238649044','14.028567770830332','4.917128556197102','4.917128556197102','test'),('2019-05-27 03:59:59','2019-05-29 07:59:59','QTUMUSDT','4h','3.064000000000000','3.089000000000000','15.193927238649044','15.317898577084495','4.958853537418095','4.958853537418095','test'),('2019-05-29 11:59:59','2019-05-30 23:59:59','QTUMUSDT','4h','3.113000000000000','3.114000000000000','15.193927238649044','15.198808037633512','4.8807989844680515','4.880798984468051','test'),('2019-06-01 03:59:59','2019-06-03 07:59:59','QTUMUSDT','4h','3.682000000000000','3.337000000000000','15.193927238649044','13.770270286630055','4.126541889910115','4.126541889910115','test'),('2019-06-12 15:59:59','2019-06-13 03:59:59','QTUMUSDT','4h','3.206000000000000','3.169000000000000','15.193927238649044','15.018576238078234','4.7392162316434945','4.739216231643494','test'),('2019-06-13 07:59:59','2019-06-18 19:59:59','QTUMUSDT','4h','3.190000000000000','3.544000000000000','15.193927238649044','16.880024493345520','4.7629865951877886','4.762986595187789','test'),('2019-06-19 03:59:59','2019-06-20 03:59:59','QTUMUSDT','4h','3.651000000000000','3.570000000000000','15.193927238649044','14.856839288407858','4.161579632607244','4.161579632607244','test'),('2019-06-22 03:59:59','2019-06-27 19:59:59','QTUMUSDT','4h','3.645000000000000','4.373000000000000','15.193927238649044','18.228544256409403','4.168429969451041','4.168429969451041','test'),('2019-06-28 23:59:59','2019-06-30 23:59:59','QTUMUSDT','4h','5.307000000000000','4.934000000000000','15.533940642083969','14.442144927085415','2.9270662600497395','2.927066260049739','test'),('2019-07-03 15:59:59','2019-07-04 23:59:59','QTUMUSDT','4h','5.103000000000000','4.840000000000000','15.533940642083969','14.733347581361242','3.044080078793645','3.044080078793645','test'),('2019-07-08 19:59:59','2019-07-09 07:59:59','QTUMUSDT','4h','5.041000000000000','4.836000000000000','15.533940642083969','14.902229110319000','3.081519667146195','3.081519667146195','test'),('2019-08-03 03:59:59','2019-08-04 03:59:59','QTUMUSDT','4h','3.090000000000000','3.004000000000000','15.533940642083969','15.101604430038915','5.027165256337854','5.027165256337854','test'),('2019-08-05 03:59:59','2019-08-06 07:59:59','QTUMUSDT','4h','3.056000000000000','3.088000000000000','15.533940642083969','15.696599706398983','5.08309575984423','5.083095759844230','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:40:44
