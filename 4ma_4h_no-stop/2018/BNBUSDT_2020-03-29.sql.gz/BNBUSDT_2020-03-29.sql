-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-23 11:59:59','2018-04-25 11:59:59','BNBUSDT','4h','13.726500000000000','13.650000000000000','15.000000000000000','14.916402578953122','1.0927767457108513','1.092776745710851','test'),('2018-04-25 19:59:59','2018-04-25 23:59:59','BNBUSDT','4h','13.647500000000001','13.399900000000001','15.000000000000000','14.727862245832570','1.099102399706906','1.099102399706906','test'),('2018-04-26 15:59:59','2018-04-30 07:59:59','BNBUSDT','4h','14.100000000000000','14.460300000000000','15.000000000000000','15.383297872340425','1.0638297872340425','1.063829787234043','test'),('2018-05-03 23:59:59','2018-05-05 03:59:59','BNBUSDT','4h','14.699900000000000','14.275200000000000','15.006890674281529','14.573321298342417','1.0208838614059639','1.020883861405964','test'),('2018-05-05 11:59:59','2018-05-05 15:59:59','BNBUSDT','4h','14.500200000000000','14.470100000000000','15.006890674281529','14.975738868837752','1.0349437024511061','1.034943702451106','test'),('2018-05-05 23:59:59','2018-05-06 07:59:59','BNBUSDT','4h','14.446800000000000','14.779999999999999','15.006890674281529','15.353008567010063','1.0387691858599502','1.038769185859950','test'),('2018-05-18 23:59:59','2018-05-22 23:59:59','BNBUSDT','4h','15.136300000000000','13.888000000000000','15.006890674281529','13.769263141218255','0.9914503989932499','0.991450398993250','test'),('2018-05-31 23:59:59','2018-06-04 11:59:59','BNBUSDT','4h','14.199999999999999','13.796099999999999','15.006890674281529','14.580039748694041','1.0568232869212344','1.056823286921234','test'),('2018-06-05 07:59:59','2018-06-09 23:59:59','BNBUSDT','4h','14.715600000000000','16.018799999999999','15.006890674281529','16.335887108455037','1.0197946855229503','1.019794685522950','test'),('2018-06-16 11:59:59','2018-06-20 03:59:59','BNBUSDT','4h','15.670400000000001','15.874599999999999','15.006890674281529','15.202444525854448','0.9576584308174346','0.957658430817435','test'),('2018-06-21 15:59:59','2018-06-22 11:59:59','BNBUSDT','4h','16.594999999999999','16.139199999999999','15.006890674281529','14.594709850579358','0.9043019387937047','0.904301938793705','test'),('2018-07-17 23:59:59','2018-07-18 23:59:59','BNBUSDT','4h','13.739800000000001','12.857400000000000','15.006890674281529','14.043115340507672','1.0922204598525107','1.092220459852511','test'),('2018-07-19 03:59:59','2018-07-19 07:59:59','BNBUSDT','4h','12.886799999999999','12.834099999999999','15.006890674281529','14.945520657013112','1.1645164567062056','1.164516456706206','test'),('2018-07-26 03:59:59','2018-07-30 03:59:59','BNBUSDT','4h','13.066599999999999','13.685300000000000','15.006890674281529','15.717462916500470','1.1484923908500704','1.148492390850070','test'),('2018-08-02 23:59:59','2018-08-04 19:59:59','BNBUSDT','4h','14.150000000000000','13.643200000000000','15.006890674281529','14.469400059883940','1.0605576448255496','1.060557644825550','test'),('2018-08-04 23:59:59','2018-08-05 03:59:59','BNBUSDT','4h','13.866300000000001','13.852800000000000','15.006890674281529','14.992280214093677','1.0822563102111975','1.082256310211198','test'),('2018-08-27 11:59:59','2018-08-30 11:59:59','BNBUSDT','4h','10.699900000000000','10.449999999999999','15.006890674281529','14.656399363194232','1.4025262548511228','1.402526254851123','test'),('2018-08-31 23:59:59','2018-09-05 11:59:59','BNBUSDT','4h','10.989900000000000','10.534700000000001','15.006890674281529','14.385307526579279','1.3655165810682106','1.365516581068211','test'),('2018-09-16 11:59:59','2018-09-16 15:59:59','BNBUSDT','4h','9.933500000000000','9.889699999999999','15.006890674281529','14.940720461211257','1.5107354582253514','1.510735458225351','test'),('2018-09-16 23:59:59','2018-09-17 11:59:59','BNBUSDT','4h','9.939900000000000','9.932000000000000','15.006890674281529','14.994963548623643','1.5097627415045956','1.509762741504596','test'),('2018-09-21 07:59:59','2018-09-24 11:59:59','BNBUSDT','4h','10.230000000000000','9.925599999999999','15.006890674281529','14.560351327140637','1.4669492350226323','1.466949235022632','test'),('2018-09-28 07:59:59','2018-09-28 11:59:59','BNBUSDT','4h','10.217300000000000','9.949999999999999','15.006890674281529','14.614287748142974','1.4687726380043191','1.468772638004319','test'),('2018-09-28 15:59:59','2018-09-28 19:59:59','BNBUSDT','4h','10.024100000000001','10.049700000000000','15.006890674281529','15.045215950492018','1.4970811019723993','1.497081101972399','test'),('2018-09-29 07:59:59','2018-09-29 11:59:59','BNBUSDT','4h','9.899400000000000','9.960900000000001','15.006890674281529','15.100120948486865','1.5159394179729608','1.515939417972961','test'),('2018-09-29 15:59:59','2018-09-29 19:59:59','BNBUSDT','4h','9.988099999999999','10.000000000000000','15.006890674281529','15.024770150760935','1.5024770150760935','1.502477015076094','test'),('2018-09-29 23:59:59','2018-09-30 03:59:59','BNBUSDT','4h','10.011799999999999','9.895500000000000','15.006890674281529','14.832566238573772','1.4989203414252712','1.498920341425271','test'),('2018-09-30 11:59:59','2018-09-30 15:59:59','BNBUSDT','4h','10.009800000000000','9.965999999999999','15.006890674281529','14.941224845640242','1.4992198319927998','1.499219831992800','test'),('2018-09-30 19:59:59','2018-09-30 23:59:59','BNBUSDT','4h','9.980800000000000','10.017200000000001','15.006890674281529','15.061620838250736','1.503575933219935','1.503575933219935','test'),('2018-10-01 23:59:59','2018-10-02 03:59:59','BNBUSDT','4h','9.981100000000000','9.973200000000000','15.006890674281529','14.995012781431360','1.5035307405277503','1.503530740527750','test'),('2018-10-02 19:59:59','2018-10-07 11:59:59','BNBUSDT','4h','10.024100000000001','10.394000000000000','15.006890674281529','15.560660973901118','1.4970811019723993','1.497081101972399','test'),('2018-10-07 23:59:59','2018-10-09 15:59:59','BNBUSDT','4h','10.585200000000000','10.345700000000001','15.006890674281529','14.667345808195822','1.4177238667461671','1.417723866746167','test'),('2018-10-16 23:59:59','2018-10-18 15:59:59','BNBUSDT','4h','10.277100000000001','10.132400000000001','15.006890674281529','14.795595943222326','1.4602261994416252','1.460226199441625','test'),('2018-11-05 15:59:59','2018-11-08 19:59:59','BNBUSDT','4h','9.726699999999999','9.742500000000000','15.006890674281529','15.031267788066641','1.5428553028551852','1.542855302855185','test'),('2018-12-05 07:59:59','2018-12-06 11:59:59','BNBUSDT','4h','5.910600000000000','5.515800000000000','15.006890674281529','14.004501671776479','2.5389792363349795','2.538979236334979','test'),('2018-12-18 15:59:59','2018-12-25 03:59:59','BNBUSDT','4h','5.085000000000000','5.365500000000000','15.006890674281529','15.834704407641603','2.951207605561756','2.951207605561756','test'),('2018-12-29 07:59:59','2018-12-30 03:59:59','BNBUSDT','4h','5.885000000000000','5.635600000000000','15.006890674281529','14.370914712656072','2.550023903871118','2.550023903871118','test'),('2018-12-30 07:59:59','2019-01-03 11:59:59','BNBUSDT','4h','5.708200000000000','5.830000000000000','15.006890674281529','15.327103575743896','2.629005759132744','2.629005759132744','test'),('2019-01-04 19:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.957600000000000','6.059900000000000','15.006890674281529','15.264579158902684','2.518949018779631','2.518949018779631','test'),('2019-01-17 15:59:59','2019-01-22 11:59:59','BNBUSDT','4h','6.132900000000000','6.436200000000000','15.006890674281529','15.749050165143858','2.4469485356489633','2.446948535648963','test'),('2019-01-22 15:59:59','2019-01-24 15:59:59','BNBUSDT','4h','6.481700000000000','6.424400000000000','15.006890674281529','14.874225658061043','2.3152707891882573','2.315270789188257','test'),('2019-01-25 03:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.493200000000000','6.739800000000000','15.006890674281529','15.576825258196672','2.311170251075206','2.311170251075206','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','BNBUSDT','4h','6.799100000000000','6.158900000000000','15.006890674281529','13.593849034994705','2.207187815193412','2.207187815193412','test'),('2019-02-02 11:59:59','2019-02-13 07:59:59','BNBUSDT','4h','6.728300000000000','9.035700000000000','15.006890674281529','20.153346620335839','2.2304134289912056','2.230413428991206','test'),('2019-02-15 23:59:59','2019-02-17 07:59:59','BNBUSDT','4h','9.291100000000000','8.920299999999999','15.315165132055480','14.703949750565000','1.6483694214953535','1.648369421495353','test'),('2019-02-17 23:59:59','2019-02-24 15:59:59','BNBUSDT','4h','9.220000000000001','9.786300000000001','15.315165132055480','16.255835198680536','1.661080816925757','1.661080816925757','test'),('2019-02-28 23:59:59','2019-03-10 11:59:59','BNBUSDT','4h','10.277900000000001','14.194800000000001','15.397528803339124','21.265515509747924','1.4981201221396514','1.498120122139651','test'),('2019-03-12 11:59:59','2019-03-18 19:59:59','BNBUSDT','4h','15.154299999999999','15.415500000000000','16.864525479941324','17.155202981070424','1.1128541390853637','1.112854139085364','test'),('2019-03-19 07:59:59','2019-03-19 15:59:59','BNBUSDT','4h','15.686700000000000','15.414999999999999','16.937194855223598','16.643835777650605','1.079716884700007','1.079716884700007','test'),('2019-03-24 11:59:59','2019-03-26 15:59:59','BNBUSDT','4h','17.040199999999999','15.904299999999999','16.937194855223598','15.808161179794409','0.9939551680862666','0.993955168086267','test'),('2019-03-26 19:59:59','2019-03-26 23:59:59','BNBUSDT','4h','16.150400000000001','16.199800000000000','16.937194855223598','16.989001462233208','1.0487167410852734','1.048716741085273','test'),('2019-03-27 03:59:59','2019-03-29 23:59:59','BNBUSDT','4h','16.375200000000000','16.475300000000001','16.937194855223598','17.040730274944146','1.0343198773281304','1.034319877328130','test'),('2019-03-30 23:59:59','2019-04-07 15:59:59','BNBUSDT','4h','16.966600000000000','18.961500000000001','16.937194855223598','18.928637455195634','0.9982668805313734','0.998266880531373','test'),('2019-04-14 07:59:59','2019-04-23 11:59:59','BNBUSDT','4h','19.053100000000001','23.763100000000001','17.118292823648602','21.350001007586382','0.8984518437235202','0.898451843723520','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 23:49:48
