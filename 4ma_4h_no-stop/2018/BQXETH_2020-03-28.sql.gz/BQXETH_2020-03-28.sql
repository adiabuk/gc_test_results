-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 19:59:59','2018-03-23 07:59:59','BQXETH','4h','0.005199300000000','0.004607600000000','0.072144500000000','0.063934183101571','13.875810205219935','13.875810205219935','test'),('2018-03-24 07:59:59','2018-03-28 19:59:59','BQXETH','4h','0.005348700000000','0.005968100000000','0.072144500000000','0.080499110148260','13.488230785050574','13.488230785050574','test'),('2018-04-19 11:59:59','2018-04-21 03:59:59','BQXETH','4h','0.005135800000000','0.005030000000000','0.072180573312458','0.070693618085140','14.054397233626261','14.054397233626261','test'),('2018-04-24 15:59:59','2018-04-25 07:59:59','BQXETH','4h','0.005350900000000','0.005205700000000','0.072180573312458','0.070221908556068','13.489426696902953','13.489426696902953','test'),('2018-04-25 15:59:59','2018-04-25 19:59:59','BQXETH','4h','0.005126300000000','0.005179500000000','0.072180573312458','0.072929652863054','14.080442680385072','14.080442680385072','test'),('2018-04-26 03:59:59','2018-04-27 15:59:59','BQXETH','4h','0.005170100000000','0.005089300000000','0.072180573312458','0.071052511897080','13.961156130917777','13.961156130917777','test'),('2018-04-27 19:59:59','2018-04-27 23:59:59','BQXETH','4h','0.005168000000000','0.005122500000000','0.072180573312458','0.071545082583798','13.966829201327013','13.966829201327013','test'),('2018-04-29 19:59:59','2018-05-01 15:59:59','BQXETH','4h','0.005449500000000','0.005260000000000','0.072180573312458','0.069670578149102','13.24535706256684','13.245357062566841','test'),('2018-05-09 07:59:59','2018-05-11 07:59:59','BQXETH','4h','0.005522500000000','0.005148500000000','0.072180573312458','0.067292291842316','13.070271310540155','13.070271310540155','test'),('2018-05-31 15:59:59','2018-06-01 15:59:59','BQXETH','4h','0.004490000000000','0.003961200000000','0.072180573312458','0.063679663030136','16.075851517251227','16.075851517251227','test'),('2018-06-01 19:59:59','2018-06-02 03:59:59','BQXETH','4h','0.004072900000000','0.004015700000000','0.072180573312458','0.071166865931115','17.72215701648899','17.722157016488989','test'),('2018-06-02 11:59:59','2018-06-03 11:59:59','BQXETH','4h','0.004111300000000','0.004020000000000','0.072180573312458','0.070577652984720','17.556630095701603','17.556630095701603','test'),('2018-06-09 15:59:59','2018-06-10 03:59:59','BQXETH','4h','0.004129300000000','0.003943400000000','0.072180573312458','0.068931022885319','17.480099123933357','17.480099123933357','test'),('2018-06-29 11:59:59','2018-07-01 11:59:59','BQXETH','4h','0.003673700000000','0.003160000000000','0.072180573312458','0.062087435464890','19.647922615471597','19.647922615471597','test'),('2018-07-02 03:59:59','2018-07-06 23:59:59','BQXETH','4h','0.003290000000000','0.003763200000000','0.072180573312458','0.082562289814420','21.939383985549544','21.939383985549544','test'),('2018-08-18 11:59:59','2018-08-18 19:59:59','BQXETH','4h','0.001616900000000','0.001487600000000','0.072180573312458','0.066408448796841','44.641334227508196','44.641334227508196','test'),('2018-08-19 15:59:59','2018-08-22 11:59:59','BQXETH','4h','0.001647700000000','0.001600000000000','0.072180573312458','0.070090985798345','43.80686612396553','43.806866123965527','test'),('2018-08-24 23:59:59','2018-08-29 19:59:59','BQXETH','4h','0.001699900000000','0.001805400000000','0.072180573312458','0.076660278285965','42.46165851665275','42.461658516652747','test'),('2018-09-08 03:59:59','2018-09-08 19:59:59','BQXETH','4h','0.001745100000000','0.001777900000000','0.072180573312458','0.073537242159314','41.36185508707696','41.361855087076961','test'),('2018-09-09 03:59:59','2018-09-09 11:59:59','BQXETH','4h','0.001839100000000','0.001748600000000','0.072180573312458','0.068628650151794','39.247769731095644','39.247769731095644','test'),('2018-09-09 15:59:59','2018-09-09 19:59:59','BQXETH','4h','0.001752100000000','0.001728700000000','0.072180573312458','0.071216572732861','41.19660596567434','41.196605965674337','test'),('2018-09-27 03:59:59','2018-09-28 03:59:59','BQXETH','4h','0.001599800000000','0.001500000000000','0.072180573312458','0.067677747198829','45.11849813255282','45.118498132552823','test'),('2018-09-28 07:59:59','2018-09-29 11:59:59','BQXETH','4h','0.001511200000000','0.001446300000000','0.072180573312458','0.069080706181715','47.763746236406824','47.763746236406824','test'),('2018-10-05 07:59:59','2018-10-05 23:59:59','BQXETH','4h','0.001547300000000','0.001473200000000','0.072180573312458','0.068723854846451','46.649372010895114','46.649372010895114','test'),('2018-10-06 03:59:59','2018-10-08 19:59:59','BQXETH','4h','0.001498000000000','0.001506200000000','0.072180573312458','0.072575687265170','48.18462837947797','48.184628379477971','test'),('2018-10-08 23:59:59','2018-10-09 03:59:59','BQXETH','4h','0.001525000000000','0.001511500000000','0.072180573312458','0.071541597745430','47.33152348357901','47.331523483579012','test'),('2018-10-11 15:59:59','2018-10-11 23:59:59','BQXETH','4h','0.001524900000000','0.001576500000000','0.072180573312458','0.074623040085966','47.334627393572035','47.334627393572035','test'),('2018-10-12 23:59:59','2018-10-13 11:59:59','BQXETH','4h','0.001541000000000','0.001524900000000','0.072180573312458','0.071426447919641','46.84008651035561','46.840086510355611','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','BQXETH','4h','0.001670800000000','0.001700900000000','0.072180573312458','0.073480929582930','43.201204999077085','43.201204999077085','test'),('2018-10-15 15:59:59','2018-10-18 19:59:59','BQXETH','4h','0.001771500000000','0.001793400000000','0.072180573312458','0.073072898774238','40.74545487578775','40.745454875787750','test'),('2018-10-19 15:59:59','2018-10-25 07:59:59','BQXETH','4h','0.001858600000000','0.002029100000000','0.072180573312458','0.078802109818309','38.83599123666093','38.835991236660931','test'),('2018-11-02 15:59:59','2018-11-02 19:59:59','BQXETH','4h','0.001958000000000','0.001935800000000','0.072180573312458','0.071362182746811','36.86443989400306','36.864439894003063','test'),('2018-12-16 03:59:59','2018-12-16 15:59:59','BQXETH','4h','0.001100500000000','0.001030700000000','0.072180573312458','0.067602468798865','65.58888987956202','65.588889879562018','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','BQXETH','4h','0.001032900000000','0.001026600000000','0.072180573312458','0.071740320033468','69.88147285551167','69.881472855511674','test'),('2018-12-17 03:59:59','2018-12-17 07:59:59','BQXETH','4h','0.001031200000000','0.001010700000000','0.072180573312458','0.070745641434156','69.99667699035881','69.996676990358807','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','BQXETH','4h','0.001045900000000','0.001019400000000','0.072180573312458','0.070351731938732','69.01288202740032','69.012882027400323','test'),('2018-12-22 19:59:59','2018-12-23 03:59:59','BQXETH','4h','0.001051200000000','0.000958200000000','0.072180573312458','0.065794734920089','68.66492895020738','68.664928950207383','test'),('2019-01-11 11:59:59','2019-01-12 19:59:59','BQXETH','4h','0.000850100000000','0.000827300000000','0.072180573312458','0.070244663335368','84.90833232850018','84.908332328500180','test'),('2019-01-12 23:59:59','2019-01-14 19:59:59','BQXETH','4h','0.000840200000000','0.000838700000000','0.072180573312458','0.072051710113257','85.90879946733872','85.908799467338724','test'),('2019-01-15 03:59:59','2019-01-15 11:59:59','BQXETH','4h','0.000845100000000','0.000846000000000','0.072180573312458','0.072257442932599','85.41068904562538','85.410689045625375','test'),('2019-01-15 15:59:59','2019-01-22 11:59:59','BQXETH','4h','0.000850300000000','0.001604200000000','0.072180573312458','0.136177908629713','84.88836094608726','84.888360946087261','test'),('2019-03-02 23:59:59','2019-03-04 07:59:59','BQXETH','4h','0.001084800000000','0.001090800000000','0.075491627594496','0.075909169782519','69.59036467044247','69.590364670442469','test'),('2019-03-04 11:59:59','2019-03-04 19:59:59','BQXETH','4h','0.001095100000000','0.001084200000000','0.075596013141502','0.074843573598773','69.03115070906925','69.031150709069252','test'),('2019-03-04 23:59:59','2019-03-05 15:59:59','BQXETH','4h','0.001092300000000','0.001068000000000','0.075596013141502','0.073914256188890','69.20810504577679','69.208105045776790','test'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BQXETH','4h','0.001109700000000','0.001081400000000','0.075596013141502','0.073668134280635','68.12292794584302','68.122927945843017','test'),('2019-03-09 03:59:59','2019-03-09 15:59:59','BQXETH','4h','0.001115300000000','0.001124700000000','0.075596013141502','0.076233153393927','67.78087791760242','67.780877917602425','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:10:21
