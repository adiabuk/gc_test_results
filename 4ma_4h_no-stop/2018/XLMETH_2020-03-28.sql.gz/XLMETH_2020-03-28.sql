-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-25 15:59:59','2018-05-27 07:59:59','XLMETH','4h','0.000490070000000','0.000472230000000','0.072144500000000','0.069518226447242','147.21264309180322','147.212643091803216','test'),('2018-05-28 07:59:59','2018-05-29 03:59:59','XLMETH','4h','0.000487090000000','0.000474530000000','0.072144500000000','0.070284197140159','148.11328501919564','148.113285019195644','test'),('2018-05-29 11:59:59','2018-05-30 19:59:59','XLMETH','4h','0.000499910000000','0.000488130000000','0.072144500000000','0.070444469574523','144.31497669580526','144.314976695805257','test'),('2018-05-30 23:59:59','2018-06-03 11:59:59','XLMETH','4h','0.000492440000000','0.000491920000000','0.072144500000000','0.072068317845829','146.5041426366664','146.504142636666387','test'),('2018-07-02 15:59:59','2018-07-05 15:59:59','XLMETH','4h','0.000451620000000','0.000437130000000','0.072144500000000','0.069829780091670','159.74602541960056','159.746025419600556','test'),('2018-07-11 03:59:59','2018-07-11 07:59:59','XLMETH','4h','0.000441740000000','0.000426920000000','0.072144500000000','0.069724113596233','163.318920632046','163.318920632046002','test'),('2018-07-14 07:59:59','2018-07-24 11:59:59','XLMETH','4h','0.000465390000000','0.000622740000000','0.072144500000000','0.096536809836911','155.01944605599604','155.019446055996042','test'),('2018-07-24 15:59:59','2018-07-24 23:59:59','XLMETH','4h','0.000632150000000','0.000627030000000','0.075493103633142','0.074881659054163','119.42276933187019','119.422769331870185','test'),('2018-07-25 11:59:59','2018-07-29 07:59:59','XLMETH','4h','0.000649000000000','0.000670040000000','0.075493103633142','0.077940522586056','116.32219357957166','116.322193579571660','test'),('2018-08-11 11:59:59','2018-08-16 03:59:59','XLMETH','4h','0.000674180000000','0.000740710000000','0.075952097226625','0.083447266214859','112.65848471717567','112.658484717175668','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','XLMETH','4h','0.000757630000000','0.000745500000000','0.077825889473684','0.076579861677377','102.72281915141163','102.722819151411628','test'),('2018-08-18 19:59:59','2018-08-23 07:59:59','XLMETH','4h','0.000768610000000','0.000771910000000','0.077825889473684','0.078160032192700','101.25536939889412','101.255369398894118','test'),('2018-08-23 15:59:59','2018-08-25 19:59:59','XLMETH','4h','0.000777320000000','0.000774000000000','0.077825889473684','0.077493488463736','100.12078612885814','100.120786128858143','test'),('2018-08-25 23:59:59','2018-08-26 03:59:59','XLMETH','4h','0.000784000000000','0.000773590000000','0.077825889473684','0.076792512548402','99.26771616541328','99.267716165413276','test'),('2018-08-27 03:59:59','2018-08-29 15:59:59','XLMETH','4h','0.000794840000000','0.000778680000000','0.077825889473684','0.076243600744009','97.91390653928339','97.913906539283388','test'),('2018-09-01 07:59:59','2018-09-01 15:59:59','XLMETH','4h','0.000788310000000','0.000777700000000','0.077825889473684','0.076778417429291','98.72498062143573','98.724980621435733','test'),('2018-09-04 23:59:59','2018-09-13 19:59:59','XLMETH','4h','0.000812530000000','0.001006820000000','0.077825889473684','0.096435407972499','95.78217354889543','95.782173548895429','test'),('2018-09-18 11:59:59','2018-09-22 03:59:59','XLMETH','4h','0.001018510000000','0.000984750000000','0.081251413151740','0.078558216513511','79.77478193806685','79.774781938066852','test'),('2018-09-23 03:59:59','2018-09-28 07:59:59','XLMETH','4h','0.001069350000000','0.001133000000000','0.081251413151740','0.086087671109479','75.98205746644224','75.982057466442242','test'),('2018-10-02 03:59:59','2018-10-02 15:59:59','XLMETH','4h','0.001127200000000','0.001116570000000','0.081787178481618','0.081015888819393','72.55782335132893','72.557823351328935','test'),('2018-10-17 07:59:59','2018-10-21 23:59:59','XLMETH','4h','0.001125900000000','0.001190260000000','0.081787178481618','0.086462391917160','72.64160092514255','72.641600925142555','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','XLMETH','4h','0.001201600000000','0.001193340000000','0.082763159424947','0.082194231581363','68.87746290358459','68.877462903584586','test'),('2018-10-23 03:59:59','2018-10-23 19:59:59','XLMETH','4h','0.001217250000000','0.001185150000000','0.082763159424947','0.080580618929945','67.99191573213966','67.991915732139660','test'),('2018-11-03 07:59:59','2018-11-04 19:59:59','XLMETH','4h','0.001189250000000','0.001161000000000','0.082763159424947','0.080797164677203','69.59273443342191','69.592734433421910','test'),('2018-11-05 03:59:59','2018-11-05 07:59:59','XLMETH','4h','0.001166090000000','0.001166100000000','0.082763159424947','0.082763869174275','70.97493283103962','70.974932831039624','test'),('2018-11-05 23:59:59','2018-11-07 11:59:59','XLMETH','4h','0.001182900000000','0.001175020000000','0.082763159424947','0.082211824826698','69.96631957472906','69.966319574729056','test'),('2018-11-08 15:59:59','2018-11-13 19:59:59','XLMETH','4h','0.001220630000000','0.001238390000000','0.082763159424947','0.083967352105274','67.80364191028158','67.803641910281584','test'),('2018-11-15 07:59:59','2018-11-23 03:59:59','XLMETH','4h','0.001296640000000','0.001456140000000','0.082763159424947','0.092943875682566','63.828942054037356','63.828942054037356','test'),('2018-11-30 23:59:59','2018-12-02 03:59:59','XLMETH','4h','0.001404500000000','0.001394820000000','0.084292364675621','0.083711410535315','60.0159235853478','60.015923585347799','test'),('2019-01-10 07:59:59','2019-01-11 07:59:59','XLMETH','4h','0.000848910000000','0.000829890000000','0.084292364675621','0.082403777220967','99.2948188566762','99.294818856676201','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','XLMETH','4h','0.000848240000000','0.000841350000000','0.084292364675621','0.083607682990467','99.37324893381708','99.373248933817081','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','XLMETH','4h','0.000844640000000','0.000845540000000','0.084292364675621','0.084382181790851','99.79679470025218','99.796794700252178','test'),('2019-01-16 03:59:59','2019-01-19 19:59:59','XLMETH','4h','0.000875050000000','0.000857130000000','0.084292364675621','0.082566155687578','96.328626564906','96.328626564906003','test'),('2019-01-21 11:59:59','2019-01-21 19:59:59','XLMETH','4h','0.000878640000000','0.000876940000000','0.084292364675621','0.084129275105435','95.93504128610239','95.935041286102390','test'),('2019-01-22 11:59:59','2019-01-22 15:59:59','XLMETH','4h','0.000880000000000','0.000869720000000','0.084292364675621','0.083307676597365','95.78677804047841','95.786778040478410','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','XLMETH','4h','0.000618210000000','0.000612070000000','0.084292364675621','0.083455181325128','136.34907988486273','136.349079884862732','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','XLMETH','4h','0.000616370000000','0.000613330000000','0.084292364675621','0.083876626095525','136.75611187374628','136.756111873746278','test'),('2019-02-28 23:59:59','2019-03-05 15:59:59','XLMETH','4h','0.000623030000000','0.000630670000000','0.084292364675621','0.085326012599672','135.29423089678025','135.294230896780249','test'),('2019-03-08 15:59:59','2019-03-15 15:59:59','XLMETH','4h','0.000641320000000','0.000783390000000','0.084292364675621','0.102965439348897','131.43573360509728','131.435733605097283','test'),('2019-03-18 15:59:59','2019-03-20 19:59:59','XLMETH','4h','0.000797620000000','0.000794460000000','0.087421216641963','0.087074872462293','109.60258850325123','109.602588503251226','test'),('2019-04-06 07:59:59','2019-04-06 11:59:59','XLMETH','4h','0.000766120000000','0.000765550000000','0.087421216641963','0.087356174489969','114.1090385865961','114.109038586596100','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','XLMETH','4h','0.000776290000000','0.000764260000000','0.087421216641963','0.086066468756247','112.61412183844054','112.614121838440539','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','XLMETH','4h','0.000768820000000','0.000758880000000','0.087421216641963','0.086290956121398','113.70830186774928','113.708301867749284','test'),('2019-05-18 23:59:59','2019-05-19 07:59:59','XLMETH','4h','0.000562270000000','0.000549070000000','0.087421216641963','0.085368892919065','155.47906991652232','155.479069916522320','test'),('2019-05-19 11:59:59','2019-05-19 15:59:59','XLMETH','4h','0.000554810000000','0.000550680000000','0.087421216641963','0.086770453993973','157.56964842371804','157.569648423718036','test'),('2019-05-19 19:59:59','2019-05-19 23:59:59','XLMETH','4h','0.000550900000000','0.000549600000000','0.087421216641963','0.087214922247999','158.6879953566219','158.687995356621911','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:40:04
