-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-01 19:59:59','2018-12-03 03:59:59','TRXUSDT','4h','0.015400000000000','0.014450000000000','15.000000000000000','14.074675324675322','974.025974025974','974.025974025974051','test'),('2018-12-18 03:59:59','2018-12-25 03:59:59','TRXUSDT','4h','0.014280000000000','0.018280000000000','15.000000000000000','19.201680672268910','1050.420168067227','1050.420168067226996','test'),('2018-12-29 07:59:59','2018-12-31 03:59:59','TRXUSDT','4h','0.020200000000000','0.019400000000000','15.819088999236058','15.192590425008889','783.1232177839634','783.123217783963355','test'),('2019-01-02 19:59:59','2019-01-10 19:59:59','TRXUSDT','4h','0.019670000000000','0.025430000000000','15.819088999236058','20.451420094080984','804.2241484105774','804.224148410577413','test'),('2019-01-11 03:59:59','2019-01-11 07:59:59','TRXUSDT','4h','0.026060000000000','0.025960000000000','16.820547129390498','16.756001668418161','645.4546097233499','645.454609723349904','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','TRXUSDT','4h','0.024290000000000','0.023950000000000','16.820547129390498','16.585101018892647','692.4885602877932','692.488560287793234','test'),('2019-01-16 03:59:59','2019-01-16 07:59:59','TRXUSDT','4h','0.023980000000000','0.023740000000000','16.820547129390498','16.652201369963738','701.4406642781692','701.440664278169152','test'),('2019-01-16 11:59:59','2019-01-17 03:59:59','TRXUSDT','4h','0.024260000000000','0.024170000000000','16.820547129390498','16.758146088926971','693.3448940391796','693.344894039179621','test'),('2019-01-17 11:59:59','2019-01-19 03:59:59','TRXUSDT','4h','0.024190000000000','0.023880000000000','16.820547129390498','16.604988236868337','695.3512662005166','695.351266200516648','test'),('2019-01-21 19:59:59','2019-01-28 03:59:59','TRXUSDT','4h','0.025280000000000','0.026650000000000','16.820547129390498','17.732103678728510','665.3697440423456','665.369744042345587','test'),('2019-01-28 07:59:59','2019-01-28 11:59:59','TRXUSDT','4h','0.027550000000000','0.027390000000000','16.861861950754342','16.763934621820741','612.0458058350033','612.045805835003307','test'),('2019-02-09 03:59:59','2019-02-09 15:59:59','TRXUSDT','4h','0.027070000000000','0.026400000000000','16.861861950754342','16.444519966749709','622.8984835890042','622.898483589004172','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','TRXUSDT','4h','0.026230000000000','0.025580000000000','16.861861950754342','16.444011768978118','642.8464335018812','642.846433501881165','test'),('2019-02-20 07:59:59','2019-02-21 11:59:59','TRXUSDT','4h','0.024670000000000','0.024600000000000','16.861861950754342','16.814017186402790','683.4966335936093','683.496633593609317','test'),('2019-02-22 23:59:59','2019-02-24 15:59:59','TRXUSDT','4h','0.024900000000000','0.023500000000000','16.861861950754342','15.913805455531207','677.1832108736684','677.183210873668372','test'),('2019-03-16 07:59:59','2019-03-17 07:59:59','TRXUSDT','4h','0.023320000000000','0.022930000000000','16.861861950754342','16.579866832366939','723.0644061215412','723.064406121541197','test'),('2019-03-17 11:59:59','2019-03-18 11:59:59','TRXUSDT','4h','0.022970000000000','0.022640000000000','16.861861950754342','16.619614913586343','734.0819308121177','734.081930812117662','test'),('2019-03-23 11:59:59','2019-03-24 23:59:59','TRXUSDT','4h','0.023960000000000','0.023240000000000','16.861861950754342','16.355161591633177','703.7504987793966','703.750498779396594','test'),('2019-03-27 19:59:59','2019-03-28 03:59:59','TRXUSDT','4h','0.023310000000000','0.022920000000000','16.861861950754342','16.579745856340175','723.3746010619623','723.374601061962267','test'),('2019-03-28 11:59:59','2019-03-29 11:59:59','TRXUSDT','4h','0.023030000000000','0.023070000000000','16.861861950754342','16.891148727915880','732.1694290383996','732.169429038399585','test'),('2019-03-29 15:59:59','2019-03-30 07:59:59','TRXUSDT','4h','0.023210000000000','0.023160000000000','16.861861950754342','16.825537388171931','726.4912516481836','726.491251648183606','test'),('2019-03-30 11:59:59','2019-03-30 19:59:59','TRXUSDT','4h','0.023560000000000','0.023180000000000','16.861861950754342','16.589896435419593','715.6987245651248','715.698724565124849','test'),('2019-03-30 23:59:59','2019-03-31 11:59:59','TRXUSDT','4h','0.023220000000000','0.023370000000000','16.861861950754342','16.970788707542159','726.1783785854583','726.178378585458290','test'),('2019-03-31 19:59:59','2019-04-03 23:59:59','TRXUSDT','4h','0.023440000000000','0.025950000000000','16.861861950754342','18.667462355890581','719.3627112096563','719.362711209656254','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','TRXUSDT','4h','0.026350000000000','0.025180000000000','16.861861950754342','16.113156885009275','639.9188596111705','639.918859611170546','test'),('2019-04-05 03:59:59','2019-04-11 03:59:59','TRXUSDT','4h','0.027110000000000','0.027180000000000','16.861861950754342','16.905400509830432','621.9794153727164','621.979415372716403','test'),('2019-05-07 19:59:59','2019-05-08 03:59:59','TRXUSDT','4h','0.024210000000000','0.024630000000000','16.861861950754342','17.154384958574120','696.4833519518522','696.483351951852228','test'),('2019-05-08 07:59:59','2019-05-09 07:59:59','TRXUSDT','4h','0.024650000000000','0.023830000000000','16.861861950754342','16.300939971053793','684.0511947567685','684.051194756768496','test'),('2019-05-11 15:59:59','2019-05-12 11:59:59','TRXUSDT','4h','0.025250000000000','0.024020000000000','16.861861950754342','16.040472239885911','667.796512901162','667.796512901162032','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','TRXUSDT','4h','0.023810000000000','0.023760000000000','16.861861950754342','16.826452748841795','708.1840382509173','708.184038250917297','test'),('2019-05-13 11:59:59','2019-05-13 23:59:59','TRXUSDT','4h','0.024720000000000','0.024330000000000','16.861861950754342','16.595837429686618','682.1141565839135','682.114156583913541','test'),('2019-05-14 03:59:59','2019-05-17 03:59:59','TRXUSDT','4h','0.025740000000000','0.026060000000000','16.861861950754342','17.071488828153001','655.0839918707981','655.083991870798059','test'),('2019-05-19 07:59:59','2019-05-20 15:59:59','TRXUSDT','4h','0.028200000000000','0.027310000000000','16.861861950754342','16.329696804081600','597.9383670480263','597.938367048026294','test'),('2019-05-20 19:59:59','2019-05-22 11:59:59','TRXUSDT','4h','0.027790000000000','0.027420000000000','16.861861950754342','16.637360730107378','606.7600558026032','606.760055802603233','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','TRXUSDT','4h','0.028080000000000','0.026550000000000','16.861861950754342','15.943106652155548','600.4936592148982','600.493659214898230','test'),('2019-05-25 03:59:59','2019-05-26 03:59:59','TRXUSDT','4h','0.028090000000000','0.027220000000000','16.861861950754342','16.339618451389576','600.2798843273173','600.279884327317291','test'),('2019-05-26 07:59:59','2019-05-30 23:59:59','TRXUSDT','4h','0.028750000000000','0.031020000000000','16.861861950754342','18.193215920431292','586.4995461131945','586.499546113194469','test'),('2019-06-01 07:59:59','2019-06-03 23:59:59','TRXUSDT','4h','0.034910000000000','0.033750000000000','16.861861950754342','16.301570920594649','483.0095087583599','483.009508758359914','test'),('2019-06-16 15:59:59','2019-06-16 23:59:59','TRXUSDT','4h','0.033560000000000','0.032810000000000','16.861861950754342','16.485032497146900','502.43927147658945','502.439271476589454','test'),('2019-06-17 03:59:59','2019-06-18 07:59:59','TRXUSDT','4h','0.033000000000000','0.032640000000000','16.861861950754342','16.677914365837022','510.96551365922244','510.965513659222438','test'),('2019-06-18 11:59:59','2019-06-18 15:59:59','TRXUSDT','4h','0.032840000000000','0.032720000000000','16.861861950754342','16.800247351665103','513.4549924103027','513.454992410302680','test'),('2019-06-18 19:59:59','2019-06-18 23:59:59','TRXUSDT','4h','0.032860000000000','0.033090000000000','16.861861950754342','16.979884721559987','513.1424817636745','513.142481763674482','test'),('2019-06-19 07:59:59','2019-06-20 11:59:59','TRXUSDT','4h','0.033670000000000','0.032580000000000','16.861861950754342','16.315992347952971','500.7978007352047','500.797800735204703','test'),('2019-06-21 11:59:59','2019-06-21 15:59:59','TRXUSDT','4h','0.033490000000000','0.032900000000000','16.861861950754342','16.564803170493217','503.48945806970266','503.489458069702664','test'),('2019-06-21 19:59:59','2019-06-26 23:59:59','TRXUSDT','4h','0.033170000000000','0.036770000000000','16.861861950754342','18.691910278240492','508.346757635042','508.346757635042025','test'),('2019-07-08 07:59:59','2019-07-10 11:59:59','TRXUSDT','4h','0.035120000000000','0.033510000000000','16.861861950754342','16.088866570893451','480.121353950864','480.121353950863977','test'),('2019-07-21 07:59:59','2019-07-21 19:59:59','TRXUSDT','4h','0.029050000000000','0.027740000000000','16.861861950754342','16.101481945401908','580.4427521774301','580.442752177430066','test'),('2019-07-21 23:59:59','2019-07-22 23:59:59','TRXUSDT','4h','0.029160000000000','0.026610000000000','16.861861950754342','15.387316409793316','578.2531533180502','578.253153318050181','test'),('2019-09-15 07:59:59','2019-09-15 19:59:59','TRXUSDT','4h','0.015800000000000','0.015470000000000','16.861861950754342','16.509683821403144','1067.2064525793887','1067.206452579388724','test'),('2019-09-15 23:59:59','2019-09-16 15:59:59','TRXUSDT','4h','0.015520000000000','0.015370000000000','16.861861950754342','16.698892924168440','1086.4601772393262','1086.460177239326185','test'),('2019-09-16 19:59:59','2019-09-16 23:59:59','TRXUSDT','4h','0.015440000000000','0.015650000000000','16.861861950754342','17.091200746716677','1092.089504582535','1092.089504582535028','test'),('2019-09-17 03:59:59','2019-09-22 19:59:59','TRXUSDT','4h','0.015660000000000','0.016580000000000','16.861861950754342','17.852469421679885','1076.7472510060243','1076.747251006024271','test'),('2019-10-05 03:59:59','2019-10-06 19:59:59','TRXUSDT','4h','0.014570000000000','0.014630000000000','16.861861950754342','16.931299954669598','1157.3000652542446','1157.300065254244601','test'),('2019-10-07 03:59:59','2019-10-11 03:59:59','TRXUSDT','4h','0.014800000000000','0.016360000000000','16.861861950754342','18.639193345563584','1139.3149966725907','1139.314996672590723','test'),('2019-10-14 03:59:59','2019-10-15 19:59:59','TRXUSDT','4h','0.016460000000000','0.015610000000000','16.861861950754342','15.991109662896434','1024.414456303423','1024.414456303423094','test'),('2019-10-25 23:59:59','2019-10-31 03:59:59','TRXUSDT','4h','0.017640000000000','0.020140000000000','16.861861950754342','19.251581614976899','955.8878656890217','955.887865689021737','test'),('2019-11-02 19:59:59','2019-11-03 11:59:59','TRXUSDT','4h','0.020120000000000','0.019490000000000','16.861861950754342','16.333881183906666','838.064709282025','838.064709282024978','test'),('2019-11-05 19:59:59','2019-11-07 11:59:59','TRXUSDT','4h','0.019920000000000','0.019340000000000','16.861861950754342','16.370904122870932','846.4790135920855','846.479013592085494','test'),('2019-11-13 07:59:59','2019-11-14 11:59:59','TRXUSDT','4h','0.019730000000000','0.019240000000000','16.861861950754342','16.443092951470529','854.6306107832914','854.630610783291445','test'),('2019-11-14 15:59:59','2019-11-14 19:59:59','TRXUSDT','4h','0.019280000000000','0.019240000000000','16.861861950754342','16.826878834673941','874.57790201008','874.577902010080038','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:02:00
