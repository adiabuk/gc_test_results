-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-02 07:59:59','2018-06-04 03:59:59','WABIBTC','4h','0.000102970000000','0.000102570000000','0.001467500000000','0.001461799310479','14.251723803049433','14.251723803049433','test'),('2018-07-01 23:59:59','2018-07-03 23:59:59','WABIBTC','4h','0.000065280000000','0.000060310000000','0.001467500000000','0.001355773973652','22.480085784313726','22.480085784313726','test'),('2018-07-04 15:59:59','2018-07-05 15:59:59','WABIBTC','4h','0.000064070000000','0.000060850000000','0.001467500000000','0.001393747073513','22.90463555486187','22.904635554861869','test'),('2018-07-06 23:59:59','2018-07-07 15:59:59','WABIBTC','4h','0.000064850000000','0.000061980000000','0.001467500000000','0.001402554356207','22.629144178874324','22.629144178874324','test'),('2018-07-07 23:59:59','2018-07-08 23:59:59','WABIBTC','4h','0.000063110000000','0.000061700000000','0.001467500000000','0.001434713199176','23.25305022975757','23.253050229757569','test'),('2018-07-17 11:59:59','2018-07-18 15:59:59','WABIBTC','4h','0.000061330000000','0.000059240000000','0.001467500000000','0.001417490624490','23.927930865807927','23.927930865807927','test'),('2018-08-25 19:59:59','2018-08-30 07:59:59','WABIBTC','4h','0.000024750000000','0.000030650000000','0.001467500000000','0.001817328282828','59.2929292929293','59.292929292929301','test'),('2018-08-31 23:59:59','2018-09-05 11:59:59','WABIBTC','4h','0.000030480000000','0.000029890000000','0.001470226705086','0.001441767592356','48.23578428760663','48.235784287606627','test'),('2018-09-16 03:59:59','2018-09-18 03:59:59','WABIBTC','4h','0.000031020000000','0.000029110000000','0.001470226705086','0.001379700173599','47.396089783559','47.396089783558999','test'),('2018-09-20 23:59:59','2018-09-21 11:59:59','WABIBTC','4h','0.000031470000000','0.000031850000000','0.001470226705086','0.001487979680870','46.71835732716873','46.718357327168732','test'),('2018-09-21 19:59:59','2018-09-21 23:59:59','WABIBTC','4h','0.000030550000000','0.000030990000000','0.001470226705086','0.001491401819660','48.12526039561375','48.125260395613751','test'),('2018-09-22 07:59:59','2018-09-22 11:59:59','WABIBTC','4h','0.000030660000000','0.000030430000000','0.001470226705086','0.001459197607168','47.95259964403131','47.952599644031309','test'),('2018-09-22 15:59:59','2018-09-22 19:59:59','WABIBTC','4h','0.000030860000000','0.000030240000000','0.001470226705086','0.001440688773876','47.64182453292288','47.641824532922882','test'),('2018-09-23 03:59:59','2018-09-24 07:59:59','WABIBTC','4h','0.000031140000000','0.000029770000000','0.001470226705086','0.001405544284214','47.213445892292874','47.213445892292874','test'),('2018-09-25 11:59:59','2018-09-28 11:59:59','WABIBTC','4h','0.000032440000000','0.000032950000000','0.001470226705086','0.001493340626775','45.321415076633784','45.321415076633784','test'),('2018-10-06 23:59:59','2018-10-07 07:59:59','WABIBTC','4h','0.000032390000000','0.000032510000000','0.001470226705086','0.001475673670341','45.39137712522383','45.391377125223833','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','WABIBTC','4h','0.000033520000000','0.000031380000000','0.001470226705086','0.001376363782983','43.86117855268497','43.861178552684969','test'),('2018-10-13 23:59:59','2018-10-16 07:59:59','WABIBTC','4h','0.000042680000000','0.000039120000000','0.001470226705086','0.001347592987417','34.4476735024836','34.447673502483603','test'),('2018-10-20 11:59:59','2018-10-21 19:59:59','WABIBTC','4h','0.000042340000000','0.000039010000000','0.001470226705086','0.001354594798427','34.724296293953714','34.724296293953714','test'),('2018-10-23 19:59:59','2018-10-23 23:59:59','WABIBTC','4h','0.000040020000000','0.000039760000000','0.001470226705086','0.001460675007352','36.73729897766117','36.737298977661169','test'),('2018-10-24 11:59:59','2018-10-25 03:59:59','WABIBTC','4h','0.000040180000000','0.000039710000000','0.001470226705086','0.001453028931283','36.59100809074167','36.591008090741667','test'),('2018-10-25 07:59:59','2018-10-25 15:59:59','WABIBTC','4h','0.000040460000000','0.000039980000000','0.001470226705086','0.001452784569188','36.33778312125556','36.337783121255562','test'),('2018-10-25 19:59:59','2018-10-26 03:59:59','WABIBTC','4h','0.000040050000000','0.000039610000000','0.001470226705086','0.001454074401709','36.70978040164794','36.709780401647940','test'),('2018-10-28 15:59:59','2018-10-29 15:59:59','WABIBTC','4h','0.000041630000000','0.000039850000000','0.001470226705086','0.001407363300449','35.316519459188086','35.316519459188086','test'),('2018-10-29 19:59:59','2018-10-29 23:59:59','WABIBTC','4h','0.000040700000000','0.000040880000000','0.001470226705086','0.001476728936214','36.12350626746929','36.123506267469288','test'),('2018-10-30 03:59:59','2018-10-31 15:59:59','WABIBTC','4h','0.000042430000000','0.000043110000000','0.001470226705086','0.001493789141085','34.65064117572472','34.650641175724722','test'),('2018-10-31 19:59:59','2018-11-05 23:59:59','WABIBTC','4h','0.000044840000000','0.000045100000000','0.001470226705086','0.001478751659219','32.78828512680643','32.788285126806429','test'),('2018-11-06 23:59:59','2018-11-08 07:59:59','WABIBTC','4h','0.000046330000000','0.000045750000000','0.001470226705086','0.001451821104202','31.733794627368876','31.733794627368876','test'),('2018-11-11 19:59:59','2018-11-14 01:59:59','WABIBTC','4h','0.000050000000000','0.000046420000000','0.001470226705086','0.001364958473002','29.40453410172','29.404534101719999','test'),('2018-11-27 19:59:59','2018-11-30 11:59:59','WABIBTC','4h','0.000038220000000','0.000037530000000','0.001470226705086','0.001443684150756','38.46747004411303','38.467470044113028','test'),('2018-11-30 15:59:59','2018-12-02 15:59:59','WABIBTC','4h','0.000038610000000','0.000038740000000','0.001470226705086','0.001475176963352','38.078909740637144','38.078909740637144','test'),('2018-12-04 15:59:59','2018-12-05 11:59:59','WABIBTC','4h','0.000042000000000','0.000039380000000','0.001470226705086','0.001378512563007','35.00539774014286','35.005397740142861','test'),('2018-12-05 15:59:59','2018-12-06 07:59:59','WABIBTC','4h','0.000041290000000','0.000038270000000','0.001470226705086','0.001362692564874','35.60733119607654','35.607331196076537','test'),('2018-12-17 15:59:59','2018-12-18 07:59:59','WABIBTC','4h','0.000038400000000','0.000034320000000','0.001470226705086','0.001314015117671','38.28715377828125','38.287153778281251','test'),('2018-12-18 11:59:59','2018-12-19 11:59:59','WABIBTC','4h','0.000034560000000','0.000034520000000','0.001470226705086','0.001468525053807','42.54128197586805','42.541281975868053','test'),('2018-12-22 19:59:59','2018-12-24 19:59:59','WABIBTC','4h','0.000035010000000','0.000034600000000','0.001470226705086','0.001453008968751','41.99447886563839','41.994478865638392','test'),('2019-01-04 15:59:59','2019-01-04 23:59:59','WABIBTC','4h','0.000033230000000','0.000032720000000','0.001470226705086','0.001447662286802','44.24395742058381','44.243957420583811','test'),('2019-01-05 03:59:59','2019-01-05 15:59:59','WABIBTC','4h','0.000033040000000','0.000032780000000','0.001470226705086','0.001458657124477','44.49838695780871','44.498386957808712','test'),('2019-01-05 19:59:59','2019-01-07 03:59:59','WABIBTC','4h','0.000032930000000','0.000032200000000','0.001470226705086','0.001437634373027','44.64703021822047','44.647030218220472','test'),('2019-01-17 11:59:59','2019-01-20 19:59:59','WABIBTC','4h','0.000032520000000','0.000036300000000','0.001470226705086','0.001641120215087','45.20992328062731','45.209923280627308','test'),('2019-01-23 03:59:59','2019-01-24 19:59:59','WABIBTC','4h','0.000040370000000','0.000037000000000','0.001470226705086','0.001347495370032','36.41879378464206','36.418793784642062','test'),('2019-02-08 15:59:59','2019-02-12 15:59:59','WABIBTC','4h','0.000037110000000','0.000036460000000','0.001470226705086','0.001444474957355','39.618073432659656','39.618073432659656','test'),('2019-02-18 03:59:59','2019-02-18 15:59:59','WABIBTC','4h','0.000037150000000','0.000035160000000','0.001470226705086','0.001391471627209','39.57541601846568','39.575416018465681','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','WABIBTC','4h','0.000035290000000','0.000034120000000','0.001470226705086','0.001421483003047','41.661283793879285','41.661283793879285','test'),('2019-02-20 23:59:59','2019-02-21 11:59:59','WABIBTC','4h','0.000037680000000','0.000035440000000','0.001470226705086','0.001382824692894','39.0187554428344','39.018755442834397','test'),('2019-02-21 15:59:59','2019-02-21 19:59:59','WABIBTC','4h','0.000035620000000','0.000035650000000','0.001470226705086','0.001471464964523','41.275314572880404','41.275314572880404','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','WABIBTC','4h','0.000035530000000','0.000035510000000','0.001470226705086','0.001469399107729','41.37986786056853','41.379867860568531','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','WABIBTC','4h','0.000036020000000','0.000035610000000','0.001470226705086','0.001453491753696','40.816954610938375','40.816954610938375','test'),('2019-02-22 19:59:59','2019-02-23 15:59:59','WABIBTC','4h','0.000036450000000','0.000035550000000','0.001470226705086','0.001433924811133','40.33543772526749','40.335437725267489','test'),('2019-02-26 03:59:59','2019-03-03 19:59:59','WABIBTC','4h','0.000036280000000','0.000041290000000','0.001470226705086','0.001673254152508','40.524440603252486','40.524440603252486','test'),('2019-03-05 07:59:59','2019-03-11 07:59:59','WABIBTC','4h','0.000043910000000','0.000052020000000','0.001470226705086','0.001741771651072','33.48273070111592','33.482730701115919','test'),('2019-03-12 23:59:59','2019-03-14 03:59:59','WABIBTC','4h','0.000058190000000','0.000053470000000','0.001470226705086','0.001350971333922','25.265968466849976','25.265968466849976','test'),('2019-03-15 19:59:59','2019-03-16 19:59:59','WABIBTC','4h','0.000055950000000','0.000054110000000','0.001470226705086','0.001421876086009','26.27751036793566','26.277510367935658','test'),('2019-03-19 11:59:59','2019-03-21 15:59:59','WABIBTC','4h','0.000056790000000','0.000056530000000','0.001470226705086','0.001463495609060','25.888830869624936','25.888830869624936','test'),('2019-03-21 19:59:59','2019-03-23 23:59:59','WABIBTC','4h','0.000056590000000','0.000057530000000','0.001470226705086','0.001494648212469','25.980327002756674','25.980327002756674','test'),('2019-03-27 15:59:59','2019-04-01 07:59:59','WABIBTC','4h','0.000059090000000','0.000080950000000','0.001470226705086','0.002014128478198','24.881142411338637','24.881142411338637','test'),('2019-04-13 15:59:59','2019-04-17 03:59:59','WABIBTC','4h','0.000082420000000','0.000076910000000','0.001470226705086','0.001371938071926','17.838227433705413','17.838227433705413','test'),('2019-05-24 03:59:59','2019-05-24 15:59:59','WABIBTC','4h','0.000045490000000','0.000042330000000','0.001470226705086','0.001368096206337','32.319778084985714','32.319778084985714','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:19:04
