-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-02 15:59:59','2018-06-03 11:59:59','TNTETH','4h','0.000145860000000','0.000133800000000','0.072144500000000','0.066179446729741','494.61469902646377','494.614699026463768','test'),('2018-06-03 15:59:59','2018-06-03 19:59:59','TNTETH','4h','0.000134170000000','0.000133730000000','0.072144500000000','0.071907907766267','537.7096221211896','537.709622121189568','test'),('2018-07-03 03:59:59','2018-07-03 23:59:59','TNTETH','4h','0.000114780000000','0.000100800000000','0.072144500000000','0.063357428123366','628.5459139222861','628.545913922286104','test'),('2018-07-04 11:59:59','2018-07-06 07:59:59','TNTETH','4h','0.000103020000000','0.000097800000000','0.072144500000000','0.068488954571928','700.2960590176665','700.296059017666494','test'),('2018-07-18 19:59:59','2018-07-20 07:59:59','TNTETH','4h','0.000100210000000','0.000095710000000','0.072144500000000','0.068904800868177','719.9331404051492','719.933140405149175','test'),('2018-08-24 23:59:59','2018-08-25 19:59:59','TNTETH','4h','0.000068280000000','0.000067010000000','0.072144500000000','0.070802620752783','1056.5978324545986','1056.597832454598574','test'),('2018-08-25 23:59:59','2018-09-02 07:59:59','TNTETH','4h','0.000067540000000','0.000078990000000','0.072144500000000','0.084375097053598','1068.174415161386','1068.174415161385923','test'),('2018-09-02 19:59:59','2018-09-03 07:59:59','TNTETH','4h','0.000082920000000','0.000078190000000','0.072144500000000','0.068029166123975','870.0494452484322','870.049445248432221','test'),('2018-09-05 03:59:59','2018-09-05 11:59:59','TNTETH','4h','0.000080370000000','0.000075780000000','0.072144500000000','0.068024265397536','897.6545974866243','897.654597486624311','test'),('2018-09-08 11:59:59','2018-09-08 23:59:59','TNTETH','4h','0.000079340000000','0.000076980000000','0.072144500000000','0.069998533022435','909.3080413410638','909.308041341063813','test'),('2018-09-09 03:59:59','2018-09-09 11:59:59','TNTETH','4h','0.000078350000000','0.000078100000000','0.072144500000000','0.071914300574346','920.7977026164647','920.797702616464676','test'),('2018-09-09 15:59:59','2018-09-13 19:59:59','TNTETH','4h','0.000078530000000','0.000081150000000','0.072144500000000','0.074551460269961','918.6871259391316','918.687125939131647','test'),('2018-09-15 23:59:59','2018-09-18 19:59:59','TNTETH','4h','0.000111000000000','0.000117650000000','0.072144500000000','0.076466670495495','649.9504504504505','649.950450450450489','test'),('2018-09-21 03:59:59','2018-09-21 19:59:59','TNTETH','4h','0.000126370000000','0.000112100000000','0.072144500000000','0.063997772018675','570.8989475350162','570.898947535016191','test'),('2018-09-25 19:59:59','2018-09-26 03:59:59','TNTETH','4h','0.000120730000000','0.000115650000000','0.072144500000000','0.069108849705955','597.5689555205831','597.568955520583131','test'),('2018-09-26 07:59:59','2018-09-27 23:59:59','TNTETH','4h','0.000118190000000','0.000116470000000','0.072144500000000','0.071094592732042','610.4112023013791','610.411202301379149','test'),('2018-09-28 07:59:59','2018-09-29 07:59:59','TNTETH','4h','0.000126570000000','0.000119140000000','0.072144500000000','0.067909423481078','569.9968396934503','569.996839693450283','test'),('2018-09-30 07:59:59','2018-09-30 15:59:59','TNTETH','4h','0.000121270000000','0.000117290000000','0.072144500000000','0.069776765935516','594.9080564030676','594.908056403067576','test'),('2018-10-01 07:59:59','2018-10-07 15:59:59','TNTETH','4h','0.000123300000000','0.000130100000000','0.072144500000000','0.076123272100568','585.1135442011355','585.113544201135483','test'),('2018-10-10 23:59:59','2018-10-11 07:59:59','TNTETH','4h','0.000134530000000','0.000130660000000','0.072144500000000','0.070069132312495','536.2707202854382','536.270720285438188','test'),('2018-10-11 11:59:59','2018-10-12 03:59:59','TNTETH','4h','0.000133010000000','0.000131050000000','0.072144500000000','0.071081397827231','542.3990677392677','542.399067739267707','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','TNTETH','4h','0.000133730000000','0.000130210000000','0.072144500000000','0.070245534622000','539.4788005683092','539.478800568309225','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','TNTETH','4h','0.000134730000000','0.000135920000000','0.072144500000000','0.072781714837082','535.4746530097232','535.474653009723170','test'),('2018-10-15 11:59:59','2018-10-19 05:59:59','TNTETH','4h','0.000138720000000','0.000148680000000','0.072144500000000','0.077324425173010','520.0728085351788','520.072808535178751','test'),('2018-10-20 15:59:59','2018-10-22 07:59:59','TNTETH','4h','0.000156910000000','0.000148850000000','0.072144500000000','0.068438651615576','459.7826779682621','459.782677968262078','test'),('2018-10-22 23:59:59','2018-10-23 15:59:59','TNTETH','4h','0.000154890000000','0.000163060000000','0.072144500000000','0.075949913938924','465.77893989282717','465.778939892827168','test'),('2018-10-23 19:59:59','2018-10-27 07:59:59','TNTETH','4h','0.000163150000000','0.000171390000000','0.072144500000000','0.075788206282562','442.19736438859945','442.197364388599453','test'),('2018-10-30 15:59:59','2018-10-31 15:59:59','TNTETH','4h','0.000187200000000','0.000172540000000','0.072144500000000','0.066494722382479','385.3872863247863','385.387286324786317','test'),('2018-10-31 19:59:59','2018-11-04 07:59:59','TNTETH','4h','0.000174890000000','0.000171120000000','0.072144500000000','0.070589323803534','412.51357996454914','412.513579964549137','test'),('2018-11-10 11:59:59','2018-11-10 19:59:59','TNTETH','4h','0.000172100000000','0.000170550000000','0.072144500000000','0.071494738378849','419.2010459035444','419.201045903544411','test'),('2018-11-11 03:59:59','2018-11-11 19:59:59','TNTETH','4h','0.000174650000000','0.000164880000000','0.072144500000000','0.068108704036645','413.08044660750073','413.080446607500733','test'),('2018-11-29 11:59:59','2018-12-03 03:59:59','TNTETH','4h','0.000140630000000','0.000140730000000','0.072144500000000','0.072195800931522','513.0093152243476','513.009315224347574','test'),('2018-12-05 11:59:59','2018-12-05 15:59:59','TNTETH','4h','0.000149880000000','0.000147940000000','0.072144500000000','0.071210684080598','481.34841206298375','481.348412062983755','test'),('2018-12-12 23:59:59','2018-12-15 03:59:59','TNTETH','4h','0.000149890000000','0.000136600000000','0.072144500000000','0.065747806391354','481.3162986189873','481.316298618987275','test'),('2018-12-15 07:59:59','2018-12-15 11:59:59','TNTETH','4h','0.000142930000000','0.000141000000000','0.072144500000000','0.071170324634436','504.75407542153505','504.754075421535049','test'),('2018-12-15 15:59:59','2018-12-15 23:59:59','TNTETH','4h','0.000146560000000','0.000142970000000','0.072144500000000','0.070377314171670','492.25231986899564','492.252319868995642','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','TNTETH','4h','0.000146940000000','0.000138000000000','0.072144500000000','0.067755144957125','490.97931128351706','490.979311283517063','test'),('2019-01-09 23:59:59','2019-01-10 19:59:59','TNTETH','4h','0.000089140000000','0.000089450000000','0.072144500000000','0.072395395164909','809.3392416423603','809.339241642360321','test'),('2019-01-11 03:59:59','2019-01-18 11:59:59','TNTETH','4h','0.000090260000000','0.000137040000000','0.072144500000000','0.109535589186794','799.2964768446709','799.296476844670906','test'),('2019-01-21 19:59:59','2019-01-23 03:59:59','TNTETH','4h','0.000149000000000','0.000134820000000','0.072144500000000','0.065278667718121','484.19127516778525','484.191275167785250','test'),('2019-01-24 15:59:59','2019-01-27 03:59:59','TNTETH','4h','0.000137300000000','0.000134470000000','0.072144500000000','0.070657472068463','525.4515659140568','525.451565914056800','test'),('2019-02-02 07:59:59','2019-02-02 11:59:59','TNTETH','4h','0.000133820000000','0.000132530000000','0.072144500000000','0.071449040390076','539.1159766850994','539.115976685099440','test'),('2019-02-02 15:59:59','2019-02-02 19:59:59','TNTETH','4h','0.000132840000000','0.000132260000000','0.072144500000000','0.071829505947004','543.0931948208371','543.093194820837084','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','TNTETH','4h','0.000117000000000','0.000111040000000','0.072144500000000','0.068469446837607','616.6196581196581','616.619658119658084','test'),('2019-02-27 19:59:59','2019-02-28 15:59:59','TNTETH','4h','0.000114630000000','0.000112600000000','0.072144500000000','0.070866882142546','629.3684026869057','629.368402686905711','test'),('2019-03-01 03:59:59','2019-03-02 15:59:59','TNTETH','4h','0.000115480000000','0.000114850000000','0.072144500000000','0.071750916392449','624.735885001732','624.735885001731958','test'),('2019-03-02 23:59:59','2019-03-03 19:59:59','TNTETH','4h','0.000114960000000','0.000114640000000','0.072144500000000','0.071943680236604','627.5617606123869','627.561760612386934','test'),('2019-03-03 23:59:59','2019-03-05 19:59:59','TNTETH','4h','0.000115870000000','0.000118700000000','0.072144500000000','0.073906551739018','622.6331233278675','622.633123327867452','test'),('2019-03-08 07:59:59','2019-03-16 07:59:59','TNTETH','4h','0.000120360000000','0.000138480000000','0.072144500000000','0.083005735792622','599.405948820206','599.405948820206049','test'),('2019-03-20 03:59:59','2019-03-21 07:59:59','TNTETH','4h','0.000141620000000','0.000140670000000','0.072144500000000','0.071660548051123','509.4231040813445','509.423104081344491','test'),('2019-03-26 23:59:59','2019-03-30 03:59:59','TNTETH','4h','0.000150380000000','0.000146790000000','0.072144500000000','0.070422204781221','479.7479718047613','479.747971804761278','test'),('2019-03-30 15:59:59','2019-04-02 07:59:59','TNTETH','4h','0.000155130000000','0.000151290000000','0.072144500000000','0.070358675981435','465.05833816798815','465.058338167988154','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:20:53
