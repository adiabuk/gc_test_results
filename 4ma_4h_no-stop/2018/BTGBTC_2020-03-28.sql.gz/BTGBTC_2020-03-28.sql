-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-16 15:59:59','2018-04-25 11:59:59','BTGBTC','4h','0.006484000000000','0.007921000000000','0.001467500000000','0.001792730953115','0.226326341764343','0.226326341764343','test'),('2018-05-03 15:59:59','2018-05-03 19:59:59','BTGBTC','4h','0.008126000000000','0.007879000000000','0.001548807738279','0.001501729777246','0.19059903252261262','0.190599032522613','test'),('2018-05-06 03:59:59','2018-05-06 07:59:59','BTGBTC','4h','0.008219000000000','0.008142000000000','0.001548807738279','0.001534297676733','0.18844235774169604','0.188442357741696','test'),('2018-05-06 19:59:59','2018-05-06 23:59:59','BTGBTC','4h','0.007948000000000','0.008004000000000','0.001548807738279','0.001559720324256','0.19486760672861095','0.194867606728611','test'),('2018-07-03 03:59:59','2018-07-05 15:59:59','BTGBTC','4h','0.004605000000000','0.004326000000000','0.001548807738279','0.001454971178240','0.33633175641237784','0.336331756412378','test'),('2018-07-05 19:59:59','2018-07-05 23:59:59','BTGBTC','4h','0.004371000000000','0.004342000000000','0.001548807738279','0.001538531960560','0.35433716272683596','0.354337162726836','test'),('2018-07-07 19:59:59','2018-07-09 07:59:59','BTGBTC','4h','0.004492000000000','0.004399000000000','0.001548807738279','0.001516742039334','0.3447924617718165','0.344792461771816','test'),('2018-07-09 15:59:59','2018-07-09 23:59:59','BTGBTC','4h','0.004588000000000','0.004404000000000','0.001548807738279','0.001486693391321','0.337577972597864','0.337577972597864','test'),('2018-07-15 03:59:59','2018-07-17 07:59:59','BTGBTC','4h','0.004468000000000','0.004386000000000','0.001548807738279','0.001520382887218','0.3466445251295882','0.346644525129588','test'),('2018-08-06 23:59:59','2018-08-07 19:59:59','BTGBTC','4h','0.003703000000000','0.003420000000000','0.001548807738279','0.001430440849288','0.41825755827140154','0.418257558271402','test'),('2018-08-07 23:59:59','2018-08-08 03:59:59','BTGBTC','4h','0.003470000000000','0.003451000000000','0.001548807738279','0.001540327234813','0.4463422876884726','0.446342287688473','test'),('2018-08-25 19:59:59','2018-08-26 03:59:59','BTGBTC','4h','0.003000000000000','0.002897000000000','0.001548807738279','0.001495632005931','0.516269246093','0.516269246093000','test'),('2018-08-26 07:59:59','2018-08-26 23:59:59','BTGBTC','4h','0.002927000000000','0.002900000000000','0.001548807738279','0.001534520820297','0.5291451104472156','0.529145110447216','test'),('2018-08-27 07:59:59','2018-08-27 11:59:59','BTGBTC','4h','0.002951000000000','0.002926000000000','0.001548807738279','0.001535686696782','0.5248416598708912','0.524841659870891','test'),('2018-08-27 19:59:59','2018-09-01 03:59:59','BTGBTC','4h','0.003024000000000','0.003033000000000','0.001548807738279','0.001553417285119','0.5121718711240079','0.512171871124008','test'),('2018-09-09 11:59:59','2018-09-11 19:59:59','BTGBTC','4h','0.003047000000000','0.003018000000000','0.001548807738279','0.001534066870406','0.5083057887361339','0.508305788736134','test'),('2018-09-13 11:59:59','2018-09-17 07:59:59','BTGBTC','4h','0.003143000000000','0.003218000000000','0.001548807738279','0.001585766243010','0.49278006308590516','0.492780063085905','test'),('2018-09-17 11:59:59','2018-09-21 11:59:59','BTGBTC','4h','0.003247000000000','0.003317000000000','0.001548807738279','0.001582197495495','0.47699653165352635','0.476996531653526','test'),('2018-09-21 19:59:59','2018-09-30 23:59:59','BTGBTC','4h','0.003352000000000','0.003920000000000','0.001548807738279','0.001811254872928','0.4620548145223747','0.462054814522375','test'),('2018-10-03 23:59:59','2018-10-06 23:59:59','BTGBTC','4h','0.003935000000000','0.004290000000000','0.001548807738279','0.001688534992939','0.3935979004520965','0.393597900452097','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','BTGBTC','4h','0.004120000000000','0.004099000000000','0.001548807738279','0.001540913329904','0.37592420832014556','0.375924208320146','test'),('2018-10-16 19:59:59','2018-10-18 07:59:59','BTGBTC','4h','0.004061000000000','0.004002000000000','0.001548807738279','0.001526305976014','0.38138580110293024','0.381385801102930','test'),('2018-10-19 23:59:59','2018-10-22 07:59:59','BTGBTC','4h','0.004038000000000','0.004027000000000','0.001548807738279','0.001544588598824','0.3835581323127786','0.383558132312779','test'),('2018-10-23 19:59:59','2018-10-26 19:59:59','BTGBTC','4h','0.004145000000000','0.004151000000000','0.001548807738279','0.001551049679517','0.37365687292617605','0.373656872926176','test'),('2018-10-27 23:59:59','2018-10-29 07:59:59','BTGBTC','4h','0.004195000000000','0.004126000000000','0.001548807738279','0.001523332712310','0.36920327491752086','0.369203274917521','test'),('2018-11-01 19:59:59','2018-11-02 15:59:59','BTGBTC','4h','0.004196000000000','0.004297000000000','0.001548807738279','0.001586088382122','0.3691152855765014','0.369115285576501','test'),('2018-11-03 11:59:59','2018-11-08 19:59:59','BTGBTC','4h','0.004274000000000','0.004658000000000','0.001548807738279','0.001687961264601','0.3623789747962096','0.362378974796210','test'),('2018-11-11 07:59:59','2018-11-11 23:59:59','BTGBTC','4h','0.004707000000000','0.004589000000000','0.001572846075767','0.001533416324983','0.3341504303733271','0.334150430373327','test'),('2018-11-15 19:59:59','2018-11-20 07:59:59','BTGBTC','4h','0.004722000000000','0.004464000000000','0.001572846075767','0.001486909123724','0.33308896140766625','0.333088961407666','test'),('2018-11-24 19:59:59','2018-11-24 23:59:59','BTGBTC','4h','0.004893000000000','0.004823000000000','0.001572846075767','0.001550344701293','0.32144820677845903','0.321448206778459','test'),('2018-11-25 03:59:59','2018-11-25 11:59:59','BTGBTC','4h','0.004841000000000','0.004898000000000','0.001572846075767','0.001591365436709','0.3249010691524479','0.324901069152448','test'),('2018-11-25 15:59:59','2018-11-26 07:59:59','BTGBTC','4h','0.005040000000000','0.004827000000000','0.001572846075767','0.001506374604708','0.312072634080754','0.312072634080754','test'),('2018-11-26 11:59:59','2018-11-26 15:59:59','BTGBTC','4h','0.004885000000000','0.004609000000000','0.001572846075767','0.001483981077423','0.32197463168208806','0.321974631682088','test'),('2018-11-27 03:59:59','2018-11-27 07:59:59','BTGBTC','4h','0.004914000000000','0.004799000000000','0.001572846075767','0.001536037508670','0.320074496493081','0.320074496493081','test'),('2018-12-21 03:59:59','2018-12-25 03:59:59','BTGBTC','4h','0.003683000000000','0.003592000000000','0.001572846075767','0.001533984008731','0.42705568171789304','0.427055681717893','test'),('2018-12-26 23:59:59','2018-12-27 07:59:59','BTGBTC','4h','0.003753000000000','0.003644000000000','0.001572846075767','0.001527165227843','0.41909034792619243','0.419090347926192','test'),('2019-02-16 23:59:59','2019-02-17 03:59:59','BTGBTC','4h','0.002820000000000','0.002792000000000','0.001572846075767','0.001557229164376','0.5577468353783688','0.557746835378369','test'),('2019-02-17 23:59:59','2019-02-18 03:59:59','BTGBTC','4h','0.002824000000000','0.003114000000000','0.001572846075767','0.001734363555219','0.5569568256965297','0.556956825696530','test'),('2019-02-18 07:59:59','2019-02-23 07:59:59','BTGBTC','4h','0.003169000000000','0.003116000000000','0.001572846075767','0.001546540982042','0.49632252311991165','0.496322523119912','test'),('2019-02-23 15:59:59','2019-02-28 03:59:59','BTGBTC','4h','0.003238000000000','0.003287000000000','0.001572846075767','0.001596647637754','0.4857461629916615','0.485746162991662','test'),('2019-03-08 07:59:59','2019-03-08 23:59:59','BTGBTC','4h','0.003342000000000','0.003216000000000','0.001572846075767','0.001513546672551','0.4706301842510473','0.470630184251047','test'),('2019-03-09 07:59:59','2019-03-09 19:59:59','BTGBTC','4h','0.003240000000000','0.003222000000000','0.001572846075767','0.001564108042013','0.48544631968117286','0.485446319681173','test'),('2019-03-13 11:59:59','2019-03-14 11:59:59','BTGBTC','4h','0.003257000000000','0.003248000000000','0.001572846075767','0.001568499863092','0.48291251942493096','0.482912519424931','test'),('2019-03-14 15:59:59','2019-03-17 07:59:59','BTGBTC','4h','0.003351000000000','0.003310000000000','0.001572846075767','0.001553602062306','0.4693661819656819','0.469366181965682','test'),('2019-04-05 07:59:59','2019-04-08 11:59:59','BTGBTC','4h','0.003496000000000','0.003478000000000','0.001572846075767','0.001564747898031','0.44989876309124716','0.449898763091247','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:41:02
