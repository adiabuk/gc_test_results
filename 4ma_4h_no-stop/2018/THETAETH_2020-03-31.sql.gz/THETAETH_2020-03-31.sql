-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-23 03:59:59','2018-11-28 15:59:59','THETAETH','4h','0.000447770000000','0.000456330000000','0.072144500000000','0.073523683330728','161.11954798222303','161.119547982223025','test'),('2018-11-30 07:59:59','2018-12-02 19:59:59','THETAETH','4h','0.000519360000000','0.000580170000000','0.072489295832682','0.080976807538600','139.57427570987755','139.574275709877554','test'),('2018-12-04 11:59:59','2018-12-04 19:59:59','THETAETH','4h','0.000629810000000','0.000582710000000','0.074611173759162','0.069031417508775','118.46616242860784','118.466162428607845','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','THETAETH','4h','0.000363560000000','0.000358480000000','0.074611173759162','0.073568636728970','205.22382484091207','205.223824840912073','test'),('2019-01-15 23:59:59','2019-01-28 07:59:59','THETAETH','4h','0.000378740000000','0.000480220000000','0.074611173759162','0.094602571322345','196.99839932186194','196.998399321861939','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','THETAETH','4h','0.000500890000000','0.000494190000000','0.077953449829813','0.076910729644024','155.62987847593783','155.629878475937829','test'),('2019-01-30 07:59:59','2019-01-30 11:59:59','THETAETH','4h','0.000499360000000','0.000493760000000','0.077953449829813','0.077079252218777','156.10671625643423','156.106716256434225','test'),('2019-02-01 15:59:59','2019-02-08 19:59:59','THETAETH','4h','0.000505340000000','0.000602010000000','0.077953449829813','0.092865706914247','154.2594091696937','154.259409169693697','test'),('2019-02-09 23:59:59','2019-02-12 15:59:59','THETAETH','4h','0.000658870000000','0.000686910000000','0.081202284651715','0.084658068131968','123.24477461671461','123.244774616714608','test'),('2019-02-13 23:59:59','2019-02-16 11:59:59','THETAETH','4h','0.000750720000000','0.000703600000000','0.082066230521778','0.076915227774833','109.31669666690378','109.316696666903781','test'),('2019-02-25 15:59:59','2019-03-03 23:59:59','THETAETH','4h','0.000759600000000','0.000999490000000','0.082066230521778','0.107983645002912','108.0387447627409','108.038744762740905','test'),('2019-03-10 03:59:59','2019-03-12 19:59:59','THETAETH','4h','0.001262990000000','0.000976950000000','0.087257833455325','0.067495815797575','69.08830113882551','69.088301138825514','test'),('2019-04-14 15:59:59','2019-04-15 03:59:59','THETAETH','4h','0.000744230000000','0.000708530000000','0.087257833455325','0.083072158792445','117.24578887618748','117.245788876187476','test'),('2019-04-15 07:59:59','2019-04-15 15:59:59','THETAETH','4h','0.000717560000000','0.000708530000000','0.087257833455325','0.086159753523192','121.60353622738866','121.603536227388659','test'),('2019-04-15 19:59:59','2019-04-18 07:59:59','THETAETH','4h','0.000740730000000','0.000731410000000','0.087257833455325','0.086159939475327','117.79978326154605','117.799783261546054','test'),('2019-05-24 15:59:59','2019-05-26 19:59:59','THETAETH','4h','0.000497010000000','0.000469630000000','0.087257833455325','0.082450848726634','175.56554889303035','175.565548893030353','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','THETAETH','4h','0.000493580000000','0.000490790000000','0.087257833455325','0.086764601648241','176.7855939367985','176.785593936798506','test'),('2019-05-29 11:59:59','2019-05-30 19:59:59','THETAETH','4h','0.000577350000000','0.000526170000000','0.087257833455325','0.079522740502621','151.13507136974974','151.135071369749738','test'),('2019-06-02 11:59:59','2019-06-03 07:59:59','THETAETH','4h','0.000530320000000','0.000511100000000','0.087257833455325','0.084095411598689','164.53807786869248','164.538077868692483','test'),('2019-06-03 11:59:59','2019-06-04 03:59:59','THETAETH','4h','0.000511510000000','0.000511790000000','0.087257833455325','0.087305598295441','170.58871469829526','170.588714698295263','test'),('2019-06-05 03:59:59','2019-06-12 11:59:59','THETAETH','4h','0.000526840000000','0.000565010000000','0.087257833455325','0.093579736695378','165.62492114365844','165.624921143658440','test'),('2019-07-07 03:59:59','2019-07-07 19:59:59','THETAETH','4h','0.000421930000000','0.000388810000000','0.087257833455325','0.080408404772746','206.80642157543906','206.806421575439060','test'),('2019-07-11 11:59:59','2019-07-12 03:59:59','THETAETH','4h','0.000424200000000','0.000393520000000','0.087257833455325','0.080946965161102','205.69974883386377','205.699748833863765','test'),('2019-07-12 07:59:59','2019-07-12 11:59:59','THETAETH','4h','0.000397290000000','0.000399570000000','0.087257833455325','0.087758595770707','219.63259446581844','219.632594465818443','test'),('2019-07-12 15:59:59','2019-07-24 15:59:59','THETAETH','4h','0.000407000000000','0.000555670000000','0.087257833455325','0.119131597828306','214.39271119244472','214.392711192444722','test'),('2019-07-25 19:59:59','2019-07-30 19:59:59','THETAETH','4h','0.000591390000000','0.000585670000000','0.087257833455325','0.086413864488375','147.54702219402594','147.547022194025942','test'),('2019-07-31 23:59:59','2019-08-02 11:59:59','THETAETH','4h','0.000642610000000','0.000595670000000','0.087257833455325','0.080884009981689','135.78661000501862','135.786610005018616','test'),('2019-08-12 07:59:59','2019-08-14 03:59:59','THETAETH','4h','0.000598160000000','0.000563980000000','0.087257833455325','0.082271754901923','145.87707880052997','145.877078800529972','test'),('2019-08-15 11:59:59','2019-08-15 23:59:59','THETAETH','4h','0.000579000000000','0.000593530000000','0.087257833455325','0.089447568032365','150.7043755705095','150.704375570509512','test'),('2019-08-16 07:59:59','2019-08-25 19:59:59','THETAETH','4h','0.000588150000000','0.000662840000000','0.087257833455325','0.098338829087015','148.35982904926468','148.359829049264675','test'),('2019-08-27 23:59:59','2019-08-28 15:59:59','THETAETH','4h','0.000708420000000','0.000654500000000','0.087257833455325','0.080616374462198','123.17245907134894','123.172459071348939','test'),('2019-08-28 19:59:59','2019-08-29 03:59:59','THETAETH','4h','0.000684460000000','0.000645870000000','0.087257833455325','0.082338218294408','127.48419696596588','127.484196965965879','test'),('2019-08-29 19:59:59','2019-08-30 11:59:59','THETAETH','4h','0.000679520000000','0.000646440000000','0.087257833455325','0.083009998026343','128.41098636585386','128.410986365853859','test'),('2019-08-31 03:59:59','2019-08-31 23:59:59','THETAETH','4h','0.000674330000000','0.000657950000000','0.087257833455325','0.085138272836639','129.3993051700577','129.399305170057687','test'),('2019-10-06 23:59:59','2019-10-07 03:59:59','THETAETH','4h','0.000493740000000','0.000477650000000','0.087257833455325','0.084414275023162','176.72830529291733','176.728305292917327','test'),('2019-10-08 23:59:59','2019-10-09 15:59:59','THETAETH','4h','0.000501890000000','0.000460740000000','0.087257833455325','0.080103556927228','173.85848184925982','173.858481849259817','test'),('2019-10-15 07:59:59','2019-10-16 11:59:59','THETAETH','4h','0.000503140000000','0.000477830000000','0.087257833455325','0.082868407520686','173.4265481880292','173.426548188029187','test'),('2019-10-16 19:59:59','2019-10-17 03:59:59','THETAETH','4h','0.000485140000000','0.000480660000000','0.087257833455325','0.086452055548164','179.8611399911881','179.861139991188111','test'),('2019-10-17 11:59:59','2019-10-18 07:59:59','THETAETH','4h','0.000482690000000','0.000477630000000','0.087257833455325','0.086343116686210','180.77406504241856','180.774065042418556','test'),('2019-10-20 03:59:59','2019-10-20 19:59:59','THETAETH','4h','0.000488220000000','0.000483680000000','0.087257833455325','0.086446415316193','178.72646236394456','178.726462363944563','test'),('2019-10-20 23:59:59','2019-10-21 11:59:59','THETAETH','4h','0.000489540000000','0.000484400000000','0.087257833455325','0.086341656505616','178.24454274487275','178.244542744872746','test'),('2019-10-21 15:59:59','2019-10-25 23:59:59','THETAETH','4h','0.000492670000000','0.000537650000000','0.087257833455325','0.095224337096343','177.112130747407','177.112130747407008','test'),('2019-10-29 03:59:59','2019-10-29 23:59:59','THETAETH','4h','0.000566710000000','0.000530450000000','0.087257833455325','0.081674785615883','153.97263760181576','153.972637601815762','test'),('2019-10-30 03:59:59','2019-10-30 07:59:59','THETAETH','4h','0.000531360000000','0.000512000000000','0.087257833455325','0.084078610977730','164.2160370658781','164.216037065878112','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  4:07:30
