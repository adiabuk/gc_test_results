-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-03 15:59:59','ETCBNB','4h','0.893000000000000','0.866400000000000','0.711908500000000','0.690702714893617','0.7972099664053752','0.797209966405375','test'),('2019-03-21 03:59:59','2019-03-24 11:59:59','ETCBNB','4h','0.306900000000000','0.280000000000000','0.711908500000000','0.649509221244705','2.3196757901596614','2.319675790159661','test'),('2019-04-05 19:59:59','2019-04-11 07:59:59','ETCBNB','4h','0.294500000000000','0.371300000000000','0.711908500000000','0.897560699660442','2.4173463497453316','2.417346349745332','test'),('2019-05-01 11:59:59','2019-05-02 11:59:59','ETCBNB','4h','0.271800000000000','0.254100000000000','0.737420283949691','0.689398433228905','2.713098910778849','2.713098910778849','test'),('2019-05-07 11:59:59','2019-05-11 19:59:59','ETCBNB','4h','0.261800000000000','0.292200000000000','0.737420283949691','0.823048918907944','2.816731413100424','2.816731413100424','test'),('2019-05-12 07:59:59','2019-05-12 15:59:59','ETCBNB','4h','0.289100000000000','0.285300000000000','0.746821980009058','0.737005572108558','2.5832652369735656','2.583265236973566','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','ETCBNB','4h','0.287800000000000','0.280100000000000','0.746821980009058','0.726840988883034','2.594933912470667','2.594933912470667','test'),('2019-05-16 03:59:59','2019-05-16 11:59:59','ETCBNB','4h','0.299300000000000','0.296400000000000','0.746821980009058','0.739585816487420','2.4952288005648446','2.495228800564845','test'),('2019-05-16 15:59:59','2019-05-17 11:59:59','ETCBNB','4h','0.306000000000000','0.281000000000000','0.746821980009058','0.685807112361259','2.440594705911954','2.440594705911954','test'),('2019-05-17 15:59:59','2019-05-17 19:59:59','ETCBNB','4h','0.287400000000000','0.280300000000000','0.746821980009058','0.728372306877310','2.598545511513772','2.598545511513772','test'),('2019-05-29 15:59:59','2019-05-30 03:59:59','ETCBNB','4h','0.248800000000000','0.245400000000000','0.746821980009058','0.736616213401217','3.001696061129654','3.001696061129654','test'),('2019-05-30 07:59:59','2019-06-04 19:59:59','ETCBNB','4h','0.253700000000000','0.264500000000000','0.746821980009058','0.778614165204556','2.9437208514349944','2.943720851434994','test'),('2019-06-09 23:59:59','2019-06-10 07:59:59','ETCBNB','4h','0.269200000000000','0.262400000000000','0.746821980009058','0.727957234600211','2.774227266006902','2.774227266006902','test'),('2019-06-16 07:59:59','2019-06-17 07:59:59','ETCBNB','4h','0.265300000000000','0.258700000000000','0.746821980009058','0.728242918312640','2.8150093479421714','2.815009347942171','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','ETCBNB','4h','0.262900000000000','0.256200000000000','0.746821980009058','0.727789240313125','2.8407074173033773','2.840707417303377','test'),('2019-06-25 15:59:59','2019-06-27 07:59:59','ETCBNB','4h','0.251900000000000','0.236800000000000','0.746821980009058','0.702054167789380','2.964755776137586','2.964755776137586','test'),('2019-07-09 19:59:59','2019-07-10 15:59:59','ETCBNB','4h','0.241800000000000','0.232700000000000','0.746821980009058','0.718715776460330','3.0885937965635155','3.088593796563516','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','ETCBNB','4h','0.208300000000000','0.209800000000000','0.746821980009058','0.752199958741720','3.5853191551082952','3.585319155108295','test'),('2019-07-26 07:59:59','2019-07-28 23:59:59','ETCBNB','4h','0.212100000000000','0.212400000000000','0.746821980009058','0.747878305299028','3.521084299901263','3.521084299901263','test'),('2019-07-29 03:59:59','2019-07-31 11:59:59','ETCBNB','4h','0.216000000000000','0.214100000000000','0.746821980009058','0.740252712592312','3.457509166708602','3.457509166708602','test'),('2019-08-04 15:59:59','2019-08-06 15:59:59','ETCBNB','4h','0.221500000000000','0.215800000000000','0.746821980009058','0.727603536279705','3.3716567946232865','3.371656794623286','test'),('2019-08-15 01:59:59','2019-08-15 15:59:59','ETCBNB','4h','0.210700000000000','0.202800000000000','0.746821980009058','0.718820586358979','3.544480208870707','3.544480208870707','test'),('2019-08-16 03:59:59','2019-08-16 07:59:59','ETCBNB','4h','0.201500000000000','0.205100000000000','0.746821980009058','0.760164705210212','3.706312555876218','3.706312555876218','test'),('2019-08-20 15:59:59','2019-08-28 11:59:59','ETCBNB','4h','0.215400000000000','0.270000000000000','0.746821980009058','0.936127830094920','3.4671401114626645','3.467140111462665','test'),('2019-08-29 03:59:59','2019-08-29 15:59:59','ETCBNB','4h','0.286300000000000','0.272200000000000','0.746821980009058','0.710041714839209','2.608529444670129','2.608529444670129','test'),('2019-08-30 19:59:59','2019-09-06 11:59:59','ETCBNB','4h','0.289600000000000','0.304200000000000','0.746821980009058','0.784472535631062','2.5788051795892883','2.578805179589288','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','ETCBNB','4h','0.313200000000000','0.303000000000000','0.746821980009058','0.722500191388073','2.384489080488691','2.384489080488691','test'),('2019-09-11 07:59:59','2019-09-11 15:59:59','ETCBNB','4h','0.303000000000000','0.297300000000000','0.746821980009058','0.732772853652452','2.4647590099308845','2.464759009930884','test'),('2019-09-11 19:59:59','2019-09-12 15:59:59','ETCBNB','4h','0.300700000000000','0.303700000000000','0.746821980009058','0.754272814528603','2.4836115065149915','2.483611506514992','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','ETCBNB','4h','0.304900000000000','0.297900000000000','0.746821980009058','0.729676181845518','2.449399737648599','2.449399737648599','test'),('2019-09-15 11:59:59','2019-09-17 07:59:59','ETCBNB','4h','0.303500000000000','0.305600000000000','0.746821980009058','0.751989446757061','2.4606984514301744','2.460698451430174','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','ETCBNB','4h','0.302300000000000','0.297800000000000','0.746821980009058','0.735704881398272','2.470466357952557','2.470466357952557','test'),('2019-09-25 15:59:59','2019-09-26 03:59:59','ETCBNB','4h','0.310100000000000','0.296800000000000','0.746821980009058','0.714791240460137','2.408326281873776','2.408326281873776','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','ETCBNB','4h','0.301000000000000','0.295100000000000','0.746821980009058','0.732183276746422','2.481136146209495','2.481136146209495','test'),('2019-09-26 15:59:59','2019-09-27 23:59:59','ETCBNB','4h','0.307400000000000','0.298900000000000','0.746821980009058','0.726171404764826','2.429479440497911','2.429479440497911','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','ETCBNB','4h','0.301400000000000','0.300100000000000','0.746821980009058','0.743600783678561','2.4778433311514863','2.477843331151486','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ETCBNB','4h','0.303100000000000','0.295100000000000','0.746821980009058','0.727110413397140','2.4639458264897987','2.463945826489799','test'),('2019-10-07 03:59:59','2019-10-07 11:59:59','ETCBNB','4h','0.298400000000000','0.294600000000000','0.746821980009058','0.737311512435216','2.5027546246952346','2.502754624695235','test'),('2019-11-07 03:59:59','2019-11-10 03:59:59','ETCBNB','4h','0.248000000000000','0.248200000000000','0.746821980009058','0.747424255799388','3.0113789516494274','3.011378951649427','test'),('2019-11-20 19:59:59','2019-11-24 07:59:59','ETCBNB','4h','0.239100000000000','0.243300000000000','0.746821980009058','0.759940559331676','3.1234712672900793','3.123471267290079','test'),('2019-11-24 15:59:59','2019-11-27 23:59:59','ETCBNB','4h','0.250600000000000','0.246000000000000','0.746821980009058','0.733113356273856','2.98013559460917','2.980135594609170','test'),('2019-11-28 19:59:59','2019-12-02 07:59:59','ETCBNB','4h','0.252300000000000','0.252700000000000','0.746821980009058','0.748006002173163','2.960055410261823','2.960055410261823','test'),('2019-12-02 11:59:59','2019-12-02 15:59:59','ETCBNB','4h','0.252900000000000','0.251600000000000','0.746821980009058','0.742983037446734','2.9530327402493395','2.953032740249339','test'),('2019-12-02 23:59:59','2019-12-03 15:59:59','ETCBNB','4h','0.254800000000000','0.252200000000000','0.746821980009058','0.739201347559986','2.931012480412315','2.931012480412315','test'),('2019-12-10 15:59:59','2019-12-23 23:59:59','ETCBNB','4h','0.256500000000000','0.300200000000000','0.746821980009058','0.874058317343935','2.9115866667019805','2.911586666701981','test'),('2019-12-25 11:59:59','2019-12-29 03:59:59','ETCBNB','4h','0.305600000000000','0.325500000000000','0.746821980009058','0.795453385120904','2.4437892016003206','2.443789201600321','test'),('2019-12-29 11:59:59','2019-12-30 03:59:59','ETCBNB','4h','0.342100000000000','0.321600000000000','0.746821980009058','0.702069420552216','2.1830516808215665','2.183051680821567','test'),('2019-12-30 19:59:59','2020-01-01 03:59:59','ETCBNB','4h','0.331500000000000','0.327400000000000','0.746821980009058','0.737585267737453','2.2528566516110344','2.252856651611034','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:34:22
