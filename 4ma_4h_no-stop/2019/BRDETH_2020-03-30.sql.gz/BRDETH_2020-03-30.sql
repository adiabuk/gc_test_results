-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-15 03:59:59','BRDETH','4h','0.001538000000000','0.001506600000000','0.072144500000000','0.070671588881664','46.90799739921977','46.907997399219767','test'),('2019-01-15 23:59:59','2019-01-20 23:59:59','BRDETH','4h','0.001595100000000','0.001674600000000','0.072144500000000','0.075740191649426','45.22882577894803','45.228825778948028','test'),('2019-01-21 19:59:59','2019-01-24 03:59:59','BRDETH','4h','0.001715400000000','0.001709400000000','0.072675195132772','0.072420997178478','42.3663257157354','42.366325715735400','test'),('2019-01-24 07:59:59','2019-01-30 23:59:59','BRDETH','4h','0.001741300000000','0.001857400000000','0.072675195132772','0.077520764623908','41.7361713276127','41.736171327612702','test'),('2019-02-27 15:59:59','2019-03-01 15:59:59','BRDETH','4h','0.001687700000000','0.001601800000000','0.073823038016983','0.070065617287198','43.74180127806068','43.741801278060677','test'),('2019-03-02 15:59:59','2019-03-03 03:59:59','BRDETH','4h','0.001646300000000','0.001607900000000','0.073823038016983','0.072101113301043','44.84178947760615','44.841789477606149','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','BRDETH','4h','0.001651800000000','0.001649100000000','0.073823038016983','0.073702368321714','44.69247972937584','44.692479729375840','test'),('2019-03-04 19:59:59','2019-03-05 15:59:59','BRDETH','4h','0.001645100000000','0.001645700000000','0.073823038016983','0.073849962716278','44.87449882498511','44.874498824985110','test'),('2019-03-08 23:59:59','2019-03-09 03:59:59','BRDETH','4h','0.001648600000000','0.001764200000000','0.073823038016983','0.078999516965644','44.77922965970096','44.779229659700960','test'),('2019-03-09 19:59:59','2019-03-11 15:59:59','BRDETH','4h','0.001697700000000','0.001671800000000','0.073823038016983','0.072696798584433','43.48414797489722','43.484147974897219','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','BRDETH','4h','0.001715400000000','0.002512400000000','0.073823038016983','0.108122304251993','43.03546579047628','43.035465790476280','test'),('2019-03-12 11:59:59','2019-03-17 07:59:59','BRDETH','4h','0.001750300000000','0.001871400000000','0.082017141844338','0.087691755269093','46.85890524158058','46.858905241580580','test'),('2019-03-17 11:59:59','2019-03-18 03:59:59','BRDETH','4h','0.001881300000000','0.001856300000000','0.083435795200527','0.082327043337447','44.35007452321652','44.350074523216520','test'),('2019-03-22 07:59:59','2019-03-23 15:59:59','BRDETH','4h','0.001859600000000','0.001859100000000','0.083435795200527','0.083413361398849','44.86760335584373','44.867603355843727','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','BRDETH','4h','0.001890500000000','0.001866600000000','0.083435795200527','0.082380986681462','44.134247659628144','44.134247659628144','test'),('2019-03-24 15:59:59','2019-03-24 23:59:59','BRDETH','4h','0.001876900000000','0.001855800000000','0.083435795200527','0.082497814871937','44.4540440090186','44.454044009018602','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','BRDETH','4h','0.001963400000000','0.001856000000000','0.083435795200527','0.078871771362014','42.49556646660232','42.495566466602320','test'),('2019-03-26 07:59:59','2019-03-26 11:59:59','BRDETH','4h','0.001864700000000','0.001899800000000','0.083435795200527','0.085006340817269','44.74488936586422','44.744889365864218','test'),('2019-03-26 15:59:59','2019-03-30 03:59:59','BRDETH','4h','0.001925200000000','0.002002700000000','0.083435795200527','0.086794549682161','43.33876750494858','43.338767504948578','test'),('2019-03-31 19:59:59','2019-04-01 15:59:59','BRDETH','4h','0.002108800000000','0.002044900000000','0.083435795200527','0.080907557665761','39.56553262543959','39.565532625439587','test'),('2019-04-01 19:59:59','2019-04-02 07:59:59','BRDETH','4h','0.002070100000000','0.002068900000000','0.083435795200527','0.083387428960133','40.30520032874112','40.305200328741122','test'),('2019-04-05 15:59:59','2019-04-06 15:59:59','BRDETH','4h','0.002042200000000','0.001990200000000','0.083435795200527','0.081311291552291','40.855839389152386','40.855839389152386','test'),('2019-04-06 19:59:59','2019-04-06 23:59:59','BRDETH','4h','0.001993500000000','0.002039100000000','0.083435795200527','0.085344334082465','41.85392284952446','41.853922849524459','test'),('2019-04-07 07:59:59','2019-04-07 23:59:59','BRDETH','4h','0.002026600000000','0.001958200000000','0.083435795200527','0.080619744479262','41.17033218223972','41.170332182239719','test'),('2019-04-20 19:59:59','2019-04-21 03:59:59','BRDETH','4h','0.001913500000000','0.001866100000000','0.083435795200527','0.081368976965615','43.60376023022054','43.603760230220537','test'),('2019-04-21 07:59:59','2019-04-21 11:59:59','BRDETH','4h','0.001868800000000','0.001879700000000','0.083435795200527','0.083922444476900','44.64672260302172','44.646722603021722','test'),('2019-04-21 15:59:59','2019-04-21 23:59:59','BRDETH','4h','0.001885400000000','0.001882500000000','0.083435795200527','0.083307459671684','44.25363063568845','44.253630635688452','test'),('2019-04-22 15:59:59','2019-04-22 19:59:59','BRDETH','4h','0.001915400000000','0.001873300000000','0.083435795200527','0.081601897853789','43.5605070484113','43.560507048411303','test'),('2019-04-28 19:59:59','2019-05-03 23:59:59','BRDETH','4h','0.001878600000000','0.002070500000000','0.083435795200527','0.091958806538215','44.41381624642127','44.413816246421270','test'),('2019-05-04 03:59:59','2019-05-06 23:59:59','BRDETH','4h','0.002165000000000','0.002181900000000','0.083435795200527','0.084087095403247','38.53847353373072','38.538473533730723','test'),('2019-05-08 19:59:59','2019-05-10 07:59:59','BRDETH','4h','0.002267900000000','0.002285000000000','0.083435795200527','0.084064902347195','36.78989161802857','36.789891618028570','test'),('2019-05-10 11:59:59','2019-05-11 11:59:59','BRDETH','4h','0.002315600000000','0.002248200000000','0.083435795200527','0.081007235606247','36.032041458165054','36.032041458165054','test'),('2019-05-11 15:59:59','2019-05-11 19:59:59','BRDETH','4h','0.002309100000000','0.002240300000000','0.083435795200527','0.080949812475744','36.133469836961154','36.133469836961154','test'),('2019-05-11 23:59:59','2019-05-14 03:59:59','BRDETH','4h','0.002388800000000','0.002265100000000','0.083435795200527','0.079115212537137','34.92791158762852','34.927911587628522','test'),('2019-06-09 19:59:59','2019-06-11 15:59:59','BRDETH','4h','0.001860500000000','0.001804600000000','0.083435795200527','0.080928909443091','44.845899059675894','44.845899059675894','test'),('2019-06-11 19:59:59','2019-06-11 23:59:59','BRDETH','4h','0.001816700000000','0.001782900000000','0.083435795200527','0.081883458613431','45.927117961428415','45.927117961428415','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','BRDETH','4h','0.002000700000000','0.001774500000000','0.083435795200527','0.074002508413723','41.70330144475784','41.703301444757841','test'),('2019-06-13 23:59:59','2019-06-14 03:59:59','BRDETH','4h','0.001807500000000','0.001775700000000','0.083435795200527','0.081967879135588','46.160882545243155','46.160882545243155','test'),('2019-07-12 07:59:59','2019-07-12 11:59:59','BRDETH','4h','0.001255300000000','0.001264300000000','0.083435795200527','0.084033996552240','66.46681685694814','66.466816856948142','test'),('2019-07-12 15:59:59','2019-07-13 19:59:59','BRDETH','4h','0.001271600000000','0.001244200000000','0.083435795200527','0.081637949346096','65.61481220551039','65.614812205510390','test'),('2019-07-14 11:59:59','2019-07-17 03:59:59','BRDETH','4h','0.001288700000000','0.001281000000000','0.083435795200527','0.082937265191181','64.74415705790875','64.744157057908751','test'),('2019-07-18 07:59:59','2019-07-19 11:59:59','BRDETH','4h','0.001330900000000','0.001276700000000','0.083435795200527','0.080037929019846','62.69125794614697','62.691257946146969','test'),('2019-07-31 03:59:59','2019-07-31 15:59:59','BRDETH','4h','0.001270000000000','0.001210500000000','0.083435795200527','0.079526795346644','65.69747653584803','65.697476535848025','test'),('2019-07-31 19:59:59','2019-07-31 23:59:59','BRDETH','4h','0.001231000000000','0.001225100000000','0.083435795200527','0.083035899837665','67.77887506135419','67.778875061354185','test'),('2019-08-01 03:59:59','2019-08-02 15:59:59','BRDETH','4h','0.001243000000000','0.001225900000000','0.083435795200527','0.082287965676851','67.12453354829204','67.124533548292035','test'),('2019-08-12 11:59:59','2019-08-22 15:59:59','BRDETH','4h','0.001256300000000','0.001597200000000','0.083435795200527','0.106076297137851','66.41391005375071','66.413910053750712','test'),('2019-08-26 19:59:59','2019-08-27 15:59:59','BRDETH','4h','0.001644800000000','0.001562000000000','0.083435795200527','0.079235598311785','50.72701556452274','50.727015564522738','test'),('2019-09-05 19:59:59','2019-09-07 19:59:59','BRDETH','4h','0.001550600000000','0.001662300000000','0.083435795200527','0.089446228790040','53.808716110232815','53.808716110232815','test'),('2019-09-08 11:59:59','2019-09-09 07:59:59','BRDETH','4h','0.001607900000000','0.001511100000000','0.083435795200527','0.078412730970531','51.891159400787984','51.891159400787984','test'),('2019-09-26 23:59:59','2019-10-01 03:59:59','BRDETH','4h','0.001152200000000','0.001146200000000','0.083435795200527','0.083001309198788','72.41433362309236','72.414333623092361','test'),('2019-10-01 07:59:59','2019-10-19 19:59:59','BRDETH','4h','0.001164800000000','0.001760300000000','0.083435795200527','0.126092058972774','71.63100549495795','71.631005494957947','test'),('2019-10-20 03:59:59','2019-10-24 07:59:59','BRDETH','4h','0.001824200000000','0.001943800000000','0.089634504176626','0.095511209965204','49.136336024901986','49.136336024901986','test'),('2019-10-24 23:59:59','2019-10-25 11:59:59','BRDETH','4h','0.001994900000000','0.001943800000000','0.091103680623771','0.088770030776724','45.6682944627654','45.668294462765402','test'),('2019-11-02 19:59:59','2019-11-05 07:59:59','BRDETH','4h','0.001907100000000','0.001932500000000','0.091103680623771','0.092317058783198','47.77079367823974','47.770793678239741','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','BRDETH','4h','0.001761800000000','0.001740800000000','0.091103680623771','0.090017758672869','51.71056909057271','51.710569090572712','test'),('2019-11-30 19:59:59','2019-12-02 07:59:59','BRDETH','4h','0.001766400000000','0.001733900000000','0.091103680623771','0.089427463673888','51.575906150232676','51.575906150232676','test'),('2019-12-02 15:59:59','2019-12-03 03:59:59','BRDETH','4h','0.002308700000000','0.001808400000000','0.091103680623771','0.071361327171147','39.46103028707541','39.461030287075410','test'),('2019-12-03 15:59:59','2019-12-03 23:59:59','BRDETH','4h','0.001800000000000','0.001799700000000','0.091103680623771','0.091088496677000','50.613155902095','50.613155902095002','test'),('2019-12-12 23:59:59','2019-12-13 07:59:59','BRDETH','4h','0.001758900000000','0.001732900000000','0.091103680623771','0.089756989114181','51.79582729192734','51.795827291927338','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','BRDETH','4h','0.001740300000000','0.001969200000000','0.091103680623771','0.103086460888542','52.3494113795156','52.349411379515601','test'),('2019-12-14 03:59:59','2019-12-15 07:59:59','BRDETH','4h','0.001859200000000','0.001747500000000','0.091103680623771','0.085630207557035','49.001549388861335','49.001549388861335','test'),('2019-12-17 11:59:59','2019-12-18 23:59:59','BRDETH','4h','0.001804500000000','0.001801000000000','0.091103680623771','0.090926976338826','50.48693855570574','50.486938555705741','test'),('2019-12-19 03:59:59','2019-12-24 11:59:59','BRDETH','4h','0.001858100000000','0.001967000000000','0.091103680623771','0.096443108437090','49.030558432684465','49.030558432684465','test'),('2019-12-27 19:59:59','2019-12-29 19:59:59','BRDETH','4h','0.002023800000000','0.001922600000000','0.091103680623771','0.086548046431101','45.01614814891343','45.016148148913430','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  2:50:41
