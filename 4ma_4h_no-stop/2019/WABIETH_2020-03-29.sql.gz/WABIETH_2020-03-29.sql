-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-14 15:59:59','WABIETH','4h','0.000895560000000','0.000882180000000','0.072144500000000','0.071066634295860','80.5579748983876','80.557974898387599','test'),('2019-01-14 19:59:59','2019-01-20 23:59:59','WABIETH','4h','0.000891810000000','0.001111700000000','0.072144500000000','0.089932878808266','80.89671566813558','80.896715668135585','test'),('2019-01-23 03:59:59','2019-01-24 23:59:59','WABIETH','4h','0.001223780000000','0.001139700000000','0.076322128276032','0.071078404285242','62.3658895193838','62.365889519383799','test'),('2019-02-07 15:59:59','2019-02-08 11:59:59','WABIETH','4h','0.001113880000000','0.001079350000000','0.076322128276032','0.073956161484841','68.51916568753546','68.519165687535462','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','WABIETH','4h','0.001156610000000','0.001124600000000','0.076322128276032','0.074209859381490','65.98778177262172','65.987781772621716','test'),('2019-02-08 23:59:59','2019-02-09 19:59:59','WABIETH','4h','0.001128740000000','0.001097380000000','0.076322128276032','0.074201655941627','67.61710250016124','67.617102500161238','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','WABIETH','4h','0.001108850000000','0.001116150000000','0.076322128276032','0.076824587162640','68.82998446681879','68.829984466818786','test'),('2019-02-10 11:59:59','2019-02-11 03:59:59','WABIETH','4h','0.001125100000000','0.001127840000000','0.076322128276032','0.076507998537765','67.83586194652209','67.835861946522087','test'),('2019-02-11 07:59:59','2019-02-12 11:59:59','WABIETH','4h','0.001144490000000','0.001112500000000','0.076322128276032','0.074188824460752','66.68658378494527','66.686583784945270','test'),('2019-02-26 15:59:59','2019-03-06 15:59:59','WABIETH','4h','0.001131270000000','0.001346220000000','0.076322128276032','0.090823919601651','67.46588195217058','67.465881952170577','test'),('2019-03-06 19:59:59','2019-03-11 07:59:59','WABIETH','4h','0.001369270000000','0.001520770000000','0.076625724437969','0.085103816598282','55.961004358504525','55.961004358504525','test'),('2019-03-12 23:59:59','2019-03-14 07:59:59','WABIETH','4h','0.001692520000000','0.001568530000000','0.078745247478048','0.072976557456776','46.52544577201318','46.525445772013178','test'),('2019-03-15 03:59:59','2019-03-16 07:59:59','WABIETH','4h','0.001649040000000','0.001546500000000','0.078745247478048','0.073848739402805','47.75217549486246','47.752175494862463','test'),('2019-03-19 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001636680000000','0.001668870000000','0.078745247478048','0.080293998312859','48.11279387421365','48.112793874213651','test'),('2019-03-21 19:59:59','2019-03-23 23:59:59','WABIETH','4h','0.001672880000000','0.001677590000000','0.078745247478048','0.078966955021698','47.07166531852135','47.071665318521347','test'),('2019-03-27 15:59:59','2019-04-01 07:59:59','WABIETH','4h','0.001723340000000','0.002343230000000','0.078745247478048','0.107070123276885','45.69339043836271','45.693390438362712','test'),('2019-04-13 15:59:59','2019-04-17 03:59:59','WABIETH','4h','0.002550000000000','0.002422480000000','0.083602781498243','0.079421986715241','32.78540450911509','32.785404509115089','test'),('2019-04-26 03:59:59','2019-04-26 15:59:59','WABIETH','4h','0.002269550000000','0.002108710000000','0.083602781498243','0.077677963196739','36.83672159601816','36.836721596018158','test'),('2019-04-28 15:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002321640000000','0.002188890000000','0.083602781498243','0.078822423973437','36.01022617556684','36.010226175566842','test'),('2019-04-29 19:59:59','2019-04-29 23:59:59','WABIETH','4h','0.002208760000000','0.002191000000000','0.083602781498243','0.082930555724773','37.85055030797506','37.850550307975062','test'),('2019-06-08 03:59:59','2019-06-12 11:59:59','WABIETH','4h','0.001291660000000','0.001305090000000','0.083602781498243','0.084472039163202','64.72506812802364','64.725068128023636','test'),('2019-06-12 15:59:59','2019-06-12 23:59:59','WABIETH','4h','0.001339910000000','0.001298050000000','0.083602781498243','0.080990955007272','62.39432611014397','62.394326110143972','test'),('2019-07-21 15:59:59','2019-07-26 15:59:59','WABIETH','4h','0.000664200000000','0.000708000000000','0.083602781498243','0.089115882717188','125.86989084348541','125.869890843485408','test'),('2019-07-28 15:59:59','2019-07-29 07:59:59','WABIETH','4h','0.000719110000000','0.000702460000000','0.083602781498243','0.081667074427078','116.25868295287647','116.258682952876470','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','WABIETH','4h','0.000571340000000','0.000552050000000','0.083602781498243','0.080780123089763','146.327548391926','146.327548391926001','test'),('2019-08-17 23:59:59','2019-08-18 11:59:59','WABIETH','4h','0.000581400000000','0.000562110000000','0.083602781498243','0.080828963722011','143.79563381190746','143.795633811907464','test'),('2019-08-23 03:59:59','2019-08-23 15:59:59','WABIETH','4h','0.000576780000000','0.000560180000000','0.083602781498243','0.081196654079000','144.94743489414162','144.947434894141622','test'),('2019-08-23 19:59:59','2019-08-26 11:59:59','WABIETH','4h','0.000574690000000','0.000643740000000','0.083602781498243','0.093647800660667','145.47457150506014','145.474571505060140','test'),('2019-08-26 15:59:59','2019-08-26 23:59:59','WABIETH','4h','0.000693010000000','0.000634530000000','0.083602781498243','0.076547918419763','120.63719354445536','120.637193544455357','test'),('2019-08-27 11:59:59','2019-08-28 15:59:59','WABIETH','4h','0.000734350000000','0.000652540000000','0.083602781498243','0.074289043424612','113.84596105160074','113.845961051600739','test'),('2019-08-29 15:59:59','2019-09-06 03:59:59','WABIETH','4h','0.000731650000000','0.000938110000000','0.083602781498243','0.107194157522472','114.26608555763411','114.266085557634113','test'),('2019-09-07 03:59:59','2019-09-07 19:59:59','WABIETH','4h','0.001109470000000','0.000950410000000','0.083602781498243','0.071617005925122','75.35380091236627','75.353800912366268','test'),('2019-09-09 03:59:59','2019-09-10 19:59:59','WABIETH','4h','0.001037170000000','0.000958300000000','0.083602781498243','0.077245336357363','80.60663295143804','80.606632951438044','test'),('2019-09-29 07:59:59','2019-09-30 19:59:59','WABIETH','4h','0.000749980000000','0.000682330000000','0.083602781498243','0.076061609509182','111.47334795360277','111.473347953602769','test'),('2019-10-01 11:59:59','2019-10-02 19:59:59','WABIETH','4h','0.000713490000000','0.000693950000000','0.083602781498243','0.081313193206220','117.17442640855934','117.174426408559341','test'),('2019-10-04 19:59:59','2019-10-06 11:59:59','WABIETH','4h','0.000737060000000','0.000717200000000','0.083602781498243','0.081350113817789','113.42737565224405','113.427375652244052','test'),('2019-10-06 15:59:59','2019-10-08 11:59:59','WABIETH','4h','0.000736930000000','0.000728620000000','0.083602781498243','0.082660033728101','113.44738509525057','113.447385095250567','test'),('2019-10-09 07:59:59','2019-10-09 15:59:59','WABIETH','4h','0.000755190000000','0.000667960000000','0.083602781498243','0.073946045272801','110.70430156416664','110.704301564166641','test'),('2019-10-15 11:59:59','2019-10-15 19:59:59','WABIETH','4h','0.000713040000000','0.000705990000000','0.083602781498243','0.082776180452632','117.24837526400063','117.248375264000629','test'),('2019-10-16 03:59:59','2019-10-16 07:59:59','WABIETH','4h','0.000691330000000','0.000686910000000','0.083602781498243','0.083068269334411','120.93035380822907','120.930353808229071','test'),('2019-10-20 11:59:59','2019-10-23 15:59:59','WABIETH','4h','0.000700070000000','0.000744490000000','0.083602781498243','0.088907444680713','119.42060293719628','119.420602937196279','test'),('2019-10-23 23:59:59','2019-10-24 03:59:59','WABIETH','4h','0.000749300000000','0.000750510000000','0.083602781498243','0.083737786657209','111.57451154176297','111.574511541762973','test'),('2019-10-24 11:59:59','2019-10-25 19:59:59','WABIETH','4h','0.000821790000000','0.000753170000000','0.083602781498243','0.076621894816232','101.7325368990168','101.732536899016793','test'),('2019-10-28 03:59:59','2019-11-02 19:59:59','WABIETH','4h','0.000861050000000','0.000930490000000','0.083602781498243','0.090344988277452','97.09399163607573','97.093991636075728','test'),('2019-11-07 03:59:59','2019-11-07 07:59:59','WABIETH','4h','0.000948470000000','0.000932650000000','0.083602781498243','0.082208329377140','88.14488755389523','88.144887553895231','test'),('2019-11-11 07:59:59','2019-11-15 19:59:59','WABIETH','4h','0.001036930000000','0.001078160000000','0.083602781498243','0.086926962186595','80.62528955497768','80.625289554977684','test'),('2019-11-18 03:59:59','2019-11-18 15:59:59','WABIETH','4h','0.001124180000000','0.001098760000000','0.083602781498243','0.081712352291456','74.36778940938551','74.367789409385509','test'),('2019-11-18 23:59:59','2019-11-21 11:59:59','WABIETH','4h','0.001108370000000','0.001100650000000','0.083602781498243','0.083020472816876','75.42858566926478','75.428585669264777','test'),('2019-11-23 19:59:59','2019-11-24 19:59:59','WABIETH','4h','0.001179280000000','0.001140310000000','0.083602781498243','0.080840078497271','70.89307161848161','70.893071618481613','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','WABIETH','4h','0.001189190000000','0.001108890000000','0.083602781498243','0.077957507526625','70.30229105377863','70.302291053778632','test'),('2019-11-25 19:59:59','2019-11-25 23:59:59','WABIETH','4h','0.001147240000000','0.001103690000000','0.083602781498243','0.080429163829535','72.87296598640478','72.872965986404779','test'),('2019-11-26 11:59:59','2019-11-30 03:59:59','WABIETH','4h','0.001186240000000','0.001201830000000','0.083602781498243','0.084701519834126','70.47712225033973','70.477122250339733','test'),('2019-12-16 11:59:59','2019-12-18 15:59:59','WABIETH','4h','0.001102790000000','0.001120910000000','0.083602781498243','0.084976463160888','75.81024628283082','75.810246282830818','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','WABIETH','4h','0.001133810000000','0.001120660000000','0.083602781498243','0.082633151157443','73.73614758931654','73.736147589316545','test'),('2019-12-19 15:59:59','2019-12-21 15:59:59','WABIETH','4h','0.001205300000000','0.001170000000000','0.083602781498243','0.081154280555002','69.36263295299345','69.362632952993451','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:45:44
