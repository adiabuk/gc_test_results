-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-06 11:59:59','LINKETH','4h','0.002945920000000','0.002453200000000','0.072144500000000','0.060077967969259','24.489633119704543','24.489633119704543','test'),('2019-01-08 15:59:59','2019-01-18 03:59:59','LINKETH','4h','0.002580000000000','0.003878990000000','0.072144500000000','0.108468137230620','27.962984496124033','27.962984496124033','test'),('2019-01-18 23:59:59','2019-01-19 15:59:59','LINKETH','4h','0.004130980000000','0.003915180000000','0.078208776299970','0.074123195172602','18.932257309396256','18.932257309396256','test'),('2019-01-20 15:59:59','2019-01-24 03:59:59','LINKETH','4h','0.004179220000000','0.004200700000000','0.078208776299970','0.078610747125847','18.713725599506606','18.713725599506606','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','LINKETH','4h','0.003995020000000','0.003885270000000','0.078208776299970','0.076060248082609','19.576566900783977','19.576566900783977','test'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKETH','4h','0.003979650000000','0.003836520000000','0.078208776299970','0.075395960561949','19.6521745128265','19.652174512826502','test'),('2019-03-03 19:59:59','2019-03-05 15:59:59','LINKETH','4h','0.003236060000000','0.003103600000000','0.078208776299970','0.075007496191229','24.167900564257152','24.167900564257152','test'),('2019-03-08 03:59:59','2019-03-15 15:59:59','LINKETH','4h','0.003609580000000','0.003553940000000','0.078208776299970','0.077003224320701','21.667001784132783','21.667001784132783','test'),('2019-03-27 19:59:59','2019-03-30 03:59:59','LINKETH','4h','0.003515940000000','0.003450000000000','0.078208776299970','0.076742003058896','22.244058857651154','22.244058857651154','test'),('2019-03-31 07:59:59','2019-04-02 23:59:59','LINKETH','4h','0.003573510000000','0.003570170000000','0.078208776299970','0.078135678054032','21.885702376646492','21.885702376646492','test'),('2019-05-01 19:59:59','2019-05-02 11:59:59','LINKETH','4h','0.002954280000000','0.002928340000000','0.078208776299970','0.077522065609981','26.47304124861895','26.473041248618951','test'),('2019-05-02 19:59:59','2019-05-02 23:59:59','LINKETH','4h','0.002896450000000','0.002861520000000','0.078208776299970','0.077265610508688','27.001597231082876','27.001597231082876','test'),('2019-05-03 15:59:59','2019-05-03 19:59:59','LINKETH','4h','0.002922590000000','0.002985500000000','0.078208776299970','0.079892253666631','26.76009166525924','26.760091665259239','test'),('2019-05-03 23:59:59','2019-05-11 19:59:59','LINKETH','4h','0.003036860000000','0.003610760000000','0.078208776299970','0.092988521404635','25.753171466570734','25.753171466570734','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','LINKETH','4h','0.003453090000000','0.003402300000000','0.078269198339510','0.077117970719128','22.666422925411663','22.666422925411663','test'),('2019-05-17 11:59:59','2019-05-25 07:59:59','LINKETH','4h','0.003742610000000','0.004716440000000','0.078269198339510','0.098634903935061','20.912998773452216','20.912998773452216','test'),('2019-06-06 07:59:59','2019-06-09 15:59:59','LINKETH','4h','0.004670550000000','0.004504760000000','0.083072817833302','0.080123991149382','17.786517183908106','17.786517183908106','test'),('2019-06-10 07:59:59','2019-06-11 23:59:59','LINKETH','4h','0.004679450000000','0.004597130000000','0.083072817833302','0.081611416522456','17.752688421353366','17.752688421353366','test'),('2019-06-13 19:59:59','2019-06-20 15:59:59','LINKETH','4h','0.006918550000000','0.006482030000000','0.083072817833302','0.077831409382023','12.00725843324136','12.007258433241359','test'),('2019-06-25 07:59:59','2019-06-26 03:59:59','LINKETH','4h','0.006642170000000','0.006220000000000','0.083072817833302','0.077792788640330','12.506879202625347','12.506879202625347','test'),('2019-06-26 07:59:59','2019-06-26 15:59:59','LINKETH','4h','0.006490600000000','0.006124140000000','0.083072817833302','0.078382517271999','12.798942753104798','12.798942753104798','test'),('2019-06-26 19:59:59','2019-07-04 03:59:59','LINKETH','4h','0.006632350000000','0.011642300000000','0.083072817833302','0.145824431319314','12.525397156860238','12.525397156860238','test'),('2019-07-05 15:59:59','2019-07-06 15:59:59','LINKETH','4h','0.012422820000000','0.011803100000000','0.093855229654725','0.089173203921306','7.555066374198853','7.555066374198853','test'),('2019-07-13 07:59:59','2019-07-16 19:59:59','LINKETH','4h','0.012081630000000','0.011354580000000','0.093855229654725','0.088207196672382','7.768424430703886','7.768424430703886','test'),('2019-07-18 11:59:59','2019-07-19 07:59:59','LINKETH','4h','0.012472020000000','0.011680960000000','0.093855229654725','0.087902295168518','7.5252629209001425','7.525262920900142','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','LINKETH','4h','0.011740910000000','0.011830540000000','0.093855229654725','0.094571719623045','7.993863308272101','7.993863308272101','test'),('2019-07-19 23:59:59','2019-07-20 07:59:59','LINKETH','4h','0.011795910000000','0.011807950000000','0.093855229654725','0.093951027008642','7.956590856892347','7.956590856892347','test'),('2019-08-03 15:59:59','2019-08-05 19:59:59','LINKETH','4h','0.011821670000000','0.010835450000000','0.093855229654725','0.086025379507488','7.939253054325235','7.939253054325235','test'),('2019-08-10 19:59:59','2019-08-19 07:59:59','LINKETH','4h','0.011221850000000','0.012397950000000','0.093855229654725','0.103691676906909','8.36361470298792','8.363614702987920','test'),('2019-09-24 03:59:59','2019-09-27 07:59:59','LINKETH','4h','0.009020480000000','0.009650950000000','0.093855229654725','0.100415069778578','10.404682417645734','10.404682417645734','test'),('2019-09-29 07:59:59','2019-09-30 15:59:59','LINKETH','4h','0.010026400000000','0.009674850000000','0.093855229654725','0.090564436749483','9.360810425947998','9.360810425947998','test'),('2019-10-01 11:59:59','2019-10-10 15:59:59','LINKETH','4h','0.009930010000000','0.013316980000000','0.093855229654725','0.125867770143976','9.451675240480624','9.451675240480624','test'),('2019-10-11 03:59:59','2019-10-13 07:59:59','LINKETH','4h','0.014344280000000','0.014243330000000','0.099309599387994','0.098610693339157','6.923289240588879','6.923289240588879','test'),('2019-10-18 11:59:59','2019-10-18 19:59:59','LINKETH','4h','0.014063990000000','0.013545390000000','0.099309599387994','0.095647625919397','7.061267775929448','7.061267775929448','test'),('2019-10-18 23:59:59','2019-10-19 03:59:59','LINKETH','4h','0.013638600000000','0.013502880000000','0.099309599387994','0.098321352879633','7.281509787514407','7.281509787514407','test'),('2019-10-20 19:59:59','2019-10-25 23:59:59','LINKETH','4h','0.013871250000000','0.015660850000000','0.099309599387994','0.112122032230366','7.159383573073371','7.159383573073371','test'),('2019-11-09 15:59:59','2019-11-10 19:59:59','LINKETH','4h','0.015462800000000','0.014727770000000','0.101175426092139','0.096366014249491','6.543150405627603','6.543150405627603','test'),('2019-11-12 15:59:59','2019-11-17 07:59:59','LINKETH','4h','0.015029520000000','0.015989420000000','0.101175426092139','0.107637261966195','6.731780262585832','6.731780262585832','test'),('2019-11-22 19:59:59','2019-11-22 23:59:59','LINKETH','4h','0.015815150000000','0.015699910000000','0.101588532099990','0.100848288571525','6.423494693378848','6.423494693378848','test'),('2019-11-23 15:59:59','2019-11-24 03:59:59','LINKETH','4h','0.016092700000000','0.015822910000000','0.101588532099990','0.099885426339288','6.312708998489376','6.312708998489376','test'),('2019-11-24 11:59:59','2019-11-24 15:59:59','LINKETH','4h','0.015788130000000','0.015566920000000','0.101588532099990','0.100165159022505','6.4344879412565','6.434487941256500','test'),('2019-11-24 19:59:59','2019-11-24 23:59:59','LINKETH','4h','0.015682380000000','0.015896840000000','0.101588532099990','0.102977777647806','6.477877216340249','6.477877216340249','test'),('2019-12-10 19:59:59','2019-12-12 07:59:59','LINKETH','4h','0.015186650000000','0.014520610000000','0.101588532099990','0.097133169928617','6.689331228413772','6.689331228413772','test'),('2019-12-12 11:59:59','2019-12-12 15:59:59','LINKETH','4h','0.014540170000000','0.014525060000000','0.101588532099990','0.101482962308163','6.986749955467508','6.986749955467508','test'),('2019-12-16 19:59:59','2019-12-17 07:59:59','LINKETH','4h','0.015055820000000','0.014345780000000','0.101588532099990','0.096797566125883','6.747459261600498','6.747459261600498','test'),('2019-12-20 23:59:59','2019-12-22 11:59:59','LINKETH','4h','0.014954100000000','0.014558630000000','0.101588532099990','0.098901963413838','6.7933564774871105','6.793356477487110','test'),('2019-12-22 15:59:59','2019-12-22 23:59:59','LINKETH','4h','0.014733000000000','0.014571380000000','0.101588532099990','0.100474112867111','6.895305239936876','6.895305239936876','test'),('2019-12-23 19:59:59','2019-12-23 23:59:59','LINKETH','4h','0.014749900000000','0.014568950000000','0.101588532099990','0.100342256200934','6.887404802743747','6.887404802743747','test'),('2019-12-27 03:59:59','2019-12-28 07:59:59','LINKETH','4h','0.014838000000000','0.014653180000000','0.101588532099990','0.100323159913528','6.846511126835827','6.846511126835827','test'),('2019-12-28 11:59:59','2019-12-28 19:59:59','LINKETH','4h','0.014760460000000','0.014665560000000','0.101588532099990','0.100935384996425','6.88247738214053','6.882477382140530','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:33:50
