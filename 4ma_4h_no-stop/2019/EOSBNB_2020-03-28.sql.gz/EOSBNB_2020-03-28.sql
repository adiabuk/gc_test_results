-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 07:59:59','2019-01-03 19:59:59','EOSBNB','4h','0.467600000000000','0.448400000000000','0.711908500000000','0.682677013259196','1.522473267750214','1.522473267750214','test'),('2019-01-03 23:59:59','2019-01-04 11:59:59','EOSBNB','4h','0.453000000000000','0.445100000000000','0.711908500000000','0.699493318653422','1.5715419426048567','1.571541942604857','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','EOSBNB','4h','0.452300000000000','0.448900000000000','0.711908500000000','0.706556987950476','1.573974132213133','1.573974132213133','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','EOSBNB','4h','0.451800000000000','0.444000000000000','0.711908500000000','0.699617915006640','1.5757160247897302','1.575716024789730','test'),('2019-01-31 11:59:59','2019-02-01 07:59:59','EOSBNB','4h','0.379400000000000','0.358300000000000','0.711908500000000','0.672316329862942','1.876406167633105','1.876406167633105','test'),('2019-02-18 11:59:59','2019-02-20 03:59:59','EOSBNB','4h','0.331500000000000','0.328500000000000','0.711908500000000','0.705465889140272','2.1475369532428354','2.147536953242835','test'),('2019-02-20 07:59:59','2019-02-20 11:59:59','EOSBNB','4h','0.335600000000000','0.346500000000000','0.711908500000000','0.735030677145411','2.121300655542312','2.121300655542312','test'),('2019-02-20 15:59:59','2019-02-24 23:59:59','EOSBNB','4h','0.353500000000000','0.355300000000000','0.711908500000000','0.715533493776521','2.013885431400283','2.013885431400283','test'),('2019-03-28 15:59:59','2019-03-30 19:59:59','EOSBNB','4h','0.259300000000000','0.250300000000000','0.711908500000000','0.687198987851909','2.745501349787891','2.745501349787891','test'),('2019-04-03 03:59:59','2019-04-11 23:59:59','EOSBNB','4h','0.270300000000000','0.301300000000000','0.711908500000000','0.793555423788383','2.6337717351091383','2.633771735109138','test'),('2019-05-07 03:59:59','2019-05-13 07:59:59','EOSBNB','4h','0.225000000000000','0.234400000000000','0.711908500000000','0.741650455111111','3.1640377777777777','3.164037777777778','test'),('2019-05-14 23:59:59','2019-05-15 02:59:59','EOSBNB','4h','0.253800000000000','0.239400000000000','0.713934247886571','0.673427340205063','2.812979700104691','2.812979700104691','test'),('2019-05-16 15:59:59','2019-05-17 03:59:59','EOSBNB','4h','0.254800000000000','0.249700000000000','0.713934247886571','0.699644355169846','2.801939748377437','2.801939748377437','test'),('2019-05-28 07:59:59','2019-06-01 23:59:59','EOSBNB','4h','0.235300000000000','0.231400000000000','0.713934247886571','0.702101083556959','3.034144699900429','3.034144699900429','test'),('2019-06-16 07:59:59','2019-06-18 03:59:59','EOSBNB','4h','0.215000000000000','0.204000000000000','0.713934247886571','0.677407379390049','3.3206244087747487','3.320624408774749','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','EOSBNB','4h','0.204000000000000','0.188800000000000','0.713934247886571','0.660739147063650','3.4996776857184857','3.499677685718486','test'),('2019-07-25 11:59:59','2019-07-27 23:59:59','EOSBNB','4h','0.156100000000000','0.154000000000000','0.713934247886571','0.704329751278231','4.57356981349501','4.573569813495010','test'),('2019-07-30 03:59:59','2019-07-31 03:59:59','EOSBNB','4h','0.158300000000000','0.153500000000000','0.713934247886571','0.692286210047938','4.510007883048459','4.510007883048459','test'),('2019-07-31 23:59:59','2019-08-01 07:59:59','EOSBNB','4h','0.159200000000000','0.153500000000000','0.713934247886571','0.688372531724803','4.484511607327707','4.484511607327707','test'),('2019-08-04 07:59:59','2019-08-04 11:59:59','EOSBNB','4h','0.154300000000000','0.153400000000000','0.713934247886571','0.709770017017498','4.626923187858529','4.626923187858529','test'),('2019-08-04 15:59:59','2019-08-05 03:59:59','EOSBNB','4h','0.154200000000000','0.156900000000000','0.713934247886571','0.726435042110266','4.629923786553638','4.629923786553638','test'),('2019-08-05 11:59:59','2019-08-06 11:59:59','EOSBNB','4h','0.156300000000000','0.157100000000000','0.713934247886571','0.717588421900066','4.567717516868656','4.567717516868656','test'),('2019-08-23 23:59:59','2019-08-25 23:59:59','EOSBNB','4h','0.136100000000000','0.136500000000000','0.713934247886571','0.716032511656994','5.245659426058567','5.245659426058567','test'),('2019-08-26 03:59:59','2019-08-26 07:59:59','EOSBNB','4h','0.139400000000000','0.133700000000000','0.713934247886571','0.684741814508139','5.121479540075832','5.121479540075832','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','EOSBNB','4h','0.138200000000000','0.139400000000000','0.713934247886571','0.720133387520897','5.16594969527186','5.165949695271860','test'),('2019-08-28 15:59:59','2019-08-28 19:59:59','EOSBNB','4h','0.139500000000000','0.137000000000000','0.713934247886571','0.701139727315127','5.1178082285775695','5.117808228577569','test'),('2019-08-28 23:59:59','2019-09-02 15:59:59','EOSBNB','4h','0.139200000000000','0.147600000000000','0.713934247886571','0.757016486983175','5.128837987690884','5.128837987690884','test'),('2019-09-04 03:59:59','2019-09-05 19:59:59','EOSBNB','4h','0.152200000000000','0.140200000000000','0.713934247886571','0.657645082481585','4.690763783748824','4.690763783748824','test'),('2019-09-07 19:59:59','2019-09-14 11:59:59','EOSBNB','4h','0.158600000000000','0.177800000000000','0.713934247886571','0.800362605764391','4.501476972803096','4.501476972803096','test'),('2019-09-14 15:59:59','2019-09-18 03:59:59','EOSBNB','4h','0.188200000000000','0.189600000000000','0.713934247886571','0.719245129645557','3.793486970704415','3.793486970704415','test'),('2019-09-21 19:59:59','2019-09-22 19:59:59','EOSBNB','4h','0.191800000000000','0.187000000000000','0.713934247886571','0.696067280264801','3.7222849212021427','3.722284921202143','test'),('2019-09-22 23:59:59','2019-09-24 15:59:59','EOSBNB','4h','0.187400000000000','0.181400000000000','0.713934247886571','0.691076160974514','3.8096811520094502','3.809681152009450','test'),('2019-09-30 19:59:59','2019-10-01 15:59:59','EOSBNB','4h','0.187000000000000','0.185300000000000','0.713934247886571','0.707443936542148','3.817830202601984','3.817830202601984','test'),('2019-10-01 19:59:59','2019-10-03 19:59:59','EOSBNB','4h','0.185400000000000','0.185200000000000','0.713934247886571','0.713164092279358','3.850778036065647','3.850778036065647','test'),('2019-10-03 23:59:59','2019-10-09 07:59:59','EOSBNB','4h','0.186900000000000','0.187500000000000','0.713934247886571','0.716226171635806','3.8198729153909627','3.819872915390963','test'),('2019-10-26 03:59:59','2019-10-26 19:59:59','EOSBNB','4h','0.171100000000000','0.167900000000000','0.713934247886571','0.700581883227091','4.172613956087498','4.172613956087498','test'),('2019-10-27 03:59:59','2019-10-27 07:59:59','EOSBNB','4h','0.166700000000000','0.163900000000000','0.713934247886571','0.701942550861482','4.28274893753192','4.282748937531920','test'),('2019-10-27 11:59:59','2019-10-27 15:59:59','EOSBNB','4h','0.166000000000000','0.175100000000000','0.713934247886571','0.753071607258666','4.3008087222082585','4.300808722208258','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','EOSBNB','4h','0.166700000000000','0.166700000000000','0.713934247886571','0.713934247886571','4.28274893753192','4.282748937531920','test'),('2019-11-02 03:59:59','2019-11-02 11:59:59','EOSBNB','4h','0.167500000000000','0.165700000000000','0.713934247886571','0.706262118655551','4.262294017233259','4.262294017233259','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','EOSBNB','4h','0.164500000000000','0.163500000000000','0.713934247886571','0.709594222063552','4.340025823018668','4.340025823018668','test'),('2019-11-05 07:59:59','2019-11-07 23:59:59','EOSBNB','4h','0.168800000000000','0.170000000000000','0.713934247886571','0.719009609838371','4.22946829316689','4.229468293166890','test'),('2019-11-08 03:59:59','2019-11-11 11:59:59','EOSBNB','4h','0.172800000000000','0.173200000000000','0.713934247886571','0.715586873460382','4.131563934528767','4.131563934528767','test'),('2019-11-18 11:59:59','2019-11-18 19:59:59','EOSBNB','4h','0.172300000000000','0.166300000000000','0.713934247886571','0.689072927588722','4.143553382974875','4.143553382974875','test'),('2019-11-18 23:59:59','2019-11-19 03:59:59','EOSBNB','4h','0.166700000000000','0.167200000000000','0.713934247886571','0.716075622355337','4.28274893753192','4.282748937531920','test'),('2019-11-19 07:59:59','2019-11-19 11:59:59','EOSBNB','4h','0.168600000000000','0.169700000000000','0.713934247886571','0.718592181888204','4.234485456029484','4.234485456029484','test'),('2019-11-19 23:59:59','2019-11-20 03:59:59','EOSBNB','4h','0.168900000000000','0.167300000000000','0.713934247886571','0.707171105218611','4.226964167475257','4.226964167475257','test'),('2019-11-20 19:59:59','2019-11-21 15:59:59','EOSBNB','4h','0.170500000000000','0.170000000000000','0.713934247886571','0.711840599065789','4.187297641563466','4.187297641563466','test'),('2019-11-23 03:59:59','2019-11-23 15:59:59','EOSBNB','4h','0.170600000000000','0.165700000000000','0.713934247886571','0.693428516264975','4.184843188080721','4.184843188080721','test'),('2019-11-27 07:59:59','2019-11-27 11:59:59','EOSBNB','4h','0.169200000000000','0.170500000000000','0.713934247886571','0.719419558301775','4.219469550157039','4.219469550157039','test'),('2019-11-27 23:59:59','2019-11-28 03:59:59','EOSBNB','4h','0.166700000000000','0.167800000000000','0.713934247886571','0.718645271717856','4.28274893753192','4.282748937531920','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','EOSBNB','4h','0.168500000000000','0.167500000000000','0.713934247886571','0.709697249382793','4.236998503777869','4.236998503777869','test'),('2019-11-28 19:59:59','2019-11-28 23:59:59','EOSBNB','4h','0.168100000000000','0.169000000000000','0.713934247886571','0.717756620421359','4.247080594209227','4.247080594209227','test'),('2019-11-29 03:59:59','2019-12-04 03:59:59','EOSBNB','4h','0.170500000000000','0.172800000000000','0.713934247886571','0.723565032462167','4.187297641563466','4.187297641563466','test'),('2019-12-07 15:59:59','2019-12-08 03:59:59','EOSBNB','4h','0.175800000000000','0.175200000000000','0.713934247886571','0.711497612228255','4.06105943052657','4.061059430526570','test'),('2019-12-08 11:59:59','2019-12-09 07:59:59','EOSBNB','4h','0.175000000000000','0.174300000000000','0.713934247886571','0.711078510895025','4.079624273637549','4.079624273637549','test'),('2019-12-09 11:59:59','2019-12-09 15:59:59','EOSBNB','4h','0.174600000000000','0.173900000000000','0.713934247886571','0.711071968542238','4.088970491904759','4.088970491904759','test'),('2019-12-10 11:59:59','2019-12-11 15:59:59','EOSBNB','4h','0.175300000000000','0.174700000000000','0.713934247886571','0.711490662326206','4.072642600607935','4.072642600607935','test'),('2019-12-12 03:59:59','2019-12-12 15:59:59','EOSBNB','4h','0.175900000000000','0.175100000000000','0.713934247886571','0.710687247327678','4.058750698616095','4.058750698616095','test'),('2019-12-12 19:59:59','2019-12-16 19:59:59','EOSBNB','4h','0.176600000000000','0.173700000000000','0.713934247886571','0.702210525809158','4.042662785314671','4.042662785314671','test'),('2019-12-17 15:59:59','2019-12-17 19:59:59','EOSBNB','4h','0.182300000000000','0.177500000000000','0.713934247886571','0.695136198573046','3.9162602736509657','3.916260273650966','test'),('2019-12-17 23:59:59','2019-12-18 03:59:59','EOSBNB','4h','0.177600000000000','0.177500000000000','0.713934247886571','0.713532257882130','4.019900044406368','4.019900044406368','test'),('2019-12-18 23:59:59','2019-12-29 15:59:59','EOSBNB','4h','0.180800000000000','0.190500000000000','0.713934247886571','0.752237136185795','3.9487513710540436','3.948751371054044','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:06:24
