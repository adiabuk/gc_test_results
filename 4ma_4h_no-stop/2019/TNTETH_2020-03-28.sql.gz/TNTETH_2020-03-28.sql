-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 23:59:59','2019-01-10 19:59:59','TNTETH','4h','0.000089140000000','0.000089450000000','0.072144500000000','0.072395395164909','809.3392416423603','809.339241642360321','test'),('2019-01-11 03:59:59','2019-01-18 11:59:59','TNTETH','4h','0.000090260000000','0.000137040000000','0.072207223791227','0.109630821497338','799.9914003016535','799.991400301653471','test'),('2019-01-21 19:59:59','2019-01-23 03:59:59','TNTETH','4h','0.000149000000000','0.000134820000000','0.081563123217755','0.073800941424280','547.403511528557','547.403511528557033','test'),('2019-01-24 15:59:59','2019-01-27 03:59:59','TNTETH','4h','0.000137300000000','0.000134470000000','0.081563123217755','0.079881960517782','594.0504240186089','594.050424018608851','test'),('2019-02-02 07:59:59','2019-02-02 11:59:59','TNTETH','4h','0.000133820000000','0.000132530000000','0.081563123217755','0.080776869825505','609.4987536822224','609.498753682222400','test'),('2019-02-02 15:59:59','2019-02-02 19:59:59','TNTETH','4h','0.000132840000000','0.000132260000000','0.081563123217755','0.081207005998045','613.9952063968307','613.995206396830667','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','TNTETH','4h','0.000117000000000','0.000111040000000','0.081563123217755','0.077408283778628','697.1207112628632','697.120711262863210','test'),('2019-02-27 19:59:59','2019-02-28 15:59:59','TNTETH','4h','0.000114630000000','0.000112600000000','0.081563123217755','0.080118709537810','711.5338324849952','711.533832484995173','test'),('2019-03-01 03:59:59','2019-03-02 15:59:59','TNTETH','4h','0.000115480000000','0.000114850000000','0.081563123217755','0.081118156404219','706.296529422887','706.296529422887033','test'),('2019-03-02 23:59:59','2019-03-03 19:59:59','TNTETH','4h','0.000114960000000','0.000114640000000','0.081563123217755','0.081336085992375','709.491329312413','709.491329312412972','test'),('2019-03-03 23:59:59','2019-03-05 19:59:59','TNTETH','4h','0.000115870000000','0.000118700000000','0.081563123217755','0.083555214688423','703.9192475856995','703.919247585699509','test'),('2019-03-08 07:59:59','2019-03-16 07:59:59','TNTETH','4h','0.000120360000000','0.000138480000000','0.081563123217755','0.093842317241565','677.6597143382768','677.659714338276785','test'),('2019-03-20 03:59:59','2019-03-21 07:59:59','TNTETH','4h','0.000141620000000','0.000140670000000','0.081563123217755','0.081015990277091','575.9294112254978','575.929411225497802','test'),('2019-03-26 23:59:59','2019-03-30 03:59:59','TNTETH','4h','0.000150380000000','0.000146790000000','0.081563123217755','0.079615978568521','542.3801251346921','542.380125134692094','test'),('2019-03-30 15:59:59','2019-04-02 07:59:59','TNTETH','4h','0.000155130000000','0.000151290000000','0.081563123217755','0.079544155944138','525.7727275043834','525.772727504383397','test'),('2019-05-21 23:59:59','2019-05-25 03:59:59','TNTETH','4h','0.000112930000000','0.000126130000000','0.081563123217755','0.091096756676308','722.2449589812716','722.244958981271566','test'),('2019-06-02 15:59:59','2019-06-03 03:59:59','TNTETH','4h','0.000136410000000','0.000116370000000','0.082171798674285','0.070099935574566','602.388378229492','602.388378229491991','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','TNTETH','4h','0.000119420000000','0.000118600000000','0.082171798674285','0.081607564250295','688.0907609636995','688.090760963699495','test'),('2019-06-05 19:59:59','2019-06-06 19:59:59','TNTETH','4h','0.000121810000000','0.000118020000000','0.082171798674285','0.079615102861334','674.5899242614316','674.589924261431634','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','TNTETH','4h','0.000120310000000','0.000119620000000','0.082171798674285','0.081700528280425','683.0005708111129','683.000570811112880','test'),('2019-06-07 11:59:59','2019-06-10 11:59:59','TNTETH','4h','0.000122790000000','0.000135910000000','0.082171798674285','0.090951780746169','669.2059506009039','669.205950600903861','test'),('2019-06-11 19:59:59','2019-06-12 23:59:59','TNTETH','4h','0.000141890000000','0.000131260000000','0.082171798674285','0.076015718471962','579.1232551574105','579.123255157410540','test'),('2019-06-20 19:59:59','2019-06-22 23:59:59','TNTETH','4h','0.000145440000000','0.000153280000000','0.082171798674285','0.086601301573119','564.987614647174','564.987614647174041','test'),('2019-06-25 19:59:59','2019-07-04 07:59:59','TNTETH','4h','0.000164240000000','0.000217200000000','0.082171798674285','0.108668501412900','500.3153840372929','500.315384037292915','test'),('2019-07-21 23:59:59','2019-07-23 23:59:59','TNTETH','4h','0.000208830000000','0.000204540000000','0.086643309618408','0.084863393905805','414.89876750662035','414.898767506620345','test'),('2019-08-20 23:59:59','2019-08-23 03:59:59','TNTETH','4h','0.000165920000000','0.000169430000000','0.086643309618408','0.088476229198691','522.1993106220347','522.199310622034659','test'),('2019-08-23 07:59:59','2019-08-23 11:59:59','TNTETH','4h','0.000170760000000','0.000168930000000','0.086656560585328','0.085727879946589','507.4757588740193','507.475758874019277','test'),('2019-08-24 03:59:59','2019-08-25 15:59:59','TNTETH','4h','0.000173580000000','0.000182150000000','0.086656560585328','0.090934972408212','499.2312512117064','499.231251211706422','test'),('2019-08-26 23:59:59','2019-08-27 19:59:59','TNTETH','4h','0.000184200000000','0.000176090000000','0.087493993381364','0.083641787701001','474.9945351865568','474.994535186556789','test'),('2019-08-31 07:59:59','2019-09-01 15:59:59','TNTETH','4h','0.000187000000000','0.000175760000000','0.087493993381364','0.082234996132131','467.8823175474011','467.882317547401101','test'),('2019-09-03 07:59:59','2019-09-03 15:59:59','TNTETH','4h','0.000186970000000','0.000177920000000','0.087493993381364','0.083258978993487','467.95739092562445','467.957390925624452','test'),('2019-09-03 19:59:59','2019-09-04 19:59:59','TNTETH','4h','0.000182740000000','0.000178710000000','0.087493993381364','0.085564471693026','478.7895008283025','478.789500828302494','test'),('2019-09-20 03:59:59','2019-09-29 19:59:59','TNTETH','4h','0.000174750000000','0.000251460000000','0.087493993381364','0.125901227900874','500.6809349434278','500.680934943427815','test'),('2019-10-02 23:59:59','2019-10-06 19:59:59','TNTETH','4h','0.000268240000000','0.000290400000000','0.093276867259789','0.100982710454230','347.7366062473476','347.736606247347595','test'),('2019-10-06 23:59:59','2019-10-10 11:59:59','TNTETH','4h','0.000304960000000','0.000298100000000','0.095203328058399','0.093061752669887','312.18300124081446','312.183001240814463','test'),('2019-10-11 19:59:59','2019-10-13 07:59:59','TNTETH','4h','0.000325440000000','0.000313470000000','0.095203328058399','0.091701656976605','292.5372666494561','292.537266649456114','test'),('2019-10-14 23:59:59','2019-10-23 15:59:59','TNTETH','4h','0.000336550000000','0.000428420000000','0.095203328058399','0.121191531144791','282.88019033843113','282.880190338431134','test'),('2019-10-24 15:59:59','2019-10-25 07:59:59','TNTETH','4h','0.000479990000000','0.000450600000000','0.100289567212420','0.094148792653840','208.94095129569422','208.940951295694219','test'),('2019-11-13 19:59:59','2019-11-17 23:59:59','TNTETH','4h','0.000399450000000','0.000403270000000','0.100289567212420','0.101248651319946','251.06913809593192','251.069138095931919','test'),('2019-11-23 15:59:59','2019-11-24 15:59:59','TNTETH','4h','0.000407840000000','0.000395930000000','0.100289567212420','0.097360848240519','245.90419579349742','245.904195793497422','test'),('2019-11-24 19:59:59','2019-11-30 19:59:59','TNTETH','4h','0.000406100000000','0.000453920000000','0.100289567212420','0.112099089753907','246.95781140709184','246.957811407091839','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','TNTETH','4h','0.000468480000000','0.000452070000000','0.101214345492053','0.097668991561203','216.04838091712193','216.048380917121932','test'),('2019-12-02 11:59:59','2019-12-04 07:59:59','TNTETH','4h','0.000471340000000','0.000458890000000','0.101214345492053','0.098540864350253','214.7374411084419','214.737441108441914','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','TNTETH','4h','0.000472840000000','0.000458990000000','0.101214345492053','0.098249666773956','214.05622513334959','214.056225133349585','test'),('2019-12-20 11:59:59','2019-12-21 23:59:59','TNTETH','4h','0.000361480000000','0.000340810000000','0.101214345492053','0.095426748608904','279.99984920895486','279.999849208954856','test'),('2019-12-22 03:59:59','2019-12-22 07:59:59','TNTETH','4h','0.000347020000000','0.000347920000000','0.101214345492053','0.101476845955839','291.66718198390004','291.667181983900036','test'),('2019-12-23 19:59:59','2019-12-25 03:59:59','TNTETH','4h','0.000359710000000','0.000343970000000','0.101214345492053','0.096785461674408','281.3776250091824','281.377625009182395','test'),('2019-12-25 07:59:59','2019-12-25 11:59:59','TNTETH','4h','0.000348590000000','0.000346500000000','0.101214345492053','0.100607506563574','290.3535542960297','290.353554296029699','test'),('2020-01-01 15:59:59','2020-01-01 15:59:59','TNTETH','4h','0.000362890000000','0.000362890000000','0.101214345492053','0.101214345492053','278.9119168124032','278.911916812403206','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:39:25
