-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-31 03:59:59','2019-06-07 03:59:59','RENBNB','4h','0.001190000000000','0.001310000000000','0.711908500000000','0.783697592436975','598.2424369747899','598.242436974789939','test'),('2019-06-08 03:59:59','2019-06-11 23:59:59','RENBNB','4h','0.001360000000000','0.001430000000000','0.729855773109244','0.767421879078102','536.6586566979734','536.658656697973356','test'),('2019-06-16 19:59:59','2019-06-17 23:59:59','RENBNB','4h','0.001560000000000','0.001400000000000','0.739247299601458','0.663427063744898','473.87647410349894','473.876474103498936','test'),('2019-06-18 07:59:59','2019-06-18 11:59:59','RENBNB','4h','0.001440000000000','0.001420000000000','0.739247299601458','0.728979975995882','513.3661802787902','513.366180278790239','test'),('2019-06-22 07:59:59','2019-07-04 11:59:59','RENBNB','4h','0.001480000000000','0.002860000000000','0.739247299601458','1.428545457337953','499.4914186496338','499.491418649633772','test'),('2019-07-04 19:59:59','2019-07-06 15:59:59','RENBNB','4h','0.003320000000000','0.002930000000000','0.890049949170048','0.785495888875976','268.0873340873639','268.087334087363899','test'),('2019-07-09 23:59:59','2019-07-12 03:59:59','RENBNB','4h','0.003180000000000','0.003167000000000','0.890049949170048','0.886411380195454','279.8899211226566','279.889921122656574','test'),('2019-07-12 07:59:59','2019-07-13 03:59:59','RENBNB','4h','0.003304000000000','0.002979000000000','0.890049949170048','0.802499636373357','269.38557783597093','269.385577835970935','test'),('2019-07-21 07:59:59','2019-07-27 19:59:59','RENBNB','4h','0.003194000000000','0.004147000000000','0.890049949170048','1.155615885788412','278.66310243270135','278.663102432701351','test'),('2019-07-28 19:59:59','2019-07-29 03:59:59','RENBNB','4h','0.004488000000000','0.004178000000000','0.907505697808300','0.844821480713698','202.20715191807037','202.207151918070366','test'),('2019-08-02 23:59:59','2019-08-03 19:59:59','RENBNB','4h','0.004283000000000','0.004001000000000','0.907505697808300','0.847753980137989','211.88552365358393','211.885523653583931','test'),('2019-08-04 03:59:59','2019-08-04 07:59:59','RENBNB','4h','0.003988000000000','0.003937000000000','0.907505697808300','0.895900183618675','227.55910175734704','227.559101757347037','test'),('2019-08-04 11:59:59','2019-08-04 15:59:59','RENBNB','4h','0.004012000000000','0.004470000000000','0.907505697808300','1.011104304387612','226.19783095919743','226.197830959197432','test'),('2019-08-04 19:59:59','2019-08-07 03:59:59','RENBNB','4h','0.004648000000000','0.004418000000000','0.907505697808300','0.862599004500230','195.24649264378226','195.246492643782261','test'),('2019-09-19 19:59:59','2019-09-22 23:59:59','RENBNB','4h','0.002495000000000','0.002399000000000','0.907505697808300','0.872587642902650','363.7297386005211','363.729738600521102','test'),('2019-09-27 03:59:59','2019-09-28 03:59:59','RENBNB','4h','0.002452000000000','0.002408000000000','0.907505697808300','0.891220929984660','370.10835962818106','370.108359628181063','test'),('2019-09-28 07:59:59','2019-09-30 07:59:59','RENBNB','4h','0.002455000000000','0.002455000000000','0.907505697808300','0.907505697808300','369.65608872028514','369.656088720285140','test'),('2019-09-30 15:59:59','2019-09-30 19:59:59','RENBNB','4h','0.002455000000000','0.002534000000000','0.907505697808300','0.936708528817203','369.65608872028514','369.656088720285140','test'),('2019-10-01 19:59:59','2019-10-04 03:59:59','RENBNB','4h','0.002597000000000','0.002545000000000','0.907505697808300','0.889334617220687','349.4438574541009','349.443857454100907','test'),('2019-10-04 11:59:59','2019-10-12 19:59:59','RENBNB','4h','0.002620000000000','0.003302000000000','0.907505697808300','1.143734280214888','346.3762205375191','346.376220537519089','test'),('2019-10-12 23:59:59','2019-10-13 15:59:59','RENBNB','4h','0.003582000000000','0.003389000000000','0.937682691412123','0.887159866330454','261.7762957599449','261.776295759944901','test'),('2019-10-14 11:59:59','2019-10-15 11:59:59','RENBNB','4h','0.003619000000000','0.003395000000000','0.937682691412123','0.879644304322785','259.09994236311775','259.099942363117748','test'),('2019-11-07 03:59:59','2019-11-10 19:59:59','RENBNB','4h','0.002933000000000','0.002726000000000','0.937682691412123','0.871504608520098','319.7008835363529','319.700883536352876','test'),('2019-11-12 11:59:59','2019-11-12 19:59:59','RENBNB','4h','0.002950000000000','0.002801000000000','0.937682691412123','0.890321769032324','317.8585394617366','317.858539461736598','test'),('2019-11-14 23:59:59','2019-11-15 07:59:59','RENBNB','4h','0.002881000000000','0.002810000000000','0.937682691412123','0.914574232165243','325.4712569983072','325.471256998307183','test'),('2019-11-15 11:59:59','2019-11-17 07:59:59','RENBNB','4h','0.002844000000000','0.002798000000000','0.937682691412123','0.922516234378031','329.7055876976522','329.705587697652220','test'),('2019-11-21 19:59:59','2019-11-24 07:59:59','RENBNB','4h','0.002916000000000','0.002873000000000','0.937682691412123','0.923855408925593','321.5647089890682','321.564708989068208','test'),('2019-12-15 19:59:59','2019-12-16 11:59:59','RENBNB','4h','0.002457000000000','0.002408000000000','0.937682691412123','0.918982466797066','381.6372370419711','381.637237041971105','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','RENBNB','4h','0.002428000000000','0.002405000000000','0.937682691412123','0.928800194747181','386.1955071713851','386.195507171385088','test'),('2019-12-17 03:59:59','2019-12-17 15:59:59','RENBNB','4h','0.002469000000000','0.002409000000000','0.937682691412123','0.914895748728961','379.78237805270277','379.782378052702768','test'),('2019-12-23 07:59:59','2019-12-23 11:59:59','RENBNB','4h','0.002399000000000','0.002376000000000','0.937682691412123','0.928692819839602','390.8639814139737','390.863981413973704','test'),('2019-12-23 15:59:59','2019-12-23 19:59:59','RENBNB','4h','0.002421000000000','0.002431000000000','0.937682691412123','0.941555812814073','387.3121401950116','387.312140195011580','test'),('2019-12-23 23:59:59','2019-12-25 19:59:59','RENBNB','4h','0.002470000000000','0.002471000000000','0.937682691412123','0.938062320032128','379.6286200049081','379.628620004908100','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','RENBNB','4h','0.002491000000000','0.002460000000000','0.937682691412123','0.926013416649467','376.4282181501899','376.428218150189878','test'),('2020-01-02 15:59:59','2020-01-05 03:59:59','RENBNB','4h','0.002700000000000','0.002481000000000','0.937682691412123','0.861626206442029','347.2898857081937','347.289885708193708','test'),('2020-01-06 15:59:59','2020-01-07 23:59:59','RENBNB','4h','0.002644000000000','0.002572000000000','0.937682691412123','0.912148215700446','354.64549599550793','354.645495995507929','test'),('2020-01-08 15:59:59','2020-01-13 03:59:59','RENBNB','4h','0.002701000000000','0.002884000000000','0.937682691412123','1.001213210674773','347.16130744617664','347.161307446176636','test'),('2020-01-13 23:59:59','2020-01-14 03:59:59','RENBNB','4h','0.003033000000000','0.002963000000000','0.937682691412123','0.916041481916954','309.1601356452763','309.160135645276284','test'),('2020-02-02 03:59:59','2020-02-02 11:59:59','RENBNB','4h','0.002439000000000','0.002432000000000','0.937682691412123','0.934991515176008','384.45374801645056','384.453748016450561','test'),('2020-02-02 19:59:59','2020-02-07 11:59:59','RENBNB','4h','0.002474000000000','0.002628000000000','0.937682691412123','0.996050975356127','379.01483080522354','379.014830805223539','test'),('2020-02-15 19:59:59','2020-02-15 23:59:59','RENBNB','4h','0.002538000000000','0.002498000000000','0.937682691412123','0.922904398403264','369.4573252214827','369.457325221482677','test'),('2020-02-16 03:59:59','2020-02-16 15:59:59','RENBNB','4h','0.002542000000000','0.002480000000000','0.937682691412123','0.914812381865486','368.8759604296314','368.875960429631391','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:53:18
