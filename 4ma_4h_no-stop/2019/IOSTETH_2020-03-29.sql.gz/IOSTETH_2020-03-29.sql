-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-10 23:59:59','IOSTETH','4h','0.000043100000000','0.000044360000000','0.072144500000000','0.074253596751740','1673.8863109048725','1673.886310904872516','test'),('2019-01-11 07:59:59','2019-01-25 11:59:59','IOSTETH','4h','0.000045820000000','0.000055280000000','0.072671774187935','0.087675593127653','1586.027372063182','1586.027372063181929','test'),('2019-01-25 19:59:59','2019-01-26 11:59:59','IOSTETH','4h','0.000056470000000','0.000055900000000','0.076422728922865','0.075651328967384','1353.3332552304676','1353.333255230467557','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','IOSTETH','4h','0.000055950000000','0.000054290000000','0.076422728922865','0.074155316411481','1365.911151436372','1365.911151436371938','test'),('2019-01-30 23:59:59','2019-01-31 03:59:59','IOSTETH','4h','0.000053900000000','0.000053590000000','0.076422728922865','0.075983191891954','1417.861390034601','1417.861390034601072','test'),('2019-02-03 11:59:59','2019-02-08 15:59:59','IOSTETH','4h','0.000055230000000','0.000056710000000','0.076422728922865','0.078470631128294','1383.7177063709037','1383.717706370903670','test'),('2019-02-12 15:59:59','2019-02-13 15:59:59','IOSTETH','4h','0.000056930000000','0.000055740000000','0.076422728922865','0.074825275077472','1342.3981894056737','1342.398189405673747','test'),('2019-02-13 19:59:59','2019-02-13 23:59:59','IOSTETH','4h','0.000056000000000','0.000055750000000','0.076422728922865','0.076081556025888','1364.6915879083035','1364.691587908303518','test'),('2019-02-23 03:59:59','2019-02-23 11:59:59','IOSTETH','4h','0.000056440000000','0.000054510000000','0.076422728922865','0.073809407398749','1354.0526031691177','1354.052603169117674','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','IOSTETH','4h','0.000056030000000','0.000054100000000','0.076422728922865','0.073790284396341','1363.9608945719258','1363.960894571925792','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','IOSTETH','4h','0.000054460000000','0.000054020000000','0.076422728922865','0.075805284913940','1403.281838466122','1403.281838466122053','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','IOSTETH','4h','0.000054120000000','0.000053900000000','0.076422728922865','0.076112067423179','1412.0977258474686','1412.097725847468610','test'),('2019-03-01 07:59:59','2019-03-05 07:59:59','IOSTETH','4h','0.000054610000000','0.000056970000000','0.076422728922865','0.079725377526746','1399.4273745260025','1399.427374526002495','test'),('2019-03-05 11:59:59','2019-03-05 19:59:59','IOSTETH','4h','0.000057410000000','0.000055270000000','0.076422728922865','0.073574015460142','1331.1745152911515','1331.174515291151465','test'),('2019-03-07 11:59:59','2019-03-08 03:59:59','IOSTETH','4h','0.000058460000000','0.000056970000000','0.076422728922865','0.074474903638995','1307.2652911882485','1307.265291188248511','test'),('2019-03-08 07:59:59','2019-03-11 07:59:59','IOSTETH','4h','0.000057090000000','0.000057510000000','0.076422728922865','0.076984956040532','1338.6359944449991','1338.635994444999142','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','IOSTETH','4h','0.000061420000000','0.000059660000000','0.076422728922865','0.074232823307361','1244.2645542635134','1244.264554263513446','test'),('2019-03-21 07:59:59','2019-03-25 03:59:59','IOSTETH','4h','0.000060270000000','0.000060830000000','0.076422728922865','0.077132812350720','1268.0061211691554','1268.006121169155449','test'),('2019-03-27 15:59:59','2019-04-07 19:59:59','IOSTETH','4h','0.000063360000000','0.000094330000000','0.076422728922865','0.113777714950976','1206.1668074947127','1206.166807494712657','test'),('2019-05-11 15:59:59','2019-05-11 19:59:59','IOSTETH','4h','0.000069350000000','0.000068010000000','0.082772867728227','0.081173507342418','1193.552526722808','1193.552526722807897','test'),('2019-05-11 23:59:59','2019-05-12 03:59:59','IOSTETH','4h','0.000068960000000','0.000067110000000','0.082772867728227','0.080552307906632','1200.302606267793','1200.302606267792953','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','IOSTETH','4h','0.000067390000000','0.000068120000000','0.082772867728227','0.083669502146414','1228.266326283232','1228.266326283232047','test'),('2019-05-13 07:59:59','2019-05-13 15:59:59','IOSTETH','4h','0.000069920000000','0.000063860000000','0.082772867728227','0.075598903505786','1183.8224789506153','1183.822478950615277','test'),('2019-06-29 15:59:59','2019-06-30 03:59:59','IOSTETH','4h','0.000044850000000','0.000041730000000','0.082772867728227','0.077014755190611','1845.5488902614718','1845.548890261471797','test'),('2019-06-30 07:59:59','2019-06-30 11:59:59','IOSTETH','4h','0.000042290000000','0.000043100000000','0.082772867728227','0.084358254884998','1957.268094779546','1957.268094779545891','test'),('2019-06-30 23:59:59','2019-07-01 07:59:59','IOSTETH','4h','0.000043090000000','0.000042770000000','0.082772867728227','0.082158170172575','1920.929861411627','1920.929861411626916','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','IOSTETH','4h','0.000043420000000','0.000042280000000','0.082772867728227','0.080599651026012','1906.330440539544','1906.330440539544043','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','IOSTETH','4h','0.000043120000000','0.000043050000000','0.082772867728227','0.082638496189707','1919.5934074264148','1919.593407426414842','test'),('2019-07-06 19:59:59','2019-07-07 19:59:59','IOSTETH','4h','0.000044910000000','0.000043590000000','0.082772867728227','0.080339997868480','1843.0832270814296','1843.083227081429641','test'),('2019-07-21 07:59:59','2019-07-23 19:59:59','IOSTETH','4h','0.000041600000000','0.000038690000000','0.082772867728227','0.076982746452046','1989.732397313149','1989.732397313149022','test'),('2019-07-25 03:59:59','2019-08-01 11:59:59','IOSTETH','4h','0.000039480000000','0.000045960000000','0.082772867728227','0.096358687963255','2096.577196763602','2096.577196763601933','test'),('2019-08-01 15:59:59','2019-08-01 23:59:59','IOSTETH','4h','0.000046840000000','0.000045940000000','0.082772867728227','0.081182441149333','1767.1406432157773','1767.140643215777345','test'),('2019-08-08 03:59:59','2019-08-08 23:59:59','IOSTETH','4h','0.000049170000000','0.000044900000000','0.082772867728227','0.075584741936087','1683.4018248571692','1683.401824857169231','test'),('2019-08-09 03:59:59','2019-08-09 11:59:59','IOSTETH','4h','0.000045440000000','0.000042990000000','0.082772867728227','0.078309982034254','1821.585997540207','1821.585997540207018','test'),('2019-08-15 11:59:59','2019-08-18 23:59:59','IOSTETH','4h','0.000046300000000','0.000045350000000','0.082772867728227','0.081074504351514','1787.750922855875','1787.750922855874933','test'),('2019-10-04 23:59:59','2019-10-07 11:59:59','IOSTETH','4h','0.000030670000000','0.000029470000000','0.082772867728227','0.079534281446066','2698.821901800685','2698.821901800684827','test'),('2019-10-27 15:59:59','2019-11-03 19:59:59','IOSTETH','4h','0.000032260000000','0.000037140000000','0.082772867728227','0.095293995890463','2565.8049512779608','2565.804951277960754','test'),('2019-11-13 19:59:59','2019-11-13 23:59:59','IOSTETH','4h','0.000034660000000','0.000034740000000','0.082772867728227','0.082963918778956','2388.138134109262','2388.138134109261955','test'),('2019-11-14 11:59:59','2019-11-14 15:59:59','IOSTETH','4h','0.000033990000000','0.000034180000000','0.082772867728227','0.083235558074457','2435.2123485797883','2435.212348579788340','test'),('2019-11-14 19:59:59','2019-11-17 23:59:59','IOSTETH','4h','0.000034460000000','0.000035210000000','0.082772867728227','0.084574366590565','2401.9984831174406','2401.998483117440628','test'),('2019-11-18 03:59:59','2019-11-18 07:59:59','IOSTETH','4h','0.000035780000000','0.000035610000000','0.082772867728227','0.082379592504253','2313.3836704367527','2313.383670436752709','test'),('2019-11-19 15:59:59','2019-11-20 11:59:59','IOSTETH','4h','0.000036550000000','0.000034940000000','0.082772867728227','0.079126785182606','2264.64754386394','2264.647543863939973','test'),('2019-11-28 03:59:59','2019-11-30 15:59:59','IOSTETH','4h','0.000035500000000','0.000034540000000','0.082772867728227','0.080534502854450','2331.6300768514648','2331.630076851464764','test'),('2019-12-01 19:59:59','2019-12-05 15:59:59','IOSTETH','4h','0.000037190000000','0.000037710000000','0.082772867728227','0.083930218930665','2225.6753893043024','2225.675389304302371','test'),('2019-12-05 23:59:59','2019-12-08 19:59:59','IOSTETH','4h','0.000039450000000','0.000038980000000','0.082772867728227','0.081786727098765','2098.171552046312','2098.171552046312172','test'),('2019-12-09 15:59:59','2019-12-10 03:59:59','IOSTETH','4h','0.000040580000000','0.000037810000000','0.082772867728227','0.077122773011441','2039.7453851214145','2039.745385121414529','test'),('2019-12-18 15:59:59','2019-12-22 15:59:59','IOSTETH','4h','0.000039160000000','0.000040810000000','0.082772867728227','0.086260488559473','2113.7095946942545','2113.709594694254520','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  2:10:31
