-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 15:59:59','2019-01-09 19:59:59','BTSETH','4h','0.000284950000000','0.000281530000000','0.072144500000000','0.071278614090191','253.18301456395858','253.183014563958579','test'),('2019-01-10 03:59:59','2019-01-15 03:59:59','BTSETH','4h','0.000285750000000','0.000304780000000','0.072144500000000','0.076949083849519','252.47419072615924','252.474190726159236','test'),('2019-01-16 07:59:59','2019-01-22 23:59:59','BTSETH','4h','0.000315720000000','0.000332530000000','0.073129174484928','0.077022818926495','231.62667707122608','231.626677071226084','test'),('2019-01-28 03:59:59','2019-01-28 07:59:59','BTSETH','4h','0.000335210000000','0.000331800000000','0.074102585595319','0.073348760181757','221.06317113248187','221.063171132481870','test'),('2019-01-28 11:59:59','2019-01-28 23:59:59','BTSETH','4h','0.000338840000000','0.000329940000000','0.074102585595319','0.072156200836146','218.69491676106423','218.694916761064235','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','BTSETH','4h','0.000331020000000','0.000331830000000','0.074102585595319','0.074283913292534','223.8613545867893','223.861354586789304','test'),('2019-01-29 15:59:59','2019-01-31 11:59:59','BTSETH','4h','0.000337480000000','0.000335200000000','0.074102585595319','0.073601951794331','219.57622850337503','219.576228503375035','test'),('2019-01-31 23:59:59','2019-02-04 03:59:59','BTSETH','4h','0.000346500000000','0.000348760000000','0.074102585595319','0.074585909818827','213.86027588836652','213.860275888366516','test'),('2019-02-06 11:59:59','2019-02-06 19:59:59','BTSETH','4h','0.000351830000000','0.000349380000000','0.074102585595319','0.073586565543849','210.6204291712446','210.620429171244609','test'),('2019-02-07 11:59:59','2019-02-08 19:59:59','BTSETH','4h','0.000351540000000','0.000333770000000','0.074102585595319','0.070356773039056','210.7941787430136','210.794178743013589','test'),('2019-02-24 23:59:59','2019-02-28 11:59:59','BTSETH','4h','0.000338760000000','0.000333670000000','0.074102585595319','0.072989165590950','218.7465627444769','218.746562744476904','test'),('2019-02-28 23:59:59','2019-03-04 07:59:59','BTSETH','4h','0.000339790000000','0.000340810000000','0.074102585595319','0.074325030744697','218.08347978256865','218.083479782568645','test'),('2019-03-07 11:59:59','2019-03-08 19:59:59','BTSETH','4h','0.000345050000000','0.000341660000000','0.074102585595319','0.073374552657576','214.75897868517316','214.758978685173162','test'),('2019-03-08 23:59:59','2019-03-10 11:59:59','BTSETH','4h','0.000342300000000','0.000343660000000','0.074102585595319','0.074397004281879','216.48432835325445','216.484328353254455','test'),('2019-03-10 19:59:59','2019-03-10 23:59:59','BTSETH','4h','0.000344890000000','0.000345340000000','0.074102585595319','0.074199271969287','214.85860881822902','214.858608818229015','test'),('2019-03-11 03:59:59','2019-03-16 07:59:59','BTSETH','4h','0.000347950000000','0.000361410000000','0.074102585595319','0.076969149188114','212.96906335772096','212.969063357720955','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','BTSETH','4h','0.000367950000000','0.000360010000000','0.074102585595319','0.072503524501076','201.39308491729582','201.393084917295823','test'),('2019-03-22 15:59:59','2019-03-28 19:59:59','BTSETH','4h','0.000367950000000','0.000423610000000','0.074102585595319','0.085312124701816','201.39308491729582','201.393084917295823','test'),('2019-04-01 11:59:59','2019-04-02 07:59:59','BTSETH','4h','0.000431060000000','0.000427980000000','0.075215364148347','0.074677937057972','174.4893150567131','174.489315056713110','test'),('2019-04-03 11:59:59','2019-04-06 19:59:59','BTSETH','4h','0.000435050000000','0.000435940000000','0.075215364148347','0.075369235367959','172.88901079955636','172.889010799556360','test'),('2019-06-09 11:59:59','2019-06-10 15:59:59','BTSETH','4h','0.000257630000000','0.000255060000000','0.075215364148347','0.074465049798849','291.9511087542095','291.951108754209486','test'),('2019-07-17 03:59:59','2019-07-22 11:59:59','BTSETH','4h','0.000203130000000','0.000204170000000','0.075215364148347','0.075600457333570','370.28190886795153','370.281908867951529','test'),('2019-07-22 15:59:59','2019-07-23 07:59:59','BTSETH','4h','0.000205660000000','0.000200860000000','0.075215364148347','0.073459875730998','365.7267536144461','365.726753614446125','test'),('2019-07-24 07:59:59','2019-07-24 23:59:59','BTSETH','4h','0.000209580000000','0.000203300000000','0.075215364148347','0.072961558981577','358.88617305251927','358.886173052519268','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','BTSETH','4h','0.000205840000000','0.000205390000000','0.075215364148347','0.075050931026180','365.40693814781866','365.406938147818664','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','BTSETH','4h','0.000208750000000','0.000203690000000','0.075215364148347','0.073392179752703','360.3131216687281','360.313121668728115','test'),('2019-07-26 23:59:59','2019-07-31 07:59:59','BTSETH','4h','0.000205080000000','0.000210260000000','0.075215364148347','0.077115186589777','366.76108907912516','366.761089079125156','test'),('2019-08-01 03:59:59','2019-08-01 11:59:59','BTSETH','4h','0.000211450000000','0.000208770000000','0.075215364148347','0.074262055205724','355.7122920233956','355.712292023395605','test'),('2019-08-10 07:59:59','2019-08-11 03:59:59','BTSETH','4h','0.000209060000000','0.000205960000000','0.075215364148347','0.074100049746453','359.7788393205156','359.778839320515601','test'),('2019-08-13 19:59:59','2019-08-13 23:59:59','BTSETH','4h','0.000206060000000','0.000203040000000','0.075215364148347','0.074113013378047','365.0168113575997','365.016811357599693','test'),('2019-08-14 07:59:59','2019-08-18 23:59:59','BTSETH','4h','0.000205390000000','0.000209370000000','0.075215364148347','0.076672870109253','366.2075278657529','366.207527865752922','test'),('2019-08-21 03:59:59','2019-08-21 07:59:59','BTSETH','4h','0.000214650000000','0.000213420000000','0.075215364148347','0.074784360664059','350.4093368196925','350.409336819692498','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','BTSETH','4h','0.000214090000000','0.000210220000000','0.075215364148347','0.073855732875265','351.3259103570788','351.325910357078783','test'),('2019-08-22 07:59:59','2019-08-22 15:59:59','BTSETH','4h','0.000212090000000','0.000208150000000','0.075215364148347','0.073818086885183','354.6388992802442','354.638899280244175','test'),('2019-08-23 07:59:59','2019-08-23 15:59:59','BTSETH','4h','0.000213140000000','0.000211950000000','0.075215364148347','0.074795422873427','352.8918276641972','352.891827664197194','test'),('2019-08-23 23:59:59','2019-08-24 11:59:59','BTSETH','4h','0.000212660000000','0.000212040000000','0.075215364148347','0.074996077372404','353.68834829468165','353.688348294681646','test'),('2019-08-24 15:59:59','2019-08-25 11:59:59','BTSETH','4h','0.000213110000000','0.000214590000000','0.075215364148347','0.075737717575871','352.94150508351083','352.941505083510833','test'),('2019-08-25 19:59:59','2019-08-25 23:59:59','BTSETH','4h','0.000214860000000','0.000213130000000','0.075215364148347','0.074609748491749','350.06685352483936','350.066853524839360','test'),('2019-09-11 11:59:59','2019-09-11 23:59:59','BTSETH','4h','0.000196510000000','0.000191000000000','0.075215364148347','0.073106379076557','382.755911395588','382.755911395587987','test'),('2019-09-12 07:59:59','2019-09-12 11:59:59','BTSETH','4h','0.000189880000000','0.000191250000000','0.075215364148347','0.075758049259382','396.1205190033021','396.120519003302093','test'),('2019-09-28 03:59:59','2019-09-28 19:59:59','BTSETH','4h','0.000169250000000','0.000165680000000','0.075215364148347','0.073628842139428','444.4039240670428','444.403924067042794','test'),('2019-09-29 03:59:59','2019-09-29 07:59:59','BTSETH','4h','0.000164320000000','0.000167610000000','0.075215364148347','0.076721319284959','457.73712359023244','457.737123590232443','test'),('2019-09-29 11:59:59','2019-09-30 11:59:59','BTSETH','4h','0.000169760000000','0.000168040000000','0.075215364148347','0.074453285765129','443.0688274525624','443.068827452562402','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','BTSETH','4h','0.000165890000000','0.000161090000000','0.075215364148347','0.073039019896662','453.4050524344264','453.405052434426409','test'),('2019-10-23 03:59:59','2019-10-23 19:59:59','BTSETH','4h','0.000155000000000','0.000151260000000','0.075215364148347','0.073400490200509','485.2604138603032','485.260413860303174','test'),('2019-10-24 03:59:59','2019-10-24 07:59:59','BTSETH','4h','0.000152690000000','0.000151410000000','0.075215364148347','0.074584833883694','492.6017692602462','492.601769260246215','test'),('2019-10-24 11:59:59','2019-10-24 15:59:59','BTSETH','4h','0.000151760000000','0.000152450000000','0.075215364148347','0.075557342280018','495.6204806823076','495.620480682307573','test'),('2019-10-24 23:59:59','2019-10-25 03:59:59','BTSETH','4h','0.000151930000000','0.000150210000000','0.075215364148347','0.074363850778143','495.06591290954384','495.065912909543840','test'),('2019-10-26 15:59:59','2019-10-29 19:59:59','BTSETH','4h','0.000158320000000','0.000157660000000','0.075215364148347','0.074901808436258','475.0844122558552','475.084412255855227','test'),('2019-10-31 19:59:59','2019-11-01 07:59:59','BTSETH','4h','0.000160040000000','0.000157000000000','0.075215364148347','0.073786629413212','469.97853129434515','469.978531294345146','test'),('2019-11-01 11:59:59','2019-11-03 03:59:59','BTSETH','4h','0.000159040000000','0.000158530000000','0.075215364148347','0.074974167998223','472.9336276933287','472.933627693328674','test'),('2019-11-30 03:59:59','2019-11-30 15:59:59','BTSETH','4h','0.000144210000000','0.000139300000000','0.075215364148347','0.072654463808784','521.568297263345','521.568297263345016','test'),('2019-11-30 19:59:59','2019-11-30 23:59:59','BTSETH','4h','0.000140210000000','0.000139850000000','0.075215364148347','0.075022242893847','536.4479291658727','536.447929165872665','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:24:30
