-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 11:59:59','2019-01-13 15:59:59','ETCETH','4h','0.036606000000000','0.035600000000000','0.072144500000000','0.070161836857346','1.9708381139703874','1.970838113970387','test'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ETCETH','4h','0.036415000000000','0.034218000000000','0.072144500000000','0.067791857778388','1.9811753398324865','1.981175339832487','test'),('2019-01-17 11:59:59','2019-01-19 23:59:59','ETCETH','4h','0.035560000000000','0.035382000000000','0.072144500000000','0.071783371737908','2.028810461192351','2.028810461192351','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','ETCETH','4h','0.035680000000000','0.035733000000000','0.072144500000000','0.072251665316704','2.021987107623318','2.021987107623318','test'),('2019-01-20 23:59:59','2019-01-27 11:59:59','ETCETH','4h','0.035929000000000','0.036621000000000','0.072144500000000','0.073534018049486','2.007974059951571','2.007974059951571','test'),('2019-01-27 23:59:59','2019-01-30 03:59:59','ETCETH','4h','0.037470000000000','0.036960000000000','0.072144500000000','0.071162549239392','1.9253936482519347','1.925393648251935','test'),('2019-03-02 11:59:59','2019-03-05 15:59:59','ETCETH','4h','0.032306000000000','0.031803000000000','0.072144500000000','0.071021220005572','2.2331610227202376','2.233161022720238','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','ETCETH','4h','0.032065000000000','0.031649000000000','0.072144500000000','0.071208522703883','2.249945423358802','2.249945423358802','test'),('2019-03-12 01:59:59','2019-03-12 11:59:59','ETCETH','4h','0.031727000000000','0.031717000000000','0.072144500000000','0.072121760850380','2.273914962019731','2.273914962019731','test'),('2019-03-12 15:59:59','2019-03-16 07:59:59','ETCETH','4h','0.031822000000000','0.031909000000000','0.072144500000000','0.072341740006913','2.2671265162466216','2.267126516246622','test'),('2019-03-19 15:59:59','2019-03-25 11:59:59','ETCETH','4h','0.032903000000000','0.034853000000000','0.072144500000000','0.076420151916239','2.192642008327508','2.192642008327508','test'),('2019-04-05 19:59:59','2019-04-06 11:59:59','ETCETH','4h','0.034817000000000','0.034531000000000','0.072144500000000','0.071551877803946','2.0721055806071744','2.072105580607174','test'),('2019-04-06 19:59:59','2019-04-10 15:59:59','ETCETH','4h','0.035215000000000','0.039177000000000','0.072144500000000','0.080261396464575','2.048686639216243','2.048686639216243','test'),('2019-04-10 23:59:59','2019-04-11 03:59:59','ETCETH','4h','0.039653000000000','0.038830000000000','0.073077867182683','0.071561132391082','1.842934133172345','1.842934133172345','test'),('2019-04-29 15:59:59','2019-05-01 19:59:59','ETCETH','4h','0.036548000000000','0.036325000000000','0.073077867182683','0.072631977821248','1.9995038629386834','1.999503862938683','test'),('2019-05-28 19:59:59','2019-05-29 07:59:59','ETCETH','4h','0.030105000000000','0.029745000000000','0.073077867182683','0.072203991341933','2.4274328909710348','2.427432890971035','test'),('2019-05-29 11:59:59','2019-06-04 19:59:59','ETCETH','4h','0.029770000000000','0.032536000000000','0.073077867182683','0.079867701936707','2.4547486457065166','2.454748645706517','test'),('2019-06-08 23:59:59','2019-06-10 19:59:59','ETCETH','4h','0.034529000000000','0.033631000000000','0.074066200872743','0.072139951969394','2.1450433222144434','2.145043322214443','test'),('2019-07-17 03:59:59','2019-07-18 15:59:59','ETCETH','4h','0.027283000000000','0.026394000000000','0.074066200872743','0.071652798659795','2.7147381472984273','2.714738147298427','test'),('2019-07-18 19:59:59','2019-07-19 07:59:59','ETCETH','4h','0.026995000000000','0.026194000000000','0.074066200872743','0.071868496597912','2.7437007176418966','2.743700717641897','test'),('2019-07-19 11:59:59','2019-07-19 23:59:59','ETCETH','4h','0.026443000000000','0.026501000000000','0.074066200872743','0.074228657464303','2.800975716550429','2.800975716550429','test'),('2019-07-20 03:59:59','2019-07-25 03:59:59','ETCETH','4h','0.026663000000000','0.027791000000000','0.074066200872743','0.077199632016442','2.7778644890951134','2.777864489095113','test'),('2019-07-26 23:59:59','2019-07-27 07:59:59','ETCETH','4h','0.028296000000000','0.027897000000000','0.074066200872743','0.073021798337112','2.6175502146148926','2.617550214614893','test'),('2019-07-27 11:59:59','2019-07-28 23:59:59','ETCETH','4h','0.028554000000000','0.027977000000000','0.074066200872743','0.072569520971378','2.5938993091245712','2.593899309124571','test'),('2019-07-29 19:59:59','2019-07-29 23:59:59','ETCETH','4h','0.028581000000000','0.028138000000000','0.074066200872743','0.072918189012184','2.5914488951661245','2.591448895166125','test'),('2019-08-10 11:59:59','2019-08-11 03:59:59','ETCETH','4h','0.027936000000000','0.027328000000000','0.074066200872743','0.072454221701400','2.651281531813538','2.651281531813538','test'),('2019-08-11 07:59:59','2019-08-11 19:59:59','ETCETH','4h','0.027518000000000','0.027152000000000','0.074066200872743','0.073081091870656','2.6915546505103203','2.691554650510320','test'),('2019-08-12 15:59:59','2019-08-17 23:59:59','ETCETH','4h','0.027499000000000','0.029371000000000','0.074066200872743','0.079108272512940','2.693414337712026','2.693414337712026','test'),('2019-08-20 15:59:59','2019-08-28 07:59:59','ETCETH','4h','0.030625000000000','0.036999000000000','0.074066200872743','0.089481644607041','2.418488191763037','2.418488191763037','test'),('2019-08-31 11:59:59','2019-09-01 03:59:59','ETCETH','4h','0.037346000000000','0.036440000000000','0.076798667184653','0.074935560226229','2.0564094463838902','2.056409446383890','test'),('2019-09-02 11:59:59','2019-09-07 03:59:59','ETCETH','4h','0.038114000000000','0.038415000000000','0.076798667184653','0.077405173949164','2.014972639572152','2.014972639572152','test'),('2019-10-21 19:59:59','2019-10-22 23:59:59','ETCETH','4h','0.026331000000000','0.026002000000000','0.076798667184653','0.075839084886079','2.9166635215013863','2.916663521501386','test'),('2019-10-23 03:59:59','2019-10-23 07:59:59','ETCETH','4h','0.026307000000000','0.025963000000000','0.076798667184653','0.075794419588518','2.919324407368875','2.919324407368875','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','ETCETH','4h','0.026062000000000','0.026169000000000','0.076798667184653','0.077113971358882','2.9467679834491984','2.946767983449198','test'),('2019-10-23 19:59:59','2019-10-25 15:59:59','ETCETH','4h','0.026389000000000','0.026140000000000','0.076798667184653','0.076074014180410','2.910253029089886','2.910253029089886','test'),('2019-10-25 19:59:59','2019-10-25 23:59:59','ETCETH','4h','0.026417000000000','0.026128000000000','0.076798667184653','0.075958495521846','2.907168383414203','2.907168383414203','test'),('2019-10-28 15:59:59','2019-10-28 23:59:59','ETCETH','4h','0.026267000000000','0.026052000000000','0.076798667184653','0.076170056629786','2.9237700226387866','2.923770022638787','test'),('2019-10-29 03:59:59','2019-10-29 15:59:59','ETCETH','4h','0.027340000000000','0.026233000000000','0.076798667184653','0.073689079599671','2.8090222086559256','2.809022208655926','test'),('2019-10-31 03:59:59','2019-11-04 15:59:59','ETCETH','4h','0.026558000000000','0.026550000000000','0.076798667184653','0.076775533313975','2.891733834801303','2.891733834801303','test'),('2019-11-07 07:59:59','2019-11-08 15:59:59','ETCETH','4h','0.027000000000000','0.026962000000000','0.076798667184653','0.076690580171578','2.844395080913074','2.844395080913074','test'),('2019-11-08 19:59:59','2019-11-08 23:59:59','ETCETH','4h','0.027027000000000','0.027080000000000','0.076798667184653','0.076949269521604','2.8415535273856887','2.841553527385689','test'),('2019-11-09 03:59:59','2019-11-09 07:59:59','ETCETH','4h','0.027371000000000','0.026800000000000','0.076798667184653','0.075196532116061','2.805840750599284','2.805840750599284','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','ETCETH','4h','0.025851000000000','0.025478000000000','0.076798667184653','0.075690551333820','2.9708199754227307','2.970819975422731','test'),('2019-11-23 07:59:59','2019-11-23 11:59:59','ETCETH','4h','0.025630000000000','0.025901000000000','0.076798667184653','0.077610701472872','2.9964364878912604','2.996436487891260','test'),('2019-11-23 15:59:59','2019-11-25 23:59:59','ETCETH','4h','0.026249000000000','0.025891000000000','0.076798667184653','0.075751239745432','2.9257749698903956','2.925774969890396','test'),('2019-11-26 07:59:59','2019-11-27 07:59:59','ETCETH','4h','0.026347000000000','0.025951000000000','0.076798667184653','0.075644369837512','2.914892290759973','2.914892290759973','test'),('2019-11-29 19:59:59','2019-11-30 11:59:59','ETCETH','4h','0.026451000000000','0.026009000000000','0.076798667184653','0.075515350451992','2.9034315218575104','2.903431521857510','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','ETCETH','4h','0.026282000000000','0.026175000000000','0.076798667184653','0.076486002342223','2.92210133112598','2.922101331125980','test'),('2019-12-07 07:59:59','2019-12-08 03:59:59','ETCETH','4h','0.026348000000000','0.026149000000000','0.076798667184653','0.076218625634260','2.91478166026465','2.914781660264650','test'),('2019-12-08 07:59:59','2019-12-08 15:59:59','ETCETH','4h','0.026155000000000','0.026089000000000','0.076798667184653','0.076604872039014','2.9362900854388454','2.936290085438845','test'),('2019-12-11 19:59:59','2019-12-23 23:59:59','ETCETH','4h','0.026433000000000','0.031239000000000','0.076798667184653','0.090762061218226','2.9054086628325577','2.905408662832558','test'),('2019-12-25 07:59:59','2019-12-30 03:59:59','ETCETH','4h','0.032154000000000','0.034286000000000','0.076798667184653','0.081890872149437','2.3884638671597003','2.388463867159700','test'),('2019-12-30 19:59:59','2020-01-01 03:59:59','ETCETH','4h','0.035100000000000','0.034751000000000','0.077897935195046','0.077123394471882','2.2193143930212464','2.219314393021246','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 23:45:30
