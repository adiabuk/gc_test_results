-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 07:59:59','2019-01-14 03:59:59','ZENETH','4h','0.037010000000000','0.036070000000000','0.072144500000000','0.070312134963523','1.9493245068900296','1.949324506890030','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','ZENETH','4h','0.037000000000000','0.036140000000000','0.072144500000000','0.070467627837838','1.9498513513513513','1.949851351351351','test'),('2019-01-17 15:59:59','2019-01-22 23:59:59','ZENETH','4h','0.037500000000000','0.039220000000000','0.072144500000000','0.075453527733333','1.9238533333333334','1.923853333333333','test'),('2019-01-28 23:59:59','2019-01-29 11:59:59','ZENETH','4h','0.039620000000000','0.038200000000000','0.072144500000000','0.069558806158506','1.8209111559818272','1.820911155981827','test'),('2019-01-29 15:59:59','2019-01-30 15:59:59','ZENETH','4h','0.039530000000000','0.039480000000000','0.072144500000000','0.072053247154060','1.8250569187958512','1.825056918795851','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','ZENETH','4h','0.039060000000000','0.038740000000000','0.072144500000000','0.071553454429083','1.8470174091141833','1.847017409114183','test'),('2019-02-09 03:59:59','2019-02-09 07:59:59','ZENETH','4h','0.037540000000000','0.037760000000000','0.072144500000000','0.072567296750133','1.9218034096963241','1.921803409696324','test'),('2019-02-12 15:59:59','2019-02-13 03:59:59','ZENETH','4h','0.038560000000000','0.038000000000000','0.072144500000000','0.071096758298755','1.8709673236514524','1.870967323651452','test'),('2019-02-13 11:59:59','2019-02-14 11:59:59','ZENETH','4h','0.038300000000000','0.037570000000000','0.072144500000000','0.070769422062663','1.8836684073107048','1.883668407310705','test'),('2019-02-25 07:59:59','2019-03-04 07:59:59','ZENETH','4h','0.037660000000000','0.040570000000000','0.072144500000000','0.077719128120021','1.915679766330324','1.915679766330324','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','ZENETH','4h','0.041270000000000','0.040660000000000','0.072171100876979','0.071104360592633','1.7487545645015448','1.748754564501545','test'),('2019-03-05 07:59:59','2019-03-05 19:59:59','ZENETH','4h','0.041640000000000','0.040360000000000','0.072171100876979','0.069952584807754','1.7332156790821085','1.733215679082108','test'),('2019-03-10 23:59:59','2019-03-16 07:59:59','ZENETH','4h','0.040000000000000','0.043050000000000','0.072171100876979','0.077674147318849','1.804277521924475','1.804277521924475','test'),('2019-03-16 23:59:59','2019-03-22 15:59:59','ZENETH','4h','0.045860000000000','0.048420000000000','0.072725548399053','0.076785238846100','1.5858165808777476','1.585816580877748','test'),('2019-03-26 19:59:59','2019-03-29 19:59:59','ZENETH','4h','0.048600000000000','0.048730000000000','0.073740471010815','0.073937719184301','1.5172936421978445','1.517293642197844','test'),('2019-04-01 15:59:59','2019-04-02 07:59:59','ZENETH','4h','0.050920000000000','0.049040000000000','0.073789783054187','0.071065415573003','1.4491316389274695','1.449131638927470','test'),('2019-04-12 11:59:59','2019-04-13 11:59:59','ZENETH','4h','0.046710000000000','0.046310000000000','0.073789783054187','0.073157885961023','1.579742732909163','1.579742732909163','test'),('2019-04-13 15:59:59','2019-04-13 23:59:59','ZENETH','4h','0.046600000000000','0.045720000000000','0.073789783054187','0.072396327923550','1.583471739360236','1.583471739360236','test'),('2019-04-25 03:59:59','2019-04-29 11:59:59','ZENETH','4h','0.043560000000000','0.045800000000000','0.073789783054187','0.077584298987185','1.6939803272311065','1.693980327231106','test'),('2019-05-01 03:59:59','2019-05-07 03:59:59','ZENETH','4h','0.048400000000000','0.053690000000000','0.073789783054187','0.081854823392134','1.5245822945079959','1.524582294507996','test'),('2019-05-07 15:59:59','2019-05-11 23:59:59','ZENETH','4h','0.056570000000000','0.061730000000000','0.075567242195677','0.082460064711669','1.3358183170527973','1.335818317052797','test'),('2019-05-12 19:59:59','2019-05-13 03:59:59','ZENETH','4h','0.064810000000000','0.062050000000000','0.077290447824675','0.073998955215570','1.1925697859076492','1.192569785907649','test'),('2019-05-13 07:59:59','2019-05-14 03:59:59','ZENETH','4h','0.064460000000000','0.059470000000000','0.077290447824675','0.071307212723137','1.1990451105286222','1.199045110528622','test'),('2019-06-10 11:59:59','2019-06-11 23:59:59','ZENETH','4h','0.043290000000000','0.041990000000000','0.077290447824675','0.074969413355466','1.7854111301611224','1.785411130161122','test'),('2019-06-13 03:59:59','2019-06-13 07:59:59','ZENETH','4h','0.042670000000000','0.041660000000000','0.077290447824675','0.075460980932176','1.8113533589096553','1.811353358909655','test'),('2019-06-20 03:59:59','2019-06-20 11:59:59','ZENETH','4h','0.041930000000000','0.040080000000000','0.077290447824675','0.073880304049916','1.843320959329239','1.843320959329239','test'),('2019-07-24 19:59:59','2019-07-29 07:59:59','ZENETH','4h','0.030370000000000','0.032920000000000','0.077290447824675','0.083780096884699','2.5449604156955874','2.544960415695587','test'),('2019-08-04 07:59:59','2019-08-05 11:59:59','ZENETH','4h','0.038110000000000','0.032550000000000','0.077290447824675','0.066014276481059','2.0280883711538964','2.028088371153896','test'),('2019-08-29 03:59:59','2019-08-31 11:59:59','ZENETH','4h','0.029010000000000','0.028000000000000','0.077290447824675','0.074599535990724','2.664269142525853','2.664269142525853','test'),('2019-09-24 23:59:59','2019-09-26 15:59:59','ZENETH','4h','0.023520000000000','0.020290000000000','0.077290447824675','0.066676155882766','3.286158495947066','3.286158495947066','test'),('2019-10-06 23:59:59','2019-10-07 03:59:59','ZENETH','4h','0.020040000000000','0.019700000000000','0.077290447824675','0.075979132841622','3.856808773686377','3.856808773686377','test'),('2019-10-16 03:59:59','2019-10-16 15:59:59','ZENETH','4h','0.019260000000000','0.018950000000000','0.077290447824675','0.076046416733001','4.013003521530374','4.013003521530374','test'),('2019-10-17 23:59:59','2019-10-18 07:59:59','ZENETH','4h','0.019190000000000','0.019040000000000','0.077290447824675','0.076686301541522','4.027641887684992','4.027641887684992','test'),('2019-10-18 15:59:59','2019-10-18 19:59:59','ZENETH','4h','0.019110000000000','0.018800000000000','0.077290447824675','0.076036651967760','4.0445027642425435','4.044502764242544','test'),('2019-10-18 23:59:59','2019-10-23 19:59:59','ZENETH','4h','0.019050000000000','0.022570000000000','0.077290447824675','0.091571937396478','4.057241355625984','4.057241355625984','test'),('2019-10-24 11:59:59','2019-10-25 19:59:59','ZENETH','4h','0.024110000000000','0.022550000000000','0.077290447824675','0.072289489773804','3.2057423403017418','3.205742340301742','test'),('2019-10-26 07:59:59','2019-10-29 11:59:59','ZENETH','4h','0.025800000000000','0.024900000000000','0.077290447824675','0.074594269412186','2.9957537916540695','2.995753791654070','test'),('2019-10-30 07:59:59','2019-10-31 15:59:59','ZENETH','4h','0.026530000000000','0.025570000000000','0.077290447824675','0.074493658155934','2.9133225716047866','2.913322571604787','test'),('2019-11-01 03:59:59','2019-11-03 03:59:59','ZENETH','4h','0.028260000000000','0.026560000000000','0.077290447824675','0.072640987056736','2.7349769223168785','2.734976922316879','test'),('2019-11-03 23:59:59','2019-11-04 07:59:59','ZENETH','4h','0.027170000000000','0.026410000000000','0.077290447824675','0.075128477256153','2.8446981164768124','2.844698116476812','test'),('2019-11-07 23:59:59','2019-11-08 15:59:59','ZENETH','4h','0.028050000000000','0.025980000000000','0.077290447824675','0.071586660765956','2.7554526853716577','2.755452685371658','test'),('2019-11-08 19:59:59','2019-11-08 23:59:59','ZENETH','4h','0.026080000000000','0.026340000000000','0.077290447824675','0.078060981430289','2.9635907908234276','2.963590790823428','test'),('2019-11-09 15:59:59','2019-11-09 19:59:59','ZENETH','4h','0.026490000000000','0.026020000000000','0.077290447824675','0.075919118625823','2.91772169968573','2.917721699685730','test'),('2019-11-13 01:59:59','2019-11-13 07:59:59','ZENETH','4h','0.026460000000000','0.025910000000000','0.077290447824675','0.075683881448879','2.9210297741751696','2.921029774175170','test'),('2019-11-13 11:59:59','2019-11-17 19:59:59','ZENETH','4h','0.026530000000000','0.029870000000000','0.077290447824675','0.087020945213835','2.9133225716047866','2.913322571604787','test'),('2019-11-21 03:59:59','2019-11-25 11:59:59','ZENETH','4h','0.033350000000000','0.032270000000000','0.077290447824675','0.074787488794671','2.317554657411544','2.317554657411544','test'),('2019-11-25 19:59:59','2019-11-30 11:59:59','ZENETH','4h','0.034440000000000','0.035950000000000','0.077290447824675','0.080679198585861','2.2442058021101916','2.244205802110192','test'),('2019-11-30 19:59:59','2019-12-01 15:59:59','ZENETH','4h','0.037680000000000','0.036050000000000','0.077290447824675','0.073946938537143','2.0512326917376593','2.051232691737659','test'),('2019-12-02 23:59:59','2019-12-03 15:59:59','ZENETH','4h','0.037140000000000','0.036140000000000','0.077290447824675','0.075209391071183','2.0810567534915183','2.081056753491518','test'),('2019-12-06 23:59:59','2019-12-08 15:59:59','ZENETH','4h','0.037910000000000','0.036390000000000','0.077290447824675','0.074191490275387','2.038787861373648','2.038787861373648','test'),('2019-12-09 07:59:59','2019-12-13 23:59:59','ZENETH','4h','0.036520000000000','0.041060000000000','0.077290447824675','0.086898844131466','2.116386851716183','2.116386851716183','test'),('2019-12-14 15:59:59','2019-12-20 23:59:59','ZENETH','4h','0.042200000000000','0.053830000000000','0.077290447824675','0.098591109156452','1.831527199636848','1.831527199636848','test'),('2019-12-22 19:59:59','2019-12-23 03:59:59','ZENETH','4h','0.060060000000000','0.052140000000000','0.077290447824675','0.067098300858784','1.2868872431680818','1.286887243168082','test'),('2019-12-29 19:59:59','2020-01-01 15:59:59','ZENETH','4h','0.059590000000000','0.068040000000000','0.077290447824675','0.088250412317350','1.2970372180680483','1.297037218068048','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 12:54:15
