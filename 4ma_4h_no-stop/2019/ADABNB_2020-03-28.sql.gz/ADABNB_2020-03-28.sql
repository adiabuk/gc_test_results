-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-04 15:59:59','ADABNB','4h','0.007330000000000','0.007080000000000','0.711908500000000','0.687627855388813','97.12257844474762','97.122578444747617','test'),('2019-01-04 23:59:59','2019-01-05 07:59:59','ADABNB','4h','0.007270000000000','0.007150000000000','0.711908500000000','0.700157603163686','97.92414030261348','97.924140302613480','test'),('2019-01-05 15:59:59','2019-01-08 11:59:59','ADABNB','4h','0.007250000000000','0.007500000000000','0.711908500000000','0.736457068965517','98.19427586206896','98.194275862068963','test'),('2019-01-09 15:59:59','2019-01-10 15:59:59','ADABNB','4h','0.007910000000000','0.007430000000000','0.711908500000000','0.668707984197219','90.00107458912768','90.001074589127683','test'),('2019-03-19 19:59:59','2019-03-24 11:59:59','ADABNB','4h','0.003410000000000','0.003600000000000','0.711908500000000','0.751574956011730','208.77082111436954','208.770821114369539','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','ADABNB','4h','0.003660000000000','0.003550000000000','0.711908500000000','0.690512342896175','194.51051912568306','194.510519125683061','test'),('2019-03-26 23:59:59','2019-03-31 11:59:59','ADABNB','4h','0.003810000000000','0.004090000000000','0.711908500000000','0.764227234908136','186.85262467191603','186.852624671916033','test'),('2019-04-02 15:59:59','2019-04-09 11:59:59','ADABNB','4h','0.004240000000000','0.004620000000000','0.715884886382819','0.780044380917128','168.8407750902875','168.840775090287508','test'),('2019-04-10 15:59:59','2019-04-12 07:59:59','ADABNB','4h','0.004800000000000','0.004670000000000','0.731924760016396','0.712101797765952','152.4843250034159','152.484325003415904','test'),('2019-05-09 15:59:59','2019-05-13 07:59:59','ADABNB','4h','0.003160000000000','0.003150000000000','0.731924760016396','0.729608542421407','231.62175949885946','231.621759498859461','test'),('2019-05-14 19:59:59','2019-05-15 02:59:59','ADABNB','4h','0.003420000000000','0.003370000000000','0.731924760016396','0.721224105630191','214.0130877240924','214.013087724092401','test'),('2019-05-15 19:59:59','2019-05-16 23:59:59','ADABNB','4h','0.003390000000000','0.003350000000000','0.731924760016396','0.723288479662220','215.9070088543941','215.907008854394093','test'),('2019-05-17 03:59:59','2019-05-17 07:59:59','ADABNB','4h','0.003360000000000','0.003230000000000','0.731924760016396','0.703606242515762','217.83475000487974','217.834750004879737','test'),('2019-05-30 07:59:59','2019-05-30 23:59:59','ADABNB','4h','0.002790000000000','0.002660000000000','0.731924760016396','0.697820738940363','262.3386236617907','262.338623661790677','test'),('2019-05-31 03:59:59','2019-05-31 07:59:59','ADABNB','4h','0.002670000000000','0.002650000000000','0.731924760016396','0.726442177544363','274.1291236016464','274.129123601646427','test'),('2019-06-02 03:59:59','2019-06-04 11:59:59','ADABNB','4h','0.002820000000000','0.002770000000000','0.731924760016396','0.718947370654403','259.5477872398567','259.547787239856689','test'),('2019-06-12 23:59:59','2019-06-13 03:59:59','ADABNB','4h','0.002770000000000','0.002690000000000','0.731924760016396','0.710786138788486','264.2327653488794','264.232765348879411','test'),('2019-06-14 23:59:59','2019-06-15 11:59:59','ADABNB','4h','0.002780000000000','0.002710000000000','0.731924760016396','0.713494999872098','263.282287775682','263.282287775681993','test'),('2019-06-15 15:59:59','2019-06-17 07:59:59','ADABNB','4h','0.002780000000000','0.002730000000000','0.731924760016396','0.718760645627612','263.282287775682','263.282287775681993','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','ADABNB','4h','0.002790000000000','0.002720000000000','0.731924760016396','0.713561056360071','262.3386236617907','262.338623661790677','test'),('2019-06-25 15:59:59','2019-06-27 11:59:59','ADABNB','4h','0.002620000000000','0.002680000000000','0.731924760016396','0.748686395741962','279.3605954261053','279.360595426105306','test'),('2019-07-26 19:59:59','2019-07-31 15:59:59','ADABNB','4h','0.002158000000000','0.002174000000000','0.731924760016396','0.737351449618000','339.16810010027615','339.168100100276149','test'),('2019-08-22 15:59:59','2019-08-26 07:59:59','ADABNB','4h','0.001837000000000','0.001833000000000','0.731924760016396','0.730331020745810','398.4348176463777','398.434817646377724','test'),('2019-08-26 15:59:59','2019-08-28 19:59:59','ADABNB','4h','0.001920000000000','0.001953000000000','0.731924760016396','0.744504716829178','381.21081250853956','381.210812508539561','test'),('2019-08-28 23:59:59','2019-09-02 15:59:59','ADABNB','4h','0.001961000000000','0.002005000000000','0.731924760016396','0.748347345146799','373.2405711455359','373.240571145535910','test'),('2019-09-03 23:59:59','2019-09-05 15:59:59','ADABNB','4h','0.002088000000000','0.002020000000000','0.731924760016396','0.708088129900920','350.538678168772','350.538678168771980','test'),('2019-09-08 03:59:59','2019-09-18 11:59:59','ADABNB','4h','0.002083000000000','0.002256000000000','0.731924760016396','0.792713518289481','351.38010562476995','351.380105624769953','test'),('2019-09-18 15:59:59','2019-09-22 11:59:59','ADABNB','4h','0.002479000000000','0.002371000000000','0.731924760016396','0.700037759580022','295.2500040404986','295.250004040498595','test'),('2019-09-23 15:59:59','2019-09-24 03:59:59','ADABNB','4h','0.002479000000000','0.002406000000000','0.731924760016396','0.710371509721440','295.2500040404986','295.250004040498595','test'),('2019-09-25 23:59:59','2019-09-28 23:59:59','ADABNB','4h','0.002443000000000','0.002457000000000','0.731924760016396','0.736119171248582','299.60080229897505','299.600802298975054','test'),('2019-09-30 11:59:59','2019-10-01 03:59:59','ADABNB','4h','0.002519000000000','0.002442000000000','0.731924760016396','0.709551514077030','290.5616355761794','290.561635576179413','test'),('2019-10-02 19:59:59','2019-10-03 19:59:59','ADABNB','4h','0.002494000000000','0.002442000000000','0.731924760016396','0.716664099422630','293.4742421878091','293.474242187809125','test'),('2019-10-04 07:59:59','2019-10-09 07:59:59','ADABNB','4h','0.002477000000000','0.002479000000000','0.731924760016396','0.732515736810919','295.48839726136293','295.488397261362934','test'),('2019-11-06 07:59:59','2019-11-07 07:59:59','ADABNB','4h','0.002164000000000','0.002134000000000','0.731924760016396','0.721777928777721','338.2277079558207','338.227707955820676','test'),('2019-11-07 11:59:59','2019-11-07 23:59:59','ADABNB','4h','0.002142000000000','0.002126000000000','0.731924760016396','0.726457534918234','341.7015686351055','341.701568635105502','test'),('2019-11-08 03:59:59','2019-11-08 07:59:59','ADABNB','4h','0.002140000000000','0.002122000000000','0.731924760016396','0.725768383530277','342.02091589551213','342.020915895512132','test'),('2019-11-08 19:59:59','2019-11-09 11:59:59','ADABNB','4h','0.002158000000000','0.002137000000000','0.731924760016396','0.724802229914290','339.16810010027615','339.168100100276149','test'),('2019-11-09 15:59:59','2019-11-10 03:59:59','ADABNB','4h','0.002141000000000','0.002146000000000','0.731924760016396','0.733634065854827','341.8611676863129','341.861167686312911','test'),('2019-11-11 11:59:59','2019-11-11 15:59:59','ADABNB','4h','0.002150000000000','0.002147000000000','0.731924760016396','0.730903469653582','340.4301209378586','340.430120937858590','test'),('2019-11-11 19:59:59','2019-11-12 19:59:59','ADABNB','4h','0.002148000000000','0.002114000000000','0.731924760016396','0.720339358787086','340.74709497970014','340.747094979700137','test'),('2019-11-16 19:59:59','2019-11-22 07:59:59','ADABNB','4h','0.002192000000000','0.002231000000000','0.731924760016396','0.744947143976542','333.9072810293777','333.907281029377714','test'),('2019-11-22 11:59:59','2019-11-24 15:59:59','ADABNB','4h','0.002284000000000','0.002338000000000','0.731924760016396','0.749229460997519','320.4574255763555','320.457425576355490','test'),('2019-11-25 15:59:59','2019-12-02 07:59:59','ADABNB','4h','0.002365000000000','0.002497000000000','0.731924760016396','0.772776374528939','309.481928125326','309.481928125326021','test'),('2019-12-08 07:59:59','2019-12-09 03:59:59','ADABNB','4h','0.002480000000000','0.002456000000000','0.731924760016396','0.724841617177527','295.1309516195145','295.130951619514519','test'),('2019-12-09 07:59:59','2019-12-09 11:59:59','ADABNB','4h','0.002457000000000','0.002446000000000','0.731924760016396','0.728647929588972','297.89367522034837','297.893675220348371','test'),('2019-12-11 07:59:59','2019-12-11 11:59:59','ADABNB','4h','0.002467000000000','0.002465000000000','0.731924760016396','0.731331387693724','296.68616133619616','296.686161336196164','test'),('2019-12-11 15:59:59','2019-12-16 19:59:59','ADABNB','4h','0.002471000000000','0.002522000000000','0.731924760016396','0.747031260526649','296.2058923579101','296.205892357910102','test'),('2019-12-16 23:59:59','2019-12-18 11:59:59','ADABNB','4h','0.002531000000000','0.002505000000000','0.731924760016396','0.724405975440961','289.1840221321201','289.184022132120106','test'),('2019-12-24 23:59:59','2019-12-27 11:59:59','ADABNB','4h','0.002542000000000','0.002477000000000','0.731924760016396','0.713209138694183','287.9326357263556','287.932635726355613','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:10:21
