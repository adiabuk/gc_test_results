-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 23:59:59','2019-01-12 07:59:59','LENDETH','4h','0.000056310000000','0.000055460000000','0.072144500000000','0.071055478067839','1281.2022731308825','1281.202273130882531','test'),('2019-01-12 11:59:59','2019-01-12 15:59:59','LENDETH','4h','0.000055840000000','0.000055500000000','0.072144500000000','0.071705224749284','1291.9860315186247','1291.986031518624713','test'),('2019-01-12 19:59:59','2019-01-20 11:59:59','LENDETH','4h','0.000057470000000','0.000067110000000','0.072144500000000','0.084245996084914','1255.3419175221857','1255.341917522185668','test'),('2019-01-22 11:59:59','2019-01-27 15:59:59','LENDETH','4h','0.000069660000000','0.000071030000000','0.074787799725509','0.076258647925681','1073.611824942711','1073.611824942711110','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','LENDETH','4h','0.000072330000000','0.000070520000000','0.075155511775552','0.073274805618857','1039.064174969615','1039.064174969614896','test'),('2019-02-02 19:59:59','2019-02-03 03:59:59','LENDETH','4h','0.000073720000000','0.000069100000000','0.075155511775552','0.070445548883487','1019.4724874600108','1019.472487460010825','test'),('2019-02-03 11:59:59','2019-02-03 15:59:59','LENDETH','4h','0.000070910000000','0.000070350000000','0.075155511775552','0.074561983548302','1059.8718343752928','1059.871834375292792','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','LENDETH','4h','0.000070890000000','0.000070660000000','0.075155511775552','0.074911672479341','1060.1708530900269','1060.170853090026867','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','LENDETH','4h','0.000057330000000','0.000056710000000','0.075155511775552','0.074342736312429','1310.9281663274378','1310.928166327437793','test'),('2019-03-01 19:59:59','2019-03-06 03:59:59','LENDETH','4h','0.000057900000000','0.000063330000000','0.075155511775552','0.082203774796990','1298.0226558817274','1298.022655881727360','test'),('2019-03-08 19:59:59','2019-03-16 07:59:59','LENDETH','4h','0.000066070000000','0.000068980000000','0.075155511775552','0.078465675832868','1137.5134217580144','1137.513421758014374','test'),('2019-03-27 15:59:59','2019-03-31 03:59:59','LENDETH','4h','0.000068980000000','0.000069690000000','0.075684915536405','0.076463928149204','1097.2008630966186','1097.200863096618605','test'),('2019-04-01 11:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000073210000000','0.000071990000000','0.075879668689604','0.074615180289094','1036.4659020571576','1036.465902057157564','test'),('2019-04-05 15:59:59','2019-04-06 15:59:59','LENDETH','4h','0.000072970000000','0.000069500000000','0.075879668689604','0.072271302918014','1039.874862129697','1039.874862129697021','test'),('2019-04-19 19:59:59','2019-04-19 23:59:59','LENDETH','4h','0.000065780000000','0.000065300000000','0.075879668689604','0.075325970894362','1153.5370734205533','1153.537073420553270','test'),('2019-04-20 11:59:59','2019-04-20 15:59:59','LENDETH','4h','0.000066200000000','0.000064980000000','0.075879668689604','0.074481282046080','1146.2185602659215','1146.218560265921496','test'),('2019-05-23 03:59:59','2019-05-24 15:59:59','LENDETH','4h','0.000039830000000','0.000038310000000','0.075879668689604','0.072983934408705','1905.0883426965602','1905.088342696560176','test'),('2019-06-08 11:59:59','2019-06-12 15:59:59','LENDETH','4h','0.000036250000000','0.000037870000000','0.075879668689604','0.079270704917939','2093.232239713214','2093.232239713213858','test'),('2019-06-16 23:59:59','2019-06-19 15:59:59','LENDETH','4h','0.000039380000000','0.000049770000000','0.075879668689604','0.095899723480995','1926.8580164957846','1926.858016495784568','test'),('2019-07-07 03:59:59','2019-07-07 19:59:59','LENDETH','4h','0.000027040000000','0.000024980000000','0.079302273221595','0.073260753885926','2932.7763765382674','2932.776376538267414','test'),('2019-07-24 03:59:59','2019-07-24 19:59:59','LENDETH','4h','0.000022500000000','0.000022190000000','0.079302273221595','0.078209664123875','3524.545476515333','3524.545476515333121','test'),('2019-07-25 23:59:59','2019-07-26 15:59:59','LENDETH','4h','0.000022800000000','0.000022200000000','0.079302273221595','0.077215371294711','3478.169878140132','3478.169878140131914','test'),('2019-08-15 23:59:59','2019-08-16 23:59:59','LENDETH','4h','0.000019200000000','0.000018200000000','0.079302273221595','0.075171946491304','4130.326730291406','4130.326730291406420','test'),('2019-08-17 03:59:59','2019-08-17 07:59:59','LENDETH','4h','0.000018210000000','0.000017900000000','0.079302273221595','0.077952261980590','4354.874970982702','4354.874970982701598','test'),('2019-08-21 15:59:59','2019-08-22 19:59:59','LENDETH','4h','0.000021600000000','0.000018500000000','0.079302273221595','0.067920928453681','3671.4015380368055','3671.401538036805505','test'),('2019-08-22 23:59:59','2019-08-23 07:59:59','LENDETH','4h','0.000018600000000','0.000020620000000','0.079302273221595','0.087914670635983','4263.5630764298385','4263.563076429838475','test'),('2019-08-23 23:59:59','2019-08-28 11:59:59','LENDETH','4h','0.000020040000000','0.000021900000000','0.079302273221595','0.086662663849947','3957.1992625546404','3957.199262554640427','test'),('2019-08-29 11:59:59','2019-08-30 03:59:59','LENDETH','4h','0.000023030000000','0.000022200000000','0.079302273221595','0.076444223426809','3443.4334876940943','3443.433487694094310','test'),('2019-09-09 19:59:59','2019-09-10 19:59:59','LENDETH','4h','0.000029340000000','0.000022450000000','0.079302273221595','0.060679483088780','2702.8722979412064','2702.872297941206398','test'),('2019-09-13 19:59:59','2019-09-14 15:59:59','LENDETH','4h','0.000023580000000','0.000021900000000','0.079302273221595','0.073652238488250','3363.1159127054707','3363.115912705470691','test'),('2019-09-15 19:59:59','2019-09-16 03:59:59','LENDETH','4h','0.000022300000000','0.000022100000000','0.079302273221595','0.078591042071626','3556.1557498473094','3556.155749847309380','test'),('2019-09-17 03:59:59','2019-09-17 07:59:59','LENDETH','4h','0.000022740000000','0.000021900000000','0.079302273221595','0.076372901651404','3487.347107370053','3487.347107370052981','test'),('2019-09-17 11:59:59','2019-09-17 19:59:59','LENDETH','4h','0.000022800000000','0.000021800000000','0.079302273221595','0.075824103343455','3478.169878140132','3478.169878140131914','test'),('2019-09-17 23:59:59','2019-09-19 23:59:59','LENDETH','4h','0.000023900000000','0.000023300000000','0.079302273221595','0.077311421174191','3318.086745673431','3318.086745673430869','test'),('2019-09-20 07:59:59','2019-09-22 11:59:59','LENDETH','4h','0.000024910000000','0.000024700000000','0.079302273221595','0.078633727361437','3183.5517150379364','3183.551715037936447','test'),('2019-09-22 15:59:59','2019-09-23 23:59:59','LENDETH','4h','0.000027500000000','0.000024670000000','0.079302273221595','0.071141348377336','2883.719026239818','2883.719026239818049','test'),('2019-09-26 19:59:59','2019-09-27 11:59:59','LENDETH','4h','0.000025100000000','0.000024600000000','0.079302273221595','0.077722546663396','3159.453116398207','3159.453116398206930','test'),('2019-09-27 15:59:59','2019-09-27 23:59:59','LENDETH','4h','0.000025300000000','0.000024500000000','0.079302273221595','0.076794691459647','3134.4772024345853','3134.477202434585251','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','LENDETH','4h','0.000024720000000','0.000024560000000','0.079302273221595','0.078788989899772','3208.0207613913835','3208.020761391383530','test'),('2019-09-28 11:59:59','2019-09-28 15:59:59','LENDETH','4h','0.000025200000000','0.000025300000000','0.079302273221595','0.079616964781998','3146.9156040315474','3146.915604031547446','test'),('2019-09-28 19:59:59','2019-09-29 15:59:59','LENDETH','4h','0.000026040000000','0.000025300000000','0.079302273221595','0.077048675595482','3045.4021974498846','3045.402197449884625','test'),('2019-09-29 19:59:59','2019-09-30 07:59:59','LENDETH','4h','0.000025530000000','0.000024500000000','0.079302273221595','0.076102847392443','3106.2386690793182','3106.238669079318242','test'),('2019-10-02 19:59:59','2019-10-08 15:59:59','LENDETH','4h','0.000025900000000','0.000028360000000','0.079302273221595','0.086834458245731','3061.863830949614','3061.863830949614112','test'),('2019-10-09 11:59:59','2019-10-09 15:59:59','LENDETH','4h','0.000030500000000','0.000026220000000','0.079302273221595','0.068173954225253','2600.0745318555737','2600.074531855573696','test'),('2019-10-11 19:59:59','2019-10-18 11:59:59','LENDETH','4h','0.000029180000000','0.000035500000000','0.079302273221595','0.096478091136622','2717.692708073852','2717.692708073851918','test'),('2019-10-18 23:59:59','2019-10-28 03:59:59','LENDETH','4h','0.000036400000000','0.000066700000000','0.079302273221595','0.145314879776934','2178.6338797141484','2178.633879714148406','test'),('2019-10-29 23:59:59','2019-10-31 07:59:59','LENDETH','4h','0.000078820000000','0.000070900000000','0.082970641194974','0.074633576005121','1052.6597461935328','1052.659746193532783','test'),('2019-11-04 11:59:59','2019-11-04 23:59:59','LENDETH','4h','0.000078000000000','0.000068640000000','0.082970641194974','0.073014164251577','1063.7261691663334','1063.726169166333420','test'),('2019-11-05 03:59:59','2019-11-05 15:59:59','LENDETH','4h','0.000070500000000','0.000069840000000','0.082970641194974','0.082193894766766','1176.8885275882838','1176.888527588283750','test'),('2019-11-05 23:59:59','2019-11-06 07:59:59','LENDETH','4h','0.000072430000000','0.000069420000000','0.082970641194974','0.079522599913780','1145.5286648484607','1145.528664848460721','test'),('2019-11-09 19:59:59','2019-11-20 19:59:59','LENDETH','4h','0.000077540000000','0.000105800000000','0.082970641194974','0.113209876688525','1070.0366416684808','1070.036641668480797','test'),('2019-11-29 19:59:59','2019-11-30 15:59:59','LENDETH','4h','0.000100900000000','0.000096600000000','0.084900867607699','0.081282693864259','841.4357542883944','841.435754288394378','test'),('2019-12-05 15:59:59','2019-12-05 19:59:59','LENDETH','4h','0.000097100000000','0.000096840000000','0.084900867607699','0.084673532637792','874.3652688743459','874.365268874345929','test'),('2019-12-06 03:59:59','2019-12-10 03:59:59','LENDETH','4h','0.000097500000000','0.000099370000000','0.084900867607699','0.086529222709508','870.7781293097332','870.778129309733231','test'),('2019-12-31 11:59:59','2020-01-01 15:59:59','LENDETH','4h','0.000087460000000','0.000153280000000','0.084900867607699','0.148794934677660','970.739396383478','970.739396383478038','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:14:48
