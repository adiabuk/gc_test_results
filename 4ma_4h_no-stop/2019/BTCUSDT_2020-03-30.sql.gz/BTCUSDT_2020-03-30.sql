-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3824.980000000000018','3756.000000000000000','15.000000000000000','14.729488781640688','0.003921589132492196','0.003921589132492','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','BTCUSDT','4h','3766.780000000000200','3780.039999999999964','15.000000000000000','15.052803720949989','0.003982181067118334','0.003982181067118','test'),('2019-01-04 07:59:59','2019-01-04 11:59:59','BTCUSDT','4h','3783.280000000000200','3757.550000000000182','15.000000000000000','14.897985346048930','0.003964813600896577','0.003964813600897','test'),('2019-01-05 03:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3815.000000000000000','3770.960000000000036','15.000000000000000','14.826841415465267','0.003931847968545216','0.003931847968545','test'),('2019-01-06 03:59:59','2019-01-06 07:59:59','BTCUSDT','4h','3771.150000000000091','3767.940000000000055','15.000000000000000','14.987232011455390','0.003977566524800127','0.003977566524800','test'),('2019-01-06 11:59:59','2019-01-10 07:59:59','BTCUSDT','4h','3814.239999999999782','3777.019999999999982','15.000000000000000','14.853627459205505','0.003932631402323923','0.003932631402324','test'),('2019-02-09 07:59:59','2019-02-13 15:59:59','BTCUSDT','4h','3660.860000000000127','3595.099999999999909','15.000000000000000','14.730555115464671','0.004097397879186858','0.004097397879187','test'),('2019-02-16 11:59:59','2019-02-24 15:59:59','BTCUSDT','4h','3626.010000000000218','3778.650000000000091','15.000000000000000','15.631437861451017','0.004136778442420181','0.004136778442420','test'),('2019-03-06 23:59:59','2019-03-08 23:59:59','BTCUSDT','4h','3861.840000000000146','3864.889999999999873','15.000000000000000','15.011846684482007','0.0038841588465601887','0.003884158846560','test'),('2019-03-09 03:59:59','2019-03-11 07:59:59','BTCUSDT','4h','3876.800000000000182','3885.500000000000000','15.000000000000000','15.033661782913741','0.0038691704498555507','0.003869170449856','test'),('2019-03-15 11:59:59','2019-03-21 15:59:59','BTCUSDT','4h','3914.050000000000182','3968.659999999999854','15.000000000000000','15.209284500708982','0.0038323475683754676','0.003832347568375','test'),('2019-03-23 23:59:59','2019-03-24 03:59:59','BTCUSDT','4h','4006.010000000000218','3988.000000000000000','15.000000000000000','14.932563822856157','0.003744374077947883','0.003744374077948','test'),('2019-03-27 23:59:59','2019-04-11 11:59:59','BTCUSDT','4h','4038.050000000000182','5001.909999999999854','15.000000000000000','18.580416290040983','0.0037146642562623047','0.003714664256262','test'),('2019-04-15 03:59:59','2019-04-15 19:59:59','BTCUSDT','4h','5136.880000000000109','5005.840000000000146','15.869436198170831','15.464612468706973','0.0030893141747852454','0.003089314174785','test'),('2019-04-16 19:59:59','2019-04-21 15:59:59','BTCUSDT','4h','5158.140000000000327','5239.420000000000073','15.869436198170831','16.119500712547588','0.003076581131603801','0.003076581131604','test'),('2019-04-22 15:59:59','2019-04-25 23:59:59','BTCUSDT','4h','5279.689999999999600','5219.899999999999636','15.869436198170831','15.689722315293496','0.003005751511579436','0.003005751511579','test'),('2019-05-01 11:59:59','2019-05-06 11:59:59','BTCUSDT','4h','5362.140000000000327','5701.670000000000073','15.869436198170831','16.874286812359372','0.0029595341035800688','0.002959534103580','test'),('2019-05-06 15:59:59','2019-05-17 03:59:59','BTCUSDT','4h','5730.979999999999563','7344.029999999999745','16.037030577226858','20.550836623068193','0.0027983051026572872','0.002798305102657','test'),('2019-05-19 11:59:59','2019-05-22 23:59:59','BTCUSDT','4h','7964.409999999999854','7628.430000000000291','17.165482088687192','16.441353286659531','0.002155273534221266','0.002155273534221','test'),('2019-05-24 07:59:59','2019-05-30 23:59:59','BTCUSDT','4h','7852.270000000000437','8269.540000000000873','17.165482088687192','18.077656620529130','0.0021860534709946537','0.002186053470995','test'),('2019-06-02 03:59:59','2019-06-03 07:59:59','BTCUSDT','4h','8544.100000000000364','8470.000000000000000','17.212493521140761','17.063215566772655','0.0020145472924170786','0.002014547292417','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','BTCUSDT','4h','8507.840000000000146','8473.659999999999854','17.212493521140761','17.143342828538103','0.002023133194928532','0.002023133194929','test'),('2019-06-13 15:59:59','2019-06-27 19:59:59','BTCUSDT','4h','8172.109999999999673','11022.010000000000218','17.212493521140761','23.215090804571730','0.0021062483888666162','0.002106248388867','test'),('2019-06-28 19:59:59','2019-06-29 03:59:59','BTCUSDT','4h','12368.430000000000291','11616.290000000000873','18.658535680255813','17.523886332962132','0.0015085613679550122','0.001508561367955','test'),('2019-06-30 03:59:59','2019-06-30 07:59:59','BTCUSDT','4h','12133.799999999999272','11731.190000000000509','18.658535680255813','18.039429295592495','0.0015377322586704754','0.001537732258670','test'),('2019-07-04 11:59:59','2019-07-04 23:59:59','BTCUSDT','4h','11672.129999999999200','11145.670000000000073','18.658535680255813','17.816960689724741','0.001598554478082048','0.001598554478082','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','BTCUSDT','4h','11154.559999999999491','10982.729999999999563','18.658535680255813','18.371110969111818','0.0016727271788627982','0.001672727178863','test'),('2019-07-06 15:59:59','2019-07-06 23:59:59','BTCUSDT','4h','11574.319999999999709','11256.489999999999782','18.658535680255813','18.146173623974693','0.0016120632296545987','0.001612063229655','test'),('2019-07-07 19:59:59','2019-07-08 03:59:59','BTCUSDT','4h','11474.180000000000291','11346.340000000000146','18.658535680255813','18.450650916258393','0.001626132384210097','0.001626132384210','test'),('2019-07-08 07:59:59','2019-07-10 23:59:59','BTCUSDT','4h','11420.549999999999272','12108.370000000000800','18.658535680255813','19.782274380370396','0.0016337685733397967','0.001633768573340','test'),('2019-08-01 23:59:59','2019-08-10 11:59:59','BTCUSDT','4h','10374.989999999999782','11395.229999999999563','18.658535680255813','20.493350407057878','0.0017984148110268842','0.001798414811027','test'),('2019-09-03 11:59:59','2019-09-06 23:59:59','BTCUSDT','4h','10424.500000000000000','10298.729999999999563','18.658535680255813','18.433423297646979','0.001789873440477319','0.001789873440477','test'),('2019-09-14 07:59:59','2019-09-14 15:59:59','BTCUSDT','4h','10319.000000000000000','10356.319999999999709','18.658535680255813','18.726016691166478','0.0018081728539835074','0.001808172853984','test'),('2019-09-14 19:59:59','2019-09-15 07:59:59','BTCUSDT','4h','10363.729999999999563','10308.420000000000073','18.658535680255813','18.558957284400755','0.0018003687552894387','0.001800368755289','test'),('2019-09-15 15:59:59','2019-09-15 23:59:59','BTCUSDT','4h','10307.969999999999345','10302.010000000000218','18.658535680255813','18.647747438472582','0.001810107681750705','0.001810107681751','test'),('2019-09-16 07:59:59','2019-09-16 11:59:59','BTCUSDT','4h','10302.250000000000000','10283.790000000000873','18.658535680255813','18.625102540052701','0.0018111126870592165','0.001811112687059','test'),('2019-10-10 07:59:59','2019-10-11 11:59:59','BTCUSDT','4h','8613.729999999999563','8297.500000000000000','18.658535680255813','17.973537573957231','0.0021661389061714046','0.002166138906171','test'),('2019-10-11 15:59:59','2019-10-11 19:59:59','BTCUSDT','4h','8343.469999999999345','8344.010000000000218','18.658535680255813','18.659743284438168','0.002236304041394745','0.002236304041395','test'),('2019-10-13 19:59:59','2019-10-13 23:59:59','BTCUSDT','4h','8434.020000000000437','8275.010000000000218','18.658535680255813','18.306758738949355','0.0022122944551063208','0.002212294455106','test'),('2019-10-22 11:59:59','2019-10-22 23:59:59','BTCUSDT','4h','8276.159999999999854','8020.000000000000000','18.658535680255813','18.081025035239968','0.0022544918996558567','0.002254491899656','test'),('2019-10-26 03:59:59','2019-10-30 11:59:59','BTCUSDT','4h','9554.049999999999272','9097.690000000000509','18.658535680255813','17.767289628263043','0.0019529451573160926','0.001952945157316','test'),('2019-11-02 03:59:59','2019-11-03 19:59:59','BTCUSDT','4h','9236.670000000000073','9135.120000000000800','18.658535680255813','18.453399597844083','0.0020200500483676274','0.002020050048368','test'),('2019-11-04 15:59:59','2019-11-07 07:59:59','BTCUSDT','4h','9295.159999999999854','9258.950000000000728','18.658535680255813','18.585849940905220','0.0020073388387349773','0.002007338838735','test'),('2019-12-07 11:59:59','2019-12-08 03:59:59','BTCUSDT','4h','7524.979999999999563','7403.909999999999854','18.658535680255813','18.358337019952586','0.002479546215439219','0.002479546215439','test'),('2019-12-08 07:59:59','2019-12-08 11:59:59','BTCUSDT','4h','7434.630000000000109','7520.029999999999745','18.658535680255813','18.872862277153551','0.002509679120582438','0.002509679120582','test'),('2019-12-08 15:59:59','2019-12-09 15:59:59','BTCUSDT','4h','7546.000000000000000','7424.000000000000000','18.658535680255813','18.356873693376510','0.0024726392367155864','0.002472639236716','test'),('2019-12-21 19:59:59','2019-12-24 19:59:59','BTCUSDT','4h','7145.819999999999709','7253.770000000000437','18.658535680255813','18.940405210510374','0.002611111906017198','0.002611111906017','test'),('2019-12-28 11:59:59','2019-12-30 15:59:59','BTCUSDT','4h','7308.279999999999745','7262.079999999999927','18.658535680255813','18.540583939432008','0.0025530679831993045','0.002553067983199','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  2:00:59
