-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-15 11:59:59','LRCETH','4h','0.000298000000000','0.000319000000000','0.072144500000000','0.077228508389262','242.09563758389262','242.095637583892625','test'),('2019-01-15 19:59:59','2019-01-24 15:59:59','LRCETH','4h','0.000336660000000','0.000682640000000','0.073415502097315','0.148863418142075','218.070166034918','218.070166034918003','test'),('2019-02-27 15:59:59','2019-03-05 07:59:59','LRCETH','4h','0.000436840000000','0.000423770000000','0.092277481108506','0.089516592274864','211.2386253742915','211.238625374291502','test'),('2019-03-08 15:59:59','2019-03-15 19:59:59','LRCETH','4h','0.000435510000000','0.000471900000000','0.092277481108506','0.099987929864077','211.88372507750913','211.883725077509126','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','LRCETH','4h','0.000462270000000','0.000441950000000','0.093514871088988','0.089404238384014','202.2949165833555','202.294916583355501','test'),('2019-03-28 15:59:59','2019-03-29 11:59:59','LRCETH','4h','0.000470740000000','0.000450000000000','0.093514871088988','0.089394765666917','198.65503481537155','198.655034815371550','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','LRCETH','4h','0.000450150000000','0.000445430000000','0.093514871088988','0.092534330843425','207.7415774497123','207.741577449712310','test'),('2019-03-30 07:59:59','2019-04-02 07:59:59','LRCETH','4h','0.000469430000000','0.000479580000000','0.093514871088988','0.095536846551897','199.2094052126792','199.209405212679201','test'),('2019-04-03 15:59:59','2019-04-08 07:59:59','LRCETH','4h','0.000506660000000','0.000520390000000','0.093514871088988','0.096049034393871','184.57125308685903','184.571253086859031','test'),('2019-05-24 03:59:59','2019-05-25 11:59:59','LRCETH','4h','0.000290270000000','0.000268140000000','0.093514871088988','0.086385356853279','322.1651258793123','322.165125879312313','test'),('2019-05-28 19:59:59','2019-05-28 23:59:59','LRCETH','4h','0.000272390000000','0.000274150000000','0.093514871088988','0.094119100954683','343.3124236902529','343.312423690252899','test'),('2019-06-09 07:59:59','2019-06-11 15:59:59','LRCETH','4h','0.000265740000000','0.000267380000000','0.093514871088988','0.094091993044982','351.903631703876','351.903631703875988','test'),('2019-06-11 23:59:59','2019-06-12 03:59:59','LRCETH','4h','0.000271830000000','0.000263770000000','0.093514871088988','0.090742072424465','344.01968542466983','344.019685424669831','test'),('2019-07-20 07:59:59','2019-07-20 19:59:59','LRCETH','4h','0.000180310000000','0.000171040000000','0.093514871088988','0.088707135217462','518.6338588485829','518.633858848582918','test'),('2019-07-20 23:59:59','2019-07-21 11:59:59','LRCETH','4h','0.000182750000000','0.000177250000000','0.093514871088988','0.090700470043902','511.70928092469495','511.709280924694951','test'),('2019-07-21 19:59:59','2019-07-21 23:59:59','LRCETH','4h','0.000176100000000','0.000175690000000','0.093514871088988','0.093297147652608','531.0327716580806','531.032771658080605','test'),('2019-07-22 03:59:59','2019-07-22 07:59:59','LRCETH','4h','0.000177020000000','0.000176310000000','0.093514871088988','0.093139797320639','528.2729131679358','528.272913167935826','test'),('2019-07-22 19:59:59','2019-07-23 07:59:59','LRCETH','4h','0.000180720000000','0.000175030000000','0.093514871088988','0.090570539435068','517.4572326747898','517.457232674789793','test'),('2019-07-23 11:59:59','2019-07-24 11:59:59','LRCETH','4h','0.000178000000000','0.000176450000000','0.093514871088988','0.092700556200292','525.3644443201573','525.364444320157304','test'),('2019-07-25 11:59:59','2019-07-28 15:59:59','LRCETH','4h','0.000179720000000','0.000200650000000','0.093514871088988','0.104405513487678','520.3364738982194','520.336473898219424','test'),('2019-07-29 15:59:59','2019-07-31 15:59:59','LRCETH','4h','0.000215390000000','0.000201250000000','0.093514871088988','0.087375773279441','434.1653330655462','434.165333065546179','test'),('2019-08-13 15:59:59','2019-08-17 11:59:59','LRCETH','4h','0.000185390000000','0.000190660000000','0.093514871088988','0.096173177203875','504.4224126920977','504.422412692097680','test'),('2019-08-17 19:59:59','2019-08-18 11:59:59','LRCETH','4h','0.000196890000000','0.000189850000000','0.093514871088988','0.090171152807377','474.95998318344255','474.959983183442546','test'),('2019-08-22 07:59:59','2019-08-22 19:59:59','LRCETH','4h','0.000194640000000','0.000191610000000','0.093514871088988','0.092059106295525','480.4504268854706','480.450426885470620','test'),('2019-08-22 23:59:59','2019-08-23 15:59:59','LRCETH','4h','0.000192200000000','0.000192280000000','0.093514871088988','0.093553795072792','486.5497975493652','486.549797549365223','test'),('2019-08-23 19:59:59','2019-08-26 03:59:59','LRCETH','4h','0.000192380000000','0.000196900000000','0.093514871088988','0.095712018491640','486.09455810888863','486.094558108888634','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','LRCETH','4h','0.000199310000000','0.000195900000000','0.093514871088988','0.091914922715031','469.1930715417591','469.193071541759082','test'),('2019-08-26 19:59:59','2019-08-27 11:59:59','LRCETH','4h','0.000202090000000','0.000195570000000','0.093514871088988','0.090497814532502','462.73873565732094','462.738735657320944','test'),('2019-08-31 11:59:59','2019-09-01 03:59:59','LRCETH','4h','0.000203010000000','0.000193880000000','0.093514871088988','0.089309212387237','460.64169789167033','460.641697891670333','test'),('2019-09-01 07:59:59','2019-09-01 11:59:59','LRCETH','4h','0.000194750000000','0.000193100000000','0.093514871088988','0.092722575647156','480.1790556559076','480.179055655907575','test'),('2019-09-05 07:59:59','2019-09-05 11:59:59','LRCETH','4h','0.000197640000000','0.000192850000000','0.093514871088988','0.091248446111674','473.1576153055454','473.157615305545391','test'),('2019-09-05 15:59:59','2019-09-06 03:59:59','LRCETH','4h','0.000202620000000','0.000194610000000','0.093514871088988','0.089818029131517','461.5283342660546','461.528334266054628','test'),('2019-09-07 11:59:59','2019-09-07 19:59:59','LRCETH','4h','0.000197150000000','0.000193430000000','0.093514871088988','0.091750350062100','474.3336093785848','474.333609378584811','test'),('2019-09-07 23:59:59','2019-09-08 03:59:59','LRCETH','4h','0.000194510000000','0.000189320000000','0.093514871088988','0.091019666827244','480.77153405474263','480.771534054742631','test'),('2019-09-24 19:59:59','2019-09-28 19:59:59','LRCETH','4h','0.000196210000000','0.000199130000000','0.093514871088988','0.094906560725499','476.6060399010652','476.606039901065174','test'),('2019-10-06 15:59:59','2019-10-06 23:59:59','LRCETH','4h','0.000193490000000','0.000190900000000','0.093514871088988','0.092263108640694','483.3059645924234','483.305964592423379','test'),('2019-10-28 03:59:59','2019-10-29 23:59:59','LRCETH','4h','0.000187630000000','0.000180720000000','0.093514871088988','0.090070924176315','498.40042151568514','498.400421515685139','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','LRCETH','4h','0.000183070000000','0.000175890000000','0.093514871088988','0.089847220603278','510.8148308788332','510.814830878833220','test'),('2019-10-30 19:59:59','2019-11-01 07:59:59','LRCETH','4h','0.000184810000000','0.000179150000000','0.093514871088988','0.090650880123328','506.00547096470973','506.005470964709730','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','LRCETH','4h','0.000183270000000','0.000181720000000','0.093514871088988','0.092723972141054','510.2573857641076','510.257385764107596','test'),('2019-11-30 03:59:59','2019-12-03 11:59:59','LRCETH','4h','0.000163030000000','0.000170220000000','0.093514871088988','0.097639093153208','573.6052940501012','573.605294050101179','test'),('2019-12-08 03:59:59','2019-12-08 11:59:59','LRCETH','4h','0.000166860000000','0.000167860000000','0.093514871088988','0.094075310206146','560.4391171580246','560.439117158024601','test'),('2019-12-09 07:59:59','2019-12-09 11:59:59','LRCETH','4h','0.000165860000000','0.000166860000000','0.093514871088988','0.094078689195156','563.8181061677801','563.818106167780115','test'),('2019-12-09 19:59:59','2019-12-09 23:59:59','LRCETH','4h','0.000169530000000','0.000167420000000','0.093514871088988','0.092350968664651','551.6125233822214','551.612523382221411','test'),('2019-12-16 11:59:59','2019-12-18 11:59:59','LRCETH','4h','0.000166770000000','0.000165340000000','0.093514871088988','0.092713010648518','560.7415667625352','560.741566762535172','test'),('2019-12-19 19:59:59','2019-12-21 11:59:59','LRCETH','4h','0.000171220000000','0.000168190000000','0.093514871088988','0.091859982294457','546.1679189871977','546.167918987197709','test'),('2019-12-21 19:59:59','2019-12-21 23:59:59','LRCETH','4h','0.000169530000000','0.000168070000000','0.093514871088988','0.092709516804850','551.6125233822214','551.612523382221411','test'),('2019-12-24 15:59:59','2019-12-26 11:59:59','LRCETH','4h','0.000173080000000','0.000170510000000','0.093514871088988','0.092126303844369','540.2985387623527','540.298538762352678','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','LRCETH','4h','0.000171160000000','0.000168070000000','0.093514871088988','0.091826620611861','546.3593777108437','546.359377710843660','test'),('2019-12-27 07:59:59','2019-12-28 23:59:59','LRCETH','4h','0.000172120000000','0.000170310000000','0.093514871088988','0.092531476267520','543.312056059656','543.312056059656015','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 14:09:02
