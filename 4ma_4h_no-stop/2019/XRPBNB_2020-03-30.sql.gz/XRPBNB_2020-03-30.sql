-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-31 03:59:59','2019-02-01 03:59:59','XRPBNB','4h','0.052950000000000','0.048730000000000','0.711908500000000','0.655170938715770','13.444919735599624','13.444919735599624','test'),('2019-02-26 19:59:59','2019-02-27 07:59:59','XRPBNB','4h','0.033690000000000','0.032350000000000','0.711908500000000','0.683592756752746','21.13115167705551','21.131151677055509','test'),('2019-04-07 03:59:59','2019-04-11 03:59:59','XRPBNB','4h','0.018990000000000','0.019110000000000','0.711908500000000','0.716407131911532','37.48859926276988','37.488599262769881','test'),('2019-05-07 15:59:59','2019-05-12 11:59:59','XRPBNB','4h','0.013820000000000','0.014990000000000','0.711908500000000','0.772178611794501','51.51291606367583','51.512916063675831','test'),('2019-05-14 11:59:59','2019-05-15 15:59:59','XRPBNB','4h','0.016320000000000','0.015990000000000','0.711908500000000','0.697513291360294','43.6218443627451','43.621844362745101','test'),('2019-05-15 19:59:59','2019-05-16 11:59:59','XRPBNB','4h','0.016360000000000','0.016170000000000','0.711908500000000','0.703640613997555','43.51518948655257','43.515189486552572','test'),('2019-05-16 15:59:59','2019-05-17 03:59:59','XRPBNB','4h','0.016570000000000','0.016210000000000','0.711908500000000','0.696441568195534','42.96369945684973','42.963699456849731','test'),('2019-05-29 15:59:59','2019-05-30 03:59:59','XRPBNB','4h','0.013430000000000','0.013070000000000','0.711908500000000','0.692825323529412','53.00882352941177','53.008823529411771','test'),('2019-05-30 07:59:59','2019-06-01 07:59:59','XRPBNB','4h','0.013570000000000','0.013060000000000','0.711908500000000','0.685152911569639','52.46193809874724','52.461938098747240','test'),('2019-06-02 23:59:59','2019-06-04 15:59:59','XRPBNB','4h','0.013400000000000','0.013380000000000','0.711908500000000','0.710845950000000','53.127500000000005','53.127500000000005','test'),('2019-06-04 23:59:59','2019-06-05 03:59:59','XRPBNB','4h','0.013640000000000','0.013340000000000','0.711908500000000','0.696250688416422','52.192705278592385','52.192705278592385','test'),('2019-06-07 15:59:59','2019-06-08 03:59:59','XRPBNB','4h','0.013520000000000','0.013190000000000','0.711908500000000','0.694532035133136','52.655954142011836','52.655954142011836','test'),('2019-06-16 23:59:59','2019-06-17 15:59:59','XRPBNB','4h','0.013270000000000','0.012630000000000','0.711908500000000','0.677573802185381','53.64796533534288','53.647965335342882','test'),('2019-06-17 23:59:59','2019-06-18 07:59:59','XRPBNB','4h','0.013210000000000','0.012670000000000','0.711908500000000','0.682807017032551','53.89163512490538','53.891635124905378','test'),('2019-06-24 11:59:59','2019-06-24 15:59:59','XRPBNB','4h','0.012570000000000','0.012300000000000','0.711908500000000','0.696616909307876','56.635521081941135','56.635521081941135','test'),('2019-06-24 19:59:59','2019-06-27 07:59:59','XRPBNB','4h','0.012430000000000','0.012470000000000','0.711908500000000','0.714199436444087','57.27341110217217','57.273411102172169','test'),('2019-06-27 11:59:59','2019-06-27 15:59:59','XRPBNB','4h','0.012660000000000','0.011900000000000','0.711908500000000','0.669171496840442','56.23289889415483','56.232898894154829','test'),('2019-07-17 11:59:59','2019-07-17 15:59:59','XRPBNB','4h','0.012190000000000','0.011430000000000','0.711908500000000','0.667523720672683','58.401025430680896','58.401025430680896','test'),('2019-07-17 19:59:59','2019-07-17 23:59:59','XRPBNB','4h','0.011500000000000','0.011220000000000','0.711908500000000','0.694575075652174','61.90508695652174','61.905086956521743','test'),('2019-07-18 03:59:59','2019-07-18 07:59:59','XRPBNB','4h','0.011270000000000','0.010850000000000','0.711908500000000','0.685377748447205','63.16845607808341','63.168456078083409','test'),('2019-07-26 23:59:59','2019-08-01 03:59:59','XRPBNB','4h','0.011170000000000','0.011400000000000','0.711908500000000','0.726567314234557','63.73397493285587','63.733974932855872','test'),('2019-08-04 03:59:59','2019-08-06 11:59:59','XRPBNB','4h','0.011430000000000','0.011480000000000','0.711908500000000','0.715022710411199','62.284208223972016','62.284208223972016','test'),('2019-08-23 15:59:59','2019-08-26 07:59:59','XRPBNB','4h','0.010140000000000','0.010050000000000','0.711908500000000','0.705589785502959','70.20793885601579','70.207938856015787','test'),('2019-08-26 15:59:59','2019-08-28 19:59:59','XRPBNB','4h','0.010410000000000','0.010800000000000','0.711908500000000','0.738579423631124','68.38698366954851','68.386983669548513','test'),('2019-08-28 23:59:59','2019-09-02 19:59:59','XRPBNB','4h','0.010960000000000','0.011640000000000','0.711908500000000','0.756078005474453','64.95515510948906','64.955155109489056','test'),('2019-09-04 07:59:59','2019-09-05 19:59:59','XRPBNB','4h','0.011880000000000','0.011140000000000','0.711908500000000','0.667564031144781','59.92495791245792','59.924957912457920','test'),('2019-09-08 15:59:59','2019-09-21 03:59:59','XRPBNB','4h','0.011730000000000','0.013710000000000','0.711908500000000','0.832077198209719','60.691261722080135','60.691261722080135','test'),('2019-09-21 15:59:59','2019-09-22 03:59:59','XRPBNB','4h','0.013920000000000','0.013650000000000','0.711908500000000','0.698099929956897','51.142852011494256','51.142852011494256','test'),('2019-09-23 15:59:59','2019-09-24 19:59:59','XRPBNB','4h','0.014200000000000','0.014630000000000','0.711908500000000','0.733466292605634','50.13440140845071','50.134401408450707','test'),('2019-09-24 23:59:59','2019-09-28 23:59:59','XRPBNB','4h','0.014710000000000','0.015380000000000','0.711908500000000','0.744333972127804','48.3962270564242','48.396227056424202','test'),('2019-09-29 11:59:59','2019-10-01 23:59:59','XRPBNB','4h','0.015550000000000','0.015660000000000','0.711908500000000','0.716944508681672','45.78189710610933','45.781897106109327','test'),('2019-10-04 03:59:59','2019-10-09 07:59:59','XRPBNB','4h','0.016080000000000','0.016360000000000','0.711908500000000','0.724304916666667','44.27291666666667','44.272916666666667','test'),('2019-10-18 11:59:59','2019-10-18 15:59:59','XRPBNB','4h','0.016120000000000','0.016010000000000','0.711908500000000','0.707050563585608','44.163058312655096','44.163058312655096','test'),('2019-10-18 19:59:59','2019-10-19 19:59:59','XRPBNB','4h','0.016030000000000','0.015960000000000','0.711908500000000','0.708799729257642','44.411010605115415','44.411010605115415','test'),('2019-10-19 23:59:59','2019-10-20 03:59:59','XRPBNB','4h','0.016010000000000','0.015870000000000','0.711908500000000','0.705683191442848','44.46648969394129','44.466489693941291','test'),('2019-10-22 03:59:59','2019-10-22 07:59:59','XRPBNB','4h','0.016240000000000','0.015950000000000','0.711908500000000','0.699195848214286','43.836730295566504','43.836730295566504','test'),('2019-10-23 07:59:59','2019-10-23 11:59:59','XRPBNB','4h','0.016080000000000','0.016110000000000','0.711908500000000','0.713236687500000','44.27291666666667','44.272916666666667','test'),('2019-10-23 15:59:59','2019-10-23 19:59:59','XRPBNB','4h','0.016280000000000','0.015990000000000','0.711908500000000','0.699227083230958','43.729023341523344','43.729023341523344','test'),('2019-10-23 23:59:59','2019-10-25 03:59:59','XRPBNB','4h','0.016360000000000','0.016070000000000','0.711908500000000','0.699289095048900','43.51518948655257','43.515189486552572','test'),('2019-11-20 11:59:59','2019-11-24 07:59:59','XRPBNB','4h','0.013600000000000','0.014260000000000','0.711908500000000','0.746457000735294','52.34621323529412','52.346213235294123','test'),('2019-11-24 15:59:59','2019-11-25 03:59:59','XRPBNB','4h','0.014860000000000','0.014460000000000','0.711908500000000','0.692745417900404','47.90770524899058','47.907705248990581','test'),('2019-11-25 07:59:59','2019-11-25 15:59:59','XRPBNB','4h','0.014520000000000','0.014270000000000','0.711908500000000','0.699651122245179','49.02951101928375','49.029511019283753','test'),('2019-11-30 15:59:59','2019-12-02 11:59:59','XRPBNB','4h','0.014460000000000','0.014370000000000','0.711908500000000','0.707477534232365','49.23295297372061','49.232952973720607','test'),('2019-12-02 19:59:59','2019-12-03 19:59:59','XRPBNB','4h','0.014530000000000','0.014350000000000','0.711908500000000','0.703089261871989','48.99576737783896','48.995767377838959','test'),('2019-12-07 07:59:59','2019-12-13 07:59:59','XRPBNB','4h','0.014460000000000','0.014800000000000','0.711908500000000','0.728647704011065','49.23295297372061','49.232952973720607','test'),('2019-12-14 15:59:59','2019-12-16 11:59:59','XRPBNB','4h','0.015060000000000','0.014910000000000','0.711908500000000','0.704817777888446','47.2714807436919','47.271480743691903','test'),('2019-12-16 15:59:59','2019-12-17 03:59:59','XRPBNB','4h','0.015020000000000','0.015050000000000','0.711908500000000','0.713330421105193','47.39737017310253','47.397370173102530','test'),('2019-12-17 11:59:59','2019-12-17 19:59:59','XRPBNB','4h','0.015070000000000','0.014780000000000','0.711908500000000','0.698208867285999','47.24011280690113','47.240112806901131','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  3:20:11
