-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-14 15:59:59','BATETH','4h','0.001002130000000','0.000973690000000','0.072144500000000','0.070097071442827','71.99115883168851','71.991158831688509','test'),('2019-01-16 15:59:59','2019-01-21 11:59:59','BATETH','4h','0.001030120000000','0.001023530000000','0.072144500000000','0.071682969057003','70.03504446083952','70.035044460839515','test'),('2019-01-21 23:59:59','2019-01-22 03:59:59','BATETH','4h','0.001047590000000','0.001028500000000','0.072144500000000','0.070829826792925','68.86711404270756','68.867114042707556','test'),('2019-01-22 11:59:59','2019-01-28 19:59:59','BATETH','4h','0.001054860000000','0.001072210000000','0.072144500000000','0.073331109668582','68.39248810268661','68.392488102686613','test'),('2019-01-30 03:59:59','2019-01-30 15:59:59','BATETH','4h','0.001093090000000','0.001067940000000','0.072144500000000','0.070484587115425','66.00051230914198','66.000512309141982','test'),('2019-02-07 15:59:59','2019-02-08 11:59:59','BATETH','4h','0.001179210000000','0.001045980000000','0.072144500000000','0.063993439768998','61.180366516566174','61.180366516566174','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','BATETH','4h','0.001055970000000','0.001015260000000','0.072144500000000','0.069363168527515','68.32059622905953','68.320596229059532','test'),('2019-02-15 11:59:59','2019-02-17 15:59:59','BATETH','4h','0.001072710000000','0.001036360000000','0.072144500000000','0.069699801456125','67.25443036794661','67.254430367946611','test'),('2019-02-17 19:59:59','2019-02-17 23:59:59','BATETH','4h','0.001080600000000','0.001032970000000','0.072144500000000','0.068964560582084','66.76337220062929','66.763372200629291','test'),('2019-02-18 03:59:59','2019-02-18 07:59:59','BATETH','4h','0.001038390000000','0.001046280000000','0.072144500000000','0.072692675642100','69.47726769325591','69.477267693255911','test'),('2019-02-26 07:59:59','2019-03-05 23:59:59','BATETH','4h','0.001325730000000','0.001285300000000','0.072144500000000','0.069944352055094','54.41869762319628','54.418697623196280','test'),('2019-03-08 03:59:59','2019-03-11 23:59:59','BATETH','4h','0.001388110000000','0.001440060000000','0.072144500000000','0.074844507041949','51.97318656302455','51.973186563024548','test'),('2019-03-13 03:59:59','2019-03-13 15:59:59','BATETH','4h','0.001467460000000','0.001441140000000','0.072144500000000','0.070850534072479','49.162839191528214','49.162839191528214','test'),('2019-03-21 19:59:59','2019-04-02 19:59:59','BATETH','4h','0.001435230000000','0.001914350000000','0.072144500000000','0.096228356134557','50.2668561833295','50.266856183329502','test'),('2019-04-13 19:59:59','2019-04-16 03:59:59','BATETH','4h','0.001887920000000','0.001819180000000','0.072890489839416','0.070236514950882','38.608886944052585','38.608886944052585','test'),('2019-04-16 11:59:59','2019-04-22 23:59:59','BATETH','4h','0.001920310000000','0.002337200000000','0.072890489839416','0.088714662139281','37.95766820951617','37.957668209516171','test'),('2019-04-24 03:59:59','2019-04-26 07:59:59','BATETH','4h','0.002529660000000','0.002389190000000','0.076183039192249','0.071952655854039','30.115920397305764','30.115920397305764','test'),('2019-04-28 03:59:59','2019-04-29 19:59:59','BATETH','4h','0.002596570000000','0.002455330000000','0.076183039192249','0.072039075249234','29.33987498594261','29.339874985942611','test'),('2019-06-08 07:59:59','2019-06-08 19:59:59','BATETH','4h','0.001398270000000','0.001372390000000','0.076183039192249','0.074772998889378','54.48378295482918','54.483782954829181','test'),('2019-06-08 23:59:59','2019-06-10 03:59:59','BATETH','4h','0.001378910000000','0.001375650000000','0.076183039192249','0.076002928301932','55.24873936098005','55.248739360980053','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','BATETH','4h','0.001378330000000','0.001358260000000','0.076183039192249','0.075073730393494','55.27198797983719','55.271987979837192','test'),('2019-07-02 03:59:59','2019-07-03 03:59:59','BATETH','4h','0.001166960000000','0.001052960000000','0.076183039192249','0.068740739140905','65.28333378371923','65.283333783719229','test'),('2019-07-12 11:59:59','2019-07-15 03:59:59','BATETH','4h','0.001067940000000','0.001049680000000','0.076183039192249','0.074880435772909','71.33644136585295','71.336441365852949','test'),('2019-07-15 07:59:59','2019-07-15 15:59:59','BATETH','4h','0.001053250000000','0.001060710000000','0.076183039192249','0.076722631380594','72.33139253951958','72.331392539519584','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','BATETH','4h','0.001079950000000','0.001048510000000','0.076183039192249','0.073965163594115','70.54311698898005','70.543116988980046','test'),('2019-07-19 03:59:59','2019-07-23 19:59:59','BATETH','4h','0.001119500000000','0.001089350000000','0.076183039192249','0.074131303031779','68.05095059602412','68.050950596024123','test'),('2019-07-26 19:59:59','2019-07-29 19:59:59','BATETH','4h','0.001146330000000','0.001207910000000','0.076183039192249','0.080275535727678','66.45820940937513','66.458209409375129','test'),('2019-08-22 19:59:59','2019-08-26 03:59:59','BATETH','4h','0.001038490000000','0.000994920000000','0.076183039192249','0.072986768628636','73.35943455618157','73.359434556181569','test'),('2019-08-28 19:59:59','2019-08-29 03:59:59','BATETH','4h','0.001040080000000','0.000994970000000','0.076183039192249','0.072878854035374','73.24728789347839','73.247287893478386','test'),('2019-08-30 07:59:59','2019-09-02 19:59:59','BATETH','4h','0.001030800000000','0.001013350000000','0.076183039192249','0.074893367060017','73.90671244882519','73.906712448825189','test'),('2019-09-21 15:59:59','2019-09-22 03:59:59','BATETH','4h','0.000989100000000','0.000932860000000','0.076183039192249','0.071851288990882','77.02258537281267','77.022585372812671','test'),('2019-09-22 07:59:59','2019-09-22 11:59:59','BATETH','4h','0.000933580000000','0.000955060000000','0.076183039192249','0.077935874173557','81.6031183104276','81.603118310427604','test'),('2019-09-22 19:59:59','2019-09-22 23:59:59','BATETH','4h','0.000932410000000','0.000906100000000','0.076183039192249','0.074033367093979','81.70551494755419','81.705514947554192','test'),('2019-09-23 07:59:59','2019-09-23 11:59:59','BATETH','4h','0.000965790000000','0.000937910000000','0.076183039192249','0.073983820798313','78.88157797476573','78.881577974765733','test'),('2019-09-23 15:59:59','2019-09-23 23:59:59','BATETH','4h','0.000958180000000','0.000928890000000','0.076183039192249','0.073854247923447','79.50806653473147','79.508066534731469','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','BATETH','4h','0.000951570000000','0.000928900000000','0.076183039192249','0.074368070773228','80.06036255057326','80.060362550573259','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','BATETH','4h','0.000967890000000','0.000938780000000','0.076183039192249','0.073891778541879','78.71043113602683','78.710431136026827','test'),('2019-09-25 03:59:59','2019-09-25 07:59:59','BATETH','4h','0.000958950000000','0.000952300000000','0.076183039192249','0.075654735098575','79.44422461259607','79.444224612596074','test'),('2019-09-26 07:59:59','2019-09-26 19:59:59','BATETH','4h','0.000965640000000','0.000940000000000','0.076183039192249','0.074160201359424','78.89383123342964','78.893831233429637','test'),('2019-09-27 19:59:59','2019-09-27 23:59:59','BATETH','4h','0.000976770000000','0.000965750000000','0.076183039192249','0.075323535837418','77.99485978505585','77.994859785055851','test'),('2019-09-28 07:59:59','2019-09-28 11:59:59','BATETH','4h','0.000943020000000','0.000937570000000','0.076183039192249','0.075742754189176','80.7862390959354','80.786239095935400','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','BATETH','4h','0.000946060000000','0.000938700000000','0.076183039192249','0.075590363073974','80.52664650471324','80.526646504713241','test'),('2019-09-28 23:59:59','2019-09-29 03:59:59','BATETH','4h','0.000948780000000','0.000948810000000','0.076183039192249','0.076185448065935','80.29578953208225','80.295789532082253','test'),('2019-09-29 11:59:59','2019-09-29 19:59:59','BATETH','4h','0.000946270000000','0.000942800000000','0.076183039192249','0.075903673740531','80.50877571121245','80.508775711212451','test'),('2019-10-02 15:59:59','2019-10-02 19:59:59','BATETH','4h','0.000953810000000','0.000941980000000','0.076183039192249','0.075238149378089','79.87234270163765','79.872342701637649','test'),('2019-10-03 07:59:59','2019-10-08 03:59:59','BATETH','4h','0.000968700000000','0.001068660000000','0.076183039192249','0.084044354973871','78.64461566248478','78.644615662484782','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','BATETH','4h','0.001132540000000','0.001052510000000','0.076183039192249','0.070799627898559','67.26741589016635','67.267415890166347','test'),('2019-10-13 07:59:59','2019-10-19 15:59:59','BATETH','4h','0.001086330000000','0.001245300000000','0.076183039192249','0.087331417438631','70.12881830774167','70.128818307741668','test'),('2019-10-20 23:59:59','2019-10-22 03:59:59','BATETH','4h','0.001289290000000','0.001250800000000','0.076183039192249','0.073908698137475','59.0891414594459','59.089141459445898','test'),('2019-10-22 07:59:59','2019-10-25 19:59:59','BATETH','4h','0.001277180000000','0.001379650000000','0.076183039192249','0.082295314694551','59.64941448523231','59.649414485232313','test'),('2019-11-05 11:59:59','2019-11-08 15:59:59','BATETH','4h','0.001329710000000','0.001273500000000','0.076183039192249','0.072962601177196','57.2929730484459','57.292973048445901','test'),('2019-11-10 03:59:59','2019-11-10 11:59:59','BATETH','4h','0.001358100000000','0.001331720000000','0.076183039192249','0.074703244940065','56.09530902897357','56.095309028973567','test'),('2019-11-14 03:59:59','2019-11-19 11:59:59','BATETH','4h','0.001375230000000','0.001389860000000','0.076183039192249','0.076993491162743','55.39658034819557','55.396580348195570','test'),('2019-11-23 11:59:59','2019-11-25 19:59:59','BATETH','4h','0.001471940000000','0.001430470000000','0.076183039192249','0.074036680892792','51.7568917158641','51.756891715864100','test'),('2019-12-15 15:59:59','2019-12-17 07:59:59','BATETH','4h','0.001289270000000','0.001273960000000','0.076183039192249','0.075278370402908','59.09005808887898','59.090058088878983','test'),('2019-12-17 11:59:59','2019-12-17 15:59:59','BATETH','4h','0.001303550000000','0.001286900000000','0.076183039192249','0.075209967501442','58.4427441925887','58.442744192588698','test'),('2019-12-19 15:59:59','2019-12-22 15:59:59','BATETH','4h','0.001288440000000','0.001303510000000','0.076183039192249','0.077074100010469','59.128123305896274','59.128123305896274','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','BATETH','4h','0.001335440000000','0.001283070000000','0.076183039192249','0.073195480213562','57.04714490523648','57.047144905236479','test'),('2019-12-26 23:59:59','2019-12-31 15:59:59','BATETH','4h','0.001311610000000','0.001408380000000','0.076183039192249','0.081803789798476','58.083606553967265','58.083606553967265','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:30:50
