-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 15:59:59','2019-01-04 23:59:59','WABIBTC','4h','0.000033230000000','0.000032720000000','0.001467500000000','0.001444977430033','44.16190189587722','44.161901895877222','test'),('2019-01-05 03:59:59','2019-01-05 15:59:59','WABIBTC','4h','0.000033040000000','0.000032780000000','0.001467500000000','0.001455951876513','44.41585956416465','44.415859564164649','test'),('2019-01-05 19:59:59','2019-01-07 03:59:59','WABIBTC','4h','0.000032930000000','0.000032200000000','0.001467500000000','0.001434968114182','44.56422714849682','44.564227148496819','test'),('2019-01-17 11:59:59','2019-01-20 19:59:59','WABIBTC','4h','0.000032520000000','0.000036300000000','0.001467500000000','0.001638076568266','45.12607626076261','45.126076260762609','test'),('2019-01-23 03:59:59','2019-01-24 19:59:59','WABIBTC','4h','0.000040370000000','0.000037000000000','0.001493493497249','0.001368819900872','36.99513245599455','36.995132455994550','test'),('2019-02-08 15:59:59','2019-02-12 15:59:59','WABIBTC','4h','0.000037110000000','0.000036460000000','0.001493493497249','0.001467334220148','40.245041693586636','40.245041693586636','test'),('2019-02-18 03:59:59','2019-02-18 15:59:59','WABIBTC','4h','0.000037150000000','0.000035160000000','0.001493493497249','0.001413492095916','40.20170921262449','40.201709212624493','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','WABIBTC','4h','0.000035290000000','0.000034120000000','0.001493493497249','0.001443978411055','42.32058649047889','42.320586490478888','test'),('2019-02-20 23:59:59','2019-02-21 11:59:59','WABIBTC','4h','0.000037680000000','0.000035440000000','0.001493493497249','0.001404708321192','39.6362393112792','39.636239311279198','test'),('2019-02-21 15:59:59','2019-02-21 19:59:59','WABIBTC','4h','0.000035620000000','0.000035650000000','0.001493493497249','0.001494751352525','41.928509187226275','41.928509187226275','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','WABIBTC','4h','0.000035530000000','0.000035510000000','0.001493493497249','0.001492652802908','42.03471706301717','42.034717063017169','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','WABIBTC','4h','0.000036020000000','0.000035610000000','0.001493493497249','0.001476493710079','41.46289553717379','41.462895537173793','test'),('2019-02-22 19:59:59','2019-02-23 15:59:59','WABIBTC','4h','0.000036450000000','0.000035550000000','0.001493493497249','0.001456617114601','40.97375849791496','40.973758497914957','test'),('2019-02-26 03:59:59','2019-03-03 19:59:59','WABIBTC','4h','0.000036280000000','0.000041290000000','0.001493493497249','0.001699733916797','41.165752404878724','41.165752404878724','test'),('2019-03-05 07:59:59','2019-03-11 07:59:59','WABIBTC','4h','0.000043910000000','0.000052020000000','0.001493493497249','0.001769335725960','34.012605266431336','34.012605266431336','test'),('2019-03-12 23:59:59','2019-03-14 03:59:59','WABIBTC','4h','0.000058190000000','0.000053470000000','0.001508365772827','0.001386016804830','25.92139152478089','25.921391524780891','test'),('2019-03-15 19:59:59','2019-03-16 19:59:59','WABIBTC','4h','0.000055950000000','0.000054110000000','0.001508365772827','0.001458760893077','26.959173777068813','26.959173777068813','test'),('2019-03-19 11:59:59','2019-03-21 15:59:59','WABIBTC','4h','0.000056790000000','0.000056530000000','0.001508365772827','0.001501460065820','26.560411565891886','26.560411565891886','test'),('2019-03-21 19:59:59','2019-03-23 23:59:59','WABIBTC','4h','0.000056590000000','0.000057530000000','0.001508365772827','0.001533420797150','26.65428119503446','26.654281195034461','test'),('2019-03-27 15:59:59','2019-04-01 07:59:59','WABIBTC','4h','0.000059090000000','0.000080950000000','0.001508365772827','0.002066376871050','25.5265827183449','25.526582718344901','test'),('2019-04-13 15:59:59','2019-04-17 03:59:59','WABIBTC','4h','0.000082420000000','0.000076910000000','0.001609417414775','0.001501823506071','19.52702517319825','19.527025173198250','test'),('2019-05-24 03:59:59','2019-05-24 15:59:59','WABIBTC','4h','0.000045490000000','0.000042330000000','0.001609417414775','0.001497617919706','35.37958704715322','35.379587047153223','test'),('2019-06-07 23:59:59','2019-06-09 15:59:59','WABIBTC','4h','0.000039140000000','0.000038800000000','0.001609417414775','0.001595436783170','41.119504720873785','41.119504720873785','test'),('2019-06-10 07:59:59','2019-06-13 15:59:59','WABIBTC','4h','0.000039890000000','0.000040110000000','0.001609417414775','0.001618293620121','40.34638793619955','40.346387936199548','test'),('2019-07-23 19:59:59','2019-07-26 23:59:59','WABIBTC','4h','0.000015510000000','0.000015440000000','0.001609417414775','0.001602153764289','103.76643551096068','103.766435510960676','test'),('2019-07-28 15:59:59','2019-07-29 11:59:59','WABIBTC','4h','0.000015750000000','0.000015330000000','0.001609417414775','0.001566499617048','102.18523268412699','102.185232684126987','test'),('2019-08-23 07:59:59','2019-08-23 15:59:59','WABIBTC','4h','0.000010840000000','0.000010470000000','0.001609417414775','0.001554483425525','148.4702412154059','148.470241215405906','test'),('2019-08-23 19:59:59','2019-08-26 03:59:59','WABIBTC','4h','0.000010700000000','0.000011790000000','0.001609417414775','0.001773367413103','150.41284250233647','150.412842502336474','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','WABIBTC','4h','0.000012220000000','0.000011770000000','0.001609417414775','0.001550150816031','131.70355276391163','131.703552763911631','test'),('2019-08-27 11:59:59','2019-08-28 15:59:59','WABIBTC','4h','0.000013300000000','0.000011860000000','0.001609417414775','0.001435164702198','121.00882817857143','121.008828178571434','test'),('2019-08-30 03:59:59','2019-08-30 23:59:59','WABIBTC','4h','0.000012810000000','0.000012090000000','0.001609417414775','0.001518958356333','125.6375811690086','125.637581169008598','test'),('2019-08-31 03:59:59','2019-09-05 23:59:59','WABIBTC','4h','0.000012290000000','0.000015580000000','0.001609417414775','0.002040254135248','130.95341047803095','130.953410478030946','test'),('2019-09-07 03:59:59','2019-09-07 19:59:59','WABIBTC','4h','0.000017860000000','0.000016040000000','0.001609417414775','0.001445411832754','90.11295715425533','90.112957154255326','test'),('2019-09-08 19:59:59','2019-09-10 23:59:59','WABIBTC','4h','0.000017520000000','0.000016580000000','0.001609417414775','0.001523067393663','91.86172458761415','91.861724587614148','test'),('2019-09-28 23:59:59','2019-10-01 03:59:59','WABIBTC','4h','0.000014810000000','0.000014310000000','0.001609417414775','0.001555081917990','108.67099357022282','108.670993570222819','test'),('2019-10-01 07:59:59','2019-10-03 07:59:59','WABIBTC','4h','0.000014610000000','0.000014840000000','0.001609417414775','0.001634753897006','110.15861839664613','110.158618396646133','test'),('2019-10-04 15:59:59','2019-10-09 15:59:59','WABIBTC','4h','0.000015250000000','0.000014900000000','0.001609417414775','0.001572479965911','105.53556818196722','105.535568181967221','test'),('2019-10-15 03:59:59','2019-10-16 07:59:59','WABIBTC','4h','0.000015500000000','0.000015100000000','0.001609417414775','0.001567884062136','103.83338159838709','103.833381598387092','test'),('2019-10-21 15:59:59','2019-10-23 15:59:59','WABIBTC','4h','0.000015680000000','0.000015670000000','0.001609417414775','0.001608391000607','102.64141675860971','102.641416758609708','test'),('2019-10-23 19:59:59','2019-10-25 19:59:59','WABIBTC','4h','0.000015900000000','0.000015750000000','0.001609417414775','0.001594234231617','101.22122105503145','101.221221055031450','test'),('2019-10-29 07:59:59','2019-11-02 19:59:59','WABIBTC','4h','0.000016360000000','0.000018260000000','0.001609417414775','0.001796330195220','98.37514760238388','98.375147602383876','test'),('2019-11-06 11:59:59','2019-11-07 19:59:59','WABIBTC','4h','0.000019170000000','0.000018580000000','0.001609417414775','0.001559883962781','83.95500337897757','83.955003378977565','test'),('2019-11-10 15:59:59','2019-11-11 07:59:59','WABIBTC','4h','0.000019890000000','0.000022050000000','0.001609417414775','0.001784195776561','80.9159082340372','80.915908234037204','test'),('2019-11-11 11:59:59','2019-11-15 19:59:59','WABIBTC','4h','0.000023770000000','0.000022730000000','0.001609417414775','0.001539001171133','67.7079265786706','67.707926578670595','test'),('2019-11-17 19:59:59','2019-11-21 11:59:59','WABIBTC','4h','0.000023050000000','0.000023670000000','0.001609417414775','0.001652707601203','69.82288133514099','69.822881335140991','test'),('2019-11-24 07:59:59','2019-11-24 15:59:59','WABIBTC','4h','0.000024230000000','0.000023090000000','0.001609417414775','0.001533695753494','66.42250989579034','66.422509895790341','test'),('2019-11-26 19:59:59','2019-11-27 11:59:59','WABIBTC','4h','0.000024190000000','0.000024310000000','0.001609417414775','0.001617401296122','66.532344554568','66.532344554567999','test'),('2019-11-27 15:59:59','2019-11-27 23:59:59','WABIBTC','4h','0.000024480000000','0.000024410000000','0.001609417414775','0.001604815322494','65.74417544015523','65.744175440155232','test'),('2019-11-28 03:59:59','2019-11-29 15:59:59','WABIBTC','4h','0.000024660000000','0.000024220000000','0.001609417414775','0.001580701126758','65.26429094789133','65.264290947891325','test'),('2019-12-16 11:59:59','2019-12-16 19:59:59','WABIBTC','4h','0.000021940000000','0.000021340000000','0.001609417414775','0.001565404176449','73.35539720943483','73.355397209434827','test'),('2019-12-16 23:59:59','2019-12-17 23:59:59','WABIBTC','4h','0.000022690000000','0.000021570000000','0.001609417414775','0.001529975039079','70.93069258594095','70.930692585940946','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  2:34:12
