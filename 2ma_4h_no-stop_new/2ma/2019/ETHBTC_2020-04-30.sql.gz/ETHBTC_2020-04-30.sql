-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-08 03:59:59','ETHBTC','4h','0.036644000000000','0.037143000000000','0.033333333333333','0.033787250300185','0.9096532401848415','0.909653240184842','test','test','0.04'),('2019-01-08 11:59:59','2019-01-08 15:59:59','ETHBTC','4h','0.037406000000000','0.037186000000000','0.033434203770412','0.033237563530090','0.8938192741916151','0.893819274191615','test','test','0.58'),('2019-01-08 19:59:59','2019-01-08 23:59:59','ETHBTC','4h','0.037266000000000','0.037296000000000','0.033390505939229','0.033417386076034','0.89600456016822','0.896004560168220','test','test','0.0'),('2019-01-09 03:59:59','2019-01-09 23:59:59','ETHBTC','4h','0.037759000000000','0.037337000000000','0.033396479302963','0.033023235460016','0.8844640828137221','0.884464082813722','test','test','1.11'),('2019-02-08 11:59:59','2019-02-24 19:59:59','ETHBTC','4h','0.031576000000000','0.036752000000000','0.033313536226753','0.038774356581126','1.055027116378037','1.055027116378037','test','test','0.0'),('2019-02-25 03:59:59','2019-02-25 07:59:59','ETHBTC','4h','0.036534000000000','0.036269000000000','0.034527051861058','0.034276609294047','0.9450662906075984','0.945066290607598','test','test','0.72'),('2019-02-27 11:59:59','2019-02-27 15:59:59','ETHBTC','4h','0.036214000000000','0.035993000000000','0.034471397957278','0.034261032381850','0.9518804318020041','0.951880431802004','test','test','0.61'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ETHBTC','4h','0.035449000000000','0.035450000000000','0.034424650051627','0.034425621155186','0.9711035586794298','0.971103558679430','test','test','0.0'),('2019-03-06 03:59:59','2019-03-06 07:59:59','ETHBTC','4h','0.035308000000000','0.035618000000000','0.034424865852418','0.034727112040654','0.9749877039882745','0.974987703988275','test','test','0.0'),('2019-03-06 11:59:59','2019-03-07 11:59:59','ETHBTC','4h','0.035893000000000','0.035317000000000','0.034492031672026','0.033938513987712','0.9609682019342487','0.960968201934249','test','test','1.60'),('2019-03-07 15:59:59','2019-03-07 19:59:59','ETHBTC','4h','0.035248000000000','0.035409000000000','0.034369027742178','0.034526012917691','0.975063201945598','0.975063201945598','test','test','0.0'),('2019-03-07 23:59:59','2019-03-08 03:59:59','ETHBTC','4h','0.035320000000000','0.035054000000000','0.034403913336737','0.034144812517157','0.9740632315044419','0.974063231504442','test','test','0.75'),('2019-03-15 15:59:59','2019-03-15 23:59:59','ETHBTC','4h','0.034832000000000','0.034804000000000','0.034346335376830','0.034318725782476','0.9860569412273259','0.986056941227326','test','test','0.08'),('2019-03-16 03:59:59','2019-03-17 03:59:59','ETHBTC','4h','0.035075000000000','0.034702000000000','0.034340199911418','0.033975014036380','0.9790506033191222','0.979050603319122','test','test','1.06'),('2019-03-17 07:59:59','2019-03-18 07:59:59','ETHBTC','4h','0.034891000000000','0.034651000000000','0.034259047494743','0.034023394420921','0.9818878075934511','0.981887807593451','test','test','0.68'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ETHBTC','4h','0.034359000000000','0.034336000000000','0.034206680145005','0.034183782108295','0.9955668134987888','0.995566813498789','test','test','0.06'),('2019-03-27 19:59:59','2019-03-27 23:59:59','ETHBTC','4h','0.034357000000000','0.034521000000000','0.034201591692403','0.034364849865048','0.9954766624676971','0.995476662467697','test','test','0.0'),('2019-03-28 03:59:59','2019-03-28 07:59:59','ETHBTC','4h','0.034428000000000','0.034318000000000','0.034237871286324','0.034128478761591','0.9944774975695299','0.994477497569530','test','test','0.31'),('2019-03-29 15:59:59','2019-03-31 07:59:59','ETHBTC','4h','0.034477000000000','0.034388000000000','0.034213561836383','0.034125241883851','0.9923590172109845','0.992359017210985','test','test','0.25'),('2019-03-31 11:59:59','2019-03-31 19:59:59','ETHBTC','4h','0.034517000000000','0.034402000000000','0.034193935180265','0.034080011532621','0.9906404142962856','0.990640414296286','test','test','0.33'),('2019-03-31 23:59:59','2019-04-01 03:59:59','ETHBTC','4h','0.034482000000000','0.034527000000000','0.034168618814122','0.034213209842677','0.9909117456679362','0.990911745667936','test','test','0.0'),('2019-04-01 07:59:59','2019-04-01 11:59:59','ETHBTC','4h','0.034502000000000','0.034375000000000','0.034178527931578','0.034052718614805','0.990624541521606','0.990624541521606','test','test','0.36'),('2019-04-07 23:59:59','2019-04-10 19:59:59','ETHBTC','4h','0.033702000000000','0.033582000000000','0.034150570305629','0.034028973117430','1.013309901656545','1.013309901656545','test','test','0.35'),('2019-04-18 15:59:59','2019-04-18 23:59:59','ETHBTC','4h','0.032807000000000','0.032962000000000','0.034123548708251','0.034284768876196','1.040130115775637','1.040130115775637','test','test','0.0'),('2019-04-19 03:59:59','2019-04-19 15:59:59','ETHBTC','4h','0.032825000000000','0.032692000000000','0.034159375412239','0.034020968803562','1.0406511930613591','1.040651193061359','test','test','0.40'),('2019-04-19 19:59:59','2019-04-19 23:59:59','ETHBTC','4h','0.032620000000000','0.032829000000000','0.034128618388089','0.034347284275370','1.0462482645030247','1.046248264503025','test','test','0.0'),('2019-04-20 03:59:59','2019-04-20 11:59:59','ETHBTC','4h','0.032823000000000','0.032662000000000','0.034177210807484','0.034009568272067','1.0412579839589449','1.041257983958945','test','test','0.49'),('2019-05-06 19:59:59','2019-05-07 15:59:59','ETHBTC','4h','0.030215000000000','0.029302000000000','0.034139956910725','0.033108357352244','1.129900940285458','1.129900940285458','test','test','3.02'),('2019-05-15 15:59:59','2019-05-23 07:59:59','ETHBTC','4h','0.029813000000000','0.030991000000000','0.033910712564396','0.035250625334022','1.137447172857344','1.137447172857344','test','test','0.72'),('2019-05-23 11:59:59','2019-05-23 19:59:59','ETHBTC','4h','0.031100000000000','0.031077000000000','0.034208470957646','0.034183172088449','1.0999508346510039','1.099950834651004','test','test','0.07'),('2019-05-23 23:59:59','2019-05-26 03:59:59','ETHBTC','4h','0.031163000000000','0.031070000000000','0.034202848986714','0.034100777140109','1.0975467376925698','1.097546737692570','test','test','0.29'),('2019-05-26 07:59:59','2019-05-26 19:59:59','ETHBTC','4h','0.031218000000000','0.030533000000000','0.034180166354135','0.033430169110475','1.0948864870950947','1.094886487095095','test','test','2.19'),('2019-05-28 15:59:59','2019-05-29 03:59:59','ETHBTC','4h','0.031169000000000','0.031048000000000','0.034013500299988','0.033881457772595','1.0912605569632647','1.091260556963265','test','test','0.38'),('2019-05-29 07:59:59','2019-05-29 11:59:59','ETHBTC','4h','0.031023000000000','0.031040000000000','0.033984157516123','0.034002780172790','1.0954503921646161','1.095450392164616','test','test','0.0'),('2019-05-29 15:59:59','2019-05-30 03:59:59','ETHBTC','4h','0.031298000000000','0.032502000000000','0.033988295884271','0.035295788639229','1.0859574376724106','1.085957437672411','test','test','0.63'),('2019-05-30 07:59:59','2019-05-30 19:59:59','ETHBTC','4h','0.032545000000000','0.031234000000000','0.034278849829817','0.032898005702397','1.0532754595119784','1.053275459511978','test','test','4.02'),('2019-05-31 23:59:59','2019-06-01 15:59:59','ETHBTC','4h','0.031314000000000','0.031134000000000','0.033971995579280','0.033776716815651','1.0848820201596587','1.084882020159659','test','test','0.57'),('2019-06-04 15:59:59','2019-06-04 19:59:59','ETHBTC','4h','0.031330000000000','0.031103000000000','0.033928600298473','0.033682772265669','1.0829428757891195','1.082942875789120','test','test','0.72'),('2019-06-04 23:59:59','2019-06-05 03:59:59','ETHBTC','4h','0.031396000000000','0.031055000000000','0.033873971846739','0.033506057959628','1.0789263551643167','1.078926355164317','test','test','1.08'),('2019-06-05 07:59:59','2019-06-07 07:59:59','ETHBTC','4h','0.031399000000000','0.031223000000000','0.033792213205159','0.033602798589276','1.0762194084257033','1.076219408425703','test','test','0.56'),('2019-06-07 11:59:59','2019-06-07 15:59:59','ETHBTC','4h','0.031276000000000','0.031344000000000','0.033750121068296','0.033823500280236','1.0791060579452545','1.079106057945254','test','test','0.0'),('2019-06-07 19:59:59','2019-06-07 23:59:59','ETHBTC','4h','0.031224000000000','0.031196000000000','0.033766427559838','0.033736147647858','1.0814254278708044','1.081425427870804','test','test','0.08'),('2019-06-08 07:59:59','2019-06-08 11:59:59','ETHBTC','4h','0.031228000000000','0.031142000000000','0.033759698690509','0.033666726547324','1.0810714323846904','1.081071432384690','test','test','0.27'),('2019-06-12 03:59:59','2019-06-12 11:59:59','ETHBTC','4h','0.031089000000000','0.031110000000000','0.033739038214246','0.033761828262253','1.085240381300324','1.085240381300324','test','test','0.14'),('2019-06-12 15:59:59','2019-06-13 23:59:59','ETHBTC','4h','0.031134000000000','0.030996000000000','0.033744102669358','0.033594533511255','1.0838344790055388','1.083834479005539','test','test','0.44'),('2019-07-01 19:59:59','2019-07-02 15:59:59','ETHBTC','4h','0.027624000000000','0.027285000000000','0.033710865078669','0.033297167451183','1.2203469837340317','1.220346983734032','test','test','1.22'),('2019-07-07 19:59:59','2019-07-08 11:59:59','ETHBTC','4h','0.026690000000000','0.025777000000000','0.033618932272561','0.032468910348063','1.2596078033930644','1.259607803393064','test','test','3.42'),('2019-07-24 23:59:59','2019-07-26 03:59:59','ETHBTC','4h','0.022155000000000','0.022153000000000','0.033363371844895','0.033360360030691','1.5059071020038213','1.505907102003821','test','test','0.80'),('2019-07-26 07:59:59','2019-07-27 03:59:59','ETHBTC','4h','0.022156000000000','0.021919000000000','0.033362702552849','0.033005825837511','1.5058089254761389','1.505808925476139','test','test','1.06'),('2019-07-27 19:59:59','2019-07-27 23:59:59','ETHBTC','4h','0.022025000000000','0.021871000000000','0.033283396616108','0.033050677293571','1.511164432059367','1.511164432059367','test','test','0.69'),('2019-07-28 07:59:59','2019-07-28 11:59:59','ETHBTC','4h','0.022038000000000','0.022015000000000','0.033231681211099','0.033196998904726','1.5079263640575067','1.507926364057507','test','test','0.10'),('2019-07-28 23:59:59','2019-07-29 11:59:59','ETHBTC','4h','0.022165000000000','0.022031000000000','0.033223974031905','0.033023116259729','1.4989385983264307','1.498938598326431','test','test','0.60'),('2019-07-29 15:59:59','2019-07-29 19:59:59','ETHBTC','4h','0.021978000000000','0.022110000000000','0.033179338971422','0.033378614280560','1.5096614328611238','1.509661432861124','test','test','0.0'),('2019-07-29 23:59:59','2019-07-30 03:59:59','ETHBTC','4h','0.022183000000000','0.021908000000000','0.033223622373452','0.032811753097308','1.4977064587049742','1.497706458704974','test','test','1.23'),('2019-08-14 03:59:59','2019-08-14 19:59:59','ETHBTC','4h','0.019593000000000','0.018389000000000','0.033132095867643','0.031096111412754','1.6910169891105327','1.691016989110533','test','test','6.14'),('2019-08-18 19:59:59','2019-08-19 03:59:59','ETHBTC','4h','0.018877000000000','0.018891000000000','0.032679654877667','0.032703891523759','1.7311890066041917','1.731189006604192','test','test','0.08'),('2019-08-19 07:59:59','2019-08-19 11:59:59','ETHBTC','4h','0.018760000000000','0.018740000000000','0.032685040799021','0.032650195339747','1.742272963700486','1.742272963700486','test','test','0.10'),('2019-08-19 15:59:59','2019-08-19 19:59:59','ETHBTC','4h','0.018809000000000','0.018532000000000','0.032677297363627','0.032196059053790','1.7373224181842144','1.737322418184214','test','test','1.47'),('2019-08-22 11:59:59','2019-08-23 15:59:59','ETHBTC','4h','0.018688000000000','0.018712000000000','0.032570355516996','0.032612183884526','1.742848647099553','1.742848647099553','test','test','0.0'),('2019-08-24 11:59:59','2019-08-25 11:59:59','ETHBTC','4h','0.018882000000000','0.018722000000000','0.032579650709781','0.032303581219602','1.7254343136204267','1.725434313620427','test','test','0.84'),('2019-08-25 15:59:59','2019-08-25 19:59:59','ETHBTC','4h','0.018675000000000','0.018420000000000','0.032518301934186','0.032074276927856','1.7412745346284098','1.741274534628410','test','test','1.36'),('2019-09-08 03:59:59','2019-09-08 07:59:59','ETHBTC','4h','0.017357000000000','0.017220000000000','0.032419629710557','0.032163739333744','1.8678129694392271','1.867812969439227','test','test','0.78'),('2019-09-08 11:59:59','2019-09-09 07:59:59','ETHBTC','4h','0.017322000000000','0.017463000000000','0.032362765182376','0.032626196073192','1.868304190184505','1.868304190184505','test','test','0.06'),('2019-09-09 11:59:59','2019-09-12 15:59:59','ETHBTC','4h','0.017554000000000','0.017409000000000','0.032421305380335','0.032153498083984','1.8469468713874395','1.846946871387440','test','test','0.82'),('2019-09-12 19:59:59','2019-09-12 23:59:59','ETHBTC','4h','0.017409000000000','0.017352000000000','0.032361792647813','0.032255834684637','1.858911634660961','1.858911634660961','test','test','0.32'),('2019-09-13 19:59:59','2019-09-14 11:59:59','ETHBTC','4h','0.017485000000000','0.017520000000000','0.032338246433774','0.032402978411194','1.8494850691320304','1.849485069132030','test','test','0.0'),('2019-09-14 15:59:59','2019-09-24 11:59:59','ETHBTC','4h','0.017868000000000','0.020317000000000','0.032352631317645','0.036786904548947','1.8106464807278193','1.810646480727819','test','test','0.0'),('2019-09-24 15:59:59','2019-09-24 19:59:59','ETHBTC','4h','0.020214000000000','0.019729000000000','0.033338025369045','0.032538137058766','1.64925424799867','1.649254247998670','test','test','2.39'),('2019-09-25 19:59:59','2019-09-25 23:59:59','ETHBTC','4h','0.020207000000000','0.020163000000000','0.033160272411205','0.033088067136494','1.6410289707133834','1.641028970713383','test','test','0.21'),('2019-09-26 03:59:59','2019-09-26 15:59:59','ETHBTC','4h','0.020138000000000','0.020179000000000','0.033144226794603','0.033211706847169','1.6458549406397307','1.645854940639731','test','test','0.10'),('2019-09-26 19:59:59','2019-10-11 19:59:59','ETHBTC','4h','0.020305000000000','0.021802000000000','0.033159222361840','0.035603908689133','1.6330569988593835','1.633056998859383','test','test','0.0'),('2019-10-11 23:59:59','2019-10-12 19:59:59','ETHBTC','4h','0.021873000000000','0.021619000000000','0.033702485990127','0.033311116198992','1.5408259493497516','1.540825949349752','test','test','1.16'),('2019-10-13 07:59:59','2019-10-13 11:59:59','ETHBTC','4h','0.021801000000000','0.021858000000000','0.033615514925430','0.033703404671348','1.5419253669753885','1.541925366975389','test','test','0.0'),('2019-10-13 15:59:59','2019-10-13 19:59:59','ETHBTC','4h','0.021845000000000','0.021697000000000','0.033635045980079','0.033407168351100','1.5397137093192446','1.539713709319245','test','test','0.67'),('2019-10-13 23:59:59','2019-10-15 23:59:59','ETHBTC','4h','0.021874000000000','0.022119000000000','0.033584406506972','0.033960569055852','1.5353573423686775','1.535357342368677','test','test','0.0'),('2019-10-16 03:59:59','2019-10-16 11:59:59','ETHBTC','4h','0.021998000000000','0.021939000000000','0.033667998184501','0.033577698525764','1.5305026904491925','1.530502690449193','test','test','0.26'),('2019-10-17 15:59:59','2019-10-17 23:59:59','ETHBTC','4h','0.021955000000000','0.021952000000000','0.033647931593671','0.033643333834856','1.5325862716315597','1.532586271631560','test','test','0.25'),('2019-10-23 23:59:59','2019-10-24 03:59:59','ETHBTC','4h','0.021742000000000','0.021602000000000','0.033646909869490','0.033430252368721','1.5475535769243758','1.547553576924376','test','test','0.64'),('2019-10-24 07:59:59','2019-10-24 23:59:59','ETHBTC','4h','0.021598000000000','0.021636000000000','0.033598763758208','0.033657878168006','1.5556423630987954','1.555642363098795','test','test','0.0'),('2019-10-25 03:59:59','2019-10-25 15:59:59','ETHBTC','4h','0.021679000000000','0.021261000000000','0.033611900293718','0.032963818079466','1.550435919263732','1.550435919263732','test','test','1.92'),('2019-11-05 15:59:59','2019-11-07 11:59:59','ETHBTC','4h','0.020321000000000','0.020291000000000','0.033467882023885','0.033418473212276','1.646960386983154','1.646960386983154','test','test','0.49'),('2019-11-07 15:59:59','2019-11-07 19:59:59','ETHBTC','4h','0.020208000000000','0.020226000000000','0.033456902287972','0.033486703566732','1.6556265977816484','1.655626597781648','test','test','0.0'),('2019-11-07 23:59:59','2019-11-08 07:59:59','ETHBTC','4h','0.020258000000000','0.020225000000000','0.033463524794363','0.033409013178300','1.651867153438773','1.651867153438773','test','test','0.16'),('2019-11-08 11:59:59','2019-11-21 11:59:59','ETHBTC','4h','0.020405000000000','0.021376000000000','0.033451411101904','0.035043242524592','1.6393732468465685','1.639373246846568','test','test','0.0'),('2019-12-10 23:59:59','2019-12-11 03:59:59','ETHBTC','4h','0.020149000000000','0.020172000000000','0.033805151418057','0.033843739858308','1.6777582717781085','1.677758271778109','test','test','0.0'),('2019-12-11 07:59:59','2019-12-11 15:59:59','ETHBTC','4h','0.020175000000000','0.019906000000000','0.033813726627002','0.033362876938642','1.676021146319791','1.676021146319791','test','test','1.33'),('2019-12-12 19:59:59','2019-12-12 23:59:59','ETHBTC','4h','0.020132000000000','0.020125000000000','0.033713537807366','0.033701815436779','1.674624369529417','1.674624369529417','test','test','0.03'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ETHBTC','4h','0.020096000000000','0.020072000000000','0.033710932836125','0.033670672964107','1.6774946674027003','1.677494667402700','test','test','0.11'),('2019-12-15 11:59:59','2019-12-15 15:59:59','ETHBTC','4h','0.020073000000000','0.020109000000000','0.033701986197898','0.033762429156256','1.6789710655058259','1.678971065505826','test','test','0.0'),('2019-12-15 19:59:59','2019-12-15 23:59:59','ETHBTC','4h','0.020087000000000','0.020012000000000','0.033715417966422','0.033589532749740','1.6784695557535942','1.678469555753594','test','test','0.37'),('2019-12-29 19:59:59','2019-12-31 15:59:59','ETHBTC','4h','0.018054000000000','0.018033000000000','0.033687443473826','0.033648259009832','1.8659268568642096','1.865926856864210','test','test','0.38'),('2019-12-31 19:59:59','2019-12-31 23:59:59','ETHBTC','4h','0.017915000000000','0.017953000000000','0.033678735815161','0.033750172709438','1.879918270452755','1.879918270452755','test','test','0.0'),('2020-01-01 03:59:59','2020-01-01 15:59:59','ETHBTC','4h','0.018021000000000','0.018253000000000','0.033694610680556','0.034128390697086','1.8697414505607903','1.869741450560790','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 21:59:28
