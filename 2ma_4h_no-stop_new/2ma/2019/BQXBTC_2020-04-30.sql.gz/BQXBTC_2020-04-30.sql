-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-01 23:59:59','BQXBTC','4h','0.000031230000000','0.000030720000000','0.033333333333333','0.032788984950368','1067.3497705197994','1067.349770519799449','test','test','1.63'),('2019-01-02 03:59:59','2019-01-02 15:59:59','BQXBTC','4h','0.000030890000000','0.000030700000000','0.033212367026008','0.033008082476479','1075.1818396247259','1075.181839624725853','test','test','0.61'),('2019-01-02 19:59:59','2019-01-03 03:59:59','BQXBTC','4h','0.000030920000000','0.000030870000000','0.033166970459446','0.033113336936711','1072.6704547039383','1072.670454703938276','test','test','0.51'),('2019-01-03 07:59:59','2019-01-03 11:59:59','BQXBTC','4h','0.000030490000000','0.000030330000000','0.033155051898838','0.032981066713406','1087.407408948442','1087.407408948442026','test','test','0.52'),('2019-01-03 15:59:59','2019-01-03 19:59:59','BQXBTC','4h','0.000030620000000','0.000030100000000','0.033116388524298','0.032553993944525','1081.5280380240872','1081.528038024087209','test','test','1.69'),('2019-01-09 07:59:59','2019-01-09 19:59:59','BQXBTC','4h','0.000032010000000','0.000030140000000','0.032991411951015','0.031064078606798','1030.65954236222','1030.659542362220009','test','test','5.84'),('2019-01-10 03:59:59','2019-01-10 07:59:59','BQXBTC','4h','0.000030400000000','0.000029780000000','0.032563115652300','0.031898999477812','1071.1551201414402','1071.155120141440193','test','test','2.03'),('2019-01-15 03:59:59','2019-01-15 07:59:59','BQXBTC','4h','0.000029610000000','0.000029100000000','0.032415534280191','0.031857212007888','1094.7495535356747','1094.749553535674750','test','test','1.72'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BQXBTC','4h','0.000029430000000','0.000029280000000','0.032291462664124','0.032126878246876','1097.2294483222563','1097.229448322256303','test','test','0.50'),('2019-01-15 23:59:59','2019-01-24 07:59:59','BQXBTC','4h','0.000029500000000','0.000047060000000','0.032254888349180','0.051454747312285','1093.3860457349153','1093.386045734915342','test','test','0.0'),('2019-01-24 11:59:59','2019-01-24 15:59:59','BQXBTC','4h','0.000047200000000','0.000047440000000','0.036521523674314','0.036707226337065','773.7610947947975','773.761094794797486','test','test','0.0'),('2019-01-24 19:59:59','2019-01-24 23:59:59','BQXBTC','4h','0.000047150000000','0.000047850000000','0.036562790932704','0.037105610734462','775.4568596543703','775.456859654370305','test','test','0.0'),('2019-01-25 03:59:59','2019-01-25 11:59:59','BQXBTC','4h','0.000050120000000','0.000046940000000','0.036683417555316','0.034355938149372','731.9117628754278','731.911762875427826','test','test','6.34'),('2019-01-25 15:59:59','2019-01-27 03:59:59','BQXBTC','4h','0.000048100000000','0.000047150000000','0.036166199909551','0.035451898663936','751.8960480156156','751.896048015615634','test','test','1.97'),('2019-01-29 11:59:59','2019-01-29 15:59:59','BQXBTC','4h','0.000047280000000','0.000045550000000','0.036007466299414','0.034689934220353','761.5792364512362','761.579236451236170','test','test','3.65'),('2019-02-12 23:59:59','2019-02-13 03:59:59','BQXBTC','4h','0.000041550000000','0.000040140000000','0.035714681392956','0.034502703035217','859.5591189640542','859.559118964054164','test','test','3.39'),('2019-02-13 19:59:59','2019-02-13 23:59:59','BQXBTC','4h','0.000040520000000','0.000040170000000','0.035445352869014','0.035139186198132','874.7619168068718','874.761916806871795','test','test','0.86'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BQXBTC','4h','0.000040480000000','0.000039580000000','0.035377315831041','0.034590764836774','873.9455491857873','873.945549185787286','test','test','2.22'),('2019-02-16 19:59:59','2019-02-16 23:59:59','BQXBTC','4h','0.000040290000000','0.000040170000000','0.035202526721204','0.035097679284953','873.7286354232702','873.728635423270248','test','test','0.29'),('2019-02-17 03:59:59','2019-02-17 15:59:59','BQXBTC','4h','0.000040660000000','0.000040320000000','0.035179227290926','0.034885057657898','865.2048030232553','865.204803023255295','test','test','0.83'),('2019-02-17 19:59:59','2019-02-17 23:59:59','BQXBTC','4h','0.000040050000000','0.000040540000000','0.035113856261364','0.035543463990904','876.750468448534','876.750468448533979','test','test','0.0'),('2019-02-18 03:59:59','2019-02-18 15:59:59','BQXBTC','4h','0.000041920000000','0.000040050000000','0.035209324645706','0.033638679677016','839.9170955559637','839.917095555963670','test','test','4.46'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BQXBTC','4h','0.000040340000000','0.000040580000000','0.034860292430442','0.035067691294679','864.1619343193246','864.161934319324587','test','test','0.0'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BQXBTC','4h','0.000040120000000','0.000038010000000','0.034906381066939','0.033070576878224','870.0493785378532','870.049378537853158','test','test','5.25'),('2019-03-06 11:59:59','2019-03-06 15:59:59','BQXBTC','4h','0.000037980000000','0.000037480000000','0.034498424580558','0.034044258906775','908.331347566023','908.331347566023055','test','test','1.31'),('2019-03-07 23:59:59','2019-03-08 07:59:59','BQXBTC','4h','0.000037800000000','0.000038190000000','0.034397498875272','0.034752393704938','909.9867427320753','909.986742732075300','test','test','0.0'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BQXBTC','4h','0.000039030000000','0.000037500000000','0.034476364392976','0.033124869708855','883.3298589027928','883.329858902792807','test','test','3.92'),('2019-03-09 03:59:59','2019-03-16 07:59:59','BQXBTC','4h','0.000038660000000','0.000040310000000','0.034176032240949','0.035634657517658','884.0153192175145','884.015319217514502','test','test','0.0'),('2019-03-16 11:59:59','2019-03-16 15:59:59','BQXBTC','4h','0.000040620000000','0.000040210000000','0.034500171191329','0.034151941989250','849.3395172656053','849.339517265605309','test','test','1.00'),('2019-03-16 19:59:59','2019-03-16 23:59:59','BQXBTC','4h','0.000040700000000','0.000040320000000','0.034422786924200','0.034101394810411','845.7687204963199','845.768720496319929','test','test','0.93'),('2019-03-17 03:59:59','2019-03-17 07:59:59','BQXBTC','4h','0.000040350000000','0.000040360000000','0.034351366454469','0.034359879804272','851.3349802842462','851.334980284246171','test','test','0.0'),('2019-03-17 11:59:59','2019-03-18 03:59:59','BQXBTC','4h','0.000040370000000','0.000040150000000','0.034353258309981','0.034166047093033','850.9600770369361','850.960077036936127','test','test','0.54'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BQXBTC','4h','0.000040980000000','0.000040410000000','0.034311655817326','0.033834407310350','837.2780824140069','837.278082414006917','test','test','1.39'),('2019-03-18 19:59:59','2019-03-18 23:59:59','BQXBTC','4h','0.000040570000000','0.000040340000000','0.034205600593554','0.034011681733891','843.1254767945172','843.125476794517226','test','test','0.56'),('2019-03-19 07:59:59','2019-03-19 11:59:59','BQXBTC','4h','0.000040420000000','0.000040090000000','0.034162507513628','0.033883595403794','845.1882116187146','845.188211618714604','test','test','0.81'),('2019-03-21 07:59:59','2019-03-21 11:59:59','BQXBTC','4h','0.000040370000000','0.000040020000000','0.034100527044776','0.033804882148425','844.699703858718','844.699703858717953','test','test','0.86'),('2019-03-25 07:59:59','2019-03-25 11:59:59','BQXBTC','4h','0.000039990000000','0.000039600000000','0.034034828178921','0.033702905623538','851.0834753418521','851.083475341852136','test','test','0.97'),('2019-03-26 15:59:59','2019-03-26 19:59:59','BQXBTC','4h','0.000042280000000','0.000039780000000','0.033961067611058','0.031952962856383','803.2419018698623','803.241901869862318','test','test','5.91'),('2019-03-26 23:59:59','2019-03-27 03:59:59','BQXBTC','4h','0.000039780000000','0.000039860000000','0.033514822110019','0.033582222456143','842.5043265464778','842.504326546477841','test','test','0.0'),('2019-03-27 07:59:59','2019-03-29 15:59:59','BQXBTC','4h','0.000041720000000','0.000041180000000','0.033529799964713','0.033095809265266','803.6864804581284','803.686480458128358','test','test','2.13'),('2019-03-29 19:59:59','2019-03-30 11:59:59','BQXBTC','4h','0.000040990000000','0.000040650000000','0.033433357587058','0.033156037714416','815.6466842414791','815.646684241479079','test','test','0.82'),('2019-03-30 15:59:59','2019-03-30 19:59:59','BQXBTC','4h','0.000040430000000','0.000040310000000','0.033371730948693','0.033272680547658','825.4200086246187','825.420008624618731','test','test','0.29'),('2019-03-30 23:59:59','2019-03-31 03:59:59','BQXBTC','4h','0.000040480000000','0.000040420000000','0.033349719748463','0.033300288345674','823.8567131537385','823.856713153738497','test','test','0.14'),('2019-03-31 07:59:59','2019-04-02 07:59:59','BQXBTC','4h','0.000041500000000','0.000050250000000','0.033338734992288','0.040367986346084','803.3430118623614','803.343011862361436','test','test','0.0'),('2019-04-02 11:59:59','2019-04-02 23:59:59','BQXBTC','4h','0.000046720000000','0.000042450000000','0.034900790848687','0.031711013945350','747.0203520695017','747.020352069501655','test','test','9.13'),('2019-04-03 07:59:59','2019-04-03 15:59:59','BQXBTC','4h','0.000043840000000','0.000042820000000','0.034191951536834','0.033396427116953','779.9259018438513','779.925901843851307','test','test','2.32'),('2019-05-21 19:59:59','2019-05-21 23:59:59','BQXBTC','4h','0.000017220000000','0.000017000000000','0.034015168332416','0.033580595914696','1975.3291714527552','1975.329171452755190','test','test','1.27'),('2019-05-22 07:59:59','2019-05-22 11:59:59','BQXBTC','4h','0.000017200000000','0.000016760000000','0.033918596684034','0.033050911652582','1972.0114351182685','1972.011435118268537','test','test','2.55'),('2019-05-22 15:59:59','2019-05-24 15:59:59','BQXBTC','4h','0.000017780000000','0.000017760000000','0.033725777788156','0.033687841030239','1896.8378958467945','1896.837895846794481','test','test','1.12'),('2019-05-24 19:59:59','2019-05-24 23:59:59','BQXBTC','4h','0.000017810000000','0.000017460000000','0.033717347397508','0.033054738099971','1893.1694215332834','1893.169421533283412','test','test','1.96'),('2019-05-25 07:59:59','2019-05-25 11:59:59','BQXBTC','4h','0.000017570000000','0.000017010000000','0.033570100886944','0.032500137512061','1910.6488837190668','1910.648883719066816','test','test','3.18'),('2019-05-26 07:59:59','2019-05-26 11:59:59','BQXBTC','4h','0.000017740000000','0.000018510000000','0.033332331248081','0.034779112254903','1878.9363724961172','1878.936372496117201','test','test','0.0'),('2019-05-26 15:59:59','2019-05-26 19:59:59','BQXBTC','4h','0.000018470000000','0.000016300000000','0.033653838138486','0.029699922125464','1822.0811119916623','1822.081111991662283','test','test','11.7'),('2019-06-07 11:59:59','2019-06-07 15:59:59','BQXBTC','4h','0.000016090000000','0.000016070000000','0.032775190135592','0.032734450309445','2036.9913073705548','2036.991307370554750','test','test','0.12'),('2019-06-07 19:59:59','2019-06-07 23:59:59','BQXBTC','4h','0.000015930000000','0.000015910000000','0.032766136840893','0.032724999192631','2056.8824131131755','2056.882413113175517','test','test','0.12'),('2019-06-08 03:59:59','2019-06-13 19:59:59','BQXBTC','4h','0.000016140000000','0.000016310000000','0.032756995141279','0.033102019253672','2029.5536023097345','2029.553602309734515','test','test','0.0'),('2019-07-03 19:59:59','2019-07-03 23:59:59','BQXBTC','4h','0.000010200000000','0.000009110000000','0.032833667166255','0.029324971361234','3218.986977083857','3218.986977083856800','test','test','10.6'),('2019-07-04 03:59:59','2019-07-04 11:59:59','BQXBTC','4h','0.000010680000000','0.000010630000000','0.032053956987362','0.031903891645661','3001.306834022639','3001.306834022639123','test','test','6.17'),('2019-07-04 15:59:59','2019-07-06 15:59:59','BQXBTC','4h','0.000010970000000','0.000010010000000','0.032020609133650','0.029218440968809','2918.925171709248','2918.925171709247934','test','test','8.75'),('2019-07-06 19:59:59','2019-07-06 23:59:59','BQXBTC','4h','0.000009990000000','0.000009920000000','0.031397905097019','0.031177899755999','3142.933443145057','3142.933443145057026','test','test','0.70'),('2019-07-07 15:59:59','2019-07-07 23:59:59','BQXBTC','4h','0.000010310000000','0.000010170000000','0.031349015021237','0.030923325195536','3040.641612147129','3040.641612147128853','test','test','1.45'),('2019-07-08 03:59:59','2019-07-10 03:59:59','BQXBTC','4h','0.000010380000000','0.000010550000000','0.031254417282192','0.031766291168317','3011.022859556091','3011.022859556091134','test','test','0.0'),('2019-07-12 11:59:59','2019-07-14 07:59:59','BQXBTC','4h','0.000012000000000','0.000012180000000','0.031368167034664','0.031838689540184','2614.013919555371','2614.013919555371103','test','test','0.91'),('2019-07-14 11:59:59','2019-07-16 19:59:59','BQXBTC','4h','0.000011850000000','0.000012100000000','0.031472727591447','0.032136709186203','2655.926379025035','2655.926379025035203','test','test','1.01'),('2019-07-16 23:59:59','2019-07-17 15:59:59','BQXBTC','4h','0.000012160000000','0.000011930000000','0.031620279056948','0.031022198120838','2600.3518961305926','2600.351896130592650','test','test','4.44'),('2019-07-17 19:59:59','2019-07-18 15:59:59','BQXBTC','4h','0.000011820000000','0.000011290000000','0.031487372182257','0.030075501855980','2663.9062759946605','2663.906275994660518','test','test','4.48'),('2019-07-19 19:59:59','2019-07-20 19:59:59','BQXBTC','4h','0.000012050000000','0.000011660000000','0.031173623220862','0.030164684378029','2587.0226739304567','2587.022673930456676','test','test','3.23'),('2019-07-20 23:59:59','2019-07-28 19:59:59','BQXBTC','4h','0.000011690000000','0.000012700000000','0.030949414589121','0.033623401649430','2647.5119409000285','2647.511940900028549','test','test','0.0'),('2019-07-28 23:59:59','2019-07-30 15:59:59','BQXBTC','4h','0.000012850000000','0.000012660000000','0.031543633935857','0.031077230009957','2454.757504735928','2454.757504735927796','test','test','2.02'),('2019-07-30 19:59:59','2019-07-30 23:59:59','BQXBTC','4h','0.000012640000000','0.000012650000000','0.031439988618990','0.031464862027708','2487.3408717555385','2487.340871755538501','test','test','0.0'),('2019-08-21 11:59:59','2019-08-23 07:59:59','BQXBTC','4h','0.000008590000000','0.000008630000000','0.031445516043150','0.031591944522978','3660.7119957100767','3660.711995710076735','test','test','0.0'),('2019-08-23 11:59:59','2019-08-23 15:59:59','BQXBTC','4h','0.000008650000000','0.000008370000000','0.031478055705334','0.030459112861693','3639.0815844316253','3639.081584431625288','test','test','3.23'),('2019-08-23 23:59:59','2019-08-24 23:59:59','BQXBTC','4h','0.000008830000000','0.000008750000000','0.031251623962302','0.030968483541352','3539.2552618688815','3539.255261868881462','test','test','0.90'),('2019-08-25 03:59:59','2019-08-25 15:59:59','BQXBTC','4h','0.000008950000000','0.000009080000000','0.031188703868758','0.031641724148416','3484.77138198411','3484.771381984110121','test','test','1.11'),('2019-08-25 19:59:59','2019-08-25 23:59:59','BQXBTC','4h','0.000008690000000','0.000008570000000','0.031289375042015','0.030857300818190','3600.6185318774587','3600.618531877458736','test','test','1.38'),('2019-08-26 11:59:59','2019-08-26 15:59:59','BQXBTC','4h','0.000008950000000','0.000008720000000','0.031193358547832','0.030391741512525','3485.2914578582995','3485.291457858299509','test','test','2.56'),('2019-08-26 19:59:59','2019-08-26 23:59:59','BQXBTC','4h','0.000008630000000','0.000008760000000','0.031015221428875','0.031482426386668','3593.884290715489','3593.884290715488987','test','test','0.0'),('2019-08-27 03:59:59','2019-08-27 07:59:59','BQXBTC','4h','0.000008740000000','0.000008670000000','0.031119044752829','0.030869807552291','3560.5314362504205','3560.531436250420484','test','test','0.80'),('2019-08-27 15:59:59','2019-08-28 03:59:59','BQXBTC','4h','0.000008720000000','0.000008750000000','0.031063658708265','0.031170529093729','3562.3461821404435','3562.346182140443489','test','test','0.0'),('2019-08-28 07:59:59','2019-08-28 11:59:59','BQXBTC','4h','0.000008730000000','0.000008690000000','0.031087407682812','0.030944968243257','3560.98598886738','3560.985988867380001','test','test','0.45'),('2019-08-29 19:59:59','2019-08-29 23:59:59','BQXBTC','4h','0.000008730000000','0.000008600000000','0.031055754474022','0.030593297649094','3557.3601917551237','3557.360191755123651','test','test','1.48'),('2019-08-30 07:59:59','2019-08-30 11:59:59','BQXBTC','4h','0.000008670000000','0.000008650000000','0.030952986290705','0.030881583784844','3570.1252930455476','3570.125293045547551','test','test','0.23'),('2019-08-30 15:59:59','2019-08-30 19:59:59','BQXBTC','4h','0.000008660000000','0.000008560000000','0.030937119067180','0.030579877507513','3572.415596672081','3572.415596672080937','test','test','1.15'),('2019-09-28 11:59:59','2019-09-29 03:59:59','BQXBTC','4h','0.000007240000000','0.000006610000000','0.030857732053921','0.028172597911107','4262.117687005648','4262.117687005647895','test','test','8.70'),('2019-09-29 07:59:59','2019-09-29 11:59:59','BQXBTC','4h','0.000006950000000','0.000006780000000','0.030261035577740','0.029520837585191','4354.105838523741','4354.105838523741113','test','test','2.44'),('2019-10-01 07:59:59','2019-10-01 11:59:59','BQXBTC','4h','0.000006750000000','0.000006840000000','0.030096547134951','0.030497834430084','4458.747723696495','4458.747723696495086','test','test','0.0'),('2019-10-01 15:59:59','2019-10-08 11:59:59','BQXBTC','4h','0.000006890000000','0.000007430000000','0.030185722089425','0.032551511629090','4381.0917401197885','4381.091740119788483','test','test','0.0'),('2019-10-08 15:59:59','2019-10-09 15:59:59','BQXBTC','4h','0.000007530000000','0.000006780000000','0.030711453098240','0.027652543427101','4078.546228185894','4078.546228185894051','test','test','9.96'),('2019-11-08 07:59:59','2019-11-08 11:59:59','BQXBTC','4h','0.000005020000000','0.000004880000000','0.030031695393542','0.029194158071810','5982.409440944666','5982.409440944666130','test','test','2.78'),('2019-11-14 15:59:59','2019-11-14 19:59:59','BQXBTC','4h','0.000004770000000','0.000004640000000','0.029845575988713','0.029032174546673','6256.934169541488','6256.934169541487790','test','test','2.72'),('2019-11-17 15:59:59','2019-11-17 23:59:59','BQXBTC','4h','0.000004710000000','0.000004720000000','0.029664820112704','0.029727802745640','6298.26329356773','6298.263293567730216','test','test','0.21'),('2019-11-18 03:59:59','2019-11-18 07:59:59','BQXBTC','4h','0.000004670000000','0.000004680000000','0.029678816253356','0.029742368322421','6355.20690650031','6355.206906500309742','test','test','0.0'),('2019-11-18 11:59:59','2019-11-18 15:59:59','BQXBTC','4h','0.000004740000000','0.000004690000000','0.029692938935371','0.029379722279935','6264.333108728036','6264.333108728035768','test','test','1.05'),('2019-11-26 23:59:59','2019-11-27 07:59:59','BQXBTC','4h','0.000004180000000','0.000004210000000','0.029623335234163','0.029835942903308','7086.922304823658','7086.922304823658123','test','test','0.23');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 19:47:35
