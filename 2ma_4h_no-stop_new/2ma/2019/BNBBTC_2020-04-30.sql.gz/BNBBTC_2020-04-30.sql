-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-06 19:59:59','BNBBTC','4h','0.001584200000000','0.001570800000000','0.033333333333333','0.033051382401212','21.04111433741531','21.041114337415308','test','test','3.20'),('2019-01-06 23:59:59','2019-01-07 11:59:59','BNBBTC','4h','0.001571600000000','0.001548600000000','0.033270677570640','0.032783768952592','21.16993991514366','21.169939915143662','test','test','1.46'),('2019-01-07 15:59:59','2019-01-13 19:59:59','BNBBTC','4h','0.001554900000000','0.001596000000000','0.033162475655518','0.034039045048689','21.327722461584667','21.327722461584667','test','test','0.0'),('2019-01-14 03:59:59','2019-01-14 07:59:59','BNBBTC','4h','0.001616700000000','0.001608900000000','0.033357268854000','0.033196331947300','20.632936756355814','20.632936756355814','test','test','0.48'),('2019-01-14 11:59:59','2019-01-14 15:59:59','BNBBTC','4h','0.001610800000000','0.001627500000000','0.033321505096956','0.033666966442324','20.686308105882787','20.686308105882787','test','test','0.0'),('2019-01-14 19:59:59','2019-01-15 11:59:59','BNBBTC','4h','0.001629100000000','0.001624100000000','0.033398274284816','0.033295768992677','20.50105842785314','20.501058427853138','test','test','0.38'),('2019-01-15 15:59:59','2019-01-15 23:59:59','BNBBTC','4h','0.001618100000000','0.001632900000000','0.033375495331007','0.033680765296336','20.62634900871818','20.626349008718179','test','test','0.0'),('2019-01-16 03:59:59','2019-01-28 15:59:59','BNBBTC','4h','0.001641400000000','0.001800900000000','0.033443333101080','0.036693126953658','20.374883088266117','20.374883088266117','test','test','0.0'),('2019-02-01 07:59:59','2019-02-14 15:59:59','BNBBTC','4h','0.001860000000000','0.002378400000000','0.034165509512764','0.043687767647934','18.368553501486023','18.368553501486023','test','test','0.0'),('2019-02-14 19:59:59','2019-02-18 19:59:59','BNBBTC','4h','0.002427500000000','0.002485900000000','0.036281566876135','0.037154416929921','14.94606256483424','14.946062564834239','test','test','0.0'),('2019-02-18 23:59:59','2019-02-19 15:59:59','BNBBTC','4h','0.002463900000000','0.002630500000000','0.036475533554754','0.038941877111807','14.803982935490167','14.803982935490167','test','test','0.12'),('2019-02-19 19:59:59','2019-02-23 19:59:59','BNBBTC','4h','0.002750300000000','0.002635100000000','0.037023609900766','0.035472826400578','13.461662328024579','13.461662328024579','test','test','4.94'),('2019-02-23 23:59:59','2019-02-24 07:59:59','BNBBTC','4h','0.002603800000000','0.002597700000000','0.036678991345169','0.036593062377043','14.086716086169702','14.086716086169702','test','test','0.23'),('2019-02-24 11:59:59','2019-02-24 15:59:59','BNBBTC','4h','0.002630000000000','0.002591100000000','0.036659896018918','0.036117664096813','13.939123961565947','13.939123961565947','test','test','1.47'),('2019-02-24 19:59:59','2019-02-25 15:59:59','BNBBTC','4h','0.002628400000000','0.002585600000000','0.036539400036228','0.035944404479406','13.901765346305146','13.901765346305146','test','test','1.62'),('2019-02-27 15:59:59','2019-02-27 23:59:59','BNBBTC','4h','0.002584600000000','0.002582400000000','0.036407178801379','0.036376189173056','14.08619469216866','14.086194692168659','test','test','0.33'),('2019-02-28 03:59:59','2019-02-28 11:59:59','BNBBTC','4h','0.002574700000000','0.002699300000000','0.036400292217307','0.038161847509293','14.13768292123639','14.137682921236390','test','test','0.0'),('2019-02-28 15:59:59','2019-03-19 15:59:59','BNBBTC','4h','0.002685800000000','0.003857300000000','0.036791748948860','0.052839680251857','13.698618269737052','13.698618269737052','test','test','0.55'),('2019-03-19 19:59:59','2019-03-20 07:59:59','BNBBTC','4h','0.003814300000000','0.003776300000000','0.040357955905081','0.039955889385826','10.580697875122915','10.580697875122915','test','test','0.99'),('2019-03-20 11:59:59','2019-03-20 15:59:59','BNBBTC','4h','0.003771500000000','0.003756600000000','0.040268607789691','0.040109519295440','10.67708015105166','10.677080151051660','test','test','0.39'),('2019-03-22 19:59:59','2019-03-23 15:59:59','BNBBTC','4h','0.003799900000000','0.003779400000000','0.040233254790969','0.040016201257135','10.587977260182871','10.587977260182871','test','test','0.73'),('2019-03-23 19:59:59','2019-03-23 23:59:59','BNBBTC','4h','0.003773800000000','0.003780800000000','0.040185020672339','0.040259559636965','10.648423518029336','10.648423518029336','test','test','0.0'),('2019-03-24 11:59:59','2019-03-30 03:59:59','BNBBTC','4h','0.004268000000000','0.003933700000000','0.040201584886700','0.037052711918653','9.41930292565615','9.419302925656149','test','test','7.83'),('2019-03-30 11:59:59','2019-04-02 07:59:59','BNBBTC','4h','0.004026000000000','0.004032700000000','0.039501835338246','0.039567573613647','9.811682895739086','9.811682895739086','test','test','0.0'),('2019-04-02 19:59:59','2019-04-02 23:59:59','BNBBTC','4h','0.004200000000000','0.004060600000000','0.039516443843890','0.038204874255357','9.40867710568815','9.408677105688151','test','test','3.31'),('2019-04-13 23:59:59','2019-04-14 03:59:59','BNBBTC','4h','0.003687700000000','0.003674800000000','0.039224983935327','0.039087770416666','10.63670687293634','10.636706872936340','test','test','0.34'),('2019-04-14 07:59:59','2019-04-16 07:59:59','BNBBTC','4h','0.003783100000000','0.003771400000000','0.039194492042292','0.039073275168063','10.360416600748476','10.360416600748476','test','test','0.85'),('2019-04-16 11:59:59','2019-04-17 19:59:59','BNBBTC','4h','0.003825700000000','0.003738000000000','0.039167554959130','0.038269681479789','10.238010026695653','10.238010026695653','test','test','2.29'),('2019-04-17 23:59:59','2019-04-18 03:59:59','BNBBTC','4h','0.003744400000000','0.003718400000000','0.038968027519276','0.038697445125434','10.407015147760925','10.407015147760925','test','test','0.69'),('2019-04-18 07:59:59','2019-04-23 19:59:59','BNBBTC','4h','0.003929900000000','0.004150000000000','0.038907898098422','0.041086993844233','9.900480444393555','9.900480444393555','test','test','0.0'),('2019-04-24 23:59:59','2019-04-25 03:59:59','BNBBTC','4h','0.004245200000000','0.004271200000000','0.039392141597491','0.039633401298220','9.27921925880791','9.279219258807910','test','test','0.0'),('2019-04-25 07:59:59','2019-04-25 11:59:59','BNBBTC','4h','0.004229900000000','0.004203400000000','0.039445754864320','0.039198630226881','9.325458016577224','9.325458016577224','test','test','0.62'),('2019-04-25 15:59:59','2019-04-25 23:59:59','BNBBTC','4h','0.004175000000000','0.004305500000000','0.039390838278222','0.040622096816020','9.434931324125138','9.434931324125138','test','test','0.0'),('2019-04-26 03:59:59','2019-04-29 11:59:59','BNBBTC','4h','0.004394300000000','0.004193300000000','0.039664451286622','0.037850156698494','9.026341234467834','9.026341234467834','test','test','4.57'),('2019-05-02 15:59:59','2019-05-03 03:59:59','BNBBTC','4h','0.004283300000000','0.004191900000000','0.039261274711482','0.038423490641109','9.166127684608234','9.166127684608234','test','test','2.13'),('2019-05-17 07:59:59','2019-05-26 19:59:59','BNBBTC','4h','0.003397700000000','0.003871200000000','0.039075100473622','0.044520566546042','11.500456330347523','11.500456330347523','test','test','0.0'),('2019-05-27 03:59:59','2019-05-27 07:59:59','BNBBTC','4h','0.003947800000000','0.003914600000000','0.040285204045271','0.039946415663311','10.204469336154485','10.204469336154485','test','test','0.84'),('2019-05-27 11:59:59','2019-05-27 15:59:59','BNBBTC','4h','0.003936900000000','0.003858400000000','0.040209917738168','0.039408150219957','10.213598958106237','10.213598958106237','test','test','1.99'),('2019-05-29 23:59:59','2019-05-30 03:59:59','BNBBTC','4h','0.003887800000000','0.003989700000000','0.040031747178566','0.041080987118248','10.296760938979888','10.296760938979888','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','BNBBTC','4h','0.003913300000000','0.003877300000000','0.040264911609606','0.039894498705421','10.289247338462795','10.289247338462795','test','test','0.91'),('2019-06-01 07:59:59','2019-06-01 15:59:59','BNBBTC','4h','0.003899300000000','0.003873900000000','0.040182597630899','0.039920848604196','10.305079791475054','10.305079791475054','test','test','0.92'),('2019-06-01 19:59:59','2019-06-01 23:59:59','BNBBTC','4h','0.003864300000000','0.003900000000000','0.040124431180520','0.040495117253844','10.383363398421507','10.383363398421507','test','test','0.0'),('2019-06-04 15:59:59','2019-06-04 19:59:59','BNBBTC','4h','0.003876400000000','0.003825000000000','0.040206805863481','0.039673674653755','10.372202523857476','10.372202523857476','test','test','1.32'),('2019-06-05 11:59:59','2019-06-14 07:59:59','BNBBTC','4h','0.003864000000000','0.004064800000000','0.040088332261320','0.042171597561028','10.374827189782552','10.374827189782552','test','test','0.0'),('2019-06-19 11:59:59','2019-06-19 19:59:59','BNBBTC','4h','0.003875000000000','0.003878100000000','0.040551280105699','0.040583721129784','10.464846478890152','10.464846478890152','test','test','0.00'),('2019-06-20 11:59:59','2019-06-20 15:59:59','BNBBTC','4h','0.003921300000000','0.003859400000000','0.040558489222163','0.039918249892642','10.34312325559449','10.343123255594490','test','test','1.57'),('2019-06-20 23:59:59','2019-06-21 03:59:59','BNBBTC','4h','0.003871000000000','0.003736300000000','0.040416213815602','0.039009842335116','10.44076822929539','10.440768229295390','test','test','3.47'),('2019-07-02 07:59:59','2019-07-02 11:59:59','BNBBTC','4h','0.003251400000000','0.003111100000000','0.040103686819939','0.038373186955008','12.334282715119302','12.334282715119302','test','test','4.31'),('2019-07-14 23:59:59','2019-07-15 03:59:59','BNBBTC','4h','0.002804200000000','0.002741600000000','0.039719131294399','0.038832455016306','14.164157797018282','14.164157797018282','test','test','2.23'),('2019-07-17 15:59:59','2019-07-18 15:59:59','BNBBTC','4h','0.002813600000000','0.002781700000000','0.039522092121489','0.039073999024149','14.046805559244072','14.046805559244072','test','test','1.13'),('2019-07-18 19:59:59','2019-07-18 23:59:59','BNBBTC','4h','0.002759800000000','0.002722800000000','0.039422515877636','0.038893987329382','14.28455535822733','14.284555358227330','test','test','1.34'),('2019-07-19 07:59:59','2019-07-19 15:59:59','BNBBTC','4h','0.002800600000000','0.002788500000000','0.039305065089135','0.039135247447352','14.034515849866063','14.034515849866063','test','test','0.58'),('2019-07-19 19:59:59','2019-07-19 23:59:59','BNBBTC','4h','0.002778400000000','0.002760600000000','0.039267327835405','0.039015759150021','14.133072212570307','14.133072212570307','test','test','0.64'),('2019-07-20 03:59:59','2019-07-27 07:59:59','BNBBTC','4h','0.002896800000000','0.002879000000000','0.039211423683098','0.038970480800759','13.536116985327874','13.536116985327874','test','test','1.69'),('2019-07-27 11:59:59','2019-07-28 23:59:59','BNBBTC','4h','0.002908400000000','0.002905500000000','0.039157880820356','0.039118836034777','13.463719165299059','13.463719165299059','test','test','0.30'),('2019-08-08 11:59:59','2019-08-08 15:59:59','BNBBTC','4h','0.002644900000000','0.002629300000000','0.039149204201338','0.038918296573246','14.80177103154684','14.801771031546840','test','test','0.58'),('2019-08-08 19:59:59','2019-08-08 23:59:59','BNBBTC','4h','0.002641700000000','0.002595600000000','0.039097891395096','0.038415598631605','14.800276865312323','14.800276865312323','test','test','1.74'),('2019-08-09 03:59:59','2019-08-09 07:59:59','BNBBTC','4h','0.002638800000000','0.002589600000000','0.038946270780986','0.038220123849644','14.759083970360184','14.759083970360184','test','test','1.86'),('2019-08-10 19:59:59','2019-08-16 19:59:59','BNBBTC','4h','0.002618700000000','0.002659600000000','0.038784904796244','0.039390664373961','14.810747621431926','14.810747621431926','test','test','0.95'),('2019-08-16 23:59:59','2019-08-18 11:59:59','BNBBTC','4h','0.002661000000000','0.002663700000000','0.038919518035736','0.038959007963844','14.62589929941242','14.625899299412421','test','test','0.0'),('2019-08-18 15:59:59','2019-08-19 19:59:59','BNBBTC','4h','0.002691800000000','0.002665700000000','0.038928293575316','0.038550840398142','14.461807554541945','14.461807554541945','test','test','0.96'),('2019-08-21 07:59:59','2019-08-21 15:59:59','BNBBTC','4h','0.002678200000000','0.002656900000000','0.038844415091500','0.038535481463896','14.503926178589936','14.503926178589936','test','test','0.79'),('2019-08-21 19:59:59','2019-08-21 23:59:59','BNBBTC','4h','0.002670600000000','0.002656200000000','0.038775763174254','0.038566682447185','14.519494935315745','14.519494935315745','test','test','0.53'),('2019-08-22 03:59:59','2019-08-22 07:59:59','BNBBTC','4h','0.002673100000000','0.002664800000000','0.038729300790461','0.038609045956538','14.488534207646973','14.488534207646973','test','test','0.31'),('2019-08-22 11:59:59','2019-08-22 19:59:59','BNBBTC','4h','0.002679400000000','0.002662400000000','0.038702577494034','0.038457021094318','14.444494100930726','14.444494100930726','test','test','0.63'),('2019-08-22 23:59:59','2019-08-23 07:59:59','BNBBTC','4h','0.002670000000000','0.002647900000000','0.038648009405208','0.038328113896648','14.474909889591014','14.474909889591014','test','test','0.82'),('2019-09-18 03:59:59','2019-09-19 07:59:59','BNBBTC','4h','0.002120800000000','0.002094900000000','0.038576921514417','0.038105805771667','18.18979701735991','18.189797017359911','test','test','1.22'),('2019-09-19 11:59:59','2019-09-19 23:59:59','BNBBTC','4h','0.002122900000000','0.002101200000000','0.038472229127139','0.038078971144163','18.122487694728495','18.122487694728495','test','test','1.02'),('2019-09-20 03:59:59','2019-09-20 07:59:59','BNBBTC','4h','0.002093500000000','0.002081000000000','0.038384838464256','0.038155647883505','18.3352464601173','18.335246460117300','test','test','0.59'),('2019-09-20 11:59:59','2019-09-20 15:59:59','BNBBTC','4h','0.002106400000000','0.002091600000000','0.038333907224089','0.038064565300942','18.198778591002977','18.198778591002977','test','test','0.70'),('2019-09-21 03:59:59','2019-09-21 15:59:59','BNBBTC','4h','0.002110700000000','0.002091000000000','0.038274053463389','0.037916826546618','18.133346028990072','18.133346028990072','test','test','0.93'),('2019-09-21 23:59:59','2019-09-22 03:59:59','BNBBTC','4h','0.002100000000000','0.002065600000000','0.038194669704107','0.037569004638478','18.18793795433662','18.187937954336618','test','test','1.63'),('2019-10-05 23:59:59','2019-10-06 03:59:59','BNBBTC','4h','0.001929800000000','0.001929600000000','0.038055633022856','0.038051689025237','19.719988093510214','19.719988093510214','test','test','0.01'),('2019-10-07 11:59:59','2019-10-07 15:59:59','BNBBTC','4h','0.001945000000000','0.001932500000000','0.038054756578941','0.037810188734603','19.5654275470132','19.565427547013201','test','test','0.64'),('2019-10-07 19:59:59','2019-10-21 07:59:59','BNBBTC','4h','0.001938300000000','0.002195700000000','0.038000408169088','0.043046740038625','19.605018918169417','19.605018918169417','test','test','0.05'),('2019-10-21 11:59:59','2019-10-23 15:59:59','BNBBTC','4h','0.002221400000000','0.002218400000000','0.039121815251207','0.039068981252038','17.611333056274024','17.611333056274024','test','test','0.94'),('2019-10-23 19:59:59','2019-10-25 15:59:59','BNBBTC','4h','0.002230000000000','0.002231500000000','0.039110074362503','0.039136381587411','17.538149938342105','17.538149938342105','test','test','0.38'),('2019-10-28 23:59:59','2019-10-29 03:59:59','BNBBTC','4h','0.002165000000000','0.002187200000000','0.039115920412482','0.039517016686458','18.067399728629308','18.067399728629308','test','test','0.0'),('2019-10-29 07:59:59','2019-10-30 03:59:59','BNBBTC','4h','0.002203600000000','0.002189900000000','0.039205052917810','0.038961311211069','17.791365455532063','17.791365455532063','test','test','0.62'),('2019-10-30 07:59:59','2019-10-30 11:59:59','BNBBTC','4h','0.002187500000000','0.002163600000000','0.039150888094090','0.038723136676742','17.897548843012675','17.897548843012675','test','test','1.09'),('2019-10-30 23:59:59','2019-10-31 07:59:59','BNBBTC','4h','0.002189600000000','0.002175700000000','0.039055832223568','0.038807898323354','17.836971238385303','17.836971238385303','test','test','0.63'),('2019-10-31 11:59:59','2019-10-31 15:59:59','BNBBTC','4h','0.002186900000000','0.002166700000000','0.039000735801299','0.038640493054403','17.833799351272884','17.833799351272884','test','test','0.92'),('2019-10-31 19:59:59','2019-10-31 23:59:59','BNBBTC','4h','0.002169400000000','0.002176900000000','0.038920681857544','0.039055237547565','17.940758669468057','17.940758669468057','test','test','0.0'),('2019-11-01 03:59:59','2019-11-01 07:59:59','BNBBTC','4h','0.002179900000000','0.002169400000000','0.038950583121993','0.038762968496193','17.868059599978494','17.868059599978494','test','test','0.48'),('2019-11-01 11:59:59','2019-11-01 15:59:59','BNBBTC','4h','0.002169900000000','0.002172900000000','0.038908890982926','0.038962684555417','17.93119083041912','17.931190830419119','test','test','0.0'),('2019-11-02 03:59:59','2019-11-02 07:59:59','BNBBTC','4h','0.002173300000000','0.002180900000000','0.038920845110147','0.039056950766447','17.908638986861764','17.908638986861764','test','test','0.0'),('2019-11-02 11:59:59','2019-11-02 15:59:59','BNBBTC','4h','0.002180800000000','0.002169400000000','0.038951090811547','0.038747476341971','17.860918383871365','17.860918383871365','test','test','0.52'),('2019-11-02 19:59:59','2019-11-02 23:59:59','BNBBTC','4h','0.002174300000000','0.002173100000000','0.038905843151641','0.038884370948273','17.8935028062553','17.893502806255299','test','test','0.05'),('2019-11-03 03:59:59','2019-11-03 15:59:59','BNBBTC','4h','0.002183100000000','0.002173300000000','0.038901071550892','0.038726443498490','17.819189020609432','17.819189020609432','test','test','0.44'),('2019-11-03 19:59:59','2019-11-04 23:59:59','BNBBTC','4h','0.002180000000000','0.002195500000000','0.038862265317025','0.039138579588774','17.82672720964465','17.826727209644648','test','test','0.0'),('2019-11-05 03:59:59','2019-11-07 11:59:59','BNBBTC','4h','0.002201100000000','0.002190400000000','0.038923668488525','0.038734452527039','17.68373471833407','17.683734718334069','test','test','0.48'),('2019-11-07 15:59:59','2019-11-18 07:59:59','BNBBTC','4h','0.002200500000000','0.002326700000000','0.038881620497084','0.041111504844610','17.669448078656572','17.669448078656572','test','test','0.0'),('2019-12-29 15:59:59','2020-01-01 15:59:59','BNBBTC','4h','0.001910400000000','0.001910800000000','0.039377150352090','0.039385395149065','20.61199243723281','20.611992437232811','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 20:01:30
