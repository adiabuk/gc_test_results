-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 23:59:59','2019-01-14 03:59:59','WAVESBNB','4h','0.476700000000000','0.461900000000000','3.111111111111111','3.014521129058574','6.526350138684941','6.526350138684941','test','test','3.10'),('2019-01-14 07:59:59','2019-01-14 15:59:59','WAVESBNB','4h','0.468500000000000','0.468900000000000','3.089646670654992','3.092284576030151','6.5947634378975275','6.594763437897528','test','test','0.0'),('2019-01-22 23:59:59','2019-01-24 23:59:59','WAVESBNB','4h','0.427900000000000','0.422000000000000','3.090232871849471','3.047623911943157','7.221857611239709','7.221857611239709','test','test','1.37'),('2019-01-25 11:59:59','2019-01-25 15:59:59','WAVESBNB','4h','0.433700000000000','0.437100000000000','3.080764214092513','3.104915928014382','7.103445271137914','7.103445271137914','test','test','0.0'),('2019-01-28 19:59:59','2019-02-01 03:59:59','WAVESBNB','4h','0.451700000000000','0.433800000000000','3.086131261630706','2.963833830629622','6.832258715144357','6.832258715144357','test','test','3.96'),('2019-02-26 23:59:59','2019-02-27 03:59:59','WAVESBNB','4h','0.280700000000000','0.279400000000000','3.058954054741576','3.044787185232619','10.897591929966428','10.897591929966428','test','test','0.46'),('2019-03-21 11:59:59','2019-03-22 11:59:59','WAVESBNB','4h','0.187300000000000','0.183900000000000','3.055805861517364','3.000334746038672','16.315033964321216','16.315033964321216','test','test','1.81'),('2019-03-24 03:59:59','2019-03-24 11:59:59','WAVESBNB','4h','0.187400000000000','0.160700000000000','3.043478946966543','2.609856279495856','16.24054934347141','16.240549343471411','test','test','14.2'),('2019-03-30 03:59:59','2019-03-30 07:59:59','WAVESBNB','4h','0.173900000000000','0.171000000000000','2.947118354195279','2.897971469622730','16.94720157674111','16.947201576741111','test','test','1.66'),('2019-04-07 03:59:59','2019-04-07 15:59:59','WAVESBNB','4h','0.163400000000000','0.159400000000000','2.936196824290268','2.864319301051828','17.969380809609966','17.969380809609966','test','test','2.44'),('2019-04-08 19:59:59','2019-04-08 23:59:59','WAVESBNB','4h','0.163900000000000','0.158800000000000','2.920224041348393','2.829356789299114','17.81710824495664','17.817108244956639','test','test','3.11'),('2019-04-11 15:59:59','2019-04-11 19:59:59','WAVESBNB','4h','0.164900000000000','0.155300000000000','2.900031318670775','2.731199901695399','17.586605934934962','17.586605934934962','test','test','5.82'),('2019-05-07 11:59:59','2019-05-07 15:59:59','WAVESBNB','4h','0.098200000000000','0.110200000000000','2.862513226009581','3.212311176234785','29.149829185433614','29.149829185433614','test','test','0.0'),('2019-05-07 19:59:59','2019-05-08 03:59:59','WAVESBNB','4h','0.108000000000000','0.099800000000000','2.940246103837403','2.717005195953452','27.224500961457437','27.224500961457437','test','test','7.59'),('2019-05-08 07:59:59','2019-05-13 07:59:59','WAVESBNB','4h','0.099900000000000','0.105800000000000','2.890637013196526','3.061355315277202','28.93530543740266','28.935305437402661','test','test','0.0'),('2019-05-23 23:59:59','2019-05-24 07:59:59','WAVESBNB','4h','0.105000000000000','0.087100000000000','2.928574413658898','2.429322204092286','27.89118489198951','27.891184891989511','test','test','17.0'),('2019-06-16 23:59:59','2019-06-17 07:59:59','WAVESBNB','4h','0.075300000000000','0.074200000000000','2.817629478199651','2.776468888212670','37.418718169982085','37.418718169982085','test','test','1.46'),('2019-06-17 11:59:59','2019-06-17 15:59:59','WAVESBNB','4h','0.075200000000000','0.072200000000000','2.808482680424766','2.696442147961012','37.34684415458466','37.346844154584659','test','test','3.98'),('2019-07-03 23:59:59','2019-07-04 03:59:59','WAVESBNB','4h','0.060000000000000','0.059100000000000','2.783584784321711','2.741831012556885','46.39307973869518','46.393079738695178','test','test','1.49'),('2019-07-06 15:59:59','2019-07-06 23:59:59','WAVESBNB','4h','0.061900000000000','0.059400000000000','2.774306168373971','2.662258261735281','44.81916265547611','44.819162655476113','test','test','4.03'),('2019-07-07 03:59:59','2019-07-08 07:59:59','WAVESBNB','4h','0.064400000000000','0.058900000000000','2.749406633565373','2.514597060822989','42.69264958952443','42.692649589524429','test','test','8.54'),('2019-07-16 15:59:59','2019-07-17 03:59:59','WAVESBNB','4h','0.058390000000000','0.055590000000000','2.697226728511510','2.567885491316233','46.19329899831324','46.193298998313239','test','test','4.79'),('2019-07-17 07:59:59','2019-07-17 11:59:59','WAVESBNB','4h','0.054760000000000','0.055320000000000','2.668484231357004','2.695773332335088','48.73053746086567','48.730537460865669','test','test','0.0'),('2019-07-29 07:59:59','2019-07-31 07:59:59','WAVESBNB','4h','0.049500000000000','0.050420000000000','2.674548476018801','2.724257255775110','54.03128234381415','54.031282343814148','test','test','0.0'),('2019-07-31 11:59:59','2019-07-31 15:59:59','WAVESBNB','4h','0.050200000000000','0.050140000000000','2.685594871520202','2.682384997171771','53.49790580717534','53.497905807175343','test','test','0.11'),('2019-07-31 19:59:59','2019-07-31 23:59:59','WAVESBNB','4h','0.050250000000000','0.049560000000000','2.684881566109440','2.648014535649430','53.430478927551036','53.430478927551036','test','test','1.37'),('2019-08-04 19:59:59','2019-08-05 03:59:59','WAVESBNB','4h','0.050140000000000','0.050360000000000','2.676688892673882','2.688433439071733','53.384301808414094','53.384301808414094','test','test','0.81'),('2019-08-05 07:59:59','2019-08-05 11:59:59','WAVESBNB','4h','0.050250000000000','0.048800000000000','2.679298791873405','2.601985692406411','53.31937894275432','53.319378942754319','test','test','2.88'),('2019-08-05 19:59:59','2019-08-06 11:59:59','WAVESBNB','4h','0.050960000000000','0.048990000000000','2.662118103102962','2.559206551629005','52.23936623043489','52.239366230434889','test','test','3.86'),('2019-08-07 07:59:59','2019-08-07 11:59:59','WAVESBNB','4h','0.050050000000000','0.049000000000000','2.639248869442083','2.583880012041200','52.73224514369796','52.732245143697959','test','test','2.09'),('2019-08-18 11:59:59','2019-08-18 23:59:59','WAVESBNB','4h','0.045520000000000','0.045140000000000','2.626944678908553','2.605015000130318','57.70968099535485','57.709680995354852','test','test','1.42'),('2019-08-19 03:59:59','2019-08-19 07:59:59','WAVESBNB','4h','0.044820000000000','0.043440000000000','2.622071416957834','2.541338294347352','58.502262761218965','58.502262761218965','test','test','3.07'),('2019-08-20 15:59:59','2019-08-20 23:59:59','WAVESBNB','4h','0.045050000000000','0.044250000000000','2.604130723044393','2.557886448273349','57.80534346380451','57.805343463804512','test','test','1.77'),('2019-08-21 15:59:59','2019-08-22 03:59:59','WAVESBNB','4h','0.045170000000000','0.045070000000000','2.593854217539717','2.588111790668918','57.42426870798576','57.424268707985760','test','test','0.22'),('2019-08-22 07:59:59','2019-08-28 03:59:59','WAVESBNB','4h','0.045150000000000','0.048450000000000','2.592578122679539','2.782068882476715','57.421442362780496','57.421442362780496','test','test','0.0'),('2019-08-28 07:59:59','2019-08-28 19:59:59','WAVESBNB','4h','0.047820000000000','0.048560000000000','2.634687180412245','2.675458165638198','55.09592598101725','55.095925981017253','test','test','0.0'),('2019-08-28 23:59:59','2019-09-02 15:59:59','WAVESBNB','4h','0.050030000000000','0.050490000000000','2.643747399351346','2.668055290690575','52.84324204180184','52.843242041801837','test','test','0.41'),('2019-09-02 19:59:59','2019-09-03 15:59:59','WAVESBNB','4h','0.050270000000000','0.050840000000000','2.649149152982285','2.679187247615265','52.69841163680695','52.698411636806952','test','test','0.71'),('2019-09-03 19:59:59','2019-09-05 19:59:59','WAVESBNB','4h','0.051190000000000','0.048360000000000','2.655824285122948','2.508999070688528','51.88170121357585','51.881701213575852','test','test','5.52'),('2019-09-11 19:59:59','2019-09-11 23:59:59','WAVESBNB','4h','0.049850000000000','0.049180000000000','2.623196459693077','2.587939857326089','52.621794577594315','52.621794577594315','test','test','1.34'),('2019-09-12 03:59:59','2019-09-12 11:59:59','WAVESBNB','4h','0.049450000000000','0.050630000000000','2.615361659167080','2.677770693703322','52.88901231884893','52.889012318848927','test','test','0.0'),('2019-09-12 15:59:59','2019-09-13 07:59:59','WAVESBNB','4h','0.049990000000000','0.049370000000000','2.629230333508467','2.596621355577375','52.5951256953084','52.595125695308397','test','test','1.70'),('2019-09-13 19:59:59','2019-09-14 15:59:59','WAVESBNB','4h','0.049180000000000','0.048440000000000','2.621983893968224','2.582531513294444','53.31402793754014','53.314027937540139','test','test','1.50'),('2019-09-15 03:59:59','2019-09-18 11:59:59','WAVESBNB','4h','0.049110000000000','0.052880000000000','2.613216698262939','2.813824048139772','53.21149864106983','53.211498641069831','test','test','0.0'),('2019-09-18 15:59:59','2019-09-19 15:59:59','WAVESBNB','4h','0.051560000000000','0.050520000000000','2.657796109346680','2.604186567963426','51.54763594543599','51.547635945435992','test','test','2.01'),('2019-09-19 19:59:59','2019-09-19 23:59:59','WAVESBNB','4h','0.050840000000000','0.049980000000000','2.645882877928179','2.601125614454177','52.04332962093193','52.043329620931928','test','test','1.69'),('2019-09-22 23:59:59','2019-09-24 15:59:59','WAVESBNB','4h','0.054190000000000','0.050970000000000','2.635936819378401','2.479307984567579','48.64249528286402','48.642495282864019','test','test','5.94'),('2019-09-24 19:59:59','2019-09-24 23:59:59','WAVESBNB','4h','0.051460000000000','0.052300000000000','2.601130411642663','2.643589594421129','50.546646164839935','50.546646164839935','test','test','0.0'),('2019-09-25 03:59:59','2019-10-01 07:59:59','WAVESBNB','4h','0.052040000000000','0.052770000000000','2.610565785593433','2.647185943615785','50.16460003061939','50.164600030619390','test','test','0.0'),('2019-10-03 03:59:59','2019-10-09 07:59:59','WAVESBNB','4h','0.055610000000000','0.053490000000000','2.618703598487289','2.518871704425195','47.09051606702552','47.090516067025519','test','test','3.81'),('2019-11-17 03:59:59','2019-11-17 07:59:59','WAVESBNB','4h','0.038460000000000','0.038420000000000','2.596518733140157','2.593818245638191','67.51218754914605','67.512187549146049','test','test','0.10'),('2019-11-17 11:59:59','2019-11-17 15:59:59','WAVESBNB','4h','0.038500000000000','0.037740000000000','2.595918624806387','2.544674516888131','67.42645778717888','67.426457787178876','test','test','1.97'),('2019-11-17 19:59:59','2019-11-17 23:59:59','WAVESBNB','4h','0.038470000000000','0.038180000000000','2.584531045268997','2.565047967464786','67.18302691107348','67.183026911073483','test','test','0.75'),('2019-11-18 03:59:59','2019-11-18 19:59:59','WAVESBNB','4h','0.038740000000000','0.038180000000000','2.580201472423616','2.542903774319403','66.60303232895242','66.603032328952423','test','test','1.44'),('2019-11-19 11:59:59','2019-11-20 07:59:59','WAVESBNB','4h','0.038520000000000','0.038490000000000','2.571913095067125','2.569910047485298','66.76825272759929','66.768252727599290','test','test','0.07'),('2019-11-20 11:59:59','2019-11-21 15:59:59','WAVESBNB','4h','0.038510000000000','0.038950000000000','2.571467973382274','2.600848547474411','66.77403202758437','66.774032027584369','test','test','0.0'),('2019-11-21 19:59:59','2019-11-21 23:59:59','WAVESBNB','4h','0.038350000000000','0.038720000000000','2.577996989847193','2.602869451026944','67.22286805338183','67.222868053381831','test','test','0.0'),('2019-11-22 03:59:59','2019-11-23 19:59:59','WAVESBNB','4h','0.039540000000000','0.038980000000000','2.583524203442694','2.546934078153673','65.33950944468118','65.339509444681184','test','test','1.41'),('2019-11-23 23:59:59','2019-11-24 03:59:59','WAVESBNB','4h','0.038840000000000','0.038280000000000','2.575393064489578','2.538260723703941','66.30775140292425','66.307751402924254','test','test','1.44'),('2019-11-25 23:59:59','2019-11-26 03:59:59','WAVESBNB','4h','0.039100000000000','0.037950000000000','2.567141433203881','2.491637273403767','65.65579113053403','65.655791130534027','test','test','2.94'),('2019-11-26 19:59:59','2019-11-27 03:59:59','WAVESBNB','4h','0.038990000000000','0.038430000000000','2.550362731026078','2.513732745661251','65.41068815147673','65.410688151476734','test','test','1.43'),('2019-11-27 07:59:59','2019-11-27 11:59:59','WAVESBNB','4h','0.039070000000000','0.038620000000000','2.542222734278339','2.512941950289978','65.06840886302378','65.068408863023777','test','test','1.15'),('2019-11-27 15:59:59','2019-11-27 19:59:59','WAVESBNB','4h','0.039200000000000','0.038180000000000','2.535715893392036','2.469735530859896','64.68662993347031','64.686629933470314','test','test','2.60'),('2019-11-28 15:59:59','2019-11-29 11:59:59','WAVESBNB','4h','0.039080000000000','0.038630000000000','2.521053590607116','2.492024058473718','64.51007140755159','64.510071407551592','test','test','1.15'),('2019-11-29 15:59:59','2019-11-29 19:59:59','WAVESBNB','4h','0.038860000000000','0.039110000000000','2.514602583466361','2.530779903226181','64.70927903927846','64.709279039278456','test','test','0.0'),('2019-11-29 23:59:59','2019-11-30 11:59:59','WAVESBNB','4h','0.038850000000000','0.038670000000000','2.518197543412987','2.506530218887521','64.81846958591987','64.818469585919871','test','test','0.46'),('2019-12-01 11:59:59','2019-12-02 11:59:59','WAVESBNB','4h','0.039340000000000','0.038920000000000','2.515604804629551','2.488747813832795','63.945216182754216','63.945216182754216','test','test','1.22'),('2019-12-02 15:59:59','2019-12-02 19:59:59','WAVESBNB','4h','0.038960000000000','0.038840000000000','2.509636584452494','2.501906697642065','64.41572342023855','64.415723420238550','test','test','0.30'),('2019-12-02 23:59:59','2019-12-03 07:59:59','WAVESBNB','4h','0.038880000000000','0.038750000000000','2.507918831827954','2.499533300754456','64.50408518076013','64.504085180760129','test','test','0.33'),('2019-12-03 11:59:59','2019-12-03 15:59:59','WAVESBNB','4h','0.039180000000000','0.038220000000000','2.506055380478288','2.444651267020933','63.96261818474446','63.962618184744457','test','test','2.45'),('2019-12-11 11:59:59','2019-12-15 03:59:59','WAVESBNB','4h','0.037890000000000','0.047550000000000','2.492410021932209','3.127846306225298','65.78015365352887','65.780153653528870','test','test','0.0'),('2019-12-15 07:59:59','2020-01-01 15:59:59','WAVESBNB','4h','0.049370000000000','0.075800000000000','2.633618085108451','4.043513284407953','53.34450243282258','53.344502432822580','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 19:05:49
