-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','ZRXETH','4h','0.002295920000000','0.002259720000000','1.297777777777778','1.277315585908917','565.2539190293119','565.253919029311874','test','test','1.57'),('2019-01-11 19:59:59','2019-01-12 03:59:59','ZRXETH','4h','0.002289560000000','0.002237980000000','1.293230624029142','1.264096276998524','564.838057980198','564.838057980197959','test','test','2.25'),('2019-01-12 07:59:59','2019-01-12 11:59:59','ZRXETH','4h','0.002243850000000','0.002237890000000','1.286756324689005','1.283338508125890','573.4591548851325','573.459154885132534','test','test','0.26'),('2019-01-12 23:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002255510000000','0.002248650000000','1.285996809897201','1.282085526810052','570.1578844240112','570.157884424011172','test','test','0.30'),('2019-01-14 19:59:59','2019-01-14 23:59:59','ZRXETH','4h','0.002249900000000','0.002213830000000','1.285127635877835','1.264524696268913','571.1932245334614','571.193224533461375','test','test','1.60'),('2019-01-15 11:59:59','2019-01-15 15:59:59','ZRXETH','4h','0.002273510000000','0.002267500000000','1.280549204853630','1.277164086371120','563.2476676388624','563.247667638862367','test','test','0.26'),('2019-01-15 19:59:59','2019-01-26 15:59:59','ZRXETH','4h','0.002266480000000','0.002482570000000','1.279796956301961','1.401814942027531','564.6628058937034','564.662805893703421','test','test','0.0'),('2019-01-26 19:59:59','2019-01-27 07:59:59','ZRXETH','4h','0.002477380000000','0.002413450000000','1.306912064240976','1.273186560577055','527.5379894247053','527.537989424705302','test','test','2.58'),('2019-01-28 23:59:59','2019-01-29 03:59:59','ZRXETH','4h','0.002451780000000','0.002446360000000','1.299417507871216','1.296544965109360','529.989439456728','529.989439456727951','test','test','0.22'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ZRXETH','4h','0.002354000000000','0.002242360000000','1.298779165035248','1.237183707947510','551.7328653505728','551.732865350572752','test','test','4.74'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXETH','4h','0.001777610000000','0.001827560000000','1.285091285682418','1.321201742824219','722.9320749109297','722.932074910929714','test','test','0.0'),('2019-02-26 19:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001827100000000','0.001813540000000','1.293115831713929','1.283518847050779','707.742231795703','707.742231795702992','test','test','2.02'),('2019-02-28 15:59:59','2019-03-01 07:59:59','ZRXETH','4h','0.001822990000000','0.001814430000000','1.290983168455451','1.284921250440553','708.1679923946106','708.167992394610565','test','test','0.49'),('2019-03-01 11:59:59','2019-03-01 19:59:59','ZRXETH','4h','0.001811530000000','0.001815370000000','1.289636075563252','1.292369788242679','711.9043436008521','711.904343600852144','test','test','0.36'),('2019-03-01 23:59:59','2019-03-03 03:59:59','ZRXETH','4h','0.001836990000000','0.001821490000000','1.290243567269791','1.279356858418528','702.3683129847146','702.368312984714635','test','test','0.84'),('2019-03-03 07:59:59','2019-03-04 07:59:59','ZRXETH','4h','0.001817670000000','0.001795570000000','1.287824298636177','1.272166386584012','708.5028077902904','708.502807790290376','test','test','1.21'),('2019-03-04 19:59:59','2019-03-04 23:59:59','ZRXETH','4h','0.001818010000000','0.001803360000000','1.284344762624585','1.273995176663864','706.4563795713912','706.456379571391153','test','test','0.80'),('2019-03-09 03:59:59','2019-03-09 11:59:59','ZRXETH','4h','0.001800000000000','0.001792450000000','1.282044854633314','1.276667388715269','712.2471414629521','712.247141462952072','test','test','0.41'),('2019-03-09 15:59:59','2019-03-16 03:59:59','ZRXETH','4h','0.001849400000000','0.001927160000000','1.280849862207081','1.334704563886124','692.5758960782314','692.575896078231381','test','test','1.13'),('2019-03-16 07:59:59','2019-03-16 11:59:59','ZRXETH','4h','0.001939380000000','0.001912130000000','1.292817573691313','1.274652346204648','666.6138527216497','666.613852721649664','test','test','1.40'),('2019-03-16 15:59:59','2019-03-16 19:59:59','ZRXETH','4h','0.001926150000000','0.001919510000000','1.288780856472054','1.284338053529929','669.096828633312','669.096828633312043','test','test','0.34'),('2019-03-19 11:59:59','2019-03-19 15:59:59','ZRXETH','4h','0.001915800000000','0.001946830000000','1.287793566929360','1.308651816423993','672.1962453958449','672.196245395844926','test','test','0.0'),('2019-03-19 19:59:59','2019-03-21 15:59:59','ZRXETH','4h','0.001941060000000','0.001907060000000','1.292428733483723','1.269790290087616','665.8365704737218','665.836570473721849','test','test','1.75'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ZRXETH','4h','0.001925130000000','0.001917860000000','1.287397968284588','1.282536279344398','668.7330041527522','668.733004152752187','test','test','0.37'),('2019-03-22 15:59:59','2019-04-03 03:59:59','ZRXETH','4h','0.001940400000000','0.002203380000000','1.286317592964545','1.460650617391372','662.9136224307078','662.913622430707846','test','test','0.0'),('2019-04-03 07:59:59','2019-04-03 19:59:59','ZRXETH','4h','0.002212640000000','0.002200460000000','1.325058265059396','1.317764168564520','598.8584971162935','598.858497116293506','test','test','0.55'),('2019-04-03 23:59:59','2019-04-04 03:59:59','ZRXETH','4h','0.002192680000000','0.002145310000000','1.323437354727201','1.294846211699752','603.5706782235444','603.570678223544405','test','test','2.16'),('2019-04-04 07:59:59','2019-04-04 11:59:59','ZRXETH','4h','0.002195910000000','0.002163480000000','1.317083767387768','1.297632593807619','599.7895029339855','599.789502933985545','test','test','1.47'),('2019-04-06 07:59:59','2019-04-06 11:59:59','ZRXETH','4h','0.002210870000000','0.002210000000000','1.312761284369957','1.312244699352565','593.7758820599842','593.775882059984156','test','test','0.03'),('2019-05-31 19:59:59','2019-05-31 23:59:59','ZRXETH','4h','0.001291110000000','0.001277920000000','1.312646487699425','1.299236470603472','1016.6805986317397','1016.680598631739713','test','test','1.02'),('2019-06-03 07:59:59','2019-06-03 11:59:59','ZRXETH','4h','0.001286320000000','0.001276680000000','1.309666483900325','1.299851519579783','1018.1498257823285','1018.149825782328548','test','test','0.74'),('2019-06-03 15:59:59','2019-06-03 19:59:59','ZRXETH','4h','0.001275480000000','0.001283880000000','1.307485380717982','1.316096160344500','1025.0928126807025','1025.092812680702536','test','test','0.0'),('2019-06-05 19:59:59','2019-06-11 07:59:59','ZRXETH','4h','0.001293000000000','0.001318410000000','1.309398887301653','1.335131157778323','1012.6828208056095','1012.682820805609481','test','test','1.16'),('2019-06-11 11:59:59','2019-06-11 15:59:59','ZRXETH','4h','0.001322970000000','0.001330110000000','1.315117169629802','1.322214788314396','994.0642415397189','994.064241539718864','test','test','0.0'),('2019-06-11 19:59:59','2019-06-11 23:59:59','ZRXETH','4h','0.001333490000000','0.001326800000000','1.316694418226378','1.310088680157150','987.404793606535','987.404793606535009','test','test','0.50'),('2019-06-15 15:59:59','2019-06-15 19:59:59','ZRXETH','4h','0.001333020000000','0.001326480000000','1.315226476433217','1.308773774181283','986.6517204792251','986.651720479225105','test','test','0.49'),('2019-06-15 23:59:59','2019-06-16 03:59:59','ZRXETH','4h','0.001333000000000','0.001312990000000','1.313792542599453','1.294070870598391','985.5908046507528','985.590804650752830','test','test','1.50'),('2019-06-17 03:59:59','2019-06-17 07:59:59','ZRXETH','4h','0.001307330000000','0.001310000000000','1.309409948821440','1.312084196764464','1001.5909898965369','1001.590989896536939','test','test','0.0'),('2019-07-15 07:59:59','2019-07-15 11:59:59','ZRXETH','4h','0.000986640000000','0.000971290000000','1.310004226142112','1.289623373073838','1327.7428708972996','1327.742870897299554','test','test','1.55'),('2019-07-15 19:59:59','2019-07-18 15:59:59','ZRXETH','4h','0.001042710000000','0.001049060000000','1.305475147682495','1.313425361248860','1252.0021364353418','1252.002136435341754','test','test','0.0'),('2019-07-18 19:59:59','2019-07-23 19:59:59','ZRXETH','4h','0.001058220000000','0.001065210000000','1.307241861808354','1.315876758723967','1235.3214471549907','1235.321447154990665','test','test','0.65'),('2019-07-23 23:59:59','2019-07-24 03:59:59','ZRXETH','4h','0.001052500000000','0.001064200000000','1.309160727789601','1.323713868421561','1243.8581736718302','1243.858173671830173','test','test','0.0'),('2019-07-24 07:59:59','2019-07-24 15:59:59','ZRXETH','4h','0.001071370000000','0.001057490000000','1.312394759041148','1.295392192929075','1224.9687400628616','1224.968740062861571','test','test','1.29'),('2019-07-24 19:59:59','2019-07-24 23:59:59','ZRXETH','4h','0.001051750000000','0.001046920000000','1.308616411016243','1.302606791557999','1244.2276311064825','1244.227631106482477','test','test','0.45'),('2019-07-25 07:59:59','2019-07-25 11:59:59','ZRXETH','4h','0.001059530000000','0.001058720000000','1.307280940025522','1.306281536930357','1233.8309816857684','1233.830981685768393','test','test','0.07'),('2019-07-25 15:59:59','2019-07-25 19:59:59','ZRXETH','4h','0.001054600000000','0.001058250000000','1.307058850448819','1.311582617568237','1239.3882518953337','1239.388251895333724','test','test','0.0'),('2019-07-25 23:59:59','2019-07-27 03:59:59','ZRXETH','4h','0.001068770000000','0.001068860000000','1.308064132030912','1.308174282738625','1223.8967523703993','1223.896752370399327','test','test','0.42'),('2019-07-27 07:59:59','2019-07-27 11:59:59','ZRXETH','4h','0.001065920000000','0.001075860000000','1.308088609965959','1.320286899502755','1227.192106317509','1227.192106317508888','test','test','0.0'),('2019-07-27 15:59:59','2019-07-29 11:59:59','ZRXETH','4h','0.001073840000000','0.001079670000000','1.310799340974136','1.317915820298690','1220.6654072991655','1220.665407299165508','test','test','0.93'),('2019-07-29 15:59:59','2019-07-29 19:59:59','ZRXETH','4h','0.001074380000000','0.001054070000000','1.312380780824037','1.287571631678915','1221.5238377706555','1221.523837770655518','test','test','1.89'),('2019-07-30 11:59:59','2019-07-30 15:59:59','ZRXETH','4h','0.001068910000000','0.001055410000000','1.306867636569565','1.290362305817968','1222.6170927108599','1222.617092710859879','test','test','1.26'),('2019-07-30 23:59:59','2019-07-31 03:59:59','ZRXETH','4h','0.001066440000000','0.001039800000000','1.303199785291432','1.270645452858136','1222.0094757243091','1222.009475724309141','test','test','2.49'),('2019-08-15 23:59:59','2019-08-17 23:59:59','ZRXETH','4h','0.000923980000000','0.000925320000000','1.295965489195144','1.297844960347681','1402.5904123413325','1402.590412341332467','test','test','0.0'),('2019-08-18 03:59:59','2019-08-18 07:59:59','ZRXETH','4h','0.000917630000000','0.000916310000000','1.296383149451264','1.294518317484921','1412.7514896540692','1412.751489654069246','test','test','0.14'),('2019-08-21 23:59:59','2019-08-22 15:59:59','ZRXETH','4h','0.000919420000000','0.000904640000000','1.295968742347632','1.275135588824870','1409.5503060055598','1409.550306005559833','test','test','1.60'),('2019-08-22 19:59:59','2019-08-23 03:59:59','ZRXETH','4h','0.000925950000000','0.000908900000000','1.291339152675907','1.267561051749157','1394.6100250293289','1394.610025029328881','test','test','1.84'),('2019-08-23 11:59:59','2019-08-23 15:59:59','ZRXETH','4h','0.000917310000000','0.000922330000000','1.286055130247740','1.293093096424762','1401.9852942274044','1401.985294227404438','test','test','0.0'),('2019-08-23 19:59:59','2019-08-26 03:59:59','ZRXETH','4h','0.000977140000000','0.000936070000000','1.287619122731523','1.233499429166032','1317.7427213413873','1317.742721341387323','test','test','4.20'),('2019-08-26 07:59:59','2019-08-26 23:59:59','ZRXETH','4h','0.000941680000000','0.000943000000000','1.275592524161414','1.277380586063433','1354.5923500142446','1354.592350014244630','test','test','0.54'),('2019-08-30 11:59:59','2019-09-01 15:59:59','ZRXETH','4h','0.000938200000000','0.000926520000000','1.275989871250751','1.260104599777495','1360.0403658609584','1360.040365860958445','test','test','1.24'),('2019-09-01 23:59:59','2019-09-02 19:59:59','ZRXETH','4h','0.000940250000000','0.000940460000000','1.272459810923361','1.272744008275442','1353.3207241939497','1353.320724193949673','test','test','0.0'),('2019-09-02 23:59:59','2019-09-03 15:59:59','ZRXETH','4h','0.000971970000000','0.000931190000000','1.272522965890490','1.219132957403588','1309.2204140976476','1309.220414097647563','test','test','4.19'),('2019-09-03 19:59:59','2019-09-04 15:59:59','ZRXETH','4h','0.000938430000000','0.000939960000000','1.260658519560068','1.262713875351045','1343.369798024432','1343.369798024431930','test','test','0.0'),('2019-09-04 19:59:59','2019-09-04 23:59:59','ZRXETH','4h','0.000943300000000','0.000939980000000','1.261115265291396','1.256676695715686','1336.9185469006636','1336.918546900663614','test','test','0.35'),('2019-09-05 03:59:59','2019-09-05 19:59:59','ZRXETH','4h','0.000939890000000','0.000935070000000','1.260128916496794','1.253666648170166','1340.7195698398682','1340.719569839868200','test','test','0.51'),('2019-09-18 15:59:59','2019-09-30 03:59:59','ZRXETH','4h','0.000897620000000','0.001142630000000','1.258692856868654','1.602259551975034','1402.2558063196611','1402.255806319661133','test','test','0.0'),('2019-09-30 07:59:59','2019-09-30 11:59:59','ZRXETH','4h','0.001146000000000','0.001153990000000','1.335041011336738','1.344349019784016','1164.9572524753387','1164.957252475338692','test','test','0.0'),('2019-10-01 15:59:59','2019-10-02 15:59:59','ZRXETH','4h','0.001167000000000','0.001164530000000','1.337109457658356','1.334279414504615','1145.7664590045893','1145.766459004589251','test','test','0.21'),('2019-10-02 19:59:59','2019-10-02 23:59:59','ZRXETH','4h','0.001151150000000','0.001151510000000','1.336480559179747','1.336898517744056','1160.996011970418','1160.996011970418067','test','test','0.0'),('2019-10-03 03:59:59','2019-10-25 15:59:59','ZRXETH','4h','0.001177380000000','0.001720930000000','1.336573438860704','1.953616783144398','1135.2099057744351','1135.209905774435128','test','test','0.28'),('2019-11-01 19:59:59','2019-11-02 03:59:59','ZRXETH','4h','0.001685000000000','0.001609900000000','1.473694182034859','1.408012025909744','874.5959537298863','874.595953729886332','test','test','4.45'),('2019-11-02 07:59:59','2019-11-02 11:59:59','ZRXETH','4h','0.001615730000000','0.001656880000000','1.459098147340389','1.496258990280148','903.0581516344865','903.058151634486535','test','test','0.0'),('2019-11-02 15:59:59','2019-11-02 19:59:59','ZRXETH','4h','0.001631020000000','0.001607720000000','1.467356112438113','1.446394139304854','899.6554992815005','899.655499281500511','test','test','1.42'),('2019-11-03 03:59:59','2019-11-03 23:59:59','ZRXETH','4h','0.001635000000000','0.001621280000000','1.462697896186278','1.450423758488617','894.6164502668364','894.616450266836409','test','test','0.83'),('2019-11-04 03:59:59','2019-11-04 11:59:59','ZRXETH','4h','0.001642010000000','0.001605350000000','1.459970310031242','1.427374581889668','889.1360649638199','889.136064963819877','test','test','2.23'),('2019-11-07 11:59:59','2019-11-07 15:59:59','ZRXETH','4h','0.001654730000000','0.001609020000000','1.452726814888670','1.412596918948812','877.9237790386767','877.923779038676685','test','test','2.76'),('2019-11-07 19:59:59','2019-11-08 15:59:59','ZRXETH','4h','0.001637950000000','0.001591270000000','1.443809060235368','1.402661890338981','881.4732197169437','881.473219716943731','test','test','2.84'),('2019-11-09 07:59:59','2019-11-10 23:59:59','ZRXETH','4h','0.001637950000000','0.001627760000000','1.434665244702837','1.425739918017943','875.8907443467978','875.890744346797760','test','test','0.62'),('2019-11-11 11:59:59','2019-11-11 15:59:59','ZRXETH','4h','0.001623000000000','0.001671420000000','1.432681838772861','1.475423954997989','882.7368076234511','882.736807623451114','test','test','0.0'),('2019-11-11 19:59:59','2019-11-12 07:59:59','ZRXETH','4h','0.001640000000000','0.001635960000000','1.442180086822890','1.438627399291936','879.3781017212741','879.378101721274106','test','test','0.42'),('2019-11-12 11:59:59','2019-11-12 15:59:59','ZRXETH','4h','0.001620430000000','0.001620000000000','1.441390600704900','1.441008110897686','889.5111795664728','889.511179566472833','test','test','0.02'),('2019-11-12 19:59:59','2019-11-12 23:59:59','ZRXETH','4h','0.001624080000000','0.001611000000000','1.441305602969963','1.429697629663939','887.4597328764368','887.459732876436760','test','test','0.80'),('2019-11-21 19:59:59','2019-11-22 15:59:59','ZRXETH','4h','0.001584830000000','0.001596100000000','1.438726053346403','1.448957082933939','907.8109660634912','907.810966063491151','test','test','1.30'),('2019-11-22 19:59:59','2019-11-23 03:59:59','ZRXETH','4h','0.001612430000000','0.001549980000000','1.440999615476966','1.385189176582542','893.6819678850964','893.681967885096356','test','test','3.87'),('2019-11-23 07:59:59','2019-12-01 07:59:59','ZRXETH','4h','0.001575750000000','0.001696990000000','1.428597295722650','1.538515199028006','906.6141810075518','906.614181007551792','test','test','0.0'),('2019-12-01 11:59:59','2019-12-02 07:59:59','ZRXETH','4h','0.001702720000000','0.001675470000000','1.453023496457173','1.429769590777755','853.3543368593621','853.354336859362093','test','test','1.60'),('2019-12-02 11:59:59','2019-12-02 23:59:59','ZRXETH','4h','0.001718250000000','0.001667790000000','1.447855961861747','1.405336647538719','842.6340531713936','842.634053171393589','test','test','2.93'),('2019-12-03 11:59:59','2019-12-03 15:59:59','ZRXETH','4h','0.001687590000000','0.001662380000000','1.438407225345518','1.416919632890620','852.3440085242969','852.344008524296896','test','test','1.49'),('2019-12-18 23:59:59','2019-12-19 03:59:59','ZRXETH','4h','0.001518170000000','0.001487540000000','1.433632204799985','1.404707806061357','944.3159888549935','944.315988854993520','test','test','2.01'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ZRXETH','4h','0.001542410000000','0.001530360000000','1.427204560635846','1.416054597295579','925.308161018047','925.308161018047031','test','test','0.78'),('2019-12-20 23:59:59','2019-12-21 03:59:59','ZRXETH','4h','0.001502730000000','0.001508820000000','1.424726791004675','1.430500673310357','948.0923326244072','948.092332624407163','test','test','0.0'),('2019-12-27 19:59:59','2019-12-27 23:59:59','ZRXETH','4h','0.001477210000000','0.001470110000000','1.426009875961494','1.419155962083761','965.3399827793569','965.339982779356887','test','test','0.48'),('2019-12-29 11:59:59','2019-12-29 15:59:59','ZRXETH','4h','0.001482580000000','0.001493320000000','1.424486783988664','1.434805949268135','960.8161340289657','960.816134028965735','test','test','0.0'),('2019-12-29 19:59:59','2019-12-29 23:59:59','ZRXETH','4h','0.001470100000000','0.001467000000000','1.426779931828547','1.423771280860131','970.5325704568033','970.532570456803342','test','test','0.21');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 19:28:14
