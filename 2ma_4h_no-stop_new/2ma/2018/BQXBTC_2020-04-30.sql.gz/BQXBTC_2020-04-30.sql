-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 07:59:59','2018-03-21 11:59:59','BQXBTC','4h','0.000336980000000','0.000332860000000','0.033333333333333','0.032925791837300','98.91783884305696','98.917838843056956','test','test','1.22'),('2018-03-21 15:59:59','2018-03-21 19:59:59','BQXBTC','4h','0.000336710000000','0.000322150000000','0.033242768556437','0.031805286122943','98.72818911359066','98.728189113590659','test','test','4.32'),('2018-03-21 23:59:59','2018-03-22 03:59:59','BQXBTC','4h','0.000327720000000','0.000323490000000','0.032923328015661','0.032498374770494','100.46176008684448','100.461760086844478','test','test','1.29'),('2018-03-22 07:59:59','2018-03-22 11:59:59','BQXBTC','4h','0.000322320000000','0.000312220000000','0.032828893961179','0.031800190098533','101.85186758866689','101.851867588666892','test','test','3.13'),('2018-03-24 07:59:59','2018-03-24 11:59:59','BQXBTC','4h','0.000324800000000','0.000318320000000','0.032600293102813','0.031949893166525','100.37036053821839','100.370360538218392','test','test','1.99'),('2018-03-24 15:59:59','2018-03-24 19:59:59','BQXBTC','4h','0.000315630000000','0.000331340000000','0.032455759783638','0.034071195534995','102.8285010412135','102.828501041213499','test','test','0.0'),('2018-03-24 23:59:59','2018-03-25 03:59:59','BQXBTC','4h','0.000318220000000','0.000328270000000','0.032814745506162','0.033851098319740','103.11968294312739','103.119682943127387','test','test','0.0'),('2018-03-25 07:59:59','2018-03-28 03:59:59','BQXBTC','4h','0.000331000000000','0.000335850000000','0.033045046131402','0.033529240916107','99.83397622779925','99.833976227799255','test','test','0.0'),('2018-03-28 07:59:59','2018-03-28 11:59:59','BQXBTC','4h','0.000344350000000','0.000350010000000','0.033152644972447','0.033697567204316','96.27601269768292','96.276012697682916','test','test','0.0'),('2018-03-28 15:59:59','2018-03-28 23:59:59','BQXBTC','4h','0.000336750000000','0.000333230000000','0.033273738801751','0.032925933128159','98.80842999777677','98.808429997776770','test','test','1.04'),('2018-04-11 15:59:59','2018-04-12 11:59:59','BQXBTC','4h','0.000295720000000','0.000296240000000','0.033196448652064','0.033254821955524','112.2563528069262','112.256352806926202','test','test','0.0'),('2018-04-12 15:59:59','2018-04-12 19:59:59','BQXBTC','4h','0.000294480000000','0.000289980000000','0.033209420497278','0.032701941577699','112.77309323987214','112.773093239872139','test','test','1.52'),('2018-04-12 23:59:59','2018-04-13 03:59:59','BQXBTC','4h','0.000294030000000','0.000292860000000','0.033096647404038','0.032964949694747','112.56214469284691','112.562144692846914','test','test','0.39'),('2018-04-13 07:59:59','2018-04-21 11:59:59','BQXBTC','4h','0.000299780000000','0.000325790000000','0.033067381246418','0.035936427167491','110.30549485094922','110.305494850949216','test','test','0.0'),('2018-04-21 15:59:59','2018-04-25 15:59:59','BQXBTC','4h','0.000334000000000','0.000356310000000','0.033704947006656','0.035956316371083','100.91301498998803','100.913014989988028','test','test','1.38'),('2018-04-25 19:59:59','2018-05-03 19:59:59','BQXBTC','4h','0.000363480000000','0.000375610000000','0.034205251309862','0.035346743822211','94.10490621179156','94.104906211791558','test','test','2.40'),('2018-05-08 07:59:59','2018-05-11 15:59:59','BQXBTC','4h','0.000381490000000','0.000398170000000','0.034458916312606','0.035965573693125','90.3271810862833','90.327181086283304','test','test','0.0'),('2018-05-11 19:59:59','2018-05-12 07:59:59','BQXBTC','4h','0.000413700000000','0.000399170000000','0.034793729063833','0.033571701306285','84.10376858552735','84.103768585527348','test','test','3.51'),('2018-05-12 11:59:59','2018-05-12 15:59:59','BQXBTC','4h','0.000397680000000','0.000396200000000','0.034522167339933','0.034393690153092','86.80891002799515','86.808910027995154','test','test','0.37'),('2018-05-13 11:59:59','2018-05-13 15:59:59','BQXBTC','4h','0.000401210000000','0.000407270000000','0.034493616853968','0.035014619117459','85.9739708730302','85.973970873030197','test','test','0.0'),('2018-05-13 19:59:59','2018-05-14 07:59:59','BQXBTC','4h','0.000406220000000','0.000404090000000','0.034609395134744','0.034427922012699','85.19864884728527','85.198648847285270','test','test','0.66'),('2018-05-14 11:59:59','2018-05-14 15:59:59','BQXBTC','4h','0.000404000000000','0.000404020000000','0.034569067774290','0.034570779114279','85.56699944131132','85.566999441311324','test','test','0.0'),('2018-05-14 19:59:59','2018-05-14 23:59:59','BQXBTC','4h','0.000403540000000','0.000400470000000','0.034569448072065','0.034306455046389','85.6654806761786','85.665480676178603','test','test','0.76'),('2018-05-31 15:59:59','2018-06-01 07:59:59','BQXBTC','4h','0.000342300000000','0.000317950000000','0.034511005177470','0.032056015472324','100.82093244951926','100.820932449519262','test','test','7.36'),('2018-06-01 11:59:59','2018-06-01 15:59:59','BQXBTC','4h','0.000314150000000','0.000305790000000','0.033965451909660','0.033061580580789','108.118580008468','108.118580008468001','test','test','2.66'),('2018-06-02 11:59:59','2018-06-02 19:59:59','BQXBTC','4h','0.000318870000000','0.000320380000000','0.033764591614356','0.033924482897129','105.88826673677535','105.888266736775350','test','test','0.78'),('2018-06-02 23:59:59','2018-06-03 19:59:59','BQXBTC','4h','0.000317200000000','0.000316480000000','0.033800123010527','0.033723401419835','106.55776485033836','106.557764850338359','test','test','0.22'),('2018-06-03 23:59:59','2018-06-04 03:59:59','BQXBTC','4h','0.000321970000000','0.000313710000000','0.033783073768151','0.032916383737015','104.926153890584','104.926153890584004','test','test','2.56'),('2018-06-09 03:59:59','2018-06-10 03:59:59','BQXBTC','4h','0.000319120000000','0.000309290000000','0.033590475983454','0.032555773116453','105.2597016277715','105.259701627771506','test','test','3.08'),('2018-06-28 15:59:59','2018-06-28 23:59:59','BQXBTC','4h','0.000242090000000','0.000217090000000','0.033360542013010','0.029915486247281','137.80223062914524','137.802230629145242','test','test','10.3'),('2018-06-29 03:59:59','2018-06-30 15:59:59','BQXBTC','4h','0.000226650000000','0.000222460000000','0.032594974065070','0.031992402075956','143.81193057608647','143.811930576086468','test','test','1.84'),('2018-06-30 19:59:59','2018-07-01 03:59:59','BQXBTC','4h','0.000234600000000','0.000222600000000','0.032461069178600','0.030800656432892','138.3677288090376','138.367728809037601','test','test','5.11'),('2018-07-01 07:59:59','2018-07-01 11:59:59','BQXBTC','4h','0.000230030000000','0.000226670000000','0.032092088568443','0.031623326156627','139.51262256419983','139.512622564199830','test','test','1.46'),('2018-07-01 19:59:59','2018-07-01 23:59:59','BQXBTC','4h','0.000230910000000','0.000228320000000','0.031987919143595','0.031629126927658','138.5298131029184','138.529813102918411','test','test','1.12'),('2018-07-02 03:59:59','2018-07-07 23:59:59','BQXBTC','4h','0.000234020000000','0.000254330000000','0.031908187540053','0.034677417900443','136.34812212654188','136.348122126541881','test','test','0.89'),('2018-07-08 03:59:59','2018-07-08 07:59:59','BQXBTC','4h','0.000251550000000','0.000246840000000','0.032523572064584','0.031914603571544','129.29267368151238','129.292673681512383','test','test','1.87'),('2018-08-17 11:59:59','2018-08-17 15:59:59','BQXBTC','4h','0.000080770000000','0.000076000000000','0.032388245732798','0.030475506694226','400.99350913455226','400.993509134552255','test','test','5.90'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BQXBTC','4h','0.000081640000000','0.000078020000000','0.031963192613115','0.030545912391906','391.5138732620665','391.513873262066511','test','test','4.43'),('2018-08-19 19:59:59','2018-08-19 23:59:59','BQXBTC','4h','0.000076880000000','0.000075490000000','0.031648241452846','0.031076037295465','411.6576671806249','411.657667180624912','test','test','1.80'),('2018-08-26 15:59:59','2018-08-29 19:59:59','BQXBTC','4h','0.000073090000000','0.000073580000000','0.031521084973428','0.031732404328155','431.263989238315','431.263989238314991','test','test','1.34'),('2018-09-01 15:59:59','2018-09-01 23:59:59','BQXBTC','4h','0.000074880000000','0.000073300000000','0.031568044830034','0.030901945593503','421.58179527289593','421.581795272895931','test','test','2.11'),('2018-09-02 03:59:59','2018-09-02 07:59:59','BQXBTC','4h','0.000073710000000','0.000072350000000','0.031420022777472','0.030840301830825','426.26540194643877','426.265401946438772','test','test','1.84'),('2018-09-26 11:59:59','2018-09-26 15:59:59','BQXBTC','4h','0.000049940000000','0.000050400000000','0.031291195900439','0.031579420772570','626.5758089795622','626.575808979562225','test','test','0.0'),('2018-09-26 19:59:59','2018-09-28 11:59:59','BQXBTC','4h','0.000052020000000','0.000050540000000','0.031355245872024','0.030463170441601','602.7536692046136','602.753669204613630','test','test','2.84'),('2018-09-28 15:59:59','2018-09-29 07:59:59','BQXBTC','4h','0.000051690000000','0.000050600000000','0.031157006887486','0.030499991265366','602.7666257977472','602.766625797747224','test','test','2.10'),('2018-09-29 11:59:59','2018-10-01 23:59:59','BQXBTC','4h','0.000051230000000','0.000051390000000','0.031011003415903','0.031107856051986','605.328975520268','605.328975520268045','test','test','0.37'),('2018-10-02 03:59:59','2018-10-02 19:59:59','BQXBTC','4h','0.000051730000000','0.000050590000000','0.031032526223922','0.030348646852276','599.8941856547801','599.894185654780131','test','test','2.20'),('2018-10-05 03:59:59','2018-10-05 23:59:59','BQXBTC','4h','0.000051080000000','0.000050710000000','0.030880553030223','0.030656868523152','604.5527218132863','604.552721813286325','test','test','0.72'),('2018-10-06 03:59:59','2018-10-09 11:59:59','BQXBTC','4h','0.000051330000000','0.000050770000000','0.030830845361985','0.030494487025677','600.6398862650432','600.639886265043174','test','test','1.09'),('2018-10-09 15:59:59','2018-10-09 19:59:59','BQXBTC','4h','0.000051440000000','0.000050950000000','0.030756099065027','0.030463126892751','597.9023923994428','597.902392399442761','test','test','0.95'),('2018-10-09 23:59:59','2018-10-10 03:59:59','BQXBTC','4h','0.000051530000000','0.000050750000000','0.030690994137855','0.030226430283255','595.594685384337','595.594685384337026','test','test','1.51'),('2018-10-10 15:59:59','2018-10-10 23:59:59','BQXBTC','4h','0.000051510000000','0.000052450000000','0.030587757725722','0.031145950159466','593.8217380260446','593.821738026044613','test','test','0.0'),('2018-10-13 15:59:59','2018-10-15 07:59:59','BQXBTC','4h','0.000053100000000','0.000054200000000','0.030711800488776','0.031348014811519','578.3766570390918','578.376657039091810','test','test','0.0'),('2018-10-15 11:59:59','2018-10-15 19:59:59','BQXBTC','4h','0.000052950000000','0.000053260000000','0.030853181449385','0.031033813862025','582.6852020658231','582.685202065823091','test','test','0.0'),('2018-10-15 23:59:59','2018-10-26 15:59:59','BQXBTC','4h','0.000054710000000','0.000060550000000','0.030893321985528','0.034191018940298','564.674136090798','564.674136090798015','test','test','1.44'),('2018-11-01 07:59:59','2018-11-01 11:59:59','BQXBTC','4h','0.000060980000000','0.000060240000000','0.031626143531032','0.031242356285821','518.6314124472286','518.631412447228627','test','test','1.21'),('2018-11-01 15:59:59','2018-11-01 19:59:59','BQXBTC','4h','0.000060330000000','0.000061560000000','0.031540857476541','0.032183908275416','522.8055275408697','522.805527540869662','test','test','0.0'),('2018-11-01 23:59:59','2018-11-02 15:59:59','BQXBTC','4h','0.000061660000000','0.000061530000000','0.031683757654068','0.031616957646040','513.8462156027966','513.846215602796633','test','test','0.56'),('2018-11-02 19:59:59','2018-11-02 23:59:59','BQXBTC','4h','0.000060970000000','0.000060360000000','0.031668913207840','0.031352068250373','519.4179630611776','519.417963061177602','test','test','1.00'),('2018-11-12 03:59:59','2018-11-12 07:59:59','BQXBTC','4h','0.000055370000000','0.000055060000000','0.031598503217292','0.031421592688172','570.6791261927357','570.679126192735680','test','test','0.55'),('2018-12-15 15:59:59','2018-12-15 19:59:59','BQXBTC','4h','0.000028200000000','0.000027230000000','0.031559189766376','0.030473643168029','1119.1202044814263','1119.120204481426299','test','test','3.43'),('2018-12-15 23:59:59','2018-12-16 15:59:59','BQXBTC','4h','0.000028040000000','0.000027310000000','0.031317957188966','0.030502618075273','1116.9028954695355','1116.902895469535451','test','test','2.60'),('2018-12-16 19:59:59','2018-12-16 23:59:59','BQXBTC','4h','0.000027440000000','0.000026860000000','0.031136770719256','0.030478631979563','1134.7219649874717','1134.721964987471665','test','test','2.11'),('2018-12-18 03:59:59','2018-12-18 07:59:59','BQXBTC','4h','0.000027560000000','0.000027800000000','0.030990517665991','0.031260391549875','1124.474516182551','1124.474516182551042','test','test','0.0'),('2018-12-18 11:59:59','2018-12-18 15:59:59','BQXBTC','4h','0.000027360000000','0.000027040000000','0.031050489640188','0.030687326018665','1134.886317258317','1134.886317258316922','test','test','1.16'),('2018-12-19 11:59:59','2018-12-19 15:59:59','BQXBTC','4h','0.000027700000000','0.000026990000000','0.030969786613182','0.030175976198187','1118.042838021027','1118.042838021026910','test','test','2.56'),('2018-12-20 23:59:59','2018-12-21 03:59:59','BQXBTC','4h','0.000027500000000','0.000027980000000','0.030793384298739','0.031330868824681','1119.7594290450586','1119.759429045058596','test','test','0.0'),('2018-12-21 07:59:59','2018-12-25 11:59:59','BQXBTC','4h','0.000028060000000','0.000028720000000','0.030912825304504','0.031639926683726','1101.6687563971489','1101.668756397148854','test','test','0.0'),('2018-12-25 23:59:59','2018-12-26 11:59:59','BQXBTC','4h','0.000029240000000','0.000028870000000','0.031074403388776','0.030681191033993','1062.7360940073718','1062.736094007371776','test','test','1.26'),('2018-12-26 19:59:59','2018-12-26 23:59:59','BQXBTC','4h','0.000029050000000','0.000029250000000','0.030987022865490','0.031200358651139','1066.6789282440773','1066.678928244077269','test','test','0.0'),('2018-12-27 03:59:59','2018-12-27 07:59:59','BQXBTC','4h','0.000028660000000','0.000028580000000','0.031034430817857','0.030947802957933','1082.848249052927','1082.848249052927031','test','test','0.27'),('2018-12-28 03:59:59','2019-01-01 23:59:59','BQXBTC','4h','0.000028880000000','0.000030720000000','0.031015180182318','0.032991216592826','1073.9328317977224','1073.932831797722429','test','test','0.0'),('2019-01-02 03:59:59','2019-01-02 15:59:59','BQXBTC','4h','0.000030890000000','0.000030700000000','0.031454299384653','0.031260828459335','1018.2680279913674','1018.268027991367376','test','test','0.61'),('2019-01-02 19:59:59','2019-01-03 03:59:59','BQXBTC','4h','0.000030920000000','0.000030870000000','0.031411305845694','0.031360511366642','1015.8895810379615','1015.889581037961534','test','test','0.51'),('2019-01-03 07:59:59','2019-01-03 11:59:59','BQXBTC','4h','0.000030490000000','0.000030330000000','0.031400018183682','0.031235242752085','1029.8464474805583','1029.846447480558254','test','test','0.52'),('2019-01-03 15:59:59','2019-01-03 19:59:59','BQXBTC','4h','0.000030620000000','0.000030100000000','0.031363401421105','0.030830776707226','1024.2782959211333','1024.278295921133349','test','test','1.69'),('2019-01-09 07:59:59','2019-01-09 19:59:59','BQXBTC','4h','0.000032010000000','0.000030140000000','0.031245040373576','0.029419728736632','976.1024796493735','976.102479649373549','test','test','5.84'),('2019-01-10 03:59:59','2019-01-10 07:59:59','BQXBTC','4h','0.000030400000000','0.000029780000000','0.030839415565367','0.030210453800547','1014.4544593870613','1014.454459387061320','test','test','2.03'),('2019-01-15 03:59:59','2019-01-15 07:59:59','BQXBTC','4h','0.000029610000000','0.000029100000000','0.030699646284296','0.030170878313847','1036.7999420565875','1036.799942056587497','test','test','1.72'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BQXBTC','4h','0.000029430000000','0.000029280000000','0.030582142290862','0.030426270005995','1039.1485657785402','1039.148565778540160','test','test','0.50'),('2019-01-15 23:59:59','2019-01-24 07:59:59','BQXBTC','4h','0.000029500000000','0.000047060000000','0.030547504005336','0.048731035203089','1035.508610350388','1035.508610350387926','test','test','0.0'),('2019-01-24 11:59:59','2019-01-24 15:59:59','BQXBTC','4h','0.000047200000000','0.000047440000000','0.034588288715948','0.034764161370436','732.8027270328013','732.802727032801272','test','test','0.0'),('2019-01-24 19:59:59','2019-01-24 23:59:59','BQXBTC','4h','0.000047150000000','0.000047850000000','0.034627371528057','0.035141457637699','734.4087280605868','734.408728060586782','test','test','0.0'),('2019-01-25 03:59:59','2019-01-25 11:59:59','BQXBTC','4h','0.000050120000000','0.000046940000000','0.034741612885755','0.032537336569380','693.1686529480226','693.168652948022554','test','test','6.34'),('2019-01-25 15:59:59','2019-01-27 03:59:59','BQXBTC','4h','0.000048100000000','0.000047150000000','0.034251773704338','0.033575283371300','712.095087408279','712.095087408279028','test','test','1.97'),('2019-01-29 11:59:59','2019-01-29 15:59:59','BQXBTC','4h','0.000047280000000','0.000045550000000','0.034101442519219','0.032853652850051','721.265704721207','721.265704721207044','test','test','3.65'),('2019-02-12 23:59:59','2019-02-13 03:59:59','BQXBTC','4h','0.000041550000000','0.000040140000000','0.033824155926070','0.032676332584174','814.0591077273218','814.059107727321816','test','test','3.39'),('2019-02-13 19:59:59','2019-02-13 23:59:59','BQXBTC','4h','0.000040520000000','0.000040170000000','0.033569084072316','0.033279124066756','828.4571587442141','828.457158744214098','test','test','0.86'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BQXBTC','4h','0.000040480000000','0.000039580000000','0.033504648515524','0.032759732911177','827.6840048301494','827.684004830149433','test','test','2.22'),('2019-02-16 19:59:59','2019-02-16 23:59:59','BQXBTC','4h','0.000040290000000','0.000040170000000','0.033339111714558','0.033239814285773','827.4785732082016','827.478573208201624','test','test','0.29'),('2019-02-17 03:59:59','2019-02-17 15:59:59','BQXBTC','4h','0.000040660000000','0.000040320000000','0.033317045619273','0.033038447598846','819.4059424316991','819.405942431699145','test','test','0.83'),('2019-02-17 19:59:59','2019-02-17 23:59:59','BQXBTC','4h','0.000040050000000','0.000040540000000','0.033255134948067','0.033662001767656','830.3404481414954','830.340448141495358','test','test','0.0'),('2019-02-18 03:59:59','2019-02-18 15:59:59','BQXBTC','4h','0.000041920000000','0.000040050000000','0.033345549796864','0.031858045547815','795.4568176732931','795.456817673293131','test','test','4.46'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BQXBTC','4h','0.000040340000000','0.000040580000000','0.033014993297076','0.033211413683573','818.4182770717844','818.418277071784360','test','test','0.0'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BQXBTC','4h','0.000040120000000','0.000038010000000','0.033058642271853','0.031320014774505','823.9940745726043','823.994074572604291','test','test','5.25'),('2019-03-06 11:59:59','2019-03-06 15:59:59','BQXBTC','4h','0.000037980000000','0.000037480000000','0.032672280605776','0.032242155795273','860.249621005149','860.249621005149038','test','test','1.31'),('2019-03-07 23:59:59','2019-03-08 07:59:59','BQXBTC','4h','0.000037800000000','0.000038190000000','0.032576697314553','0.032912806096370','861.8173892738803','861.817389273880281','test','test','0.0'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BQXBTC','4h','0.000039030000000','0.000037500000000','0.032651388154956','0.031371433661564','836.5715643083897','836.571564308389725','test','test','3.92'),('2019-03-09 03:59:59','2019-03-09 15:59:59','BQXBTC','4h','0.000038660000000','0.000039170000000','0.032366953823092','0.032793936400686','837.2207403800196','837.220740380019606','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 18:04:45
