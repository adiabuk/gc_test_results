-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-22 15:59:59','2018-04-03 19:59:59','MDAETH','4h','0.001600200000000','0.001797100000000','1.297777777777778','1.457465594578456','811.0097348942493','811.009734894249277','test','test','0.0'),('2018-04-04 19:59:59','2018-04-04 23:59:59','MDAETH','4h','0.001820000000000','0.001778400000000','1.333263959289040','1.302789354505291','732.5626149939778','732.562614993977832','test','test','2.28'),('2018-04-06 07:59:59','2018-04-06 11:59:59','MDAETH','4h','0.001807600000000','0.001828300000000','1.326491824892651','1.341682343135226','733.8414609939427','733.841460993942746','test','test','0.0'),('2018-04-06 15:59:59','2018-04-07 07:59:59','MDAETH','4h','0.001832600000000','0.001853000000000','1.329867495613223','1.344671215415968','725.6725393502254','725.672539350225406','test','test','0.51'),('2018-04-07 11:59:59','2018-04-07 23:59:59','MDAETH','4h','0.001868700000000','0.001835600000000','1.333157211124944','1.309543199411862','713.4142511505027','713.414251150502650','test','test','1.77'),('2018-04-08 03:59:59','2018-04-08 07:59:59','MDAETH','4h','0.001813400000000','0.001806400000000','1.327909652966482','1.322783719597802','732.2761955257977','732.276195525797675','test','test','0.38'),('2018-04-11 15:59:59','2018-04-12 03:59:59','MDAETH','4h','0.001912800000000','0.001781200000000','1.326770556662330','1.235489186285520','693.6274344742421','693.627434474242136','test','test','6.87'),('2018-04-12 15:59:59','2018-04-12 19:59:59','MDAETH','4h','0.001803400000000','0.001799700000000','1.306485807689706','1.303805316679142','724.4570298822813','724.457029882281290','test','test','0.20'),('2018-04-13 11:59:59','2018-04-14 03:59:59','MDAETH','4h','0.001835100000000','0.001801300000000','1.305890143020692','1.281837455519139','711.6179734187192','711.617973418719203','test','test','1.84'),('2018-04-14 07:59:59','2018-04-14 19:59:59','MDAETH','4h','0.001825200000000','0.001779800000000','1.300545101353680','1.268195360173833','712.5493651948718','712.549365194871825','test','test','2.48'),('2018-04-14 23:59:59','2018-04-15 03:59:59','MDAETH','4h','0.001790300000000','0.001791900000000','1.293356269980381','1.294512148901215','722.424325521075','722.424325521075048','test','test','0.0'),('2018-04-15 11:59:59','2018-04-15 15:59:59','MDAETH','4h','0.001852400000000','0.001856800000000','1.293613131962788','1.296685847240609','698.3443813230341','698.344381323034099','test','test','0.0'),('2018-04-15 19:59:59','2018-04-16 11:59:59','MDAETH','4h','0.001865800000000','0.001812700000000','1.294295957580082','1.257460758015551','693.6949070533187','693.694907053318730','test','test','2.84'),('2018-04-16 15:59:59','2018-04-17 03:59:59','MDAETH','4h','0.001823000000000','0.001815500000000','1.286110357676853','1.280819174087947','705.4911451875221','705.491145187522079','test','test','0.41'),('2018-04-17 07:59:59','2018-04-17 11:59:59','MDAETH','4h','0.001819000000000','0.001825000000000','1.284934539101540','1.289172915811056','706.3961182526334','706.396118252633414','test','test','0.0'),('2018-04-17 15:59:59','2018-04-18 07:59:59','MDAETH','4h','0.001897900000000','0.001875000000000','1.285876400592544','1.270361057543084','677.5258973563116','677.525897356311589','test','test','1.77'),('2018-04-18 11:59:59','2018-04-21 03:59:59','MDAETH','4h','0.001892800000000','0.001894400000000','1.282428546581553','1.283512594380861','677.5298745675998','677.529874567599791','test','test','0.0'),('2018-04-21 07:59:59','2018-04-21 11:59:59','MDAETH','4h','0.001872100000000','0.001818800000000','1.282669446092510','1.246150947360214','685.1500700243097','685.150070024309684','test','test','2.84'),('2018-04-23 11:59:59','2018-04-24 03:59:59','MDAETH','4h','0.001935200000000','0.001858600000000','1.274554224152000','1.224104217139783','658.6162795328646','658.616279532864610','test','test','3.95'),('2018-04-24 07:59:59','2018-04-24 11:59:59','MDAETH','4h','0.001852600000000','0.001823000000000','1.263343111482618','1.243157989977768','681.9297805692639','681.929780569263926','test','test','1.59'),('2018-04-30 15:59:59','2018-05-01 03:59:59','MDAETH','4h','0.001899800000000','0.001825900000000','1.258857528925985','1.209889442081248','662.6263443130777','662.626344313077652','test','test','3.88'),('2018-05-01 07:59:59','2018-05-01 11:59:59','MDAETH','4h','0.001797500000000','0.001832800000000','1.247975731849377','1.272483961798909','694.2841345476365','694.284134547636540','test','test','0.0'),('2018-05-01 15:59:59','2018-05-01 19:59:59','MDAETH','4h','0.001899900000000','0.001804300000000','1.253422005171495','1.190351767951433','659.7305148542002','659.730514854200237','test','test','5.03'),('2018-05-01 23:59:59','2018-05-02 03:59:59','MDAETH','4h','0.001809100000000','0.001800000000000','1.239406396900370','1.233172027207267','685.0955706707036','685.095570670703637','test','test','0.50'),('2018-05-02 11:59:59','2018-05-02 15:59:59','MDAETH','4h','0.001806500000000','0.001799400000000','1.238020981413014','1.233155247137879','685.314686638812','685.314686638811963','test','test','0.39'),('2018-05-02 19:59:59','2018-05-03 03:59:59','MDAETH','4h','0.001818500000000','0.001773700000000','1.236939707129650','1.206466845496761','680.1978043055542','680.197804305554200','test','test','2.46'),('2018-06-01 15:59:59','2018-06-03 11:59:59','MDAETH','4h','0.001395800000000','0.001282300000000','1.230167960100120','1.130136391486161','881.3354062903852','881.335406290385208','test','test','8.13'),('2018-06-03 19:59:59','2018-06-04 03:59:59','MDAETH','4h','0.001295500000000','0.001281300000000','1.207938722630351','1.194698483447525','932.4112100581636','932.411210058163647','test','test','1.09'),('2018-06-06 11:59:59','2018-06-06 15:59:59','MDAETH','4h','0.001288900000000','0.001266400000000','1.204996447256390','1.183961130270380','934.9029771560165','934.902977156016505','test','test','1.74'),('2018-06-06 19:59:59','2018-06-07 11:59:59','MDAETH','4h','0.001280700000000','0.001280100000000','1.200321932370610','1.199759588996344','937.2389571098693','937.238957109869261','test','test','0.04'),('2018-06-07 15:59:59','2018-06-07 23:59:59','MDAETH','4h','0.001288900000000','0.001276900000000','1.200196967176328','1.189022815879784','931.1792747120244','931.179274712024380','test','test','0.93'),('2018-06-08 03:59:59','2018-06-08 07:59:59','MDAETH','4h','0.001294900000000','0.001270100000000','1.197713822443763','1.174775137760308','924.9469630425228','924.946963042522839','test','test','1.91'),('2018-06-29 23:59:59','2018-06-30 03:59:59','MDAETH','4h','0.000976100000000','0.001002200000000','1.192616336958551','1.224505781067370','1221.8177819470861','1221.817781947086132','test','test','0.0'),('2018-06-30 07:59:59','2018-07-10 03:59:59','MDAETH','4h','0.001123000000000','0.001123600000000','1.199702880093844','1.200343861151775','1068.3017632180265','1068.301763218026508','test','test','4.06'),('2018-07-11 15:59:59','2018-07-11 19:59:59','MDAETH','4h','0.001142600000000','0.001123200000000','1.199845320328940','1.179473362325806','1050.1009279966215','1050.100927996621522','test','test','1.69'),('2018-07-17 07:59:59','2018-07-30 19:59:59','MDAETH','4h','0.001150800000000','0.001346900000000','1.195318218550465','1.399004265350731','1038.6845833771858','1038.684583377185845','test','test','0.0'),('2018-07-30 23:59:59','2018-07-31 03:59:59','MDAETH','4h','0.001352200000000','0.001349600000000','1.240581784506080','1.238196403172168','917.4543591969235','917.454359196923519','test','test','0.19'),('2018-07-31 07:59:59','2018-07-31 15:59:59','MDAETH','4h','0.001377400000000','0.001341200000000','1.240051699765211','1.207461405347104','900.284376190802','900.284376190802050','test','test','2.62'),('2018-07-31 19:59:59','2018-08-01 03:59:59','MDAETH','4h','0.001363600000000','0.001367700000000','1.232809412116743','1.236516157929062','904.0843444681303','904.084344468130325','test','test','1.15'),('2018-08-01 07:59:59','2018-08-01 11:59:59','MDAETH','4h','0.001347200000000','0.001348300000000','1.233633133408369','1.234640405117654','915.7015538957606','915.701553895760640','test','test','0.0'),('2018-08-01 15:59:59','2018-08-02 11:59:59','MDAETH','4h','0.001365200000000','0.001338900000000','1.233856971565988','1.210087239400601','903.7920975432082','903.792097543208229','test','test','1.92'),('2018-08-10 03:59:59','2018-08-10 07:59:59','MDAETH','4h','0.001295000000000','0.001252800000000','1.228574808862569','1.188539398102723','948.7064161100916','948.706416110091595','test','test','3.25'),('2018-08-11 03:59:59','2018-08-11 07:59:59','MDAETH','4h','0.001298100000000','0.001270600000000','1.219678050915936','1.193839404894683','939.587128045556','939.587128045556028','test','test','2.11'),('2018-08-13 23:59:59','2018-08-14 23:59:59','MDAETH','4h','0.001253000000000','0.001239500000000','1.213936129577880','1.200857009267185','968.8237267181803','968.823726718180296','test','test','1.07'),('2018-08-15 03:59:59','2018-08-15 19:59:59','MDAETH','4h','0.001269400000000','0.001232900000000','1.211029658397725','1.176208024136250','954.0173770267255','954.017377026725512','test','test','2.87'),('2018-08-17 11:59:59','2018-09-07 07:59:59','MDAETH','4h','0.001309200000000','0.002634200000000','1.203291517450731','2.421104884867641','919.1044282391774','919.104428239177423','test','test','1.40'),('2018-09-07 19:59:59','2018-09-07 23:59:59','MDAETH','4h','0.002686100000000','0.002637700000000','1.473916710210044','1.447358663683792','548.7199695506662','548.719969550666178','test','test','1.80'),('2018-09-17 03:59:59','2018-09-17 07:59:59','MDAETH','4h','0.002506200000000','0.002463200000000','1.468014922093100','1.442827530165080','585.7533006516238','585.753300651623817','test','test','1.71'),('2018-10-04 11:59:59','2018-10-04 15:59:59','MDAETH','4h','0.002020800000000','0.001996500000000','1.462417723886873','1.444832237599041','723.6825632852696','723.682563285269566','test','test','1.20'),('2018-10-06 11:59:59','2018-10-06 15:59:59','MDAETH','4h','0.001996800000000','0.001964800000000','1.458509838045132','1.435136282948255','730.42359677741','730.423596777410012','test','test','1.60'),('2018-10-07 15:59:59','2018-10-20 15:59:59','MDAETH','4h','0.002136500000000','0.009737700000000','1.453315714690271','6.623895359204051','680.2320218536254','680.232021853625383','test','test','0.0'),('2018-10-20 19:59:59','2018-10-22 07:59:59','MDAETH','4h','0.009469300000000','0.008089800000000','2.602333413471110','2.223222080649951','274.8179288301258','274.817928830125823','test','test','14.5'),('2018-10-22 19:59:59','2018-10-22 23:59:59','MDAETH','4h','0.008790100000000','0.008216200000000','2.518086450621964','2.353682198791843','286.46846459334523','286.468464593345232','test','test','6.52'),('2018-11-12 07:59:59','2018-11-12 15:59:59','MDAETH','4h','0.006735100000000','0.006211300000000','2.481552172437493','2.288557706442518','368.4506796391283','368.450679639128282','test','test','7.77'),('2018-11-12 19:59:59','2018-11-12 23:59:59','MDAETH','4h','0.006067100000000','0.006653000000000','2.438664513327498','2.674166406877725','401.94895639226297','401.948956392262971','test','test','0.0'),('2018-11-13 03:59:59','2018-11-13 11:59:59','MDAETH','4h','0.006401300000000','0.005840100000000','2.490998267449771','2.272613216336277','389.139435341223','389.139435341223020','test','test','8.76'),('2018-11-22 11:59:59','2018-11-22 15:59:59','MDAETH','4h','0.005463500000000','0.005530700000000','2.442468256091217','2.472510146236606','447.0519366873281','447.051936687328123','test','test','0.0'),('2018-11-22 19:59:59','2018-11-23 03:59:59','MDAETH','4h','0.005573200000000','0.005285700000000','2.449144231679081','2.322802279729081','439.4502676521713','439.450267652171306','test','test','5.15'),('2018-11-23 07:59:59','2018-11-23 11:59:59','MDAETH','4h','0.005428100000000','0.005594000000000','2.421068242356859','2.495063788018693','446.02498892003814','446.024988920038140','test','test','0.0'),('2018-11-23 15:59:59','2018-11-23 19:59:59','MDAETH','4h','0.005427700000000','0.005465300000000','2.437511696948378','2.454397383298998','449.0874029420156','449.087402942015615','test','test','0.0'),('2018-11-23 23:59:59','2018-11-24 03:59:59','MDAETH','4h','0.005561600000000','0.005430800000000','2.441264071692960','2.383849417532748','438.9499553533084','438.949955353308383','test','test','2.35'),('2018-11-24 15:59:59','2018-11-24 19:59:59','MDAETH','4h','0.005829700000000','0.005345400000000','2.428505259657357','2.226758154788829','416.57465386852795','416.574653868527946','test','test','8.30'),('2018-11-25 19:59:59','2018-11-30 15:59:59','MDAETH','4h','0.005917300000000','0.008283200000000','2.383672569686573','3.336730709821678','402.8311171795537','402.831117179553701','test','test','0.0'),('2018-11-30 19:59:59','2018-12-02 23:59:59','MDAETH','4h','0.008183700000000','0.007777300000000','2.595463267494375','2.466573367826778','317.1503436702683','317.150343670268285','test','test','4.96'),('2018-12-03 03:59:59','2018-12-03 07:59:59','MDAETH','4h','0.007929100000000','0.007633400000000','2.566821067568242','2.471096585637137','323.72161627022507','323.721616270225070','test','test','3.72'),('2018-12-03 11:59:59','2018-12-03 15:59:59','MDAETH','4h','0.007638500000000','0.007331700000000','2.545548960472441','2.443307103946559','333.25246586010877','333.252465860108771','test','test','4.01'),('2018-12-07 15:59:59','2018-12-07 19:59:59','MDAETH','4h','0.007575600000000','0.006750000000000','2.522828547911133','2.247886992238258','333.02029514640867','333.020295146408671','test','test','10.8'),('2018-12-08 07:59:59','2018-12-08 11:59:59','MDAETH','4h','0.007274100000000','0.007071500000000','2.461730424428273','2.393165710719475','338.42405581835175','338.424055818351746','test','test','2.78'),('2018-12-11 03:59:59','2018-12-20 19:59:59','MDAETH','4h','0.007458000000000','0.009143600000000','2.446493821381873','2.999431604342624','328.03617878544816','328.036178785448158','test','test','1.98'),('2018-12-20 23:59:59','2018-12-21 03:59:59','MDAETH','4h','0.009058300000000','0.008809700000000','2.569368884262040','2.498853985812271','283.6480227263438','283.648022726343811','test','test','2.74'),('2018-12-21 07:59:59','2018-12-21 11:59:59','MDAETH','4h','0.008832300000000','0.008682700000000','2.553698906828758','2.510444787690869','289.13181241904806','289.131812419048060','test','test','1.69'),('2018-12-21 15:59:59','2018-12-21 19:59:59','MDAETH','4h','0.008879900000000','0.009000000000000','2.544086880353671','2.578495469902030','286.4994966557812','286.499496655781172','test','test','0.0'),('2018-12-21 23:59:59','2018-12-22 03:59:59','MDAETH','4h','0.009001900000000','0.008770800000000','2.551733233586640','2.486224224346160','283.4660720055366','283.466072005536603','test','test','2.56'),('2019-01-10 11:59:59','2019-01-10 15:59:59','MDAETH','4h','0.005887700000000','0.005654800000000','2.537175675977644','2.436812509556938','430.9281512267345','430.928151226734485','test','test','3.95'),('2019-01-16 15:59:59','2019-01-16 19:59:59','MDAETH','4h','0.005656900000000','0.005584200000000','2.514872750106377','2.482552707515429','444.5672983624205','444.567298362420502','test','test','1.28'),('2019-01-17 03:59:59','2019-01-20 15:59:59','MDAETH','4h','0.005848500000000','0.005899800000000','2.507690518419499','2.529686675313561','428.7749881883387','428.774988188338682','test','test','0.0'),('2019-01-20 19:59:59','2019-01-20 23:59:59','MDAETH','4h','0.005894900000000','0.005894800000000','2.512578553284846','2.512535930364130','426.2292071595526','426.229207159552573','test','test','0.00'),('2019-01-21 03:59:59','2019-01-21 07:59:59','MDAETH','4h','0.005860000000000','0.005856300000000','2.512569081524687','2.510982647121677','428.76605486769404','428.766054867694038','test','test','0.06'),('2019-01-21 11:59:59','2019-01-31 03:59:59','MDAETH','4h','0.005909700000000','0.006341800000000','2.512216540546240','2.695902475055611','425.1005195773457','425.100519577345722','test','test','0.0'),('2019-01-31 07:59:59','2019-01-31 11:59:59','MDAETH','4h','0.006281400000000','0.006223800000000','2.553035637103878','2.529624478333989','406.4437286439135','406.443728643913516','test','test','0.91'),('2019-01-31 15:59:59','2019-02-06 23:59:59','MDAETH','4h','0.006709000000000','0.006697800000000','2.547833157377236','2.543579806451223','379.76347553692597','379.763475536925966','test','test','1.31'),('2019-02-07 03:59:59','2019-02-07 11:59:59','MDAETH','4h','0.006740700000000','0.006691600000000','2.546887968282567','2.528336156268581','377.83731189380444','377.837311893804440','test','test','1.47'),('2019-02-07 15:59:59','2019-02-07 19:59:59','MDAETH','4h','0.006714700000000','0.006692400000000','2.542765343390570','2.534320637423422','378.6863662398276','378.686366239827578','test','test','0.33'),('2019-02-07 23:59:59','2019-02-08 03:59:59','MDAETH','4h','0.006711400000000','0.006647200000000','2.540888742064537','2.516583074507762','378.5929525977497','378.592952597749672','test','test','0.95'),('2019-02-08 07:59:59','2019-02-08 11:59:59','MDAETH','4h','0.006698200000000','0.006534800000000','2.535487482607476','2.473635245490331','378.5326628956251','378.532662895625094','test','test','2.43'),('2019-02-23 07:59:59','2019-02-23 19:59:59','MDAETH','4h','0.006221500000000','0.005554200000000','2.521742541025888','2.251267768442657','405.32709813162234','405.327098131622336','test','test','10.7'),('2019-02-24 23:59:59','2019-03-02 15:59:59','MDAETH','4h','0.006162200000000','0.006436200000000','2.461637036007392','2.571092838783353','399.47373275898093','399.473732758980930','test','test','0.04'),('2019-03-02 19:59:59','2019-03-03 03:59:59','MDAETH','4h','0.006435400000000','0.006445000000000','2.485960547735384','2.489668976311426','386.2946433376921','386.294643337692094','test','test','0.0'),('2019-03-03 07:59:59','2019-03-03 11:59:59','MDAETH','4h','0.006340000000000','0.006400000000000','2.486784642974504','2.510318882497922','392.2373253903004','392.237325390300384','test','test','0.0'),('2019-03-03 15:59:59','2019-03-04 03:59:59','MDAETH','4h','0.006525200000000','0.006279500000000','2.492014473979708','2.398180115453255','381.90622110888677','381.906221108886768','test','test','3.76'),('2019-03-07 19:59:59','2019-03-09 03:59:59','MDAETH','4h','0.006495600000000','0.006344300000000','2.471162394307163','2.413602373637991','380.4363560421151','380.436356042115108','test','test','2.37'),('2019-03-09 07:59:59','2019-03-09 11:59:59','MDAETH','4h','0.006285700000000','0.006285800000000','2.458371278602903','2.458410389143950','391.1054104718492','391.105410471849211','test','test','0.0'),('2019-03-09 15:59:59','2019-03-09 19:59:59','MDAETH','4h','0.006317100000000','0.006945000000000','2.458379969834246','2.702735256763205','389.1627439543851','389.162743954385121','test','test','0.0'),('2019-03-09 23:59:59','2019-03-12 19:59:59','MDAETH','4h','0.006769200000000','0.007400400000000','2.512681144707348','2.746978305160471','371.1932199827673','371.193219982767289','test','test','0.0'),('2019-03-12 23:59:59','2019-03-16 15:59:59','MDAETH','4h','0.008161400000000','0.007786100000000','2.564747180363598','2.446807903181931','314.2533364819269','314.253336481926908','test','test','5.68'),('2019-03-16 19:59:59','2019-03-18 03:59:59','MDAETH','4h','0.007880100000000','0.007792300000000','2.538538452101005','2.510254080570889','322.14546161863495','322.145461618634954','test','test','1.94'),('2019-03-18 07:59:59','2019-03-18 19:59:59','MDAETH','4h','0.007868200000000','0.007668600000000','2.532253036205424','2.468015001327484','321.83384207384455','321.833842073844551','test','test','2.53'),('2019-03-18 23:59:59','2019-03-19 03:59:59','MDAETH','4h','0.007715300000000','0.007647400000000','2.517977917343659','2.495817962372675','326.36163432966435','326.361634329664355','test','test','0.88');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 17:42:03
