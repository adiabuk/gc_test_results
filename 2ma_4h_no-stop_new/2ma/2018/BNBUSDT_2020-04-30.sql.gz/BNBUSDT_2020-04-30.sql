-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-23 11:59:59','2018-04-25 15:59:59','BNBUSDT','4h','13.726500000000000','13.590000000000000','222.222222222222200','220.012384803118039','16.18928512164224','16.189285121642239','test','test','2.01'),('2018-04-25 19:59:59','2018-05-01 03:59:59','BNBUSDT','4h','13.647500000000001','13.802800000000000','221.731147240199078','224.254308783808000','16.247015734764542','16.247015734764542','test','test','1.81'),('2018-05-01 23:59:59','2018-05-02 03:59:59','BNBUSDT','4h','14.171099999999999','14.036700000000000','222.291849805445509','220.183613704235881','15.686280514952651','15.686280514952651','test','test','0.94'),('2018-05-02 07:59:59','2018-05-02 15:59:59','BNBUSDT','4h','14.219900000000001','14.138999999999999','221.823352894065579','220.561353214100848','15.599501606485669','15.599501606485669','test','test','0.56'),('2018-05-02 19:59:59','2018-05-06 11:59:59','BNBUSDT','4h','14.120300000000000','14.150399999999999','221.542908520740070','222.015167718241116','15.689674335583526','15.689674335583526','test','test','0.0'),('2018-05-09 19:59:59','2018-05-10 19:59:59','BNBUSDT','4h','14.570800000000000','13.919900000000000','221.647855009073652','211.746505129492164','15.211783499126586','15.211783499126586','test','test','4.46'),('2018-05-18 11:59:59','2018-05-22 23:59:59','BNBUSDT','4h','14.879799999999999','13.888000000000000','219.447555035833346','204.820470996764328','14.748017784905265','14.748017784905265','test','test','7.25'),('2018-05-31 07:59:59','2018-06-04 15:59:59','BNBUSDT','4h','13.856199999999999','13.891999999999999','216.197091916040222','216.755676224190665','15.60291363548738','15.602913635487379','test','test','0.54'),('2018-06-04 19:59:59','2018-06-10 07:59:59','BNBUSDT','4h','14.070499999999999','14.597200000000001','216.321221762295863','224.418758275014056','15.374096283877323','15.374096283877323','test','test','0.0'),('2018-06-11 23:59:59','2018-06-12 15:59:59','BNBUSDT','4h','15.470000000000001','15.770000000000000','218.120674320677693','222.350551650748997','14.09959110023773','14.099591100237729','test','test','0.0'),('2018-06-12 19:59:59','2018-06-12 23:59:59','BNBUSDT','4h','15.180000000000000','15.226300000000000','219.060647060693526','219.728796465101283','14.43087266539483','14.430872665394830','test','test','0.0'),('2018-06-13 03:59:59','2018-06-13 11:59:59','BNBUSDT','4h','15.630100000000001','15.153499999999999','219.209124706117450','212.524902030962721','14.024806284420281','14.024806284420281','test','test','3.04'),('2018-06-15 15:59:59','2018-06-15 23:59:59','BNBUSDT','4h','15.325400000000000','14.989500000000000','217.723741889416459','212.951702993162201','14.206724906979032','14.206724906979032','test','test','2.19'),('2018-06-16 03:59:59','2018-06-20 07:59:59','BNBUSDT','4h','15.193700000000000','15.991899999999999','216.663288801359926','228.045679997793030','14.260074162406783','14.260074162406783','test','test','0.0'),('2018-06-20 11:59:59','2018-06-22 11:59:59','BNBUSDT','4h','15.995100000000001','16.139199999999999','219.192709067233949','221.167418157929717','13.70374108741014','13.703741087410140','test','test','0.34'),('2018-06-22 15:59:59','2018-06-22 19:59:59','BNBUSDT','4h','16.020000000000000','16.024500000000000','219.631533309610774','219.693227560540436','13.709833539925766','13.709833539925766','test','test','0.0'),('2018-07-16 11:59:59','2018-07-17 07:59:59','BNBUSDT','4h','13.183100000000000','13.050000000000001','219.645243143150736','217.427647747352097','16.661122432747288','16.661122432747288','test','test','1.00'),('2018-07-17 15:59:59','2018-07-18 19:59:59','BNBUSDT','4h','13.183600000000000','13.170000000000000','219.152444166306594','218.926369858783488','16.62311084728804','16.623110847288039','test','test','0.10'),('2018-07-19 11:59:59','2018-07-19 15:59:59','BNBUSDT','4h','13.263400000000001','13.060400000000000','219.102205431301428','215.748785666945793','16.51930918401778','16.519309184017779','test','test','1.53'),('2018-07-25 07:59:59','2018-07-30 15:59:59','BNBUSDT','4h','13.042199999999999','13.390000000000001','218.357001039222382','224.179988339021634','16.742344162734998','16.742344162734998','test','test','0.77'),('2018-07-31 07:59:59','2018-07-31 11:59:59','BNBUSDT','4h','13.404999999999999','13.449999999999999','219.650998216955571','220.388357032305265','16.385751452216006','16.385751452216006','test','test','0.0'),('2018-07-31 15:59:59','2018-08-01 07:59:59','BNBUSDT','4h','13.752800000000001','13.495799999999999','219.814855731477707','215.707152723872696','15.983280185233385','15.983280185233385','test','test','1.86'),('2018-08-01 11:59:59','2018-08-02 07:59:59','BNBUSDT','4h','13.635100000000000','13.364000000000001','218.902032840898841','214.549711178192496','16.0543034404514','16.054303440451399','test','test','1.98'),('2018-08-02 11:59:59','2018-08-02 15:59:59','BNBUSDT','4h','13.612800000000000','13.516299999999999','217.934850249186297','216.389928333853192','16.009553526767917','16.009553526767917','test','test','0.70'),('2018-08-02 19:59:59','2018-08-04 19:59:59','BNBUSDT','4h','13.481400000000001','13.643200000000000','217.591534268001169','220.203007130208533','16.14012893824092','16.140128938240920','test','test','0.0'),('2018-08-04 23:59:59','2018-08-05 07:59:59','BNBUSDT','4h','13.866300000000001','13.405900000000001','218.171861570713901','210.927944659414095','15.733963751737225','15.733963751737225','test','test','3.32'),('2018-08-05 23:59:59','2018-08-06 03:59:59','BNBUSDT','4h','13.640000000000001','13.746600000000001','216.562102257091738','218.254589067986615','15.876986968994995','15.876986968994995','test','test','0.0'),('2018-08-06 07:59:59','2018-08-06 11:59:59','BNBUSDT','4h','13.753399999999999','13.619700000000000','216.938210437290621','214.829303640755541','15.773424057854104','15.773424057854104','test','test','0.97'),('2018-08-06 15:59:59','2018-08-06 19:59:59','BNBUSDT','4h','13.679600000000001','13.612399999999999','216.469564482505007','215.406174125095077','15.82426127098051','15.824261270980511','test','test','0.49'),('2018-08-06 23:59:59','2018-08-07 03:59:59','BNBUSDT','4h','13.699800000000000','13.560300000000000','216.233255514191711','214.031432192374638','15.783679726287371','15.783679726287371','test','test','1.01'),('2018-08-07 11:59:59','2018-08-07 19:59:59','BNBUSDT','4h','13.763900000000000','13.649900000000001','215.743961442676806','213.957054272146280','15.674624302899383','15.674624302899383','test','test','0.82'),('2018-08-26 23:59:59','2018-08-27 03:59:59','BNBUSDT','4h','10.215800000000000','10.313599999999999','215.346870960336702','217.408473965477839','21.079785328641584','21.079785328641584','test','test','0.0'),('2018-08-27 07:59:59','2018-08-30 11:59:59','BNBUSDT','4h','10.420000000000000','10.449999999999999','215.805004961479170','216.426324553498773','20.710653067320457','20.710653067320457','test','test','0.0'),('2018-08-30 15:59:59','2018-08-30 19:59:59','BNBUSDT','4h','10.508699999999999','10.385800000000000','215.943075981927933','213.417606224662165','20.548980937882703','20.548980937882703','test','test','1.16'),('2018-08-30 23:59:59','2018-09-05 11:59:59','BNBUSDT','4h','10.789899999999999','10.534700000000001','215.381860480313350','210.287702907529933','19.96143249523289','19.961432495232891','test','test','2.36'),('2018-09-14 19:59:59','2018-09-14 23:59:59','BNBUSDT','4h','10.026000000000000','9.926800000000000','214.249825464139263','212.129978796869921','21.369422049086303','21.369422049086303','test','test','0.98'),('2018-09-15 03:59:59','2018-09-16 03:59:59','BNBUSDT','4h','10.140000000000001','9.897100000000000','213.778748426968292','208.657756514452444','21.08271680739332','21.082716807393322','test','test','2.39'),('2018-09-16 11:59:59','2018-09-16 15:59:59','BNBUSDT','4h','9.933500000000000','9.889699999999999','212.640750224186974','211.703148687989284','21.40642776706971','21.406427767069712','test','test','0.44'),('2018-09-16 23:59:59','2018-09-17 07:59:59','BNBUSDT','4h','9.939900000000000','9.897300000000000','212.432394327254173','211.521960620844538','21.37168324905222','21.371683249052221','test','test','0.42'),('2018-09-17 11:59:59','2018-09-17 15:59:59','BNBUSDT','4h','9.932000000000000','9.470000000000001','212.230075725829806','202.357915538019370','21.368312094827807','21.368312094827807','test','test','4.65'),('2018-09-20 23:59:59','2018-09-24 11:59:59','BNBUSDT','4h','10.038800000000000','9.925599999999999','210.036262350760836','207.667841334493318','20.922447140172213','20.922447140172213','test','test','1.12'),('2018-09-24 15:59:59','2018-09-24 23:59:59','BNBUSDT','4h','10.030600000000000','10.058800000000000','209.509946569368026','210.098962230769729','20.88708019155066','20.887080191550659','test','test','0.0'),('2018-09-27 19:59:59','2018-09-28 11:59:59','BNBUSDT','4h','10.039500000000000','9.949999999999999','209.640838938568436','207.771935598262417','20.881601567664568','20.881601567664568','test','test','0.89'),('2018-09-28 15:59:59','2018-09-28 19:59:59','BNBUSDT','4h','10.024100000000001','10.049700000000000','209.225527085167073','209.759856700132985','20.8722505846078','20.872250584607801','test','test','0.0'),('2018-09-28 23:59:59','2018-09-29 03:59:59','BNBUSDT','4h','9.991099999999999','9.781599999999999','209.344266999603974','204.954597800374955','20.95307493665402','20.953074936654019','test','test','2.09'),('2018-09-29 11:59:59','2018-09-29 15:59:59','BNBUSDT','4h','9.960900000000001','9.988099999999999','208.368784955330852','208.937772792854020','20.918670497177047','20.918670497177047','test','test','0.0'),('2018-09-29 19:59:59','2018-09-30 03:59:59','BNBUSDT','4h','10.000000000000000','9.895500000000000','208.495226697002664','206.316451578018984','20.849522669700267','20.849522669700267','test','test','1.04'),('2018-09-30 11:59:59','2018-09-30 15:59:59','BNBUSDT','4h','10.009800000000000','9.965999999999999','208.011054448339593','207.100858022353322','20.780740319321023','20.780740319321023','test','test','0.43'),('2018-09-30 19:59:59','2018-09-30 23:59:59','BNBUSDT','4h','9.980800000000000','10.017200000000001','207.808788575898234','208.566667694221707','20.820854898995893','20.820854898995893','test','test','0.0'),('2018-10-01 03:59:59','2018-10-01 07:59:59','BNBUSDT','4h','9.993499999999999','9.955000000000000','207.977206157747901','207.175973112561223','20.811247926927294','20.811247926927294','test','test','0.38'),('2018-10-01 11:59:59','2018-10-01 15:59:59','BNBUSDT','4h','9.917100000000000','9.920600000000000','207.799154369928630','207.872492043270142','20.95362095470739','20.953620954707390','test','test','0.0'),('2018-10-01 19:59:59','2018-10-01 23:59:59','BNBUSDT','4h','9.951900000000000','9.981100000000000','207.815451630671191','208.425205666344340','20.881987523053002','20.881987523053002','test','test','0.0'),('2018-10-02 03:59:59','2018-10-02 07:59:59','BNBUSDT','4h','9.973200000000000','9.964800000000000','207.950952527487431','207.775804330195598','20.850975868075185','20.850975868075185','test','test','0.08'),('2018-10-02 11:59:59','2018-10-02 15:59:59','BNBUSDT','4h','9.937799999999999','9.913900000000000','207.912030705867011','207.412010828844927','20.92133376661505','20.921333766615049','test','test','0.24'),('2018-10-02 19:59:59','2018-10-09 15:59:59','BNBUSDT','4h','10.024100000000001','10.345700000000001','207.800915177639894','214.467725596643021','20.730131899885265','20.730131899885265','test','test','0.0'),('2018-10-09 19:59:59','2018-10-10 07:59:59','BNBUSDT','4h','10.401800000000000','10.343200000000000','209.282428604085027','208.103406673630758','20.119828164748892','20.119828164748892','test','test','0.56'),('2018-10-10 11:59:59','2018-10-11 03:59:59','BNBUSDT','4h','10.331600000000000','9.866400000000001','209.020423730650720','199.608880395688203','20.231176558388896','20.231176558388896','test','test','4.50'),('2018-10-15 07:59:59','2018-10-18 15:59:59','BNBUSDT','4h','10.355100000000000','10.132400000000001','206.928969656214605','202.478690900583189','19.98329032614022','19.983290326140221','test','test','2.15'),('2018-11-04 15:59:59','2018-11-04 19:59:59','BNBUSDT','4h','9.700900000000001','9.826499999999999','205.940018821629877','208.606376207439098','21.228960078098925','21.228960078098925','test','test','0.0'),('2018-11-04 23:59:59','2018-11-05 11:59:59','BNBUSDT','4h','9.819000000000001','9.695000000000000','206.532542685143056','203.924330515578134','21.03396910939434','21.033969109394342','test','test','1.26'),('2018-11-05 15:59:59','2018-11-05 19:59:59','BNBUSDT','4h','9.726699999999999','9.729699999999999','205.952939980795264','206.016461917314587','21.173978839770456','21.173978839770456','test','test','0.0'),('2018-11-05 23:59:59','2018-11-06 03:59:59','BNBUSDT','4h','9.733300000000000','9.694200000000000','205.967055966688463','205.139658076117172','21.16107137010967','21.161071370109671','test','test','0.40'),('2018-11-06 07:59:59','2018-11-08 19:59:59','BNBUSDT','4h','9.742000000000001','9.742500000000000','205.783189768783728','205.793751418843669','21.123300119973692','21.123300119973692','test','test','0.12'),('2018-12-04 15:59:59','2018-12-06 07:59:59','BNBUSDT','4h','5.756200000000000','5.894800000000000','205.785536802130395','210.740520194086059','35.75024092320114','35.750240923201140','test','test','0.0'),('2018-12-17 19:59:59','2018-12-25 03:59:59','BNBUSDT','4h','5.061900000000000','5.365500000000000','206.886644222564996','219.295183542972524','40.87134163507083','40.871341635070827','test','test','1.61'),('2018-12-25 07:59:59','2018-12-25 11:59:59','BNBUSDT','4h','5.525900000000000','5.454600000000000','209.644097404877783','206.939085706336783','37.938452994965125','37.938452994965125','test','test','1.29'),('2018-12-26 03:59:59','2018-12-26 11:59:59','BNBUSDT','4h','5.651200000000000','5.481400000000000','209.042983694090850','202.761928585218982','36.99090170124767','36.990901701247672','test','test','3.00'),('2018-12-26 19:59:59','2018-12-26 23:59:59','BNBUSDT','4h','5.547400000000000','5.602900000000000','207.647193669897121','209.724638824145870','37.431444220697465','37.431444220697465','test','test','0.0'),('2018-12-27 03:59:59','2018-12-27 07:59:59','BNBUSDT','4h','5.452200000000000','5.427800000000000','208.108848148619046','207.177507424722961','38.1697017990204','38.169701799020402','test','test','0.44'),('2018-12-28 15:59:59','2019-01-04 03:59:59','BNBUSDT','4h','5.637000000000000','5.893500000000000','207.901883543308827','217.362027791820225','36.88165399029783','36.881653990297828','test','test','0.02'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','210.004137820755801','216.949500465401371','35.800838374461854','35.800838374461854','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.892900000000000','211.547551741788169','205.772009913537374','34.918632577090634','34.918632577090634','test','test','2.73'),('2019-01-16 15:59:59','2019-01-16 19:59:59','BNBUSDT','4h','5.970200000000000','6.004800000000000','210.264098002176866','211.482673224259116','35.21893705439966','35.218937054399660','test','test','0.0'),('2019-01-16 23:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.091100000000000','6.739800000000000','210.534892495972940','232.956784233448531','34.56434675115709','34.564346751157089','test','test','1.64'),('2019-01-28 11:59:59','2019-01-28 15:59:59','BNBUSDT','4h','6.799100000000000','6.158900000000000','215.517535104300833','195.224507207406617','31.69795047937239','31.697950479372391','test','test','9.41'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','211.007973349435474','314.095176683740078','32.09539628702779','32.095396287027789','test','test','0.78'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BNBUSDT','4h','9.932499999999999','9.947600000000000','233.916240757058716','234.271854674544898','23.550590561999368','23.550590561999368','test','test','0.0'),('2019-02-25 03:59:59','2019-02-25 07:59:59','BNBUSDT','4h','9.929600000000001','9.901700000000000','233.995266072055642','233.337790652762749','23.56542721479774','23.565427214797740','test','test','0.28'),('2019-02-27 23:59:59','2019-02-28 03:59:59','BNBUSDT','4h','9.846700000000000','9.825799999999999','233.849160423323866','233.352806573521605','23.748988028814107','23.748988028814107','test','test','0.21'),('2019-02-28 07:59:59','2019-02-28 11:59:59','BNBUSDT','4h','9.956300000000001','10.347600000000000','233.738859567812256','242.925205474312150','23.476478166368253','23.476478166368253','test','test','0.0'),('2019-02-28 15:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.341500000000000','14.458200000000000','235.780269769256705','329.638669088417316','22.79942655990492','22.799426559904919','test','test','1.26'),('2019-03-22 15:59:59','2019-03-22 19:59:59','BNBUSDT','4h','14.913500000000001','15.220000000000001','256.637691840181276','261.912070929530898','17.208414647143947','17.208414647143947','test','test','0.0'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.700400000000000','257.809776082258963','250.155564436089293','17.016922290283887','17.016922290283887','test','test','2.96'),('2019-03-24 11:59:59','2019-03-30 07:59:59','BNBUSDT','4h','17.040199999999999','16.367000000000001','256.108840160887951','245.990856146832414','15.029685107034423','15.029685107034423','test','test','6.66'),('2019-03-30 11:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.486999999999998','17.836900000000000','253.860399268875568','274.645633269788789','15.397610194024116','15.397610194024116','test','test','0.0'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.105000000000000','258.479340157967385','255.747412536615201','14.125789148666954','14.125789148666954','test','test','1.05'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','257.872245131000284','256.997270869979104','14.089762657345348','14.089762657345348','test','test','0.33'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','257.677806406328898','258.564920756477704','14.103566775020193','14.103566775020193','test','test','0.0'),('2019-04-13 03:59:59','2019-04-13 11:59:59','BNBUSDT','4h','18.185700000000001','18.054700000000000','257.874942928584176','256.017350560754267','14.180094410915398','14.180094410915398','test','test','0.72'),('2019-04-13 15:59:59','2019-04-23 11:59:59','BNBUSDT','4h','18.379899999999999','23.763100000000001','257.462144624621942','332.868986715344192','14.007809869728451','14.007809869728451','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 16:55:45
