-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','CMTETH','4h','0.000183550000000','0.000181860000000','1.297777777777778','1.285828747843458','7070.431913798844','7070.431913798844107','test','test','0.92'),('2019-01-11 19:59:59','2019-01-12 03:59:59','CMTETH','4h','0.000183030000000','0.000178880000000','1.295122437792373','1.265756988866851','7076.0117892824865','7076.011789282486461','test','test','2.26'),('2019-01-12 15:59:59','2019-01-14 15:59:59','CMTETH','4h','0.000180670000000','0.000180000000000','1.288596782475591','1.283818126117266','7132.322922873696','7132.322922873696371','test','test','0.37'),('2019-01-15 23:59:59','2019-01-27 19:59:59','CMTETH','4h','0.000187730000000','0.000227580000000','1.287534858840407','1.560843675357694','6858.439561286995','6858.439561286994831','test','test','0.67'),('2019-01-27 23:59:59','2019-01-28 03:59:59','CMTETH','4h','0.000226820000000','0.000218060000000','1.348270151399804','1.296198700353766','5944.229571465498','5944.229571465498339','test','test','3.86'),('2019-02-05 23:59:59','2019-02-06 03:59:59','CMTETH','4h','0.000215820000000','0.000213580000000','1.336698717834018','1.322825095704705','6193.581307728747','6193.581307728746651','test','test','1.03'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CMTETH','4h','0.000216230000000','0.000215410000000','1.333615690694171','1.328558275597426','6167.579386274665','6167.579386274665012','test','test','0.37'),('2019-02-08 07:59:59','2019-02-08 11:59:59','CMTETH','4h','0.000214390000000','0.000216070000000','1.332491820672672','1.342933474941668','6215.270398212006','6215.270398212005603','test','test','0.0'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTETH','4h','0.000220300000000','0.000214460000000','1.334812188288004','1.299427244213551','6059.06576617342','6059.065766173420343','test','test','2.65'),('2019-02-10 19:59:59','2019-02-10 23:59:59','CMTETH','4h','0.000215480000000','0.000204800000000','1.326948867382570','1.261180286058801','6158.106865521489','6158.106865521489453','test','test','4.95'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CMTETH','4h','0.000216880000000','0.000210440000000','1.312333627088400','1.273365402455196','6050.966557950939','6050.966557950939205','test','test','2.96'),('2019-02-16 03:59:59','2019-02-16 11:59:59','CMTETH','4h','0.000213290000000','0.000208490000000','1.303674021614354','1.274335396719849','6112.213519688472','6112.213519688471933','test','test','2.25'),('2019-02-16 19:59:59','2019-02-17 11:59:59','CMTETH','4h','0.000210590000000','0.000203070000000','1.297154327193353','1.250833986529057','6159.619769188247','6159.619769188247119','test','test','3.57'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTETH','4h','0.000193790000000','0.000191180000000','1.286860918156843','1.269529234394062','6640.491863134541','6640.491863134540836','test','test','1.34'),('2019-02-25 23:59:59','2019-03-05 15:59:59','CMTETH','4h','0.000194840000000','0.000205520000000','1.283009432876225','1.353336576907831','6584.938579738374','6584.938579738373846','test','test','0.0'),('2019-03-07 23:59:59','2019-03-08 03:59:59','CMTETH','4h','0.000207250000000','0.000212910000000','1.298637687105471','1.334103498005432','6266.0443286150585','6266.044328615058475','test','test','0.0'),('2019-03-08 07:59:59','2019-03-16 03:59:59','CMTETH','4h','0.000212010000000','0.000237970000000','1.306518978416573','1.466498378820772','6162.53468429118','6162.534684291180383','test','test','0.0'),('2019-03-17 15:59:59','2019-03-18 15:59:59','CMTETH','4h','0.000239420000000','0.000239550000000','1.342069956284173','1.342798671906581','5605.50478775446','5605.504787754460267','test','test','0.93'),('2019-03-18 19:59:59','2019-03-18 23:59:59','CMTETH','4h','0.000238240000000','0.000238260000000','1.342231893089153','1.342344572059359','5633.948510280191','5633.948510280190931','test','test','0.0'),('2019-03-19 03:59:59','2019-03-19 07:59:59','CMTETH','4h','0.000238960000000','0.000235220000000','1.342256932860309','1.321249061547547','5617.077891112776','5617.077891112776342','test','test','1.56'),('2019-03-19 11:59:59','2019-03-21 15:59:59','CMTETH','4h','0.000242390000000','0.000241470000000','1.337588517013029','1.332511651483709','5518.332097087458','5518.332097087458351','test','test','0.37'),('2019-03-21 19:59:59','2019-03-21 23:59:59','CMTETH','4h','0.000244590000000','0.000242790000000','1.336460324673180','1.326624973332521','5464.084078143751','5464.084078143750958','test','test','0.73'),('2019-03-22 03:59:59','2019-03-22 07:59:59','CMTETH','4h','0.000243920000000','0.000242340000000','1.334274691041922','1.325631881875612','5470.132383740252','5470.132383740252408','test','test','0.64'),('2019-03-22 11:59:59','2019-03-22 15:59:59','CMTETH','4h','0.000242270000000','0.000242180000000','1.332354066782742','1.331859115422646','5499.459556621712','5499.459556621712181','test','test','0.03'),('2019-03-22 19:59:59','2019-03-24 11:59:59','CMTETH','4h','0.000243180000000','0.000243860000000','1.332244077591610','1.335969408510116','5478.427821332387','5478.427821332386884','test','test','0.26'),('2019-03-24 15:59:59','2019-03-24 19:59:59','CMTETH','4h','0.000241700000000','0.000244210000000','1.333071928906833','1.346915580299287','5515.398961137084','5515.398961137084370','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 07:59:59','CMTETH','4h','0.000242850000000','0.000240460000000','1.336148295882934','1.322998637957630','5501.948922721575','5501.948922721575400','test','test','0.98'),('2019-03-27 15:59:59','2019-03-27 23:59:59','CMTETH','4h','0.000243660000000','0.000238650000000','1.333226149677311','1.305813102768162','5471.666049730409','5471.666049730409213','test','test','2.05'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTETH','4h','0.000242980000000','0.000241030000000','1.327134361475278','1.316483641231320','5461.9078174141','5461.907817414099554','test','test','0.80'),('2019-03-30 11:59:59','2019-03-30 15:59:59','CMTETH','4h','0.000243340000000','0.000252750000000','1.324767534754399','1.375996525064413','5444.100989374531','5444.100989374531309','test','test','0.0'),('2019-03-30 19:59:59','2019-04-03 03:59:59','CMTETH','4h','0.000258880000000','0.000244460000000','1.336151754823291','1.261726120148724','5161.278410164133','5161.278410164132765','test','test','5.57'),('2019-04-03 07:59:59','2019-04-07 23:59:59','CMTETH','4h','0.000261660000000','0.000275150000000','1.319612724895609','1.387645957559531','5043.234445064622','5043.234445064622378','test','test','0.0'),('2019-04-13 19:59:59','2019-04-13 23:59:59','CMTETH','4h','0.000259730000000','0.000253220000000','1.334731221043147','1.301276863637415','5138.918188284554','5138.918188284554162','test','test','2.50'),('2019-04-19 23:59:59','2019-04-20 03:59:59','CMTETH','4h','0.000246410000000','0.000242480000000','1.327296919397429','1.306127823608979','5386.53836856227','5386.538368562270080','test','test','1.59'),('2019-05-23 15:59:59','2019-05-23 19:59:59','CMTETH','4h','0.000162740000000','0.000160690000000','1.322592675888885','1.305932266735805','8127.028855160898','8127.028855160898274','test','test','1.25'),('2019-05-24 03:59:59','2019-05-24 19:59:59','CMTETH','4h','0.000164790000000','0.000169570000000','1.318890362743756','1.357146907035977','8003.461149000278','8003.461149000278056','test','test','1.25'),('2019-05-24 23:59:59','2019-05-25 07:59:59','CMTETH','4h','0.000168100000000','0.000163150000000','1.327391817030916','1.288304431579976','7896.441505240427','7896.441505240427432','test','test','2.94'),('2019-05-26 07:59:59','2019-05-26 11:59:59','CMTETH','4h','0.000162530000000','0.000159280000000','1.318705731375151','1.292336484916225','8113.614295054152','8113.614295054151626','test','test','1.99'),('2019-05-26 15:59:59','2019-05-26 19:59:59','CMTETH','4h','0.000168090000000','0.000161000000000','1.312845898828723','1.257470341551695','7810.374792246555','7810.374792246555444','test','test','4.21'),('2019-05-27 11:59:59','2019-05-27 19:59:59','CMTETH','4h','0.000164310000000','0.000164360000000','1.300540219433828','1.300935977518982','7915.161703084586','7915.161703084586406','test','test','0.0'),('2019-05-27 23:59:59','2019-05-28 03:59:59','CMTETH','4h','0.000162800000000','0.000162580000000','1.300628165674974','1.298870560045684','7989.116496775022','7989.116496775021915','test','test','0.13'),('2019-05-28 07:59:59','2019-05-28 11:59:59','CMTETH','4h','0.000164560000000','0.000165970000000','1.300237586646243','1.311378416721421','7901.297925657769','7901.297925657769156','test','test','0.0'),('2019-05-28 15:59:59','2019-05-28 19:59:59','CMTETH','4h','0.000165040000000','0.000162570000000','1.302713326662949','1.283216829348010','7893.318750987329','7893.318750987328713','test','test','1.49'),('2019-05-28 23:59:59','2019-05-29 07:59:59','CMTETH','4h','0.000165290000000','0.000163030000000','1.298380771704074','1.280628091299626','7855.168320552202','7855.168320552202204','test','test','1.36'),('2019-06-08 11:59:59','2019-06-09 15:59:59','CMTETH','4h','0.000148210000000','0.000149640000000','1.294435731614196','1.306925058219744','8733.794829054694','8733.794829054693764','test','test','0.0'),('2019-06-09 19:59:59','2019-06-09 23:59:59','CMTETH','4h','0.000147200000000','0.000146630000000','1.297211137526540','1.292187969398890','8812.57566254443','8812.575662544430088','test','test','0.38'),('2019-06-10 07:59:59','2019-06-11 07:59:59','CMTETH','4h','0.000153230000000','0.000148790000000','1.296094877942618','1.258539169151486','8458.492970975774','8458.492970975774369','test','test','2.89'),('2019-06-11 11:59:59','2019-06-11 15:59:59','CMTETH','4h','0.000148510000000','0.000150630000000','1.287749164877922','1.306131955461325','8671.127633680708','8671.127633680707731','test','test','0.0'),('2019-06-11 19:59:59','2019-06-12 03:59:59','CMTETH','4h','0.000151530000000','0.000148350000000','1.291834229452012','1.264723869459552','8525.270437880363','8525.270437880362806','test','test','2.09'),('2019-06-13 19:59:59','2019-06-18 07:59:59','CMTETH','4h','0.000167940000000','0.000167170000000','1.285809705009243','1.279914305027957','7656.363612059322','7656.363612059321895','test','test','3.09'),('2019-06-18 15:59:59','2019-06-20 03:59:59','CMTETH','4h','0.000172610000000','0.000170060000000','1.284499616124512','1.265523461665804','7441.629199493149','7441.629199493148917','test','test','1.47'),('2019-07-03 07:59:59','2019-07-07 19:59:59','CMTETH','4h','0.000153910000000','0.000180160000000','1.280282692911466','1.498640308978817','8318.385373994322','8318.385373994322435','test','test','0.0'),('2019-07-07 23:59:59','2019-07-08 03:59:59','CMTETH','4h','0.000179750000000','0.000178610000000','1.328806607593100','1.320379127578323','7392.526328751598','7392.526328751598157','test','test','0.63'),('2019-07-09 15:59:59','2019-07-16 19:59:59','CMTETH','4h','0.000233600000000','0.000206600000000','1.326933834256483','1.173563913344989','5680.36744116645','5680.367441166449680','test','test','17.0'),('2019-07-19 15:59:59','2019-07-19 19:59:59','CMTETH','4h','0.000208700000000','0.000204870000000','1.292851629609484','1.269125603057475','6194.7850005246','6194.785000524600036','test','test','1.83'),('2019-07-20 11:59:59','2019-07-20 15:59:59','CMTETH','4h','0.000205140000000','0.000198810000000','1.287579179264593','1.247848379787432','6276.5875951281705','6276.587595128170506','test','test','3.08'),('2019-07-21 11:59:59','2019-07-21 15:59:59','CMTETH','4h','0.000204010000000','0.000198700000000','1.278750112714113','1.245466631029333','6268.075646851199','6268.075646851199053','test','test','2.60'),('2019-07-22 19:59:59','2019-07-22 23:59:59','CMTETH','4h','0.000203780000000','0.000204010000000','1.271353783450828','1.272788720000998','6238.854565957544','6238.854565957543855','test','test','0.0'),('2019-07-23 03:59:59','2019-07-23 07:59:59','CMTETH','4h','0.000208660000000','0.000200440000000','1.271672658239755','1.221576093250151','6094.472626472517','6094.472626472516822','test','test','3.93'),('2019-07-28 19:59:59','2019-07-28 23:59:59','CMTETH','4h','0.000203240000000','0.000198770000000','1.260540088242065','1.232816145147979','6202.224405835787','6202.224405835787366','test','test','2.19'),('2019-08-18 03:59:59','2019-08-18 07:59:59','CMTETH','4h','0.000159250000000','0.000152810000000','1.254379211998935','1.203652668041176','7876.792540024711','7876.792540024711343','test','test','4.04'),('2019-08-19 11:59:59','2019-08-22 19:59:59','CMTETH','4h','0.000170960000000','0.000162260000000','1.243106646674989','1.179846072119114','7271.330408721272','7271.330408721271851','test','test','6.38'),('2019-08-22 23:59:59','2019-08-23 03:59:59','CMTETH','4h','0.000161830000000','0.000162480000000','1.229048741218128','1.233985289953170','7594.69036160247','7594.690361602470148','test','test','0.0'),('2019-08-23 07:59:59','2019-08-23 11:59:59','CMTETH','4h','0.000160750000000','0.000163390000000','1.230145752048137','1.250348456778507','7652.539670594943','7652.539670594943345','test','test','0.0'),('2019-08-23 15:59:59','2019-08-23 19:59:59','CMTETH','4h','0.000160660000000','0.000158100000000','1.234635241988219','1.214962229293772','7684.770583768325','7684.770583768325196','test','test','1.59'),('2019-08-24 07:59:59','2019-08-24 11:59:59','CMTETH','4h','0.000162970000000','0.000163010000000','1.230263461389453','1.230565422108945','7549.017987294921','7549.017987294921113','test','test','0.0'),('2019-08-24 15:59:59','2019-08-24 23:59:59','CMTETH','4h','0.000162880000000','0.000162520000000','1.230330563771562','1.227611267338864','7553.601201937392','7553.601201937392034','test','test','0.22'),('2019-08-25 03:59:59','2019-08-25 15:59:59','CMTETH','4h','0.000163050000000','0.000163770000000','1.229726275675407','1.235156529698629','7542.019476696764','7542.019476696764286','test','test','0.0'),('2019-08-25 19:59:59','2019-08-26 03:59:59','CMTETH','4h','0.000166050000000','0.000159320000000','1.230932998791679','1.181043332535323','7413.026189651786','7413.026189651785899','test','test','4.05'),('2019-09-22 03:59:59','2019-09-22 07:59:59','CMTETH','4h','0.000113060000000','0.000112630000000','1.219846406290267','1.215206976299954','10789.3720704959','10789.372070495899607','test','test','0.38'),('2019-10-03 03:59:59','2019-10-03 15:59:59','CMTETH','4h','0.000106100000000','0.000103630000000','1.218815421847975','1.190441490726726','11487.421506578461','11487.421506578461049','test','test','2.83'),('2019-10-03 19:59:59','2019-10-05 15:59:59','CMTETH','4h','0.000103810000000','0.000103080000000','1.212510103821031','1.203983638395838','11680.08962355294','11680.089623552939884','test','test','0.70'),('2019-10-05 19:59:59','2019-10-06 07:59:59','CMTETH','4h','0.000103670000000','0.000101250000000','1.210615333726543','1.182355575767459','11677.58593350577','11677.585933505770299','test','test','2.33'),('2019-10-07 07:59:59','2019-10-07 11:59:59','CMTETH','4h','0.000103000000000','0.000102320000000','1.204335387513413','1.196384435440509','11692.57657780013','11692.576577800129598','test','test','0.66'),('2019-10-07 15:59:59','2019-10-07 19:59:59','CMTETH','4h','0.000102660000000','0.000102590000000','1.202568509274990','1.201748522954619','11714.090291009063','11714.090291009062639','test','test','0.06'),('2019-10-07 23:59:59','2019-10-08 03:59:59','CMTETH','4h','0.000102750000000','0.000100520000000','1.202386290092686','1.176290704429361','11702.056351267014','11702.056351267014179','test','test','2.17'),('2019-10-08 19:59:59','2019-10-09 03:59:59','CMTETH','4h','0.000104310000000','0.000102670000000','1.196587271056391','1.177774088000764','11471.453082699561','11471.453082699561492','test','test','1.57'),('2019-10-09 07:59:59','2019-10-09 15:59:59','CMTETH','4h','0.000104130000000','0.000094380000000','1.192406563710696','1.080758009056137','11451.13381072406','11451.133810724060822','test','test','9.36'),('2019-10-22 11:59:59','2019-10-23 03:59:59','CMTETH','4h','0.000095550000000','0.000096390000000','1.167595773787461','1.177860352018560','12219.735989403043','12219.735989403043277','test','test','0.0'),('2019-10-23 07:59:59','2019-10-23 15:59:59','CMTETH','4h','0.000097750000000','0.000094040000000','1.169876791172150','1.125475329328174','11968.049014548846','11968.049014548845662','test','test','3.79'),('2019-10-27 15:59:59','2019-11-04 19:59:59','CMTETH','4h','0.000099330000000','0.000106670000000','1.160009799651266','1.245728836492505','11678.342893901803','11678.342893901803109','test','test','3.70'),('2019-11-04 23:59:59','2019-11-07 03:59:59','CMTETH','4h','0.000109530000000','0.000106070000000','1.179058474504875','1.141812584595381','10764.708066327716','10764.708066327715642','test','test','3.15'),('2019-11-14 11:59:59','2019-11-14 15:59:59','CMTETH','4h','0.000106670000000','0.000111490000000','1.170781610080543','1.223684650866033','10975.734602798751','10975.734602798751439','test','test','0.0'),('2019-11-14 19:59:59','2019-11-16 19:59:59','CMTETH','4h','0.000111390000000','0.000107800000000','1.182537841366207','1.144425705173509','10616.193925542753','10616.193925542753277','test','test','3.22'),('2019-11-16 23:59:59','2019-11-17 03:59:59','CMTETH','4h','0.000106420000000','0.000106180000000','1.174068477767830','1.171420700708403','11032.404414281433','11032.404414281432764','test','test','0.22'),('2019-11-17 07:59:59','2019-11-17 11:59:59','CMTETH','4h','0.000106790000000','0.000106340000000','1.173480082865735','1.168535181308571','10988.670127031884','10988.670127031884476','test','test','0.42'),('2019-11-17 15:59:59','2019-11-18 03:59:59','CMTETH','4h','0.000107640000000','0.000106670000000','1.172381215853032','1.161816279218162','10891.687252443624','10891.687252443623947','test','test','0.90'),('2019-11-28 15:59:59','2019-11-28 19:59:59','CMTETH','4h','0.000102160000000','0.000099780000000','1.170033452156394','1.142775429289007','11452.950784616229','11452.950784616228702','test','test','2.32'),('2019-11-29 07:59:59','2019-11-29 11:59:59','CMTETH','4h','0.000099960000000','0.000100180000000','1.163976113741419','1.166537885900514','11644.418904976184','11644.418904976184422','test','test','0.0'),('2019-12-04 15:59:59','2019-12-04 19:59:59','CMTETH','4h','0.000098250000000','0.000096490000000','1.164545396443440','1.143684328781960','11852.879353113894','11852.879353113894467','test','test','1.79'),('2019-12-19 15:59:59','2019-12-19 19:59:59','CMTETH','4h','0.000091710000000','0.000089370000000','1.159909603629778','1.130314265362482','12647.580456109235','12647.580456109235456','test','test','2.55'),('2019-12-20 03:59:59','2019-12-22 03:59:59','CMTETH','4h','0.000091280000000','0.000092160000000','1.153332861792601','1.164451758794984','12635.110229980295','12635.110229980295117','test','test','0.27'),('2019-12-22 07:59:59','2019-12-22 11:59:59','CMTETH','4h','0.000090940000000','0.000090300000000','1.155803727793131','1.147669635140969','12709.519769002978','12709.519769002978137','test','test','0.70'),('2019-12-27 03:59:59','2019-12-27 11:59:59','CMTETH','4h','0.000094120000000','0.000090060000000','1.153996151648206','1.104216887138094','12260.902588697469','12260.902588697468673','test','test','4.31'),('2019-12-27 15:59:59','2019-12-27 19:59:59','CMTETH','4h','0.000091650000000','0.000089840000000','1.142934092868181','1.120362235714974','12470.639311164005','12470.639311164004539','test','test','1.97');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 19:56:05
