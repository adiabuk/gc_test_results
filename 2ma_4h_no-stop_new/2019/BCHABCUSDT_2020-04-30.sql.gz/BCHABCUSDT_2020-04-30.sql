-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-02 19:59:59','2019-05-02 23:59:59','BCHABCUSDT','4h','269.000000000000000','269.269999999999982','222.222222222222200','222.445270549359748','0.8261049153242461','0.826104915324246','test','test','0.0'),('2019-05-03 03:59:59','2019-05-03 11:59:59','BCHABCUSDT','4h','272.220000000000027','289.709999999999980','222.271788517141687','236.552640699805693','0.8165152763101229','0.816515276310123','test','test','0.0'),('2019-05-03 15:59:59','2019-05-04 15:59:59','BCHABCUSDT','4h','290.589999999999975','276.680000000000007','225.445311224400342','214.653665678678180','0.7758192340562317','0.775819234056232','test','test','4.78'),('2019-05-04 19:59:59','2019-05-06 07:59:59','BCHABCUSDT','4h','282.990000000000009','277.610000000000014','223.047167769795436','218.806757286734211','0.7881803871861035','0.788180387186104','test','test','1.90'),('2019-05-06 11:59:59','2019-05-08 03:59:59','BCHABCUSDT','4h','286.639999999999986','283.269999999999982','222.104854329115142','219.493588074966652','0.7748564552369354','0.774856455236935','test','test','1.17'),('2019-05-08 07:59:59','2019-05-08 15:59:59','BCHABCUSDT','4h','285.089999999999975','286.129999999999995','221.524572939304363','222.332688116465562','0.7770338241934279','0.777033824193428','test','test','0.0'),('2019-05-08 19:59:59','2019-05-08 23:59:59','BCHABCUSDT','4h','284.660000000000025','286.209999999999980','221.704154089784623','222.911353692254806','0.7788384532065784','0.778838453206578','test','test','0.0'),('2019-05-09 03:59:59','2019-05-09 15:59:59','BCHABCUSDT','4h','291.000000000000000','282.509999999999991','221.972420668111340','215.496318085732412','0.7627918236017572','0.762791823601757','test','test','2.91'),('2019-05-09 23:59:59','2019-05-10 03:59:59','BCHABCUSDT','4h','284.430000000000007','281.730000000000018','220.533286760916013','218.439837145001832','0.7753517095978484','0.775351709597848','test','test','0.94'),('2019-05-10 07:59:59','2019-05-17 11:59:59','BCHABCUSDT','4h','292.420000000000016','351.100000000000023','220.068075735157322','264.229195645351695','0.7525753222596173','0.752575322259617','test','test','2.03'),('2019-05-17 15:59:59','2019-05-17 19:59:59','BCHABCUSDT','4h','346.860000000000014','354.569999999999993','229.881657937422773','234.991464726033513','0.6627505562400472','0.662750556240047','test','test','0.0'),('2019-05-17 23:59:59','2019-05-23 07:59:59','BCHABCUSDT','4h','367.389999999999986','378.160000000000025','231.017170557113985','237.789415111674884','0.628806365325986','0.628806365325986','test','test','2.83'),('2019-05-23 11:59:59','2019-05-26 11:59:59','BCHABCUSDT','4h','382.800000000000011','393.449999999999989','232.522113791460896','238.991185139107358','0.607424539685112','0.607424539685112','test','test','0.0'),('2019-05-26 15:59:59','2019-05-30 23:59:59','BCHABCUSDT','4h','403.379999999999995','420.990000000000009','233.959685202049030','244.173453996754006','0.5799982279787026','0.579998227978703','test','test','0.0'),('2019-05-31 03:59:59','2019-05-31 07:59:59','BCHABCUSDT','4h','422.670000000000016','424.290000000000020','236.229411600872339','237.134826337649031','0.5588979856646374','0.558897985664637','test','test','0.0'),('2019-05-31 11:59:59','2019-06-03 07:59:59','BCHABCUSDT','4h','422.089999999999975','425.300000000000011','236.430614875711598','238.228672810633157','0.5601426588540633','0.560142658854063','test','test','0.0'),('2019-06-03 11:59:59','2019-06-03 15:59:59','BCHABCUSDT','4h','427.879999999999995','423.920000000000016','236.830183305694135','234.638336232003979','0.5534967357803453','0.553496735780345','test','test','0.92'),('2019-06-03 19:59:59','2019-06-03 23:59:59','BCHABCUSDT','4h','428.670000000000016','401.000000000000000','236.343106178207449','221.087516218679127','0.5513404394480776','0.551340439448078','test','test','6.45'),('2019-06-13 07:59:59','2019-06-13 11:59:59','BCHABCUSDT','4h','400.759999999999991','398.670000000000016','232.952975076090041','231.738104036293095','0.5812780094722279','0.581278009472228','test','test','0.52'),('2019-06-13 15:59:59','2019-06-14 19:59:59','BCHABCUSDT','4h','417.519999999999982','404.160000000000025','232.683003733912955','225.237504285060027','0.5572978629380939','0.557297862938094','test','test','3.19'),('2019-06-14 23:59:59','2019-06-18 07:59:59','BCHABCUSDT','4h','419.769999999999982','415.870000000000005','231.028448300834498','228.882008706834824','0.5503691266665901','0.550369126666590','test','test','0.92'),('2019-06-18 11:59:59','2019-06-18 15:59:59','BCHABCUSDT','4h','413.860000000000014','413.829999999999984','230.551461724390123','230.534749445233558','0.5570759718851547','0.557075971885155','test','test','0.00'),('2019-06-18 23:59:59','2019-06-19 03:59:59','BCHABCUSDT','4h','413.870000000000005','413.350000000000023','230.547747884577547','230.258080044676177','0.5570535382718669','0.557053538271867','test','test','0.12'),('2019-06-19 07:59:59','2019-06-19 15:59:59','BCHABCUSDT','4h','419.560000000000002','411.680000000000007','230.483377253488356','226.154535102765010','0.5493454505994098','0.549345450599410','test','test','1.87'),('2019-06-19 19:59:59','2019-06-19 23:59:59','BCHABCUSDT','4h','411.540000000000020','415.389999999999986','229.521412331105381','231.668609292457262','0.5577134964550357','0.557713496455036','test','test','0.0'),('2019-06-20 03:59:59','2019-06-20 07:59:59','BCHABCUSDT','4h','415.680000000000007','410.259999999999991','229.998567211405799','226.999644399902166','0.5533067917903334','0.553306791790333','test','test','1.30'),('2019-06-21 03:59:59','2019-06-26 23:59:59','BCHABCUSDT','4h','422.740000000000009','488.550000000000011','229.332139919960554','265.033393948755077','0.5424898044186983','0.542489804418698','test','test','0.0'),('2019-06-27 03:59:59','2019-06-27 11:59:59','BCHABCUSDT','4h','484.360000000000014','444.269999999999982','237.265751926359371','217.627499397810880','0.4898541413955722','0.489854141395572','test','test','8.27'),('2019-07-09 03:59:59','2019-07-09 11:59:59','BCHABCUSDT','4h','423.000000000000000','414.930000000000007','232.901695808904151','228.458393952691722','0.5505950255529649','0.550595025552965','test','test','1.90'),('2019-07-10 03:59:59','2019-07-10 07:59:59','BCHABCUSDT','4h','417.930000000000007','414.240000000000009','231.914295396412513','229.866670794175860','0.5549118163242948','0.554911816324295','test','test','0.88'),('2019-07-20 19:59:59','2019-07-20 23:59:59','BCHABCUSDT','4h','334.230000000000018','324.069999999999993','231.459267707026555','224.423315937576177','0.6925149379380263','0.692514937938026','test','test','3.03'),('2019-07-26 19:59:59','2019-07-26 23:59:59','BCHABCUSDT','4h','319.560000000000002','317.160000000000025','229.895722869370928','228.169130883870594','0.7194133272918104','0.719413327291810','test','test','0.75'),('2019-07-27 03:59:59','2019-07-27 07:59:59','BCHABCUSDT','4h','320.790000000000020','318.850000000000023','229.512035761481940','228.124045645277334','0.7154588227858784','0.715458822785878','test','test','0.60'),('2019-07-30 15:59:59','2019-08-07 19:59:59','BCHABCUSDT','4h','319.509999999999991','336.759999999999991','229.203593513436516','241.578048109870991','0.7173596867498248','0.717359686749825','test','test','0.42'),('2019-08-07 23:59:59','2019-08-08 15:59:59','BCHABCUSDT','4h','338.339999999999975','328.620000000000005','231.953472312644152','225.289797456349021','0.6855632568204888','0.685563256820489','test','test','2.87'),('2019-08-08 23:59:59','2019-08-09 03:59:59','BCHABCUSDT','4h','333.620000000000005','330.490000000000009','230.472655677911916','228.310377000758677','0.6908238585154125','0.690823858515413','test','test','0.93'),('2019-08-11 19:59:59','2019-08-12 11:59:59','BCHABCUSDT','4h','338.730000000000018','330.269999999999982','229.992149305211143','224.247947188120548','0.6789837017837544','0.678983701783754','test','test','2.49'),('2019-08-12 15:59:59','2019-08-13 03:59:59','BCHABCUSDT','4h','330.860000000000014','329.339999999999975','228.715659945857738','227.664920046451016','0.691276249609677','0.691276249609677','test','test','0.45'),('2019-08-13 07:59:59','2019-08-14 19:59:59','BCHABCUSDT','4h','331.810000000000002','312.509999999999991','228.482162190433996','215.192310376819648','0.6885933582183599','0.688593358218360','test','test','5.81'),('2019-08-19 07:59:59','2019-08-19 11:59:59','BCHABCUSDT','4h','322.800000000000011','323.000000000000000','225.528861787408573','225.668594663361091','0.6986643797627279','0.698664379762728','test','test','0.0'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BCHABCUSDT','4h','323.639999999999986','320.540000000000020','225.559913537620247','223.399377967336562','0.6969469581560384','0.696946958156038','test','test','0.95'),('2019-08-19 23:59:59','2019-08-20 03:59:59','BCHABCUSDT','4h','324.939999999999998','320.850000000000023','225.079794522001663','222.246728849585281','0.6926810935003437','0.692681093500344','test','test','1.25'),('2019-09-03 03:59:59','2019-09-03 11:59:59','BCHABCUSDT','4h','296.120000000000005','296.379999999999995','224.450224372575803','224.647296702499034','0.7579704997047677','0.757970499704768','test','test','0.48'),('2019-09-03 15:59:59','2019-09-04 11:59:59','BCHABCUSDT','4h','301.129999999999995','297.220000000000027','224.494018223669855','221.579092406731831','0.7455053240250717','0.745505324025072','test','test','1.29'),('2019-09-04 15:59:59','2019-09-04 19:59:59','BCHABCUSDT','4h','293.149999999999977','297.379999999999995','223.846256931016939','227.076240443956408','0.7635894829644105','0.763589482964411','test','test','0.0'),('2019-09-04 23:59:59','2019-09-05 03:59:59','BCHABCUSDT','4h','294.149999999999977','292.850000000000023','224.564031045003503','223.571567198807713','0.7634337278429493','0.763433727842949','test','test','0.44'),('2019-09-06 07:59:59','2019-09-06 11:59:59','BCHABCUSDT','4h','295.069999999999993','299.000000000000000','224.343483523626674','227.331485998455889','0.7603059732389829','0.760305973238983','test','test','0.0'),('2019-09-06 15:59:59','2019-09-06 19:59:59','BCHABCUSDT','4h','297.920000000000016','288.199999999999989','225.007484073588699','217.666343011574440','0.7552614261331522','0.755261426133152','test','test','3.26'),('2019-09-07 15:59:59','2019-09-07 19:59:59','BCHABCUSDT','4h','298.930000000000007','299.160000000000025','223.376119393141124','223.547987413950096','0.7472522643867833','0.747252264386783','test','test','0.0'),('2019-09-07 23:59:59','2019-09-08 11:59:59','BCHABCUSDT','4h','299.620000000000005','300.230000000000018','223.414312286654223','223.869164200728221','0.7456588755311869','0.745658875531187','test','test','0.0'),('2019-09-08 15:59:59','2019-09-11 07:59:59','BCHABCUSDT','4h','305.680000000000007','301.490000000000009','223.515390489781765','220.451632683735625','0.7312071136148317','0.731207113614832','test','test','2.12'),('2019-09-11 11:59:59','2019-09-11 15:59:59','BCHABCUSDT','4h','300.220000000000027','294.629999999999995','222.834555421771512','218.685447551517314','0.7422375438737309','0.742237543873731','test','test','1.86'),('2019-09-12 15:59:59','2019-09-12 19:59:59','BCHABCUSDT','4h','299.290000000000020','299.829999999999984','221.912531450603893','222.312921597228609','0.7414632344903066','0.741463234490307','test','test','0.0'),('2019-09-12 23:59:59','2019-09-13 03:59:59','BCHABCUSDT','4h','300.009999999999991','298.240000000000009','222.001507038742716','220.691741806055234','0.7399803574505607','0.739980357450561','test','test','0.58'),('2019-09-14 15:59:59','2019-09-19 03:59:59','BCHABCUSDT','4h','303.959999999999980','310.240000000000009','221.710448098145520','226.291121917254458','0.7294066590937806','0.729406659093781','test','test','1.03'),('2019-09-19 07:59:59','2019-09-20 19:59:59','BCHABCUSDT','4h','310.149999999999977','313.579999999999984','222.728375613503061','225.191565451821020','0.7181311481976562','0.718131148197656','test','test','0.0'),('2019-09-20 23:59:59','2019-09-22 03:59:59','BCHABCUSDT','4h','315.310000000000002','304.069999999999993','223.275751133129262','215.316538159432355','0.7081150332470562','0.708115033247056','test','test','3.56'),('2019-10-07 15:59:59','2019-10-08 11:59:59','BCHABCUSDT','4h','233.599999999999994','233.139999999999986','221.507037138974397','221.070850336389100','0.9482321795332809','0.948232179533281','test','test','0.37'),('2019-10-09 11:59:59','2019-10-09 15:59:59','BCHABCUSDT','4h','232.250000000000000','237.879999999999995','221.410106738399890','226.777335590659050','0.9533266167423031','0.953326616742303','test','test','0.0'),('2019-10-09 19:59:59','2019-10-10 11:59:59','BCHABCUSDT','4h','237.250000000000000','231.240000000000009','222.602824261124141','216.963865467407174','0.9382626944620617','0.938262694462062','test','test','2.53'),('2019-10-20 19:59:59','2019-10-23 03:59:59','BCHABCUSDT','4h','225.120000000000005','218.460000000000008','221.349722306964821','214.801263038288624','0.9832521424438736','0.983252142443874','test','test','2.95'),('2019-10-25 15:59:59','2019-11-08 15:59:59','BCHABCUSDT','4h','235.370000000000005','279.550000000000011','219.894509136147889','261.169690398139721','0.9342503680849211','0.934250368084921','test','test','0.0'),('2019-11-09 23:59:59','2019-11-10 03:59:59','BCHABCUSDT','4h','282.569999999999993','280.519999999999982','229.066771638812753','227.404928973775526','0.8106549585547396','0.810654958554740','test','test','0.72'),('2019-11-10 07:59:59','2019-11-10 15:59:59','BCHABCUSDT','4h','287.079999999999984','284.050000000000011','228.697473268804487','226.283674522794769','0.7966332495081667','0.796633249508167','test','test','1.05'),('2019-11-10 19:59:59','2019-11-11 11:59:59','BCHABCUSDT','4h','293.430000000000007','286.120000000000005','228.161073547468987','222.477069022941862','0.7775655984305251','0.777565598430525','test','test','2.49'),('2019-11-11 15:59:59','2019-11-12 15:59:59','BCHABCUSDT','4h','286.899999999999977','286.949999999999989','226.897961430907372','226.937504470543303','0.7908607927183945','0.790860792718394','test','test','0.23'),('2019-11-12 19:59:59','2019-11-13 15:59:59','BCHABCUSDT','4h','288.449999999999989','285.290000000000020','226.906748773048690','224.420961544333750','0.7866415280743585','0.786641528074358','test','test','1.09'),('2019-11-13 19:59:59','2019-11-13 23:59:59','BCHABCUSDT','4h','285.120000000000005','285.420000000000016','226.354351611112065','226.592519068615360','0.7938915250109149','0.793891525010915','test','test','0.0'),('2019-11-14 03:59:59','2019-11-14 07:59:59','BCHABCUSDT','4h','284.300000000000011','276.500000000000000','226.407277712779461','220.195611282390161','0.796367491075552','0.796367491075552','test','test','2.74');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 20:33:11
