-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-02 03:59:59','TRXBTC','4h','0.000005100000000','0.000005060000000','0.033333333333333','0.033071895424836','6535.9477124183','6535.947712418300398','test','test','0.0'),('2019-01-02 07:59:59','2019-01-03 07:59:59','TRXBTC','4h','0.000005070000000','0.000005110000000','0.033275236020334','0.033537762537260','6563.1629231428005','6563.162923142800537','test','test','0.19'),('2019-01-03 11:59:59','2019-01-13 03:59:59','TRXBTC','4h','0.000005120000000','0.000006210000000','0.033333575246318','0.040429980913991','6510.4639152963955','6510.463915296395498','test','test','0.19'),('2019-01-13 07:59:59','2019-01-13 11:59:59','TRXBTC','4h','0.000006290000000','0.000006270000000','0.034910554283578','0.034799550931325','5550.167612651545','5550.167612651544914','test','test','1.27'),('2019-01-14 03:59:59','2019-01-19 03:59:59','TRXBTC','4h','0.000006470000000','0.000006620000000','0.034885886871966','0.035694678685072','5391.945420705787','5391.945420705787001','test','test','3.09'),('2019-01-19 07:59:59','2019-01-19 19:59:59','TRXBTC','4h','0.000006650000000','0.000006600000000','0.035065618385990','0.034801967119930','5273.025321201504','5273.025321201504084','test','test','0.45'),('2019-01-19 23:59:59','2019-01-20 03:59:59','TRXBTC','4h','0.000006590000000','0.000006620000000','0.035007029215754','0.035166393536918','5312.144038809476','5312.144038809476115','test','test','0.0'),('2019-01-20 11:59:59','2019-01-20 15:59:59','TRXBTC','4h','0.000006600000000','0.000006590000000','0.035042443509346','0.034989348897968','5309.461137779765','5309.461137779764613','test','test','0.0'),('2019-01-20 19:59:59','2019-01-28 15:59:59','TRXBTC','4h','0.000006680000000','0.000007590000000','0.035030644706818','0.039802783431849','5244.10848904461','5244.108489044609996','test','test','1.34'),('2019-01-28 19:59:59','2019-01-31 11:59:59','TRXBTC','4h','0.000007650000000','0.000007540000000','0.036091119979047','0.035572162698303','4717.793461313348','4717.793461313348416','test','test','0.78'),('2019-01-31 15:59:59','2019-01-31 19:59:59','TRXBTC','4h','0.000007530000000','0.000007490000000','0.035975796138882','0.035784689652088','4777.662169838218','4777.662169838217778','test','test','0.0'),('2019-02-01 23:59:59','2019-02-02 03:59:59','TRXBTC','4h','0.000007560000000','0.000007470000000','0.035933328030705','0.035505550316054','4753.085718347267','4753.085718347267175','test','test','0.92'),('2019-02-04 11:59:59','2019-02-05 23:59:59','TRXBTC','4h','0.000007880000000','0.000007550000000','0.035838266316338','0.034337425214258','4548.003339636858','4548.003339636858072','test','test','5.20'),('2019-02-06 07:59:59','2019-02-06 11:59:59','TRXBTC','4h','0.000007680000000','0.000007570000000','0.035504746071432','0.034996214552180','4623.013811384347','4623.013811384346809','test','test','1.82'),('2019-02-06 15:59:59','2019-02-06 19:59:59','TRXBTC','4h','0.000007560000000','0.000007520000000','0.035391739067154','0.035204481188492','4681.446966554704','4681.446966554703977','test','test','0.0'),('2019-02-07 03:59:59','2019-02-07 07:59:59','TRXBTC','4h','0.000007660000000','0.000007570000000','0.035350126205229','0.034934785296812','4614.898982405832','4614.898982405831703','test','test','1.82'),('2019-02-07 11:59:59','2019-02-07 15:59:59','TRXBTC','4h','0.000007580000000','0.000007550000000','0.035257828225580','0.035118285369806','4651.42852580217','4651.428525802170043','test','test','0.13'),('2019-02-07 19:59:59','2019-02-07 23:59:59','TRXBTC','4h','0.000007590000000','0.000007560000000','0.035226818702075','0.035087582264517','4641.214585253638','4641.214585253637779','test','test','0.52'),('2019-02-08 11:59:59','2019-02-08 15:59:59','TRXBTC','4h','0.000007580000000','0.000007590000000','0.035195877271507','0.035242309827274','4643.255576715919','4643.255576715919233','test','test','0.26'),('2019-03-23 11:59:59','2019-03-24 19:59:59','TRXBTC','4h','0.000005980000000','0.000005820000000','0.035206195617233','0.034264223828143','5887.323681811483','5887.323681811482857','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 03:59:59','TRXBTC','4h','0.000005820000000','0.000005730000000','0.034996868552990','0.034455679864026','6013.207655152997','6013.207655152997177','test','test','0.0'),('2019-03-27 15:59:59','2019-03-27 19:59:59','TRXBTC','4h','0.000005780000000','0.000005800000000','0.034876604399887','0.034997284691928','6034.014602056632','6034.014602056631702','test','test','0.86'),('2019-03-27 23:59:59','2019-03-28 03:59:59','TRXBTC','4h','0.000005770000000','0.000005710000000','0.034903422242563','0.034540475044200','6049.119972714578','6049.119972714577671','test','test','0.0'),('2019-03-28 23:59:59','2019-03-29 03:59:59','TRXBTC','4h','0.000005750000000','0.000005750000000','0.034822767309594','0.034822767309594','6056.1334451467055','6056.133445146705526','test','test','0.69'),('2019-03-29 07:59:59','2019-03-29 11:59:59','TRXBTC','4h','0.000005800000000','0.000005590000000','0.034822767309594','0.033561942975971','6003.925398205785','6003.925398205785314','test','test','0.86'),('2019-04-01 15:59:59','2019-04-02 07:59:59','TRXBTC','4h','0.000005810000000','0.000005620000000','0.034542584124344','0.033412964333703','5945.367319164199','5945.367319164199216','test','test','3.78'),('2019-04-07 23:59:59','2019-04-08 03:59:59','TRXBTC','4h','0.000005590000000','0.000005390000000','0.034291557504202','0.033064668148059','6134.446780715842','6134.446780715841669','test','test','0.0'),('2019-04-08 15:59:59','2019-04-10 19:59:59','TRXBTC','4h','0.000005960000000','0.000005650000000','0.034018915425059','0.032249475193219','5707.871715613869','5707.871715613869128','test','test','9.56'),('2019-04-10 23:59:59','2019-04-11 03:59:59','TRXBTC','4h','0.000005650000000','0.000005280000000','0.033625706484650','0.031423669068841','5951.452475159253','5951.452475159252572','test','test','0.53'),('2019-05-15 23:59:59','2019-05-16 07:59:59','TRXBTC','4h','0.000003790000000','0.000003830000000','0.033136364836692','0.033486089003834','8743.10417854676','8743.104178546760522','test','test','0.0'),('2019-05-16 15:59:59','2019-05-16 19:59:59','TRXBTC','4h','0.000003780000000','0.000003610000000','0.033214081318279','0.031720326338356','8786.793999544798','8786.793999544797771','test','test','0.0'),('2019-05-21 15:59:59','2019-05-21 19:59:59','TRXBTC','4h','0.000003650000000','0.000003610000000','0.032882135767185','0.032521783594394','9008.804319776802','9008.804319776802004','test','test','1.09'),('2019-05-26 11:59:59','2019-05-26 19:59:59','TRXBTC','4h','0.000003670000000','0.000003520000000','0.032802057506565','0.031461373957250','8937.890328764335','8937.890328764335209','test','test','1.63'),('2019-05-26 23:59:59','2019-05-27 03:59:59','TRXBTC','4h','0.000003570000000','0.000003600000000','0.032504127828940','0.032777271760276','9104.79771118755','9104.797711187549794','test','test','1.40'),('2019-05-27 07:59:59','2019-05-30 19:59:59','TRXBTC','4h','0.000003690000000','0.000003830000000','0.032564826480348','0.033800348352231','8825.156227736465','8825.156227736464643','test','test','2.43'),('2019-05-30 23:59:59','2019-05-31 07:59:59','TRXBTC','4h','0.000003750000000','0.000003790000000','0.032839386896322','0.033189673689883','8757.169839019081','8757.169839019081337','test','test','0.0'),('2019-05-31 11:59:59','2019-06-06 19:59:59','TRXBTC','4h','0.000003810000000','0.000004140000000','0.032917228406002','0.035768326929357','8639.692495013589','8639.692495013588996','test','test','1.31'),('2019-06-06 23:59:59','2019-06-08 03:59:59','TRXBTC','4h','0.000004180000000','0.000004110000000','0.033550805855636','0.032988950255183','8026.508577903403','8026.508577903403420','test','test','9.33'),('2019-06-08 07:59:59','2019-06-08 11:59:59','TRXBTC','4h','0.000004140000000','0.000004140000000','0.033425949055536','0.033425949055536','8073.900738052065','8073.900738052065208','test','test','7.48'),('2019-06-12 23:59:59','2019-06-13 11:59:59','TRXBTC','4h','0.000004120000000','0.000004070000000','0.033425949055536','0.033020294333988','8113.094430955231','8113.094430955230564','test','test','0.0'),('2019-06-13 15:59:59','2019-06-13 19:59:59','TRXBTC','4h','0.000004040000000','0.000003960000000','0.033335803561858','0.032675688639841','8251.43652521243','8251.436525212429842','test','test','0.0'),('2019-07-07 19:59:59','2019-07-08 11:59:59','TRXBTC','4h','0.000003040000000','0.000002820000000','0.033189111356966','0.030787267771922','10917.470841107088','10917.470841107087836','test','test','0.0'),('2019-07-19 19:59:59','2019-07-22 23:59:59','TRXBTC','4h','0.000002590000000','0.000002580000000','0.032655368338067','0.032529285834831','12608.25032357795','12608.250323577949530','test','test','0.0'),('2019-08-14 07:59:59','2019-08-14 11:59:59','TRXBTC','4h','0.000001910000000','0.000001900000000','0.032627350004014','0.032456526182003','17082.382201054683','17082.382201054682810','test','test','0.0'),('2019-08-22 19:59:59','2019-08-22 23:59:59','TRXBTC','4h','0.000001740000000','0.000001710000000','0.032589389154679','0.032027503134771','18729.53399694176','18729.533996941758232','test','test','0.0'),('2019-08-23 03:59:59','2019-08-23 15:59:59','TRXBTC','4h','0.000001770000000','0.000001730000000','0.032464525594699','0.031730863999339','18341.539884010796','18341.539884010795504','test','test','3.38'),('2019-08-23 19:59:59','2019-08-23 23:59:59','TRXBTC','4h','0.000001750000000','0.000001730000000','0.032301489684619','0.031932329802509','18457.994105496633','18457.994105496632983','test','test','1.14'),('2019-08-24 07:59:59','2019-08-24 11:59:59','TRXBTC','4h','0.000001740000000','0.000001780000000','0.032219454155261','0.032960131262278','18516.927675437542','18516.927675437542348','test','test','0.57'),('2019-08-24 15:59:59','2019-08-24 23:59:59','TRXBTC','4h','0.000001750000000','0.000001760000000','0.032384049067932','0.032569100776892','18505.170895961015','18505.170895961015049','test','test','0.0'),('2019-08-25 03:59:59','2019-08-25 15:59:59','TRXBTC','4h','0.000001790000000','0.000001750000000','0.032425171669923','0.031700586828137','18114.621044649655','18114.621044649655232','test','test','1.67'),('2019-08-25 19:59:59','2019-08-25 23:59:59','TRXBTC','4h','0.000001750000000','0.000001730000000','0.032264152816193','0.031895419641151','18436.658752110092','18436.658752110091882','test','test','0.0'),('2019-09-10 03:59:59','2019-09-10 15:59:59','TRXBTC','4h','0.000001540000000','0.000001540000000','0.032182212110628','0.032182212110628','20897.540331576474','20897.540331576474273','test','test','0.0'),('2019-09-10 19:59:59','2019-09-11 07:59:59','TRXBTC','4h','0.000001550000000','0.000001520000000','0.032182212110628','0.031559330585906','20762.717490727595','20762.717490727594850','test','test','1.29'),('2019-09-14 15:59:59','2019-09-14 19:59:59','TRXBTC','4h','0.000001520000000','0.000001530000000','0.032043793994023','0.032254608428194','21081.443417120317','21081.443417120317463','test','test','0.0'),('2019-09-14 23:59:59','2019-09-15 19:59:59','TRXBTC','4h','0.000001520000000','0.000001510000000','0.032090641646061','0.031879519003653','21112.264240829525','21112.264240829525079','test','test','0.0'),('2019-09-15 23:59:59','2019-09-16 03:59:59','TRXBTC','4h','0.000001500000000','0.000001530000000','0.032043725503304','0.032684600013370','21362.483668869034','21362.483668869033863','test','test','0.0'),('2019-09-16 07:59:59','2019-09-16 11:59:59','TRXBTC','4h','0.000001520000000','0.000001520000000','0.032186142061096','0.032186142061096','21175.093461247365','21175.093461247364758','test','test','0.65'),('2019-09-16 15:59:59','2019-09-22 19:59:59','TRXBTC','4h','0.000001520000000','0.000001660000000','0.032186142061096','0.035150655145671','21175.093461247365','21175.093461247364758','test','test','0.0'),('2019-09-22 23:59:59','2019-09-23 23:59:59','TRXBTC','4h','0.000001680000000','0.000001650000000','0.032844922746557','0.032258406268940','19550.549253903042','19550.549253903041972','test','test','8.92'),('2019-09-24 07:59:59','2019-09-24 11:59:59','TRXBTC','4h','0.000001660000000','0.000001640000000','0.032714585751531','0.032320434115970','19707.58177803079','19707.581778030791611','test','test','0.60'),('2019-09-27 07:59:59','2019-09-27 11:59:59','TRXBTC','4h','0.000001650000000','0.000001660000000','0.032626996499184','0.032824735871906','19773.93727223286','19773.937272232858959','test','test','0.60'),('2019-09-27 15:59:59','2019-09-29 07:59:59','TRXBTC','4h','0.000001650000000','0.000001630000000','0.032670938582011','0.032274927205259','19800.568837582625','19800.568837582624838','test','test','0.0'),('2019-09-29 15:59:59','2019-10-15 19:59:59','TRXBTC','4h','0.000001640000000','0.000001910000000','0.032582936053844','0.037947199916367','19867.643935270866','19867.643935270865768','test','test','0.60'),('2019-10-15 23:59:59','2019-10-16 11:59:59','TRXBTC','4h','0.000001910000000','0.000001910000000','0.033774994689960','0.033774994689960','17683.243293173007','17683.243293173007260','test','test','13.0'),('2019-10-17 23:59:59','2019-10-18 03:59:59','TRXBTC','4h','0.000001910000000','0.000001890000000','0.033774994689960','0.033421329824097','17683.243293173007','17683.243293173007260','test','test','9.42'),('2019-10-18 19:59:59','2019-10-20 07:59:59','TRXBTC','4h','0.000001940000000','0.000001900000000','0.033696402497546','0.033001631312030','17369.279637910535','17369.279637910534802','test','test','8.24'),('2019-10-20 11:59:59','2019-10-20 15:59:59','TRXBTC','4h','0.000001920000000','0.000001920000000','0.033542008900765','0.033542008900765','17469.796302481827','17469.796302481827297','test','test','1.04'),('2019-10-23 19:59:59','2019-10-25 15:59:59','TRXBTC','4h','0.000001910000000','0.000001950000000','0.033542008900765','0.034244459348949','17561.26120458906','17561.261204589060071','test','test','0.0'),('2019-10-25 19:59:59','2019-10-25 23:59:59','TRXBTC','4h','0.000001930000000','0.000002040000000','0.033698109000362','0.035618726611782','17460.160103814276','17460.160103814276226','test','test','0.51'),('2019-10-27 15:59:59','2019-11-04 07:59:59','TRXBTC','4h','0.000002060000000','0.000002080000000','0.034124912914010','0.034456222748127','16565.49170583031','16565.491705830310821','test','test','4.36'),('2019-11-04 11:59:59','2019-11-04 23:59:59','TRXBTC','4h','0.000002110000000','0.000002100000000','0.034198537321592','0.034036458945660','16207.837593171562','16207.837593171561821','test','test','3.31'),('2019-11-05 03:59:59','2019-11-05 07:59:59','TRXBTC','4h','0.000002120000000','0.000002110000000','0.034162519904718','0.034001375942903','16114.396181470855','16114.396181470854572','test','test','0.94'),('2019-11-05 11:59:59','2019-11-06 03:59:59','TRXBTC','4h','0.000002120000000','0.000002120000000','0.034126710135426','0.034126710135426','16097.504780861318','16097.504780861318068','test','test','0.47'),('2019-11-06 07:59:59','2019-11-07 11:59:59','TRXBTC','4h','0.000002130000000','0.000002110000000','0.034126710135426','0.033806271542605','16021.929641045068','16021.929641045067910','test','test','0.46'),('2019-11-07 15:59:59','2019-11-08 07:59:59','TRXBTC','4h','0.000002120000000','0.000002090000000','0.034055501559244','0.033573584084349','16063.915829831863','16063.915829831863448','test','test','0.47'),('2019-11-08 11:59:59','2019-11-08 15:59:59','TRXBTC','4h','0.000002130000000','0.000002110000000','0.033948408787045','0.033629644385289','15938.220087814394','15938.220087814393992','test','test','1.87'),('2019-11-08 19:59:59','2019-11-10 19:59:59','TRXBTC','4h','0.000002130000000','0.000002150000000','0.033877572253321','0.034195671523305','15904.963499211788','15904.963499211788076','test','test','0.93'),('2019-11-10 23:59:59','2019-11-11 03:59:59','TRXBTC','4h','0.000002140000000','0.000002130000000','0.033948260979984','0.033789624246433','15863.673355132814','15863.673355132814322','test','test','0.0'),('2019-11-11 07:59:59','2019-11-15 15:59:59','TRXBTC','4h','0.000002150000000','0.000002180000000','0.033913008372528','0.034386213140517','15773.492266292296','15773.492266292296335','test','test','0.93'),('2019-11-15 19:59:59','2019-11-15 23:59:59','TRXBTC','4h','0.000002180000000','0.000002200000000','0.034018164987637','0.034330258244404','15604.66283836565','15604.662838365649804','test','test','1.37'),('2019-11-16 03:59:59','2019-11-16 07:59:59','TRXBTC','4h','0.000002200000000','0.000002200000000','0.034087519044696','0.034087519044696','15494.326838498384','15494.326838498383950','test','test','0.0'),('2019-11-16 11:59:59','2019-11-16 15:59:59','TRXBTC','4h','0.000002190000000','0.000002190000000','0.034087519044696','0.034087519044696','15565.077189359106','15565.077189359106342','test','test','0.0'),('2019-11-16 19:59:59','2019-11-17 07:59:59','TRXBTC','4h','0.000002210000000','0.000002180000000','0.034087519044696','0.033624792541827','15424.216762306083','15424.216762306083183','test','test','0.90'),('2019-11-17 11:59:59','2019-11-17 15:59:59','TRXBTC','4h','0.000002200000000','0.000002180000000','0.033984690932948','0.033675739197194','15447.586787703536','15447.586787703536174','test','test','0.90'),('2019-11-17 19:59:59','2019-11-18 07:59:59','TRXBTC','4h','0.000002200000000','0.000002180000000','0.033916034991669','0.033607707400836','15416.379541667779','15416.379541667778540','test','test','0.90'),('2019-11-26 15:59:59','2019-11-29 15:59:59','TRXBTC','4h','0.000002130000000','0.000002090000000','0.033847517749262','0.033211883613126','15890.853403409286','15890.853403409286329','test','test','0.0'),('2019-11-29 19:59:59','2019-11-29 23:59:59','TRXBTC','4h','0.000002090000000','0.000002090000000','0.033706265719009','0.033706265719009','16127.399865554704','16127.399865554703865','test','test','0.0'),('2019-12-01 07:59:59','2019-12-01 11:59:59','TRXBTC','4h','0.000002100000000','0.000002100000000','0.033706265719009','0.033706265719009','16050.602723337777','16050.602723337777206','test','test','0.47'),('2019-12-01 15:59:59','2019-12-02 19:59:59','TRXBTC','4h','0.000002150000000','0.000002080000000','0.033706265719009','0.032608852416530','15677.332892562477','15677.332892562477355','test','test','2.32'),('2019-12-03 07:59:59','2019-12-03 11:59:59','TRXBTC','4h','0.000002100000000','0.000002090000000','0.033462396096236','0.033303051352921','15934.474331541061','15934.474331541061474','test','test','0.95'),('2019-12-03 15:59:59','2019-12-03 19:59:59','TRXBTC','4h','0.000002100000000','0.000002100000000','0.033426986153277','0.033426986153277','15917.612453941589','15917.612453941588683','test','test','0.47'),('2019-12-14 03:59:59','2019-12-14 11:59:59','TRXBTC','4h','0.000001990000000','0.000001980000000','0.033426986153277','0.033259011348487','16797.480479033835','16797.480479033834854','test','test','0.0'),('2019-12-14 15:59:59','2019-12-14 19:59:59','TRXBTC','4h','0.000001970000000','0.000001970000000','0.033389658418880','0.033389658418880','16949.065187248503','16949.065187248503207','test','test','0.0'),('2019-12-15 03:59:59','2019-12-15 07:59:59','TRXBTC','4h','0.000001980000000','0.000001970000000','0.033389658418880','0.033221023780401','16863.463847918963','16863.463847918963438','test','test','0.50'),('2019-12-15 11:59:59','2019-12-15 15:59:59','TRXBTC','4h','0.000001980000000','0.000001960000000','0.033352184054773','0.033015293306745','16844.537401400565','16844.537401400564704','test','test','0.50'),('2019-12-22 03:59:59','2019-12-23 07:59:59','TRXBTC','4h','0.000001950000000','0.000001920000000','0.033277319444100','0.032765360683422','17065.2920226155','17065.292022615500173','test','test','0.0'),('2019-12-23 11:59:59','2019-12-23 15:59:59','TRXBTC','4h','0.000001920000000','0.000001870000000','0.033163550830616','0.032299916694402','17272.682724279282','17272.682724279282411','test','test','0.0'),('2019-12-30 07:59:59','2019-12-30 11:59:59','TRXBTC','4h','0.000001890000000','0.000001870000000','0.032971632133680','0.032622725973535','17445.308007237978','17445.308007237978018','test','test','1.05');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 22:34:41
