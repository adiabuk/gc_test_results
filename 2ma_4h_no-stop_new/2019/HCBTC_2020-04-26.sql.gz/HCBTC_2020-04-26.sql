-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-07 15:59:59','2019-02-07 19:59:59','HCBTC','4h','0.000271400000000','0.000266900000000','0.033333333333333','0.032780643576516','122.81994595922379','122.819945959223787','test','test','0.0'),('2019-02-08 11:59:59','2019-02-14 11:59:59','HCBTC','4h','0.000312900000000','0.000300500000000','0.033210513387374','0.031894404835110','106.13778647291146','106.137786472911458','test','test','14.7'),('2019-02-14 15:59:59','2019-02-14 23:59:59','HCBTC','4h','0.000304400000000','0.000303500000000','0.032918044820204','0.032820718143666','108.14075170894948','108.140751708949480','test','test','1.28'),('2019-02-15 03:59:59','2019-02-16 19:59:59','HCBTC','4h','0.000303000000000','0.000307400000000','0.032896416669862','0.033374120410282','108.56903191373746','108.569031913737462','test','test','0.0'),('2019-02-16 23:59:59','2019-02-17 03:59:59','HCBTC','4h','0.000305600000000','0.000311100000000','0.033002573056622','0.033596532977471','107.99271288161795','107.992712881617948','test','test','0.68'),('2019-02-17 07:59:59','2019-02-18 15:59:59','HCBTC','4h','0.000310200000000','0.000306200000000','0.033134564150144','0.032707297043114','106.81677675739668','106.816776757396681','test','test','0.0'),('2019-02-19 11:59:59','2019-02-19 15:59:59','HCBTC','4h','0.000307200000000','0.000304300000000','0.033039615904138','0.032727718488376','107.55083302128185','107.550833021281846','test','test','0.32'),('2019-02-19 19:59:59','2019-02-19 23:59:59','HCBTC','4h','0.000306700000000','0.000302900000000','0.032970305367302','0.032561804681303','107.50018052592691','107.500180525926908','test','test','0.78'),('2019-02-24 11:59:59','2019-02-24 15:59:59','HCBTC','4h','0.000301700000000','0.000294300000000','0.032879527437080','0.032073069024636','108.98086654650241','108.980866546502412','test','test','0.0'),('2019-02-26 15:59:59','2019-02-27 03:59:59','HCBTC','4h','0.000304200000000','0.000303000000000','0.032700314456537','0.032571319133237','107.49610274995618','107.496102749956179','test','test','3.25'),('2019-02-27 07:59:59','2019-02-27 15:59:59','HCBTC','4h','0.000301900000000','0.000298300000000','0.032671648829137','0.032282056461516','108.22010211704757','108.220102117047574','test','test','0.0'),('2019-02-28 03:59:59','2019-02-28 07:59:59','HCBTC','4h','0.000299900000000','0.000299200000000','0.032585072747443','0.032509015558636','108.6531268670994','108.653126867099402','test','test','0.53'),('2019-03-01 03:59:59','2019-03-01 07:59:59','HCBTC','4h','0.000299500000000','0.000299500000000','0.032568171149930','0.032568171149930','108.74180684450899','108.741806844508986','test','test','0.10'),('2019-03-01 11:59:59','2019-03-02 03:59:59','HCBTC','4h','0.000301400000000','0.000299200000000','0.032568171149930','0.032330447272923','108.05630773035979','108.056307730359791','test','test','0.63'),('2019-03-02 07:59:59','2019-03-02 11:59:59','HCBTC','4h','0.000298600000000','0.000299400000000','0.032515343621707','0.032602457737237','108.89264441294932','108.892644412949323','test','test','0.0'),('2019-03-02 15:59:59','2019-03-02 19:59:59','HCBTC','4h','0.000299300000000','0.000298500000000','0.032534702314047','0.032447740196268','108.70264722367747','108.702647223677474','test','test','0.03'),('2019-03-02 23:59:59','2019-03-03 03:59:59','HCBTC','4h','0.000300700000000','0.000298300000000','0.032515377398985','0.032255859920576','108.13228267038467','108.132282670384669','test','test','0.73'),('2019-03-07 07:59:59','2019-03-07 15:59:59','HCBTC','4h','0.000298500000000','0.000295200000000','0.032457706848227','0.032098877928297','108.73603634246938','108.736036342469376','test','test','0.70'),('2019-03-08 11:59:59','2019-03-20 07:59:59','HCBTC','4h','0.000304500000000','0.000326600000000','0.032377967088243','0.034727895077242','106.33158321261959','106.331583212619591','test','test','3.05'),('2019-03-20 11:59:59','2019-03-20 15:59:59','HCBTC','4h','0.000327500000000','0.000325700000000','0.032900173308020','0.032719347928006','100.45854445197014','100.458544451970141','test','test','8.91'),('2019-03-21 03:59:59','2019-03-21 15:59:59','HCBTC','4h','0.000331900000000','0.000322900000000','0.032859989890239','0.031968938642839','99.00569415558705','99.005694155587051','test','test','8.73'),('2019-03-22 19:59:59','2019-03-22 23:59:59','HCBTC','4h','0.000328000000000','0.000328100000000','0.032661978501928','0.032671936422203','99.57920274978116','99.579202749781160','test','test','5.15'),('2019-03-23 03:59:59','2019-03-26 07:59:59','HCBTC','4h','0.000331900000000','0.000330400000000','0.032664191373100','0.032516567730257','98.41576189545177','98.415761895451766','test','test','1.14'),('2019-03-26 19:59:59','2019-03-28 15:59:59','HCBTC','4h','0.000338000000000','0.000338200000000','0.032631386119135','0.032650694631632','96.54256248264892','96.542562482648918','test','test','2.24'),('2019-03-28 19:59:59','2019-03-29 07:59:59','HCBTC','4h','0.000341500000000','0.000338700000000','0.032635676899690','0.032368093018814','95.5656717414062','95.565671741406206','test','test','0.96'),('2019-03-29 11:59:59','2019-03-29 15:59:59','HCBTC','4h','0.000337000000000','0.000336600000000','0.032576213815051','0.032537547685894','96.66532289332673','96.665322893326731','test','test','0.0'),('2019-03-29 23:59:59','2019-03-30 07:59:59','HCBTC','4h','0.000340600000000','0.000338100000000','0.032567621341905','0.032328575383729','95.61838327042018','95.618383270420182','test','test','1.17'),('2019-03-30 23:59:59','2019-03-31 03:59:59','HCBTC','4h','0.000338800000000','0.000336300000000','0.032514500017866','0.032274576021276','95.96959863596813','95.969598635968126','test','test','0.20'),('2019-03-31 07:59:59','2019-03-31 11:59:59','HCBTC','4h','0.000338000000000','0.000338900000000','0.032461183574179','0.032547618678371','96.03900465733531','96.039004657335312','test','test','0.50'),('2019-03-31 15:59:59','2019-04-02 03:59:59','HCBTC','4h','0.000343400000000','0.000340500000000','0.032480391375111','0.032206095699549','94.58471571086456','94.584715710864558','test','test','1.36'),('2019-05-16 03:59:59','2019-05-16 07:59:59','HCBTC','4h','0.000176500000000','0.000173900000000','0.032419436780542','0.031941870006438','183.67952850165187','183.679528501651873','test','test','0.0'),('2019-05-16 19:59:59','2019-05-16 23:59:59','HCBTC','4h','0.000177300000000','0.000171100000000','0.032313310830741','0.031183347338634','182.25217614630944','182.252176146309438','test','test','1.91'),('2019-05-17 03:59:59','2019-05-17 07:59:59','HCBTC','4h','0.000173900000000','0.000173000000000','0.032062207832495','0.031896273461884','184.37152290106187','184.371522901061866','test','test','1.61'),('2019-05-17 11:59:59','2019-05-17 15:59:59','HCBTC','4h','0.000174100000000','0.000171600000000','0.032025333527914','0.031565463718495','183.94792376745804','183.947923767458036','test','test','0.63'),('2019-05-18 11:59:59','2019-05-18 15:59:59','HCBTC','4h','0.000174100000000','0.000172300000000','0.031923140236932','0.031593090538905','183.36094334826214','183.360943348262140','test','test','1.43'),('2019-05-30 03:59:59','2019-06-22 03:59:59','HCBTC','4h','0.000164800000000','0.000310900000000','0.031849795859593','0.060085567553079','193.2633243907349','193.263324390734908','test','test','0.0'),('2019-06-22 07:59:59','2019-06-22 11:59:59','HCBTC','4h','0.000317100000000','0.000313200000000','0.038124411791479','0.037655521201801','120.2283563275903','120.228356327590305','test','test','48.2'),('2019-06-22 15:59:59','2019-06-26 19:59:59','HCBTC','4h','0.000335400000000','0.000362800000000','0.038020213882662','0.041126218236821','113.35782314448883','113.357823144488833','test','test','48.6'),('2019-06-26 23:59:59','2019-07-01 11:59:59','HCBTC','4h','0.000420700000000','0.000392600000000','0.038710437072475','0.036124833835640','92.01435006530703','92.014350065307028','test','test','19.0'),('2019-07-01 15:59:59','2019-07-02 07:59:59','HCBTC','4h','0.000405700000000','0.000412600000000','0.038135858575400','0.038784459571629','94.00014438107029','94.000144381070285','test','test','3.22'),('2019-07-02 11:59:59','2019-07-03 07:59:59','HCBTC','4h','0.000415300000000','0.000400200000000','0.038279992130118','0.036888160005955','92.1743128584584','92.174312858458407','test','test','2.48'),('2019-07-03 19:59:59','2019-07-08 07:59:59','HCBTC','4h','0.000409100000000','0.000417900000000','0.037970696102526','0.038787469814827','92.81519457962843','92.815194579628425','test','test','2.17'),('2019-07-24 15:59:59','2019-07-25 11:59:59','HCBTC','4h','0.000318900000000','0.000307900000000','0.038152201371926','0.036836195680201','119.6368810659336','119.636881065933594','test','test','0.0'),('2019-07-26 11:59:59','2019-07-26 19:59:59','HCBTC','4h','0.000313200000000','0.000309500000000','0.037859755662654','0.037412498012744','120.88044592162835','120.880445921628350','test','test','1.69'),('2019-07-26 23:59:59','2019-07-27 03:59:59','HCBTC','4h','0.000311500000000','0.000309500000000','0.037760365073785','0.037517922922428','121.22107567828286','121.221075678282858','test','test','0.64'),('2019-08-17 15:59:59','2019-08-24 03:59:59','HCBTC','4h','0.000234000000000','0.000245400000000','0.037706489040150','0.039543471839542','161.13884205192403','161.138842051924030','test','test','0.0'),('2019-08-24 07:59:59','2019-08-24 11:59:59','HCBTC','4h','0.000247500000000','0.000241400000000','0.038114707440015','0.037175314650584','153.998817939455','153.998817939454995','test','test','0.84'),('2019-08-24 15:59:59','2019-08-24 19:59:59','HCBTC','4h','0.000246500000000','0.000245800000000','0.037905953486808','0.037798309805507','153.7766875732585','153.776687573258499','test','test','2.06'),('2019-08-25 03:59:59','2019-08-25 07:59:59','HCBTC','4h','0.000247800000000','0.000243000000000','0.037882032668741','0.037148240268378','152.87341674229754','152.873416742297536','test','test','0.80'),('2019-08-25 11:59:59','2019-08-25 15:59:59','HCBTC','4h','0.000251200000000','0.000245600000000','0.037718967690883','0.036878098984398','150.15512615797329','150.155126157973285','test','test','3.26'),('2019-08-28 19:59:59','2019-08-28 23:59:59','HCBTC','4h','0.000238700000000','0.000233400000000','0.037532107978331','0.036698759958703','157.23547540146905','157.235475401469046','test','test','0.0'),('2019-09-08 07:59:59','2019-09-08 15:59:59','HCBTC','4h','0.000220700000000','0.000214600000000','0.037346919529524','0.036314675718332','169.22029691673964','169.220296916739642','test','test','0.0'),('2019-09-08 19:59:59','2019-09-09 03:59:59','HCBTC','4h','0.000212300000000','0.000208100000000','0.037117532015926','0.036383223798936','174.83528975942636','174.835289759426360','test','test','0.32'),('2019-09-09 07:59:59','2019-09-09 11:59:59','HCBTC','4h','0.000209000000000','0.000210600000000','0.036954352412151','0.037237256545450','176.81508331172566','176.815083311725658','test','test','0.43'),('2019-09-09 15:59:59','2019-09-09 19:59:59','HCBTC','4h','0.000209900000000','0.000210300000000','0.037017219997328','0.037087762579505','176.3564554422497','176.356455442249711','test','test','0.0'),('2019-09-09 23:59:59','2019-09-10 03:59:59','HCBTC','4h','0.000211700000000','0.000212800000000','0.037032896126701','0.037225320244506','174.93101618658898','174.931016186588977','test','test','0.66'),('2019-09-10 07:59:59','2019-09-10 11:59:59','HCBTC','4h','0.000211400000000','0.000209900000000','0.037075657041769','0.036812584735418','175.38153756749605','175.381537567496053','test','test','0.37'),('2019-09-10 15:59:59','2019-09-10 19:59:59','HCBTC','4h','0.000211200000000','0.000211800000000','0.037017196529246','0.037122359019386','175.27081689984004','175.270816899840042','test','test','0.61'),('2019-09-10 23:59:59','2019-09-11 03:59:59','HCBTC','4h','0.000209400000000','0.000209600000000','0.037040565971500','0.037075943780451','176.8890447540571','176.889044754057096','test','test','0.0'),('2019-09-11 07:59:59','2019-09-11 11:59:59','HCBTC','4h','0.000209100000000','0.000209900000000','0.037048427706822','0.037190172050033','177.1804290139742','177.180429013974191','test','test','0.0'),('2019-09-14 19:59:59','2019-09-14 23:59:59','HCBTC','4h','0.000208200000000','0.000208000000000','0.037079926449758','0.037044306923870','178.09762944168','178.097629441679999','test','test','0.0'),('2019-09-15 03:59:59','2019-09-16 15:59:59','HCBTC','4h','0.000209800000000','0.000209200000000','0.037072010999560','0.036965989995748','176.7016730198305','176.701673019830508','test','test','0.85'),('2019-09-17 15:59:59','2019-09-19 23:59:59','HCBTC','4h','0.000212600000000','0.000212200000000','0.037048450776491','0.036978745318774','174.263644292056','174.263644292056000','test','test','1.64'),('2019-09-20 03:59:59','2019-09-20 11:59:59','HCBTC','4h','0.000211200000000','0.000211400000000','0.037032960674776','0.037068029766324','175.3454577404177','175.345457740417686','test','test','0.94'),('2019-09-21 03:59:59','2019-09-21 07:59:59','HCBTC','4h','0.000211400000000','0.000211000000000','0.037040753806231','0.036970667233277','175.21643238520022','175.216432385200221','test','test','0.85'),('2019-09-21 11:59:59','2019-09-22 07:59:59','HCBTC','4h','0.000211700000000','0.000211400000000','0.037025179012242','0.036972710643306','174.89456311876026','174.894563118760260','test','test','0.33'),('2019-09-30 19:59:59','2019-09-30 23:59:59','HCBTC','4h','0.000201400000000','0.000199600000000','0.037013519374700','0.036682713342553','183.78112897070616','183.781128970706163','test','test','0.0'),('2019-10-01 03:59:59','2019-10-01 07:59:59','HCBTC','4h','0.000201400000000','0.000197100000000','0.036940006923112','0.036151317599530','183.41612176321746','183.416121763217461','test','test','0.89'),('2019-10-03 11:59:59','2019-10-03 15:59:59','HCBTC','4h','0.000200100000000','0.000199600000000','0.036764742628983','0.036672876705372','183.73184722130264','183.731847221302644','test','test','1.49'),('2019-10-03 19:59:59','2019-10-03 23:59:59','HCBTC','4h','0.000202500000000','0.000200100000000','0.036744327979291','0.036308839647685','181.4534715026732','181.453471502673210','test','test','1.43'),('2019-10-07 03:59:59','2019-10-07 07:59:59','HCBTC','4h','0.000202400000000','0.000197900000000','0.036647552794490','0.035832760365759','181.06498416249994','181.064984162499940','test','test','1.13'),('2019-10-27 15:59:59','2019-10-30 07:59:59','HCBTC','4h','0.000188700000000','0.000187200000000','0.036466487810328','0.036176611118672','193.2511277706812','193.251127770681194','test','test','0.0'),('2019-10-30 11:59:59','2019-11-10 19:59:59','HCBTC','4h','0.000183700000000','0.000208300000000','0.036402070767737','0.041276817315839','198.16042878463435','198.160428784634348','test','test','0.0'),('2019-11-10 23:59:59','2019-11-11 03:59:59','HCBTC','4h','0.000210600000000','0.000211600000000','0.037485347778427','0.037663340882788','177.9931043610003','177.993104361000292','test','test','13.6'),('2019-11-11 07:59:59','2019-11-15 15:59:59','HCBTC','4h','0.000212300000000','0.000202400000000','0.037524901801618','0.035775035914496','176.75413001233156','176.754130012331558','test','test','12.4'),('2019-12-13 11:59:59','2019-12-13 15:59:59','HCBTC','4h','0.000165000000000','0.000169700000000','0.037136042715591','0.038193857265671','225.06692554903563','225.066925549035631','test','test','0.0'),('2019-12-13 19:59:59','2019-12-14 07:59:59','HCBTC','4h','0.000165400000000','0.000164800000000','0.037371112615609','0.037235546306242','225.9438489456388','225.943848945638791','test','test','0.0'),('2019-12-14 23:59:59','2019-12-15 03:59:59','HCBTC','4h','0.000164400000000','0.000165700000000','0.037340986769083','0.037636262211904','227.13495601631786','227.134956016317858','test','test','0.0'),('2019-12-15 07:59:59','2019-12-15 11:59:59','HCBTC','4h','0.000165800000000','0.000164800000000','0.037406603534154','0.037180990726348','225.61280780551266','225.612807805512659','test','test','0.60'),('2019-12-15 15:59:59','2019-12-15 19:59:59','HCBTC','4h','0.000164400000000','0.000162800000000','0.037356467354642','0.036992900762383','227.2291201620532','227.229120162053192','test','test','0.0'),('2019-12-16 15:59:59','2019-12-16 19:59:59','HCBTC','4h','0.000165900000000','0.000162000000000','0.037275674778584','0.036399393093012','224.68761168525614','224.687611685256144','test','test','1.86'),('2019-12-31 11:59:59','2019-12-31 15:59:59','HCBTC','4h','0.000153700000000','0.000152600000000','0.037080945515124','0.036815564642862','241.25533841980192','241.255338419801916','test','test','0.0'),('2019-12-31 19:59:59','2019-12-31 23:59:59','HCBTC','4h','0.000154200000000','0.000152800000000','0.037021971987954','0.036685845134626','240.0906095198068','240.090609519806804','test','test','1.03'),('2020-01-01 15:59:59','2020-01-01 19:59:59','HCBTC','4h','0.000153700000000','0.000153700000000','0.036947277131659','0.036947277131659','240.38566774013734','240.385667740137336','test','test','0.58'),('2020-01-06 15:59:59','2020-01-06 19:59:59','HCBTC','4h','0.000150900000000','0.000149800000000','0.036947277131659','0.036677946416982','244.84610425221408','244.846104252214076','test','test','0.0'),('2020-01-07 03:59:59','2020-01-07 07:59:59','HCBTC','4h','0.000150600000000','0.000150300000000','0.036887425861731','0.036813944933720','244.93642670472033','244.936426704720333','test','test','0.53'),('2020-01-07 11:59:59','2020-01-07 23:59:59','HCBTC','4h','0.000154900000000','0.000150100000000','0.036871096766617','0.035728545026916','238.03161243781358','238.031612437813578','test','test','2.96'),('2020-01-10 23:59:59','2020-01-11 03:59:59','HCBTC','4h','0.000148900000000','0.000147300000000','0.036617196380017','0.036223727513610','245.91804150448024','245.918041504480243','test','test','0.0'),('2020-01-11 07:59:59','2020-01-11 11:59:59','HCBTC','4h','0.000149200000000','0.000148100000000','0.036529758854149','0.036260437575734','244.83752583209704','244.837525832097043','test','test','1.27'),('2020-01-11 15:59:59','2020-01-12 15:59:59','HCBTC','4h','0.000151400000000','0.000151600000000','0.036469909681168','0.036518086576388','240.8844760975414','240.884476097541409','test','test','2.17'),('2020-01-12 19:59:59','2020-01-13 03:59:59','HCBTC','4h','0.000150100000000','0.000148800000000','0.036480615657883','0.036164660958648','243.0420763349989','243.042076334998910','test','test','0.0'),('2020-01-14 15:59:59','2020-01-14 19:59:59','HCBTC','4h','0.000150400000000','0.000154700000000','0.036410403502498','0.037451392432423','242.09044881979898','242.090448819798979','test','test','1.06'),('2020-01-14 23:59:59','2020-01-16 03:59:59','HCBTC','4h','0.000155800000000','0.000162000000000','0.036641734375814','0.038099877849049','235.1844311669733','235.184431166973297','test','test','1.34'),('2020-01-16 07:59:59','2020-01-20 07:59:59','HCBTC','4h','0.000163300000000','0.000164000000000','0.036965766258756','0.037124223309467','226.36721530162612','226.367215301626118','test','test','0.79'),('2020-01-20 11:59:59','2020-01-20 15:59:59','HCBTC','4h','0.000162000000000','0.000165800000000','0.037000978936691','0.037868903133971','228.40110454747736','228.401104547477360','test','test','0.0'),('2020-01-20 19:59:59','2020-01-21 19:59:59','HCBTC','4h','0.000164800000000','0.000161800000000','0.037193850980531','0.036516778450546','225.69084332846683','225.690843328466826','test','test','0.48'),('2020-01-21 23:59:59','2020-01-23 07:59:59','HCBTC','4h','0.000162300000000','0.000162800000000','0.037043390418312','0.037157510536668','228.24023671172174','228.240236711721735','test','test','0.30'),('2020-01-23 19:59:59','2020-01-23 23:59:59','HCBTC','4h','0.000164100000000','0.000164500000000','0.037068750444614','0.037159106935643','225.891227572296','225.891227572296003','test','test','0.79'),('2020-01-24 15:59:59','2020-01-24 19:59:59','HCBTC','4h','0.000163700000000','0.000162400000000','0.037088829664842','0.036794294059684','226.56585012121218','226.565850121212179','test','test','0.0'),('2020-01-24 23:59:59','2020-01-25 23:59:59','HCBTC','4h','0.000163600000000','0.000164400000000','0.037023377308141','0.037204420717961','226.30426227469843','226.304262274698431','test','test','0.73'),('2020-01-26 03:59:59','2020-01-26 07:59:59','HCBTC','4h','0.000163800000000','0.000164500000000','0.037063609176990','0.037222000669199','226.2735602990815','226.273560299081510','test','test','0.0'),('2020-01-26 11:59:59','2020-01-28 23:59:59','HCBTC','4h','0.000164400000000','0.000163900000000','0.037098807286369','0.036985976363965','225.6618448075993','225.661844807599294','test','test','0.0'),('2020-01-29 07:59:59','2020-01-29 11:59:59','HCBTC','4h','0.000167100000000','0.000164700000000','0.037073733748057','0.036541256423130','221.86555205300613','221.865552053006127','test','test','1.91'),('2020-01-29 19:59:59','2020-01-30 03:59:59','HCBTC','4h','0.000167200000000','0.000165100000000','0.036955405453629','0.036491252633936','221.0251522346238','221.025152234623789','test','test','1.61'),('2020-01-30 11:59:59','2020-02-04 15:59:59','HCBTC','4h','0.000166400000000','0.000184000000000','0.036852260382586','0.040750095615360','221.46791095304218','221.467910953042178','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 21:03:11
