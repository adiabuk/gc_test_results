-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 23:59:59','2019-01-04 03:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.033333333333333','0.033333333333333','15948.96331738437','15948.963317384370384','test','test','0.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.033333333333333','0.033333333333333','15948.96331738437','15948.963317384370384','test','test','0.0'),('2019-01-04 23:59:59','2019-01-05 03:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.033333333333333','0.033333333333333','15948.96331738437','15948.963317384370384','test','test','0.0'),('2019-01-05 07:59:59','2019-01-05 11:59:59','LENDBTC','4h','0.000002090000000','0.000002080000000','0.033333333333333','0.033173843700159','15948.96331738437','15948.963317384370384','test','test','0.0'),('2019-01-05 15:59:59','2019-01-05 19:59:59','LENDBTC','4h','0.000002090000000','0.000002080000000','0.033297891192628','0.033138571139075','15932.005355324403','15932.005355324403354','test','test','0.47'),('2019-01-06 11:59:59','2019-01-06 15:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.033262486736283','0.033262486736283','15915.065424058796','15915.065424058795543','test','test','0.47'),('2019-01-07 03:59:59','2019-01-07 07:59:59','LENDBTC','4h','0.000002090000000','0.000002070000000','0.033262486736283','0.032944185427802','15915.065424058796','15915.065424058795543','test','test','0.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','LENDBTC','4h','0.000002110000000','0.000002080000000','0.033191753112176','0.032719832451813','15730.688678756398','15730.688678756398076','test','test','1.89'),('2019-01-09 19:59:59','2019-01-09 23:59:59','LENDBTC','4h','0.000002080000000','0.000002070000000','0.033086881854318','0.032927810306941','15907.15473765267','15907.154737652670519','test','test','0.0'),('2019-01-13 11:59:59','2019-01-13 19:59:59','LENDBTC','4h','0.000002080000000','0.000002060000000','0.033051532621567','0.032733729423283','15890.159914214957','15890.159914214957098','test','test','0.48'),('2019-01-13 23:59:59','2019-01-20 11:59:59','LENDBTC','4h','0.000002100000000','0.000002220000000','0.032980909688615','0.034865533099393','15705.195089816722','15705.195089816721520','test','test','1.90'),('2019-01-20 15:59:59','2019-01-20 19:59:59','LENDBTC','4h','0.000002240000000','0.000002230000000','0.033399714891010','0.033250609020961','14910.587004915276','14910.587004915276339','test','test','0.89'),('2019-01-20 23:59:59','2019-01-23 23:59:59','LENDBTC','4h','0.000002260000000','0.000002290000000','0.033366580253222','0.033809499460123','14763.97356337237','14763.973563372370336','test','test','1.32'),('2019-01-24 03:59:59','2019-01-24 07:59:59','LENDBTC','4h','0.000002270000000','0.000002290000000','0.033465006743644','0.033759852618037','14742.29371966696','14742.293719666960897','test','test','0.0'),('2019-01-24 11:59:59','2019-01-27 15:59:59','LENDBTC','4h','0.000002310000000','0.000002280000000','0.033530528049065','0.033095066645830','14515.380107820203','14515.380107820203193','test','test','1.29'),('2019-02-02 19:59:59','2019-02-03 03:59:59','LENDBTC','4h','0.000002290000000','0.000002180000000','0.033433758848346','0.031827770432050','14599.894693600778','14599.894693600777828','test','test','1.31'),('2019-02-09 19:59:59','2019-02-10 03:59:59','LENDBTC','4h','0.000002170000000','0.000002130000000','0.033076872533613','0.032467160597510','15242.79840258679','15242.798402586789962','test','test','0.0'),('2019-02-15 07:59:59','2019-02-15 11:59:59','LENDBTC','4h','0.000002110000000','0.000002120000000','0.032941380992257','0.033097501281320','15612.028906282989','15612.028906282988828','test','test','0.0'),('2019-02-18 03:59:59','2019-02-18 07:59:59','LENDBTC','4h','0.000002090000000','0.000002080000000','0.032976074389827','0.032818294129589','15778.026023840514','15778.026023840513517','test','test','0.0'),('2019-02-18 11:59:59','2019-02-18 15:59:59','LENDBTC','4h','0.000002100000000','0.000002070000000','0.032941012109774','0.032470426222492','15686.19624274942','15686.196242749419980','test','test','0.95'),('2019-02-21 23:59:59','2019-02-23 03:59:59','LENDBTC','4h','0.000002190000000','0.000002070000000','0.032836437468156','0.031037180620586','14993.807063084729','14993.807063084728725','test','test','5.47'),('2019-02-23 07:59:59','2019-02-23 11:59:59','LENDBTC','4h','0.000002080000000','0.000002060000000','0.032436602613140','0.032124712203398','15594.520487086538','15594.520487086538196','test','test','0.48'),('2019-02-23 15:59:59','2019-02-23 19:59:59','LENDBTC','4h','0.000002060000000','0.000002030000000','0.032367293633197','0.031895925279315','15712.278462717151','15712.278462717151342','test','test','0.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','LENDBTC','4h','0.000002070000000','0.000002020000000','0.032262545110112','0.031483256580882','15585.770584595382','15585.770584595382388','test','test','1.93'),('2019-03-02 03:59:59','2019-03-02 07:59:59','LENDBTC','4h','0.000002050000000','0.000002020000000','0.032089369881395','0.031619769346545','15653.351161655939','15653.351161655938995','test','test','1.46'),('2019-03-02 11:59:59','2019-03-07 07:59:59','LENDBTC','4h','0.000002050000000','0.000002170000000','0.031985014206984','0.033857307721539','15602.445954626126','15602.445954626125967','test','test','1.46'),('2019-03-07 11:59:59','2019-03-07 15:59:59','LENDBTC','4h','0.000002160000000','0.000002230000000','0.032401079432440','0.033451114414047','15000.499737240847','15000.499737240847026','test','test','1.85'),('2019-03-07 19:59:59','2019-03-07 23:59:59','LENDBTC','4h','0.000002200000000','0.000002180000000','0.032634420539464','0.032337743989105','14833.827517938184','14833.827517938183519','test','test','3.18'),('2019-03-08 03:59:59','2019-03-11 19:59:59','LENDBTC','4h','0.000002260000000','0.000002250000000','0.032568492417162','0.032424384043635','14410.837352726554','14410.837352726553945','test','test','3.53'),('2019-03-11 23:59:59','2019-03-12 11:59:59','LENDBTC','4h','0.000002290000000','0.000002340000000','0.032536468334156','0.033246871572893','14208.064774740611','14208.064774740611028','test','test','2.18'),('2019-03-12 15:59:59','2019-03-16 23:59:59','LENDBTC','4h','0.000002370000000','0.000002340000000','0.032694335720542','0.032280483369649','13795.07836309789','13795.078363097889451','test','test','5.06'),('2019-03-17 11:59:59','2019-03-17 15:59:59','LENDBTC','4h','0.000002330000000','0.000002310000000','0.032602368531455','0.032322519874533','13992.432846117885','13992.432846117884765','test','test','2.14'),('2019-03-26 23:59:59','2019-03-27 03:59:59','LENDBTC','4h','0.000002240000000','0.000002260000000','0.032540179941028','0.032830717261930','14526.866045101588','14526.866045101587588','test','test','0.0'),('2019-03-27 07:59:59','2019-04-02 07:59:59','LENDBTC','4h','0.000002270000000','0.000002310000000','0.032604743790117','0.033179276720339','14363.323255558103','14363.323255558103483','test','test','0.44'),('2019-04-05 15:59:59','2019-04-06 11:59:59','LENDBTC','4h','0.000002390000000','0.000002310000000','0.032732417774611','0.031636771991360','13695.57229063208','13695.572290632080694','test','test','4.18'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDBTC','4h','0.000002370000000','0.000002280000000','0.032488940933888','0.031255183683234','13708.41389615537','13708.413896155370821','test','test','2.53'),('2019-04-14 19:59:59','2019-04-14 23:59:59','LENDBTC','4h','0.000002210000000','0.000002170000000','0.032214772655965','0.031631699847712','14576.820206319058','14576.820206319058343','test','test','0.0'),('2019-04-15 07:59:59','2019-04-15 11:59:59','LENDBTC','4h','0.000002190000000','0.000002160000000','0.032085200920798','0.031645677620513','14650.776676163372','14650.776676163372031','test','test','0.91'),('2019-04-18 19:59:59','2019-04-19 03:59:59','LENDBTC','4h','0.000002160000000','0.000002140000000','0.031987529076290','0.031691348251510','14809.041239023152','14809.041239023152229','test','test','0.0'),('2019-04-19 07:59:59','2019-04-19 15:59:59','LENDBTC','4h','0.000002220000000','0.000002160000000','0.031921711115228','0.031058962166168','14379.149151003507','14379.149151003506631','test','test','3.60'),('2019-04-19 19:59:59','2019-04-19 23:59:59','LENDBTC','4h','0.000002150000000','0.000002150000000','0.031729989126548','0.031729989126548','14758.134477464082','14758.134477464082011','test','test','0.0'),('2019-04-20 11:59:59','2019-04-20 15:59:59','LENDBTC','4h','0.000002160000000','0.000002130000000','0.031729989126548','0.031289294833124','14689.809780809157','14689.809780809157019','test','test','0.46'),('2019-05-18 03:59:59','2019-05-18 07:59:59','LENDBTC','4h','0.000001180000000','0.000001160000000','0.031632057061342','0.031095920500980','26806.828018086817','26806.828018086816883','test','test','0.0'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDBTC','4h','0.000001250000000','0.000001140000000','0.031512915603484','0.028739779030377','25210.332482787377','25210.332482787376648','test','test','7.20'),('2019-05-21 07:59:59','2019-05-21 11:59:59','LENDBTC','4h','0.000001180000000','0.000001160000000','0.030896663031683','0.030372990776909','26183.61273871413','26183.612738714131410','test','test','3.38'),('2019-05-21 15:59:59','2019-05-22 11:59:59','LENDBTC','4h','0.000001160000000','0.000001150000000','0.030780291419511','0.030514944079688','26534.733982336784','26534.733982336783811','test','test','0.0'),('2019-05-22 15:59:59','2019-05-24 15:59:59','LENDBTC','4h','0.000001240000000','0.000001200000000','0.030721325343994','0.029730314849026','24775.26237418907','24775.262374189071124','test','test','7.25'),('2019-05-26 07:59:59','2019-05-26 15:59:59','LENDBTC','4h','0.000001200000000','0.000001220000000','0.030501100789557','0.031009452469383','25417.583991297597','25417.583991297597095','test','test','0.0'),('2019-06-06 15:59:59','2019-06-06 19:59:59','LENDBTC','4h','0.000001090000000','0.000001060000000','0.030614067829518','0.029771478806687','28086.300761026105','28086.300761026104738','test','test','0.0'),('2019-06-07 03:59:59','2019-06-07 07:59:59','LENDBTC','4h','0.000001080000000','0.000001100000000','0.030426825824445','0.030990285561935','28172.98687448601','28172.986874486010493','test','test','1.85'),('2019-06-07 11:59:59','2019-06-07 15:59:59','LENDBTC','4h','0.000001080000000','0.000001080000000','0.030552039099443','0.030552039099443','28288.925092076544','28288.925092076544388','test','test','0.0'),('2019-06-07 19:59:59','2019-06-07 23:59:59','LENDBTC','4h','0.000001080000000','0.000001070000000','0.030552039099443','0.030269149848522','28288.925092076544','28288.925092076544388','test','test','0.0'),('2019-06-08 03:59:59','2019-06-08 07:59:59','LENDBTC','4h','0.000001080000000','0.000001130000000','0.030489174821460','0.031900710692824','28230.71742727799','28230.717427277988463','test','test','0.92'),('2019-06-08 11:59:59','2019-06-12 15:59:59','LENDBTC','4h','0.000001140000000','0.000001180000000','0.030802849459541','0.031883651194963','27020.04338556238','27020.043385562381445','test','test','3.50'),('2019-06-12 19:59:59','2019-06-13 15:59:59','LENDBTC','4h','0.000001180000000','0.000001150000000','0.031043027622968','0.030253798107130','26307.65052793918','26307.650527939178573','test','test','0.84'),('2019-06-16 11:59:59','2019-06-16 15:59:59','LENDBTC','4h','0.000001140000000','0.000001180000000','0.030867643286115','0.031950718489137','27076.880075539768','27076.880075539767859','test','test','0.0'),('2019-06-16 19:59:59','2019-06-16 23:59:59','LENDBTC','4h','0.000001160000000','0.000001170000000','0.031108326664565','0.031376501894432','26817.522986693682','26817.522986693682469','test','test','0.86'),('2019-06-17 03:59:59','2019-06-17 11:59:59','LENDBTC','4h','0.000001170000000','0.000001150000000','0.031167921160091','0.030635136182995','26639.248854778354','26639.248854778354143','test','test','0.0'),('2019-06-17 15:59:59','2019-06-19 19:59:59','LENDBTC','4h','0.000001150000000','0.000001130000000','0.031049524498514','0.030509532768105','26999.58652044677','26999.586520446770010','test','test','0.0'),('2019-07-25 15:59:59','2019-07-26 15:59:59','LENDBTC','4h','0.000000490000000','0.000000490000000','0.030929526336201','0.030929526336201','63121.48231877688','63121.482318776877946','test','test','0.0'),('2019-07-26 19:59:59','2019-07-27 03:59:59','LENDBTC','4h','0.000000490000000','0.000000490000000','0.030929526336201','0.030929526336201','63121.48231877688','63121.482318776877946','test','test','0.0'),('2019-07-28 23:59:59','2019-07-29 03:59:59','LENDBTC','4h','0.000000500000000','0.000000490000000','0.030929526336201','0.030310935809477','61859.05267240134','61859.052672401339805','test','test','2.00'),('2019-07-29 07:59:59','2019-07-29 11:59:59','LENDBTC','4h','0.000000490000000','0.000000480000000','0.030792061774706','0.030163652350732','62840.94239736011','62840.942397360107861','test','test','0.0'),('2019-08-13 23:59:59','2019-08-14 03:59:59','LENDBTC','4h','0.000000360000000','0.000000360000000','0.030652415236046','0.030652415236046','85145.59787790434','85145.597877904336201','test','test','0.0'),('2019-08-14 11:59:59','2019-08-14 15:59:59','LENDBTC','4h','0.000000360000000','0.000000350000000','0.030652415236046','0.029800959257267','85145.59787790434','85145.597877904336201','test','test','0.0'),('2019-08-21 11:59:59','2019-08-22 19:59:59','LENDBTC','4h','0.000000350000000','0.000000350000000','0.030463202796317','0.030463202796317','87037.72227519113','87037.722275191132212','test','test','0.0'),('2019-08-22 23:59:59','2019-08-26 03:59:59','LENDBTC','4h','0.000000350000000','0.000000380000000','0.030463202796317','0.033074334464573','87037.72227519113','87037.722275191132212','test','test','0.0'),('2019-08-26 07:59:59','2019-08-28 15:59:59','LENDBTC','4h','0.000000420000000','0.000000390000000','0.031043454278152','0.028826064686855','73912.98637655134','73912.986376551343710','test','test','9.52'),('2019-08-28 19:59:59','2019-08-30 11:59:59','LENDBTC','4h','0.000000390000000','0.000000390000000','0.030550701035641','0.030550701035641','78335.13086061824','78335.130860618242878','test','test','0.0'),('2019-08-30 15:59:59','2019-08-30 19:59:59','LENDBTC','4h','0.000000390000000','0.000000390000000','0.030550701035641','0.030550701035641','78335.13086061824','78335.130860618242878','test','test','0.0'),('2019-08-30 23:59:59','2019-08-31 03:59:59','LENDBTC','4h','0.000000390000000','0.000000390000000','0.030550701035641','0.030550701035641','78335.13086061824','78335.130860618242878','test','test','0.0'),('2019-09-02 07:59:59','2019-09-02 11:59:59','LENDBTC','4h','0.000000390000000','0.000000380000000','0.030550701035641','0.029767349727035','78335.13086061824','78335.130860618242878','test','test','0.0'),('2019-09-08 03:59:59','2019-09-08 15:59:59','LENDBTC','4h','0.000000370000000','0.000000360000000','0.030376622967062','0.029555633157141','82098.98099205947','82098.980992059470736','test','test','0.0'),('2019-09-08 19:59:59','2019-09-09 03:59:59','LENDBTC','4h','0.000000360000000','0.000000360000000','0.030194180787080','0.030194180787080','83872.72440855435','83872.724408554349793','test','test','0.0'),('2019-09-09 07:59:59','2019-09-09 11:59:59','LENDBTC','4h','0.000000370000000','0.000000350000000','0.030194180787080','0.028562062906697','81605.89401913396','81605.894019133964321','test','test','2.70'),('2019-09-09 15:59:59','2019-09-11 15:59:59','LENDBTC','4h','0.000000380000000','0.000000380000000','0.029831487924772','0.029831487924772','78503.91559150587','78503.915591505865450','test','test','7.89'),('2019-09-13 15:59:59','2019-09-24 03:59:59','LENDBTC','4h','0.000000390000000','0.000000500000000','0.029831487924772','0.038245497339451','76490.99467890315','76490.994678903152817','test','test','2.56'),('2019-09-24 07:59:59','2019-09-24 11:59:59','LENDBTC','4h','0.000000510000000','0.000000500000000','0.031701267794701','0.031079674308530','62159.348617060576','62159.348617060575634','test','test','5.88'),('2019-09-24 15:59:59','2019-09-24 19:59:59','LENDBTC','4h','0.000000500000000','0.000000440000000','0.031563135908885','0.027775559599819','63126.27181777024','63126.271817770240887','test','test','0.0'),('2019-09-26 07:59:59','2019-09-26 19:59:59','LENDBTC','4h','0.000000540000000','0.000000510000000','0.030721452284648','0.029014704935501','56891.57830490413','56891.578304904127435','test','test','18.5'),('2019-09-26 23:59:59','2019-09-27 11:59:59','LENDBTC','4h','0.000000510000000','0.000000510000000','0.030342175095949','0.030342175095949','59494.460972448804','59494.460972448803659','test','test','0.0'),('2019-09-27 15:59:59','2019-10-09 15:59:59','LENDBTC','4h','0.000000510000000','0.000000580000000','0.030342175095949','0.034506787364020','59494.460972448804','59494.460972448803659','test','test','0.0'),('2019-10-10 15:59:59','2019-10-11 07:59:59','LENDBTC','4h','0.000000620000000','0.000000620000000','0.031267644488854','0.031267644488854','50431.684659441235','50431.684659441234544','test','test','6.45'),('2019-10-11 11:59:59','2019-10-31 11:59:59','LENDBTC','4h','0.000000640000000','0.000001360000000','0.031267644488854','0.066443744538815','48855.694513833696','48855.694513833695964','test','test','3.12'),('2019-10-31 15:59:59','2019-11-02 15:59:59','LENDBTC','4h','0.000001330000000','0.000001290000000','0.039084555611067','0.037909080254343','29386.88391809558','29386.883918095580157','test','test','15.0'),('2019-11-02 23:59:59','2019-11-03 03:59:59','LENDBTC','4h','0.000001300000000','0.000001310000000','0.038823338865128','0.039121979933321','29864.10681932958','29864.106819329579594','test','test','9.23'),('2019-11-03 07:59:59','2019-11-07 11:59:59','LENDBTC','4h','0.000001310000000','0.000001380000000','0.038889703546949','0.040967779309000','29686.796600724516','29686.796600724515883','test','test','6.87'),('2019-11-07 15:59:59','2019-11-08 07:59:59','LENDBTC','4h','0.000001390000000','0.000001360000000','0.039351498160738','0.038502185250794','28310.43033146635','28310.430331466348434','test','test','1.43'),('2019-11-08 15:59:59','2019-11-08 19:59:59','LENDBTC','4h','0.000001380000000','0.000001380000000','0.039162761958528','0.039162761958528','28378.813013426414','28378.813013426413818','test','test','1.44'),('2019-11-08 23:59:59','2019-11-09 03:59:59','LENDBTC','4h','0.000001390000000','0.000001370000000','0.039162761958528','0.038599268980707','28174.64889102766','28174.648891027660284','test','test','0.71'),('2019-11-09 11:59:59','2019-11-21 03:59:59','LENDBTC','4h','0.000001450000000','0.000002000000000','0.039037541296790','0.053844884547297','26922.442273648587','26922.442273648586706','test','test','5.51'),('2019-11-22 03:59:59','2019-11-22 07:59:59','LENDBTC','4h','0.000002220000000','0.000002090000000','0.042328062019125','0.039849391720708','19066.694603209613','19066.694603209612978','test','test','9.90'),('2019-11-28 19:59:59','2019-11-29 15:59:59','LENDBTC','4h','0.000002050000000','0.000002010000000','0.041777246397255','0.040962080613894','20379.144584026777','20379.144584026777011','test','test','0.0'),('2019-11-29 19:59:59','2019-11-29 23:59:59','LENDBTC','4h','0.000002000000000','0.000002010000000','0.041596098445397','0.041804078937624','20798.04922269845','20798.049222698449739','test','test','0.0'),('2019-11-30 03:59:59','2019-11-30 07:59:59','LENDBTC','4h','0.000002020000000','0.000001990000000','0.041642316332558','0.041023866089995','20615.008085424975','20615.008085424975434','test','test','0.49'),('2019-11-30 11:59:59','2019-11-30 15:59:59','LENDBTC','4h','0.000002000000000','0.000001930000000','0.041504882945322','0.040052212042236','20752.441472661118','20752.441472661117587','test','test','0.49'),('2019-12-04 23:59:59','2019-12-05 07:59:59','LENDBTC','4h','0.000002030000000','0.000001960000000','0.041182067189081','0.039761995906699','20286.73260545857','20286.732605458568287','test','test','4.92'),('2019-12-06 11:59:59','2019-12-10 03:59:59','LENDBTC','4h','0.000001990000000','0.000001970000000','0.040866495792996','0.040455777242313','20535.92753416885','20535.927534168851707','test','test','1.50'),('2019-12-30 23:59:59','2020-01-01 15:59:59','LENDBTC','4h','0.000001370000000','0.000002770000000','0.040775225003955','0.082443338146683','29762.93795909149','29762.937959091490484','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 21:38:22
