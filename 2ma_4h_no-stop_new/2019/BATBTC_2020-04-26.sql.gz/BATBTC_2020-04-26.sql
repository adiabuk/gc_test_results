-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-05 03:59:59','BATBTC','4h','0.000035840000000','0.000035820000000','0.033333333333333','0.033314732142857','930.0595238095237','930.059523809523739','test','test','0.0'),('2019-01-05 07:59:59','2019-01-05 11:59:59','BATBTC','4h','0.000035570000000','0.000035680000000','0.033329199735450','0.033432270074806','937.0030850562208','937.003085056220812','test','test','0.0'),('2019-01-05 15:59:59','2019-01-05 19:59:59','BATBTC','4h','0.000035600000000','0.000036380000000','0.033352104255307','0.034082852606968','936.8568611041198','936.856861104119844','test','test','0.0'),('2019-01-05 23:59:59','2019-01-06 03:59:59','BATBTC','4h','0.000035520000000','0.000035200000000','0.033514492777898','0.033212560410530','943.5386480264076','943.538648026407600','test','test','0.0'),('2019-01-09 07:59:59','2019-01-09 15:59:59','BATBTC','4h','0.000035410000000','0.000035120000000','0.033447396696261','0.033173469979460','944.5748855199283','944.574885519928330','test','test','0.59'),('2019-01-09 19:59:59','2019-01-09 23:59:59','BATBTC','4h','0.000035370000000','0.000035150000000','0.033386524092527','0.033178861234162','943.9220834754624','943.922083475462387','test','test','0.70'),('2019-01-11 23:59:59','2019-01-12 03:59:59','BATBTC','4h','0.000035280000000','0.000034730000000','0.033340376790668','0.032820614680836','945.0220178760834','945.022017876083396','test','test','0.36'),('2019-01-12 07:59:59','2019-01-12 11:59:59','BATBTC','4h','0.000035190000000','0.000035370000000','0.033224874099594','0.033394822304707','944.1566950723058','944.156695072305752','test','test','1.30'),('2019-01-12 15:59:59','2019-01-13 03:59:59','BATBTC','4h','0.000035700000000','0.000035080000000','0.033262640367397','0.032684969862417','931.7266209354995','931.726620935499454','test','test','0.92'),('2019-01-13 07:59:59','2019-01-13 11:59:59','BATBTC','4h','0.000035250000000','0.000035210000000','0.033134269144068','0.033096669973408','939.9792664983953','939.979266498395305','test','test','0.48'),('2019-01-17 23:59:59','2019-01-18 19:59:59','BATBTC','4h','0.000035230000000','0.000034590000000','0.033125913772811','0.032524137309155','940.2757244624088','940.275724462408789','test','test','0.96'),('2019-01-19 03:59:59','2019-01-19 07:59:59','BATBTC','4h','0.000034770000000','0.000034510000000','0.032992185669776','0.032745479650963','948.869303128444','948.869303128444017','test','test','0.51'),('2019-01-19 19:59:59','2019-01-19 23:59:59','BATBTC','4h','0.000034660000000','0.000034900000000','0.032937362110040','0.033165433861523','950.2989645135539','950.298964513553869','test','test','0.43'),('2019-01-20 03:59:59','2019-01-20 15:59:59','BATBTC','4h','0.000035000000000','0.000034440000000','0.032988044721480','0.032460236005936','942.51556347087','942.515563470870006','test','test','0.71'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BATBTC','4h','0.000034710000000','0.000034590000000','0.032870753895804','0.032757112568593','947.0110600923076','947.011060092307616','test','test','0.77'),('2019-01-25 11:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000034790000000','0.000034690000000','0.032845500267535','0.032751089516550','944.1075098457859','944.107509845785899','test','test','0.57'),('2019-01-27 23:59:59','2019-01-28 03:59:59','BATBTC','4h','0.000034810000000','0.000034050000000','0.032824520100649','0.032107868699428','942.9623700272716','942.962370027271618','test','test','0.34'),('2019-02-06 23:59:59','2019-02-08 23:59:59','BATBTC','4h','0.000034240000000','0.000032360000000','0.032665264233711','0.030871727529290','954.0088853303545','954.008885330354474','test','test','3.73'),('2019-02-10 03:59:59','2019-02-11 23:59:59','BATBTC','4h','0.000033160000000','0.000033060000000','0.032266700521618','0.032169394428368','973.0609324975202','973.060932497520184','test','test','2.41'),('2019-02-12 03:59:59','2019-02-12 07:59:59','BATBTC','4h','0.000032950000000','0.000032680000000','0.032245076945340','0.031980853249582','978.6062805869497','978.606280586949651','test','test','0.0'),('2019-02-12 15:59:59','2019-02-12 19:59:59','BATBTC','4h','0.000033160000000','0.000032710000000','0.032186360568505','0.031749573407593','970.6381353590134','970.638135359013404','test','test','1.44'),('2019-02-13 07:59:59','2019-02-13 15:59:59','BATBTC','4h','0.000033260000000','0.000032810000000','0.032089296754969','0.031655136095326','964.8014658739895','964.801465873989514','test','test','1.65'),('2019-02-13 19:59:59','2019-02-21 07:59:59','BATBTC','4h','0.000033050000000','0.000035460000000','0.031992816608382','0.034325726987390','968.0126053973238','968.012605397323796','test','test','0.72'),('2019-02-21 11:59:59','2019-02-21 15:59:59','BATBTC','4h','0.000035010000000','0.000034860000000','0.032511241137050','0.032371947044775','928.6272818351898','928.627281835189820','test','test','5.56'),('2019-02-25 23:59:59','2019-03-17 07:59:59','BATBTC','4h','0.000039000000000','0.000048350000000','0.032480286894322','0.040267227470268','832.8278690851851','832.827869085185057','test','test','12.6'),('2019-03-17 11:59:59','2019-03-17 23:59:59','BATBTC','4h','0.000048680000000','0.000048620000000','0.034210718133421','0.034168552088063','702.7674226257461','702.767422625746121','test','test','28.3'),('2019-03-18 03:59:59','2019-03-18 07:59:59','BATBTC','4h','0.000048480000000','0.000048200000000','0.034201347901120','0.034003815363737','705.4733477953703','705.473347795370273','test','test','27.3'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BATBTC','4h','0.000048730000000','0.000048560000000','0.034157451781701','0.034038289729518','700.9532481366941','700.953248136694128','test','test','26.7'),('2019-03-18 19:59:59','2019-03-18 23:59:59','BATBTC','4h','0.000049240000000','0.000048490000000','0.034130971325660','0.033611104784347','693.1553884171494','693.155388417149425','test','test','27.2'),('2019-03-19 03:59:59','2019-03-19 07:59:59','BATBTC','4h','0.000048560000000','0.000048280000000','0.034015445427591','0.033819310239788','700.4828135830084','700.482813583008351','test','test','0.14'),('2019-03-21 07:59:59','2019-03-21 15:59:59','BATBTC','4h','0.000048510000000','0.000047990000000','0.033971859830301','0.033607700541252','700.3063250938225','700.306325093822466','test','test','0.47'),('2019-03-21 19:59:59','2019-03-22 03:59:59','BATBTC','4h','0.000048720000000','0.000048520000000','0.033890935543846','0.033751810192681','695.6267558260672','695.626755826067210','test','test','1.49'),('2019-03-22 07:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000048740000000','0.000066050000000','0.033860018799143','0.045885396833882','694.7069921859388','694.706992185938816','test','test','0.45'),('2019-04-02 11:59:59','2019-04-03 15:59:59','BATBTC','4h','0.000065080000000','0.000061780000000','0.036532325029085','0.034679886912982','561.3448836675578','561.344883667557838','test','test','0.0'),('2019-04-05 19:59:59','2019-04-06 11:59:59','BATBTC','4h','0.000062730000000','0.000060510000000','0.036120672114395','0.034842369992700','575.8117665294931','575.811766529493070','test','test','2.47'),('2019-04-13 07:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000058460000000','0.000058220000000','0.035836604976241','0.035689482410482','613.0106906643972','613.010690664397202','test','test','0.0'),('2019-04-16 07:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000059050000000','0.000072750000000','0.035803911072739','0.044110660974458','606.3321096145412','606.332109614541196','test','test','1.40'),('2019-04-26 11:59:59','2019-04-26 15:59:59','BATBTC','4h','0.000073460000000','0.000070790000000','0.037649855495343','0.036281422141510','512.5218553681307','512.521855368130673','test','test','17.6'),('2019-04-27 19:59:59','2019-04-29 11:59:59','BATBTC','4h','0.000074490000000','0.000073500000000','0.037345759194491','0.036849420067057','501.3526539735683','501.352653973568295','test','test','17.0'),('2019-04-29 15:59:59','2019-04-29 19:59:59','BATBTC','4h','0.000073400000000','0.000072740000000','0.037235461610617','0.036900646833192','507.2951173108567','507.295117310856710','test','test','10.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BATBTC','4h','0.000073140000000','0.000073640000000','0.037161058326745','0.037415098922361','508.08119123249463','508.081191232494632','test','test','0.54'),('2019-05-18 11:59:59','2019-05-18 15:59:59','BATBTC','4h','0.000052980000000','0.000052450000000','0.037217511792437','0.036845196178054','702.4822912879786','702.482291287978569','test','test','0.0'),('2019-06-03 19:59:59','2019-06-03 23:59:59','BATBTC','4h','0.000043670000000','0.000041590000000','0.037134774989241','0.035366047442238','850.3497822129809','850.349782212980926','test','test','0.0'),('2019-06-04 11:59:59','2019-06-04 19:59:59','BATBTC','4h','0.000043580000000','0.000042460000000','0.036741724423240','0.035797467164084','843.0868385323593','843.086838532359252','test','test','4.56'),('2019-06-04 23:59:59','2019-06-05 03:59:59','BATBTC','4h','0.000042920000000','0.000043620000000','0.036531889476761','0.037127703144835','851.162382962747','851.162382962746960','test','test','1.07'),('2019-06-05 07:59:59','2019-06-05 11:59:59','BATBTC','4h','0.000043230000000','0.000042910000000','0.036664292514111','0.036392893633599','848.121501598679','848.121501598678947','test','test','0.0'),('2019-06-07 15:59:59','2019-06-07 19:59:59','BATBTC','4h','0.000043250000000','0.000042600000000','0.036603981651775','0.036053864008454','846.3348358791881','846.334835879188063','test','test','0.78'),('2019-06-08 03:59:59','2019-06-08 15:59:59','BATBTC','4h','0.000043110000000','0.000042400000000','0.036481733286592','0.035880897502934','846.2475826163869','846.247582616386921','test','test','1.18'),('2019-06-09 07:59:59','2019-06-09 15:59:59','BATBTC','4h','0.000043050000000','0.000042260000000','0.036348214223557','0.035681197051975','844.3255336482538','844.325533648253781','test','test','1.50'),('2019-07-01 07:59:59','2019-07-02 15:59:59','BATBTC','4h','0.000030760000000','0.000029330000000','0.036199988185428','0.034517088864714','1176.8526718279581','1176.852671827958147','test','test','0.0'),('2019-07-02 23:59:59','2019-07-03 03:59:59','BATBTC','4h','0.000029710000000','0.000027490000000','0.035826010558603','0.033149008086705','1205.8569693235497','1205.856969323549720','test','test','1.27'),('2019-07-20 07:59:59','2019-07-20 19:59:59','BATBTC','4h','0.000024370000000','0.000023870000000','0.035231121120403','0.034508283181946','1445.6758769143662','1445.675876914366199','test','test','0.0'),('2019-07-23 03:59:59','2019-07-23 07:59:59','BATBTC','4h','0.000024650000000','0.000023540000000','0.035070490467413','0.033491251342917','1422.7379499964568','1422.737949996456791','test','test','3.16'),('2019-07-24 19:59:59','2019-07-24 23:59:59','BATBTC','4h','0.000024090000000','0.000023730000000','0.034719548439747','0.034200700891457','1441.2431896947646','1441.243189694764624','test','test','2.28'),('2019-07-26 07:59:59','2019-07-26 11:59:59','BATBTC','4h','0.000023790000000','0.000024400000000','0.034604248984571','0.035491537420073','1454.571205740703','1454.571205740702908','test','test','0.25'),('2019-07-26 15:59:59','2019-07-30 15:59:59','BATBTC','4h','0.000024350000000','0.000025260000000','0.034801424192461','0.036102011297806','1429.2165992796988','1429.216599279698812','test','test','0.0'),('2019-07-30 19:59:59','2019-07-30 23:59:59','BATBTC','4h','0.000025580000000','0.000025760000000','0.035090443549204','0.035337366138682','1371.7921637687255','1371.792163768725459','test','test','4.61'),('2019-07-31 03:59:59','2019-07-31 15:59:59','BATBTC','4h','0.000025710000000','0.000024490000000','0.035145315235755','0.033477587324918','1366.9900908500451','1366.990090850045135','test','test','0.0'),('2019-08-21 23:59:59','2019-08-22 03:59:59','BATBTC','4h','0.000018040000000','0.000018230000000','0.034774709033346','0.035140961512079','1927.6446249083388','1927.644624908338756','test','test','0.0'),('2019-08-22 07:59:59','2019-08-26 03:59:59','BATBTC','4h','0.000018610000000','0.000018430000000','0.034856098473065','0.034518962646888','1872.9768120937604','1872.976812093760373','test','test','2.04'),('2019-08-28 03:59:59','2019-08-28 19:59:59','BATBTC','4h','0.000018790000000','0.000018400000000','0.034781179400581','0.034059270940431','1851.0473337190579','1851.047333719057860','test','test','1.91'),('2019-08-28 23:59:59','2019-08-29 03:59:59','BATBTC','4h','0.000018800000000','0.000017550000000','0.034620755298326','0.032318843376895','1841.529537144976','1841.529537144976075','test','test','2.12'),('2019-08-30 15:59:59','2019-08-30 19:59:59','BATBTC','4h','0.000018630000000','0.000018480000000','0.034109219315785','0.033834587920328','1830.875969714725','1830.875969714724988','test','test','5.79'),('2019-08-30 23:59:59','2019-08-31 03:59:59','BATBTC','4h','0.000018620000000','0.000018550000000','0.034048190116795','0.033920189402070','1828.581638925611','1828.581638925611060','test','test','0.75'),('2019-08-31 07:59:59','2019-08-31 11:59:59','BATBTC','4h','0.000018520000000','0.000018460000000','0.034019745513523','0.033909530355272','1836.919304185889','1836.919304185888905','test','test','0.0'),('2019-08-31 19:59:59','2019-08-31 23:59:59','BATBTC','4h','0.000018550000000','0.000018440000000','0.033995253256134','0.033793664153267','1832.6282078778192','1832.628207877819250','test','test','0.48'),('2019-09-01 03:59:59','2019-09-01 07:59:59','BATBTC','4h','0.000018500000000','0.000018530000000','0.033950455677719','0.034005510470710','1835.1597663631708','1835.159766363170775','test','test','0.32'),('2019-09-01 11:59:59','2019-09-01 15:59:59','BATBTC','4h','0.000018480000000','0.000018500000000','0.033962690076161','0.033999446234252','1837.8079045541722','1837.807904554172183','test','test','0.0'),('2019-09-01 19:59:59','2019-09-02 03:59:59','BATBTC','4h','0.000018960000000','0.000018260000000','0.033970858111292','0.032716659763301','1791.7119257010775','1791.711925701077462','test','test','2.42'),('2019-09-10 11:59:59','2019-09-10 15:59:59','BATBTC','4h','0.000017190000000','0.000017260000000','0.033692147367294','0.033829346338540','1959.9853035075298','1959.985303507529807','test','test','0.0'),('2019-09-10 19:59:59','2019-09-10 23:59:59','BATBTC','4h','0.000017660000000','0.000017050000000','0.033722636027571','0.032557811113821','1909.5490389338238','1909.549038933823795','test','test','2.26'),('2019-09-12 07:59:59','2019-09-12 11:59:59','BATBTC','4h','0.000017550000000','0.000017120000000','0.033463786046738','0.032643875619382','1906.7684357115666','1906.768435711566553','test','test','2.84'),('2019-09-16 03:59:59','2019-09-16 07:59:59','BATBTC','4h','0.000017070000000','0.000016930000000','0.033281583729548','0.033008624050454','1949.7119935294536','1949.711993529453594','test','test','0.0'),('2019-09-16 15:59:59','2019-09-24 15:59:59','BATBTC','4h','0.000017220000000','0.000018800000000','0.033220926023082','0.036269071384085','1929.2059246853908','1929.205924685390755','test','test','1.68'),('2019-09-24 19:59:59','2019-09-24 23:59:59','BATBTC','4h','0.000018990000000','0.000018310000000','0.033898291658861','0.032684450777975','1785.06011895002','1785.060118950020069','test','test','9.84'),('2019-09-25 03:59:59','2019-09-25 07:59:59','BATBTC','4h','0.000019070000000','0.000018800000000','0.033628549240886','0.033152424002551','1763.426808646367','1763.426808646366908','test','test','4.24'),('2019-09-25 23:59:59','2019-09-26 19:59:59','BATBTC','4h','0.000019030000000','0.000019100000000','0.033522743632367','0.033646053777100','1761.5734961832543','1761.573496183254292','test','test','2.62'),('2019-09-26 23:59:59','2019-09-27 03:59:59','BATBTC','4h','0.000018860000000','0.000019160000000','0.033550145886752','0.034083817348365','1778.9048720441378','1778.904872044137846','test','test','1.64'),('2019-09-27 07:59:59','2019-10-10 11:59:59','BATBTC','4h','0.000019520000000','0.000022930000000','0.033668739544889','0.039550419967434','1724.8329684881485','1724.832968488148481','test','test','2.15'),('2019-10-10 15:59:59','2019-10-10 19:59:59','BATBTC','4h','0.000023170000000','0.000022750000000','0.034975779638788','0.034341777590955','1509.5286853166829','1509.528685316682868','test','test','17.3'),('2019-10-10 23:59:59','2019-10-11 03:59:59','BATBTC','4h','0.000022740000000','0.000022610000000','0.034834890294825','0.034635746243008','1531.8773216721486','1531.877321672148582','test','test','0.0'),('2019-10-11 07:59:59','2019-10-11 11:59:59','BATBTC','4h','0.000022770000000','0.000022450000000','0.034790636061088','0.034301703099316','1527.9155055374415','1527.915505537441504','test','test','0.70'),('2019-10-11 15:59:59','2019-10-11 23:59:59','BATBTC','4h','0.000023330000000','0.000022860000000','0.034681984291805','0.033983290223346','1486.583124380835','1486.583124380834988','test','test','3.77'),('2019-10-12 03:59:59','2019-10-22 03:59:59','BATBTC','4h','0.000023070000000','0.000026610000000','0.034526718943258','0.039824707025578','1496.6068029154067','1496.606802915406661','test','test','1.38'),('2019-10-22 07:59:59','2019-10-25 19:59:59','BATBTC','4h','0.000027020000000','0.000028720000000','0.035704049628218','0.037950418405715','1321.3933985276994','1321.393398527699446','test','test','9.36'),('2019-10-25 23:59:59','2019-10-26 03:59:59','BATBTC','4h','0.000029060000000','0.000027200000000','0.036203242689884','0.033886035828109','1245.8101407393128','1245.810140739312828','test','test','11.3'),('2019-11-04 19:59:59','2019-11-04 23:59:59','BATBTC','4h','0.000026460000000','0.000025850000000','0.035688307831712','0.034865561506038','1348.7644683186775','1348.764468318677473','test','test','0.0'),('2019-11-05 07:59:59','2019-11-05 11:59:59','BATBTC','4h','0.000026170000000','0.000026590000000','0.035505475314896','0.036075299527057','1356.724314669307','1356.724314669306978','test','test','1.22'),('2019-11-05 15:59:59','2019-11-08 15:59:59','BATBTC','4h','0.000026680000000','0.000026530000000','0.035632102917598','0.035431772503893','1335.536091364251','1335.536091364250979','test','test','0.33'),('2019-11-08 19:59:59','2019-11-20 11:59:59','BATBTC','4h','0.000026740000000','0.000029750000000','0.035587585047886','0.039593517396208','1330.874534326327','1330.874534326326966','test','test','0.78'),('2019-11-20 15:59:59','2019-11-20 19:59:59','BATBTC','4h','0.000029710000000','0.000029070000000','0.036477792236402','0.035692003376379','1227.7950937866706','1227.795093786670577','test','test','8.44'),('2019-11-22 23:59:59','2019-11-23 07:59:59','BATBTC','4h','0.000030140000000','0.000029510000000','0.036303172489730','0.035544347052818','1204.484820495362','1204.484820495362101','test','test','8.79'),('2019-11-23 11:59:59','2019-11-23 19:59:59','BATBTC','4h','0.000030500000000','0.000029930000000','0.036134544614861','0.035459243289272','1184.7391677003566','1184.739167700356575','test','test','3.24'),('2019-11-23 23:59:59','2019-11-24 15:59:59','BATBTC','4h','0.000030250000000','0.000029650000000','0.035984477653619','0.035270735948093','1189.5695092105414','1189.569509210541355','test','test','1.61'),('2019-11-24 19:59:59','2019-11-24 23:59:59','BATBTC','4h','0.000029720000000','0.000029350000000','0.035825868385724','0.035379853200572','1205.4464463568038','1205.446446356803790','test','test','0.23'),('2019-11-25 03:59:59','2019-11-25 07:59:59','BATBTC','4h','0.000029880000000','0.000030300000000','0.035726753900135','0.036228937187888','1195.6744946497618','1195.674494649761755','test','test','1.77'),('2019-11-25 11:59:59','2019-11-25 15:59:59','BATBTC','4h','0.000030210000000','0.000029890000000','0.035838350186302','0.035458731779827','1186.3075202350947','1186.307520235094671','test','test','0.92'),('2019-12-13 15:59:59','2019-12-14 15:59:59','BATBTC','4h','0.000026070000000','0.000025400000000','0.035753990540419','0.034835111612069','1371.4610870893316','1371.461087089331613','test','test','0.0'),('2019-12-15 15:59:59','2019-12-16 11:59:59','BATBTC','4h','0.000025910000000','0.000025500000000','0.035549795223008','0.034987255043871','1372.0492174067065','1372.049217406706475','test','test','1.96'),('2019-12-16 15:59:59','2019-12-16 19:59:59','BATBTC','4h','0.000025700000000','0.000025130000000','0.035424786294311','0.034639100372608','1378.3963538642276','1378.396353864227649','test','test','0.77'),('2019-12-28 03:59:59','2020-01-01 15:59:59','BATBTC','4h','0.000023800000000','0.000026110000000','0.035250189422821','0.038671531337389','1481.100395916853','1481.100395916852904','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 21:13:48
