-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000695300000000','0.000694000000000','0.033333333333333','0.033271010115537','47.940936765904404','47.940936765904404','test','test','0.92'),('2019-01-07 07:59:59','2019-01-07 11:59:59','EOSBTC','4h','0.000701400000000','0.000688400000000','0.033319483729379','0.032701928427865','47.50425396261572','47.504253962615721','test','test','1.85'),('2019-01-08 23:59:59','2019-01-09 03:59:59','EOSBTC','4h','0.000693400000000','0.000695200000000','0.033182249217931','0.033268387159368','47.85441190933243','47.854411909332427','test','test','0.0'),('2019-01-09 07:59:59','2019-01-09 11:59:59','EOSBTC','4h','0.000693500000000','0.000696400000000','0.033201390982695','0.033340228810885','47.87511316899047','47.875113168990467','test','test','0.0'),('2019-01-09 15:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000703400000000','0.000677800000000','0.033232243833404','0.032022767799661','47.24515756810318','47.245157568103181','test','test','3.63'),('2019-01-17 11:59:59','2019-01-17 15:59:59','EOSBTC','4h','0.000672400000000','0.000673000000000','0.032963471381461','0.032992885543907','49.02360407712804','49.023604077128041','test','test','0.0'),('2019-01-17 19:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000682700000000','0.000676900000000','0.032970007862004','0.032689905261155','48.293551870520645','48.293551870520645','test','test','0.84'),('2019-01-18 15:59:59','2019-01-18 19:59:59','EOSBTC','4h','0.000672400000000','0.000670300000000','0.032907762839594','0.032804987256662','48.94075377690892','48.940753776908920','test','test','0.31'),('2019-01-18 23:59:59','2019-01-19 03:59:59','EOSBTC','4h','0.000675700000000','0.000672700000000','0.032884923821164','0.032738920015535','48.667935209655504','48.667935209655504','test','test','0.44'),('2019-01-19 07:59:59','2019-01-19 11:59:59','EOSBTC','4h','0.000672400000000','0.000671100000000','0.032852478531024','0.032788962436303','48.85853440069073','48.858534400690729','test','test','0.19'),('2019-01-22 19:59:59','2019-01-26 23:59:59','EOSBTC','4h','0.000687900000000','0.000674500000000','0.032838363843309','0.032198686454880','47.73711853948054','47.737118539480541','test','test','1.94'),('2019-01-27 03:59:59','2019-01-27 11:59:59','EOSBTC','4h','0.000677300000000','0.000669500000000','0.032696213312547','0.032319673427950','48.274344179162355','48.274344179162355','test','test','1.15'),('2019-01-30 19:59:59','2019-01-31 11:59:59','EOSBTC','4h','0.000671900000000','0.000667900000000','0.032612537782636','0.032418386642391','48.53778506122373','48.537785061223730','test','test','0.59'),('2019-01-31 15:59:59','2019-02-01 03:59:59','EOSBTC','4h','0.000671400000000','0.000672200000000','0.032569393084804','0.032608200821575','48.509670963366105','48.509670963366105','test','test','0.10'),('2019-02-01 07:59:59','2019-02-01 11:59:59','EOSBTC','4h','0.000667200000000','0.000672300000000','0.032578017026309','0.032827039638471','48.827963168927866','48.827963168927866','test','test','0.0'),('2019-02-01 15:59:59','2019-02-02 23:59:59','EOSBTC','4h','0.000672400000000','0.000695900000000','0.032633355384567','0.033773872712850','48.53265226735112','48.532652267351118','test','test','0.29'),('2019-02-03 03:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000695900000000','0.000679200000000','0.032886803679741','0.032097596004139','47.25794464684709','47.257944646847093','test','test','2.39'),('2019-02-06 07:59:59','2019-02-06 11:59:59','EOSBTC','4h','0.000678500000000','0.000681200000000','0.032711424196274','0.032841594933680','48.211384224427086','48.211384224427086','test','test','0.0'),('2019-02-06 15:59:59','2019-02-25 11:59:59','EOSBTC','4h','0.000685800000000','0.000896200000000','0.032740351026808','0.042784926494933','47.740377700216456','47.740377700216456','test','test','0.0'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSBTC','4h','0.000935800000000','0.000925700000000','0.034972478908614','0.034595024284787','37.37174493333405','37.371744933334050','test','test','1.07'),('2019-02-26 03:59:59','2019-02-26 07:59:59','EOSBTC','4h','0.000915800000000','0.000912700000000','0.034888600103319','0.034770501544332','38.096309350643274','38.096309350643274','test','test','0.33'),('2019-02-26 11:59:59','2019-02-26 15:59:59','EOSBTC','4h','0.000908700000000','0.000896100000000','0.034862355979100','0.034378955863180','38.36508856509275','38.365088565092748','test','test','1.38'),('2019-02-27 07:59:59','2019-02-27 11:59:59','EOSBTC','4h','0.000915600000000','0.000914500000000','0.034754933731118','0.034713179223577','37.958643218782825','37.958643218782825','test','test','0.12'),('2019-02-27 15:59:59','2019-02-27 19:59:59','EOSBTC','4h','0.000900000000000','0.000901400000000','0.034745654951664','0.034799703748255','38.60628327962667','38.606283279626673','test','test','0.0'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSBTC','4h','0.000917600000000','0.000907400000000','0.034757665795351','0.034371301158132','37.87888600190812','37.878886001908121','test','test','1.11'),('2019-03-02 03:59:59','2019-03-02 07:59:59','EOSBTC','4h','0.000913400000000','0.000910200000000','0.034671806987080','0.034550337989534','37.95906173317276','37.959061733172760','test','test','0.35'),('2019-03-02 11:59:59','2019-03-02 15:59:59','EOSBTC','4h','0.000914100000000','0.000910800000000','0.034644813876514','0.034519742346274','37.90046370912835','37.900463709128353','test','test','0.36'),('2019-03-02 19:59:59','2019-03-02 23:59:59','EOSBTC','4h','0.000909500000000','0.000910100000000','0.034617020203128','0.034639857159832','38.061594505912645','38.061594505912645','test','test','0.0'),('2019-03-03 03:59:59','2019-03-03 07:59:59','EOSBTC','4h','0.000909800000000','0.000914100000000','0.034622095082395','0.034785729956933','38.054621985485944','38.054621985485944','test','test','0.0'),('2019-03-03 11:59:59','2019-03-04 03:59:59','EOSBTC','4h','0.000926000000000','0.000909000000000','0.034658458387848','0.034022179994119','37.428140807611236','37.428140807611236','test','test','1.83'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000946300000000','0.000928400000000','0.034517063189242','0.033864146111056','36.4758144237996','36.475814423799598','test','test','1.89'),('2019-03-09 03:59:59','2019-03-11 07:59:59','EOSBTC','4h','0.000938900000000','0.000926900000000','0.034371970505200','0.033932665311822','36.608766114815445','36.608766114815445','test','test','1.27'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSBTC','4h','0.000942400000000','0.000935900000000','0.034274347128894','0.034037947238892','36.36921384644949','36.369213846449490','test','test','0.68'),('2019-03-12 19:59:59','2019-03-12 23:59:59','EOSBTC','4h','0.000937900000000','0.000937800000000','0.034221813820005','0.034218165050006','36.487699989342865','36.487699989342865','test','test','0.01'),('2019-03-13 03:59:59','2019-03-13 07:59:59','EOSBTC','4h','0.000936100000000','0.000935800000000','0.034221002982227','0.034210035883739','36.55699496018279','36.556994960182791','test','test','0.03'),('2019-03-15 11:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000941600000000','0.000935700000000','0.034218565849230','0.034004154699580','36.34087282203673','36.340872822036729','test','test','0.62'),('2019-03-25 23:59:59','2019-03-26 03:59:59','EOSBTC','4h','0.000927300000000','0.000921400000000','0.034170918927085','0.033953504474729','36.84990717899853','36.849907178998528','test','test','0.63'),('2019-03-26 07:59:59','2019-04-02 07:59:59','EOSBTC','4h','0.000924800000000','0.000975800000000','0.034122604604340','0.036004365887668','36.89728006524606','36.897280065246058','test','test','0.01'),('2019-04-02 19:59:59','2019-04-03 23:59:59','EOSBTC','4h','0.001019500000000','0.001056400000000','0.034540773778412','0.035790949896532','33.88011160217013','33.880111602170132','test','test','0.0'),('2019-04-04 03:59:59','2019-04-04 15:59:59','EOSBTC','4h','0.001037800000000','0.001033200000000','0.034818590693550','0.034664258917495','33.55038609900773','33.550386099007731','test','test','0.44'),('2019-04-04 19:59:59','2019-04-08 11:59:59','EOSBTC','4h','0.001020000000000','0.001032600000000','0.034784294743316','0.035213983090145','34.1022497483488','34.102249748348797','test','test','0.0'),('2019-04-08 15:59:59','2019-04-09 03:59:59','EOSBTC','4h','0.001046600000000','0.001040600000000','0.034879781042611','0.034679820516856','33.32675429257703','33.326754292577029','test','test','0.57'),('2019-04-09 07:59:59','2019-04-10 23:59:59','EOSBTC','4h','0.001041500000000','0.001100600000000','0.034835345370221','0.036812079802655','33.44728312071158','33.447283120711582','test','test','0.0'),('2019-04-11 03:59:59','2019-04-11 11:59:59','EOSBTC','4h','0.001075000000000','0.001049000000000','0.035274619688540','0.034421466096073','32.813599710269564','32.813599710269564','test','test','2.41'),('2019-04-12 03:59:59','2019-04-12 07:59:59','EOSBTC','4h','0.001059600000000','0.001055400000000','0.035085030001325','0.034945961365986','33.111579842699975','33.111579842699975','test','test','0.39'),('2019-04-12 11:59:59','2019-04-12 19:59:59','EOSBTC','4h','0.001064900000000','0.001051900000000','0.035054125860138','0.034626194940632','32.917763038913','32.917763038913002','test','test','1.37'),('2019-04-12 23:59:59','2019-04-13 11:59:59','EOSBTC','4h','0.001056600000000','0.001043500000000','0.034959030100248','0.034525599005876','33.08634308181736','33.086343081817361','test','test','1.23'),('2019-04-14 23:59:59','2019-04-15 15:59:59','EOSBTC','4h','0.001080600000000','0.001068400000000','0.034862712079277','0.034469111221080','32.26236542594547','32.262365425945468','test','test','2.00'),('2019-04-15 19:59:59','2019-04-15 23:59:59','EOSBTC','4h','0.001052600000000','0.001059900000000','0.034775245221900','0.035016418782721','33.03747408502713','33.037474085027128','test','test','0.0'),('2019-04-16 03:59:59','2019-04-16 15:59:59','EOSBTC','4h','0.001059000000000','0.001057700000000','0.034828839346526','0.034786084397375','32.888422423537726','32.888422423537726','test','test','0.12'),('2019-04-16 19:59:59','2019-04-17 03:59:59','EOSBTC','4h','0.001057400000000','0.001050500000000','0.034819338246715','0.034592126752576','32.92920204909694','32.929202049096943','test','test','0.65'),('2019-05-16 03:59:59','2019-05-19 03:59:59','EOSBTC','4h','0.000818900000000','0.000790200000000','0.034768846803573','0.033550302532890','42.45798852555027','42.457988525550270','test','test','3.50'),('2019-05-24 11:59:59','2019-05-25 15:59:59','EOSBTC','4h','0.000798600000000','0.000792100000000','0.034498059187866','0.034217271077772','43.19817078370371','43.198170783703709','test','test','0.81'),('2019-05-26 03:59:59','2019-05-26 07:59:59','EOSBTC','4h','0.000793200000000','0.000794100000000','0.034435661830067','0.034474734063611','43.41359282661008','43.413592826610078','test','test','0.0'),('2019-05-27 03:59:59','2019-05-27 07:59:59','EOSBTC','4h','0.000798400000000','0.000794200000000','0.034444344548632','0.034263149349353','43.1417141140186','43.141714114018598','test','test','0.52'),('2019-05-27 11:59:59','2019-05-30 23:59:59','EOSBTC','4h','0.000800300000000','0.000882500000000','0.034404078948793','0.037937772925540','42.988977819308595','42.988977819308595','test','test','0.0'),('2019-05-31 03:59:59','2019-06-01 23:59:59','EOSBTC','4h','0.000889500000000','0.000902400000000','0.035189344276959','0.035699678780807','39.56081425178041','39.560814251780407','test','test','0.0'),('2019-06-02 03:59:59','2019-06-02 19:59:59','EOSBTC','4h','0.000890100000000','0.000869400000000','0.035302751944480','0.034481757713213','39.66155706603802','39.661557066038021','test','test','2.32'),('2019-06-02 23:59:59','2019-06-03 03:59:59','EOSBTC','4h','0.000884800000000','0.000874600000000','0.035120308781977','0.034715440846199','39.69293488017255','39.692934880172551','test','test','1.15'),('2019-07-23 19:59:59','2019-07-28 23:59:59','EOSBTC','4h','0.000419500000000','0.000448200000000','0.035030338129582','0.037426930988507','83.5049776628881','83.504977662888095','test','test','0.0'),('2019-07-29 03:59:59','2019-07-29 11:59:59','EOSBTC','4h','0.000445300000000','0.000438900000000','0.035562914320454','0.035051792264198','79.86282129003769','79.862821290037687','test','test','1.43'),('2019-07-29 15:59:59','2019-07-29 19:59:59','EOSBTC','4h','0.000439600000000','0.000436900000000','0.035449331641286','0.035231603717193','80.63997188645537','80.639971886455371','test','test','0.61'),('2019-07-29 23:59:59','2019-07-30 03:59:59','EOSBTC','4h','0.000443000000000','0.000441800000000','0.035400947658154','0.035305053443279','79.91184572946729','79.911845729467288','test','test','0.27'),('2019-07-30 07:59:59','2019-07-30 11:59:59','EOSBTC','4h','0.000439200000000','0.000441500000000','0.035379637832626','0.035564913713808','80.55473094860253','80.554730948602526','test','test','0.0'),('2019-07-30 15:59:59','2019-07-30 19:59:59','EOSBTC','4h','0.000439000000000','0.000436600000000','0.035420810250667','0.035227165729934','80.68521697190586','80.685216971905859','test','test','0.54'),('2019-08-13 23:59:59','2019-08-14 03:59:59','EOSBTC','4h','0.000374500000000','0.000386600000000','0.035377778134948','0.036520825172152','94.46669728958138','94.466697289581376','test','test','0.0'),('2019-08-14 07:59:59','2019-08-14 19:59:59','EOSBTC','4h','0.000385600000000','0.000358400000000','0.035631788587660','0.033118342919651','92.40609073563338','92.406090735633384','test','test','7.05'),('2019-08-22 15:59:59','2019-08-23 15:59:59','EOSBTC','4h','0.000359600000000','0.000356600000000','0.035073245105880','0.034780642949824','97.53405201857746','97.534052018577455','test','test','0.83'),('2019-08-24 11:59:59','2019-08-24 19:59:59','EOSBTC','4h','0.000360700000000','0.000361200000000','0.035008222404535','0.035056750575320','97.05634157065337','97.056341570653373','test','test','0.19'),('2019-08-24 23:59:59','2019-08-25 15:59:59','EOSBTC','4h','0.000361200000000','0.000356100000000','0.035019006442487','0.034524552032585','96.95184507886736','96.951845078867365','test','test','1.41'),('2019-09-07 19:59:59','2019-09-22 19:59:59','EOSBTC','4h','0.000338900000000','0.000376700000000','0.034909127684731','0.038802798462196','103.00716342499524','103.007163424995241','test','test','0.0'),('2019-09-23 15:59:59','2019-09-23 23:59:59','EOSBTC','4h','0.000387300000000','0.000380700000000','0.035774387857501','0.035164754601990','92.36867507746163','92.368675077461631','test','test','1.70'),('2019-09-30 11:59:59','2019-09-30 15:59:59','EOSBTC','4h','0.000362600000000','0.000354200000000','0.035638913800721','0.034813301898002','98.28713127611879','98.287131276118785','test','test','2.31'),('2019-10-01 03:59:59','2019-10-01 15:59:59','EOSBTC','4h','0.000360800000000','0.000352500000000','0.035455444489005','0.034639812035405','98.2689703132077','98.268970313207703','test','test','2.30'),('2019-10-02 11:59:59','2019-10-02 15:59:59','EOSBTC','4h','0.000359100000000','0.000359300000000','0.035274192832650','0.035293838721167','98.22944258604785','98.229442586047853','test','test','0.0'),('2019-10-02 19:59:59','2019-10-03 03:59:59','EOSBTC','4h','0.000363700000000','0.000358000000000','0.035278558585654','0.034725663936387','96.9990612748242','96.999061274824200','test','test','1.56'),('2019-10-03 07:59:59','2019-10-03 11:59:59','EOSBTC','4h','0.000358500000000','0.000359200000000','0.035155693108039','0.035224337418152','98.06330016189308','98.063300161893082','test','test','0.0'),('2019-10-03 15:59:59','2019-10-03 19:59:59','EOSBTC','4h','0.000357600000000','0.000351700000000','0.035170947399175','0.034590666108193','98.35276118337497','98.352761183374966','test','test','1.64'),('2019-10-04 07:59:59','2019-10-06 19:59:59','EOSBTC','4h','0.000361600000000','0.000369100000000','0.035041996001179','0.035768807312044','96.90817478202126','96.908174782021263','test','test','0.0'),('2019-10-06 23:59:59','2019-10-10 07:59:59','EOSBTC','4h','0.000369900000000','0.000369600000000','0.035203509625816','0.035174958523119','95.17034232445405','95.170342324454055','test','test','0.08'),('2019-10-11 19:59:59','2019-10-11 23:59:59','EOSBTC','4h','0.000371300000000','0.000370200000000','0.035197164936327','0.035092891083836','94.7944113555813','94.794411355581303','test','test','0.29'),('2019-10-12 03:59:59','2019-10-12 11:59:59','EOSBTC','4h','0.000371700000000','0.000369800000000','0.035173992969107','0.034994195856809','94.63005910440441','94.630059104404410','test','test','0.51'),('2019-10-13 03:59:59','2019-10-13 07:59:59','EOSBTC','4h','0.000372200000000','0.000371800000000','0.035134038055263','0.035096279819846','94.39558854181386','94.395588541813865','test','test','0.10'),('2019-10-13 11:59:59','2019-10-13 15:59:59','EOSBTC','4h','0.000372200000000','0.000370100000000','0.035125647336282','0.034927463941854','94.37304496582902','94.373044965829024','test','test','0.56'),('2019-10-13 23:59:59','2019-10-15 11:59:59','EOSBTC','4h','0.000374700000000','0.000374700000000','0.035081606581964','0.035081606581964','93.62585156649114','93.625851566491136','test','test','0.0'),('2019-10-15 15:59:59','2019-10-15 19:59:59','EOSBTC','4h','0.000373300000000','0.000360000000000','0.035081606581964','0.033831712749818','93.97697986060602','93.976979860606022','test','test','3.56'),('2019-10-24 03:59:59','2019-10-24 07:59:59','EOSBTC','4h','0.000363300000000','0.000363300000000','0.034803852397043','0.034803852397043','95.79920835960057','95.799208359600570','test','test','0.0'),('2019-10-24 15:59:59','2019-10-26 03:59:59','EOSBTC','4h','0.000369700000000','0.000344500000000','0.034803852397043','0.032431504329947','94.14079631334295','94.140796313342946','test','test','6.81'),('2019-10-28 11:59:59','2019-10-28 15:59:59','EOSBTC','4h','0.000361100000000','0.000357300000000','0.034276663937688','0.033915956867726','94.92291314784886','94.922913147848860','test','test','1.05'),('2019-10-29 03:59:59','2019-10-29 15:59:59','EOSBTC','4h','0.000360000000000','0.000359700000000','0.034196506811030','0.034168009722021','94.99029669730555','94.990296697305553','test','test','0.08'),('2019-10-29 19:59:59','2019-10-29 23:59:59','EOSBTC','4h','0.000363800000000','0.000361600000000','0.034190174124584','0.033983416612011','93.98068753321485','93.980687533214848','test','test','0.60'),('2019-10-30 03:59:59','2019-10-30 11:59:59','EOSBTC','4h','0.000363800000000','0.000359500000000','0.034144228010678','0.033740654122701','93.85439255271702','93.854392552717016','test','test','1.18'),('2019-11-01 19:59:59','2019-11-02 15:59:59','EOSBTC','4h','0.000361100000000','0.000358800000000','0.034054544924461','0.033837636995006','94.30779541529034','94.307795415290343','test','test','0.63'),('2019-11-04 11:59:59','2019-11-15 15:59:59','EOSBTC','4h','0.000363900000000','0.000391800000000','0.034006343162360','0.036613589587834','93.44969266930536','93.449692669305364','test','test','0.0'),('2019-11-15 19:59:59','2019-11-18 19:59:59','EOSBTC','4h','0.000392600000000','0.000385700000000','0.034585731256910','0.033977882184896','88.09406840781966','88.094068407819663','test','test','1.75'),('2019-12-01 03:59:59','2019-12-02 15:59:59','EOSBTC','4h','0.000368700000000','0.000368400000000','0.034450653685351','0.034422622234020','93.43817110211916','93.438171102119156','test','test','0.13'),('2019-12-03 07:59:59','2019-12-03 11:59:59','EOSBTC','4h','0.000368500000000','0.000367100000000','0.034444424473944','0.034313563702537','93.47197957651139','93.471979576511387','test','test','0.37'),('2019-12-03 15:59:59','2019-12-03 19:59:59','EOSBTC','4h','0.000369200000000','0.000370400000000','0.034415344302521','0.034527203493103','93.21599215200615','93.215992152006152','test','test','0.0'),('2019-12-03 23:59:59','2019-12-04 03:59:59','EOSBTC','4h','0.000369500000000','0.000363300000000','0.034440201900428','0.033862314886131','93.20758295109006','93.207582951090060','test','test','1.67'),('2019-12-13 15:59:59','2019-12-13 19:59:59','EOSBTC','4h','0.000363500000000','0.000360900000000','0.034311782563917','0.034066361285606','94.39279935052912','94.392799350529117','test','test','0.71'),('2019-12-14 15:59:59','2019-12-14 19:59:59','EOSBTC','4h','0.000362700000000','0.000363200000000','0.034257244502070','0.034304469818450','94.45063276005087','94.450632760050865','test','test','0.0'),('2019-12-14 23:59:59','2019-12-15 03:59:59','EOSBTC','4h','0.000363000000000','0.000362100000000','0.034267739016822','0.034182777680417','94.40148489482523','94.401484894825231','test','test','0.24'),('2019-12-24 19:59:59','2019-12-25 15:59:59','EOSBTC','4h','0.000350900000000','0.000344300000000','0.034248858719843','0.033604679558968','97.602903162846','97.602903162846005','test','test','1.88'),('2019-12-26 15:59:59','2020-01-01 15:59:59','EOSBTC','4h','0.000348400000000','0.000363100000000','0.034105707795204','0.035544725891041','97.89238747188224','97.892387471882245','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 18:55:16
