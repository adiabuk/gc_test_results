-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-23 03:59:59','2019-05-24 19:59:59','RENBTC','4h','0.000004700000000','0.000004090000000','0.033333333333333','0.029007092198581','7092.198581560284','7092.198581560283856','test','test','12.9'),('2019-05-29 23:59:59','2019-05-30 03:59:59','RENBTC','4h','0.000004040000000','0.000004020000000','0.032371946414500','0.032211689254032','8012.858023390978','8012.858023390977905','test','test','0.49'),('2019-05-30 07:59:59','2019-05-30 11:59:59','RENBTC','4h','0.000003910000000','0.000003970000000','0.032336333712173','0.032832543436656','8270.162074724638','8270.162074724637932','test','test','0.0'),('2019-05-30 23:59:59','2019-06-14 03:59:59','RENBTC','4h','0.000004260000000','0.000005810000000','0.032446602539836','0.044252291257382','7616.573366158738','7616.573366158738281','test','test','0.0'),('2019-06-14 07:59:59','2019-06-14 15:59:59','RENBTC','4h','0.000005740000000','0.000004600000000','0.035070088921513','0.028104949309923','6109.771589113781','6109.771589113781374','test','test','19.8'),('2019-06-16 11:59:59','2019-06-16 15:59:59','RENBTC','4h','0.000005820000000','0.000005230000000','0.033522280118938','0.030123973371486','5759.841944834631','5759.841944834631249','test','test','10.1'),('2019-06-16 19:59:59','2019-06-17 15:59:59','RENBTC','4h','0.000005610000000','0.000005250000000','0.032767100841726','0.030664399183433','5840.837939701603','5840.837939701603318','test','test','6.41'),('2019-06-18 07:59:59','2019-06-18 15:59:59','RENBTC','4h','0.000005440000000','0.000005330000000','0.032299833806550','0.031646712167079','5937.469449733416','5937.469449733415786','test','test','2.02'),('2019-06-20 03:59:59','2019-06-20 11:59:59','RENBTC','4h','0.000005590000000','0.000005250000000','0.032154695664445','0.030198953888790','5752.181693102882','5752.181693102881582','test','test','6.08'),('2019-06-20 23:59:59','2019-06-21 07:59:59','RENBTC','4h','0.000005450000000','0.000005310000000','0.031720086380966','0.030905258473932','5820.199335957104','5820.199335957104267','test','test','2.56'),('2019-06-22 15:59:59','2019-06-23 11:59:59','RENBTC','4h','0.000005430000000','0.000005400000000','0.031539013512736','0.031364764819295','5808.289781351094','5808.289781351093552','test','test','0.55'),('2019-06-23 15:59:59','2019-06-23 19:59:59','RENBTC','4h','0.000005400000000','0.000005340000000','0.031500291580861','0.031150288341074','5833.387329789012','5833.387329789012256','test','test','1.11'),('2019-06-23 23:59:59','2019-06-24 03:59:59','RENBTC','4h','0.000005420000000','0.000005240000000','0.031422513083130','0.030378960988118','5797.511638953915','5797.511638953915281','test','test','3.32'),('2019-06-25 11:59:59','2019-06-25 19:59:59','RENBTC','4h','0.000005380000000','0.000005340000000','0.031190612617572','0.030958712152014','5797.511638953903','5797.511638953902548','test','test','0.74'),('2019-06-26 03:59:59','2019-06-26 07:59:59','RENBTC','4h','0.000005360000000','0.000005220000000','0.031139079180781','0.030325745023074','5809.529697906964','5809.529697906964429','test','test','2.61'),('2019-06-26 15:59:59','2019-06-26 19:59:59','RENBTC','4h','0.000005510000000','0.000005170000000','0.030958338256846','0.029048023373483','5618.573186360515','5618.573186360515137','test','test','6.17'),('2019-06-26 23:59:59','2019-06-27 03:59:59','RENBTC','4h','0.000005420000000','0.000005250000000','0.030533823838321','0.029576120876602','5633.546833638622','5633.546833638622047','test','test','3.13'),('2019-06-27 07:59:59','2019-06-27 15:59:59','RENBTC','4h','0.000005640000000','0.000005580000000','0.030321000957939','0.029998437117961','5376.063999634633','5376.063999634632637','test','test','3.36'),('2019-06-27 19:59:59','2019-07-04 11:59:59','RENBTC','4h','0.000005710000000','0.000008320000000','0.030249320104611','0.044076067122656','5297.60422147301','5297.604221473009602','test','test','0.0'),('2019-07-04 15:59:59','2019-07-07 15:59:59','RENBTC','4h','0.000008260000000','0.000007790000000','0.033321930553065','0.031425888499803','4034.1320282161414','4034.132028216141407','test','test','5.69'),('2019-07-09 19:59:59','2019-07-10 03:59:59','RENBTC','4h','0.000008000000000','0.000008400000000','0.032900587874563','0.034545617268291','4112.573484320333','4112.573484320332682','test','test','0.0'),('2019-07-10 07:59:59','2019-07-10 11:59:59','RENBTC','4h','0.000008270000000','0.000007550000000','0.033266149962058','0.030369943435736','4022.509064335885','4022.509064335884887','test','test','8.70'),('2019-07-10 15:59:59','2019-07-13 03:59:59','RENBTC','4h','0.000007900000000','0.000008150000000','0.032622548511764','0.033654907641883','4129.4365204764545','4129.436520476454461','test','test','0.0'),('2019-07-13 07:59:59','2019-07-14 23:59:59','RENBTC','4h','0.000008590000000','0.000008000000000','0.032851961651790','0.030595540537173','3824.442567146733','3824.442567146732927','test','test','6.86'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBTC','4h','0.000007760000000','0.000007400000000','0.032350534737431','0.030849736734148','4168.883342452463','4168.883342452462784','test','test','4.63'),('2019-07-19 23:59:59','2019-07-30 11:59:59','RENBTC','4h','0.000007810000000','0.000010690000000','0.032017024070035','0.043823557914043','4099.4909180582445','4099.490918058244461','test','test','0.0'),('2019-08-02 11:59:59','2019-08-03 03:59:59','RENBTC','4h','0.000011380000000','0.000011070000000','0.034640698257592','0.033697058849872','3043.9980894193513','3043.998089419351345','test','test','2.72'),('2019-08-03 07:59:59','2019-08-03 15:59:59','RENBTC','4h','0.000011000000000','0.000010650000000','0.034431000611432','0.033335468773796','3130.0909646756563','3130.090964675656323','test','test','3.18'),('2019-08-04 15:59:59','2019-08-04 19:59:59','RENBTC','4h','0.000011240000000','0.000011550000000','0.034187549091958','0.035130444129192','3041.5968943022735','3041.596894302273540','test','test','0.0'),('2019-08-04 23:59:59','2019-08-05 19:59:59','RENBTC','4h','0.000011430000000','0.000011220000000','0.034397081322454','0.033765113949076','3009.3684446591424','3009.368444659142369','test','test','1.83'),('2019-08-05 23:59:59','2019-08-06 11:59:59','RENBTC','4h','0.000012070000000','0.000011800000000','0.034256644128370','0.033490339744388','2838.164385117647','2838.164385117646816','test','test','6.21'),('2019-08-06 15:59:59','2019-08-06 19:59:59','RENBTC','4h','0.000011220000000','0.000010830000000','0.034086354265263','0.032901534464599','3037.9994888826104','3037.999488882610422','test','test','3.47'),('2019-08-06 23:59:59','2019-08-07 03:59:59','RENBTC','4h','0.000011320000000','0.000010650000000','0.033823060976226','0.031821166024453','2987.9029130942085','2987.902913094208543','test','test','5.91'),('2019-08-09 19:59:59','2019-08-09 23:59:59','RENBTC','4h','0.000010980000000','0.000010690000000','0.033378195431388','0.032496621963710','3039.90850923388','3039.908509233880068','test','test','2.64'),('2019-08-15 23:59:59','2019-08-16 03:59:59','RENBTC','4h','0.000010240000000','0.000009880000000','0.033182290216348','0.032015725325930','3240.4580289402775','3240.458028940277472','test','test','3.51'),('2019-09-18 15:59:59','2019-09-18 19:59:59','RENBTC','4h','0.000004570000000','0.000004470000000','0.032923053574033','0.032202636646811','7204.169272217359','7204.169272217359321','test','test','2.18'),('2019-09-18 23:59:59','2019-09-19 03:59:59','RENBTC','4h','0.000004600000000','0.000004360000000','0.032762960923540','0.031053589049268','7122.38280946512','7122.382809465119863','test','test','5.21'),('2019-09-19 11:59:59','2019-09-22 23:59:59','RENBTC','4h','0.000004540000000','0.000004880000000','0.032383100507035','0.034808266624302','7132.841521373276','7132.841521373276009','test','test','0.0'),('2019-09-23 03:59:59','2019-09-23 07:59:59','RENBTC','4h','0.000004940000000','0.000004860000000','0.032922026310872','0.032388876087214','6664.37779572303','6664.377795723030431','test','test','1.61'),('2019-09-23 11:59:59','2019-09-23 15:59:59','RENBTC','4h','0.000004840000000','0.000004810000000','0.032803548483392','0.032600220703536','6777.592661857896','6777.592661857896019','test','test','0.61'),('2019-09-27 03:59:59','2019-09-27 11:59:59','RENBTC','4h','0.000004680000000','0.000004800000000','0.032758364532313','0.033598322597244','6999.650541092543','6999.650541092542881','test','test','0.0'),('2019-09-27 15:59:59','2019-09-27 23:59:59','RENBTC','4h','0.000004770000000','0.000004720000000','0.032945021880076','0.032599686220956','6906.713182405776','6906.713182405776024','test','test','1.04'),('2019-09-28 03:59:59','2019-09-28 07:59:59','RENBTC','4h','0.000004620000000','0.000004710000000','0.032868280622493','0.033508571803451','7114.346455085136','7114.346455085135858','test','test','0.0'),('2019-09-28 11:59:59','2019-09-29 07:59:59','RENBTC','4h','0.000004810000000','0.000004690000000','0.033010567551595','0.032187019088769','6862.90385688048','6862.903856880479907','test','test','2.49'),('2019-09-29 11:59:59','2019-09-30 07:59:59','RENBTC','4h','0.000004710000000','0.000004670000000','0.032827556782078','0.032548766490935','6969.75727857287','6969.757278572869836','test','test','0.84'),('2019-09-30 11:59:59','2019-09-30 15:59:59','RENBTC','4h','0.000004670000000','0.000004620000000','0.032765603384046','0.032414793925973','7016.189161466046','7016.189161466046244','test','test','1.07'),('2019-09-30 19:59:59','2019-10-01 03:59:59','RENBTC','4h','0.000004800000000','0.000004740000000','0.032687645726697','0.032279050155113','6809.9261930618495','6809.926193061849517','test','test','1.24'),('2019-10-01 07:59:59','2019-10-01 11:59:59','RENBTC','4h','0.000004720000000','0.000004730000000','0.032596846710789','0.032665907826702','6906.111591268926','6906.111591268925622','test','test','0.0'),('2019-10-01 15:59:59','2019-10-04 03:59:59','RENBTC','4h','0.000004820000000','0.000004850000000','0.032612193625437','0.032815174083687','6766.015274986859','6766.015274986859367','test','test','0.0'),('2019-10-04 07:59:59','2019-10-16 15:59:59','RENBTC','4h','0.000004960000000','0.000006740000000','0.032657300393937','0.044377057390148','6584.133143938843','6584.133143938843205','test','test','0.0'),('2019-10-16 19:59:59','2019-10-16 23:59:59','RENBTC','4h','0.000006790000000','0.000007120000000','0.035261690837539','0.036975440171322','5193.17979934302','5193.179799343020022','test','test','0.0'),('2019-10-17 03:59:59','2019-10-18 11:59:59','RENBTC','4h','0.000006830000000','0.000006870000000','0.035642524022824','0.035851265012709','5218.5247471192115','5218.524747119211497','test','test','0.0'),('2019-10-18 19:59:59','2019-10-18 23:59:59','RENBTC','4h','0.000006830000000','0.000006710000000','0.035688910909465','0.035061872943266','5225.316384987602','5225.316384987601850','test','test','1.75'),('2019-10-19 23:59:59','2019-10-20 03:59:59','RENBTC','4h','0.000006880000000','0.000006730000000','0.035549569139199','0.034774505858548','5167.088537674255','5167.088537674255349','test','test','2.18'),('2019-10-20 15:59:59','2019-10-20 19:59:59','RENBTC','4h','0.000006970000000','0.000006700000000','0.035377332854610','0.034006905326526','5075.657511421775','5075.657511421774871','test','test','3.87'),('2019-10-21 07:59:59','2019-10-21 11:59:59','RENBTC','4h','0.000006830000000','0.000006820000000','0.035072793403924','0.035021442315485','5135.108843912802','5135.108843912801603','test','test','0.14'),('2019-10-22 07:59:59','2019-10-22 11:59:59','RENBTC','4h','0.000006840000000','0.000006970000000','0.035061382050938','0.035727753347228','5125.933048382746','5125.933048382746165','test','test','0.0'),('2019-10-22 15:59:59','2019-10-23 15:59:59','RENBTC','4h','0.000007140000000','0.000006800000000','0.035209464561225','0.033532823391643','4931.29755759449','4931.297557594490172','test','test','4.76'),('2019-10-23 19:59:59','2019-10-23 23:59:59','RENBTC','4h','0.000006830000000','0.000006900000000','0.034836877634651','0.035193917376148','5100.567735673628','5100.567735673627794','test','test','0.0'),('2019-10-24 03:59:59','2019-10-24 07:59:59','RENBTC','4h','0.000006840000000','0.000007030000000','0.034916219799428','0.035886114793857','5104.710496992396','5104.710496992395747','test','test','0.0'),('2019-10-24 11:59:59','2019-10-25 15:59:59','RENBTC','4h','0.000007030000000','0.000006670000000','0.035131752020412','0.033332686483094','4997.404270328906','4997.404270328906023','test','test','5.12'),('2019-11-02 07:59:59','2019-11-02 11:59:59','RENBTC','4h','0.000006020000000','0.000005890000000','0.034731959678786','0.033981933971437','5769.428518070762','5769.428518070762038','test','test','2.15'),('2019-11-06 15:59:59','2019-11-10 19:59:59','RENBTC','4h','0.000006360000000','0.000006200000000','0.034565287299375','0.033695720323290','5434.7936005306765','5434.793600530676486','test','test','4.08'),('2019-11-10 23:59:59','2019-11-17 07:59:59','RENBTC','4h','0.000006180000000','0.000006610000000','0.034372050193578','0.036763632974037','5561.820419672886','5561.820419672885691','test','test','0.0'),('2019-11-17 11:59:59','2019-11-17 15:59:59','RENBTC','4h','0.000006520000000','0.000006570000000','0.034903513033680','0.035171178010932','5353.299545043011','5353.299545043010767','test','test','0.0'),('2019-11-17 19:59:59','2019-11-17 23:59:59','RENBTC','4h','0.000006540000000','0.000006580000000','0.034962994139736','0.035176835082487','5346.023568767039','5346.023568767039251','test','test','0.0'),('2019-11-18 03:59:59','2019-11-18 07:59:59','RENBTC','4h','0.000006530000000','0.000006430000000','0.035010514349237','0.034474365584318','5361.487649193974','5361.487649193973994','test','test','1.53'),('2019-11-22 03:59:59','2019-11-22 07:59:59','RENBTC','4h','0.000006440000000','0.000006370000000','0.034891370179255','0.034512116155567','5417.914624107866','5417.914624107866075','test','test','1.08'),('2019-11-23 19:59:59','2019-11-23 23:59:59','RENBTC','4h','0.000006410000000','0.000006420000000','0.034807091507324','0.034861392742125','5430.1234800817465','5430.123480081746493','test','test','0.0'),('2019-11-24 03:59:59','2019-11-24 07:59:59','RENBTC','4h','0.000006360000000','0.000006440000000','0.034819158448391','0.035257135284220','5474.7104478602005','5474.710447860200475','test','test','0.0'),('2019-12-14 19:59:59','2019-12-15 03:59:59','RENBTC','4h','0.000005310000000','0.000004920000000','0.034916486634131','0.032351998915240','6575.609535617826','6575.609535617825713','test','test','7.34'),('2019-12-15 07:59:59','2019-12-15 11:59:59','RENBTC','4h','0.000005010000000','0.000004970000000','0.034346600474377','0.034072376119292','6855.608877121177','6855.608877121177102','test','test','0.79'),('2019-12-15 23:59:59','2019-12-16 07:59:59','RENBTC','4h','0.000005050000000','0.000004910000000','0.034285661728803','0.033335168136321','6789.2399462975545','6789.239946297554525','test','test','2.77'),('2019-12-24 15:59:59','2019-12-25 15:59:59','RENBTC','4h','0.000004810000000','0.000004570000000','0.034074440930473','0.032374260925626','7084.083353528759','7084.083353528759289','test','test','4.98'),('2019-12-31 11:59:59','2019-12-31 15:59:59','RENBTC','4h','0.000004500000000','0.000004480000000','0.033696623151618','0.033546860382055','7488.13847813743','7488.138478137429956','test','test','0.44'),('2020-01-02 03:59:59','2020-01-05 03:59:59','RENBTC','4h','0.000004540000000','0.000004670000000','0.033663342536160','0.034627270846667','7414.8331577444915','7414.833157744491473','test','test','0.66'),('2020-01-05 07:59:59','2020-01-05 15:59:59','RENBTC','4h','0.000004710000000','0.000004670000000','0.033877548827384','0.033589841406345','7192.685525983815','7192.685525983814841','test','test','0.84'),('2020-01-05 19:59:59','2020-01-07 19:59:59','RENBTC','4h','0.000004830000000','0.000004830000000','0.033813613844931','0.033813613844931','7000.748208060178','7000.748208060177603','test','test','0.82'),('2020-01-07 23:59:59','2020-01-08 03:59:59','RENBTC','4h','0.000004750000000','0.000004560000000','0.033813613844931','0.032461069291134','7118.655546301191','7118.655546301190952','test','test','3.99'),('2020-01-08 19:59:59','2020-01-13 07:59:59','RENBTC','4h','0.000005090000000','0.000005400000000','0.033513048388531','0.035554118133216','6584.095950595544','6584.095950595544309','test','test','2.35'),('2020-01-13 11:59:59','2020-01-14 07:59:59','RENBTC','4h','0.000005590000000','0.000005290000000','0.033966619442906','0.032143723945076','6076.31832610121','6076.318326101210005','test','test','5.36'),('2020-01-14 11:59:59','2020-01-14 15:59:59','RENBTC','4h','0.000005230000000','0.000004990000000','0.033561531554499','0.032021423031922','6417.118844072486','6417.118844072486354','test','test','4.58'),('2020-01-15 07:59:59','2020-01-15 11:59:59','RENBTC','4h','0.000005240000000','0.000005330000000','0.033219285216149','0.033789845458411','6339.558247356614','6339.558247356613720','test','test','0.0'),('2020-01-15 15:59:59','2020-01-15 19:59:59','RENBTC','4h','0.000005200000000','0.000005270000000','0.033346076381096','0.033794965870842','6412.706996364571','6412.706996364570841','test','test','0.0'),('2020-01-15 23:59:59','2020-01-16 03:59:59','RENBTC','4h','0.000005260000000','0.000005250000000','0.033445829601039','0.033382244373661','6358.522737840177','6358.522737840176887','test','test','0.19'),('2020-01-16 07:59:59','2020-01-16 11:59:59','RENBTC','4h','0.000005230000000','0.000005120000000','0.033431699550511','0.032728547169908','6392.294369122538','6392.294369122538228','test','test','2.10'),('2020-01-26 07:59:59','2020-01-26 11:59:59','RENBTC','4h','0.000004930000000','0.000004890000000','0.033275443465932','0.033005460151807','6749.582853130312','6749.582853130312287','test','test','0.81'),('2020-02-02 11:59:59','2020-02-02 15:59:59','RENBTC','4h','0.000004780000000','0.000004770000000','0.033215447173905','0.033145958790696','6948.838320900556','6948.838320900556027','test','test','0.20'),('2020-02-02 19:59:59','2020-02-10 11:59:59','RENBTC','4h','0.000004890000000','0.000005710000000','0.033200005310969','0.038767286365160','6789.367139257531','6789.367139257530653','test','test','0.20'),('2020-02-10 15:59:59','2020-02-16 15:59:59','RENBTC','4h','0.000005710000000','0.000005840000000','0.034437178878567','0.035221212723438','6031.029575931229','6031.029575931229374','test','test','0.52');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 19:19:58
