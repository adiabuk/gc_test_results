-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 07:59:59','2019-01-14 15:59:59','LTCETH','4h','0.232610000000000','0.251430000000000','1.297777777777778','1.402778327099723','5.579200282781383','5.579200282781383','test','test','0.0'),('2019-01-15 19:59:59','2019-01-16 15:59:59','LTCETH','4h','0.253570000000000','0.256340000000000','1.321111233182654','1.335543059171201','5.2100454832300915','5.210045483230092','test','test','0.84'),('2019-01-16 19:59:59','2019-01-17 11:59:59','LTCETH','4h','0.257580000000000','0.254460000000000','1.324318305624554','1.308277180096374','5.141386387237184','5.141386387237184','test','test','1.49'),('2019-01-17 15:59:59','2019-02-13 15:59:59','LTCETH','4h','0.255040000000000','0.338760000000000','1.320753611062736','1.754307141168493','5.178613594192033','5.178613594192033','test','test','0.22'),('2019-02-13 19:59:59','2019-02-13 23:59:59','LTCETH','4h','0.341570000000000','0.341510000000000','1.417098839975126','1.416849913165399','4.148780162119409','4.148780162119409','test','test','24.9'),('2019-02-14 15:59:59','2019-02-17 11:59:59','LTCETH','4h','0.341340000000000','0.342220000000000','1.417043522906298','1.420696766886369','4.151413613717403','4.151413613717403','test','test','0.0'),('2019-02-20 11:59:59','2019-02-21 11:59:59','LTCETH','4h','0.346600000000000','0.337550000000000','1.417855354901869','1.380834030718771','4.090754053381042','4.090754053381042','test','test','1.65'),('2019-02-27 23:59:59','2019-02-28 03:59:59','LTCETH','4h','0.335070000000000','0.334360000000000','1.409628393972292','1.406641447484333','4.206966884448898','4.206966884448898','test','test','0.0'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LTCETH','4h','0.333050000000000','0.335310000000000','1.408964628086079','1.418525535035410','4.230489800588737','4.230489800588737','test','test','0.0'),('2019-02-28 15:59:59','2019-03-20 11:59:59','LTCETH','4h','0.336440000000000','0.432480000000000','1.411089274074819','1.813898137117696','4.194178082495599','4.194178082495599','test','test','0.61'),('2019-03-20 15:59:59','2019-03-29 07:59:59','LTCETH','4h','0.434530000000000','0.433750000000000','1.500602354751014','1.497908709118478','3.453391836584388','3.453391836584388','test','test','22.3'),('2019-03-29 11:59:59','2019-03-29 15:59:59','LTCETH','4h','0.435560000000000','0.432430000000000','1.500003766832673','1.489224513021060','3.443851058023401','3.443851058023401','test','test','21.5'),('2019-04-02 07:59:59','2019-04-08 07:59:59','LTCETH','4h','0.448070000000000','0.493540000000000','1.497608377096759','1.649585195242561','3.342353598983995','3.342353598983995','test','test','3.49'),('2019-04-08 11:59:59','2019-04-08 15:59:59','LTCETH','4h','0.498490000000000','0.489790000000000','1.531381003351381','1.504654259125505','3.0720395661926645','3.072039566192664','test','test','0.99'),('2019-04-08 23:59:59','2019-04-09 03:59:59','LTCETH','4h','0.495640000000000','0.490560000000000','1.525441726856742','1.509806903250027','3.0777211824242237','3.077721182424224','test','test','1.18'),('2019-04-09 11:59:59','2019-04-09 15:59:59','LTCETH','4h','0.498480000000000','0.493150000000000','1.521967321610806','1.505693678086120','3.0532164211418826','3.053216421141883','test','test','1.58'),('2019-04-10 19:59:59','2019-04-10 23:59:59','LTCETH','4h','0.496650000000000','0.498150000000000','1.518350956383098','1.522936733962026','3.057185052618741','3.057185052618741','test','test','0.70'),('2019-04-11 03:59:59','2019-04-11 07:59:59','LTCETH','4h','0.499910000000000','0.493730000000000','1.519370018067304','1.500587223741013','3.039287107814014','3.039287107814014','test','test','0.35'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCETH','4h','0.499060000000000','0.485620000000000','1.515196063772573','1.474390879832559','3.036099995536754','3.036099995536754','test','test','1.06'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LTCETH','4h','0.493240000000000','0.484090000000000','1.506128245119236','1.478188350863213','3.053540355849558','3.053540355849558','test','test','1.54'),('2019-04-15 23:59:59','2019-04-16 03:59:59','LTCETH','4h','0.488330000000000','0.485630000000000','1.499919379729009','1.491626253512581','3.0715282283066956','3.071528228306696','test','test','0.86'),('2019-04-26 03:59:59','2019-04-27 07:59:59','LTCETH','4h','0.471700000000000','0.464160000000000','1.498076462792025','1.474130105935014','3.1759093974815022','3.175909397481502','test','test','0.0'),('2019-04-27 11:59:59','2019-04-27 15:59:59','LTCETH','4h','0.462750000000000','0.460580000000000','1.492755050157133','1.485754988657747','3.2258347923438864','3.225834792343886','test','test','0.0'),('2019-04-30 19:59:59','2019-05-01 03:59:59','LTCETH','4h','0.458280000000000','0.454640000000000','1.491199480935048','1.479355267548901','3.253904776414087','3.253904776414087','test','test','0.0'),('2019-05-01 07:59:59','2019-05-01 11:59:59','LTCETH','4h','0.456280000000000','0.455070000000000','1.488567433515904','1.484619930678711','3.2623990390021564','3.262399039002156','test','test','0.35'),('2019-05-01 15:59:59','2019-05-01 19:59:59','LTCETH','4h','0.456830000000000','0.456850000000000','1.487690210663194','1.487755341683953','3.2565510379423293','3.256551037942329','test','test','0.38'),('2019-05-01 23:59:59','2019-05-02 03:59:59','LTCETH','4h','0.457610000000000','0.457490000000000','1.487704684223363','1.487314560401535','3.2510318485683505','3.251031848568350','test','test','0.16'),('2019-05-02 07:59:59','2019-05-02 15:59:59','LTCETH','4h','0.458290000000000','0.456460000000000','1.487617990040735','1.481677775500216','3.246018874600656','3.246018874600656','test','test','0.17'),('2019-05-03 03:59:59','2019-05-03 11:59:59','LTCETH','4h','0.460070000000000','0.470640000000000','1.486297942365064','1.520445287879439','3.2305908717479164','3.230590871747916','test','test','0.78'),('2019-05-03 15:59:59','2019-05-06 03:59:59','LTCETH','4h','0.468990000000000','0.449870000000000','1.493886241368258','1.432982800068953','3.1853264277879236','3.185326427787924','test','test','1.79'),('2019-05-11 11:59:59','2019-05-12 03:59:59','LTCETH','4h','0.457700000000000','0.457310000000000','1.480352143301746','1.479090755196245','3.23432847564288','3.234328475642880','test','test','1.71'),('2019-05-12 07:59:59','2019-05-13 07:59:59','LTCETH','4h','0.458300000000000','0.452100000000000','1.480071834833857','1.460049043265081','3.229482511092858','3.229482511092858','test','test','1.79'),('2019-05-13 11:59:59','2019-05-13 15:59:59','LTCETH','4h','0.453940000000000','0.449710000000000','1.475622325596351','1.461871868625666','3.2506990474431667','3.250699047443167','test','test','0.40'),('2019-05-24 11:59:59','2019-05-30 23:59:59','LTCETH','4h','0.395420000000000','0.424110000000000','1.472566668491755','1.579409867417020','3.7240571253142347','3.724057125314235','test','test','0.0'),('2019-05-31 03:59:59','2019-06-04 07:59:59','LTCETH','4h','0.423760000000000','0.418310000000000','1.496309601586258','1.477065483857720','3.531030775878464','3.531030775878464','test','test','0.0'),('2019-06-04 11:59:59','2019-06-04 19:59:59','LTCETH','4h','0.423440000000000','0.421230000000000','1.492033130979916','1.484245975256636','3.523599874787257','3.523599874787257','test','test','1.21'),('2019-06-04 23:59:59','2019-06-05 19:59:59','LTCETH','4h','0.423070000000000','0.420430000000000','1.490302651930298','1.481003011206314','3.522591183327341','3.522591183327341','test','test','0.53'),('2019-06-05 23:59:59','2019-06-16 11:59:59','LTCETH','4h','0.421700000000000','0.497010000000000','1.488236065102746','1.754015192593587','3.5291346101559067','3.529134610155907','test','test','0.30'),('2019-06-16 15:59:59','2019-06-17 15:59:59','LTCETH','4h','0.496180000000000','0.491360000000000','1.547298093434044','1.532267304586545','3.118420922717651','3.118420922717651','test','test','15.1'),('2019-06-18 15:59:59','2019-06-20 19:59:59','LTCETH','4h','0.500760000000000','0.499320000000000','1.543957918134600','1.539518067902725','3.0832293276911096','3.083229327691110','test','test','15.3'),('2019-06-20 23:59:59','2019-06-21 03:59:59','LTCETH','4h','0.499180000000000','0.491820000000000','1.542971284749739','1.520221437689043','3.091011828898872','3.091011828898872','test','test','9.91'),('2019-06-30 15:59:59','2019-06-30 19:59:59','LTCETH','4h','0.448450000000000','0.428210000000000','1.537915763180695','1.468504647009935','3.4294029728636306','3.429402972863631','test','test','0.0'),('2019-07-15 03:59:59','2019-07-15 07:59:59','LTCETH','4h','0.401160000000000','0.392760000000000','1.522491070698304','1.490611209810215','3.7952215342963016','3.795221534296302','test','test','0.0'),('2019-07-15 11:59:59','2019-07-15 15:59:59','LTCETH','4h','0.391000000000000','0.398590000000000','1.515406657167618','1.544823374630283','3.8757203508123212','3.875720350812321','test','test','0.0'),('2019-07-15 19:59:59','2019-07-15 23:59:59','LTCETH','4h','0.394400000000000','0.396490000000000','1.521943705492655','1.530008772289003','3.8588836346162645','3.858883634616264','test','test','0.41'),('2019-07-16 03:59:59','2019-07-16 07:59:59','LTCETH','4h','0.390920000000000','0.395720000000000','1.523735942558510','1.542445480377708','3.897820378999564','3.897820378999564','test','test','0.0'),('2019-07-16 11:59:59','2019-07-16 19:59:59','LTCETH','4h','0.399550000000000','0.390380000000000','1.527893617629442','1.492827206733028','3.8240360846688586','3.824036084668859','test','test','0.95'),('2019-07-16 23:59:59','2019-07-17 11:59:59','LTCETH','4h','0.400020000000000','0.401060000000000','1.520101081874684','1.524053147084298','3.8000627015516315','3.800062701551632','test','test','2.40'),('2019-07-17 15:59:59','2019-07-23 19:59:59','LTCETH','4h','0.421170000000000','0.428760000000000','1.520979318587931','1.548389231516398','3.611319226411975','3.611319226411975','test','test','5.85'),('2019-07-23 23:59:59','2019-07-24 03:59:59','LTCETH','4h','0.424760000000000','0.432000000000000','1.527070410349813','1.553099202540538','3.5951370429179135','3.595137042917913','test','test','0.0'),('2019-07-24 07:59:59','2019-07-25 07:59:59','LTCETH','4h','0.432370000000000','0.426120000000000','1.532854586392196','1.510696848424827','3.545238074779','3.545238074779000','test','test','0.96'),('2019-07-25 11:59:59','2019-07-25 15:59:59','LTCETH','4h','0.428780000000000','0.426190000000000','1.527930644621670','1.518701342019939','3.5634372979655526','3.563437297965553','test','test','0.62'),('2019-07-25 19:59:59','2019-07-25 23:59:59','LTCETH','4h','0.425190000000000','0.425530000000000','1.525879688487952','1.527099846756222','3.5887007890306726','3.588700789030673','test','test','0.0'),('2019-07-26 03:59:59','2019-07-26 07:59:59','LTCETH','4h','0.427200000000000','0.427260000000000','1.526150834769790','1.526365181797145','3.5724504559217922','3.572450455921792','test','test','0.39'),('2019-07-26 11:59:59','2019-07-26 19:59:59','LTCETH','4h','0.430430000000000','0.427550000000000','1.526198467442535','1.515986698778096','3.545753008485782','3.545753008485782','test','test','0.98'),('2019-07-26 23:59:59','2019-07-27 03:59:59','LTCETH','4h','0.429760000000000','0.424520000000000','1.523929185517104','1.505348142767407','3.546000524751267','3.546000524751267','test','test','0.51'),('2019-07-27 07:59:59','2019-07-27 11:59:59','LTCETH','4h','0.425710000000000','0.431760000000000','1.519800064906060','1.541398783265229','3.570036092424562','3.570036092424562','test','test','0.27'),('2019-07-27 15:59:59','2019-07-27 19:59:59','LTCETH','4h','0.426660000000000','0.424470000000000','1.524599780096987','1.516774173013097','3.573336567986188','3.573336567986188','test','test','0.0'),('2019-07-27 23:59:59','2019-07-28 03:59:59','LTCETH','4h','0.428250000000000','0.426110000000000','1.522860756300567','1.515250897530028','3.5560087712797825','3.556008771279783','test','test','0.88'),('2019-07-28 07:59:59','2019-07-28 11:59:59','LTCETH','4h','0.427600000000000','0.425300000000000','1.521169676573781','1.512987519754044','3.5574594868423306','3.557459486842331','test','test','0.34'),('2019-07-28 15:59:59','2019-07-28 23:59:59','LTCETH','4h','0.427570000000000','0.425470000000000','1.519351419502728','1.511889160735846','3.553456555658086','3.553456555658086','test','test','0.53'),('2019-07-29 07:59:59','2019-07-29 11:59:59','LTCETH','4h','0.426500000000000','0.426630000000000','1.517693139776754','1.518155742609511','3.55848332890212','3.558483328902120','test','test','0.24'),('2019-07-29 15:59:59','2019-07-29 19:59:59','LTCETH','4h','0.426500000000000','0.430430000000000','1.517795940406256','1.531781727149038','3.55872436203108','3.558724362031080','test','test','0.0'),('2019-07-29 23:59:59','2019-08-02 19:59:59','LTCETH','4h','0.428280000000000','0.430160000000000','1.520903893015763','1.527580131268471','3.5511905599508795','3.551190559950880','test','test','0.38'),('2019-08-02 23:59:59','2019-08-03 03:59:59','LTCETH','4h','0.435140000000000','0.432120000000000','1.522387501516364','1.511821683033624','3.4986153916357132','3.498615391635713','test','test','1.14'),('2019-08-11 15:59:59','2019-08-11 23:59:59','LTCETH','4h','0.421110000000000','0.415980000000000','1.520039541853533','1.501522283061985','3.609602103615524','3.609602103615524','test','test','0.0'),('2019-08-26 19:59:59','2019-08-26 23:59:59','LTCETH','4h','0.393910000000000','0.390000000000000','1.515924595455411','1.500877338040695','3.8484034308735793','3.848403430873579','test','test','0.0'),('2019-09-01 19:59:59','2019-09-02 03:59:59','LTCETH','4h','0.389520000000000','0.385320000000000','1.512580760474364','1.496271356094634','3.8831915189832706','3.883191518983271','test','test','0.0'),('2019-09-03 23:59:59','2019-09-04 03:59:59','LTCETH','4h','0.386390000000000','0.379910000000000','1.508956448389979','1.483650312657773','3.9052678599083284','3.905267859908328','test','test','0.27'),('2019-09-06 23:59:59','2019-09-07 03:59:59','LTCETH','4h','0.384260000000000','0.382010000000000','1.503332862671711','1.494530231794151','3.9122803900268335','3.912280390026833','test','test','1.13'),('2019-09-07 11:59:59','2019-09-08 11:59:59','LTCETH','4h','0.390620000000000','0.385720000000000','1.501376722476698','1.482543211801014','3.843573607282519','3.843573607282519','test','test','2.20'),('2019-09-08 15:59:59','2019-09-09 07:59:59','LTCETH','4h','0.389400000000000','0.386870000000000','1.497191497882101','1.487463982500381','3.844867739810223','3.844867739810223','test','test','0.95'),('2019-09-09 11:59:59','2019-09-09 15:59:59','LTCETH','4h','0.385590000000000','0.383420000000000','1.495029827797275','1.486616189667862','3.8772525941992133','3.877252594199213','test','test','0.0'),('2019-09-09 19:59:59','2019-09-09 23:59:59','LTCETH','4h','0.385780000000000','0.386800000000000','1.493160130435183','1.497108036840502','3.870496475802745','3.870496475802745','test','test','0.61'),('2019-09-10 03:59:59','2019-09-11 23:59:59','LTCETH','4h','0.393820000000000','0.391000000000000','1.494037442969698','1.483339191003890','3.7937063708539385','3.793706370853938','test','test','2.05'),('2019-09-12 03:59:59','2019-09-12 07:59:59','LTCETH','4h','0.389910000000000','0.386670000000000','1.491660053643963','1.479264940479883','3.825652211135809','3.825652211135809','test','test','0.0'),('2019-09-12 11:59:59','2019-09-12 15:59:59','LTCETH','4h','0.387070000000000','0.386100000000000','1.488905584051945','1.485174376734069','3.8466054823467206','3.846605482346721','test','test','0.10'),('2019-10-18 03:59:59','2019-10-18 07:59:59','LTCETH','4h','0.309780000000000','0.307180000000000','1.488076426870195','1.475586922351303','4.803655584189408','4.803655584189408','test','test','0.0'),('2019-10-18 11:59:59','2019-10-18 15:59:59','LTCETH','4h','0.310600000000000','0.308760000000000','1.485300981421552','1.476502031628198','4.782037931170484','4.782037931170484','test','test','1.10'),('2019-10-19 19:59:59','2019-10-20 11:59:59','LTCETH','4h','0.314200000000000','0.310500000000000','1.483345659245251','1.465877871405635','4.721023740436829','4.721023740436829','test','test','1.73'),('2019-10-20 15:59:59','2019-10-21 11:59:59','LTCETH','4h','0.312500000000000','0.311750000000000','1.479463928614226','1.475913215185552','4.734284571565523','4.734284571565523','test','test','0.65'),('2019-10-21 15:59:59','2019-10-22 23:59:59','LTCETH','4h','0.314380000000000','0.311540000000000','1.478674881185632','1.465317044610254','4.703463582879419','4.703463582879419','test','test','1.23'),('2019-10-23 03:59:59','2019-10-23 15:59:59','LTCETH','4h','0.315060000000000','0.305550000000000','1.475706473057770','1.431162676451475','4.683890284573636','4.683890284573636','test','test','1.11'),('2019-10-25 19:59:59','2019-10-26 03:59:59','LTCETH','4h','0.314080000000000','0.314510000000000','1.465807851589704','1.467814656786417','4.666988829564773','4.666988829564773','test','test','2.71'),('2019-10-26 07:59:59','2019-10-26 11:59:59','LTCETH','4h','0.314360000000000','0.310800000000000','1.466253808300085','1.449649076280909','4.66425056718439','4.664250567184390','test','test','0.0'),('2019-10-26 19:59:59','2019-10-29 19:59:59','LTCETH','4h','0.313220000000000','0.311810000000000','1.462563867851379','1.455979949028601','4.669445973601237','4.669445973601237','test','test','0.77'),('2019-10-30 03:59:59','2019-10-30 07:59:59','LTCETH','4h','0.315060000000000','0.316810000000000','1.461100774779651','1.469216455462265','4.63753181863661','4.637531818636610','test','test','1.03'),('2019-10-30 11:59:59','2019-10-30 15:59:59','LTCETH','4h','0.318270000000000','0.317700000000000','1.462904259375787','1.460284296992137','4.596425234473206','4.596425234473206','test','test','1.18'),('2019-10-30 19:59:59','2019-11-01 23:59:59','LTCETH','4h','0.317160000000000','0.318490000000000','1.462322045512754','1.468454244782939','4.610676142996449','4.610676142996449','test','test','0.0'),('2019-11-02 03:59:59','2019-11-03 03:59:59','LTCETH','4h','0.318440000000000','0.317290000000000','1.463684756461684','1.458398870674940','4.596422423256136','4.596422423256136','test','test','0.70'),('2019-11-03 07:59:59','2019-11-03 11:59:59','LTCETH','4h','0.316590000000000','0.317360000000000','1.462510115175741','1.466067185167482','4.6195714178456075','4.619571417845608','test','test','0.0'),('2019-11-03 15:59:59','2019-11-08 15:59:59','LTCETH','4h','0.319290000000000','0.328600000000000','1.463300575173905','1.505968144953319','4.582982790484842','4.582982790484842','test','test','0.62'),('2019-11-08 19:59:59','2019-11-11 11:59:59','LTCETH','4h','0.328210000000000','0.331400000000000','1.472782257347109','1.487096798040376','4.48731683174525','4.487316831745250','test','test','3.20'),('2019-11-11 15:59:59','2019-11-12 15:59:59','LTCETH','4h','0.333880000000000','0.330240000000000','1.475963266390057','1.459872136973321','4.42063994965274','4.420639949652740','test','test','1.27'),('2019-11-12 19:59:59','2019-11-12 23:59:59','LTCETH','4h','0.330800000000000','0.328210000000000','1.472387459853004','1.460859396004699','4.4509899028204485','4.450989902820448','test','test','0.16'),('2019-11-25 07:59:59','2019-11-25 11:59:59','LTCETH','4h','0.320120000000000','0.317430000000000','1.469825667886714','1.457474577524927','4.5914834058687815','4.591483405868781','test','test','0.0'),('2019-11-26 15:59:59','2019-11-26 19:59:59','LTCETH','4h','0.320020000000000','0.320920000000000','1.467080981139650','1.471206888529893','4.584341544714862','4.584341544714862','test','test','0.80'),('2019-11-26 23:59:59','2019-11-27 03:59:59','LTCETH','4h','0.318040000000000','0.316600000000000','1.467997849448593','1.461351148080193','4.615764839166751','4.615764839166751','test','test','0.0'),('2019-12-01 15:59:59','2019-12-01 19:59:59','LTCETH','4h','0.315680000000000','0.315390000000000','1.466520804700060','1.465173582724125','4.645593020463951','4.645593020463951','test','test','0.0'),('2019-12-13 19:59:59','2019-12-14 11:59:59','LTCETH','4h','0.306020000000000','0.305800000000000','1.466221422038741','1.465167344812257','4.791260120380175','4.791260120380175','test','test','0.0'),('2019-12-14 15:59:59','2019-12-14 19:59:59','LTCETH','4h','0.307030000000000','0.304520000000000','1.465987182655078','1.454002595388478','4.774735962788907','4.774735962788907','test','test','0.40'),('2019-12-15 03:59:59','2019-12-15 07:59:59','LTCETH','4h','0.307010000000000','0.304930000000000','1.463323941040278','1.453409886783531','4.766372238820487','4.766372238820487','test','test','0.81'),('2019-12-18 15:59:59','2019-12-29 23:59:59','LTCETH','4h','0.309940000000000','0.321130000000000','1.461120817872112','1.513872776160777','4.714205387727019','4.714205387727019','test','test','1.61'),('2019-12-30 03:59:59','2019-12-30 07:59:59','LTCETH','4h','0.320520000000000','0.323710000000000','1.472843475269593','1.487502063457881','4.595168711062003','4.595168711062003','test','test','1.60'),('2019-12-30 11:59:59','2019-12-30 19:59:59','LTCETH','4h','0.322970000000000','0.320720000000000','1.476100939311435','1.465817547313879','4.570396443358315','4.570396443358315','test','test','1.97'),('2019-12-30 23:59:59','2019-12-31 15:59:59','LTCETH','4h','0.321860000000000','0.320660000000000','1.473815741089756','1.468320870993106','4.57905841387484','4.579058413874840','test','test','0.49'),('2019-12-31 19:59:59','2019-12-31 23:59:59','LTCETH','4h','0.320510000000000','0.319880000000000','1.472594658846056','1.469700101312522','4.594535767514448','4.594535767514448','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 21:45:11
