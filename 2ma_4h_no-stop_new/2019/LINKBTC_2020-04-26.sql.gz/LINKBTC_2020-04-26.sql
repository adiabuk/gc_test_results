-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-08 07:59:59','LINKBTC','4h','0.000079050000000','0.000092190000000','0.033333333333333','0.038874130297280','421.67404596247104','421.674045962471041','test','test','0.0'),('2019-01-08 11:59:59','2019-01-10 11:59:59','LINKBTC','4h','0.000093480000000','0.000093490000000','0.034564621547544','0.034568319089430','369.7541885702158','369.754188570215774','test','test','16.2'),('2019-01-10 15:59:59','2019-01-25 15:59:59','LINKBTC','4h','0.000095170000000','0.000137160000000','0.034565443223518','0.049816078517786','363.1968395872485','363.196839587248519','test','test','1.76'),('2019-01-25 19:59:59','2019-01-25 23:59:59','LINKBTC','4h','0.000133500000000','0.000132620000000','0.037954473288911','0.037704286498692','284.3031707034557','284.303170703455692','test','test','0.0'),('2019-01-26 07:59:59','2019-01-26 11:59:59','LINKBTC','4h','0.000134290000000','0.000133370000000','0.037898876224418','0.037639236890689','282.2166670967177','282.216667096717686','test','test','1.24'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.037841178594701','0.037841178594701','286.39354116930804','286.393541169308037','test','test','0.0'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120220000000','0.037841178594701','0.037393280376911','311.0404290210477','311.040429021047714','test','test','0.0'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.037741645657414','0.037493753075099','309.8657278933826','309.865727893382598','test','test','1.29'),('2019-02-08 23:59:59','2019-02-09 03:59:59','LINKBTC','4h','0.000119860000000','0.000119390000000','0.037686558416900','0.037538780321990','314.42147853245086','314.421478532450863','test','test','0.0'),('2019-02-09 11:59:59','2019-02-10 23:59:59','LINKBTC','4h','0.000121430000000','0.000122400000000','0.037653718840253','0.037954502067421','310.08580120442144','310.085801204421443','test','test','1.67'),('2019-02-11 03:59:59','2019-02-11 07:59:59','LINKBTC','4h','0.000120660000000','0.000122680000000','0.037720559557401','0.038352049117371','312.61859404443334','312.618594044433337','test','test','0.0'),('2019-02-11 11:59:59','2019-02-11 15:59:59','LINKBTC','4h','0.000122200000000','0.000116360000000','0.037860890570728','0.036051499401063','309.8272550796072','309.827255079607198','test','test','0.98'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000119920000000','0.037458803644136','0.036669875371468','305.7861521970267','305.786152197026695','test','test','5.01'),('2019-02-14 07:59:59','2019-02-14 11:59:59','LINKBTC','4h','0.000122150000000','0.000121410000000','0.037283486250210','0.037057618220532','305.22706713229275','305.227067132292746','test','test','1.82'),('2019-02-14 15:59:59','2019-02-14 19:59:59','LINKBTC','4h','0.000120100000000','0.000118900000000','0.037233293354726','0.036861270440274','310.01909537656576','310.019095376565758','test','test','0.0'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.037150621595958','0.037082918342553','307.7420609340494','307.742060934049391','test','test','1.50'),('2019-02-16 11:59:59','2019-02-16 15:59:59','LINKBTC','4h','0.000120740000000','0.000122290000000','0.037135576428535','0.037612304467828','307.56647696318623','307.566476963186233','test','test','0.19'),('2019-02-16 19:59:59','2019-02-16 23:59:59','LINKBTC','4h','0.000120700000000','0.000121120000000','0.037241515992822','0.037371105360817','308.546114273591','308.546114273591002','test','test','0.0'),('2019-02-17 11:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000123660000000','0.000121060000000','0.037270313630155','0.036486690668499','301.39344679083507','301.393446790835071','test','test','2.05'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120250000000','0.037096175194231','0.036615078938737','304.49130094583523','304.491300945835235','test','test','0.63'),('2019-02-19 11:59:59','2019-02-19 15:59:59','LINKBTC','4h','0.000121500000000','0.000117220000000','0.036989264915232','0.035686268587354','304.43839436405307','304.438394364053067','test','test','1.02'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000116640000000','0.036699710175704','0.035642416277220','305.57627123816815','305.576271238168147','test','test','2.39'),('2019-02-25 23:59:59','2019-02-26 07:59:59','LINKBTC','4h','0.000123280000000','0.000115600000000','0.036464755976041','0.034193103429837','295.7880919536088','295.788091953608784','test','test','5.38'),('2019-02-26 11:59:59','2019-02-26 15:59:59','LINKBTC','4h','0.000115600000000','0.000114760000000','0.035959944299107','0.035698643665792','311.0721825182237','311.072182518223713','test','test','0.0'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.035901877491703','0.038372805215212','319.2413079468552','319.241307946855216','test','test','0.0'),('2019-03-07 23:59:59','2019-03-16 03:59:59','LINKBTC','4h','0.000116660000000','0.000121660000000','0.036450972541372','0.038013246351649','312.454762055306','312.454762055305991','test','test','1.62'),('2019-03-20 07:59:59','2019-03-20 11:59:59','LINKBTC','4h','0.000121190000000','0.000119350000000','0.036798144499211','0.036239446703365','303.6401064379184','303.640106437918405','test','test','0.0'),('2019-03-25 23:59:59','2019-03-26 15:59:59','LINKBTC','4h','0.000120260000000','0.000115800000000','0.036673989433468','0.035313886382801','304.955840956825','304.955840956825000','test','test','1.37'),('2019-03-27 15:59:59','2019-03-30 11:59:59','LINKBTC','4h','0.000118130000000','0.000119090000000','0.036371744311097','0.036667324388458','307.8959139176952','307.895913917695225','test','test','1.97'),('2019-03-30 15:59:59','2019-03-31 03:59:59','LINKBTC','4h','0.000121180000000','0.000120800000000','0.036437428772733','0.036323167154202','300.6884698195504','300.688469819550392','test','test','1.72'),('2019-03-31 07:59:59','2019-04-02 07:59:59','LINKBTC','4h','0.000122840000000','0.000127310000000','0.036412037301948','0.037737027588009','296.4184085147219','296.418408514721875','test','test','2.84'),('2019-04-02 11:59:59','2019-04-02 15:59:59','LINKBTC','4h','0.000122240000000','0.000124270000000','0.036706479587740','0.037316052179061','300.2820646902796','300.282064690279583','test','test','0.67'),('2019-04-02 19:59:59','2019-04-02 23:59:59','LINKBTC','4h','0.000122500000000','0.000119940000000','0.036841940163589','0.036072018801803','300.75053194766434','300.750531947664342','test','test','0.0'),('2019-05-01 03:59:59','2019-05-01 07:59:59','LINKBTC','4h','0.000089060000000','0.000089820000000','0.036670846527636','0.036983779868766','411.75439622318027','411.754396223180265','test','test','0.0'),('2019-05-01 11:59:59','2019-05-01 15:59:59','LINKBTC','4h','0.000089150000000','0.000088410000000','0.036740387270110','0.036435419389236','412.11875793729416','412.118757937294163','test','test','0.0'),('2019-05-05 07:59:59','2019-05-05 19:59:59','LINKBTC','4h','0.000088380000000','0.000087790000000','0.036672616629916','0.036427800565064','414.94248280058326','414.942482800583264','test','test','0.0'),('2019-05-06 03:59:59','2019-05-11 23:59:59','LINKBTC','4h','0.000089280000000','0.000095480000000','0.036618213059948','0.039161144522444','410.1502358865193','410.150235886519283','test','test','1.66'),('2019-05-14 15:59:59','2019-05-25 15:59:59','LINKBTC','4h','0.000107050000000','0.000142980000000','0.037183308940503','0.049663423748838','347.34524932744614','347.345249327446140','test','test','17.4'),('2019-05-25 19:59:59','2019-05-25 23:59:59','LINKBTC','4h','0.000143830000000','0.000138860000000','0.039956667786800','0.038575977813217','277.8048236584841','277.804823658484111','test','test','37.5'),('2019-05-26 03:59:59','2019-05-26 11:59:59','LINKBTC','4h','0.000146840000000','0.000133840000000','0.039649847792670','0.036139577966296','270.02075587489935','270.020755874899351','test','test','18.3'),('2019-05-27 07:59:59','2019-05-27 11:59:59','LINKBTC','4h','0.000142750000000','0.000137430000000','0.038869787831254','0.037421190484408','272.29273436955356','272.292734369553557','test','test','12.9'),('2019-05-28 07:59:59','2019-05-28 11:59:59','LINKBTC','4h','0.000137920000000','0.000142490000000','0.038547877309732','0.039825167037875','279.4944700531644','279.494470053164378','test','test','4.19'),('2019-05-28 15:59:59','2019-05-29 03:59:59','LINKBTC','4h','0.000139530000000','0.000137370000000','0.038831719471542','0.038230583414361','278.3037301766072','278.303730176607189','test','test','4.41'),('2019-05-29 07:59:59','2019-05-29 19:59:59','LINKBTC','4h','0.000144340000000','0.000135990000000','0.038698133681057','0.036459465146785','268.1040160804859','268.104016080485906','test','test','4.97'),('2019-06-05 07:59:59','2019-06-09 19:59:59','LINKBTC','4h','0.000127060000000','0.000136520000000','0.038200651784552','0.041044805459051','300.65049413310595','300.650494133105951','test','test','0.0'),('2019-06-09 23:59:59','2019-06-12 07:59:59','LINKBTC','4h','0.000138970000000','0.000138090000000','0.038832685934441','0.038586785642131','279.4321503521703','279.432150352170311','test','test','2.14'),('2019-06-12 11:59:59','2019-06-12 15:59:59','LINKBTC','4h','0.000138640000000','0.000140670000000','0.038778041425039','0.039345838771352','279.70312626254247','279.703126262542469','test','test','0.39'),('2019-06-12 19:59:59','2019-06-12 23:59:59','LINKBTC','4h','0.000139570000000','0.000140860000000','0.038904218613108','0.039263797620136','278.74341630084143','278.743416300841432','test','test','0.0'),('2019-06-13 03:59:59','2019-06-13 15:59:59','LINKBTC','4h','0.000139790000000','0.000137990000000','0.038984125059115','0.038482147627922','278.8763506625271','278.876350662527102','test','test','0.0'),('2019-06-13 19:59:59','2019-06-20 19:59:59','LINKBTC','4h','0.000217740000000','0.000179460000000','0.038872574518850','0.032038542404486','178.5274847012471','178.527484701247090','test','test','36.6'),('2019-06-20 23:59:59','2019-06-21 03:59:59','LINKBTC','4h','0.000185610000000','0.000172680000000','0.037353900715658','0.034751746002801','201.24939774612116','201.249397746121161','test','test','24.2'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKBTC','4h','0.000179250000000','0.000168300000000','0.036775644112800','0.034529098489173','205.16398389288952','205.163983892889519','test','test','3.66'),('2019-06-27 03:59:59','2019-07-07 23:59:59','LINKBTC','4h','0.000184050000000','0.000286990000000','0.036276411751994','0.056565973424095','197.10085168157806','197.100851681578064','test','test','8.55'),('2019-07-08 03:59:59','2019-07-08 11:59:59','LINKBTC','4h','0.000292530000000','0.000284000000000','0.040785203234684','0.039595931079377','139.4222925330173','139.422292533017298','test','test','1.89'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKBTC','4h','0.000284190000000','0.000269670000000','0.040520920533504','0.038450602203702','142.58390701116937','142.583907011169373','test','test','0.06'),('2019-07-13 03:59:59','2019-07-13 15:59:59','LINKBTC','4h','0.000277170000000','0.000278350000000','0.040060849793548','0.040231401450496','144.53530249864062','144.535302498640618','test','test','2.70'),('2019-07-13 19:59:59','2019-07-14 15:59:59','LINKBTC','4h','0.000288010000000','0.000272030000000','0.040098750161759','0.037873903706480','139.22693712634592','139.226937126345916','test','test','3.77'),('2019-07-14 19:59:59','2019-07-14 23:59:59','LINKBTC','4h','0.000272840000000','0.000273250000000','0.039604339838364','0.039663853763499','145.1559149624819','145.155914962481887','test','test','0.29'),('2019-07-15 07:59:59','2019-07-15 11:59:59','LINKBTC','4h','0.000274630000000','0.000268510000000','0.039617565155060','0.038734706404199','144.25796582696802','144.257965826968018','test','test','0.50'),('2019-07-18 11:59:59','2019-07-18 15:59:59','LINKBTC','4h','0.000276240000000','0.000261840000000','0.039421374321536','0.037366393905122','142.70697336206032','142.706973362060324','test','test','2.79'),('2019-08-03 03:59:59','2019-08-03 19:59:59','LINKBTC','4h','0.000234210000000','0.000233520000000','0.038964712006777','0.038849919080409','166.36655995378888','166.366559953788880','test','test','0.0'),('2019-08-04 11:59:59','2019-08-04 15:59:59','LINKBTC','4h','0.000230940000000','0.000229690000000','0.038939202467584','0.038728437753440','168.6117713154239','168.611771315423908','test','test','0.0'),('2019-08-04 19:59:59','2019-08-04 23:59:59','LINKBTC','4h','0.000231790000000','0.000229380000000','0.038892365864441','0.038487988618946','167.79138817222866','167.791388172228665','test','test','0.90'),('2019-08-11 19:59:59','2019-08-11 23:59:59','LINKBTC','4h','0.000213680000000','0.000210030000000','0.038802504254331','0.038139694723592','181.59165225725798','181.591652257257977','test','test','0.0'),('2019-08-12 03:59:59','2019-08-12 07:59:59','LINKBTC','4h','0.000212280000000','0.000215530000000','0.038655213247500','0.039247023324070','182.0954081755229','182.095408175522891','test','test','1.05'),('2019-08-12 11:59:59','2019-08-12 15:59:59','LINKBTC','4h','0.000213650000000','0.000211330000000','0.038786726597849','0.038365546135846','181.54330258763815','181.543302587638152','test','test','0.0'),('2019-08-13 15:59:59','2019-08-20 11:59:59','LINKBTC','4h','0.000213200000000','0.000225240000000','0.038693130939626','0.040878240210325','181.4874809550938','181.487480955093787','test','test','0.87'),('2019-09-18 07:59:59','2019-10-15 19:59:59','LINKBTC','4h','0.000170760000000','0.000297510000000','0.039178710777559','0.068259886644598','229.43728494705502','229.437284947055019','test','test','0.0'),('2019-10-15 23:59:59','2019-10-16 03:59:59','LINKBTC','4h','0.000293710000000','0.000281940000000','0.045641194303568','0.043812189989949','155.39543871018276','155.395438710182759','test','test','41.8'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKBTC','4h','0.000297050000000','0.000296270000000','0.045234748900541','0.045115970566448','152.27991550426302','152.279915504263016','test','test','27.4'),('2019-10-17 07:59:59','2019-10-17 11:59:59','LINKBTC','4h','0.000291380000000','0.000296020000000','0.045208353715187','0.045928261606046','155.15256268510993','155.152562685109928','test','test','21.2'),('2019-10-17 15:59:59','2019-10-18 23:59:59','LINKBTC','4h','0.000303640000000','0.000296150000000','0.045368333246489','0.044249215817902','149.41487698092917','149.414876980929165','test','test','23.0'),('2019-10-19 03:59:59','2019-10-19 07:59:59','LINKBTC','4h','0.000294770000000','0.000292390000000','0.045119640484581','0.044755340371431','153.0672744328836','153.067274432883607','test','test','11.1'),('2019-10-19 11:59:59','2019-10-19 15:59:59','LINKBTC','4h','0.000295540000000','0.000294470000000','0.045038684903881','0.044875622736840','152.3945486359921','152.394548635992095','test','test','5.81'),('2019-10-19 19:59:59','2019-10-20 03:59:59','LINKBTC','4h','0.000294310000000','0.000294090000000','0.045002448866761','0.044968809035458','152.90832410302363','152.908324103023631','test','test','0.0'),('2019-10-20 19:59:59','2019-10-20 23:59:59','LINKBTC','4h','0.000295530000000','0.000297460000000','0.044994973348694','0.045288819315476','152.25179625991797','152.251796259917967','test','test','0.48'),('2019-10-21 03:59:59','2019-10-26 03:59:59','LINKBTC','4h','0.000302500000000','0.000297940000000','0.045060272452423','0.044381016775124','148.959578355117','148.959578355117003','test','test','2.65'),('2019-11-08 03:59:59','2019-11-08 07:59:59','LINKBTC','4h','0.000294010000000','0.000294670000000','0.044909326746356','0.045010140173289','152.7476165652748','152.747616565274797','test','test','0.0'),('2019-11-08 11:59:59','2019-11-19 07:59:59','LINKBTC','4h','0.000296720000000','0.000330580000000','0.044931729730119','0.050059083358664','151.4280457337535','151.428045733753493','test','test','0.69'),('2019-11-19 15:59:59','2019-11-19 19:59:59','LINKBTC','4h','0.000333270000000','0.000328490000000','0.046071141647574','0.045410355927061','138.2396904839133','138.239690483913307','test','test','10.6'),('2019-11-19 23:59:59','2019-11-20 19:59:59','LINKBTC','4h','0.000335370000000','0.000326670000000','0.045924300376349','0.044732955255216','136.93622081983682','136.936220819836819','test','test','2.05'),('2019-11-20 23:59:59','2019-11-21 03:59:59','LINKBTC','4h','0.000333450000000','0.000330130000000','0.045659557016097','0.045204946941743','136.93074528744006','136.930745287440061','test','test','2.03'),('2019-11-21 15:59:59','2019-11-21 19:59:59','LINKBTC','4h','0.000338250000000','0.000334850000000','0.045558532555129','0.045100590173200','134.68893586143184','134.688935861431844','test','test','2.40'),('2019-11-21 23:59:59','2019-11-22 07:59:59','LINKBTC','4h','0.000333290000000','0.000323610000000','0.045456767581367','0.044136531420103','136.3880331884165','136.388033188416500','test','test','0.0'),('2019-11-23 15:59:59','2019-11-23 19:59:59','LINKBTC','4h','0.000335170000000','0.000334680000000','0.045163381767753','0.045097355401831','134.74768555584663','134.747685555846630','test','test','3.44'),('2019-11-23 23:59:59','2019-11-24 03:59:59','LINKBTC','4h','0.000331980000000','0.000328040000000','0.045148709241993','0.044612876015855','135.99828074580597','135.998280745805971','test','test','0.0'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKBTC','4h','0.000294170000000','0.000288270000000','0.045029635191740','0.044126501467597','153.07351256667837','153.073512566678374','test','test','0.0'),('2019-12-12 11:59:59','2019-12-12 15:59:59','LINKBTC','4h','0.000291190000000','0.000290420000000','0.044828938808597','0.044710396678432','153.95081839553862','153.950818395538619','test','test','1.00'),('2019-12-12 19:59:59','2019-12-13 03:59:59','LINKBTC','4h','0.000292770000000','0.000291850000000','0.044802596113005','0.044661808503537','153.03001029137093','153.030010291370928','test','test','0.80'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKBTC','4h','0.000293250000000','0.000291000000000','0.044771309977567','0.044427796090271','152.6728387981836','152.672838798183591','test','test','0.47'),('2019-12-16 03:59:59','2019-12-16 07:59:59','LINKBTC','4h','0.000289340000000','0.000287010000000','0.044694973558168','0.044335053435162','154.47215579653076','154.472155796530757','test','test','0.0'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKBTC','4h','0.000291230000000','0.000287630000000','0.044614991308611','0.044063489166967','153.19503934557335','153.195039345573349','test','test','1.44'),('2019-12-27 15:59:59','2019-12-27 19:59:59','LINKBTC','4h','0.000266090000000','0.000261920000000','0.044492435277135','0.043795176999463','167.20822006514672','167.208220065146719','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 20:55:18
