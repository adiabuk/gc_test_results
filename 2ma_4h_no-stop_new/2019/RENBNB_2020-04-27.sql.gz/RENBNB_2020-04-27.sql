-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-23 03:59:59','2019-05-23 11:59:59','RENBNB','4h','0.001170000000000','0.001140000000000','3.111111111111111','3.031339031339031','2659.069325735992','2659.069325735992152','test','test','0.0'),('2019-05-30 11:59:59','2019-05-30 15:59:59','RENBNB','4h','0.001030000000000','0.001030000000000','3.093383982272871','3.093383982272871','3003.2854196823987','3003.285419682398697','test','test','0.0'),('2019-05-30 23:59:59','2019-06-12 19:59:59','RENBNB','4h','0.001110000000000','0.001340000000000','3.093383982272871','3.734355438059141','2786.8324164620453','2786.832416462045330','test','test','7.20'),('2019-06-14 03:59:59','2019-06-14 15:59:59','RENBNB','4h','0.001380000000000','0.001250000000000','3.235822083558709','2.930998264093033','2344.798611274427','2344.798611274427003','test','test','17.3'),('2019-06-16 11:59:59','2019-06-18 03:59:59','RENBNB','4h','0.001610000000000','0.001400000000000','3.168083457010781','2.754855180009375','1967.7537000066961','1967.753700006696135','test','test','22.3'),('2019-06-18 07:59:59','2019-06-18 19:59:59','RENBNB','4h','0.001440000000000','0.001390000000000','3.076254951010469','2.969440542989272','2136.2881604239365','2136.288160423936461','test','test','3.47'),('2019-06-20 03:59:59','2019-06-20 11:59:59','RENBNB','4h','0.001500000000000','0.001340000000000','3.052518415894646','2.726916451532550','2035.0122772630975','2035.012277263097531','test','test','7.33'),('2019-06-20 23:59:59','2019-06-21 07:59:59','RENBNB','4h','0.001410000000000','0.001360000000000','2.980162423814182','2.874482905239211','2113.5903714994197','2113.590371499419689','test','test','4.96'),('2019-06-22 03:59:59','2019-07-07 15:59:59','RENBNB','4h','0.001450000000000','0.002660000000000','2.956678086353076','5.423974972206333','2039.0883354159148','2039.088335415914798','test','test','6.20'),('2019-07-07 19:59:59','2019-07-07 23:59:59','RENBNB','4h','0.002610000000000','0.002480000000000','3.504966283209356','3.330389418528430','1342.8989590840442','1342.898959084044236','test','test','46.3'),('2019-07-09 15:59:59','2019-07-13 03:59:59','RENBNB','4h','0.002890000000000','0.002979000000000','3.466171424391372','3.572915111855327','1199.3672748759072','1199.367274875907242','test','test','14.1'),('2019-07-13 07:59:59','2019-07-14 19:59:59','RENBNB','4h','0.003130000000000','0.003020000000000','3.489892243827807','3.367244273597437','1114.9815475488201','1114.981547548820117','test','test','4.82'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBNB','4h','0.002797000000000','0.002657000000000','3.462637139332168','3.289319584985903','1237.9825310447509','1237.982531044750885','test','test','0.0'),('2019-07-19 23:59:59','2019-07-20 15:59:59','RENBNB','4h','0.002821000000000','0.003119000000000','3.424122127255221','3.785833716734858','1213.7972801330097','1213.797280133009735','test','test','5.81'),('2019-07-20 19:59:59','2019-07-30 11:59:59','RENBNB','4h','0.003166000000000','0.003809000000000','3.504502480472918','4.216250773253741','1106.9180292081232','1106.918029208123244','test','test','4.61'),('2019-07-30 23:59:59','2019-07-31 03:59:59','RENBNB','4h','0.003967000000000','0.003916000000000','3.662668767757545','3.615581269104751','923.2842873096912','923.284287309691194','test','test','3.98'),('2019-08-02 07:59:59','2019-08-03 23:59:59','RENBNB','4h','0.003874000000000','0.003943000000000','3.652204879168036','3.717254475621985','942.7477746948983','942.747774694898339','test','test','0.0'),('2019-08-04 03:59:59','2019-08-04 07:59:59','RENBNB','4h','0.003988000000000','0.003937000000000','3.666660345046691','3.619769753873827','919.4233563306645','919.423356330664546','test','test','1.80'),('2019-08-04 11:59:59','2019-08-07 15:59:59','RENBNB','4h','0.004012000000000','0.004200000000000','3.656240213674943','3.827569515811256','911.3260751931564','911.326075193156385','test','test','1.86'),('2019-08-09 19:59:59','2019-08-10 03:59:59','RENBNB','4h','0.004330000000000','0.004214000000000','3.694313391927457','3.595343333390832','853.1901597984889','853.190159798488935','test','test','3.00'),('2019-08-28 03:59:59','2019-08-28 07:59:59','RENBNB','4h','0.003257000000000','0.003110000000000','3.672320045585986','3.506575174016707','1127.5161331243432','1127.516133124343241','test','test','0.0'),('2019-08-30 23:59:59','2019-08-31 03:59:59','RENBNB','4h','0.003199000000000','0.003053000000000','3.635487851903923','3.469566868353447','1136.4450928114795','1136.445092811479526','test','test','2.78'),('2019-08-31 07:59:59','2019-08-31 11:59:59','RENBNB','4h','0.003160000000000','0.003031000000000','3.598616522226040','3.451710974325040','1138.8026969069747','1138.802696906974688','test','test','3.38'),('2019-09-19 15:59:59','2019-09-23 19:59:59','RENBNB','4h','0.002346000000000','0.002349000000000','3.565970844914707','3.570530909933780','1520.0216730241716','1520.021673024171605','test','test','0.0'),('2019-09-25 23:59:59','2019-09-26 03:59:59','RENBNB','4h','0.002406000000000','0.002371000000000','3.566984192696722','3.515095395213602','1482.5370709462686','1482.537070946268614','test','test','2.36'),('2019-09-26 07:59:59','2019-09-26 11:59:59','RENBNB','4h','0.002341000000000','0.002328000000000','3.555453348811584','3.535709267848512','1518.7754586978147','1518.775458697814656','test','test','0.0'),('2019-09-26 15:59:59','2019-09-28 03:59:59','RENBNB','4h','0.002317000000000','0.002408000000000','3.551065775264235','3.690533615380353','1532.6136276496482','1532.613627649648151','test','test','0.0'),('2019-09-28 07:59:59','2019-09-30 07:59:59','RENBNB','4h','0.002455000000000','0.002455000000000','3.582058628623372','3.582058628623372','1459.0870177691943','1459.087017769194290','test','test','5.17'),('2019-09-30 11:59:59','2019-10-16 11:59:59','RENBNB','4h','0.002445000000000','0.003018000000000','3.582058628623372','4.421534945270076','1465.05465383369','1465.054653833690054','test','test','3.02'),('2019-10-22 15:59:59','2019-10-22 19:59:59','RENBNB','4h','0.003191000000000','0.003150000000000','3.768608921211529','3.720187433975655','1181.0118838017954','1181.011883801795420','test','test','5.42'),('2019-10-22 23:59:59','2019-10-23 07:59:59','RENBNB','4h','0.003140000000000','0.003079000000000','3.757848590714668','3.684845799621167','1196.767067106582','1196.767067106582090','test','test','3.47'),('2019-10-23 11:59:59','2019-10-23 15:59:59','RENBNB','4h','0.003186000000000','0.003057000000000','3.741625748249445','3.590128660514298','1174.3960289546283','1174.396028954628264','test','test','3.35'),('2019-10-24 07:59:59','2019-10-24 23:59:59','RENBNB','4h','0.003147000000000','0.003100000000000','3.707959728752747','3.652581874526061','1178.2522175890522','1178.252217589052179','test','test','2.85'),('2019-11-02 07:59:59','2019-11-02 11:59:59','RENBNB','4h','0.002759000000000','0.002698000000000','3.695653538924594','3.613944635019410','1339.4902279538217','1339.490227953821659','test','test','0.0'),('2019-11-06 15:59:59','2019-11-10 19:59:59','RENBNB','4h','0.002875000000000','0.002726000000000','3.677496004723442','3.486905777000384','1279.1290451211974','1279.129045121197350','test','test','6.15'),('2019-11-11 03:59:59','2019-11-11 07:59:59','RENBNB','4h','0.002754000000000','0.002771000000000','3.635142620784985','3.657581772765139','1319.9501164796604','1319.950116479660437','test','test','1.01'),('2019-11-11 11:59:59','2019-11-11 15:59:59','RENBNB','4h','0.002785000000000','0.002782000000000','3.640129099002797','3.636207954551447','1307.0481504498373','1307.048150449837294','test','test','0.50'),('2019-11-11 19:59:59','2019-11-11 23:59:59','RENBNB','4h','0.002773000000000','0.002773000000000','3.639257733569164','3.639257733569164','1312.3900950483824','1312.390095048382364','test','test','0.0'),('2019-11-12 03:59:59','2019-11-12 23:59:59','RENBNB','4h','0.002763000000000','0.002763000000000','3.639257733569164','3.639257733569164','1317.1399687184814','1317.139968718481441','test','test','0.0'),('2019-11-14 19:59:59','2019-11-15 07:59:59','RENBNB','4h','0.002869000000000','0.002810000000000','3.639257733569164','3.564417647727205','1268.4760312196458','1268.476031219645847','test','test','3.69'),('2019-11-15 11:59:59','2019-11-17 07:59:59','RENBNB','4h','0.002844000000000','0.002798000000000','3.622626603382062','3.564032783496136','1273.7786931723142','1273.778693172314206','test','test','2.49'),('2019-11-18 03:59:59','2019-11-18 07:59:59','RENBNB','4h','0.002791000000000','0.002761000000000','3.609605754518523','3.570806695888800','1293.3019543240855','1293.301954324085500','test','test','0.32'),('2019-11-19 15:59:59','2019-11-19 23:59:59','RENBNB','4h','0.002798000000000','0.002819000000000','3.600983741489695','3.628010424324321','1286.9848968869533','1286.984896886953265','test','test','1.32'),('2019-11-20 03:59:59','2019-11-20 07:59:59','RENBNB','4h','0.002796000000000','0.002788000000000','3.606989671008501','3.596669242765273','1290.0535304036127','1290.053530403612740','test','test','0.0'),('2019-11-20 15:59:59','2019-11-20 19:59:59','RENBNB','4h','0.002787000000000','0.002768000000000','3.604696242510006','3.580121707666917','1293.396570688915','1293.396570688915062','test','test','0.0'),('2019-11-21 07:59:59','2019-11-21 11:59:59','RENBNB','4h','0.002789000000000','0.002799000000000','3.599235234767097','3.612140344967051','1290.5110199953738','1290.511019995373772','test','test','0.75'),('2019-11-21 15:59:59','2019-11-24 07:59:59','RENBNB','4h','0.002770000000000','0.002873000000000','3.602103037033754','3.736044052490244','1300.3982083154347','1300.398208315434658','test','test','0.0'),('2019-11-24 11:59:59','2019-11-24 15:59:59','RENBNB','4h','0.002832000000000','0.002820000000000','3.631867707135196','3.616478437189708','1282.43916212401','1282.439162124009954','test','test','1.55'),('2019-11-24 19:59:59','2019-11-24 23:59:59','RENBNB','4h','0.002839000000000','0.002824000000000','3.628447869369532','3.609276781648312','1278.0725147479861','1278.072514747986133','test','test','0.70'),('2019-11-25 03:59:59','2019-11-25 07:59:59','RENBNB','4h','0.002823000000000','0.002675000000000','3.624187627653705','3.434184167188686','1283.8071653041816','1283.807165304181581','test','test','0.0'),('2019-12-07 07:59:59','2019-12-07 15:59:59','RENBNB','4h','0.002567000000000','0.002518000000000','3.581964636439257','3.513590554948987','1395.3894181687795','1395.389418168779457','test','test','0.0'),('2019-12-14 15:59:59','2019-12-15 03:59:59','RENBNB','4h','0.002457000000000','0.002448000000000','3.566770396108085','3.553705303082048','1451.6770028929936','1451.677002892993642','test','test','0.0'),('2019-12-15 07:59:59','2019-12-16 11:59:59','RENBNB','4h','0.002485000000000','0.002408000000000','3.563867042102299','3.453437359107580','1434.1517272041447','1434.151727204144663','test','test','2.01'),('2019-12-16 15:59:59','2019-12-16 19:59:59','RENBNB','4h','0.002428000000000','0.002405000000000','3.539327112547918','3.505799714035315','1457.7129788088623','1457.712978808862317','test','test','0.82'),('2019-12-17 03:59:59','2019-12-17 15:59:59','RENBNB','4h','0.002469000000000','0.002409000000000','3.531876579545117','3.446047258049489','1430.48869159381','1430.488691593810017','test','test','2.59'),('2019-12-18 19:59:59','2019-12-18 23:59:59','RENBNB','4h','0.002455000000000','0.002361000000000','3.512803396990533','3.378300945130202','1430.8771474503187','1430.877147450318716','test','test','1.87'),('2019-12-21 23:59:59','2019-12-22 03:59:59','RENBNB','4h','0.002401000000000','0.002417000000000','3.482913963243793','3.506123718933881','1450.6097306304844','1450.609730630484364','test','test','1.66'),('2019-12-22 07:59:59','2019-12-22 19:59:59','RENBNB','4h','0.002502000000000','0.002404000000000','3.488071686730479','3.351448575099949','1394.1133839850036','1394.113383985003566','test','test','3.39'),('2019-12-23 15:59:59','2019-12-23 19:59:59','RENBNB','4h','0.002421000000000','0.002431000000000','3.457710995257028','3.471993155501790','1428.216024476261','1428.216024476261055','test','test','0.70'),('2019-12-23 23:59:59','2019-12-25 19:59:59','RENBNB','4h','0.002470000000000','0.002471000000000','3.460884808644753','3.462285976583476','1401.167938722572','1401.167938722571989','test','test','1.57'),('2019-12-25 23:59:59','2019-12-26 03:59:59','RENBNB','4h','0.002491000000000','0.002460000000000','3.461196179297803','3.418122280639339','1389.4806018859101','1389.480601885910119','test','test','1.72'),('2019-12-26 07:59:59','2019-12-26 11:59:59','RENBNB','4h','0.002455000000000','0.002505000000000','3.451624201818143','3.521922047069021','1405.9569050175735','1405.956905017573490','test','test','0.0'),('2019-12-26 15:59:59','2019-12-26 19:59:59','RENBNB','4h','0.002488000000000','0.002475000000000','3.467245945207228','3.449129306426001','1393.5875985559596','1393.587598555959630','test','test','1.12'),('2019-12-26 23:59:59','2019-12-27 15:59:59','RENBNB','4h','0.002464000000000','0.002478000000000','3.463220025478066','3.482897411986464','1405.5276077427216','1405.527607742721557','test','test','0.0'),('2020-01-02 03:59:59','2020-01-05 15:59:59','RENBNB','4h','0.002390000000000','0.002452000000000','3.467592778035488','3.557547067674903','1450.8756393453923','1450.875639345392301','test','test','0.0'),('2020-01-05 19:59:59','2020-01-06 03:59:59','RENBNB','4h','0.002550000000000','0.002513000000000','3.487582620177580','3.436978480198533','1367.6794588931687','1367.679458893168658','test','test','3.84'),('2020-01-06 07:59:59','2020-01-07 23:59:59','RENBNB','4h','0.002678000000000','0.002572000000000','3.476337255737791','3.338737648154444','1298.109505503283','1298.109505503282890','test','test','7.58'),('2020-01-08 03:59:59','2020-01-08 07:59:59','RENBNB','4h','0.002520000000000','0.002631000000000','3.445759565163714','3.597537069819735','1367.3649068109976','1367.364906810997581','test','test','0.07'),('2020-01-08 11:59:59','2020-01-13 07:59:59','RENBNB','4h','0.002572000000000','0.002920000000000','3.479487899531719','3.950273976140210','1352.8335534726746','1352.833553472674566','test','test','0.0'),('2020-01-13 11:59:59','2020-01-14 15:59:59','RENBNB','4h','0.003020000000000','0.002690000000000','3.584107027666939','3.192466193517903','1186.7904065122314','1186.790406512231357','test','test','12.8'),('2020-01-31 19:59:59','2020-02-01 07:59:59','RENBNB','4h','0.002454000000000','0.002424000000000','3.497075731189376','3.454324194133271','1425.0512352034946','1425.051235203494571','test','test','0.0'),('2020-02-01 11:59:59','2020-02-02 07:59:59','RENBNB','4h','0.002432000000000','0.002432000000000','3.487575389621353','3.487575389621353','1434.0359332324642','1434.035933232464231','test','test','0.32'),('2020-02-02 11:59:59','2020-02-02 19:59:59','RENBNB','4h','0.002432000000000','0.002474000000000','3.487575389621353','3.547804898817117','1434.0359332324642','1434.035933232464231','test','test','0.32'),('2020-02-02 23:59:59','2020-02-07 11:59:59','RENBNB','4h','0.002507000000000','0.002628000000000','3.500959724998189','3.669933050377040','1396.473763461583','1396.473763461583076','test','test','2.99'),('2020-02-07 15:59:59','2020-02-07 19:59:59','RENBNB','4h','0.002638000000000','0.002599000000000','3.538509352860156','3.486196288128713','1341.3606341395587','1341.360634139558670','test','test','0.37'),('2020-02-08 03:59:59','2020-02-08 07:59:59','RENBNB','4h','0.002651000000000','0.002684000000000','3.526884227364280','3.570787350526491','1330.39767158215','1330.397671582149997','test','test','1.96'),('2020-02-08 11:59:59','2020-02-08 23:59:59','RENBNB','4h','0.002907000000000','0.002570000000000','3.536640476955882','3.126648099682359','1216.5945913160929','1216.594591316092874','test','test','7.98'),('2020-02-13 23:59:59','2020-02-14 03:59:59','RENBNB','4h','0.002507000000000','0.002472000000000','3.445531059783988','3.397428312639017','1374.3642041419976','1374.364204141997561','test','test','0.0'),('2020-02-14 11:59:59','2020-02-14 19:59:59','RENBNB','4h','0.002590000000000','0.002551000000000','3.434841560418439','3.383120007964262','1326.1936526712122','1326.193652671212249','test','test','4.55'),('2020-02-14 23:59:59','2020-02-15 19:59:59','RENBNB','4h','0.002561000000000','0.002538000000000','3.423347882095289','3.392603250588771','1336.7231089790273','1336.723108979027302','test','test','2.10'),('2020-02-15 23:59:59','2020-02-16 03:59:59','RENBNB','4h','0.002498000000000','0.002542000000000','3.416515741760507','3.476694561871581','1367.7004570698589','1367.700457069858885','test','test','0.0'),('2020-02-16 07:59:59','2020-02-16 15:59:59','RENBNB','4h','0.002538000000000','0.002480000000000','3.429888812896301','3.351506799047607','1351.4140318740351','1351.414031874035118','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-27  9:55:17
