-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-15 03:59:59','GXSETH','4h','0.003955000000000','0.004097000000000','1.297777777777778','1.344373086107599','328.13597415367326','328.135974153673260','test','test','0.0'),('2019-01-15 07:59:59','2019-01-15 11:59:59','GXSETH','4h','0.004103000000000','0.004129000000000','1.308132290739960','1.316421698382962','318.8233708847088','318.823370884708822','test','test','0.14'),('2019-01-15 15:59:59','2019-01-31 15:59:59','GXSETH','4h','0.004171000000000','0.004999000000000','1.309974381327294','1.570022040818782','314.06722160807817','314.067221608078171','test','test','1.00'),('2019-01-31 19:59:59','2019-02-02 15:59:59','GXSETH','4h','0.005027000000000','0.004966000000000','1.367762750103180','1.351165668791007','272.0833001995584','272.083300199558380','test','test','0.55'),('2019-02-02 19:59:59','2019-02-03 03:59:59','GXSETH','4h','0.005023000000000','0.004963000000000','1.364074509811586','1.347780567826977','271.5656997434972','271.565699743497191','test','test','1.23'),('2019-02-03 07:59:59','2019-02-05 23:59:59','GXSETH','4h','0.004990000000000','0.005036000000000','1.360453633815006','1.372994889757990','272.63599876052234','272.635998760522341','test','test','0.54'),('2019-02-06 03:59:59','2019-02-06 23:59:59','GXSETH','4h','0.005146000000000','0.005050000000000','1.363240579580114','1.337808963637694','264.91266606687014','264.912666066870145','test','test','3.49'),('2019-02-07 03:59:59','2019-02-08 19:59:59','GXSETH','4h','0.005075000000000','0.004944000000000','1.357589109370687','1.322545922508114','267.5052432257512','267.505243225751201','test','test','0.49'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSETH','4h','0.004855000000000','0.004824000000000','1.349801734512338','1.341183021068490','278.02301431768024','278.023014317680236','test','test','0.0'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GXSETH','4h','0.004564000000000','0.004330000000000','1.347886464858149','1.278779227176990','295.3300755605059','295.330075560505918','test','test','0.0'),('2019-02-24 23:59:59','2019-02-25 03:59:59','GXSETH','4h','0.004657000000000','0.004414000000000','1.332529300929003','1.262998568670951','286.13470065041935','286.134700650419347','test','test','7.02'),('2019-02-25 19:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004508000000000','0.004911000000000','1.317078027093880','1.434820361814118','292.16460228346943','292.164602283469435','test','test','2.08'),('2019-03-05 19:59:59','2019-03-05 23:59:59','GXSETH','4h','0.004803000000000','0.004790000000000','1.343242990365044','1.339607312897889','279.6674974734633','279.667497473463300','test','test','0.0'),('2019-03-06 03:59:59','2019-03-06 07:59:59','GXSETH','4h','0.004811000000000','0.004763000000000','1.342435062039010','1.329041405215507','279.03451715631047','279.034517156310471','test','test','0.43'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GXSETH','4h','0.004784000000000','0.004797000000000','1.339458693856009','1.343098527263226','279.9871851705705','279.987185170570513','test','test','0.43'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSETH','4h','0.004940000000000','0.007357000000000','1.340267545724280','1.996021929937961','271.30921978224285','271.309219782242849','test','test','2.89'),('2019-03-27 15:59:59','2019-04-02 15:59:59','GXSETH','4h','0.007801000000000','0.008025000000000','1.485990742216209','1.528659877744530','190.48721218000367','190.487212180003667','test','test','38.1'),('2019-04-02 19:59:59','2019-04-02 23:59:59','GXSETH','4h','0.007904000000000','0.008023000000000','1.495472772333613','1.517988113921126','189.2045511555685','189.204551155568510','test','test','37.4'),('2019-04-03 03:59:59','2019-04-03 07:59:59','GXSETH','4h','0.007723000000000','0.007671000000000','1.500476181575283','1.490373273192282','194.28669967309114','194.286699673091135','test','test','0.0'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GXSETH','4h','0.007913000000000','0.007749000000000','1.498231090823505','1.467179669252034','189.33793641141222','189.337936411412215','test','test','3.05'),('2019-04-04 23:59:59','2019-04-05 03:59:59','GXSETH','4h','0.007777000000000','0.007872000000000','1.491330774918733','1.509548136834289','191.7617043742746','191.761704374274586','test','test','0.36'),('2019-04-12 19:59:59','2019-04-18 19:59:59','GXSETH','4h','0.007573000000000','0.007586000000000','1.495379077566635','1.497946082453518','197.4619143756285','197.461914375628510','test','test','0.0'),('2019-04-21 19:59:59','2019-04-22 11:59:59','GXSETH','4h','0.007866000000000','0.007707000000000','1.495949523097053','1.465711031592803','190.17919185062973','190.179191850629735','test','test','5.45'),('2019-04-22 15:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007728000000000','0.007612000000000','1.489229858318331','1.466875993985395','192.70572700806562','192.705727008065622','test','test','0.27'),('2019-05-31 11:59:59','2019-05-31 15:59:59','GXSETH','4h','0.004618000000000','0.004440000000000','1.484262332911012','1.427051701629470','321.40804090753835','321.408040907538350','test','test','0.0'),('2019-05-31 19:59:59','2019-05-31 23:59:59','GXSETH','4h','0.004429000000000','0.004416000000000','1.471548859292892','1.467229569346898','332.2530727687721','332.253072768772086','test','test','0.0'),('2019-06-04 11:59:59','2019-06-20 23:59:59','GXSETH','4h','0.004464000000000','0.008338000000000','1.470589017082671','2.746812550276727','329.4330235400248','329.433023540024806','test','test','1.07'),('2019-06-23 07:59:59','2019-06-23 15:59:59','GXSETH','4h','0.008574000000000','0.008404000000000','1.754194246681350','1.719413161780973','204.59461706103917','204.594617061039173','test','test','48.2'),('2019-06-23 19:59:59','2019-06-23 23:59:59','GXSETH','4h','0.008451000000000','0.008684000000000','1.746465116703488','1.794616385451791','206.6578057867102','206.657805786710213','test','test','9.92'),('2019-06-24 03:59:59','2019-06-24 19:59:59','GXSETH','4h','0.008826000000000','0.008070000000000','1.757165398647555','1.606653610592088','199.08966674003574','199.089666740035739','test','test','10.8'),('2019-07-04 23:59:59','2019-07-05 03:59:59','GXSETH','4h','0.007309000000000','0.007252000000000','1.723718334635230','1.710275737142521','235.83504373173204','235.835043731732043','test','test','0.0'),('2019-07-07 07:59:59','2019-07-07 11:59:59','GXSETH','4h','0.007288000000000','0.007111000000000','1.720731090747961','1.678940557945767','236.10470509714062','236.104705097140624','test','test','0.49'),('2019-07-15 23:59:59','2019-07-16 03:59:59','GXSETH','4h','0.006579000000000','0.006508000000000','1.711444305680807','1.692974546491973','260.13745336385574','260.137453363855741','test','test','0.0'),('2019-07-16 23:59:59','2019-07-17 11:59:59','GXSETH','4h','0.006665000000000','0.006451000000000','1.707339914749955','1.652520598657458','256.1650284696106','256.165028469610604','test','test','2.35'),('2019-07-18 11:59:59','2019-07-18 15:59:59','GXSETH','4h','0.006650000000000','0.006566000000000','1.695157844507177','1.673745324366034','254.9109540612297','254.910954061229688','test','test','2.99'),('2019-07-18 19:59:59','2019-07-23 07:59:59','GXSETH','4h','0.006740000000000','0.006810000000000','1.690399506698035','1.707955584660774','250.80111375341758','250.801113753417582','test','test','2.58'),('2019-07-24 03:59:59','2019-07-24 23:59:59','GXSETH','4h','0.006780000000000','0.006805000000000','1.694300857356421','1.700548279396821','249.8968816159913','249.896881615991305','test','test','0.0'),('2019-07-25 03:59:59','2019-07-27 03:59:59','GXSETH','4h','0.006884000000000','0.006940000000000','1.695689173365398','1.709483274717586','246.32323843192887','246.323238431928871','test','test','1.14'),('2019-07-27 07:59:59','2019-07-27 11:59:59','GXSETH','4h','0.006907000000000','0.006984000000000','1.698754529221441','1.717692432616555','245.94679733914012','245.946797339140119','test','test','1.40'),('2019-07-29 19:59:59','2019-07-29 23:59:59','GXSETH','4h','0.006920000000000','0.006879000000000','1.702962952198132','1.692873142799270','246.09291216736017','246.092912167360168','test','test','0.0'),('2019-07-30 03:59:59','2019-07-30 15:59:59','GXSETH','4h','0.007134000000000','0.006949000000000','1.700720772331719','1.656617416166683','238.3965198110063','238.396519811006300','test','test','3.57'),('2019-07-30 19:59:59','2019-08-06 03:59:59','GXSETH','4h','0.007126000000000','0.007957000000000','1.690920026517266','1.888107023715673','237.2888052929085','237.288805292908506','test','test','2.48'),('2019-08-06 07:59:59','2019-08-06 11:59:59','GXSETH','4h','0.007956000000000','0.007784000000000','1.734739359228024','1.697236195604693','218.04164897285366','218.041648972853665','test','test','12.2'),('2019-09-27 19:59:59','2019-09-30 07:59:59','GXSETH','4h','0.002496000000000','0.002425000000000','1.726405322867283','1.677296838122260','691.6687992256743','691.668799225674320','test','test','0.0'),('2019-09-30 19:59:59','2019-10-01 11:59:59','GXSETH','4h','0.002470000000000','0.002478000000000','1.715492326257278','1.721048576706695','694.5313061770357','694.531306177035731','test','test','1.82'),('2019-10-01 15:59:59','2019-10-01 19:59:59','GXSETH','4h','0.002465000000000','0.002437000000000','1.716727048579371','1.697226700765893','696.440993338487','696.440993338487033','test','test','0.0'),('2019-10-01 23:59:59','2019-10-02 03:59:59','GXSETH','4h','0.002450000000000','0.002422000000000','1.712393637954153','1.692823424948963','698.9361787567973','698.936178756797290','test','test','0.53'),('2019-10-02 07:59:59','2019-10-02 11:59:59','GXSETH','4h','0.002443000000000','0.002494000000000','1.708044701730778','1.743701795381319','699.1586990301997','699.158699030199728','test','test','0.85'),('2019-10-02 15:59:59','2019-10-02 23:59:59','GXSETH','4h','0.002514000000000','0.002473000000000','1.715968500319787','1.687983333846791','682.565035926725','682.565035926725045','test','test','2.50'),('2019-10-03 03:59:59','2019-10-03 07:59:59','GXSETH','4h','0.002432000000000','0.002441000000000','1.709749574436899','1.716076772697562','703.0220289625405','703.022028962540503','test','test','0.0'),('2019-10-03 11:59:59','2019-10-04 03:59:59','GXSETH','4h','0.002456000000000','0.002525000000000','1.711155618494824','1.759229615919964','696.7246003643421','696.724600364342109','test','test','0.61'),('2019-10-04 07:59:59','2019-10-04 11:59:59','GXSETH','4h','0.002466000000000','0.002445000000000','1.721838729033744','1.707175868810829','698.2314391864332','698.231439186433249','test','test','0.0'),('2019-10-04 15:59:59','2019-10-04 19:59:59','GXSETH','4h','0.002447000000000','0.002399000000000','1.718580315650874','1.684868891396178','702.3213386395071','702.321338639507076','test','test','0.08'),('2019-10-09 03:59:59','2019-10-09 15:59:59','GXSETH','4h','0.002489000000000','0.002343000000000','1.711088888038719','1.610719672428573','687.46038089141','687.460380891409955','test','test','3.61'),('2019-10-09 23:59:59','2019-10-10 11:59:59','GXSETH','4h','0.002432000000000','0.002518000000000','1.688784617903131','1.748503152911218','694.4015698614849','694.401569861484859','test','test','3.65'),('2019-10-10 15:59:59','2019-10-11 03:59:59','GXSETH','4h','0.002552000000000','0.002454000000000','1.702055403460484','1.636694341728851','666.9496095064593','666.949609506459296','test','test','3.09'),('2019-10-11 07:59:59','2019-10-14 07:59:59','GXSETH','4h','0.002490000000000','0.002508000000000','1.687530723075677','1.699729740350923','677.723181958103','677.723181958103055','test','test','1.44'),('2019-10-14 11:59:59','2019-10-14 19:59:59','GXSETH','4h','0.002504000000000','0.002483000000000','1.690241615803509','1.676066266789182','675.0166197298358','675.016619729835838','test','test','1.03'),('2019-10-14 23:59:59','2019-10-15 07:59:59','GXSETH','4h','0.002511000000000','0.002495000000000','1.687091538244770','1.676341452776066','671.8803417940143','671.880341794014271','test','test','1.11'),('2019-10-15 11:59:59','2019-10-20 19:59:59','GXSETH','4h','0.003024000000000','0.002664000000000','1.684702630362836','1.484142793414879','557.1106581887684','557.110658188768411','test','test','17.4'),('2019-10-20 23:59:59','2019-10-21 07:59:59','GXSETH','4h','0.002763000000000','0.002667000000000','1.640133777707734','1.583147587819952','593.6061446643989','593.606144664398926','test','test','3.58'),('2019-10-22 15:59:59','2019-10-22 19:59:59','GXSETH','4h','0.002735000000000','0.002663000000000','1.627470179954893','1.584626358032863','595.053082250418','595.053082250418015','test','test','2.48'),('2019-10-23 11:59:59','2019-10-23 15:59:59','GXSETH','4h','0.002726000000000','0.002637000000000','1.617949330638887','1.565125599741286','593.5250662651823','593.525066265182318','test','test','2.31'),('2019-10-27 15:59:59','2019-10-29 11:59:59','GXSETH','4h','0.003022000000000','0.002741000000000','1.606210723772753','1.456857575731673','531.5058649148754','531.505864914875360','test','test','12.7'),('2019-10-29 15:59:59','2019-10-29 19:59:59','GXSETH','4h','0.002740000000000','0.002580000000000','1.573021135319180','1.481165886541418','574.0953048610147','574.095304861014711','test','test','0.0'),('2019-10-30 23:59:59','2019-10-31 03:59:59','GXSETH','4h','0.002711000000000','0.002688000000000','1.552608857813011','1.539436595279002','572.7070666960572','572.707066696057154','test','test','4.83'),('2019-10-31 15:59:59','2019-10-31 19:59:59','GXSETH','4h','0.002755000000000','0.002716000000000','1.549681688361009','1.527744270631035','562.4978905121628','562.497890512162826','test','test','2.43'),('2019-10-31 23:59:59','2019-11-01 03:59:59','GXSETH','4h','0.002744000000000','0.002727000000000','1.544806706643237','1.535236111157473','562.9762050449114','562.976205044911353','test','test','1.02'),('2019-11-01 07:59:59','2019-11-04 15:59:59','GXSETH','4h','0.002786000000000','0.002831000000000','1.542679907646400','1.567597565881895','553.7257385665471','553.725738566547079','test','test','2.11'),('2019-11-04 19:59:59','2019-11-05 07:59:59','GXSETH','4h','0.002911000000000','0.002890000000000','1.548217165032066','1.537048301938396','531.8506235080954','531.850623508095396','test','test','5.83'),('2019-11-05 11:59:59','2019-11-11 11:59:59','GXSETH','4h','0.002892000000000','0.002976000000000','1.545735195455695','1.590632068352748','534.4865821077783','534.486582107778304','test','test','1.17'),('2019-11-11 15:59:59','2019-11-11 19:59:59','GXSETH','4h','0.002992000000000','0.002957000000000','1.555712278321707','1.537513772392142','519.9573122732977','519.957312273297703','test','test','3.40'),('2019-11-11 23:59:59','2019-11-12 03:59:59','GXSETH','4h','0.002975000000000','0.003008000000000','1.551668165892914','1.568879947228869','521.5691313925761','521.569131392576082','test','test','0.60'),('2019-11-12 07:59:59','2019-11-18 03:59:59','GXSETH','4h','0.002976000000000','0.003151000000000','1.555493006189793','1.646961848959690','522.6791015422692','522.679101542269223','test','test','0.0'),('2019-11-18 07:59:59','2019-11-18 11:59:59','GXSETH','4h','0.003168000000000','0.003075000000000','1.575819415694215','1.529559565422889','497.4177448529719','497.417744852971907','test','test','5.05'),('2019-11-21 19:59:59','2019-11-22 07:59:59','GXSETH','4h','0.003147000000000','0.003026000000000','1.565539448967254','1.505345526715892','497.47043182944185','497.470431829441850','test','test','2.28'),('2019-11-22 11:59:59','2019-11-22 15:59:59','GXSETH','4h','0.003090000000000','0.003074000000000','1.552163021800284','1.544125931719765','502.31813003245446','502.318130032454462','test','test','2.07'),('2019-11-27 11:59:59','2019-11-27 15:59:59','GXSETH','4h','0.003000000000000','0.002949000000000','1.550377001782391','1.524020592752090','516.7923339274637','516.792333927463687','test','test','0.0'),('2019-11-28 15:59:59','2019-11-30 11:59:59','GXSETH','4h','0.003009000000000','0.003009000000000','1.544520021997880','1.544520021997880','513.3001070115918','513.300107011591763','test','test','1.99'),('2019-12-03 07:59:59','2019-12-04 03:59:59','GXSETH','4h','0.003061000000000','0.003043000000000','1.544520021997880','1.535437578222656','504.5802097346879','504.580209734687912','test','test','1.69'),('2019-12-04 11:59:59','2019-12-04 15:59:59','GXSETH','4h','0.003020000000000','0.003024000000000','1.542501701158941','1.544544749769748','510.76215270163607','510.762152701636069','test','test','0.0'),('2019-12-04 19:59:59','2019-12-04 23:59:59','GXSETH','4h','0.003020000000000','0.003026000000000','1.542955711961343','1.546021186885770','510.9124874044181','510.912487404418073','test','test','0.0'),('2019-12-05 03:59:59','2019-12-05 11:59:59','GXSETH','4h','0.003045000000000','0.003060000000000','1.543636928611215','1.551241051412255','506.94152006936457','506.941520069364572','test','test','0.68'),('2019-12-05 15:59:59','2019-12-05 23:59:59','GXSETH','4h','0.003008000000000','0.003044000000000','1.545326733678113','1.563821335543941','513.7389407174578','513.738940717457808','test','test','0.0'),('2019-12-06 03:59:59','2019-12-06 07:59:59','GXSETH','4h','0.003044000000000','0.003020000000000','1.549436645203852','1.537220324742324','509.01335256368344','509.013352563683441','test','test','0.03'),('2019-12-06 11:59:59','2019-12-07 03:59:59','GXSETH','4h','0.003044000000000','0.003056000000000','1.546721907323513','1.552819365565262','508.12152014570074','508.121520145700742','test','test','0.78'),('2019-12-07 07:59:59','2019-12-07 19:59:59','GXSETH','4h','0.003044000000000','0.003067000000000','1.548076898043901','1.559773931110593','508.56665507355507','508.566655073555069','test','test','0.0'),('2019-12-07 23:59:59','2019-12-08 07:59:59','GXSETH','4h','0.003062000000000','0.003077000000000','1.550676238725389','1.558272627876558','506.4259434112961','506.425943411296089','test','test','0.19'),('2019-12-08 11:59:59','2019-12-08 15:59:59','GXSETH','4h','0.003059000000000','0.002992000000000','1.552364325203426','1.518363537433361','507.4744443293318','507.474444329331789','test','test','0.0'),('2019-12-16 15:59:59','2019-12-17 07:59:59','GXSETH','4h','0.002992000000000','0.002957000000000','1.544808594587856','1.526737638434589','516.3130329504868','516.313032950486786','test','test','0.0'),('2019-12-17 11:59:59','2019-12-17 15:59:59','GXSETH','4h','0.002957000000000','0.002975000000000','1.540792826553797','1.550172018599103','521.0662247391941','521.066224739194126','test','test','0.0'),('2019-12-17 19:59:59','2019-12-22 19:59:59','GXSETH','4h','0.002995000000000','0.003066000000000','1.542877091452754','1.579452808812736','515.1509487321382','515.150948732138204','test','test','0.66'),('2019-12-22 23:59:59','2019-12-23 03:59:59','GXSETH','4h','0.003035000000000','0.003042000000000','1.551005028643861','1.554582305480931','511.0395481528372','511.039548152837199','test','test','0.0'),('2019-12-23 23:59:59','2019-12-24 11:59:59','GXSETH','4h','0.003080000000000','0.003035000000000','1.551799979052099','1.529127576760754','503.8311620299022','503.831162029902202','test','test','1.23'),('2019-12-24 15:59:59','2019-12-24 23:59:59','GXSETH','4h','0.003088000000000','0.003039000000000','1.546761667431800','1.522217845636412','500.8943223548574','500.894322354857422','test','test','1.71'),('2019-12-25 03:59:59','2019-12-26 07:59:59','GXSETH','4h','0.003109000000000','0.003050000000000','1.541307484810602','1.512057841322720','495.7566692861378','495.756669286137821','test','test','2.25'),('2019-12-26 11:59:59','2019-12-26 19:59:59','GXSETH','4h','0.003069000000000','0.003044000000000','1.534807564035517','1.522305058626300','500.10021636869254','500.100216368692543','test','test','0.61'),('2019-12-26 23:59:59','2019-12-27 07:59:59','GXSETH','4h','0.003106000000000','0.003060000000000','1.532029229500136','1.509339807556477','493.2483031230315','493.248303123031519','test','test','1.99'),('2019-12-27 11:59:59','2019-12-27 23:59:59','GXSETH','4h','0.003099000000000','0.003035000000000','1.526987135734879','1.495452067426704','492.7354423152238','492.735442315223793','test','test','1.25'),('2019-12-28 03:59:59','2019-12-28 15:59:59','GXSETH','4h','0.003103000000000','0.003062000000000','1.519979342777506','1.499895825841032','489.84187649935745','489.841876499357454','test','test','2.19'),('2019-12-29 07:59:59','2019-12-29 11:59:59','GXSETH','4h','0.003084000000000','0.003026000000000','1.515516339013845','1.487014410459110','491.4125612885361','491.412561288536097','test','test','0.71');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 21:19:16
