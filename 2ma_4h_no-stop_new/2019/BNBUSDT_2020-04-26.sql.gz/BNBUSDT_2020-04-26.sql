-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-04 03:59:59','BNBUSDT','4h','5.854000000000000','5.893500000000000','222.222222222222200','223.721671791367726','37.96074858596211','37.960748585962108','test','test','0.0'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','222.555433237587891','229.915898647515093','37.94054335014028','37.940543350140281','test','test','1.15'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.892900000000000','224.191092217571736','218.070364182844770','37.00561085082808','37.005610850828077','test','test','0.0'),('2019-01-16 15:59:59','2019-01-16 19:59:59','BNBUSDT','4h','5.970200000000000','6.004800000000000','222.830930432076826','224.122336112447670','37.32386359453231','37.323863594532313','test','test','1.29'),('2019-01-16 23:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.091100000000000','6.739800000000000','223.117909472159255','246.879888076120722','36.630150460862446','36.630150460862446','test','test','1.64'),('2019-01-28 11:59:59','2019-01-28 15:59:59','BNBUSDT','4h','6.799100000000000','6.158900000000000','228.398349161928451','206.892469981821279','33.592438581860605','33.592438581860605','test','test','11.6'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','223.619264899682435','332.867670371100417','34.01363849167718','34.013638491677177','test','test','7.82'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BNBUSDT','4h','9.932499999999999','9.947600000000000','247.896688337775345','248.273556195203014','24.958136253488583','24.958136253488583','test','test','1.47'),('2019-02-25 03:59:59','2019-02-25 07:59:59','BNBUSDT','4h','9.929600000000001','9.901700000000000','247.980436750536995','247.283666066386559','24.973859646968354','24.973859646968354','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','BNBUSDT','4h','9.846700000000000','9.825799999999999','247.825598820725787','247.299579442116340','25.168391321023876','25.168391321023876','test','test','0.0'),('2019-02-28 07:59:59','2019-02-28 11:59:59','BNBUSDT','4h','9.956300000000001','10.347600000000000','247.708705625479269','257.444090910298939','24.879594390032366','24.879594390032366','test','test','1.31'),('2019-02-28 15:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.341500000000000','14.458200000000000','249.872124577661424','349.340149066261631','24.162077510773237','24.162077510773237','test','test','4.25'),('2019-03-22 15:59:59','2019-03-22 19:59:59','BNBUSDT','4h','14.913500000000001','15.220000000000001','271.976130019572508','277.565742374217564','18.236908171761993','18.236908171761993','test','test','33.2'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.700400000000000','273.218266098382571','265.106585982539059','18.03397091116834','18.033970911168339','test','test','0.0'),('2019-03-24 11:59:59','2019-03-30 07:59:59','BNBUSDT','4h','17.040199999999999','16.367000000000001','271.415670517084038','260.692966007037171','15.927962730313263','15.927962730313263','test','test','13.7'),('2019-03-30 11:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.486999999999998','17.836900000000000','269.032847292629128','291.060350207672570','16.31787755762899','16.317877557628989','test','test','7.68'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.105000000000000','273.927847940416598','271.032641485662282','14.97004371641327','14.970043716413270','test','test','2.52'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','273.284468728248953','272.357199971766136','14.93186403353981','14.931864033539810','test','test','1.07'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','273.078409004586149','274.018543425638200','14.946493180476956','14.946493180476956','test','test','0.16'),('2019-04-13 03:59:59','2019-04-13 11:59:59','BNBUSDT','4h','18.185700000000001','18.054700000000000','273.287327764819906','271.318712867554950','15.027594635610392','15.027594635610392','test','test','0.0'),('2019-04-13 15:59:59','2019-04-24 07:59:59','BNBUSDT','4h','18.379899999999999','21.444099999999999','272.849857787649910','318.337947180569188','14.84501318220719','14.845013182207190','test','test','1.76'),('2019-04-24 11:59:59','2019-04-24 15:59:59','BNBUSDT','4h','22.004500000000000','22.086600000000001','282.958322097187533','284.014055162886734','12.859111640672932','12.859111640672932','test','test','16.6'),('2019-04-24 19:59:59','2019-04-24 23:59:59','BNBUSDT','4h','21.862200000000001','22.970300000000002','283.192929445120683','297.546749514378973','12.953542161590356','12.953542161590356','test','test','0.0'),('2019-04-25 03:59:59','2019-04-25 23:59:59','BNBUSDT','4h','23.097600000000000','22.486300000000000','286.382667238289173','278.803276977709459','12.398806249925931','12.398806249925931','test','test','4.37'),('2019-04-26 03:59:59','2019-04-29 11:59:59','BNBUSDT','4h','23.489899999999999','22.114500000000000','284.698358291493719','268.028465188750829','12.120032792455214','12.120032792455214','test','test','4.50'),('2019-05-02 11:59:59','2019-05-04 15:59:59','BNBUSDT','4h','22.739300000000000','22.677000000000000','280.993937601995299','280.224084426541140','12.357193827514273','12.357193827514273','test','test','2.74'),('2019-05-04 19:59:59','2019-05-06 03:59:59','BNBUSDT','4h','22.831000000000000','22.419300000000000','280.822859118560984','275.758921003756086','12.300068289543209','12.300068289543209','test','test','1.50'),('2019-05-12 07:59:59','2019-05-12 11:59:59','BNBUSDT','4h','21.401000000000000','20.876899999999999','279.697539537493242','272.847883891887875','13.069367764940575','13.069367764940575','test','test','0.0'),('2019-05-13 03:59:59','2019-05-29 07:59:59','BNBUSDT','4h','21.890100000000000','32.824399999999997','278.175393838469859','417.126481720570894','12.707817407799409','12.707817407799409','test','test','4.62'),('2019-05-29 11:59:59','2019-05-30 23:59:59','BNBUSDT','4h','33.380000000000003','31.666599999999999','309.053413367825669','293.189659069909737','9.258640304608317','9.258640304608317','test','test','32.8'),('2019-05-31 19:59:59','2019-06-03 03:59:59','BNBUSDT','4h','31.916899999999998','32.081499999999998','305.528134634955393','307.103786749067808','9.572613086952536','9.572613086952536','test','test','0.78'),('2019-06-06 11:59:59','2019-06-06 15:59:59','BNBUSDT','4h','31.897099999999998','30.668399999999998','305.878279549202659','294.095620872329050','9.589532576604226','9.589532576604226','test','test','0.0'),('2019-06-08 03:59:59','2019-06-08 07:59:59','BNBUSDT','4h','31.497800000000002','31.468399999999999','303.259910954341819','302.976848601350241','9.627971190189214','9.627971190189214','test','test','2.63'),('2019-06-08 11:59:59','2019-06-08 15:59:59','BNBUSDT','4h','32.249200000000002','31.722100000000001','303.197008209232592','298.241376967927806','9.401690839128802','9.401690839128802','test','test','2.42'),('2019-06-08 19:59:59','2019-06-09 03:59:59','BNBUSDT','4h','31.583300000000001','31.401900000000001','302.095756822275973','300.360657251060786','9.565047250359397','9.565047250359397','test','test','0.0'),('2019-06-09 07:59:59','2019-06-09 11:59:59','BNBUSDT','4h','31.476600000000001','31.356999999999999','301.710179139783747','300.563786663305393','9.585221375236962','9.585221375236962','test','test','0.23'),('2019-06-10 15:59:59','2019-06-11 11:59:59','BNBUSDT','4h','31.620000000000001','31.108499999999999','301.455425256121828','296.578940435802167','9.533694663381462','9.533694663381462','test','test','0.83'),('2019-06-11 19:59:59','2019-06-14 11:59:59','BNBUSDT','4h','31.672300000000000','31.729299999999999','300.371761962717471','300.912334969157598','9.483736955090647','9.483736955090647','test','test','1.78'),('2019-06-15 07:59:59','2019-06-15 19:59:59','BNBUSDT','4h','33.049999999999997','32.847499999999997','300.491889297481976','298.650751397852900','9.092039010513828','9.092039010513828','test','test','4.01'),('2019-06-15 23:59:59','2019-06-16 07:59:59','BNBUSDT','4h','32.674300000000002','33.170000000000002','300.082747542008860','304.635286324984293','9.184060486131573','9.184060486131573','test','test','1.81'),('2019-06-16 11:59:59','2019-06-16 15:59:59','BNBUSDT','4h','32.779200000000003','32.433900000000001','301.094422827114499','297.922658287339175','9.185532985158712','9.185532985158712','test','test','0.0'),('2019-06-17 07:59:59','2019-06-25 23:59:59','BNBUSDT','4h','33.579999999999998','36.094099999999997','300.389586262719945','322.879445072222723','8.945490954815961','8.945490954815961','test','test','3.41'),('2019-06-26 03:59:59','2019-06-26 19:59:59','BNBUSDT','4h','36.372799999999998','36.088200000000001','305.387332664831661','302.997820862704486','8.396035847249363','8.396035847249363','test','test','8.80'),('2019-06-26 23:59:59','2019-06-27 03:59:59','BNBUSDT','4h','36.118899999999996','35.316299999999998','304.856330042136790','298.082101300624174','8.440354773875638','8.440354773875638','test','test','0.08'),('2019-07-08 07:59:59','2019-07-08 19:59:59','BNBUSDT','4h','33.718499999999999','33.413400000000003','303.350945877356196','300.606091462504423','8.99657297558777','8.996572975587769','test','test','0.0'),('2019-07-20 03:59:59','2019-07-21 15:59:59','BNBUSDT','4h','30.428500000000000','29.718399999999999','302.740978229611358','295.676010563086663','9.94925738138953','9.949257381389531','test','test','0.0'),('2019-07-21 23:59:59','2019-07-22 15:59:59','BNBUSDT','4h','30.438800000000001','29.940700000000000','301.170985414828067','296.242628586203864','9.894312043011816','9.894312043011816','test','test','2.36'),('2019-07-22 19:59:59','2019-07-23 07:59:59','BNBUSDT','4h','30.199999999999999','29.858599999999999','300.075795008467139','296.683547445027045','9.936284602929376','9.936284602929376','test','test','0.85'),('2019-08-01 15:59:59','2019-08-01 19:59:59','BNBUSDT','4h','28.489899999999999','28.284800000000001','299.321962216591601','297.167130699084623','10.506248256982005','10.506248256982005','test','test','0.0'),('2019-08-01 23:59:59','2019-08-02 03:59:59','BNBUSDT','4h','28.708800000000000','28.239999999999998','298.843110768256679','293.963155830113692','10.40946019228448','10.409460192284479','test','test','1.47'),('2019-08-02 07:59:59','2019-08-02 11:59:59','BNBUSDT','4h','28.428799999999999','28.092099999999999','297.758676337558256','294.232134720505940','10.47383907648435','10.473839076484349','test','test','0.66'),('2019-08-05 11:59:59','2019-08-05 15:59:59','BNBUSDT','4h','28.300000000000001','28.049800000000001','296.975000422657729','294.349447592065928','10.493816269351862','10.493816269351862','test','test','0.73'),('2019-08-07 15:59:59','2019-08-13 15:59:59','BNBUSDT','4h','28.730000000000000','29.267199999999999','296.391544238081792','301.933539976497968','10.316447763246842','10.316447763246842','test','test','2.36'),('2019-08-13 19:59:59','2019-08-13 23:59:59','BNBUSDT','4h','29.411200000000001','29.451200000000000','297.623098846618745','298.027874032733678','10.119379652874372','10.119379652874372','test','test','0.48'),('2019-08-19 07:59:59','2019-08-19 19:59:59','BNBUSDT','4h','28.968299999999999','28.480599999999999','297.713048887977607','292.700857839739797','10.277201247155602','10.277201247155602','test','test','0.0'),('2019-08-19 23:59:59','2019-08-20 03:59:59','BNBUSDT','4h','28.793099999999999','28.420100000000001','296.599228655035859','292.756936151334401','10.301052288744035','10.301052288744035','test','test','1.08'),('2019-08-20 07:59:59','2019-08-20 11:59:59','BNBUSDT','4h','28.444700000000001','27.985800000000001','295.745385876435535','290.974108359755917','10.397205309826981','10.397205309826981','test','test','0.08'),('2019-09-18 03:59:59','2019-09-19 03:59:59','BNBUSDT','4h','21.640699999999999','20.731100000000001','294.685101983840070','282.298923682560542','13.61717051591862','13.617170515918620','test','test','0.0'),('2019-09-19 23:59:59','2019-09-20 03:59:59','BNBUSDT','4h','21.537600000000001','21.389299999999999','291.932617916889001','289.922477175252254','13.554556585547553','13.554556585547553','test','test','3.74'),('2019-09-20 11:59:59','2019-09-20 15:59:59','BNBUSDT','4h','21.431100000000001','21.294799999999999','291.485919974303101','289.632093950790647','13.60107133904947','13.601071339049470','test','test','0.19'),('2019-10-09 07:59:59','2019-10-16 15:59:59','BNBUSDT','4h','16.963500000000000','17.608799999999999','291.073958635744759','302.146557186023074','17.158838602631814','17.158838602631814','test','test','0.0'),('2019-10-16 19:59:59','2019-10-20 07:59:59','BNBUSDT','4h','17.519300000000001','17.768100000000000','293.534536091362213','297.703161126582245','16.754923775000268','16.754923775000268','test','test','3.76'),('2019-10-20 11:59:59','2019-10-23 03:59:59','BNBUSDT','4h','17.968000000000000','17.800100000000000','294.460897210299947','291.709339739150721','16.388073086058547','16.388073086058547','test','test','1.11'),('2019-10-25 15:59:59','2019-11-07 11:59:59','BNBUSDT','4h','18.433199999999999','20.150900000000000','293.849439994489046','321.231836055863880','15.94131458425499','15.941314584254989','test','test','3.43'),('2019-11-07 15:59:59','2019-11-08 11:59:59','BNBUSDT','4h','20.233100000000000','20.014500000000002','299.934416897016774','296.693901922361988','14.823947734010941','14.823947734010941','test','test','0.48'),('2019-11-10 07:59:59','2019-11-10 15:59:59','BNBUSDT','4h','20.195900000000002','20.069600000000001','299.214302458204600','297.343092638366329','14.815596356597357','14.815596356597357','test','test','0.89'),('2019-11-10 19:59:59','2019-11-11 07:59:59','BNBUSDT','4h','20.541799999999999','20.082100000000001','298.798478053796146','292.111738802059222','14.54587611863596','14.545876118635960','test','test','2.29'),('2019-11-11 11:59:59','2019-11-11 15:59:59','BNBUSDT','4h','19.986999999999998','20.074800000000000','297.312535997854582','298.618586964013218','14.875295742125111','14.875295742125111','test','test','0.0'),('2019-11-11 19:59:59','2019-11-12 03:59:59','BNBUSDT','4h','20.156099999999999','20.250000000000000','297.602769545889828','298.989193509868983','14.7648984449318','14.764898444931800','test','test','0.40'),('2019-11-12 07:59:59','2019-11-12 15:59:59','BNBUSDT','4h','20.326899999999998','20.219999999999999','297.910863760107361','296.344138320618072','14.655991014867363','14.655991014867363','test','test','1.20'),('2019-11-12 19:59:59','2019-11-15 15:59:59','BNBUSDT','4h','20.638600000000000','20.140300000000000','297.562702551332052','290.378324992712351','14.417775554123441','14.417775554123441','test','test','2.36'),('2019-12-28 19:59:59','2019-12-31 19:59:59','BNBUSDT','4h','13.693400000000000','13.668100000000001','295.966174204972049','295.419345498632822','21.613782859258624','21.613782859258624','test','test','0.0'),('2019-12-31 23:59:59','2020-01-01 15:59:59','BNBUSDT','4h','13.716100000000001','13.822300000000000','295.844656714674500','298.135300741992637','21.5691527996059','21.569152799605899','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 20:55:49
