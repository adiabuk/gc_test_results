-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 11:59:59','2018-05-31 19:59:59','LTCETH','4h','0.212700000000000','0.206900000000000','1.297777777777778','1.262389385153842','6.101447004126834','6.101447004126834','test','test','0.0'),('2018-06-01 19:59:59','2018-06-01 23:59:59','LTCETH','4h','0.207230000000000','0.207420000000000','1.289913690528014','1.291096355205910','6.224550936293077','6.224550936293077','test','test','0.24'),('2018-06-02 03:59:59','2018-06-02 15:59:59','LTCETH','4h','0.207000000000000','0.207430000000000','1.290176504900880','1.292856581698500','6.232736738651596','6.232736738651596','test','test','0.0'),('2018-06-02 19:59:59','2018-06-03 03:59:59','LTCETH','4h','0.207510000000000','0.206420000000000','1.290772077522573','1.283991963000383','6.2202885524677045','6.220288552467705','test','test','0.04'),('2018-06-03 07:59:59','2018-06-03 11:59:59','LTCETH','4h','0.206290000000000','0.204620000000000','1.289265385406531','1.278828266817996','6.249771609901262','6.249771609901262','test','test','0.0'),('2018-06-11 03:59:59','2018-06-11 07:59:59','LTCETH','4h','0.202240000000000','0.201430000000000','1.286946025720190','1.281791623619550','6.3634593835056865','6.363459383505687','test','test','0.0'),('2018-06-11 19:59:59','2018-06-11 23:59:59','LTCETH','4h','0.203090000000000','0.201590000000000','1.285800603031159','1.276303823748345','6.331186188542808','6.331186188542808','test','test','0.81'),('2018-06-12 19:59:59','2018-06-12 23:59:59','LTCETH','4h','0.202240000000000','0.202100000000000','1.283690207634978','1.282801577151054','6.347360599460928','6.347360599460928','test','test','0.32'),('2018-06-14 15:59:59','2018-06-14 19:59:59','LTCETH','4h','0.203520000000000','0.193540000000000','1.283492734194106','1.220554165565680','6.306469802447455','6.306469802447455','test','test','0.69'),('2018-06-27 19:59:59','2018-06-27 23:59:59','LTCETH','4h','0.184770000000000','0.182540000000000','1.269506385610011','1.254184638357155','6.870738678411059','6.870738678411059','test','test','0.0'),('2018-07-03 03:59:59','2018-07-05 03:59:59','LTCETH','4h','0.182600000000000','0.180830000000000','1.266101552887154','1.253828826991150','6.933743444069848','6.933743444069848','test','test','0.09'),('2018-07-11 11:59:59','2018-07-11 15:59:59','LTCETH','4h','0.179540000000000','0.176820000000000','1.263374280465820','1.244234378255354','7.036728753847722','7.036728753847722','test','test','0.0'),('2018-07-11 19:59:59','2018-07-11 23:59:59','LTCETH','4h','0.176710000000000','0.175760000000000','1.259120968863494','1.252351884372405','7.125352095883053','7.125352095883053','test','test','0.0'),('2018-07-12 19:59:59','2018-07-13 11:59:59','LTCETH','4h','0.177020000000000','0.176210000000000','1.257616727865475','1.251862182901228','7.104376499070582','7.104376499070582','test','test','0.71'),('2018-07-13 15:59:59','2018-07-13 19:59:59','LTCETH','4h','0.176740000000000','0.176620000000000','1.256337940095642','1.255484932554556','7.108396175713714','7.108396175713714','test','test','0.29'),('2018-07-13 23:59:59','2018-07-14 03:59:59','LTCETH','4h','0.177240000000000','0.176370000000000','1.256148382864290','1.249982454783203','7.0872736564223064','7.087273656422306','test','test','0.34'),('2018-07-14 07:59:59','2018-07-14 11:59:59','LTCETH','4h','0.176520000000000','0.175470000000000','1.254778176624048','1.247314336348412','7.1084193101294355','7.108419310129436','test','test','0.08'),('2018-07-15 03:59:59','2018-07-15 07:59:59','LTCETH','4h','0.177350000000000','0.176580000000000','1.253119545451684','1.247678879818767','7.0657995232685895','7.065799523268590','test','test','1.06'),('2018-07-17 19:59:59','2018-07-21 03:59:59','LTCETH','4h','0.178010000000000','0.177600000000000','1.251910508644370','1.249027056543116','7.032810003058084','7.032810003058084','test','test','0.80'),('2018-07-21 07:59:59','2018-07-21 11:59:59','LTCETH','4h','0.178450000000000','0.180170000000000','1.251269741510758','1.263330172754235','7.011878629928594','7.011878629928594','test','test','0.91'),('2018-07-21 15:59:59','2018-07-22 07:59:59','LTCETH','4h','0.181300000000000','0.179190000000000','1.253949837342641','1.239356157492707','6.9164359478358595','6.916435947835859','test','test','0.72'),('2018-07-22 11:59:59','2018-07-22 15:59:59','LTCETH','4h','0.179150000000000','0.177460000000000','1.250706797375990','1.238908335262870','6.981338528473288','6.981338528473288','test','test','0.0'),('2018-07-22 19:59:59','2018-07-26 07:59:59','LTCETH','4h','0.179990000000000','0.180880000000000','1.248084916906407','1.254256346297188','6.934190326720413','6.934190326720413','test','test','1.40'),('2018-07-26 11:59:59','2018-07-26 19:59:59','LTCETH','4h','0.182790000000000','0.181230000000000','1.249456345659914','1.238793005765885','6.835474291043898','6.835474291043898','test','test','1.96'),('2018-07-26 23:59:59','2018-07-27 03:59:59','LTCETH','4h','0.180680000000000','0.179780000000000','1.247086714572352','1.240874748427150','6.9021846057801195','6.902184605780119','test','test','0.28'),('2018-07-30 03:59:59','2018-07-30 07:59:59','LTCETH','4h','0.180970000000000','0.179630000000000','1.245706277651196','1.236482392962836','6.883496036089938','6.883496036089938','test','test','0.65'),('2018-07-31 03:59:59','2018-07-31 07:59:59','LTCETH','4h','0.180800000000000','0.180590000000000','1.243656525498227','1.242212012940956','6.878631225100814','6.878631225100814','test','test','0.64'),('2018-07-31 11:59:59','2018-07-31 15:59:59','LTCETH','4h','0.180830000000000','0.180100000000000','1.243335522707722','1.238316250841458','6.875714885294046','6.875714885294046','test','test','0.13'),('2018-07-31 23:59:59','2018-08-01 03:59:59','LTCETH','4h','0.182380000000000','0.184150000000000','1.242220128959664','1.254275889614663','6.811164211863493','6.811164211863493','test','test','1.25'),('2018-08-01 07:59:59','2018-08-04 19:59:59','LTCETH','4h','0.183320000000000','0.179560000000000','1.244899186882997','1.219365579296918','6.790853081404085','6.790853081404085','test','test','1.35'),('2018-08-05 15:59:59','2018-08-05 19:59:59','LTCETH','4h','0.182610000000000','0.183130000000000','1.239225051863868','1.242753867520016','6.786183954131036','6.786183954131036','test','test','1.67'),('2018-08-05 23:59:59','2018-08-06 03:59:59','LTCETH','4h','0.182480000000000','0.184350000000000','1.240009233120790','1.252716473727628','6.795315832533922','6.795315832533922','test','test','0.0'),('2018-08-06 07:59:59','2018-08-06 11:59:59','LTCETH','4h','0.183730000000000','0.181220000000000','1.242833064366754','1.225854285770114','6.764453624159113','6.764453624159113','test','test','0.64'),('2018-08-07 07:59:59','2018-08-07 11:59:59','LTCETH','4h','0.183030000000000','0.182510000000000','1.239060002456390','1.235539753309926','6.769709897046329','6.769709897046329','test','test','0.98'),('2018-08-07 15:59:59','2018-08-07 19:59:59','LTCETH','4h','0.182230000000000','0.183210000000000','1.238277724868286','1.244936958640831','6.795136502597193','6.795136502597193','test','test','0.0'),('2018-08-11 15:59:59','2018-08-18 15:59:59','LTCETH','4h','0.180270000000000','0.195540000000000','1.239757554595519','1.344772797612513','6.877226130778935','6.877226130778935','test','test','0.0'),('2018-08-18 19:59:59','2018-08-19 15:59:59','LTCETH','4h','0.193820000000000','0.193950000000000','1.263094275265962','1.263941464698346','6.5168417875655855','6.516841787565586','test','test','5.83'),('2018-08-19 19:59:59','2018-08-20 11:59:59','LTCETH','4h','0.193370000000000','0.193620000000000','1.263282539584269','1.264915784838942','6.532981018690952','6.532981018690952','test','test','0.0'),('2018-08-20 15:59:59','2018-09-13 23:59:59','LTCETH','4h','0.195860000000000','0.258530000000000','1.263645482974197','1.667978488273864','6.451779245247609','6.451779245247609','test','test','2.21'),('2018-09-14 15:59:59','2018-09-14 19:59:59','LTCETH','4h','0.262000000000000','0.264460000000000','1.353497261929678','1.366205671335582','5.166020083701062','5.166020083701062','test','test','26.1'),('2018-09-14 23:59:59','2018-09-15 15:59:59','LTCETH','4h','0.269300000000000','0.259040000000000','1.356321352908768','1.304647171398022','5.03646993282127','5.036469932821270','test','test','24.0'),('2018-09-17 19:59:59','2018-09-18 03:59:59','LTCETH','4h','0.264870000000000','0.258880000000000','1.344838201461935','1.314424863497058','5.077351914002852','5.077351914002852','test','test','22.0'),('2018-09-18 07:59:59','2018-09-18 11:59:59','LTCETH','4h','0.259850000000000','0.262600000000000','1.338079681914185','1.352240617551145','5.149431140712661','5.149431140712661','test','test','0.37'),('2018-09-25 03:59:59','2018-09-29 11:59:59','LTCETH','4h','0.258220000000000','0.266050000000000','1.341226556500176','1.381896543090666','5.194123447061328','5.194123447061328','test','test','0.0'),('2018-09-29 15:59:59','2018-09-29 19:59:59','LTCETH','4h','0.265670000000000','0.263840000000000','1.350264331298063','1.340963380019125','5.082487037671031','5.082487037671031','test','test','1.15'),('2018-09-29 23:59:59','2018-09-30 03:59:59','LTCETH','4h','0.266250000000000','0.264200000000000','1.348197453236077','1.337816965802710','5.063652406520476','5.063652406520476','test','test','0.90'),('2018-10-01 11:59:59','2018-10-01 15:59:59','LTCETH','4h','0.265600000000000','0.263220000000000','1.345890678250884','1.333830362685232','5.06735948136628','5.067359481366280','test','test','0.52'),('2018-10-02 03:59:59','2018-10-02 11:59:59','LTCETH','4h','0.265280000000000','0.262000000000000','1.343210608125183','1.326602756818448','5.063369300833773','5.063369300833773','test','test','0.77'),('2018-10-02 23:59:59','2018-10-03 03:59:59','LTCETH','4h','0.264180000000000','0.260650000000000','1.339519974501465','1.321621172510435','5.070482150433282','5.070482150433282','test','test','0.82'),('2018-10-11 11:59:59','2018-10-11 15:59:59','LTCETH','4h','0.261990000000000','0.262340000000000','1.335542462947902','1.337326652657554','5.097684884720419','5.097684884720419','test','test','0.51'),('2018-10-11 19:59:59','2018-10-15 07:59:59','LTCETH','4h','0.260360000000000','0.261250000000000','1.335938949550047','1.340505648217659','5.131122098440803','5.131122098440803','test','test','0.0'),('2018-10-15 19:59:59','2018-10-15 23:59:59','LTCETH','4h','0.268080000000000','0.261860000000000','1.336953771476183','1.305933730971178','4.987144775724349','4.987144775724349','test','test','2.54'),('2018-10-19 15:59:59','2018-10-19 19:59:59','LTCETH','4h','0.262500000000000','0.263360000000000','1.330060429141738','1.334417960452450','5.066896872920906','5.066896872920906','test','test','0.24'),('2018-10-19 23:59:59','2018-10-20 03:59:59','LTCETH','4h','0.261930000000000','0.261310000000000','1.331028769433007','1.327878164931619','5.081620163528451','5.081620163528451','test','test','0.0'),('2018-10-23 15:59:59','2018-10-23 19:59:59','LTCETH','4h','0.261240000000000','0.258220000000000','1.330328635099365','1.314949702018673','5.09236194724914','5.092361947249140','test','test','0.0'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCETH','4h','0.257180000000000','0.255880000000000','1.326911094414767','1.320203790492459','5.159464555621615','5.159464555621615','test','test','0.0'),('2018-11-03 03:59:59','2018-11-03 07:59:59','LTCETH','4h','0.255860000000000','0.255760000000000','1.325420582432032','1.324902556721709','5.1802571032284535','5.180257103228453','test','test','0.03'),('2018-11-03 11:59:59','2018-11-03 15:59:59','LTCETH','4h','0.255890000000000','0.255230000000000','1.325305465607516','1.321887193665272','5.179199912491757','5.179199912491757','test','test','0.05'),('2018-11-03 19:59:59','2018-11-03 23:59:59','LTCETH','4h','0.256760000000000','0.255020000000000','1.324545849620350','1.315569724918919','5.158692357144222','5.158692357144222','test','test','0.59'),('2018-11-04 03:59:59','2018-11-04 07:59:59','LTCETH','4h','0.256280000000000','0.257430000000000','1.322551155242255','1.328485811979139','5.160571075551173','5.160571075551173','test','test','0.49'),('2018-11-04 11:59:59','2018-11-04 19:59:59','LTCETH','4h','0.263280000000000','0.255040000000000','1.323869967850451','1.282436176696213','5.028372712892931','5.028372712892931','test','test','2.22'),('2018-11-04 23:59:59','2018-11-05 03:59:59','LTCETH','4h','0.257270000000000','0.256190000000000','1.314662458705065','1.309143605144986','5.110049592665545','5.110049592665545','test','test','0.86'),('2018-11-05 07:59:59','2018-11-05 11:59:59','LTCETH','4h','0.257530000000000','0.256240000000000','1.313436046802825','1.306856881267254','5.100128322148198','5.100128322148198','test','test','0.52'),('2018-11-05 19:59:59','2018-11-05 23:59:59','LTCETH','4h','0.256780000000000','0.255820000000000','1.311974010017143','1.307069052272706','5.109330983788234','5.109330983788234','test','test','0.21'),('2018-11-06 03:59:59','2018-11-06 11:59:59','LTCETH','4h','0.258360000000000','0.255660000000000','1.310884019407268','1.297184581210954','5.0738659986347265','5.073865998634727','test','test','0.98'),('2018-11-20 03:59:59','2018-11-20 11:59:59','LTCETH','4h','0.251000000000000','0.243950000000000','1.307839699808087','1.271105556845350','5.210516732303135','5.210516732303135','test','test','0.0'),('2018-11-20 15:59:59','2018-11-20 19:59:59','LTCETH','4h','0.246030000000000','0.247730000000000','1.299676556927479','1.308656966417284','5.2825938175323275','5.282593817532327','test','test','0.84'),('2018-11-20 23:59:59','2018-12-07 19:59:59','LTCETH','4h','0.252840000000000','0.263770000000000','1.301672203480769','1.357942086347581','5.1482052028190495','5.148205202819049','test','test','2.02'),('2018-12-14 23:59:59','2018-12-19 19:59:59','LTCETH','4h','0.278400000000000','0.289990000000000','1.314176621895616','1.368886776521228','4.720462003935402','4.720462003935402','test','test','8.16'),('2018-12-19 23:59:59','2018-12-20 03:59:59','LTCETH','4h','0.292510000000000','0.290620000000000','1.326334434034641','1.317764566063202','4.534321678009779','4.534321678009779','test','test','11.7'),('2018-12-20 07:59:59','2018-12-20 11:59:59','LTCETH','4h','0.289160000000000','0.289960000000000','1.324430018929877','1.328094232566424','4.580267045683624','4.580267045683624','test','test','9.63'),('2019-01-06 07:59:59','2019-01-14 15:59:59','LTCETH','4h','0.232610000000000','0.251430000000000','1.325244288626887','1.432467097241985','5.697279947667282','5.697279947667282','test','test','0.0'),('2019-01-15 19:59:59','2019-01-16 15:59:59','LTCETH','4h','0.253570000000000','0.256340000000000','1.349071579430242','1.363808844386750','5.3203122586672','5.320312258667200','test','test','0.84'),('2019-01-16 19:59:59','2019-01-17 11:59:59','LTCETH','4h','0.257580000000000','0.254460000000000','1.352346527198355','1.335965903062712','5.2502000434752505','5.250200043475250','test','test','1.49'),('2019-01-17 15:59:59','2019-02-13 15:59:59','LTCETH','4h','0.255040000000000','0.338760000000000','1.348706388501545','1.791435759758404','5.288215136847339','5.288215136847339','test','test','0.22'),('2019-02-13 19:59:59','2019-02-13 23:59:59','LTCETH','4h','0.341570000000000','0.341510000000000','1.447090693225292','1.446836498062972','4.2365860386605725','4.236586038660572','test','test','24.9'),('2019-02-14 15:59:59','2019-02-17 11:59:59','LTCETH','4h','0.341340000000000','0.342220000000000','1.447034205411443','1.450764767609727','4.239275225322093','4.239275225322093','test','test','23.1'),('2019-02-20 11:59:59','2019-02-21 11:59:59','LTCETH','4h','0.346600000000000','0.337550000000000','1.447863219233284','1.410058365990176','4.177331850067178','4.177331850067178','test','test','1.39'),('2019-02-27 23:59:59','2019-02-28 03:59:59','LTCETH','4h','0.335070000000000','0.334360000000000','1.439462140734815','1.436411977724334','4.296004240113455','4.296004240113455','test','test','0.0'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LTCETH','4h','0.333050000000000','0.335310000000000','1.438784326732486','1.448547583235760','4.32002500144869','4.320025001448690','test','test','0.0'),('2019-02-28 15:59:59','2019-03-20 11:59:59','LTCETH','4h','0.336440000000000','0.432480000000000','1.440953939288770','1.852287955247911','4.282944772585809','4.282944772585809','test','test','0.61'),('2019-03-20 15:59:59','2019-03-29 07:59:59','LTCETH','4h','0.434530000000000','0.433750000000000','1.532361498390801','1.529610843732331','3.5264803313713684','3.526480331371368','test','test','22.3'),('2019-03-29 11:59:59','2019-03-29 15:59:59','LTCETH','4h','0.435560000000000','0.432430000000000','1.531750241800029','1.520742853020448','3.516737629258953','3.516737629258953','test','test','21.4'),('2019-04-02 07:59:59','2019-04-08 07:59:59','LTCETH','4h','0.448070000000000','0.493540000000000','1.529304155404567','1.684497450975004','3.4130920512521863','3.413092051252186','test','test','3.49'),('2019-04-08 11:59:59','2019-04-08 15:59:59','LTCETH','4h','0.498490000000000','0.489790000000000','1.563791554420220','1.536499158337137','3.1370570210439928','3.137057021043993','test','test','0.99'),('2019-04-08 23:59:59','2019-04-09 03:59:59','LTCETH','4h','0.495640000000000','0.490560000000000','1.557726577512868','1.541760854379615','3.1428588844985637','3.142858884498564','test','test','1.18'),('2019-04-09 11:59:59','2019-04-09 15:59:59','LTCETH','4h','0.498480000000000','0.493150000000000','1.554178639038812','1.537560575834517','3.1178354979915177','3.117835497991518','test','test','1.58'),('2019-04-10 19:59:59','2019-04-10 23:59:59','LTCETH','4h','0.496650000000000','0.498150000000000','1.550485736104524','1.555168568288470','3.121888122630674','3.121888122630674','test','test','0.70'),('2019-04-11 03:59:59','2019-04-11 07:59:59','LTCETH','4h','0.499910000000000','0.493730000000000','1.551526365478734','1.532346047144117','3.1036113810060497','3.103611381006050','test','test','0.35'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCETH','4h','0.499060000000000','0.485620000000000','1.547264072515486','1.505595276910532','3.1003568158447607','3.100356815844761','test','test','1.06'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LTCETH','4h','0.493240000000000','0.484090000000000','1.538004340158830','1.509473118618701','3.1181662885387027','3.118166288538703','test','test','1.54'),('2019-04-15 23:59:59','2019-04-16 03:59:59','LTCETH','4h','0.488330000000000','0.485630000000000','1.531664068705467','1.523195424580583','3.1365348610682684','3.136534861068268','test','test','0.86'),('2019-04-26 03:59:59','2019-04-27 07:59:59','LTCETH','4h','0.471700000000000','0.464160000000000','1.529782147788827','1.505328983925508','3.2431251808115893','3.243125180811589','test','test','0.0'),('2019-04-27 11:59:59','2019-04-27 15:59:59','LTCETH','4h','0.462750000000000','0.460580000000000','1.524348111374756','1.517199898729303','3.294107209886021','3.294107209886021','test','test','0.0'),('2019-04-30 19:59:59','2019-05-01 03:59:59','LTCETH','4h','0.458280000000000','0.454640000000000','1.522759619675766','1.510664732236602','3.3227712744954316','3.322771274495432','test','test','0.0'),('2019-05-01 07:59:59','2019-05-01 11:59:59','LTCETH','4h','0.456280000000000','0.455070000000000','1.520071866911508','1.516040818084115','3.331445311895125','3.331445311895125','test','test','0.35'),('2019-05-01 15:59:59','2019-05-01 19:59:59','LTCETH','4h','0.456830000000000','0.456850000000000','1.519176078283198','1.519242587754042','3.3254735421999393','3.325473542199939','test','test','0.38'),('2019-05-01 23:59:59','2019-05-02 03:59:59','LTCETH','4h','0.457610000000000','0.457490000000000','1.519190858165608','1.518792477660418','3.319837543247761','3.319837543247761','test','test','0.16'),('2019-05-02 07:59:59','2019-05-02 15:59:59','LTCETH','4h','0.458290000000000','0.456460000000000','1.519102329164454','1.513036394358172','3.314718473378111','3.314718473378111','test','test','0.17'),('2019-05-03 03:59:59','2019-05-03 11:59:59','LTCETH','4h','0.460070000000000','0.470640000000000','1.517754343651948','1.552624392584504','3.2989639482077675','3.298963948207768','test','test','0.78'),('2019-05-03 15:59:59','2019-05-06 03:59:59','LTCETH','4h','0.468990000000000','0.449870000000000','1.525503243414738','1.463310825635916','3.2527415156287716','3.252741515628772','test','test','1.79'),('2019-05-11 11:59:59','2019-05-12 03:59:59','LTCETH','4h','0.457700000000000','0.457310000000000','1.511682706130555','1.510394621674818','3.3027806557364108','3.302780655736411','test','test','1.71'),('2019-05-12 07:59:59','2019-05-13 07:59:59','LTCETH','4h','0.458300000000000','0.452100000000000','1.511396465140391','1.490949905934913','3.297832129915757','3.297832129915757','test','test','1.79'),('2019-05-13 11:59:59','2019-05-13 15:59:59','LTCETH','4h','0.453940000000000','0.449710000000000','1.506852785316952','1.492811310051739','3.319497698631871','3.319497698631871','test','test','0.40'),('2019-05-24 11:59:59','2019-05-30 19:59:59','LTCETH','4h','0.395420000000000','0.421150000000000','1.503732457480238','1.601580406827683','3.802874051591315','3.802874051591315','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 19:59:37
