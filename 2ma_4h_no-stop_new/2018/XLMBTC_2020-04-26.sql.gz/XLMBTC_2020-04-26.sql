-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-25 15:59:59','2018-05-25 19:59:59','XLMBTC','4h','0.000039240000000','0.000038570000000','0.033333333333333','0.032764186204553','849.4733265375468','849.473326537546768','test','test','0.0'),('2018-05-26 03:59:59','2018-05-26 07:59:59','XLMBTC','4h','0.000038790000000','0.000038810000000','0.033206856193604','0.033223977542505','856.0674450529631','856.067445052963080','test','test','0.56'),('2018-05-26 11:59:59','2018-05-26 15:59:59','XLMBTC','4h','0.000038730000000','0.000038790000000','0.033210660937805','0.033262110451264','857.491890983854','857.491890983853978','test','test','0.0'),('2018-05-26 19:59:59','2018-05-26 23:59:59','XLMBTC','4h','0.000038590000000','0.000038570000000','0.033222094163018','0.033204876182109','860.899045426737','860.899045426736961','test','test','0.0'),('2018-05-31 11:59:59','2018-06-01 19:59:59','XLMBTC','4h','0.000038600000000','0.000038080000000','0.033218267945038','0.032770767962359','860.5768897678237','860.576889767823673','test','test','0.07'),('2018-06-01 23:59:59','2018-06-04 15:59:59','XLMBTC','4h','0.000038380000000','0.000038500000000','0.033118823504443','0.033222373760319','862.9187989693243','862.918798969324257','test','test','0.78'),('2018-06-04 19:59:59','2018-06-05 03:59:59','XLMBTC','4h','0.000038520000000','0.000038120000000','0.033141834672415','0.032797682702816','860.3799239983156','860.379923998315576','test','test','0.05'),('2018-06-05 15:59:59','2018-06-05 23:59:59','XLMBTC','4h','0.000038690000000','0.000038550000000','0.033065356456949','0.032945709263773','854.6228083987768','854.622808398776783','test','test','1.47'),('2018-06-06 03:59:59','2018-06-06 07:59:59','XLMBTC','4h','0.000038420000000','0.000038320000000','0.033038768191798','0.032952774521335','859.9367046277574','859.936704627757422','test','test','0.0'),('2018-06-06 15:59:59','2018-06-06 19:59:59','XLMBTC','4h','0.000038730000000','0.000038560000000','0.033019658487251','0.032874723244730','852.5602501226728','852.560250122672755','test','test','1.05'),('2018-06-06 23:59:59','2018-06-07 15:59:59','XLMBTC','4h','0.000039100000000','0.000038440000000','0.032987450655580','0.032430629237864','843.6688147207104','843.668814720710429','test','test','1.40'),('2018-06-07 19:59:59','2018-06-07 23:59:59','XLMBTC','4h','0.000038900000000','0.000038040000000','0.032863712562754','0.032137162619207','844.8255157520309','844.825515752030924','test','test','1.18'),('2018-07-02 15:59:59','2018-07-03 19:59:59','XLMBTC','4h','0.000032210000000','0.000031750000000','0.032702257019744','0.032235226959853','1015.282738893001','1015.282738893001010','test','test','0.0'),('2018-07-04 15:59:59','2018-07-04 19:59:59','XLMBTC','4h','0.000032060000000','0.000032110000000','0.032598472561990','0.032649312350764','1016.7957754831565','1016.795775483156490','test','test','0.96'),('2018-07-04 23:59:59','2018-07-05 03:59:59','XLMBTC','4h','0.000031940000000','0.000032150000000','0.032609770292829','0.032824173917171','1020.9696397253808','1020.969639725380830','test','test','0.0'),('2018-07-05 07:59:59','2018-07-05 11:59:59','XLMBTC','4h','0.000031810000000','0.000031940000000','0.032657415542682','0.032790878731005','1026.6399101754932','1026.639910175493242','test','test','0.0'),('2018-07-08 19:59:59','2018-07-08 23:59:59','XLMBTC','4h','0.000031800000000','0.000031350000000','0.032687074028976','0.032224521094604','1027.8954097162405','1027.895409716240465','test','test','0.0'),('2018-07-09 03:59:59','2018-07-09 07:59:59','XLMBTC','4h','0.000031770000000','0.000031680000000','0.032584284488005','0.032491977733081','1025.6306102614067','1025.630610261406673','test','test','1.32'),('2018-07-09 11:59:59','2018-07-09 15:59:59','XLMBTC','4h','0.000031750000000','0.000031590000000','0.032563771875800','0.032399670978158','1025.6306102614033','1025.630610261403262','test','test','0.22'),('2018-07-13 23:59:59','2018-07-23 19:59:59','XLMBTC','4h','0.000033070000000','0.000036490000000','0.032527305009657','0.035891181124959','983.589507398152','983.589507398152023','test','test','4.47'),('2018-07-23 23:59:59','2018-07-24 03:59:59','XLMBTC','4h','0.000037040000000','0.000036560000000','0.033274833035280','0.032843625695730','898.3486240626232','898.348624062623230','test','test','13.7'),('2018-07-24 07:59:59','2018-07-24 11:59:59','XLMBTC','4h','0.000036830000000','0.000035920000000','0.033179009182046','0.032359218295387','900.8691062190125','900.869106219012451','test','test','12.8'),('2018-07-24 15:59:59','2018-07-24 19:59:59','XLMBTC','4h','0.000036770000000','0.000036270000000','0.032996833429455','0.032548141106509','897.3846458921768','897.384645892176763','test','test','2.31'),('2018-07-25 11:59:59','2018-07-26 23:59:59','XLMBTC','4h','0.000037250000000','0.000038850000000','0.032897124024356','0.034310154854932','883.1442691102343','883.144269110234291','test','test','2.63'),('2018-07-27 03:59:59','2018-07-29 15:59:59','XLMBTC','4h','0.000038690000000','0.000037760000000','0.033211130875595','0.032412827652170','858.3905628223143','858.390562822314337','test','test','1.96'),('2018-08-10 19:59:59','2018-08-11 03:59:59','XLMBTC','4h','0.000035980000000','0.000034560000000','0.033033730159279','0.031730008735539','918.1136786903467','918.113678690346660','test','test','0.0'),('2018-08-11 11:59:59','2018-08-11 15:59:59','XLMBTC','4h','0.000034700000000','0.000033900000000','0.032744014287336','0.031989109058810','943.6315356581106','943.631535658110579','test','test','0.40'),('2018-08-11 23:59:59','2018-08-13 23:59:59','XLMBTC','4h','0.000034680000000','0.000035480000000','0.032576257569886','0.033327728332744','939.3384535722672','939.338453572267213','test','test','2.24'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XLMBTC','4h','0.000035810000000','0.000035260000000','0.032743251072744','0.032240352773665','914.3605437794907','914.360543779490740','test','test','0.92'),('2018-08-14 11:59:59','2018-08-14 15:59:59','XLMBTC','4h','0.000035020000000','0.000035010000000','0.032631495895170','0.032622177935177','931.7959992909894','931.795999290989357','test','test','0.0'),('2018-08-14 19:59:59','2018-08-14 23:59:59','XLMBTC','4h','0.000035190000000','0.000035030000000','0.032629425237394','0.032481067521055','927.2357271211772','927.235727121177206','test','test','0.51'),('2018-08-15 03:59:59','2018-08-15 11:59:59','XLMBTC','4h','0.000036040000000','0.000034650000000','0.032596456855986','0.031339268314648','904.452188012918','904.452188012917986','test','test','2.80'),('2018-08-17 15:59:59','2018-08-18 07:59:59','XLMBTC','4h','0.000035500000000','0.000034980000000','0.032317081624577','0.031843704654302','910.3403274528765','910.340327452876522','test','test','2.39'),('2018-08-18 11:59:59','2018-08-18 15:59:59','XLMBTC','4h','0.000035420000000','0.000035140000000','0.032211886742294','0.031957247321406','909.4265031703495','909.426503170349520','test','test','1.24'),('2018-08-18 19:59:59','2018-08-18 23:59:59','XLMBTC','4h','0.000034940000000','0.000034740000000','0.032155300204319','0.031971240100116','920.3005210165618','920.300521016561788','test','test','0.0'),('2018-08-19 03:59:59','2018-08-19 07:59:59','XLMBTC','4h','0.000035010000000','0.000035020000000','0.032114397958940','0.032123570880379','917.2921439285984','917.292143928598421','test','test','0.77'),('2018-08-19 11:59:59','2018-08-19 19:59:59','XLMBTC','4h','0.000035430000000','0.000035280000000','0.032116436385927','0.031980465021042','906.475765902531','906.475765902530952','test','test','1.15'),('2018-08-19 23:59:59','2018-08-20 07:59:59','XLMBTC','4h','0.000035200000000','0.000035080000000','0.032086220527063','0.031976835684357','911.5403558824813','911.540355882481322','test','test','0.17'),('2018-09-06 23:59:59','2018-09-07 03:59:59','XLMBTC','4h','0.000031930000000','0.000032050000000','0.032061912784240','0.032182408541650','1004.1313117519508','1004.131311751950761','test','test','0.0'),('2018-09-07 07:59:59','2018-09-07 11:59:59','XLMBTC','4h','0.000031590000000','0.000031540000000','0.032088689619220','0.032037900303583','1015.7863127325033','1015.786312732503347','test','test','0.0'),('2018-09-07 15:59:59','2018-09-08 19:59:59','XLMBTC','4h','0.000031890000000','0.000031450000000','0.032077403104634','0.031634817423667','1005.8765476523607','1005.876547652360728','test','test','1.09'),('2018-09-11 23:59:59','2018-09-12 03:59:59','XLMBTC','4h','0.000031880000000','0.000030870000000','0.031979050731086','0.030965912674675','1003.1069865459714','1003.106986545971381','test','test','1.34'),('2018-09-12 19:59:59','2018-09-12 23:59:59','XLMBTC','4h','0.000031760000000','0.000031060000000','0.031753908940772','0.031054043189559','999.8082160192697','999.808216019269707','test','test','2.80'),('2018-09-13 03:59:59','2018-09-14 11:59:59','XLMBTC','4h','0.000031760000000','0.000031120000000','0.031598383218280','0.030961639979624','994.9113103992515','994.911310399251533','test','test','2.20'),('2018-09-15 15:59:59','2018-09-15 19:59:59','XLMBTC','4h','0.000031310000000','0.000031220000000','0.031456884720801','0.031366462503462','1004.6913037624123','1004.691303762412304','test','test','0.60'),('2018-09-16 11:59:59','2018-09-17 07:59:59','XLMBTC','4h','0.000031780000000','0.000031610000000','0.031436790894726','0.031268626815050','989.2004686823722','989.200468682372161','test','test','1.76'),('2018-09-17 11:59:59','2018-09-17 23:59:59','XLMBTC','4h','0.000032180000000','0.000031300000000','0.031399421099242','0.030540766948610','975.7433529907468','975.743352990746757','test','test','1.77'),('2018-09-18 11:59:59','2018-10-02 23:59:59','XLMBTC','4h','0.000032350000000','0.000037790000000','0.031208609065768','0.036456671919486','964.717436345238','964.717436345237957','test','test','3.24'),('2018-10-08 23:59:59','2018-10-09 03:59:59','XLMBTC','4h','0.000037490000000','0.000037140000000','0.032374845255484','0.032072599434214','863.5594893433865','863.559489343386531','test','test','14.5'),('2018-10-17 07:59:59','2018-10-18 19:59:59','XLMBTC','4h','0.000035690000000','0.000036470000000','0.032307679517424','0.033013759372386','905.2305832844932','905.230583284493150','test','test','1.70'),('2018-10-18 23:59:59','2018-10-24 11:59:59','XLMBTC','4h','0.000036970000000','0.000037070000000','0.032464586151860','0.032552399476588','878.133247277781','878.133247277781038','test','test','4.62'),('2018-10-24 15:59:59','2018-10-24 19:59:59','XLMBTC','4h','0.000036980000000','0.000036720000000','0.032484100224021','0.032255710119688','878.4234782050119','878.423478205011861','test','test','0.0'),('2018-11-02 23:59:59','2018-11-14 01:59:59','XLMBTC','4h','0.000037030000000','0.000040050000000','0.032433346867503','0.035078464543438','875.8667801107993','875.866780110799255','test','test','0.83'),('2018-11-14 11:59:59','2018-11-14 15:59:59','XLMBTC','4h','0.000040050000000','0.000039000000000','0.033021150795488','0.032155427740925','824.4981472032073','824.498147203207282','test','test','7.44'),('2018-11-14 23:59:59','2018-11-15 03:59:59','XLMBTC','4h','0.000040760000000','0.000040300000000','0.032828767894474','0.032458276402044','805.416287891915','805.416287891914976','test','test','7.36'),('2018-11-15 07:59:59','2018-11-15 15:59:59','XLMBTC','4h','0.000041210000000','0.000041010000000','0.032746436451712','0.032587511741925','794.623548937448','794.623548937448049','test','test','7.69'),('2018-11-15 19:59:59','2018-11-20 11:59:59','XLMBTC','4h','0.000041980000000','0.000044250000000','0.032711119849537','0.034479920279705','779.2072379594413','779.207237959441272','test','test','7.59'),('2018-11-20 15:59:59','2018-11-21 03:59:59','XLMBTC','4h','0.000044590000000','0.000042970000000','0.033104186611797','0.031901477880891','742.412796855728','742.412796855727947','test','test','12.9'),('2018-11-21 07:59:59','2018-11-22 23:59:59','XLMBTC','4h','0.000044250000000','0.000042740000000','0.032836918004929','0.031716381367925','742.0772430492407','742.077243049240678','test','test','2.89'),('2018-12-01 11:59:59','2018-12-01 15:59:59','XLMBTC','4h','0.000039980000000','0.000039730000000','0.032587909863372','0.032384133538564','815.1052992339283','815.105299233928349','test','test','0.0'),('2018-12-23 23:59:59','2018-12-24 03:59:59','XLMBTC','4h','0.000031720000000','0.000031810000000','0.032542626235637','0.032634960294944','1025.9339922962592','1025.933992296259248','test','test','0.0'),('2018-12-24 07:59:59','2018-12-25 03:59:59','XLMBTC','4h','0.000033080000000','0.000031420000000','0.032563144915483','0.030929081416097','984.3756020400043','984.375602040004310','test','test','3.83'),('2018-12-25 07:59:59','2018-12-25 11:59:59','XLMBTC','4h','0.000031780000000','0.000031580000000','0.032200019693398','0.031997376397656','1013.2164787098039','1013.216478709803937','test','test','1.13'),('2018-12-25 23:59:59','2018-12-26 03:59:59','XLMBTC','4h','0.000031730000000','0.000031910000000','0.032154987849899','0.032337398748512','1013.393881181826','1013.393881181826032','test','test','0.47'),('2018-12-26 07:59:59','2018-12-26 11:59:59','XLMBTC','4h','0.000031530000000','0.000030910000000','0.032195523605147','0.031562436873933','1021.1076309910143','1021.107630991014275','test','test','0.0'),('2019-01-07 11:59:59','2019-01-08 03:59:59','XLMBTC','4h','0.000030480000000','0.000030050000000','0.032054837664877','0.031602620466849','1051.6679023909744','1051.667902390974405','test','test','0.0'),('2019-01-08 07:59:59','2019-01-08 11:59:59','XLMBTC','4h','0.000030310000000','0.000030530000000','0.031954344954204','0.032186280153476','1054.250905780403','1054.250905780402945','test','test','0.85'),('2019-01-08 15:59:59','2019-01-09 19:59:59','XLMBTC','4h','0.000030690000000','0.000030460000000','0.032005886109598','0.031766024467200','1042.876706080084','1042.876706080083977','test','test','0.97'),('2019-01-09 23:59:59','2019-01-10 07:59:59','XLMBTC','4h','0.000030870000000','0.000030400000000','0.031952583522398','0.031466101039226','1035.0691131324336','1035.069113132433586','test','test','1.32'),('2019-01-13 03:59:59','2019-01-13 19:59:59','XLMBTC','4h','0.000030740000000','0.000029270000000','0.031844476303916','0.030321659772792','1035.929613009615','1035.929613009614968','test','test','2.08'),('2019-01-17 15:59:59','2019-01-17 19:59:59','XLMBTC','4h','0.000029880000000','0.000029570000000','0.031506072630332','0.031179202398893','1054.4201014167486','1054.420101416748594','test','test','2.04'),('2019-02-19 11:59:59','2019-02-20 03:59:59','XLMBTC','4h','0.000022370000000','0.000022480000000','0.031433434801124','0.031588002428666','1405.1602503855065','1405.160250385506515','test','test','0.0'),('2019-02-20 07:59:59','2019-02-24 15:59:59','XLMBTC','4h','0.000022410000000','0.000021910000000','0.031467783162800','0.030765690722755','1404.1848800892362','1404.184880089236231','test','test','0.0'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMBTC','4h','0.000022620000000','0.000022470000000','0.031311762620568','0.031104124937408','1384.2512210684156','1384.251221068415589','test','test','3.13'),('2019-02-26 03:59:59','2019-02-26 07:59:59','XLMBTC','4h','0.000022290000000','0.000022160000000','0.031265620913199','0.031083273191408','1402.674783005773','1402.674783005772952','test','test','0.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','XLMBTC','4h','0.000022290000000','0.000022170000000','0.031225099197245','0.031056996375187','1400.85685048206','1400.856850482060054','test','test','0.58'),('2019-03-03 15:59:59','2019-03-04 07:59:59','XLMBTC','4h','0.000022850000000','0.000022260000000','0.031187743014566','0.030382457746356','1364.8902851013374','1364.890285101337440','test','test','2.97'),('2019-03-05 23:59:59','2019-03-06 03:59:59','XLMBTC','4h','0.000022210000000','0.000021920000000','0.031008790732741','0.030603903325605','1396.163472883436','1396.163472883436043','test','test','0.0'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMBTC','4h','0.000022390000000','0.000026230000000','0.030918815753378','0.036221551460969','1380.9207571852419','1380.920757185241882','test','test','2.09'),('2019-03-22 15:59:59','2019-03-23 11:59:59','XLMBTC','4h','0.000027200000000','0.000026620000000','0.032097201466176','0.031412775846677','1180.0441715505722','1180.044171550572173','test','test','18.1'),('2019-03-23 15:59:59','2019-03-23 19:59:59','XLMBTC','4h','0.000026680000000','0.000026850000000','0.031945106884065','0.032148655166310','1197.3428367340584','1197.342836734058437','test','test','15.7'),('2019-03-23 23:59:59','2019-03-24 03:59:59','XLMBTC','4h','0.000026640000000','0.000026490000000','0.031990339835675','0.031810214048312','1200.8385824202205','1200.838582420220519','test','test','15.6'),('2019-03-27 11:59:59','2019-03-27 15:59:59','XLMBTC','4h','0.000026370000000','0.000026410000000','0.031950311882927','0.031998776519837','1211.615922750373','1211.615922750373102','test','test','0.0'),('2019-03-27 19:59:59','2019-03-28 07:59:59','XLMBTC','4h','0.000026520000000','0.000026340000000','0.031961081802241','0.031744151382769','1205.1689970678985','1205.168997067898545','test','test','0.41'),('2019-03-28 23:59:59','2019-03-29 03:59:59','XLMBTC','4h','0.000026440000000','0.000026380000000','0.031912875042358','0.031840455507466','1206.992248198109','1206.992248198109110','test','test','0.37'),('2019-03-31 23:59:59','2019-04-01 03:59:59','XLMBTC','4h','0.000026380000000','0.000026650000000','0.031896781812382','0.032223246220621','1209.1274379219863','1209.127437921986257','test','test','0.0'),('2019-04-01 07:59:59','2019-04-02 07:59:59','XLMBTC','4h','0.000026510000000','0.000024900000000','0.031969329458657','0.030027774557547','1205.9347211866216','1205.934721186621573','test','test','0.45'),('2019-04-07 23:59:59','2019-04-08 03:59:59','XLMBTC','4h','0.000025560000000','0.000025130000000','0.031537872813966','0.031007306096047','1233.8760881833423','1233.876088183342290','test','test','2.58'),('2019-05-15 19:59:59','2019-05-15 23:59:59','XLMBTC','4h','0.000015500000000','0.000017320000000','0.031419969098873','0.035109281599515','2027.094780572459','2027.094780572459058','test','test','0.0'),('2019-05-16 03:59:59','2019-05-22 11:59:59','XLMBTC','4h','0.000018420000000','0.000016550000000','0.032239816321238','0.028966827367888','1750.2614723799136','1750.261472379913585','test','test','9.06');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 19:49:27
