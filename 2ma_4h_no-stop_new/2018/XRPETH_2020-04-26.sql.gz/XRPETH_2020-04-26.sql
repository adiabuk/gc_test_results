-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 15:59:59','2018-04-23 03:59:59','XRPETH','4h','0.001335000000000','0.001344130000000','1.297777777777778','1.306653216812318','972.1181856013316','972.118185601331561','test','test','0.0'),('2018-04-23 07:59:59','2018-04-23 15:59:59','XRPETH','4h','0.001358300000000','0.001350000000000','1.299750097563231','1.291807871390976','956.8947195488706','956.894719548870626','test','test','1.83'),('2018-04-23 19:59:59','2018-04-23 23:59:59','XRPETH','4h','0.001354670000000','0.001358950000000','1.297985158413841','1.302086065998723','958.15597777602','958.155977776019995','test','test','0.34'),('2018-04-24 03:59:59','2018-04-24 07:59:59','XRPETH','4h','0.001358430000000','0.001337070000000','1.298896471210482','1.278472578462931','956.1747540988358','956.174754098835820','test','test','0.0'),('2018-05-23 19:59:59','2018-05-25 19:59:59','XRPETH','4h','0.001027800000000','0.001034590000000','1.294357828377692','1.302908800993653','1259.3479552225067','1259.347955222506698','test','test','0.0'),('2018-05-25 23:59:59','2018-06-10 11:59:59','XRPETH','4h','0.001034050000000','0.001095710000000','1.296258044514573','1.373553408399075','1253.573854759995','1253.573854759994902','test','test','1.71'),('2018-06-10 19:59:59','2018-06-10 23:59:59','XRPETH','4h','0.001101010000000','0.001109660000000','1.313434792044462','1.323753691011033','1192.9362967134375','1192.936296713437514','test','test','0.48'),('2018-06-11 03:59:59','2018-06-11 07:59:59','XRPETH','4h','0.001096150000000','0.001085340000000','1.315727880703700','1.302752449977607','1200.3173659660629','1200.317365966062880','test','test','0.0'),('2018-06-11 15:59:59','2018-06-11 19:59:59','XRPETH','4h','0.001099530000000','0.001111530000000','1.312844451653457','1.327172513115938','1194.005121873398','1194.005121873397911','test','test','1.29'),('2018-06-11 23:59:59','2018-06-12 15:59:59','XRPETH','4h','0.001126940000000','0.001098510000000','1.316028465311786','1.282828215725460','1167.7892925193762','1167.789292519376204','test','test','1.78'),('2018-06-12 19:59:59','2018-06-13 19:59:59','XRPETH','4h','0.001129000000000','0.001102520000000','1.308650632070380','1.277957037086125','1159.123677653127','1159.123677653127061','test','test','2.70'),('2018-06-13 23:59:59','2018-06-14 03:59:59','XRPETH','4h','0.001112930000000','0.001125040000000','1.301829833184990','1.315995287687852','1169.7319985848078','1169.731998584807798','test','test','0.93'),('2018-06-14 07:59:59','2018-06-14 19:59:59','XRPETH','4h','0.001131750000000','0.001075240000000','1.304977711963404','1.239818188656091','1153.0618175068735','1153.061817506873467','test','test','1.95'),('2018-06-24 19:59:59','2018-06-24 23:59:59','XRPETH','4h','0.001052870000000','0.001041280000000','1.290497817895113','1.276292009286828','1225.6953070133184','1225.695307013318370','test','test','0.0'),('2018-06-25 03:59:59','2018-06-25 11:59:59','XRPETH','4h','0.001054250000000','0.001049570000000','1.287340971537716','1.281626239978032','1221.0964871118954','1221.096487111895385','test','test','1.23'),('2018-06-26 01:59:59','2018-06-27 03:59:59','XRPETH','4h','0.001052620000000','0.001059700000000','1.286071031191119','1.294721240099208','1221.7809192216748','1221.780919221674822','test','test','0.28'),('2018-06-27 07:59:59','2018-06-28 15:59:59','XRPETH','4h','0.001061300000000','0.001057100000000','1.287993299837361','1.282896181341821','1213.5996417953086','1213.599641795308571','test','test','0.59'),('2018-06-28 19:59:59','2018-06-28 23:59:59','XRPETH','4h','0.001054730000000','0.001060350000000','1.286860606838352','1.293717486428798','1220.0853363783644','1220.085336378364445','test','test','0.0'),('2018-06-29 03:59:59','2018-06-29 11:59:59','XRPETH','4h','0.001061660000000','0.001042860000000','1.288384357858452','1.265569496294732','1213.5564661553146','1213.556466155314638','test','test','0.42'),('2018-07-03 03:59:59','2018-07-03 23:59:59','XRPETH','4h','0.001052550000000','0.001051360000000','1.283314388622069','1.281863489261031','1219.2431605359075','1219.243160535907464','test','test','0.92'),('2018-07-04 00:22:26','2018-07-04 11:59:59','XRPETH','4h','0.001045710000000','0.001034280000000','1.282991966541839','1.268968386220743','1226.9099143565986','1226.909914356598620','test','test','0.0'),('2018-07-04 15:59:59','2018-07-04 19:59:59','XRPETH','4h','0.001048610000000','0.001065490000000','1.279875615359373','1.300478413718407','1220.5449264830327','1220.544926483032668','test','test','1.36'),('2018-07-04 23:59:59','2018-07-05 03:59:59','XRPETH','4h','0.001049450000000','0.001048280000000','1.284454014994714','1.283022016140510','1223.930644618337','1223.930644618337055','test','test','0.0'),('2018-07-10 19:59:59','2018-07-10 23:59:59','XRPETH','4h','0.001023610000000','0.001023710000000','1.284135793027113','1.284261244692593','1254.5166548071165','1254.516654807116538','test','test','0.0'),('2018-07-11 03:59:59','2018-07-11 07:59:59','XRPETH','4h','0.001027970000000','0.001022150000000','1.284163671174997','1.276893193859279','1249.2229064807311','1249.222906480731126','test','test','0.41'),('2018-07-11 19:59:59','2018-07-11 23:59:59','XRPETH','4h','0.001023320000000','0.001010680000000','1.282548009549282','1.266706037496842','1253.320573768989','1253.320573768989107','test','test','0.11'),('2018-07-17 15:59:59','2018-07-17 19:59:59','XRPETH','4h','0.001014080000000','0.001013990000000','1.279027571315406','1.278914057113944','1261.2689051311595','1261.268905131159499','test','test','0.33'),('2018-07-17 23:59:59','2018-07-18 19:59:59','XRPETH','4h','0.001016060000000','0.001015460000000','1.279002345937304','1.278247074193940','1258.7862389399286','1258.786238939928580','test','test','0.20'),('2018-07-18 23:59:59','2018-07-19 03:59:59','XRPETH','4h','0.001018320000000','0.001006390000000','1.278834507772112','1.263852482792026','1255.8277435109903','1255.827743510990331','test','test','0.28'),('2018-07-19 11:59:59','2018-07-19 23:59:59','XRPETH','4h','0.001018000000000','0.001018880000000','1.275505168887648','1.276607766676078','1252.9520323061379','1252.952032306137880','test','test','1.14'),('2018-07-31 11:59:59','2018-08-06 23:59:59','XRPETH','4h','0.000999000000000','0.001017910000000','1.275750190618411','1.299898775307694','1277.0272178362466','1277.027217836246564','test','test','0.0'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XRPETH','4h','0.000987780000000','0.000976100000000','1.281116542771584','1.265967986190592','1296.9654607013551','1296.965460701355141','test','test','0.0'),('2018-08-14 11:59:59','2018-08-14 23:59:59','XRPETH','4h','0.000995260000000','0.000979220000000','1.277750196864697','1.257157474201564','1283.835577502057','1283.835577502057049','test','test','1.92'),('2018-08-15 03:59:59','2018-08-15 19:59:59','XRPETH','4h','0.000999340000000','0.000991860000000','1.273174036272890','1.263644404924879','1274.0148860977147','1274.014886097714680','test','test','2.01'),('2018-08-15 23:59:59','2018-08-31 15:59:59','XRPETH','4h','0.000998660000000','0.001186000000000','1.271056340417777','1.509495543764128','1272.7618412850986','1272.761841285098626','test','test','0.97'),('2018-08-31 19:59:59','2018-09-01 15:59:59','XRPETH','4h','0.001190000000000','0.001167880000000','1.324042830050299','1.299431210385835','1112.6410336557133','1112.641033655713272','test','test','16.6'),('2018-09-01 19:59:59','2018-09-01 23:59:59','XRPETH','4h','0.001169310000000','0.001175590000000','1.318573581235974','1.325655229464555','1127.6509918122426','1127.650991812242637','test','test','12.9'),('2018-09-04 07:59:59','2018-09-04 11:59:59','XRPETH','4h','0.001169050000000','0.001168980000000','1.320147280842325','1.320068233487927','1129.2479199711943','1129.247919971194278','test','test','12.8'),('2018-09-05 11:59:59','2018-09-05 19:59:59','XRPETH','4h','0.001172280000000','0.001186520000000','1.320129714763570','1.336165684956897','1126.1215023403709','1126.121502340370853','test','test','10.5'),('2018-09-05 23:59:59','2018-09-13 23:59:59','XRPETH','4h','0.001222490000000','0.001321790000000','1.323693263695420','1.431213767818116','1082.7845329576687','1082.784532957668716','test','test','13.9'),('2018-09-17 19:59:59','2018-10-02 23:59:59','XRPETH','4h','0.001370000000000','0.002294530000000','1.347586709056019','2.256991336883436','983.6399336175323','983.639933617532279','test','test','22.6'),('2018-10-03 03:59:59','2018-10-05 11:59:59','XRPETH','4h','0.002368040000000','0.002324530000000','1.549676626351001','1.521203108161894','654.4131967158497','654.413196715849722','test','test','54.5'),('2018-10-15 23:59:59','2018-10-16 03:59:59','XRPETH','4h','0.002157190000000','0.002156010000000','1.543349177864533','1.542504953651608','715.4442482417093','715.444248241709261','test','test','38.0'),('2018-10-16 07:59:59','2018-10-22 15:59:59','XRPETH','4h','0.002197600000000','0.002233800000000','1.543161572483883','1.568581325361530','702.203118167038','702.203118167038042','test','test','38.1'),('2018-10-22 19:59:59','2018-10-23 11:59:59','XRPETH','4h','0.002233680000000','0.002205610000000','1.548810406456693','1.529346961330605','693.3895663016607','693.389566301660693','test','test','0.0'),('2018-10-23 23:59:59','2018-10-27 23:59:59','XRPETH','4h','0.002282400000000','0.002249540000000','1.544485196428674','1.522249048709323','676.6934789820689','676.693478982068882','test','test','3.36'),('2018-10-28 03:59:59','2018-10-28 15:59:59','XRPETH','4h','0.002253130000000','0.002253310000000','1.539543830268818','1.539666822679131','683.2911684052044','683.291168405204417','test','test','0.85'),('2018-10-28 19:59:59','2018-10-29 11:59:59','XRPETH','4h','0.002255790000000','0.002232930000000','1.539571161915554','1.523969267784722','682.4975560293973','682.497556029397288','test','test','0.17'),('2018-10-29 15:59:59','2018-10-29 19:59:59','XRPETH','4h','0.002256860000000','0.002252630000000','1.536104074330925','1.533224976719899','680.6377331030391','680.637733103039068','test','test','1.06'),('2018-10-29 23:59:59','2018-10-31 15:59:59','XRPETH','4h','0.002263810000000','0.002286340000000','1.535464274861808','1.550745597107331','678.2655235473859','678.265523547385897','test','test','0.49'),('2018-10-31 19:59:59','2018-11-04 07:59:59','XRPETH','4h','0.002287640000000','0.002256960000000','1.538860124249702','1.518222161715395','672.6845676110322','672.684567611032207','test','test','1.50'),('2018-11-05 15:59:59','2018-11-08 19:59:59','XRPETH','4h','0.002333720000000','0.002361690000000','1.534273910353189','1.552662423659232','657.4370148746161','657.437014874616125','test','test','3.28'),('2018-11-08 23:59:59','2018-11-09 03:59:59','XRPETH','4h','0.002331060000000','0.002417000000000','1.538360246643421','1.595075509054743','659.9402188890124','659.940218889012385','test','test','0.0'),('2018-11-09 07:59:59','2018-11-14 19:59:59','XRPETH','4h','0.002399320000000','0.002506570000000','1.550963638290382','1.620291968903491','646.4180010546245','646.418001054624483','test','test','1.56'),('2018-11-14 23:59:59','2018-11-29 15:59:59','XRPETH','4h','0.002586730000000','0.003208670000000','1.566369933982183','1.942979830160322','605.54056046908','605.540560469079992','test','test','3.09'),('2018-11-29 19:59:59','2018-11-30 11:59:59','XRPETH','4h','0.003212460000000','0.003167190000000','1.650061022021770','1.626808355072788','513.6440677928348','513.644067792834790','test','test','0.29'),('2018-11-30 15:59:59','2018-12-01 11:59:59','XRPETH','4h','0.003184440000000','0.003127700000000','1.644893762699774','1.615585227417091','516.5409813655695','516.540981365569451','test','test','0.54'),('2018-12-02 03:59:59','2018-12-02 07:59:59','XRPETH','4h','0.003172320000000','0.003148950000000','1.638380754859178','1.626311052483296','516.4613768028375','516.461376802837549','test','test','1.40'),('2018-12-02 23:59:59','2018-12-03 03:59:59','XRPETH','4h','0.003168150000000','0.003183900000000','1.635698598775648','1.643830238038535','516.2945563737981','516.294556373798059','test','test','0.60'),('2018-12-03 07:59:59','2018-12-04 11:59:59','XRPETH','4h','0.003196100000000','0.003203380000000','1.637505629722956','1.641235500810964','512.344929671461','512.344929671461045','test','test','0.47'),('2018-12-04 15:59:59','2018-12-07 19:59:59','XRPETH','4h','0.003187180000000','0.003203020000000','1.638334489964736','1.646476866084391','514.0388964428543','514.038896442854252','test','test','0.10'),('2018-12-07 23:59:59','2018-12-08 03:59:59','XRPETH','4h','0.003233320000000','0.003298690000000','1.640143906880215','1.673303695330711','507.2630939344744','507.263093934474398','test','test','0.93'),('2018-12-08 07:59:59','2018-12-09 15:59:59','XRPETH','4h','0.003348520000000','0.003272750000000','1.647512748758103','1.610232983078519','492.01221696692966','492.012216966929657','test','test','4.17'),('2018-12-09 23:59:59','2018-12-16 03:59:59','XRPETH','4h','0.003314520000000','0.003361590000000','1.639228356384862','1.662507286285733','494.5598024404324','494.559802440432406','test','test','1.26'),('2018-12-16 23:59:59','2018-12-17 03:59:59','XRPETH','4h','0.003383980000000','0.003368010000000','1.644401451918389','1.636641036316897','485.93710716918804','485.937107169188039','test','test','0.66'),('2018-12-17 11:59:59','2018-12-17 15:59:59','XRPETH','4h','0.003371540000000','0.003380610000000','1.642676915118057','1.647095987595358','487.2185752261748','487.218575226174778','test','test','0.10'),('2018-12-17 19:59:59','2018-12-20 15:59:59','XRPETH','4h','0.003446030000000','0.003413370000000','1.643658931224124','1.628081034138556','476.971741750398','476.971741750397996','test','test','1.89'),('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','1.640197176316220','1.652968144184166','636.6384779633978','636.638477963397804','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','XRPETH','4h','0.002590000000000','0.002587550000000','1.643035169175764','1.641480946718436','634.3765131952757','634.376513195275720','test','test','0.0'),('2019-01-15 11:59:59','2019-01-15 15:59:59','XRPETH','4h','0.002607890000000','0.002590000000000','1.642689786407469','1.631421013461206','629.8922831896548','629.892283189654790','test','test','0.77'),('2019-01-15 19:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002603960000000','0.002648540000000','1.640185614641632','1.668265721363979','629.8812633994502','629.881263399450177','test','test','0.53'),('2019-01-19 15:59:59','2019-01-27 11:59:59','XRPETH','4h','0.002654650000000','0.002688090000000','1.646425638357710','1.667165273845131','620.2044105089973','620.204410508997285','test','test','2.19'),('2019-01-27 15:59:59','2019-01-27 23:59:59','XRPETH','4h','0.002713340000000','0.002735430000000','1.651034446243803','1.664475943040196','608.4878585963437','608.487858596343699','test','test','0.93'),('2019-01-28 03:59:59','2019-02-03 07:59:59','XRPETH','4h','0.002754280000000','0.002812130000000','1.654021445531890','1.688761973228428','600.527704348102','600.527704348102020','test','test','0.93'),('2019-02-03 11:59:59','2019-02-03 19:59:59','XRPETH','4h','0.002835600000000','0.002805030000000','1.661741562797788','1.643826680735886','586.0281996042416','586.028199604241649','test','test','3.53'),('2019-02-03 23:59:59','2019-02-04 03:59:59','XRPETH','4h','0.002816620000000','0.002801850000000','1.657760477895143','1.649067391053996','588.5637671731163','588.563767173116275','test','test','0.41'),('2019-02-04 07:59:59','2019-02-04 11:59:59','XRPETH','4h','0.002804000000000','0.002812320000000','1.655828680819333','1.660741838673975','590.5237806060388','590.523780606038827','test','test','0.07'),('2019-02-04 15:59:59','2019-02-04 19:59:59','XRPETH','4h','0.002798000000000','0.002792180000000','1.656920493675919','1.653474004300224','592.180305102187','592.180305102187049','test','test','0.0'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','1.656154607147988','1.643741110428254','588.3173800821961','588.317380082196109','test','test','0.81'),('2019-02-06 03:59:59','2019-02-06 19:59:59','XRPETH','4h','0.002829350000000','0.002793490000000','1.653396052321380','1.632440432678619','584.3731077178079','584.373107717807898','test','test','1.25'),('2019-02-07 19:59:59','2019-02-07 23:59:59','XRPETH','4h','0.002805900000000','0.002789410000000','1.648739247956322','1.639049768574021','587.5972942572158','587.597294257215822','test','test','0.44'),('2019-02-25 19:59:59','2019-02-27 03:59:59','XRPETH','4h','0.002380130000000','0.002309270000000','1.646586030315810','1.597564722190549','691.8050822080351','691.805082208035060','test','test','0.0'),('2019-02-27 07:59:59','2019-02-27 11:59:59','XRPETH','4h','0.002286200000000','0.002282650000000','1.635692406287975','1.633152511247155','715.4633917802356','715.463391780235611','test','test','0.0'),('2019-02-27 19:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002304900000000','0.002287290000000','1.635127985167792','1.622635207251698','709.4138509990856','709.413850999085639','test','test','0.96'),('2019-02-28 23:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002317970000000','0.002341950000000','1.632351812297549','1.649238914571908','704.2161081884361','704.216108188436124','test','test','1.32'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','1.636104501691851','1.629382504459133','705.3512311351512','705.351231135151238','test','test','0.44'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','1.634610724529025','1.636790864005369','705.5467560985089','705.546756098508922','test','test','0.29'),('2019-03-12 15:59:59','2019-03-15 07:59:59','XRPETH','4h','0.002324780000000','0.002332830000000','1.635095199968213','1.640757033070590','703.3333046431115','703.333304643111546','test','test','0.21'),('2019-03-15 11:59:59','2019-03-15 15:59:59','XRPETH','4h','0.002331100000000','0.002308000000000','1.636353385102074','1.620137966117106','701.9661898254361','701.966189825436118','test','test','0.0'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002201400000000','1.632749958660970','1.596581378064941','725.2572808507955','725.257280850795496','test','test','0.0'),('2019-04-05 11:59:59','2019-04-05 15:59:59','XRPETH','4h','0.002215810000000','0.002199970000000','1.624712496306297','1.613098032096147','733.2363769033884','733.236376903388418','test','test','0.65'),('2019-04-05 19:59:59','2019-04-05 23:59:59','XRPETH','4h','0.002203470000000','0.002191210000000','1.622131504259597','1.613106043399126','736.1713589291423','736.171358929142343','test','test','0.15'),('2019-04-06 03:59:59','2019-04-06 07:59:59','XRPETH','4h','0.002192160000000','0.002162550000000','1.620125846290604','1.598242440741436','739.0545609310469','739.054560931046922','test','test','0.04');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 18:40:23
