-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-01 19:59:59','2018-01-02 19:59:59','ETHBTC','4h','0.056529000000000','0.057845000000000','0.033333333333333','0.034109336210912','0.5896678401056684','0.589667840105668','test','test','0.0'),('2018-01-02 23:59:59','2018-01-05 19:59:59','ETHBTC','4h','0.058261000000000','0.058499000000000','0.033505778417240','0.033642651716073','0.5750978942558449','0.575097894255845','test','test','3.25'),('2018-01-05 23:59:59','2018-01-06 03:59:59','ETHBTC','4h','0.056584000000000','0.058299000000000','0.033536194705869','0.034552640590228','0.592679815952731','0.592679815952731','test','test','0.0'),('2018-01-06 07:59:59','2018-01-16 11:59:59','ETHBTC','4h','0.060134000000000','0.093500000000000','0.033762071569060','0.052495321976039','0.56144729386138','0.561447293861380','test','test','3.05'),('2018-01-16 15:59:59','2018-01-17 15:59:59','ETHBTC','4h','0.093387000000000','0.083948000000000','0.037925016103944','0.034091782067032','0.4061059473368289','0.406105947336829','test','test','37.3'),('2018-01-17 19:59:59','2018-02-02 15:59:59','ETHBTC','4h','0.088038000000000','0.107076000000000','0.037073186317964','0.045090171269024','0.42110436763629344','0.421104367636293','test','test','4.64'),('2018-02-02 19:59:59','2018-02-04 11:59:59','ETHBTC','4h','0.103598000000000','0.101937000000000','0.038854738529311','0.038231775531018','0.3750529791049119','0.375052979104912','test','test','0.0'),('2018-02-05 07:59:59','2018-02-05 11:59:59','ETHBTC','4h','0.102882000000000','0.101000000000000','0.038716302307468','0.038008072676020','0.3763175512477185','0.376317551247718','test','test','0.91'),('2018-02-25 19:59:59','2018-02-26 15:59:59','ETHBTC','4h','0.087994000000000','0.085364000000000','0.038558917944924','0.037406453524678','0.4381993993331793','0.438199399333179','test','test','0.0'),('2018-03-09 23:59:59','2018-03-10 07:59:59','ETHBTC','4h','0.078477000000000','0.078060000000000','0.038302814740425','0.038099286652619','0.48807694917523176','0.488076949175232','test','test','0.0'),('2018-03-11 03:59:59','2018-03-11 07:59:59','ETHBTC','4h','0.078533000000000','0.079029000000000','0.038257586276468','0.038499214162747','0.48715299652971084','0.487152996529711','test','test','0.60'),('2018-03-11 11:59:59','2018-03-11 15:59:59','ETHBTC','4h','0.078145000000000','0.077378000000000','0.038311281362308','0.037935252789720','0.4902588951603757','0.490258895160376','test','test','0.0'),('2018-04-08 19:59:59','2018-04-25 11:59:59','ETHBTC','4h','0.057168000000000','0.068881000000000','0.038227719457288','0.046060095576852','0.6686908665212706','0.668690866521271','test','test','0.0'),('2018-04-25 15:59:59','2018-05-01 03:59:59','ETHBTC','4h','0.069348000000000','0.071767000000000','0.039968247483858','0.041362421658505','0.5763431891886972','0.576343189188697','test','test','17.6'),('2018-05-01 07:59:59','2018-05-07 11:59:59','ETHBTC','4h','0.073734000000000','0.078480000000000','0.040278063967113','0.042870622238574','0.5462617512560375','0.546261751256037','test','test','2.66'),('2018-05-07 15:59:59','2018-05-11 07:59:59','ETHBTC','4h','0.077945000000000','0.079512000000000','0.040854188027437','0.041675517331934','0.5241412281408344','0.524141228140834','test','test','0.72'),('2018-05-11 11:59:59','2018-05-11 15:59:59','ETHBTC','4h','0.078803000000000','0.079438000000000','0.041036705650659','0.041367382250384','0.5207505507488153','0.520750550748815','test','test','0.0'),('2018-05-11 19:59:59','2018-05-12 07:59:59','ETHBTC','4h','0.080113000000000','0.078509000000000','0.041110189339487','0.040287092667280','0.5131525387825531','0.513152538782553','test','test','1.35'),('2018-05-12 11:59:59','2018-05-12 15:59:59','ETHBTC','4h','0.079422000000000','0.079269000000000','0.040927278967885','0.040848435905735','0.5153141317000971','0.515314131700097','test','test','1.14'),('2018-05-12 19:59:59','2018-05-21 19:59:59','ETHBTC','4h','0.080340000000000','0.083041000000000','0.040909758287407','0.042285128677428','0.5092078452502781','0.509207845250278','test','test','1.33'),('2018-05-21 23:59:59','2018-05-22 03:59:59','ETHBTC','4h','0.083142000000000','0.082740000000000','0.041215396151856','0.041016115532517','0.4957229336780022','0.495722933678002','test','test','0.12'),('2018-05-22 07:59:59','2018-05-22 11:59:59','ETHBTC','4h','0.083412000000000','0.083332000000000','0.041171111569781','0.041131624578394','0.49358739233900534','0.493587392339005','test','test','0.80'),('2018-06-02 19:59:59','2018-06-02 23:59:59','ETHBTC','4h','0.078069000000000','0.077350000000000','0.041162336682806','0.040783239729150','0.527255846530713','0.527255846530713','test','test','0.0'),('2018-06-03 07:59:59','2018-06-04 15:59:59','ETHBTC','4h','0.078552000000000','0.078215000000000','0.041078092915327','0.040901861663259','0.5229414007959965','0.522941400795996','test','test','1.53'),('2018-06-04 19:59:59','2018-06-05 03:59:59','ETHBTC','4h','0.078970000000000','0.078580000000000','0.041038930414868','0.040836256198561','0.5196774777113786','0.519677477711379','test','test','0.95'),('2018-06-05 07:59:59','2018-06-05 11:59:59','ETHBTC','4h','0.079096000000000','0.079060000000000','0.040993891700133','0.040975233612477','0.518280212654656','0.518280212654656','test','test','0.65'),('2018-06-05 15:59:59','2018-06-07 07:59:59','ETHBTC','4h','0.079227000000000','0.079030000000000','0.040989745458431','0.040887823388236','0.5173709146936187','0.517370914693619','test','test','0.21'),('2018-06-07 11:59:59','2018-06-07 15:59:59','ETHBTC','4h','0.078998000000000','0.078760000000000','0.040967096109499','0.040843673125701','0.5185839655370911','0.518583965537091','test','test','0.0'),('2018-06-07 19:59:59','2018-06-07 23:59:59','ETHBTC','4h','0.078802000000000','0.078698000000000','0.040939668779766','0.040885638100937','0.5195257579727194','0.519525757972719','test','test','0.05'),('2018-06-08 03:59:59','2018-06-08 07:59:59','ETHBTC','4h','0.078911000000000','0.078720000000000','0.040927661962249','0.040828598670252','0.518655979042829','0.518655979042829','test','test','0.26'),('2018-06-08 11:59:59','2018-06-08 15:59:59','ETHBTC','4h','0.078962000000000','0.078617000000000','0.040905647897360','0.040726923339667','0.5180421962128675','0.518042196212868','test','test','0.30'),('2018-06-09 03:59:59','2018-06-09 19:59:59','ETHBTC','4h','0.079073000000000','0.078771000000000','0.040865931328984','0.040709853890903','0.5168127088764082','0.516812708876408','test','test','0.57'),('2018-06-09 23:59:59','2018-06-10 03:59:59','ETHBTC','4h','0.079108000000000','0.078445000000000','0.040831247453855','0.040489042909916','0.5161456168005146','0.516145616800515','test','test','0.42'),('2018-06-14 23:59:59','2018-06-15 07:59:59','ETHBTC','4h','0.078267000000000','0.076847000000000','0.040755201999646','0.040015779422577','0.5207201246968256','0.520720124696826','test','test','0.0'),('2018-06-17 03:59:59','2018-06-17 07:59:59','ETHBTC','4h','0.077560000000000','0.076805000000000','0.040590885871409','0.040195757985477','0.5233481932878918','0.523348193287892','test','test','0.91'),('2018-06-19 07:59:59','2018-06-21 19:59:59','ETHBTC','4h','0.077526000000000','0.078102000000000','0.040503079674535','0.040804008058465','0.5224451109890245','0.522445110989024','test','test','0.93'),('2018-06-21 23:59:59','2018-06-22 03:59:59','ETHBTC','4h','0.078334000000000','0.077602000000000','0.040569952648742','0.040190842615565','0.5179098813892024','0.517909881389202','test','test','0.29'),('2018-07-08 07:59:59','2018-07-08 11:59:59','ETHBTC','4h','0.071962000000000','0.072131000000000','0.040485705974702','0.040580785104100','0.5625983988035692','0.562598398803569','test','test','0.0'),('2018-07-08 15:59:59','2018-07-09 03:59:59','ETHBTC','4h','0.072687000000000','0.071920000000000','0.040506834670124','0.040079402774572','0.557277569168135','0.557277569168135','test','test','0.76'),('2018-07-09 07:59:59','2018-07-09 11:59:59','ETHBTC','4h','0.071936000000000','0.071835000000000','0.040411849804446','0.040355110524666','0.5617750473260399','0.561775047326040','test','test','0.02'),('2018-07-15 15:59:59','2018-07-15 19:59:59','ETHBTC','4h','0.070867000000000','0.070747000000000','0.040399241075606','0.040330832522555','0.5700712754258823','0.570071275425882','test','test','0.0'),('2018-07-15 23:59:59','2018-07-16 03:59:59','ETHBTC','4h','0.070750000000000','0.070441000000000','0.040384039174928','0.040207662240581','0.5707991402816679','0.570799140281668','test','test','0.00'),('2018-07-16 07:59:59','2018-07-17 07:59:59','ETHBTC','4h','0.071090000000000','0.070809000000000','0.040344844300629','0.040185371783419','0.5675178548407465','0.567517854840746','test','test','0.91'),('2018-08-04 19:59:59','2018-08-07 15:59:59','ETHBTC','4h','0.058032000000000','0.057458000000000','0.040309405963471','0.039910701817086','0.6946065268036754','0.694606526803675','test','test','0.0'),('2018-09-15 15:59:59','2018-09-16 03:59:59','ETHBTC','4h','0.034276000000000','0.033147000000000','0.040220805042052','0.038895992085684','1.1734392881915043','1.173439288191504','test','test','0.0'),('2018-09-16 11:59:59','2018-09-16 15:59:59','ETHBTC','4h','0.033760000000000','0.033557000000000','0.039926402162859','0.039686323382081','1.1826540925017508','1.182654092501751','test','test','1.81'),('2018-09-16 19:59:59','2018-09-17 11:59:59','ETHBTC','4h','0.034142000000000','0.033840000000000','0.039873051322686','0.039520357822028','1.16785927370061','1.167859273700610','test','test','1.71'),('2018-09-19 03:59:59','2018-09-19 07:59:59','ETHBTC','4h','0.033436000000000','0.033266000000000','0.039794674989207','0.039592345322137','1.1901745121786897','1.190174512178690','test','test','0.0'),('2018-09-20 23:59:59','2018-09-24 23:59:59','ETHBTC','4h','0.034522000000000','0.034631000000000','0.039749712840969','0.039875218857413','1.1514313435191732','1.151431343519173','test','test','3.63'),('2018-09-25 03:59:59','2018-09-25 07:59:59','ETHBTC','4h','0.034255000000000','0.032756000000000','0.039777603066845','0.038036933763175','1.1612203493459448','1.161220349345945','test','test','1.21'),('2018-09-27 19:59:59','2018-09-28 07:59:59','ETHBTC','4h','0.034297000000000','0.033977000000000','0.039390787666030','0.039023261291912','1.1485199191191584','1.148519919119158','test','test','4.49'),('2018-09-29 11:59:59','2018-10-02 19:59:59','ETHBTC','4h','0.035291000000000','0.034535000000000','0.039309115138448','0.038467039508835','1.1138566529270353','1.113856652927035','test','test','3.72'),('2018-10-02 23:59:59','2018-10-03 03:59:59','ETHBTC','4h','0.034556000000000','0.033832000000000','0.039121987220756','0.038302322943993','1.1321329789546306','1.132132978954631','test','test','0.06'),('2018-10-05 23:59:59','2018-10-06 11:59:59','ETHBTC','4h','0.034409000000000','0.034179000000000','0.038939839603698','0.038679554122898','1.1316760034786764','1.131676003478676','test','test','1.67'),('2018-10-08 15:59:59','2018-10-09 15:59:59','ETHBTC','4h','0.034402000000000','0.034397000000000','0.038881998385742','0.038876347261042','1.130224939995995','1.130224939995995','test','test','0.64'),('2018-10-09 19:59:59','2018-10-10 03:59:59','ETHBTC','4h','0.034368000000000','0.034230000000000','0.038880742580253','0.038724622280088','1.1313065229356765','1.131306522935676','test','test','0.0'),('2018-10-10 07:59:59','2018-10-10 15:59:59','ETHBTC','4h','0.034358000000000','0.034179000000000','0.038846049180217','0.038643667120631','1.130626031207191','1.130626031207191','test','test','0.37'),('2018-10-28 19:59:59','2018-10-28 23:59:59','ETHBTC','4h','0.031562000000000','0.031616000000000','0.038801075389198','0.038867460854980','1.2293604774474862','1.229360477447486','test','test','0.0'),('2018-10-29 03:59:59','2018-10-29 07:59:59','ETHBTC','4h','0.031547000000000','0.031591000000000','0.038815827714927','0.038869965871311','1.2304126450986428','1.230412645098643','test','test','0.0'),('2018-10-29 11:59:59','2018-10-29 15:59:59','ETHBTC','4h','0.031662000000000','0.031109000000000','0.038827858416346','0.038149701455186','1.226323618733673','1.226323618733673','test','test','0.22'),('2018-11-02 15:59:59','2018-11-03 03:59:59','ETHBTC','4h','0.031463000000000','0.031384000000000','0.038677156869421','0.038580042945361','1.2292901779684429','1.229290177968443','test','test','1.12'),('2018-11-03 07:59:59','2018-11-03 11:59:59','ETHBTC','4h','0.031380000000000','0.031388000000000','0.038655575997408','0.038665430828765','1.2318539196114653','1.231853919611465','test','test','0.0'),('2018-11-03 15:59:59','2018-11-03 19:59:59','ETHBTC','4h','0.031385000000000','0.031357000000000','0.038657765959932','0.038623277591384','1.231727448141837','1.231727448141837','test','test','0.00'),('2018-11-03 23:59:59','2018-11-04 03:59:59','ETHBTC','4h','0.031353000000000','0.031306000000000','0.038650101878032','0.038592163091049','1.2327401485673464','1.232740148567346','test','test','0.0'),('2018-11-04 07:59:59','2018-11-13 11:59:59','ETHBTC','4h','0.031534000000000','0.032804000000000','0.038637226592036','0.040193301868623','1.2252561232966255','1.225256123296625','test','test','0.72'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ETHBTC','4h','0.032843000000000','0.032504000000000','0.038983021097944','0.038580644818304','1.1869506774029173','1.186950677402917','test','test','4.52'),('2018-12-16 15:59:59','2018-12-16 19:59:59','ETHBTC','4h','0.026582000000000','0.026541000000000','0.038893604146913','0.038833614764247','1.4631556747766492','1.463155674776649','test','test','0.0'),('2018-12-17 19:59:59','2018-12-18 07:59:59','ETHBTC','4h','0.026991000000000','0.026666000000000','0.038880273172987','0.038412113831680','1.4404902809450228','1.440490280945023','test','test','1.66'),('2018-12-18 11:59:59','2018-12-18 19:59:59','ETHBTC','4h','0.026757000000000','0.026509000000000','0.038776237763808','0.038416836225316','1.4491997519829496','1.449199751982950','test','test','0.34'),('2018-12-18 23:59:59','2019-01-02 07:59:59','ETHBTC','4h','0.027493000000000','0.038058000000000','0.038696370755254','0.053566597977793','1.4074990272161643','1.407499027216164','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 20:04:57
