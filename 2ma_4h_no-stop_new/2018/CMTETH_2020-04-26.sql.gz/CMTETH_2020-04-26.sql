-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-22 23:59:59','2018-06-01 07:59:59','CMTETH','4h','0.000499960000000','0.000583450000000','1.297777777777778','1.514498048732787','2595.763216612884','2595.763216612884207','test','test','0.0'),('2018-06-02 15:59:59','2018-06-02 19:59:59','CMTETH','4h','0.000582120000000','0.000556000000000','1.345937837990002','1.285544969976020','2312.131240964066','2312.131240964065910','test','test','16.3'),('2018-06-04 23:59:59','2018-06-05 03:59:59','CMTETH','4h','0.000588880000000','0.000550170000000','1.332517200653562','1.244924243111619','2262.7992131734172','2262.799213173417229','test','test','5.58'),('2018-07-01 03:59:59','2018-07-06 07:59:59','CMTETH','4h','0.000353660000000','0.000379090000000','1.313052098977574','1.407467398635437','3712.7526408911785','3712.752640891178544','test','test','0.0'),('2018-07-06 11:59:59','2018-07-06 15:59:59','CMTETH','4h','0.000379650000000','0.000374990000000','1.334033276679321','1.317658734155087','3513.8503270889537','3513.850327088953691','test','test','7.64'),('2018-07-06 19:59:59','2018-07-07 11:59:59','CMTETH','4h','0.000390840000000','0.000381690000000','1.330394489451714','1.299248471698968','3403.9363664203106','3403.936366420310605','test','test','4.05'),('2018-07-07 15:59:59','2018-07-07 19:59:59','CMTETH','4h','0.000377830000000','0.000383030000000','1.323473152173326','1.341687852941664','3502.8270708343066','3502.827070834306596','test','test','0.0'),('2018-07-07 23:59:59','2018-07-08 07:59:59','CMTETH','4h','0.000384520000000','0.000376490000000','1.327520863455179','1.299798007599710','3452.4104427732727','3452.410442773272734','test','test','0.73'),('2018-07-08 15:59:59','2018-07-09 03:59:59','CMTETH','4h','0.000383770000000','0.000377270000000','1.321360228820630','1.298980049319017','3443.1045387097224','3443.104538709722419','test','test','1.89'),('2018-07-16 23:59:59','2018-07-17 03:59:59','CMTETH','4h','0.000346200000000','0.000340000000000','1.316386855598050','1.292812047669951','3802.388375499854','3802.388375499854192','test','test','0.0'),('2018-07-17 19:59:59','2018-07-19 03:59:59','CMTETH','4h','0.000353250000000','0.000336660000000','1.311148009391805','1.249571376763893','3711.671647252102','3711.671647252102048','test','test','3.75'),('2018-07-19 07:59:59','2018-07-19 11:59:59','CMTETH','4h','0.000343820000000','0.000349970000000','1.297464313252269','1.320672403318296','3773.67318146783','3773.673181467830091','test','test','2.08'),('2018-07-19 15:59:59','2018-07-19 23:59:59','CMTETH','4h','0.000343360000000','0.000355740000000','1.302621666600275','1.349588279579397','3793.749029008257','3793.749029008256912','test','test','0.0'),('2018-08-11 03:59:59','2018-08-11 07:59:59','CMTETH','4h','0.000275970000000','0.000265960000000','1.313058691706747','1.265431349952264','4757.976199249001','4757.976199249001183','test','test','0.0'),('2018-08-13 11:59:59','2018-08-14 03:59:59','CMTETH','4h','0.000273780000000','0.000275000000000','1.302474837983528','1.308278838649537','4757.377595089227','4757.377595089226816','test','test','2.85'),('2018-08-14 07:59:59','2018-08-14 11:59:59','CMTETH','4h','0.000270380000000','0.000263230000000','1.303764615909308','1.269287520696084','4821.971358492891','4821.971358492891341','test','test','0.0'),('2018-08-14 15:59:59','2018-08-14 19:59:59','CMTETH','4h','0.000271590000000','0.000266370000000','1.296103039195258','1.271191746936341','4772.278210520484','4772.278210520484208','test','test','3.07'),('2018-08-17 03:59:59','2018-08-18 07:59:59','CMTETH','4h','0.000274230000000','0.000270250000000','1.290567196471055','1.271836724086725','4706.148840283903','4706.148840283903155','test','test','2.86'),('2018-08-18 11:59:59','2018-08-18 15:59:59','CMTETH','4h','0.000277760000000','0.000275000000000','1.286404869274537','1.273622332411066','4631.353936040238','4631.353936040238295','test','test','2.70'),('2018-08-18 19:59:59','2018-08-18 23:59:59','CMTETH','4h','0.000272530000000','0.000275230000000','1.283564305527099','1.296280790409216','4709.809215598646','4709.809215598646006','test','test','0.0'),('2018-08-19 15:59:59','2018-08-19 23:59:59','CMTETH','4h','0.000275540000000','0.000280480000000','1.286390191056458','1.309453149406675','4668.615050651296','4668.615050651295860','test','test','0.19'),('2018-08-20 03:59:59','2018-08-20 11:59:59','CMTETH','4h','0.000281140000000','0.000272480000000','1.291515292912062','1.251732542550611','4593.851080999011','4593.851080999011174','test','test','1.96'),('2018-08-20 15:59:59','2018-08-20 23:59:59','CMTETH','4h','0.000275650000000','0.000274180000000','1.282674681720628','1.275834370521175','4653.272924798217','4653.272924798216991','test','test','1.15'),('2018-08-21 03:59:59','2018-08-29 03:59:59','CMTETH','4h','0.000275180000000','0.000344960000000','1.281154612565194','1.606029126936875','4655.696680591593','4655.696680591592667','test','test','0.36'),('2018-08-29 07:59:59','2018-09-02 03:59:59','CMTETH','4h','0.000349210000000','0.000339750000000','1.353348949092235','1.316687109344196','3875.4587471499513','3875.458747149951250','test','test','19.6'),('2018-09-02 07:59:59','2018-09-13 15:59:59','CMTETH','4h','0.000347960000000','0.000394380000000','1.345201873592671','1.524660061235422','3865.9669892880515','3865.966989288051536','test','test','2.35'),('2018-09-17 19:59:59','2018-09-18 15:59:59','CMTETH','4h','0.000415800000000','0.000391460000000','1.385081470846615','1.304001906151072','3331.124268510377','3331.124268510377078','test','test','15.8'),('2018-09-18 19:59:59','2018-09-18 23:59:59','CMTETH','4h','0.000391580000000','0.000389350000000','1.367063789803161','1.359278529444458','3491.148142916291','3491.148142916290908','test','test','3.65'),('2018-09-19 03:59:59','2018-09-21 15:59:59','CMTETH','4h','0.000403800000000','0.000407400000000','1.365333731945672','1.377506098055143','3381.212808186408','3381.212808186407983','test','test','3.57'),('2018-09-25 03:59:59','2018-09-27 19:59:59','CMTETH','4h','0.000400290000000','0.000400620000000','1.368038702192220','1.369166516456187','3417.618981718805','3417.618981718805117','test','test','0.0'),('2018-09-28 11:59:59','2018-09-28 15:59:59','CMTETH','4h','0.000404000000000','0.000401400000000','1.368289327584213','1.359483505178968','3386.854771248052','3386.854771248052202','test','test','0.83'),('2018-09-28 19:59:59','2018-10-12 03:59:59','CMTETH','4h','0.000414760000000','0.000534970000000','1.366332478160825','1.762336980040738','3294.272538723178','3294.272538723178059','test','test','3.22'),('2018-10-12 07:59:59','2018-10-15 07:59:59','CMTETH','4h','0.000531620000000','0.000540000000000','1.454333478578584','1.477258339476384','2735.6635916229334','2735.663591622933382','test','test','23.3'),('2018-10-15 11:59:59','2018-10-15 19:59:59','CMTETH','4h','0.000542760000000','0.000541170000000','1.459427892111428','1.455152539564341','2688.9009730109597','2688.900973010959660','test','test','0.50'),('2018-10-16 07:59:59','2018-10-18 07:59:59','CMTETH','4h','0.000552370000000','0.000554360000000','1.458477813767631','1.463732210004569','2640.4001190644517','2640.400119064451701','test','test','2.02'),('2018-10-18 11:59:59','2018-10-18 19:59:59','CMTETH','4h','0.000560360000000','0.000549880000000','1.459645457375840','1.432346784391868','2604.8352083943178','2604.835208394317760','test','test','1.81'),('2018-10-19 03:59:59','2018-10-19 05:59:59','CMTETH','4h','0.000553980000000','0.000552340000000','1.453579085601624','1.449275916352939','2623.8836882227224','2623.883688222722412','test','test','0.74'),('2018-10-19 11:59:59','2018-10-19 15:59:59','CMTETH','4h','0.000560870000000','0.000546780000000','1.452622825768582','1.416130491332653','2589.9456661411423','2589.945666141142283','test','test','1.52'),('2018-10-19 23:59:59','2018-10-20 03:59:59','CMTETH','4h','0.000554410000000','0.000548340000000','1.444513418116154','1.428698053227416','2605.496686777212','2605.496686777211835','test','test','1.37'),('2018-10-21 11:59:59','2018-10-21 15:59:59','CMTETH','4h','0.000564570000000','0.000554470000000','1.440998892585323','1.415219823886824','2552.383039455379','2552.383039455378821','test','test','2.87'),('2018-10-21 19:59:59','2018-10-22 03:59:59','CMTETH','4h','0.000556990000000','0.000552840000000','1.435270210652323','1.424576353717356','2576.832996377535','2576.832996377534982','test','test','0.45'),('2018-11-22 19:59:59','2018-11-23 03:59:59','CMTETH','4h','0.000380210000000','0.000380690000000','1.432893798000109','1.434702769418641','3768.690455275002','3768.690455275002023','test','test','0.0'),('2018-11-23 11:59:59','2018-11-23 15:59:59','CMTETH','4h','0.000381440000000','0.000372380000000','1.433295791648671','1.399252010523627','3757.5917356561226','3757.591735656122637','test','test','0.19'),('2018-11-23 23:59:59','2018-11-24 03:59:59','CMTETH','4h','0.000391130000000','0.000379710000000','1.425730506954217','1.384102806728161','3645.1576380083784','3645.157638008378399','test','test','4.79'),('2018-11-24 07:59:59','2018-11-24 23:59:59','CMTETH','4h','0.000384090000000','0.000374540000000','1.416479906903982','1.381260601244024','3687.885409419621','3687.885409419620828','test','test','1.14'),('2018-11-25 03:59:59','2018-11-25 07:59:59','CMTETH','4h','0.000383990000000','0.000390070000000','1.408653394535103','1.430957654122002','3668.4637478452632','3668.463747845263242','test','test','2.46'),('2018-11-25 11:59:59','2018-11-25 23:59:59','CMTETH','4h','0.000391420000000','0.000389430000000','1.413609896665525','1.406423029120779','3611.4912285154687','3611.491228515468720','test','test','1.89'),('2018-11-26 03:59:59','2018-11-26 11:59:59','CMTETH','4h','0.000387850000000','0.000375300000000','1.412012814988915','1.366323087444475','3640.6157405927925','3640.615740592792463','test','test','0.0'),('2018-11-29 07:59:59','2018-11-30 07:59:59','CMTETH','4h','0.000391000000000','0.000376410000000','1.401859542201261','1.349549744961577','3585.3185222538655','3585.318522253865467','test','test','4.01'),('2018-11-30 11:59:59','2018-11-30 15:59:59','CMTETH','4h','0.000374850000000','0.000432010000000','1.390235142814665','1.602228848999236','3708.7772250624644','3708.777225062464368','test','test','0.0'),('2018-11-30 19:59:59','2018-12-02 19:59:59','CMTETH','4h','0.000403830000000','0.000385940000000','1.437344855300125','1.373669300087983','3559.282012976067','3559.282012976067108','test','test','6.78'),('2019-01-11 11:59:59','2019-01-11 15:59:59','CMTETH','4h','0.000183550000000','0.000181860000000','1.423194731919649','1.410090950405379','7753.716872348946','7753.716872348945799','test','test','0.0'),('2019-01-11 19:59:59','2019-01-12 03:59:59','CMTETH','4h','0.000183030000000','0.000178880000000','1.420282780472033','1.388079461131166','7759.835985751152','7759.835985751152293','test','test','0.83'),('2019-01-12 15:59:59','2019-01-14 15:59:59','CMTETH','4h','0.000180670000000','0.000180000000000','1.413126487285174','1.407886022645328','7821.589014696265','7821.589014696264712','test','test','0.99'),('2019-01-15 23:59:59','2019-01-27 19:59:59','CMTETH','4h','0.000187730000000','0.000227580000000','1.411961939587431','1.711683258995939','7521.237626311355','7521.237626311354688','test','test','4.11'),('2019-01-27 23:59:59','2019-01-28 03:59:59','CMTETH','4h','0.000226820000000','0.000218060000000','1.478566677233766','1.421463052806609','6518.678587575019','6518.678587575019264','test','test','19.8'),('2019-02-05 23:59:59','2019-02-06 03:59:59','CMTETH','4h','0.000215820000000','0.000213580000000','1.465876982916620','1.450662617048150','6792.127619852747','6792.127619852746648','test','test','0.0'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CMTETH','4h','0.000216230000000','0.000215410000000','1.462496012723626','1.456949850163235','6763.612878525766','6763.612878525766064','test','test','1.22'),('2019-02-08 07:59:59','2019-02-08 11:59:59','CMTETH','4h','0.000214390000000','0.000216070000000','1.461263532154651','1.472714265556488','6815.91273918863','6815.912739188630439','test','test','0.0'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTETH','4h','0.000220300000000','0.000214460000000','1.463808139577281','1.425003602422804','6644.61252645157','6644.612526451570375','test','test','2.21'),('2019-02-10 19:59:59','2019-02-10 23:59:59','CMTETH','4h','0.000215480000000','0.000204800000000','1.455184909098508','1.383060466787518','6753.2249354859305','6753.224935485930473','test','test','0.47'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CMTETH','4h','0.000216880000000','0.000210440000000','1.439157255251621','1.396423150106746','6635.730612558195','6635.730612558195389','test','test','5.56'),('2019-02-16 03:59:59','2019-02-16 11:59:59','CMTETH','4h','0.000213290000000','0.000208490000000','1.429660787441650','1.397486884400158','6702.896466977587','6702.896466977586897','test','test','1.33'),('2019-02-16 19:59:59','2019-02-17 11:59:59','CMTETH','4h','0.000210590000000','0.000203070000000','1.422511031210207','1.371714303185606','6754.8840458246195','6754.884045824619534','test','test','0.99'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTETH','4h','0.000193790000000','0.000191180000000','1.411222869426962','1.392216255622305','7282.227511362619','7282.227511362619225','test','test','0.0'),('2019-02-25 23:59:59','2019-03-05 15:59:59','CMTETH','4h','0.000194840000000','0.000205520000000','1.406999177470372','1.484122720969569','7221.305571085873','7221.305571085873453','test','test','1.87'),('2019-03-07 23:59:59','2019-03-08 03:59:59','CMTETH','4h','0.000207250000000','0.000212910000000','1.424137742692415','1.463030961624328','6871.5934508681075','6871.593450868107539','test','test','2.01'),('2019-03-08 07:59:59','2019-03-16 03:59:59','CMTETH','4h','0.000212010000000','0.000237970000000','1.432780680232841','1.608220454105982','6758.0806576710565','6758.080657671056542','test','test','0.0'),('2019-03-17 15:59:59','2019-03-18 15:59:59','CMTETH','4h','0.000239420000000','0.000239550000000','1.471767296649094','1.472566435186244','6147.219516536188','6147.219516536188166','test','test','11.0'),('2019-03-18 19:59:59','2019-03-18 23:59:59','CMTETH','4h','0.000238240000000','0.000238260000000','1.471944882990683','1.472068451231364','6178.41203404417','6178.412034044169559','test','test','8.47'),('2019-03-19 03:59:59','2019-03-19 07:59:59','CMTETH','4h','0.000238960000000','0.000235220000000','1.471972342599723','1.448934275302590','6159.9110420142415','6159.911042014241502','test','test','0.29'),('2019-03-19 11:59:59','2019-03-21 15:59:59','CMTETH','4h','0.000242390000000','0.000241470000000','1.466852772089249','1.461285279410830','6051.622476542964','6051.622476542964250','test','test','2.95'),('2019-03-21 19:59:59','2019-03-21 23:59:59','CMTETH','4h','0.000244590000000','0.000242790000000','1.465615551494045','1.454829713999915','5992.131941183388','5992.131941183388335','test','test','1.27'),('2019-03-22 03:59:59','2019-03-22 07:59:59','CMTETH','4h','0.000243920000000','0.000242340000000','1.463218698717571','1.453740650406757','5998.764753679778','5998.764753679777641','test','test','0.46'),('2019-03-22 11:59:59','2019-03-22 15:59:59','CMTETH','4h','0.000242270000000','0.000242180000000','1.461112465759613','1.460569682410794','6030.926097988248','6030.926097988248330','test','test','0.0'),('2019-03-22 19:59:59','2019-03-24 11:59:59','CMTETH','4h','0.000243180000000','0.000243860000000','1.460991847237653','1.465077193302797','6007.861860505193','6007.861860505193363','test','test','0.41'),('2019-03-24 15:59:59','2019-03-24 19:59:59','CMTETH','4h','0.000241700000000','0.000244210000000','1.461899701918796','1.477081200685102','6048.405882990468','6048.405882990467944','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 07:59:59','CMTETH','4h','0.000242850000000','0.000240460000000','1.465273368311309','1.450852930385577','6033.6560358711495','6033.656035871149470','test','test','0.21'),('2019-03-27 15:59:59','2019-03-27 23:59:59','CMTETH','4h','0.000243660000000','0.000238650000000','1.462068826550035','1.432006588919666','6000.446632808154','6000.446632808154391','test','test','1.38'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTETH','4h','0.000242980000000','0.000241030000000','1.455388329298842','1.443708325832990','5989.745367103636','5989.745367103636454','test','test','1.78'),('2019-03-30 11:59:59','2019-03-30 15:59:59','CMTETH','4h','0.000243340000000','0.000252750000000','1.452792772973097','1.508972521447153','5970.21769118557','5970.217691185570402','test','test','1.18'),('2019-03-30 19:59:59','2019-04-03 03:59:59','CMTETH','4h','0.000258880000000','0.000244460000000','1.465277161522887','1.383659050161793','5660.06320118544','5660.063201185440448','test','test','2.36'),('2019-04-03 07:59:59','2019-04-07 23:59:59','CMTETH','4h','0.000261660000000','0.000275150000000','1.447139803442644','1.521747752492714','5530.611493704211','5530.611493704211171','test','test','6.57'),('2019-04-13 19:59:59','2019-04-13 23:59:59','CMTETH','4h','0.000259730000000','0.000253220000000','1.463719347675993','1.427031968654045','5635.542092465224','5635.542092465224414','test','test','0.0'),('2019-04-19 23:59:59','2019-04-20 03:59:59','CMTETH','4h','0.000246410000000','0.000242480000000','1.455566596782226','1.432351724312139','5907.092231574313','5907.092231574312791','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 19:43:46
