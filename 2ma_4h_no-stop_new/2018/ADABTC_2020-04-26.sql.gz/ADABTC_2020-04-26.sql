-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 11:59:59','2018-05-30 15:59:59','ADABTC','4h','0.000028360000000','0.000027340000000','0.033333333333333','0.032134461683121','1175.3643629525152','1175.364362952515194','test','test','0.0'),('2018-05-30 19:59:59','2018-06-04 07:59:59','ADABTC','4h','0.000027690000000','0.000028460000000','0.033066917411064','0.033986438046908','1194.182643953196','1194.182643953196020','test','test','1.26'),('2018-06-05 19:59:59','2018-06-06 07:59:59','ADABTC','4h','0.000028700000000','0.000028250000000','0.033271255330140','0.032749580594998','1159.2771892035','1159.277189203500029','test','test','0.83'),('2018-07-01 11:59:59','2018-07-01 15:59:59','ADABTC','4h','0.000022370000000','0.000022060000000','0.033155327611220','0.032695866209366','1482.1335543683504','1482.133554368350360','test','test','0.0'),('2018-07-01 19:59:59','2018-07-02 07:59:59','ADABTC','4h','0.000022050000000','0.000022310000000','0.033053225077475','0.033442968321019','1499.0124751689193','1499.012475168919309','test','test','0.0'),('2018-07-02 11:59:59','2018-07-05 15:59:59','ADABTC','4h','0.000022430000000','0.000022620000000','0.033139834687151','0.033420555533810','1477.4781403099025','1477.478140309902528','test','test','1.64'),('2018-07-05 19:59:59','2018-07-05 23:59:59','ADABTC','4h','0.000022380000000','0.000022580000000','0.033202217097520','0.033498930387042','1483.5664476103568','1483.566447610356818','test','test','0.0'),('2018-07-13 23:59:59','2018-07-20 19:59:59','ADABTC','4h','0.000022130000000','0.000022270000000','0.033268153384080','0.033478616170965','1503.3056206091378','1503.305620609137804','test','test','0.0'),('2018-07-22 11:59:59','2018-07-22 23:59:59','ADABTC','4h','0.000022970000000','0.000022890000000','0.033314922892277','0.033198893556997','1450.3666910002999','1450.366691000299852','test','test','3.78'),('2018-07-23 03:59:59','2018-07-23 11:59:59','ADABTC','4h','0.000023190000000','0.000022410000000','0.033289138595548','0.032169452174482','1435.4954116234585','1435.495411623458494','test','test','2.63'),('2018-08-09 19:59:59','2018-08-09 23:59:59','ADABTC','4h','0.000019080000000','0.000018710000000','0.033040319390867','0.032399600408969','1731.6729240496159','1731.672924049615858','test','test','0.0'),('2018-08-28 19:59:59','2018-08-28 23:59:59','ADABTC','4h','0.000015000000000','0.000014900000000','0.032897937394889','0.032678617812256','2193.1958263259553','2193.195826325955295','test','test','0.0'),('2018-08-29 11:59:59','2018-08-29 15:59:59','ADABTC','4h','0.000014850000000','0.000014700000000','0.032849199709860','0.032517389611781','2212.067320529278','2212.067320529277822','test','test','0.0'),('2018-08-29 19:59:59','2018-08-30 07:59:59','ADABTC','4h','0.000014820000000','0.000014730000000','0.032775464132509','0.032576422852352','2211.5697795215174','2211.569779521517376','test','test','0.80'),('2018-09-01 03:59:59','2018-09-02 03:59:59','ADABTC','4h','0.000014840000000','0.000014710000000','0.032731232736918','0.032444503609169','2205.608674994505','2205.608674994504781','test','test','0.74'),('2018-09-19 07:59:59','2018-09-19 11:59:59','ADABTC','4h','0.000011560000000','0.000010980000000','0.032667515152974','0.031028487576095','2825.909615309189','2825.909615309189121','test','test','0.0'),('2018-09-19 23:59:59','2018-09-20 03:59:59','ADABTC','4h','0.000011290000000','0.000011320000000','0.032303286802557','0.032389123702830','2861.23000908385','2861.230009083849836','test','test','2.74'),('2018-09-20 07:59:59','2018-09-20 11:59:59','ADABTC','4h','0.000011280000000','0.000011550000000','0.032322361669284','0.033096035219879','2865.457594794681','2865.457594794680972','test','test','0.0'),('2018-09-20 15:59:59','2018-09-25 03:59:59','ADABTC','4h','0.000011690000000','0.000012300000000','0.032494289124972','0.034189885050227','2779.6654512379623','2779.665451237962316','test','test','3.16'),('2018-09-25 23:59:59','2018-09-26 03:59:59','ADABTC','4h','0.000012580000000','0.000012060000000','0.032871088219473','0.031512346894026','2612.964087398481','2612.964087398480842','test','test','2.22'),('2018-09-26 07:59:59','2018-09-26 23:59:59','ADABTC','4h','0.000012360000000','0.000012240000000','0.032569145702707','0.032252940404622','2635.044150704441','2635.044150704441108','test','test','2.42'),('2018-09-27 03:59:59','2018-09-27 07:59:59','ADABTC','4h','0.000012420000000','0.000012210000000','0.032498877858688','0.031949379923879','2616.6568324225445','2616.656832422544539','test','test','1.44'),('2018-09-27 11:59:59','2018-09-28 11:59:59','ADABTC','4h','0.000012370000000','0.000012340000000','0.032376767206508','0.032298246348287','2617.3619407039796','2617.361940703979599','test','test','1.29'),('2018-09-28 15:59:59','2018-10-03 03:59:59','ADABTC','4h','0.000012700000000','0.000012260000000','0.032359318126904','0.031238207892586','2547.977805267997','2547.977805267997155','test','test','2.83'),('2018-10-05 23:59:59','2018-10-06 03:59:59','ADABTC','4h','0.000012570000000','0.000012500000000','0.032110182519277','0.031931366864834','2554.5093491867415','2554.509349186741474','test','test','2.46'),('2018-10-06 07:59:59','2018-10-06 11:59:59','ADABTC','4h','0.000012500000000','0.000012500000000','0.032070445707179','0.032070445707179','2565.6356565743113','2565.635656574311270','test','test','0.0'),('2018-10-07 15:59:59','2018-10-11 03:59:59','ADABTC','4h','0.000012700000000','0.000012310000000','0.032070445707179','0.031085605248455','2525.231945447157','2525.231945447157159','test','test','1.57'),('2018-10-17 19:59:59','2018-10-17 23:59:59','ADABTC','4h','0.000012020000000','0.000011880000000','0.031851592271907','0.031480608668074','2649.882884518044','2649.882884518044193','test','test','0.0'),('2018-10-20 11:59:59','2018-10-20 15:59:59','ADABTC','4h','0.000011890000000','0.000011880000000','0.031769151471055','0.031742432251988','2671.9219067329786','2671.921906732978641','test','test','0.08'),('2018-10-20 19:59:59','2018-10-20 23:59:59','ADABTC','4h','0.000011850000000','0.000011780000000','0.031763213866818','0.031575583067605','2680.439988761013','2680.439988761012955','test','test','0.0'),('2018-10-21 03:59:59','2018-10-21 07:59:59','ADABTC','4h','0.000011890000000','0.000011850000000','0.031721518133660','0.031614801504110','2667.9157387434443','2667.915738743444308','test','test','0.92'),('2018-11-02 23:59:59','2018-11-03 07:59:59','ADABTC','4h','0.000011360000000','0.000011280000000','0.031697803327093','0.031474579360001','2790.299588652544','2790.299588652544116','test','test','0.0'),('2018-11-04 03:59:59','2018-11-04 07:59:59','ADABTC','4h','0.000011310000000','0.000011640000000','0.031648198001072','0.032571620223915','2798.24916013019','2798.249160130189921','test','test','0.26'),('2018-11-04 11:59:59','2018-11-09 15:59:59','ADABTC','4h','0.000011630000000','0.000011680000000','0.031853402939482','0.031990347922025','2738.8996508582977','2738.899650858297719','test','test','0.0'),('2018-11-09 19:59:59','2018-11-09 23:59:59','ADABTC','4h','0.000011720000000','0.000011620000000','0.031883835157825','0.031611788782758','2720.463750667653','2720.463750667653130','test','test','0.68'),('2018-11-10 15:59:59','2018-11-10 23:59:59','ADABTC','4h','0.000011730000000','0.000011740000000','0.031823380407810','0.031850510314381','2712.990657102302','2712.990657102302066','test','test','0.93'),('2018-11-11 07:59:59','2018-11-11 15:59:59','ADABTC','4h','0.000011930000000','0.000011780000000','0.031829409275937','0.031429207147572','2668.014189097812','2668.014189097812050','test','test','1.59'),('2018-11-11 19:59:59','2018-11-12 11:59:59','ADABTC','4h','0.000011950000000','0.000011850000000','0.031740475469634','0.031474864796248','2656.1067338605485','2656.106733860548502','test','test','1.50'),('2018-11-12 15:59:59','2018-11-13 11:59:59','ADABTC','4h','0.000011990000000','0.000011840000000','0.031681450875548','0.031285102449248','2642.3228419973125','2642.322841997312480','test','test','1.75'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ADABTC','4h','0.000011830000000','0.000011640000000','0.031593373447481','0.031085956629643','2670.6148307253684','2670.614830725368392','test','test','0.0'),('2018-12-02 03:59:59','2018-12-02 07:59:59','ADABTC','4h','0.000010000000000','0.000009960000000','0.031480614154628','0.031354691698009','3148.061415462822','3148.061415462821969','test','test','0.0'),('2018-12-02 11:59:59','2018-12-02 15:59:59','ADABTC','4h','0.000009930000000','0.000009900000000','0.031452631386491','0.031357608330943','3167.4351849436725','3167.435184943672539','test','test','0.0'),('2018-12-02 19:59:59','2018-12-03 15:59:59','ADABTC','4h','0.000010030000000','0.000009900000000','0.031431515151924','0.031024127617552','3133.7502643992466','3133.750264399246589','test','test','1.29'),('2018-12-16 15:59:59','2018-12-16 19:59:59','ADABTC','4h','0.000008970000000','0.000009000000000','0.031340984588731','0.031445803935182','3493.9782150201413','3493.978215020141306','test','test','0.0'),('2018-12-16 23:59:59','2018-12-17 03:59:59','ADABTC','4h','0.000008980000000','0.000009010000000','0.031364277776831','0.031469058214838','3492.6812669076717','3492.681266907671670','test','test','0.0'),('2018-12-17 07:59:59','2018-12-17 11:59:59','ADABTC','4h','0.000009020000000','0.000008970000000','0.031387562318610','0.031213573613961','3479.774092972309','3479.774092972309063','test','test','0.22'),('2018-12-17 15:59:59','2018-12-27 19:59:59','ADABTC','4h','0.000009180000000','0.000010120000000','0.031348898162022','0.034558916056608','3414.9126538149844','3414.912653814984424','test','test','2.28'),('2018-12-28 15:59:59','2019-01-10 15:59:59','ADABTC','4h','0.000010360000000','0.000011970000000','0.032062235471930','0.037044880173649','3094.8103737383744','3094.810373738374437','test','test','4.44'),('2019-01-10 19:59:59','2019-01-11 07:59:59','ADABTC','4h','0.000012000000000','0.000012110000000','0.033169489850089','0.033473543507048','2764.124154174111','2764.124154174111027','test','test','17.0'),('2019-01-11 11:59:59','2019-01-12 15:59:59','ADABTC','4h','0.000012010000000','0.000011890000000','0.033237057329414','0.032904963500977','2767.4485703092055','2767.448570309205479','test','test','3.08'),('2019-01-12 19:59:59','2019-01-13 03:59:59','ADABTC','4h','0.000011940000000','0.000011910000000','0.033163258700872','0.033079933930267','2777.492353506868','2777.492353506867858','test','test','0.83'),('2019-01-13 07:59:59','2019-01-13 15:59:59','ADABTC','4h','0.000011970000000','0.000011790000000','0.033144742085182','0.032646324910969','2768.984301184795','2768.984301184795186','test','test','1.00'),('2019-01-14 19:59:59','2019-01-15 03:59:59','ADABTC','4h','0.000011920000000','0.000011900000000','0.033033982713135','0.032978556567643','2771.3072745918344','2771.307274591834357','test','test','1.09'),('2019-01-15 07:59:59','2019-01-15 11:59:59','ADABTC','4h','0.000011890000000','0.000011790000000','0.033021665791914','0.032743939418559','2777.263733550398','2777.263733550397774','test','test','0.08'),('2019-01-15 19:59:59','2019-01-15 23:59:59','ADABTC','4h','0.000011840000000','0.000011830000000','0.032959948820058','0.032932111025446','2783.77946115351','2783.779461153510056','test','test','0.42'),('2019-01-16 03:59:59','2019-01-20 15:59:59','ADABTC','4h','0.000012010000000','0.000012040000000','0.032953762643477','0.033036078453577','2743.860336675863','2743.860336675862982','test','test','1.49'),('2019-01-20 19:59:59','2019-01-20 23:59:59','ADABTC','4h','0.000012070000000','0.000012120000000','0.032972055045722','0.033108641852042','2731.7361264060946','2731.736126406094627','test','test','0.24'),('2019-01-21 03:59:59','2019-01-21 07:59:59','ADABTC','4h','0.000012120000000','0.000012020000000','0.033002407669348','0.032730110576367','2722.9709298142097','2722.970929814209740','test','test','0.0'),('2019-01-21 11:59:59','2019-01-21 19:59:59','ADABTC','4h','0.000012220000000','0.000012070000000','0.032941897204241','0.032537536763927','2695.73626875952','2695.736268759520044','test','test','1.63'),('2019-01-21 23:59:59','2019-01-22 03:59:59','ADABTC','4h','0.000012060000000','0.000012070000000','0.032852039328616','0.032879279825572','2724.049695573466','2724.049695573466124','test','test','0.0'),('2019-01-22 19:59:59','2019-01-23 07:59:59','ADABTC','4h','0.000012180000000','0.000012090000000','0.032858092772384','0.032615298983426','2697.7087662055833','2697.708766205583288','test','test','0.90'),('2019-01-23 11:59:59','2019-01-23 19:59:59','ADABTC','4h','0.000012210000000','0.000012050000000','0.032804138597060','0.032374272735018','2686.661637760852','2686.661637760852045','test','test','0.98'),('2019-02-08 15:59:59','2019-02-08 19:59:59','ADABTC','4h','0.000011360000000','0.000011240000000','0.032708612849940','0.032363099333920','2879.2793001707355','2879.279300170735496','test','test','0.0'),('2019-02-08 23:59:59','2019-02-10 07:59:59','ADABTC','4h','0.000011130000000','0.000011140000000','0.032631832068602','0.032661150875492','2931.8806890028554','2931.880689002855434','test','test','0.0'),('2019-02-10 11:59:59','2019-02-10 15:59:59','ADABTC','4h','0.000011220000000','0.000011210000000','0.032638347359022','0.032609257922873','2908.9436148860773','2908.943614886077285','test','test','0.71'),('2019-02-10 19:59:59','2019-02-14 03:59:59','ADABTC','4h','0.000011450000000','0.000011330000000','0.032631883039878','0.032289889505836','2849.9461170198742','2849.946117019874237','test','test','2.09'),('2019-02-14 07:59:59','2019-02-14 11:59:59','ADABTC','4h','0.000011280000000','0.000011180000000','0.032555884476757','0.032267268479623','2886.1599713437163','2886.159971343716279','test','test','0.35'),('2019-02-16 03:59:59','2019-02-16 07:59:59','ADABTC','4h','0.000011300000000','0.000011290000000','0.032491747588505','0.032462993829577','2875.375892788063','2875.375892788063084','test','test','1.06'),('2019-02-16 11:59:59','2019-02-16 15:59:59','ADABTC','4h','0.000011280000000','0.000011340000000','0.032485357864299','0.032658152321024','2879.907612083235','2879.907612083235108','test','test','0.0'),('2019-02-16 19:59:59','2019-02-17 03:59:59','ADABTC','4h','0.000011340000000','0.000011290000000','0.032523756632460','0.032380353825439','2868.0561404285722','2868.056140428572235','test','test','0.44'),('2019-02-17 07:59:59','2019-02-17 11:59:59','ADABTC','4h','0.000011290000000','0.000011310000000','0.032491889342011','0.032549448047666','2877.9352827290427','2877.935282729042683','test','test','0.0'),('2019-02-17 19:59:59','2019-02-17 23:59:59','ADABTC','4h','0.000011300000000','0.000011340000000','0.032504680165490','0.032619740980235','2876.5203686274144','2876.520368627414427','test','test','0.0'),('2019-02-18 03:59:59','2019-02-21 11:59:59','ADABTC','4h','0.000011540000000','0.000011460000000','0.032530249235433','0.032304736242466','2818.9124120825923','2818.912412082592255','test','test','1.99'),('2019-02-21 15:59:59','2019-02-21 19:59:59','ADABTC','4h','0.000011480000000','0.000011400000000','0.032480135236996','0.032253792831163','2829.2800729090595','2829.280072909059527','test','test','0.17'),('2019-02-22 19:59:59','2019-02-24 15:59:59','ADABTC','4h','0.000011600000000','0.000011310000000','0.032429836924589','0.031619091001474','2795.6755969472993','2795.675596947299255','test','test','1.72'),('2019-03-09 07:59:59','2019-04-02 07:59:59','ADABTC','4h','0.000011250000000','0.000016690000000','0.032249671163896','0.047844178820038','2866.6374367907956','2866.637436790795618','test','test','0.0'),('2019-04-02 11:59:59','2019-04-08 03:59:59','ADABTC','4h','0.000016660000000','0.000016860000000','0.035715117309706','0.036143870218586','2143.7645444001073','2143.764544400107297','test','test','32.1'),('2019-05-15 15:59:59','2019-05-15 19:59:59','ADABTC','4h','0.000011010000000','0.000010970000000','0.035810395733901','0.035680294387002','3252.5336724706035','3252.533672470603506','test','test','0.0'),('2019-05-15 23:59:59','2019-05-16 11:59:59','ADABTC','4h','0.000011490000000','0.000011000000000','0.035781484323479','0.034255555052939','3114.141368449029','3114.141368449028960','test','test','4.52'),('2019-05-16 15:59:59','2019-05-17 03:59:59','ADABTC','4h','0.000011690000000','0.000011030000000','0.035442388930026','0.033441364405320','3031.855340464158','3031.855340464157962','test','test','5.90'),('2019-05-17 07:59:59','2019-05-17 11:59:59','ADABTC','4h','0.000010980000000','0.000010850000000','0.034997716813425','0.034583354046053','3187.405902861992','3187.405902861992217','test','test','0.0'),('2019-05-17 15:59:59','2019-05-17 19:59:59','ADABTC','4h','0.000010940000000','0.000010990000000','0.034905636198453','0.035065168356581','3190.6431625642704','3190.643162564270369','test','test','0.82'),('2019-05-17 23:59:59','2019-05-18 07:59:59','ADABTC','4h','0.000011240000000','0.000011010000000','0.034941087789148','0.034226101117306','3108.637703660874','3108.637703660874195','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 18:30:09
