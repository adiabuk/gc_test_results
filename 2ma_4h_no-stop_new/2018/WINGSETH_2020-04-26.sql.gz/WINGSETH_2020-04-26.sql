-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 15:59:59','2018-07-01 19:59:59','WINGSETH','4h','0.000477900000000','0.000484900000000','1.297777777777778','1.316786868475506','2715.5843853897836','2715.584385389783620','test','test','0.0'),('2018-07-01 23:59:59','2018-07-02 11:59:59','WINGSETH','4h','0.000489800000000','0.000477800000000','1.302002020155051','1.270103236484450','2658.231972550124','2658.231972550123828','test','test','1.00'),('2018-07-02 15:59:59','2018-07-03 19:59:59','WINGSETH','4h','0.000483000000000','0.000478600000000','1.294913401561584','1.283117089000775','2680.9801274566953','2680.980127456695300','test','test','1.07'),('2018-07-03 23:59:59','2018-07-04 00:22:27','WINGSETH','4h','0.000480700000000','0.000473000000000','1.292291998770293','1.271591669270540','2688.3544804873995','2688.354480487399542','test','test','0.43'),('2018-07-04 11:59:59','2018-07-04 15:59:59','WINGSETH','4h','0.000483000000000','0.000529400000000','1.287691925548126','1.411395663323350','2666.0288313625792','2666.028831362579240','test','test','2.07'),('2018-07-04 19:59:59','2018-07-05 23:59:59','WINGSETH','4h','0.000522400000000','0.000485800000000','1.315181645053731','1.223038367471483','2517.575890225365','2517.575890225365129','test','test','0.0'),('2018-07-09 19:59:59','2018-07-10 03:59:59','WINGSETH','4h','0.000503800000000','0.000491100000000','1.294705361146565','1.262067889756010','2569.879637051538','2569.879637051537884','test','test','3.63'),('2018-07-16 19:59:59','2018-07-16 23:59:59','WINGSETH','4h','0.000461400000000','0.000447200000000','1.287452589726441','1.247830078295762','2790.317706385872','2790.317706385872043','test','test','0.0'),('2018-07-17 11:59:59','2018-07-17 15:59:59','WINGSETH','4h','0.000461700000000','0.000451800000000','1.278647587186290','1.251230192529274','2769.433803738987','2769.433803738987081','test','test','3.14'),('2018-07-17 19:59:59','2018-07-21 11:59:59','WINGSETH','4h','0.000460600000000','0.000493500000000','1.272554832818065','1.363451606590784','2762.819871511213','2762.819871511213023','test','test','1.91'),('2018-07-21 15:59:59','2018-07-23 03:59:59','WINGSETH','4h','0.000492100000000','0.000487300000000','1.292754115878669','1.280144443543336','2627.0150698611437','2627.015069861143729','test','test','1.32'),('2018-07-23 07:59:59','2018-07-23 11:59:59','WINGSETH','4h','0.000490000000000','0.000473200000000','1.289951966470817','1.245725041906103','2632.5550336139127','2632.555033613912656','test','test','0.85'),('2018-07-23 19:59:59','2018-07-24 03:59:59','WINGSETH','4h','0.000487500000000','0.000473300000000','1.280123761011992','1.242836053511745','2625.8948943835735','2625.894894383573501','test','test','2.93'),('2018-07-25 11:59:59','2018-07-25 15:59:59','WINGSETH','4h','0.000481600000000','0.000467200000000','1.271837603789715','1.233809236898993','2640.8588118557195','2640.858811855719523','test','test','1.72'),('2018-07-25 23:59:59','2018-07-26 03:59:59','WINGSETH','4h','0.000484100000000','0.000484600000000','1.263386855591776','1.264691737698357','2609.764213162108','2609.764213162107808','test','test','3.49'),('2018-07-26 07:59:59','2018-07-26 11:59:59','WINGSETH','4h','0.000486200000000','0.000478400000000','1.263676829393239','1.243403939082117','2599.088501425831','2599.088501425831055','test','test','0.32'),('2018-07-26 15:59:59','2018-07-26 19:59:59','WINGSETH','4h','0.000482800000000','0.000480400000000','1.259171742657434','1.252912396795011','2608.060776009598','2608.060776009598158','test','test','0.91'),('2018-07-27 19:59:59','2018-07-30 23:59:59','WINGSETH','4h','0.000484000000000','0.000511000000000','1.257780776910229','1.327946233473403','2598.720613450886','2598.720613450886049','test','test','0.74'),('2018-07-31 03:59:59','2018-07-31 11:59:59','WINGSETH','4h','0.000509500000000','0.000500000000000','1.273373100590934','1.249630128155971','2499.2602563119417','2499.260256311941703','test','test','0.0'),('2018-08-07 19:59:59','2018-08-07 23:59:59','WINGSETH','4h','0.000459300000000','0.000445900000000','1.268096884494276','1.231100371861523','2760.933778563631','2760.933778563631222','test','test','0.0'),('2018-08-08 15:59:59','2018-08-08 19:59:59','WINGSETH','4h','0.000463000000000','0.000417500000000','1.259875437242553','1.136064784122604','2721.1132553834836','2721.113255383483647','test','test','3.69'),('2018-08-10 15:59:59','2018-08-10 19:59:59','WINGSETH','4h','0.000447300000000','0.000430900000000','1.232361958771453','1.187178108729307','2755.112807447917','2755.112807447917021','test','test','6.66'),('2018-08-10 23:59:59','2018-08-15 03:59:59','WINGSETH','4h','0.000444300000000','0.000451800000000','1.222321103206532','1.242954477669843','2751.1165951081066','2751.116595108106594','test','test','3.01'),('2018-08-15 07:59:59','2018-08-15 19:59:59','WINGSETH','4h','0.000458100000000','0.000448900000000','1.226906297531712','1.202266398083356','2678.2499400386637','2678.249940038663681','test','test','1.72'),('2018-08-15 23:59:59','2018-08-16 07:59:59','WINGSETH','4h','0.000451900000000','0.000449100000000','1.221430764320966','1.213862704705789','2702.878433991959','2702.878433991958900','test','test','0.66'),('2018-08-17 03:59:59','2018-08-17 07:59:59','WINGSETH','4h','0.000451600000000','0.000461500000000','1.219748973295371','1.246488377271510','2700.949896579653','2700.949896579652886','test','test','0.55'),('2018-08-17 11:59:59','2018-08-23 11:59:59','WINGSETH','4h','0.000467800000000','0.000518000000000','1.225691063067847','1.357220971930622','2620.1177064297704','2620.117706429770351','test','test','3.42'),('2018-08-23 15:59:59','2018-08-29 19:59:59','WINGSETH','4h','0.000527600000000','0.000519000000000','1.254919931704019','1.234464451391937','2378.5442223351383','2378.544222335138329','test','test','5.23'),('2018-08-29 23:59:59','2018-08-30 15:59:59','WINGSETH','4h','0.000516400000000','0.000501400000000','1.250374269412445','1.214054335173121','2421.3289492882363','2421.328949288236345','test','test','1.43'),('2018-08-31 07:59:59','2018-08-31 19:59:59','WINGSETH','4h','0.000513100000000','0.000512800000000','1.242303172914818','1.241576821420227','2421.171648635388','2421.171648635388010','test','test','2.28'),('2018-08-31 23:59:59','2018-09-01 03:59:59','WINGSETH','4h','0.000512300000000','0.000507400000000','1.242141761471575','1.230261038006397','2424.6374418730725','2424.637441873072476','test','test','0.25'),('2018-09-01 11:59:59','2018-09-01 15:59:59','WINGSETH','4h','0.000511800000000','0.000508700000000','1.239501600701536','1.231993873147463','2421.84759808819','2421.847598088189898','test','test','0.85'),('2018-09-01 23:59:59','2018-09-02 15:59:59','WINGSETH','4h','0.000509400000000','0.000509100000000','1.237833216800631','1.237104221973304','2429.9827577554584','2429.982757755458351','test','test','0.13'),('2018-09-02 19:59:59','2018-09-02 23:59:59','WINGSETH','4h','0.000508200000000','0.000509100000000','1.237671217950113','1.239863079611182','2435.401845631864','2435.401845631864035','test','test','0.0'),('2018-09-03 07:59:59','2018-09-13 23:59:59','WINGSETH','4h','0.000511700000000','0.000573600000000','1.238158298319240','1.387937463193113','2419.695716863865','2419.695716863865073','test','test','0.50'),('2018-09-16 07:59:59','2018-09-16 11:59:59','WINGSETH','4h','0.000585600000000','0.000574400000000','1.271442557180100','1.247125349802338','2171.1792301572755','2171.179230157275470','test','test','9.59'),('2018-09-16 15:59:59','2018-09-21 15:59:59','WINGSETH','4h','0.000582400000000','0.000603300000000','1.266038733318376','1.311471785389726','2173.83024264831','2173.830242648310104','test','test','1.37'),('2018-09-23 07:59:59','2018-09-23 11:59:59','WINGSETH','4h','0.000625600000000','0.000592500000000','1.276134967112009','1.208615677771524','2039.8576840025714','2039.857684002571432','test','test','3.56'),('2018-09-24 23:59:59','2018-09-29 11:59:59','WINGSETH','4h','0.000604100000000','0.000619000000000','1.261130680591901','1.292236204744888','2087.619070670255','2087.619070670255041','test','test','1.92'),('2018-09-29 15:59:59','2018-09-29 19:59:59','WINGSETH','4h','0.000620000000000','0.000612600000000','1.268043019292565','1.252908312288105','2045.2306762783305','2045.230676278330520','test','test','0.16'),('2018-09-29 23:59:59','2018-09-30 03:59:59','WINGSETH','4h','0.000618800000000','0.000610100000000','1.264679751069352','1.246899024123160','2043.761717953057','2043.761717953057087','test','test','1.00'),('2018-10-01 07:59:59','2018-10-01 11:59:59','WINGSETH','4h','0.000612700000000','0.000620000000000','1.260728478414642','1.275749398754820','2057.6603205722904','2057.660320572290402','test','test','0.42'),('2018-10-01 15:59:59','2018-10-03 19:59:59','WINGSETH','4h','0.000620700000000','0.000631900000000','1.264066460712460','1.286875457586924','2036.517578077106','2036.517578077106009','test','test','0.11'),('2018-10-03 23:59:59','2018-10-11 15:59:59','WINGSETH','4h','0.000638500000000','0.000671200000000','1.269135126684563','1.334132336774752','1987.6822657549924','1987.682265754992386','test','test','1.03'),('2018-10-11 19:59:59','2018-10-11 23:59:59','WINGSETH','4h','0.000665700000000','0.000646400000000','1.283578951149049','1.246365380836331','1928.16426490769','1928.164264907690040','test','test','0.0'),('2018-10-12 07:59:59','2018-10-17 07:59:59','WINGSETH','4h','0.000673600000000','0.000754800000000','1.275309268857334','1.429043105898925','1893.273855192004','1893.273855192004021','test','test','4.03'),('2018-10-17 11:59:59','2018-10-17 15:59:59','WINGSETH','4h','0.000757700000000','0.000755400000000','1.309472343755466','1.305497437604433','1728.2200656664452','1728.220065666445180','test','test','11.4'),('2018-10-17 19:59:59','2018-10-27 15:59:59','WINGSETH','4h','0.000777000000000','0.000820300000000','1.308589031277458','1.381512976006305','1684.1557674098558','1684.155767409855798','test','test','2.77'),('2018-10-27 19:59:59','2018-10-27 23:59:59','WINGSETH','4h','0.000815700000000','0.000811500000000','1.324794352328313','1.317973050036075','1624.1195933901101','1624.119593390110140','test','test','0.0'),('2018-10-28 03:59:59','2018-11-03 11:59:59','WINGSETH','4h','0.000849800000000','0.000873200000000','1.323278507374482','1.359716159848668','1557.1646356489553','1557.164635648955255','test','test','4.50'),('2018-11-03 15:59:59','2018-11-04 11:59:59','WINGSETH','4h','0.000871700000000','0.000847900000000','1.331375763479857','1.295025249345613','1527.3325266489123','1527.332526648912335','test','test','5.89'),('2018-11-07 19:59:59','2018-11-12 11:59:59','WINGSETH','4h','0.001057500000000','0.000878700000000','1.323297871450025','1.099557295170815','1251.3455049172812','1251.345504917281232','test','test','19.8'),('2018-11-26 15:59:59','2018-11-26 19:59:59','WINGSETH','4h','0.000778700000000','0.000689500000000','1.273577743387978','1.127689551901902','1635.5178417721565','1635.517841772156544','test','test','0.0'),('2018-11-29 07:59:59','2018-11-30 03:59:59','WINGSETH','4h','0.000720200000000','0.000714100000000','1.241158145279961','1.230645697784532','1723.3520484309377','1723.352048430937657','test','test','4.26'),('2018-11-30 07:59:59','2018-12-05 23:59:59','WINGSETH','4h','0.000765200000000','0.000765200000000','1.238822045836532','1.238822045836532','1618.9519678992845','1618.951967899284455','test','test','6.67'),('2018-12-06 11:59:59','2018-12-06 15:59:59','WINGSETH','4h','0.000784000000000','0.000735300000000','1.238822045836532','1.161869707019900','1580.1301605057813','1580.130160505781305','test','test','2.39'),('2018-12-07 15:59:59','2018-12-07 19:59:59','WINGSETH','4h','0.000804500000000','0.000742000000000','1.221721526099503','1.126808418105446','1518.609727904914','1518.609727904914052','test','test','8.60'),('2018-12-08 11:59:59','2018-12-08 15:59:59','WINGSETH','4h','0.000788800000000','0.000767000000000','1.200629724323046','1.167448020481461','1522.0965064947343','1522.096506494734285','test','test','5.93'),('2018-12-12 11:59:59','2018-12-12 15:59:59','WINGSETH','4h','0.000771400000000','0.000762200000000','1.193256012358250','1.179024802462352','1546.8706408585035','1546.870640858503521','test','test','0.57'),('2018-12-12 19:59:59','2018-12-12 23:59:59','WINGSETH','4h','0.000758300000000','0.000866300000000','1.190093521270272','1.359591213868438','1569.4230796126496','1569.423079612649644','test','test','0.0'),('2018-12-13 03:59:59','2018-12-13 07:59:59','WINGSETH','4h','0.000780100000000','0.000770900000000','1.227759675180976','1.213280263552127','1573.849090092265','1573.849090092264987','test','test','2.29'),('2018-12-13 11:59:59','2018-12-13 15:59:59','WINGSETH','4h','0.000778700000000','0.000766600000000','1.224542028152343','1.205514214436350','1572.5465880985523','1572.546588098552320','test','test','1.00'),('2018-12-13 19:59:59','2018-12-14 11:59:59','WINGSETH','4h','0.000773100000000','0.000759600000000','1.220313625104344','1.199004306854559','1578.4680185025795','1578.468018502579525','test','test','0.84'),('2018-12-14 23:59:59','2018-12-15 03:59:59','WINGSETH','4h','0.000767200000000','0.000752800000000','1.215578221048836','1.192762362885250','1584.4345946934782','1584.434594693478175','test','test','0.99'),('2018-12-15 07:59:59','2018-12-15 19:59:59','WINGSETH','4h','0.000768300000000','0.000761500000000','1.210508030345817','1.199794175593309','1575.5668753687587','1575.566875368758701','test','test','2.01'),('2018-12-15 23:59:59','2018-12-16 03:59:59','WINGSETH','4h','0.000765300000000','0.000762500000000','1.208127173734149','1.203707003753154','1578.6321360697095','1578.632136069709532','test','test','0.49'),('2018-12-16 23:59:59','2018-12-17 19:59:59','WINGSETH','4h','0.000773800000000','0.000754900000000','1.207144913738372','1.177660500621733','1560.0218580232258','1560.021858023225832','test','test','1.46'),('2019-01-08 07:59:59','2019-01-10 19:59:59','WINGSETH','4h','0.000572400000000','0.000570700000000','1.200592821934675','1.197027119982738','2097.471736433743','2097.471736433742990','test','test','0.0'),('2019-01-10 23:59:59','2019-01-14 15:59:59','WINGSETH','4h','0.000577100000000','0.000570200000000','1.199800443723133','1.185455229615198','2079.0165373819673','2079.016537381967282','test','test','2.09'),('2019-01-14 19:59:59','2019-01-26 15:59:59','WINGSETH','4h','0.000600700000000','0.000818200000000','1.196612618365814','1.629879214827550','1992.0303285597042','1992.030328559704230','test','test','5.07'),('2019-01-26 19:59:59','2019-01-26 23:59:59','WINGSETH','4h','0.000806500000000','0.000809300000000','1.292894084246200','1.297382743187166','1603.0924789165529','1603.092478916552864','test','test','6.39'),('2019-01-27 03:59:59','2019-01-27 07:59:59','WINGSETH','4h','0.000810300000000','0.000788800000000','1.293891564010859','1.259560243973548','1596.8055831307652','1596.805583130765172','test','test','0.12'),('2019-01-27 19:59:59','2019-01-27 23:59:59','WINGSETH','4h','0.000845300000000','0.000795900000000','1.286262381780346','1.211092191717707','1521.66376645019','1521.663766450189996','test','test','6.68'),('2019-01-28 15:59:59','2019-01-29 07:59:59','WINGSETH','4h','0.000851200000000','0.000810000000000','1.269557895099759','1.208108429312506','1491.4918880401308','1491.491888040130789','test','test','6.49'),('2019-01-29 11:59:59','2019-01-29 15:59:59','WINGSETH','4h','0.000800100000000','0.000811400000000','1.255902458258148','1.273639863305413','1569.6818625898607','1569.681862589860657','test','test','0.0'),('2019-01-29 19:59:59','2019-01-29 23:59:59','WINGSETH','4h','0.000816600000000','0.000824200000000','1.259844103824206','1.271569324481889','1542.7921918003992','1542.792191800399223','test','test','0.80'),('2019-01-30 03:59:59','2019-01-30 07:59:59','WINGSETH','4h','0.000811500000000','0.000802300000000','1.262449708414803','1.248137277955880','1555.6989629264356','1555.698962926435570','test','test','0.0'),('2019-01-30 11:59:59','2019-01-30 15:59:59','WINGSETH','4h','0.000822100000000','0.000788200000000','1.259269168312820','1.207342121961033','1531.7712788137935','1531.771278813793515','test','test','2.40'),('2019-02-02 07:59:59','2019-02-02 11:59:59','WINGSETH','4h','0.000813300000000','0.000794300000000','1.247729824679089','1.218580843160704','1534.1569220202744','1534.156922020274351','test','test','3.08'),('2019-02-02 15:59:59','2019-02-02 19:59:59','WINGSETH','4h','0.000826000000000','0.000797600000000','1.241252273230559','1.198574834296239','1502.7267230394177','1502.726723039417720','test','test','3.83'),('2019-02-03 07:59:59','2019-02-03 11:59:59','WINGSETH','4h','0.000812100000000','0.000838200000000','1.231768397911821','1.271356078228899','1516.7693608075622','1516.769360807562180','test','test','1.78'),('2019-02-03 15:59:59','2019-02-03 23:59:59','WINGSETH','4h','0.000831300000000','0.000810400000000','1.240565660204505','1.209376171093144','1492.3200531751536','1492.320053175153589','test','test','2.80'),('2019-02-04 03:59:59','2019-02-04 07:59:59','WINGSETH','4h','0.000799200000000','0.000807100000000','1.233634662624203','1.245828999254247','1543.586915195449','1543.586915195448910','test','test','0.0'),('2019-02-07 19:59:59','2019-02-08 03:59:59','WINGSETH','4h','0.000824100000000','0.000767300000000','1.236344515208657','1.151131108505767','1500.2360335015862','1500.236033501586235','test','test','3.27'),('2019-02-10 11:59:59','2019-02-10 15:59:59','WINGSETH','4h','0.000773400000000','0.000769000000000','1.217408202608015','1.210482166803160','1574.0990465580744','1574.099046558074406','test','test','0.78');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 19:02:53
