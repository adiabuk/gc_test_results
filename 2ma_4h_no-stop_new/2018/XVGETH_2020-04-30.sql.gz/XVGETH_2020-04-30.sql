-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-19 15:59:59','2018-04-14 19:59:59','XVGETH','4h','0.000056730000000','0.000172950000000','1.297777777777778','3.956472178153828','22876.39305090389','22876.393050903890980','test','test','1.26'),('2018-04-14 23:59:59','2018-04-15 03:59:59','XVGETH','4h','0.000173450000000','0.000180320000000','1.888598755639122','1.963402292400383','10888.433298582428','10888.433298582427597','test','test','0.0'),('2018-04-15 07:59:59','2018-04-15 11:59:59','XVGETH','4h','0.000176830000000','0.000172030000000','1.905221763808291','1.853505061516373','10774.312977482845','10774.312977482844872','test','test','2.71'),('2018-04-16 23:59:59','2018-04-17 11:59:59','XVGETH','4h','0.000183780000000','0.000208460000000','1.893729163298976','2.148039946573645','10304.326712912049','10304.326712912048606','test','test','0.0'),('2018-04-17 15:59:59','2018-04-17 19:59:59','XVGETH','4h','0.000156190000000','0.000159610000000','1.950242670693348','1.992945980340388','12486.347850011829','12486.347850011828996','test','test','0.0'),('2018-04-30 23:59:59','2018-05-01 03:59:59','XVGETH','4h','0.000115250000000','0.000112210000000','1.959732295059356','1.908039573350198','17004.184772749293','17004.184772749293188','test','test','2.63'),('2018-05-01 11:59:59','2018-05-03 03:59:59','XVGETH','4h','0.000121250000000','0.000108850000000','1.948245023568432','1.749001821158135','16068.000194378823','16068.000194378822926','test','test','10.2'),('2018-07-01 23:59:59','2018-07-05 11:59:59','XVGETH','4h','0.000055360000000','0.000054280000000','1.903968756366144','1.866824857217383','34392.49921181618','34392.499211816182651','test','test','1.95'),('2018-07-08 03:59:59','2018-07-08 07:59:59','XVGETH','4h','0.000054790000000','0.000053320000000','1.895714556555308','1.844853078217357','34599.645127857424','34599.645127857424086','test','test','2.68'),('2018-07-16 15:59:59','2018-07-16 19:59:59','XVGETH','4h','0.000051710000000','0.000051860000000','1.884412005813541','1.889878294749376','36441.92623890043','36441.926238900428871','test','test','0.0'),('2018-07-16 23:59:59','2018-07-17 03:59:59','XVGETH','4h','0.000052200000000','0.000051210000000','1.885626736688171','1.849864850302706','36123.11756107608','36123.117561076076527','test','test','1.89'),('2018-07-17 07:59:59','2018-07-17 11:59:59','XVGETH','4h','0.000051480000000','0.000051800000000','1.877679650824735','1.889351319205930','36473.96369123417','36473.963691234166618','test','test','0.0'),('2018-07-17 15:59:59','2018-07-17 19:59:59','XVGETH','4h','0.000052000000000','0.000052160000000','1.880273354909445','1.886058811386090','36159.10297902778','36159.102979027782567','test','test','0.0'),('2018-07-17 23:59:59','2018-07-20 07:59:59','XVGETH','4h','0.000052780000000','0.000051120000000','1.881559011904254','1.822381521192601','35649.09079015261','35649.090790152607951','test','test','3.14'),('2018-07-25 07:59:59','2018-07-25 19:59:59','XVGETH','4h','0.000051960000000','0.000051270000000','1.868408458412776','1.843597029692514','35958.592348205864','35958.592348205864255','test','test','1.32'),('2018-07-25 23:59:59','2018-07-26 11:59:59','XVGETH','4h','0.000051430000000','0.000051820000000','1.862894807586051','1.877021367472471','36221.94842671692','36221.948426716917311','test','test','0.0'),('2018-07-26 15:59:59','2018-07-26 19:59:59','XVGETH','4h','0.000051430000000','0.000051510000000','1.866034043116367','1.868936682110132','36282.98742205652','36282.987422056517971','test','test','0.0'),('2018-07-27 19:59:59','2018-07-27 23:59:59','XVGETH','4h','0.000051390000000','0.000050480000000','1.866679074003870','1.833624433853188','36323.780385364276','36323.780385364276299','test','test','1.77'),('2018-07-29 03:59:59','2018-07-29 07:59:59','XVGETH','4h','0.000051240000000','0.000050850000000','1.859333598414830','1.845181761892938','36286.76031254547','36286.760312545469787','test','test','0.76'),('2018-07-29 23:59:59','2018-07-30 03:59:59','XVGETH','4h','0.000051220000000','0.000051190000000','1.856188745854409','1.855101559943132','36239.530375915834','36239.530375915834156','test','test','0.05'),('2018-07-30 07:59:59','2018-07-30 15:59:59','XVGETH','4h','0.000052400000000','0.000052000000000','1.855947148985237','1.841779613496800','35418.8387210923','35418.838721092302876','test','test','0.76'),('2018-07-30 19:59:59','2018-07-30 23:59:59','XVGETH','4h','0.000050920000000','0.000053110000000','1.852798807765584','1.932485166544190','36386.4651957106','36386.465195710603439','test','test','0.0'),('2018-07-31 03:59:59','2018-08-02 11:59:59','XVGETH','4h','0.000057600000000','0.000050670000000','1.870506887494163','1.645461527592522','32474.07790788478','32474.077907884780871','test','test','12.0'),('2018-08-17 03:59:59','2018-08-22 19:59:59','XVGETH','4h','0.000044330000000','0.000045950000000','1.820496807516021','1.887025226829713','41066.92550227884','41066.925502278842032','test','test','0.0'),('2018-08-22 23:59:59','2018-08-23 07:59:59','XVGETH','4h','0.000046440000000','0.000046260000000','1.835280900696841','1.828167408833675','39519.399239811384','39519.399239811384177','test','test','1.37'),('2018-08-23 11:59:59','2018-08-23 15:59:59','XVGETH','4h','0.000045490000000','0.000045340000000','1.833700124727249','1.827653630581083','40309.960974439404','40309.960974439403799','test','test','0.32'),('2018-08-23 23:59:59','2018-08-24 03:59:59','XVGETH','4h','0.000046260000000','0.000045410000000','1.832356459361434','1.798687998694395','39609.953725928106','39609.953725928105996','test','test','1.83'),('2018-08-24 07:59:59','2018-08-24 15:59:59','XVGETH','4h','0.000046250000000','0.000046370000000','1.824874579213203','1.829609388932243','39456.747658663844','39456.747658663844049','test','test','0.0'),('2018-08-24 19:59:59','2018-08-30 15:59:59','XVGETH','4h','0.000046810000000','0.000050000000000','1.825926759150768','1.950359708556685','39007.194171133684','39007.194171133683994','test','test','0.0'),('2018-08-30 19:59:59','2018-08-30 23:59:59','XVGETH','4h','0.000048850000000','0.000050130000000','1.853578525685416','1.902147215815966','37944.289164491616','37944.289164491616248','test','test','0.0'),('2018-08-31 03:59:59','2018-09-13 23:59:59','XVGETH','4h','0.000050320000000','0.000063800000000','1.864371567936649','2.363809738361650','37050.309378709244','37050.309378709243902','test','test','0.0'),('2018-09-17 19:59:59','2018-09-18 15:59:59','XVGETH','4h','0.000064960000000','0.000062840000000','1.975357828031093','1.910891100884758','30408.833559591956','30408.833559591956146','test','test','3.26'),('2018-09-18 19:59:59','2018-09-18 23:59:59','XVGETH','4h','0.000063780000000','0.000063760000000','1.961031888665241','1.960416952356471','30746.815438464117','30746.815438464116596','test','test','0.03'),('2018-09-19 03:59:59','2018-09-21 19:59:59','XVGETH','4h','0.000064400000000','0.000064050000000','1.960895236152181','1.950238196825267','30448.683791182946','30448.683791182946152','test','test','1.21'),('2018-09-21 23:59:59','2018-09-22 03:59:59','XVGETH','4h','0.000064400000000','0.000063430000000','1.958527005190645','1.929027452472711','30411.910018488274','30411.910018488273636','test','test','1.50'),('2018-09-25 03:59:59','2018-09-25 07:59:59','XVGETH','4h','0.000064220000000','0.000064350000000','1.951971549031104','1.955922908442098','30395.07239226259','30395.072392262591165','test','test','0.0'),('2018-09-25 11:59:59','2018-09-25 23:59:59','XVGETH','4h','0.000064930000000','0.000063740000000','1.952849628900214','1.917058914925298','30076.230231021313','30076.230231021312647','test','test','1.83'),('2018-09-26 03:59:59','2018-09-26 19:59:59','XVGETH','4h','0.000064950000000','0.000064360000000','1.944896136905788','1.927228874076313','29944.513270296968','29944.513270296967676','test','test','0.90'),('2018-09-26 23:59:59','2018-09-27 03:59:59','XVGETH','4h','0.000064660000000','0.000064360000000','1.940970078499238','1.931964649740349','30018.095862963775','30018.095862963775289','test','test','0.46'),('2018-09-27 07:59:59','2018-09-28 03:59:59','XVGETH','4h','0.000064870000000','0.000064080000000','1.938968872108374','1.915355716428312','29890.070481091014','29890.070481091013789','test','test','1.21'),('2018-09-28 07:59:59','2018-09-28 11:59:59','XVGETH','4h','0.000064950000000','0.000064440000000','1.933721504179471','1.918537547795614','29772.463497759367','29772.463497759366874','test','test','0.78'),('2018-09-28 15:59:59','2018-09-28 19:59:59','XVGETH','4h','0.000063790000000','0.000064590000000','1.930347291649725','1.954556067842229','30260.97024062902','30260.970240629019827','test','test','0.0'),('2018-09-28 23:59:59','2018-09-29 03:59:59','XVGETH','4h','0.000064230000000','0.000064400000000','1.935727019692504','1.940850382503460','30137.42829974317','30137.428299743169191','test','test','0.0'),('2018-09-29 07:59:59','2018-09-29 11:59:59','XVGETH','4h','0.000065000000000','0.000062340000000','1.936865544761605','1.857603047083669','29797.931457870855','29797.931457870854501','test','test','4.09'),('2018-09-30 15:59:59','2018-10-10 07:59:59','XVGETH','4h','0.000065880000000','0.000069190000000','1.919251656388730','2.015680359829026','29132.538803714786','29132.538803714785900','test','test','0.65'),('2018-10-10 11:59:59','2018-10-15 03:59:59','XVGETH','4h','0.000070300000000','0.000070410000000','1.940680257153240','1.943716883444660','27605.693558367573','27605.693558367573132','test','test','0.0'),('2018-10-18 11:59:59','2018-10-18 19:59:59','XVGETH','4h','0.000070740000000','0.000069540000000','1.941355062995779','1.908422831223162','27443.526477180927','27443.526477180927031','test','test','1.69'),('2018-10-19 19:59:59','2018-10-20 03:59:59','XVGETH','4h','0.000070520000000','0.000069680000000','1.934036789268530','1.910999482079285','27425.36570148228','27425.365701482278382','test','test','1.19'),('2018-10-21 03:59:59','2018-10-22 07:59:59','XVGETH','4h','0.000070470000000','0.000070430000000','1.928917387670920','1.927822500548644','27372.17805691671','27372.178056916709465','test','test','0.61'),('2018-10-22 23:59:59','2018-10-23 03:59:59','XVGETH','4h','0.000070020000000','0.000069990000000','1.928674079421525','1.927847740912775','27544.616958319413','27544.616958319413243','test','test','0.04'),('2018-10-23 07:59:59','2018-10-23 11:59:59','XVGETH','4h','0.000070100000000','0.000069920000000','1.928490448641803','1.923538547347145','27510.562748099903','27510.562748099902819','test','test','0.25'),('2018-10-23 15:59:59','2018-10-27 23:59:59','XVGETH','4h','0.000070180000000','0.000071810000000','1.927390026131879','1.972155568203623','27463.522743400958','27463.522743400957552','test','test','0.0'),('2018-10-28 03:59:59','2018-10-29 11:59:59','XVGETH','4h','0.000072490000000','0.000070660000000','1.937337924370045','1.888430097061490','26725.588693199676','26725.588693199675618','test','test','2.52'),('2018-11-27 23:59:59','2018-12-04 07:59:59','XVGETH','4h','0.000055290000000','0.000064780000000','1.926469518301477','2.257129596591964','34843.0008736024','34843.000873602402862','test','test','0.0'),('2018-12-04 11:59:59','2018-12-06 15:59:59','XVGETH','4h','0.000065120000000','0.000061400000000','1.999949535699362','1.885701804237421','30711.755769339103','30711.755769339102699','test','test','5.71'),('2018-12-07 07:59:59','2018-12-08 03:59:59','XVGETH','4h','0.000065220000000','0.000064820000000','1.974561150930042','1.962450993610630','30275.393298528707','30275.393298528706509','test','test','1.51'),('2018-12-08 07:59:59','2018-12-10 15:59:59','XVGETH','4h','0.000065140000000','0.000064720000000','1.971870004859062','1.959156074830803','30271.261972045773','30271.261972045773291','test','test','0.64'),('2018-12-11 15:59:59','2018-12-11 19:59:59','XVGETH','4h','0.000064410000000','0.000064420000000','1.969044687075004','1.969350391885915','30570.481091057354','30570.481091057354206','test','test','0.0'),('2018-12-11 23:59:59','2018-12-12 03:59:59','XVGETH','4h','0.000064350000000','0.000063720000000','1.969112621477429','1.949834595812615','30600.04073779998','30600.040737799979979','test','test','0.97'),('2018-12-12 11:59:59','2018-12-12 15:59:59','XVGETH','4h','0.000064700000000','0.000064700000000','1.964828615774137','1.964828615774137','30368.293906864565','30368.293906864564633','test','test','0.0'),('2018-12-12 19:59:59','2018-12-12 23:59:59','XVGETH','4h','0.000064710000000','0.000064800000000','1.964828615774137','1.967561339857273','30363.60092372334','30363.600923723341111','test','test','0.0'),('2018-12-13 03:59:59','2018-12-13 11:59:59','XVGETH','4h','0.000065250000000','0.000064050000000','1.965435887792612','1.929289940430909','30121.62280141934','30121.622801419340249','test','test','1.83'),('2018-12-13 19:59:59','2018-12-13 23:59:59','XVGETH','4h','0.000064960000000','0.000064020000000','1.957403455045567','1.929078959236718','30132.442349839384','30132.442349839384406','test','test','1.44'),('2018-12-14 11:59:59','2018-12-14 15:59:59','XVGETH','4h','0.000064530000000','0.000064710000000','1.951109122643601','1.956551546974546','30235.690727469406','30235.690727469405829','test','test','0.0'),('2018-12-14 19:59:59','2018-12-16 23:59:59','XVGETH','4h','0.000069210000000','0.000065710000000','1.952318550272699','1.853588382291852','28208.61942309925','28208.619423099251435','test','test','5.66'),('2018-12-17 03:59:59','2018-12-17 15:59:59','XVGETH','4h','0.000065790000000','0.000066180000000','1.930378512943622','1.941821705222813','29341.518664593736','29341.518664593735593','test','test','0.27'),('2018-12-17 19:59:59','2018-12-18 03:59:59','XVGETH','4h','0.000066490000000','0.000065350000000','1.932921444561220','1.899780664792837','29070.85944595007','29070.859445950070949','test','test','1.71'),('2018-12-18 07:59:59','2018-12-18 11:59:59','XVGETH','4h','0.000065730000000','0.000065580000000','1.925556826834913','1.921162584874998','29294.946399435765','29294.946399435764761','test','test','0.22'),('2018-12-18 15:59:59','2018-12-18 19:59:59','XVGETH','4h','0.000065880000000','0.000065930000000','1.924580328621598','1.926040999787826','29213.42332455371','29213.423324553710700','test','test','0.0'),('2018-12-18 23:59:59','2018-12-19 03:59:59','XVGETH','4h','0.000065000000000','0.000067260000000','1.924904922214093','1.991832385663383','29613.921880216825','29613.921880216825230','test','test','0.0'),('2018-12-19 07:59:59','2018-12-22 23:59:59','XVGETH','4h','0.000066600000000','0.000068960000000','1.939777691869491','2.008514559028830','29125.791169211574','29125.791169211574015','test','test','0.0'),('2019-01-10 15:59:59','2019-01-15 03:59:59','XVGETH','4h','0.000057520000000','0.000053190000000','1.955052551238233','1.807879784429096','33989.09164183299','33989.091641832987079','test','test','7.52'),('2019-01-15 07:59:59','2019-01-15 11:59:59','XVGETH','4h','0.000053120000000','0.000052800000000','1.922347491947314','1.910767085369318','36188.77055623709','36188.770556237090204','test','test','0.60'),('2019-01-15 15:59:59','2019-01-27 11:59:59','XVGETH','4h','0.000055350000000','0.000056570000000','1.919774068263315','1.962088871574630','34684.265009273986','34684.265009273985925','test','test','1.19'),('2019-01-27 15:59:59','2019-01-27 19:59:59','XVGETH','4h','0.000056160000000','0.000056220000000','1.929177357888052','1.931238444808873','34351.4486803428','34351.448680342800799','test','test','0.0'),('2019-01-27 23:59:59','2019-01-28 07:59:59','XVGETH','4h','0.000056990000000','0.000056520000000','1.929635377203790','1.913721556756593','33859.192440845574','33859.192440845574311','test','test','0.82'),('2019-01-28 11:59:59','2019-01-29 11:59:59','XVGETH','4h','0.000057450000000','0.000057470000000','1.926098972659968','1.926769503198753','33526.526939250965','33526.526939250965370','test','test','1.35'),('2019-01-29 15:59:59','2019-01-30 15:59:59','XVGETH','4h','0.000057510000000','0.000057030000000','1.926247979446365','1.910170792346134','33494.13979214684','33494.139792146837863','test','test','1.02'),('2019-01-30 19:59:59','2019-01-31 03:59:59','XVGETH','4h','0.000057030000000','0.000055970000000','1.922675271201869','1.886939065915634','33713.40121342923','33713.401213429227937','test','test','1.85'),('2019-03-01 23:59:59','2019-03-02 07:59:59','XVGETH','4h','0.000044970000000','0.000044750000000','1.914733892249372','1.905366726221023','42578.02740158711','42578.027401587110944','test','test','0.48'),('2019-03-02 11:59:59','2019-03-03 03:59:59','XVGETH','4h','0.000044600000000','0.000045260000000','1.912652299798628','1.940956123069190','42884.58071297372','42884.580712973722257','test','test','0.0'),('2019-03-03 07:59:59','2019-03-03 11:59:59','XVGETH','4h','0.000044650000000','0.000045220000000','1.918942038303197','1.943439170707068','42977.42526994843','42977.425269948427740','test','test','0.0'),('2019-03-03 15:59:59','2019-03-05 23:59:59','XVGETH','4h','0.000050860000000','0.000046020000000','1.924385845504058','1.741255143729783','37836.9218541891','37836.921854189102305','test','test','9.51'),('2019-03-08 11:59:59','2019-03-10 07:59:59','XVGETH','4h','0.000047270000000','0.000046240000000','1.883690133998663','1.842645055978383','39849.5903109512','39849.590310951200081','test','test','2.17'),('2019-03-10 11:59:59','2019-03-18 19:59:59','XVGETH','4h','0.000046700000000','0.000049580000000','1.874569005549712','1.990174117669266','40140.66393040069','40140.663930400689424','test','test','0.0'),('2019-03-18 23:59:59','2019-03-19 03:59:59','XVGETH','4h','0.000049070000000','0.000049240000000','1.900259030465169','1.906842361118910','38725.47443377152','38725.474433771516487','test','test','0.0'),('2019-03-19 11:59:59','2019-03-19 15:59:59','XVGETH','4h','0.000049390000000','0.000049680000000','1.901721992832666','1.912888208218807','38504.190986690955','38504.190986690955469','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 18:38:37
