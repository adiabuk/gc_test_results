-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-12 19:59:59','2018-02-12 23:59:59','BTCUSDT','4h','8792.760000000000218','8903.000000000000000','222.222222222222200','225.008352831698375','0.025273318300763604','0.025273318300764','test','test','0.0'),('2018-02-13 03:59:59','2018-02-13 07:59:59','BTCUSDT','4h','8760.590000000000146','8669.389999999999418','222.841362357661382','220.521526336683451','0.02543679847563479','0.025436798475635','test','test','0.0'),('2018-02-14 07:59:59','2018-02-22 11:59:59','BTCUSDT','4h','8870.170000000000073','10259.870000000000800','222.325843241888492','257.157895429530072','0.025064439942175686','0.025064439942176','test','test','2.26'),('2018-02-23 15:59:59','2018-02-23 19:59:59','BTCUSDT','4h','10292.000000000000000','10033.000000000000000','230.066299283586631','224.276640178024167','0.022353896160472855','0.022353896160473','test','test','13.4'),('2018-02-24 03:59:59','2018-02-24 07:59:59','BTCUSDT','4h','10400.000000000000000','10119.159999999999854','228.779708371239394','222.601776323260651','0.021998048881849943','0.021998048881850','test','test','3.52'),('2018-02-26 15:59:59','2018-03-06 15:59:59','BTCUSDT','4h','10260.920000000000073','10966.000000000000000','227.406834582799689','243.033114772845067','0.022162421555065207','0.022162421555065','test','test','1.38'),('2018-03-20 19:59:59','2018-03-22 11:59:59','BTCUSDT','4h','8950.000000000000000','8642.010000000000218','230.879341291698637','222.934254328075156','0.025796574445999847','0.025796574446000','test','test','0.0'),('2018-03-23 23:59:59','2018-03-24 11:59:59','BTCUSDT','4h','8898.030000000000655','8723.000000000000000','229.113766410893419','224.606950572455133','0.02574881927919926','0.025748819279199','test','test','2.87'),('2018-03-24 15:59:59','2018-03-24 23:59:59','BTCUSDT','4h','8950.000000000000000','8546.860000000000582','228.112251780129412','217.837260363074506','0.025487402433534014','0.025487402433534','test','test','2.53'),('2018-04-12 11:59:59','2018-05-01 03:59:59','BTCUSDT','4h','7690.000000000000000','8938.010000000000218','225.828920354117173','262.478692901729914','0.02936656961692031','0.029366569616920','test','test','0.0'),('2018-05-01 07:59:59','2018-05-01 15:59:59','BTCUSDT','4h','8973.709999999999127','8915.090000000000146','233.973314253586665','232.444903408847409','0.026073197624347864','0.026073197624348','test','test','15.1'),('2018-05-01 19:59:59','2018-05-07 03:59:59','BTCUSDT','4h','8979.520000000000437','9350.020000000000437','233.633667399200164','243.273522733494588','0.0260185029265707','0.026018502926571','test','test','4.81'),('2018-05-07 07:59:59','2018-05-07 11:59:59','BTCUSDT','4h','9324.250000000000000','9339.000000000000000','235.775857473487832','236.148830516653106','0.02528630801120603','0.025286308011206','test','test','0.0'),('2018-05-07 15:59:59','2018-05-07 23:59:59','BTCUSDT','4h','9365.280000000000655','9365.000000000000000','235.858740371969020','235.851688746464561','0.025184376801544534','0.025184376801545','test','test','0.28'),('2018-05-08 03:59:59','2018-05-08 07:59:59','BTCUSDT','4h','9444.000000000000000','9370.000000000000000','235.857173344079115','234.009076051887035','0.02497428773232519','0.024974287732325','test','test','0.99'),('2018-05-10 03:59:59','2018-05-10 07:59:59','BTCUSDT','4h','9344.889999999999418','9369.000000000000000','235.446485056925326','236.053941619252157','0.02519521204176029','0.025195212041760','test','test','0.0'),('2018-05-10 11:59:59','2018-05-10 19:59:59','BTCUSDT','4h','9344.000000000000000','9085.000000000000000','235.581475404109057','229.051552230985749','0.025212058583487698','0.025212058583488','test','test','0.0'),('2018-05-21 07:59:59','2018-05-21 11:59:59','BTCUSDT','4h','8540.000000000000000','8469.979999999999563','234.130381365637248','232.210731564323197','0.02741573552290834','0.027415735522908','test','test','0.0'),('2018-06-02 11:59:59','2018-06-02 15:59:59','BTCUSDT','4h','7652.279999999999745','7623.100000000000364','233.703792520900748','232.812623266017283','0.0305404131214358','0.030540413121436','test','test','0.0'),('2018-06-02 19:59:59','2018-06-02 23:59:59','BTCUSDT','4h','7665.000000000000000','7640.029999999999745','233.505754908704461','232.745071451421950','0.030463894965258247','0.030463894965258','test','test','0.54'),('2018-06-03 03:59:59','2018-06-04 07:59:59','BTCUSDT','4h','7643.100000000000364','7597.699999999999818','233.336714140419446','231.950694485832258','0.030529067281655276','0.030529067281655','test','test','0.04'),('2018-06-05 23:59:59','2018-06-06 03:59:59','BTCUSDT','4h','7625.000000000000000','7595.000000000000000','233.028709772733379','232.111875504775071','0.03056114226527651','0.030561142265277','test','test','0.35'),('2018-06-06 07:59:59','2018-06-06 11:59:59','BTCUSDT','4h','7619.149999999999636','7619.000000000000000','232.824968824298168','232.820385144317640','0.030557866536857548','0.030557866536858','test','test','0.31'),('2018-06-06 15:59:59','2018-06-06 19:59:59','BTCUSDT','4h','7650.500000000000000','7526.869999999999891','232.823950228746980','229.061578492680042','0.030432514244656816','0.030432514244657','test','test','0.41'),('2018-06-06 23:59:59','2018-06-08 07:59:59','BTCUSDT','4h','7658.840000000000146','7627.880000000000109','231.987867620732118','231.050082736658567','0.03029020943390019','0.030290209433900','test','test','1.72'),('2018-06-08 19:59:59','2018-06-08 23:59:59','BTCUSDT','4h','7641.130000000000109','7603.439999999999600','231.779470979826897','230.636214908901565','0.030333140645405442','0.030333140645405','test','test','0.17'),('2018-06-09 03:59:59','2018-06-09 11:59:59','BTCUSDT','4h','7661.149999999999636','7635.010000000000218','231.525414075176769','230.735444641876938','0.030220712827079065','0.030220712827079','test','test','0.75'),('2018-06-09 15:59:59','2018-06-09 19:59:59','BTCUSDT','4h','7610.000000000000000','7613.859999999999673','231.349865312221283','231.467212287267955','0.0304007707374798','0.030400770737480','test','test','0.0'),('2018-06-21 03:59:59','2018-06-21 07:59:59','BTCUSDT','4h','6772.409999999999854','6758.720000000000255','231.375942417787229','230.908230532107012','0.034164491284164315','0.034164491284164','test','test','0.0'),('2018-06-30 03:59:59','2018-07-01 15:59:59','BTCUSDT','4h','6366.000000000000000','6316.579999999999927','231.272006443191600','229.476614900869492','0.03632925014816079','0.036329250148161','test','test','0.0'),('2018-07-01 19:59:59','2018-07-02 07:59:59','BTCUSDT','4h','6326.920000000000073','6345.409999999999854','230.873030544897830','231.547741515603178','0.036490587923491656','0.036490587923492','test','test','0.16'),('2018-07-02 11:59:59','2018-07-06 07:59:59','BTCUSDT','4h','6343.989999999999782','6478.850000000000364','231.022966316165679','235.934032890576788','0.03641603569932577','0.036416035699326','test','test','0.0'),('2018-07-06 11:59:59','2018-07-10 07:59:59','BTCUSDT','4h','6526.560000000000400','6601.170000000000073','232.114314443812560','234.767787176868381','0.03556457221626899','0.035564572216269','test','test','2.77'),('2018-07-16 11:59:59','2018-07-31 15:59:59','BTCUSDT','4h','6635.569999999999709','7758.439999999999600','232.703975051158324','272.082101190388869','0.035069176431136787','0.035069176431137','test','test','0.51'),('2018-08-17 23:59:59','2018-08-18 03:59:59','BTCUSDT','4h','6584.489999999999782','6524.989999999999782','241.454669748765099','239.272791904003924','0.036670215878339116','0.036670215878339','test','test','0.0'),('2018-08-22 03:59:59','2018-08-22 15:59:59','BTCUSDT','4h','6726.010000000000218','6459.359999999999673','240.969808005484850','231.416655496841145','0.03582656106748055','0.035826561067481','test','test','2.98'),('2018-08-23 23:59:59','2018-08-24 03:59:59','BTCUSDT','4h','6525.010000000000218','6495.000000000000000','238.846885225786224','237.748374261722432','0.03660483052528444','0.036604830525284','test','test','1.00'),('2018-08-24 07:59:59','2018-08-24 15:59:59','BTCUSDT','4h','6534.649999999999636','6504.079999999999927','238.602771678216527','237.486554783631050','0.03651347381699349','0.036513473816993','test','test','0.60'),('2018-08-24 19:59:59','2018-09-05 11:59:59','BTCUSDT','4h','6623.560000000000400','6991.899999999999636','238.354723479419732','251.609767420504170','0.03598589330804276','0.035985893308043','test','test','1.80'),('2018-09-14 03:59:59','2018-09-14 11:59:59','BTCUSDT','4h','6542.369999999999891','6459.279999999999745','241.300288799660734','238.235705017886858','0.03688270287367739','0.036882702873677','test','test','0.0'),('2018-09-15 11:59:59','2018-09-15 15:59:59','BTCUSDT','4h','6523.510000000000218','6542.220000000000255','240.619270181488758','241.309387395242680','0.03688493927065165','0.036884939270652','test','test','0.98'),('2018-09-15 19:59:59','2018-09-15 23:59:59','BTCUSDT','4h','6530.000000000000000','6514.960000000000036','240.772629562322919','240.218078207251352','0.03687176562975849','0.036871765629758','test','test','0.0'),('2018-09-17 03:59:59','2018-09-17 07:59:59','BTCUSDT','4h','6517.159999999999854','6480.010000000000218','240.649395927862628','239.277613578078359','0.03692550066714069','0.036925500667141','test','test','0.03'),('2018-09-20 23:59:59','2018-09-24 23:59:59','BTCUSDT','4h','6492.000000000000000','6581.390000000000327','240.344555405688311','243.653920748835986','0.03702165055540486','0.037021650555405','test','test','0.18'),('2018-09-27 19:59:59','2018-09-28 19:59:59','BTCUSDT','4h','6669.359999999999673','6684.000000000000000','241.079969926387804','241.609167744427680','0.036147391942613356','0.036147391942613','test','test','1.90'),('2018-09-28 23:59:59','2018-09-29 03:59:59','BTCUSDT','4h','6634.579999999999927','6500.890000000000327','241.197569441507767','236.337321609898964','0.036354610154901705','0.036354610154902','test','test','0.0'),('2018-09-29 11:59:59','2018-09-29 15:59:59','BTCUSDT','4h','6584.960000000000036','6589.010000000000218','240.117514367816938','240.265195740701444','0.036464536514696666','0.036464536514697','test','test','1.27'),('2018-09-29 19:59:59','2018-09-30 03:59:59','BTCUSDT','4h','6588.590000000000146','6580.000000000000000','240.150332450680139','239.837231869865207','0.03644942733584578','0.036449427335846','test','test','0.0'),('2018-09-30 07:59:59','2018-09-30 23:59:59','BTCUSDT','4h','6577.750000000000000','6626.569999999999709','240.080754543832398','241.862631695872238','0.036498917493646366','0.036498917493646','test','test','0.0'),('2018-10-01 03:59:59','2018-10-01 11:59:59','BTCUSDT','4h','6644.609999999999673','6595.000000000000000','240.476727244285684','238.681279439435002','0.0361912478300887','0.036191247830089','test','test','0.97'),('2018-10-01 15:59:59','2018-10-01 19:59:59','BTCUSDT','4h','6569.920000000000073','6587.909999999999854','240.077738843207754','240.735128662534208','0.036541957716868356','0.036541957716868','test','test','0.0'),('2018-10-01 23:59:59','2018-10-02 11:59:59','BTCUSDT','4h','6611.609999999999673','6572.010000000000218','240.223825469724744','238.785013517930707','0.036333635146314554','0.036333635146315','test','test','0.35'),('2018-10-04 03:59:59','2018-10-04 23:59:59','BTCUSDT','4h','6598.510000000000218','6593.789999999999964','239.904089480437193','239.732482965883491','0.03635731240544262','0.036357312405443','test','test','0.41'),('2018-10-05 03:59:59','2018-10-06 11:59:59','BTCUSDT','4h','6579.000000000000000','6587.159999999999854','239.865954699425259','240.163462860292753','0.03645933343964512','0.036459333439645','test','test','0.10'),('2018-10-06 15:59:59','2018-10-07 07:59:59','BTCUSDT','4h','6596.079999999999927','6570.930000000000291','239.932067624062455','239.017237679497640','0.03637494809402895','0.036374948094029','test','test','0.13'),('2018-10-07 15:59:59','2018-10-07 19:59:59','BTCUSDT','4h','6582.069999999999709','6584.000000000000000','239.728772080825848','239.799065549311621','0.03642148626204611','0.036421486262046','test','test','0.16'),('2018-10-07 23:59:59','2018-10-10 03:59:59','BTCUSDT','4h','6615.260000000000218','6616.060000000000400','239.744392851600452','239.773385742927644','0.036241114159020274','0.036241114159020','test','test','0.47'),('2018-10-10 19:59:59','2018-10-11 03:59:59','BTCUSDT','4h','6635.960000000000036','6340.520000000000437','239.750835716339822','229.076873410353159','0.03612903569586613','0.036129035695866','test','test','0.70'),('2018-10-15 07:59:59','2018-10-18 23:59:59','BTCUSDT','4h','6860.250000000000000','6618.960000000000036','237.378844092787261','229.029710855492908','0.034602069034333625','0.034602069034334','test','test','7.57'),('2018-10-19 03:59:59','2018-10-19 05:59:59','BTCUSDT','4h','6613.000000000000000','6588.010000000000218','235.523481151166266','234.633456685119455','0.035615224731765656','0.035615224731766','test','test','0.0'),('2018-10-21 03:59:59','2018-10-21 23:59:59','BTCUSDT','4h','6616.619999999999891','6590.109999999999673','235.325697936489206','234.382847319059692','0.03556584750771379','0.035565847507714','test','test','0.43'),('2018-10-22 03:59:59','2018-10-22 07:59:59','BTCUSDT','4h','6597.909999999999854','6615.060000000000400','235.116175577060432','235.727314924391152','0.03563494736622058','0.035634947366221','test','test','0.11'),('2018-10-22 11:59:59','2018-10-22 15:59:59','BTCUSDT','4h','6594.000000000000000','6563.489999999999782','235.251984320911703','234.163489015841776','0.03567667338806668','0.035676673388067','test','test','0.0'),('2018-10-24 07:59:59','2018-10-24 15:59:59','BTCUSDT','4h','6610.939999999999600','6581.000000000000000','235.010096475340589','233.945769422232928','0.03554866576845964','0.035548665768460','test','test','0.71'),('2018-11-04 15:59:59','2018-11-05 11:59:59','BTCUSDT','4h','6479.989999999999782','6452.840000000000146','234.773579352427788','233.789920013537085','0.03623054655214403','0.036230546552144','test','test','0.0'),('2018-11-05 15:59:59','2018-11-05 19:59:59','BTCUSDT','4h','6473.149999999999636','6448.119999999999891','234.554988388229845','233.648024798732109','0.03623506150610288','0.036235061506103','test','test','0.31'),('2018-11-05 23:59:59','2018-11-06 03:59:59','BTCUSDT','4h','6468.989999999999782','6448.380000000000109','234.353440923897011','233.606798184081157','0.03622720717204649','0.036227207172046','test','test','0.32'),('2018-11-06 07:59:59','2018-11-08 19:59:59','BTCUSDT','4h','6464.340000000000146','6495.720000000000255','234.187520315049056','235.324342386209622','0.03622759946337121','0.036227599463371','test','test','0.24'),('2018-11-08 23:59:59','2018-11-09 03:59:59','BTCUSDT','4h','6479.840000000000146','6486.840000000000146','234.440147441973636','234.693406940988098','0.03617992843063619','0.036179928430636','test','test','0.0'),('2018-11-09 07:59:59','2018-11-09 11:59:59','BTCUSDT','4h','6499.270000000000437','6428.909999999999854','234.496427330643513','231.957808589310389','0.03608042554481403','0.036080425544814','test','test','0.19'),('2018-11-13 19:59:59','2018-11-13 23:59:59','BTCUSDT','4h','6461.300000000000182','6457.659999999999854','233.932289832569495','233.800503112406290','0.036205142901980944','0.036205142901981','test','test','0.50'),('2018-11-14 01:59:59','2018-11-14 11:59:59','BTCUSDT','4h','6472.000000000000000','6381.880000000000109','233.903003894755443','230.645998531499060','0.03614076079956048','0.036140760799560','test','test','0.22'),('2018-12-17 19:59:59','2018-12-18 11:59:59','BTCUSDT','4h','3535.610000000000127','3490.849999999999909','233.179224925142876','230.227230189397289','0.06595162501665706','0.065951625016657','test','test','0.0'),('2018-12-18 15:59:59','2018-12-25 03:59:59','BTCUSDT','4h','3512.179999999999836','3709.099999999999909','232.523226094977218','245.560278205809510','0.06620481470054987','0.066204814700550','test','test','0.60'),('2018-12-25 07:59:59','2018-12-25 11:59:59','BTCUSDT','4h','3750.389999999999873','3737.309999999999945','235.420348786273280','234.599288000028537','0.06277223136427766','0.062772231364278','test','test','1.10'),('2018-12-26 03:59:59','2018-12-26 07:59:59','BTCUSDT','4h','3795.230000000000018','3743.449999999999818','235.237890833774458','232.028436337637743','0.06198251247849918','0.061982512478499','test','test','1.52'),('2018-12-26 23:59:59','2018-12-27 03:59:59','BTCUSDT','4h','3777.739999999999782','3711.590000000000146','234.524678723521873','230.418041554854653','0.06208068282187813','0.062080682821878','test','test','0.90'),('2018-12-28 19:59:59','2018-12-29 23:59:59','BTCUSDT','4h','3819.539999999999964','3695.320000000000164','233.612092686040228','226.014503930991225','0.06116236318667699','0.061162363186677','test','test','2.82'),('2018-12-30 11:59:59','2018-12-30 15:59:59','BTCUSDT','4h','3785.929999999999836','3768.000000000000000','231.923739629362700','230.825358874421539','0.06125938399002694','0.061259383990027','test','test','2.39'),('2018-12-30 19:59:59','2018-12-30 23:59:59','BTCUSDT','4h','3780.119999999999891','3801.909999999999854','231.679655017153550','233.015141637372949','0.06128896834416726','0.061288968344167','test','test','0.32'),('2018-12-31 03:59:59','2018-12-31 07:59:59','BTCUSDT','4h','3744.579999999999927','3754.449999999999818','231.976429821646747','232.587875527797905','0.06194991956952362','0.061949919569524','test','test','0.0'),('2019-01-01 23:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3797.139999999999873','3756.000000000000000','232.112306645235890','229.597492786546184','0.06112819296766406','0.061128192967664','test','test','1.12'),('2019-01-03 23:59:59','2019-01-04 03:59:59','BTCUSDT','4h','3766.780000000000200','3780.039999999999964','231.553459121082625','232.368584737111547','0.06147252006251563','0.061472520062516','test','test','0.28'),('2019-01-04 07:59:59','2019-01-04 11:59:59','BTCUSDT','4h','3783.280000000000200','3757.550000000000182','231.734598146866830','230.158576490970631','0.06125229910206668','0.061252299102067','test','test','0.08'),('2019-01-04 23:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3792.010000000000218','3770.960000000000036','231.384371112223249','230.099922755833802','0.06101892429403489','0.061018924294035','test','test','0.90'),('2019-01-06 03:59:59','2019-01-06 07:59:59','BTCUSDT','4h','3771.150000000000091','3767.940000000000055','231.098938144136696','230.902226904476976','0.061280760018598224','0.061280760018598','test','test','0.00'),('2019-01-06 11:59:59','2019-01-10 07:59:59','BTCUSDT','4h','3814.239999999999782','3777.019999999999982','231.055224535323418','228.800548516718209','0.060577002111907856','0.060577002111908','test','test','1.21'),('2019-01-19 11:59:59','2019-01-20 11:59:59','BTCUSDT','4h','3695.380000000000109','3580.000000000000000','230.554185420077829','223.355645103853618','0.06238984500107643','0.062389845001076','test','test','0.0'),('2019-01-26 07:59:59','2019-01-26 11:59:59','BTCUSDT','4h','3620.579999999999927','3589.929999999999836','228.954509794250185','227.016296655693992','0.06323697026284468','0.063236970262845','test','test','1.12');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 18:33:11
