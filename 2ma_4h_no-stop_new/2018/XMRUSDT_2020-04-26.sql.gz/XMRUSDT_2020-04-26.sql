-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-09-03 15:59:59','2019-09-04 03:59:59','XMRUSDT','4h','74.879999999999995','73.980000000000004','222.222222222222200','219.551282051282072','2.967711301044634','2.967711301044634','test','test','0.0'),('2019-09-05 03:59:59','2019-09-07 03:59:59','XMRUSDT','4h','74.329999999999998','73.959999999999994','221.628679962013280','220.525456343205974','2.9816854562358843','2.981685456235884','test','test','0.47'),('2019-09-07 07:59:59','2019-09-07 11:59:59','XMRUSDT','4h','74.700000000000003','75.939999999999998','221.383519157833888','225.058426303158001','2.96363479461625','2.963634794616250','test','test','0.99'),('2019-09-07 15:59:59','2019-09-09 03:59:59','XMRUSDT','4h','77.569999999999993','76.049999999999997','222.200165190128132','217.846107550718642','2.86451160487467','2.864511604874670','test','test','2.10'),('2019-09-09 07:59:59','2019-09-09 11:59:59','XMRUSDT','4h','75.530000000000001','76.560000000000002','221.232596825814909','224.249538103857930','2.9290692019835154','2.929069201983515','test','test','0.0'),('2019-09-09 15:59:59','2019-09-09 19:59:59','XMRUSDT','4h','75.709999999999994','75.140000000000001','221.903028220935568','220.232380669939261','2.9309606157830617','2.930960615783062','test','test','0.0'),('2019-09-12 23:59:59','2019-09-13 03:59:59','XMRUSDT','4h','74.879999999999995','73.879999999999995','221.531773209603102','218.573282648577418','2.9584905610256826','2.958490561025683','test','test','0.0'),('2019-09-13 23:59:59','2019-09-14 07:59:59','XMRUSDT','4h','76.790000000000006','75.349999999999994','220.874330862708490','216.732397844837635','2.876342373521402','2.876342373521402','test','test','3.78'),('2019-09-14 11:59:59','2019-09-14 15:59:59','XMRUSDT','4h','74.620000000000005','74.739999999999995','219.953901303181624','220.307619718571345','2.947653461581099','2.947653461581099','test','test','0.0'),('2019-09-14 19:59:59','2019-09-15 03:59:59','XMRUSDT','4h','75.430000000000007','74.280000000000001','220.032505395490460','216.677906678735638','2.9170423623954718','2.917042362395472','test','test','0.91'),('2019-09-15 07:59:59','2019-09-15 11:59:59','XMRUSDT','4h','75.129999999999995','74.930000000000007','219.287039013989414','218.703285416188322','2.9187679890055827','2.918767989005583','test','test','1.13'),('2019-09-15 15:59:59','2019-09-16 11:59:59','XMRUSDT','4h','74.810000000000002','73.450000000000003','219.157315992255803','215.173170159486546','2.9295189946832747','2.929518994683275','test','test','0.0'),('2019-09-16 23:59:59','2019-09-17 03:59:59','XMRUSDT','4h','75.370000000000005','74.989999999999995','218.271950251640419','217.171468082400338','2.896005708526475','2.896005708526475','test','test','2.54'),('2019-09-18 07:59:59','2019-09-19 03:59:59','XMRUSDT','4h','75.099999999999994','74.310000000000002','218.027398658475960','215.733901388966046','2.9031611006454856','2.903161100645486','test','test','0.22'),('2019-09-19 19:59:59','2019-09-20 03:59:59','XMRUSDT','4h','76.040000000000006','75.840000000000003','217.517732598584871','216.945618625416586','2.860569865841463','2.860569865841463','test','test','2.27'),('2019-09-20 07:59:59','2019-09-20 15:59:59','XMRUSDT','4h','76.519999999999996','74.200000000000003','217.390596160103058','210.799558743853225','2.840964403555973','2.840964403555973','test','test','1.80'),('2019-10-17 03:59:59','2019-10-18 07:59:59','XMRUSDT','4h','57.039999999999999','58.079999999999998','215.925921178714162','219.862859433024511','3.7855175522214966','3.785517552221497','test','test','0.0'),('2019-10-18 11:59:59','2019-10-18 23:59:59','XMRUSDT','4h','57.530000000000001','55.229999999999997','216.800796346338728','208.133286671445973','3.7684824673446675','3.768482467344668','test','test','2.43'),('2019-10-20 15:59:59','2019-10-23 11:59:59','XMRUSDT','4h','56.219999999999999','55.939999999999998','214.874683085251405','213.804513905886921','3.822032783444529','3.822032783444529','test','test','1.76'),('2019-10-25 15:59:59','2019-10-26 19:59:59','XMRUSDT','4h','57.079999999999998','55.590000000000003','214.636867712059285','209.034048285097697','3.760281494605103','3.760281494605103','test','test','1.99'),('2019-10-26 23:59:59','2019-10-27 03:59:59','XMRUSDT','4h','56.770000000000003','55.560000000000002','213.391796728290075','208.843548110336371','3.758883155333628','3.758883155333628','test','test','2.07'),('2019-10-27 07:59:59','2019-10-30 11:59:59','XMRUSDT','4h','56.700000000000003','57.759999999999998','212.381074813189230','216.351514659784954','3.7456979684865823','3.745697968486582','test','test','2.01'),('2019-10-30 15:59:59','2019-10-31 07:59:59','XMRUSDT','4h','58.729999999999997','58.039999999999999','213.263394779099400','210.757831312428578','3.6312514009722356','3.631251400972236','test','test','1.65'),('2019-10-31 11:59:59','2019-11-08 15:59:59','XMRUSDT','4h','57.880000000000003','60.600000000000001','212.706602897617017','222.702490248714440','3.674958584962284','3.674958584962284','test','test','0.0'),('2019-11-09 03:59:59','2019-11-09 15:59:59','XMRUSDT','4h','61.630000000000003','61.109999999999999','214.927911197860880','213.114467845225988','3.4873910627593845','3.487391062759384','test','test','5.82'),('2019-11-09 23:59:59','2019-11-11 07:59:59','XMRUSDT','4h','61.829999999999998','62.100000000000001','214.524923786164237','215.461713846365853','3.4695928155614464','3.469592815561446','test','test','1.16'),('2019-11-11 11:59:59','2019-11-11 15:59:59','XMRUSDT','4h','61.789999999999999','62.579999999999998','214.733099355097920','217.478513637190929','3.475207952016474','3.475207952016474','test','test','0.0'),('2019-11-11 19:59:59','2019-11-11 23:59:59','XMRUSDT','4h','62.130000000000003','61.719999999999999','215.343191417785278','213.922127382998667','3.4660098409429465','3.466009840942947','test','test','0.04'),('2019-11-12 03:59:59','2019-11-12 15:59:59','XMRUSDT','4h','62.140000000000001','63.000000000000000','215.027399410054869','218.003317715375886','3.4603701224662835','3.460370122466284','test','test','0.67'),('2019-11-12 19:59:59','2019-11-12 23:59:59','XMRUSDT','4h','63.210000000000001','62.259999999999998','215.688714589015149','212.447071196204433','3.4122562029586323','3.412256202958632','test','test','0.33'),('2019-11-13 01:59:59','2019-11-13 07:59:59','XMRUSDT','4h','61.829999999999998','63.229999999999997','214.968349390612758','219.835819698664778','3.47676450575146','3.476764505751460','test','test','0.0'),('2019-11-13 11:59:59','2019-11-15 15:59:59','XMRUSDT','4h','63.399999999999999','62.649999999999999','216.050009459068747','213.494212817202794','3.4077288558212735','3.407728855821273','test','test','1.79'),('2019-11-27 19:59:59','2019-11-28 15:59:59','XMRUSDT','4h','56.829999999999998','55.070000000000000','215.482054649765217','208.808670588818757','3.7916954891741197','3.791695489174120','test','test','0.0'),('2019-11-28 19:59:59','2019-11-28 23:59:59','XMRUSDT','4h','55.329999999999998','53.810000000000002','213.999080413999337','208.120197308463844','3.8676862536417738','3.867686253641774','test','test','0.46'),('2019-11-29 07:59:59','2019-11-29 15:59:59','XMRUSDT','4h','55.590000000000003','55.969999999999999','212.692661946102561','214.146578325658595','3.826095735673728','3.826095735673728','test','test','3.20'),('2019-11-29 19:59:59','2019-11-30 15:59:59','XMRUSDT','4h','55.689999999999998','54.270000000000003','213.015754474892788','207.584216113349498','3.8250270151713557','3.825027015171356','test','test','0.0'),('2019-12-03 03:59:59','2019-12-03 07:59:59','XMRUSDT','4h','54.710000000000001','54.850000000000001','211.808745950105390','212.350753342410542','3.871481373608214','3.871481373608214','test','test','0.80'),('2019-12-03 11:59:59','2019-12-03 15:59:59','XMRUSDT','4h','54.930000000000000','54.409999999999997','211.929192037284309','209.922944452005055','3.858168433229279','3.858168433229279','test','test','0.14'),('2019-12-04 15:59:59','2019-12-04 23:59:59','XMRUSDT','4h','54.700000000000003','52.609999999999999','211.483359240555586','203.402916446903646','3.8662405711253305','3.866240571125330','test','test','0.54'),('2019-12-06 07:59:59','2019-12-06 11:59:59','XMRUSDT','4h','54.229999999999997','54.030000000000001','209.687705286410733','208.914377957307266','3.8666366455174397','3.866636645517440','test','test','2.98'),('2019-12-06 23:59:59','2019-12-07 03:59:59','XMRUSDT','4h','54.030000000000001','53.880000000000003','209.515854768832156','208.934189430773216','3.8777689203929695','3.877768920392969','test','test','0.0'),('2019-12-07 07:59:59','2019-12-07 11:59:59','XMRUSDT','4h','53.930000000000000','54.729999999999997','209.386595804819052','212.492645807486497','3.8825625033343045','3.882562503334305','test','test','0.09'),('2019-12-07 15:59:59','2019-12-07 19:59:59','XMRUSDT','4h','53.850000000000001','54.479999999999997','210.076829138745182','212.534552488000685','3.901148173421452','3.901148173421452','test','test','0.0'),('2019-12-07 23:59:59','2019-12-08 03:59:59','XMRUSDT','4h','54.380000000000003','53.609999999999999','210.622989883024161','207.640648908218537','3.8731700971501315','3.873170097150131','test','test','0.0'),('2019-12-08 07:59:59','2019-12-08 11:59:59','XMRUSDT','4h','54.149999999999999','54.259999999999998','209.960247444178464','210.386759488848071','3.877382224269224','3.877382224269224','test','test','0.99'),('2019-12-08 15:59:59','2019-12-08 19:59:59','XMRUSDT','4h','54.270000000000003','53.789999999999999','210.055027898549497','208.197161427362744','3.870555148305684','3.870555148305684','test','test','0.01'),('2019-12-09 23:59:59','2019-12-10 03:59:59','XMRUSDT','4h','54.409999999999997','53.590000000000003','209.642168682730215','206.482702071448529','3.853008062538692','3.853008062538692','test','test','1.13'),('2019-12-10 07:59:59','2019-12-10 11:59:59','XMRUSDT','4h','54.060000000000002','53.729999999999997','208.940064991334310','207.664626192830042','3.8649660560735164','3.864966056073516','test','test','0.86'),('2020-01-03 03:59:59','2020-01-20 15:59:59','XMRUSDT','4h','47.229999999999997','65.030000000000001','208.656634147222235','287.294959106370186','4.417883424671231','4.417883424671231','test','test','0.0'),('2020-01-20 19:59:59','2020-01-23 07:59:59','XMRUSDT','4h','65.349999999999994','63.149999999999999','226.131817471477319','218.519116653768833','3.4603185535038614','3.460318553503861','test','test','17.7'),('2020-01-26 11:59:59','2020-02-16 15:59:59','XMRUSDT','4h','63.490000000000002','85.250000000000000','224.440106178653224','301.362719353129421','3.5350465613270314','3.535046561327031','test','test','14.3');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-26 19:05:37
