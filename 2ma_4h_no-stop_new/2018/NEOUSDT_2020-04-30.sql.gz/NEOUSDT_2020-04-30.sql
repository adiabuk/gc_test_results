-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-21 07:59:59','2018-05-21 11:59:59','NEOUSDT','4h','65.659999999999997','63.567999999999998','222.222222222222200','215.141977188885505','3.38443835245541','3.384438352455410','test','test','3.18'),('2018-06-01 23:59:59','2018-06-04 07:59:59','NEOUSDT','4h','55.500000000000000','54.704999999999998','220.648834437036271','217.488188970776008','3.975654674541194','3.975654674541194','test','test','1.43'),('2018-07-02 11:59:59','2018-07-09 19:59:59','NEOUSDT','4h','32.973999999999997','37.619999999999997','219.946468777867352','250.936682095692646','6.6702998962172435','6.670299896217244','test','test','0.0'),('2018-07-09 23:59:59','2018-07-10 03:59:59','NEOUSDT','4h','36.435000000000002','34.884999999999998','226.833182848495198','217.183356214347583','6.225694602675866','6.225694602675866','test','test','4.25'),('2018-07-16 11:59:59','2018-07-19 19:59:59','NEOUSDT','4h','35.218000000000004','35.810000000000002','224.688776929795722','228.465702250439648','6.379941420006692','6.379941420006692','test','test','0.0'),('2018-07-19 23:59:59','2018-07-20 03:59:59','NEOUSDT','4h','35.984000000000002','35.359999999999999','225.528093667716604','221.617201870010518','6.267454804016134','6.267454804016134','test','test','1.73'),('2018-07-25 07:59:59','2018-07-25 11:59:59','NEOUSDT','4h','34.871000000000002','33.997000000000000','224.659006601559668','219.028196708818882','6.442574247987142','6.442574247987142','test','test','2.50'),('2018-07-26 07:59:59','2018-07-26 15:59:59','NEOUSDT','4h','35.174999999999997','34.423000000000002','223.407715514283950','218.631522136409302','6.351320981216317','6.351320981216317','test','test','2.13'),('2018-07-26 19:59:59','2018-07-26 23:59:59','NEOUSDT','4h','34.765000000000001','33.037999999999997','222.346339208089574','211.300973817254771','6.395695072863212','6.395695072863212','test','test','4.96'),('2018-08-17 23:59:59','2018-08-18 03:59:59','NEOUSDT','4h','20.670000000000002','19.859000000000002','219.891813565681815','211.264224750888985','10.638210622432597','10.638210622432597','test','test','3.92'),('2018-08-27 19:59:59','2018-08-30 11:59:59','NEOUSDT','4h','19.946999999999999','18.701000000000001','217.974571606839021','204.358673666190242','10.92768695076147','10.927686950761469','test','test','6.24'),('2018-08-30 15:59:59','2018-08-30 19:59:59','NEOUSDT','4h','19.004999999999999','18.536999999999999','214.948816508917048','209.655680695911371','11.310119258559173','11.310119258559173','test','test','2.46'),('2018-08-30 23:59:59','2018-08-31 03:59:59','NEOUSDT','4h','19.559999999999999','19.356999999999999','213.772564106026920','211.553963364026771','10.929067694582153','10.929067694582153','test','test','1.03'),('2018-08-31 07:59:59','2018-09-05 11:59:59','NEOUSDT','4h','19.436000000000000','21.524999999999999','213.279541718915766','236.203032285432272','10.973427748452139','10.973427748452139','test','test','0.90'),('2018-09-05 15:59:59','2018-09-05 19:59:59','NEOUSDT','4h','21.532000000000000','20.506000000000000','218.373650733697218','207.968144247872715','10.14181918696346','10.141819186963460','test','test','4.76'),('2018-09-20 23:59:59','2018-09-21 03:59:59','NEOUSDT','4h','18.186000000000000','18.265000000000001','216.061315959069560','216.999886505685993','11.880639830587791','11.880639830587791','test','test','0.0'),('2018-09-21 07:59:59','2018-09-24 07:59:59','NEOUSDT','4h','19.149999999999999','18.841999999999999','216.269887191650952','212.791499449874010','11.29346669408099','11.293466694080990','test','test','2.78'),('2018-09-24 11:59:59','2018-09-24 15:59:59','NEOUSDT','4h','18.315000000000001','18.655000000000001','215.496912137922777','219.497400815339859','11.766143168873752','11.766143168873752','test','test','0.0'),('2018-09-24 19:59:59','2018-09-24 23:59:59','NEOUSDT','4h','18.811000000000000','18.448000000000000','216.385909621793218','212.210263181268488','11.503158238360173','11.503158238360173','test','test','1.92'),('2018-09-26 15:59:59','2018-09-26 19:59:59','NEOUSDT','4h','18.559999999999999','18.135000000000002','215.457988190565516','210.524278870469089','11.608727811991677','11.608727811991677','test','test','2.28'),('2018-09-27 15:59:59','2018-09-29 03:59:59','NEOUSDT','4h','18.472999999999999','18.638999999999999','214.361608341655170','216.287880575981717','11.604049604376938','11.604049604376938','test','test','0.0'),('2018-09-29 07:59:59','2018-09-30 23:59:59','NEOUSDT','4h','18.890000000000001','18.936000000000000','214.789668838172219','215.312714087857529','11.37054890620287','11.370548906202870','test','test','0.34'),('2018-10-01 03:59:59','2018-10-01 11:59:59','NEOUSDT','4h','18.998999999999999','18.765999999999998','214.905901115880056','212.270337404105732','11.311432239374708','11.311432239374708','test','test','1.22'),('2018-10-01 23:59:59','2018-10-02 03:59:59','NEOUSDT','4h','18.713000000000001','18.690999999999999','214.320220291041295','214.068254019123202','11.45301235991243','11.453012359912430','test','test','0.11'),('2018-10-02 07:59:59','2018-10-02 11:59:59','NEOUSDT','4h','18.670999999999999','18.559000000000001','214.264227786170636','212.978940789649272','11.475776754655381','11.475776754655381','test','test','0.59'),('2018-10-08 11:59:59','2018-10-09 11:59:59','NEOUSDT','4h','18.408000000000001','18.297000000000001','213.978608453610292','212.688320234447389','11.624218190656794','11.624218190656794','test','test','0.60'),('2018-10-17 15:59:59','2018-10-18 19:59:59','NEOUSDT','4h','17.190999999999999','16.905000000000001','213.691877738240777','210.136768842124411','12.430450685721645','12.430450685721645','test','test','1.66'),('2018-10-20 11:59:59','2018-10-20 15:59:59','NEOUSDT','4h','17.088999999999999','16.885000000000002','212.901853539103769','210.360336883829802','12.458414976833271','12.458414976833271','test','test','1.19'),('2018-10-21 15:59:59','2018-10-21 19:59:59','NEOUSDT','4h','17.120000000000001','16.981000000000002','212.337072060154043','210.613073636301152','12.402866358653856','12.402866358653856','test','test','0.81'),('2018-10-22 15:59:59','2018-10-23 03:59:59','NEOUSDT','4h','17.143999999999998','16.884000000000000','211.953961299297845','208.739540514310846','12.363156865334686','12.363156865334686','test','test','1.51'),('2018-10-24 19:59:59','2018-10-24 23:59:59','NEOUSDT','4h','16.986000000000001','16.934000000000001','211.239645569300706','210.592968213266118','12.436103000665295','12.436103000665295','test','test','0.30'),('2018-11-02 15:59:59','2018-11-02 19:59:59','NEOUSDT','4h','16.138000000000002','16.180000000000000','211.095939490181962','211.645327856682599','13.080675392872843','13.080675392872843','test','test','0.0'),('2018-11-02 23:59:59','2018-11-03 11:59:59','NEOUSDT','4h','16.295999999999999','16.004999999999999','211.218025793848739','207.446275333244273','12.9613417890187','12.961341789018700','test','test','1.78'),('2018-11-04 07:59:59','2018-11-04 11:59:59','NEOUSDT','4h','16.152000000000001','16.559999999999999','210.379859024825492','215.694060515794320','13.025003654335405','13.025003654335405','test','test','0.0'),('2018-11-04 15:59:59','2018-11-08 19:59:59','NEOUSDT','4h','16.651000000000000','16.460000000000001','211.560792689485282','209.134024843488561','12.70559081673685','12.705590816736850','test','test','1.81'),('2018-11-08 23:59:59','2018-11-09 03:59:59','NEOUSDT','4h','16.408999999999999','16.405999999999999','211.021510945930430','210.982930622154583','12.860107925280666','12.860107925280666','test','test','0.01'),('2018-11-09 07:59:59','2018-11-09 11:59:59','NEOUSDT','4h','16.420000000000002','16.093000000000000','211.012937540646931','206.810670148698591','12.850970617578984','12.850970617578984','test','test','1.99'),('2018-12-17 19:59:59','2018-12-27 19:59:59','NEOUSDT','4h','6.592000000000000','6.814000000000000','210.079100342436163','217.153972957123813','31.868795561655972','31.868795561655972','test','test','3.65'),('2018-12-28 15:59:59','2018-12-31 19:59:59','NEOUSDT','4h','7.372000000000000','7.418000000000000','211.651294256811184','212.971961583969829','28.71015928605686','28.710159286056861','test','test','0.0'),('2018-12-31 23:59:59','2019-01-01 03:59:59','NEOUSDT','4h','7.409000000000000','7.373000000000000','211.944775885068680','210.914945687759683','28.606394369694787','28.606394369694787','test','test','0.48'),('2019-01-01 07:59:59','2019-01-01 15:59:59','NEOUSDT','4h','7.445000000000000','7.361000000000000','211.715924730111141','209.327188977615577','28.43733038685173','28.437330386851730','test','test','1.12'),('2019-01-01 19:59:59','2019-01-03 19:59:59','NEOUSDT','4h','7.460000000000000','7.480000000000000','211.185094562889873','211.751274441074571','28.308993909234566','28.308993909234566','test','test','0.0'),('2019-01-03 23:59:59','2019-01-04 03:59:59','NEOUSDT','4h','7.522000000000000','7.600000000000000','211.310912313597584','213.502118264203858','28.09238398213209','28.092383982132091','test','test','0.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','NEOUSDT','4h','7.581000000000000','7.445000000000000','211.797846969287889','207.998281319924587','27.937982715906593','27.937982715906593','test','test','1.79'),('2019-01-05 03:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.579000000000000','8.327999999999999','210.953499047207174','231.801126806325527','27.83394894408328','27.833948944083279','test','test','0.42'),('2019-01-10 11:59:59','2019-01-10 15:59:59','NEOUSDT','4h','8.145000000000000','7.926000000000000','215.586305215900097','209.789693694441297','26.468545760085956','26.468545760085956','test','test','2.68'),('2019-01-19 11:59:59','2019-01-20 11:59:59','NEOUSDT','4h','7.900000000000000','7.522000000000000','214.298169322242614','204.044408815431495','27.126350547119316','27.126350547119316','test','test','4.78'),('2019-01-24 23:59:59','2019-01-25 07:59:59','NEOUSDT','4h','7.642000000000000','7.579000000000000','212.019555876284585','210.271684635744663','27.743987945077805','27.743987945077805','test','test','0.82'),('2019-02-02 23:59:59','2019-02-03 03:59:59','NEOUSDT','4h','7.237000000000000','7.119000000000000','211.631140045053485','208.180473397918433','29.242937687585115','29.242937687585115','test','test','1.63'),('2019-02-08 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','7.413000000000000','9.410000000000000','210.864325234579042','267.669405160850999','28.445207774798195','28.445207774798195','test','test','0.0'),('2019-02-24 23:59:59','2019-02-27 23:59:59','NEOUSDT','4h','8.907999999999999','8.856999999999999','223.487676329306140','222.208166732000933','25.088423476572313','25.088423476572313','test','test','0.71'),('2019-02-28 03:59:59','2019-02-28 11:59:59','NEOUSDT','4h','8.891999999999999','8.920000000000000','223.203340863238310','223.906185391372702','25.101590290512632','25.101590290512632','test','test','0.0'),('2019-02-28 15:59:59','2019-02-28 19:59:59','NEOUSDT','4h','8.945000000000000','8.864000000000001','223.359528536157057','221.336932470038732','24.970321803930357','24.970321803930357','test','test','0.90'),('2019-03-01 07:59:59','2019-03-01 11:59:59','NEOUSDT','4h','8.869999999999999','8.851000000000001','222.910062743686325','222.432577829128292','25.130784976740287','25.130784976740287','test','test','0.21'),('2019-03-01 19:59:59','2019-03-02 07:59:59','NEOUSDT','4h','8.971000000000000','8.746000000000000','222.803954984895654','217.215849994192098','24.836022180904653','24.836022180904653','test','test','2.50'),('2019-03-05 19:59:59','2019-03-05 23:59:59','NEOUSDT','4h','8.754000000000000','8.739000000000001','221.562153875850413','221.182506593677971','25.30981881149765','25.309818811497649','test','test','0.17'),('2019-03-06 11:59:59','2019-03-06 15:59:59','NEOUSDT','4h','8.736000000000001','8.689000000000000','221.477787813145397','220.286229201971167','25.35231087604686','25.352310876046861','test','test','0.53'),('2019-03-06 23:59:59','2019-03-07 03:59:59','NEOUSDT','4h','8.705000000000000','8.763999999999999','221.212997010662292','222.712315428080899','25.412176566417266','25.412176566417266','test','test','0.0'),('2019-03-07 07:59:59','2019-03-07 11:59:59','NEOUSDT','4h','8.779999999999999','8.669000000000000','221.546178881199722','218.745310332701678','25.23304998646922','25.233049986469219','test','test','1.26'),('2019-03-07 15:59:59','2019-03-08 23:59:59','NEOUSDT','4h','8.755000000000001','8.765000000000001','220.923763648200179','221.176103755165599','25.234010696539137','25.234010696539137','test','test','0.0'),('2019-03-09 03:59:59','2019-03-10 07:59:59','NEOUSDT','4h','8.848000000000001','8.755000000000001','220.979839227525844','218.657153304361316','24.975117453382214','24.975117453382214','test','test','1.05'),('2019-03-11 03:59:59','2019-03-11 07:59:59','NEOUSDT','4h','8.821000000000000','8.622000000000000','220.463686800155898','215.490070013710948','24.993049178115395','24.993049178115395','test','test','2.25'),('2019-03-12 15:59:59','2019-03-12 19:59:59','NEOUSDT','4h','8.789999999999999','8.811000000000000','219.358438625390392','219.882503154529559','24.95545376853133','24.955453768531331','test','test','0.0'),('2019-03-12 23:59:59','2019-03-13 11:59:59','NEOUSDT','4h','8.826000000000001','8.784000000000001','219.474897409643518','218.430489332235283','24.86685898591021','24.866858985910209','test','test','0.47'),('2019-03-13 15:59:59','2019-03-14 07:59:59','NEOUSDT','4h','8.981999999999999','8.779000000000000','219.242806725775040','214.287753311687737','24.409130118656766','24.409130118656766','test','test','2.26'),('2019-03-14 15:59:59','2019-03-18 07:59:59','NEOUSDT','4h','9.090999999999999','9.053000000000001','218.141683744866754','217.229860625044438','23.99534525848276','23.995345258482761','test','test','0.41'),('2019-03-18 11:59:59','2019-03-19 07:59:59','NEOUSDT','4h','9.086000000000000','9.016999999999999','217.939056384906252','216.284005219315361','23.986248776679094','23.986248776679094','test','test','0.75'),('2019-03-19 11:59:59','2019-03-19 15:59:59','NEOUSDT','4h','9.063000000000001','9.125000000000000','217.571267236997159','219.059672684276620','24.006539472249493','24.006539472249493','test','test','0.0'),('2019-03-19 19:59:59','2019-03-20 03:59:59','NEOUSDT','4h','9.143000000000001','9.029999999999999','217.902024003059267','215.208933254689356','23.832661489998824','23.832661489998824','test','test','1.23'),('2019-03-20 07:59:59','2019-03-20 11:59:59','NEOUSDT','4h','9.101000000000001','9.084000000000000','217.303559392310376','216.897652293126811','23.876888187266275','23.876888187266275','test','test','0.18'),('2019-03-20 15:59:59','2019-03-21 15:59:59','NEOUSDT','4h','9.183999999999999','8.920000000000000','217.213357814714044','210.969419828751029','23.65128024985998','23.651280249859980','test','test','2.87'),('2019-03-22 11:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.143000000000001','9.132000000000000','215.825816040055571','215.566154662341376','23.605579792196824','23.605579792196824','test','test','0.12'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NEOUSDT','4h','9.148000000000000','9.111000000000001','215.768113511674642','214.895417818634428','23.586370082168195','23.586370082168195','test','test','0.40'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NEOUSDT','4h','9.124000000000001','9.085000000000001','215.574181135443467','214.652722009590519','23.627157073152503','23.627157073152503','test','test','0.42'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOUSDT','4h','9.268000000000001','8.932000000000000','215.369412440809498','207.561457911233305','23.2379599094529','23.237959909452901','test','test','3.62'),('2019-03-27 07:59:59','2019-04-09 07:59:59','NEOUSDT','4h','9.125999999999999','12.166000000000000','213.634311434237020','284.798929751142623','23.40941392003474','23.409413920034741','test','test','0.0'),('2019-04-09 11:59:59','2019-04-11 03:59:59','NEOUSDT','4h','12.317000000000000','11.432000000000000','229.448671060216043','212.962345340617816','18.628616632314365','18.628616632314365','test','test','7.18'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOUSDT','4h','10.061999999999999','9.853000000000000','225.785043122527554','221.095212670071959','22.43938015528996','22.439380155289960','test','test','2.07'),('2019-05-03 11:59:59','2019-05-03 19:59:59','NEOUSDT','4h','10.016000000000000','9.948000000000000','224.742858577537390','223.217048435437505','22.438384442645507','22.438384442645507','test','test','0.67'),('2019-05-03 23:59:59','2019-05-04 07:59:59','NEOUSDT','4h','9.929000000000000','9.747999999999999','224.403789657070774','220.313036718413287','22.60084496495828','22.600844964958281','test','test','1.82');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-30 17:28:27
