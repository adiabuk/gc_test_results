-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-14 11:59:59','2018-06-14 15:59:59','ICXBTC','4h','0.000330200000000','0.000322200000000','0.001467500000000','0.001431945790430','4.4442761962447','4.444276196244700','test'),('2018-06-14 19:59:59','2018-06-15 11:59:59','ICXBTC','4h','0.000342900000000','0.000326700000000','0.001467500000000','0.001398169291339','4.279673374161564','4.279673374161564','test'),('2018-07-02 19:59:59','2018-07-03 03:59:59','ICXBTC','4h','0.000269900000000','0.000270700000000','0.001467500000000','0.001471849759170','5.437198962578733','5.437198962578733','test'),('2018-07-04 15:59:59','2018-07-04 19:59:59','ICXBTC','4h','0.000268200000000','0.000264000000000','0.001467500000000','0.001444519015660','5.471662938105891','5.471662938105891','test'),('2018-07-05 07:59:59','2018-07-05 11:59:59','ICXBTC','4h','0.000266600000000','0.000262800000000','0.001467500000000','0.001446582895724','5.504501125281321','5.504501125281321','test'),('2018-07-08 19:59:59','2018-07-08 23:59:59','ICXBTC','4h','0.000264400000000','0.000257200000000','0.001467500000000','0.001427537821483','5.550302571860818','5.550302571860818','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','ICXBTC','4h','0.000112100000000','0.000109400000000','0.001467500000000','0.001432154326494','13.09099018733274','13.090990187332739','test'),('2018-08-20 03:59:59','2018-08-20 07:59:59','ICXBTC','4h','0.000105300000000','0.000103300000000','0.001467500000000','0.001439627255461','13.936372269705604','13.936372269705604','test'),('2018-08-24 07:59:59','2018-08-24 15:59:59','ICXBTC','4h','0.000102900000000','0.000098100000000','0.001467500000000','0.001399045189504','14.26141885325559','14.261418853255590','test'),('2018-08-24 19:59:59','2018-08-24 23:59:59','ICXBTC','4h','0.000101400000000','0.000101500000000','0.001467500000000','0.001468947238659','14.472386587771204','14.472386587771204','test'),('2018-09-21 07:59:59','2018-09-21 15:59:59','ICXBTC','4h','0.000099800000000','0.000098300000000','0.001467500000000','0.001445443386774','14.70440881763527','14.704408817635271','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','ICXBTC','4h','0.000100300000000','0.000101200000000','0.001467500000000','0.001480667996012','14.631106679960121','14.631106679960121','test'),('2018-09-27 15:59:59','2018-09-28 03:59:59','ICXBTC','4h','0.000100700000000','0.000100900000000','0.001467500000000','0.001470414597815','14.572989076464749','14.572989076464749','test'),('2018-09-29 15:59:59','2018-09-29 19:59:59','ICXBTC','4h','0.000099800000000','0.000099300000000','0.001467500000000','0.001460147795591','14.70440881763527','14.704408817635271','test'),('2018-10-01 07:59:59','2018-10-01 23:59:59','ICXBTC','4h','0.000100400000000','0.000101100000000','0.001467500000000','0.001477731573705','14.616533864541832','14.616533864541832','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','ICXBTC','4h','0.000101600000000','0.000101500000000','0.001467500000000','0.001466055610236','14.443897637795276','14.443897637795276','test'),('2018-10-07 23:59:59','2018-10-11 03:59:59','ICXBTC','4h','0.000102300000000','0.000102800000000','0.001467500000000','0.001474672531769','14.345063538611925','14.345063538611925','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','ICXBTC','4h','0.000101800000000','0.000103300000000','0.001467500000000','0.001489123280943','14.415520628683694','14.415520628683694','test'),('2018-11-01 11:59:59','2018-11-01 15:59:59','ICXBTC','4h','0.000102500000000','0.000102000000000','0.001467500000000','0.001460341463415','14.317073170731708','14.317073170731708','test'),('2018-11-29 11:59:59','2018-11-29 23:59:59','ICXBTC','4h','0.000068000000000','0.000067500000000','0.001467500000000','0.001456709558824','21.580882352941178','21.580882352941178','test'),('2018-12-01 15:59:59','2018-12-01 23:59:59','ICXBTC','4h','0.000066500000000','0.000066300000000','0.001467500000000','0.001463086466165','22.06766917293233','22.067669172932330','test'),('2018-12-18 03:59:59','2018-12-18 07:59:59','ICXBTC','4h','0.000060200000000','0.000059400000000','0.001467500000000','0.001447998338870','24.377076411960132','24.377076411960132','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','ICXBTC','4h','0.000060700000000','0.000059700000000','0.001467500000000','0.001443323723229','24.176276771004943','24.176276771004943','test'),('2018-12-20 19:59:59','2018-12-20 23:59:59','ICXBTC','4h','0.000061100000000','0.000061700000000','0.001467500000000','0.001481910801964','24.018003273322424','24.018003273322424','test'),('2018-12-28 19:59:59','2018-12-29 11:59:59','ICXBTC','4h','0.000063700000000','0.000063100000000','0.001467500000000','0.001453677394035','23.03767660910518','23.037676609105180','test'),('2018-12-30 23:59:59','2018-12-31 03:59:59','ICXBTC','4h','0.000063400000000','0.000062700000000','0.001467500000000','0.001451297318612','23.146687697160885','23.146687697160885','test'),('2018-12-31 15:59:59','2018-12-31 19:59:59','ICXBTC','4h','0.000063500000000','0.000062900000000','0.001467500000000','0.001453633858268','23.11023622047244','23.110236220472441','test'),('2019-01-01 07:59:59','2019-01-01 11:59:59','ICXBTC','4h','0.000062900000000','0.000063200000000','0.001467500000000','0.001474499205087','23.330683624801274','23.330683624801274','test'),('2019-01-17 15:59:59','2019-01-17 19:59:59','ICXBTC','4h','0.000065500000000','0.000065800000000','0.001467500000000','0.001474221374046','22.404580152671755','22.404580152671755','test'),('2019-01-19 07:59:59','2019-01-19 15:59:59','ICXBTC','4h','0.000065700000000','0.000065100000000','0.001467500000000','0.001454098173516','22.336377473363775','22.336377473363775','test'),('2019-01-23 15:59:59','2019-01-23 19:59:59','ICXBTC','4h','0.000065100000000','0.000064300000000','0.001467500000000','0.001449466205837','22.542242703533027','22.542242703533027','test'),('2019-02-07 03:59:59','2019-02-13 15:59:59','ICXBTC','4h','0.000058100000000','0.000060600000000','0.001467500000000','0.001530645438898','25.25817555938038','25.258175559380380','test'),('2019-02-14 23:59:59','2019-02-15 03:59:59','ICXBTC','4h','0.000060300000000','0.000060600000000','0.001467500000000','0.001474800995025','24.33665008291874','24.336650082918741','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','ICXBTC','4h','0.000061500000000','0.000060900000000','0.001467500000000','0.001453182926829','23.861788617886177','23.861788617886177','test'),('2019-02-20 19:59:59','2019-02-20 23:59:59','ICXBTC','4h','0.000061300000000','0.000061300000000','0.001467500000000','0.001467500000000','23.939641109298535','23.939641109298535','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','ICXBTC','4h','0.000083600000000','0.000083200000000','0.001467500000000','0.001460478468900','17.553827751196174','17.553827751196174','test'),('2019-03-19 03:59:59','2019-03-19 15:59:59','ICXBTC','4h','0.000085000000000','0.000084400000000','0.001467500000000','0.001457141176471','17.264705882352942','17.264705882352942','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ICXBTC','4h','0.000084400000000','0.000080300000000','0.001467500000000','0.001396211492891','17.387440758293838','17.387440758293838','test'),('2019-03-24 15:59:59','2019-03-25 07:59:59','ICXBTC','4h','0.000085900000000','0.000084800000000','0.001467500000000','0.001448707799767','17.083818393480794','17.083818393480794','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ICXBTC','4h','0.000082000000000','0.000081100000000','0.001467500000000','0.001451393292683','17.896341463414636','17.896341463414636','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','ICXBTC','4h','0.000081900000000','0.000082500000000','0.001467500000000','0.001478250915751','17.91819291819292','17.918192918192918','test'),('2019-04-03 07:59:59','2019-04-03 23:59:59','ICXBTC','4h','0.000083100000000','0.000081300000000','0.001467500000000','0.001435712996390','17.65944645006017','17.659446450060170','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','ICXBTC','4h','0.000085600000000','0.000082400000000','0.001467500000000','0.001412640186916','17.14369158878505','17.143691588785050','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','ICXBTC','4h','0.000083100000000','0.000083200000000','0.001467500000000','0.001469265944645','17.65944645006017','17.659446450060170','test'),('2019-04-22 11:59:59','2019-04-23 07:59:59','ICXBTC','4h','0.000074300000000','0.000072900000000','0.001467500000000','0.001439848586810','19.75100942126514','19.751009421265142','test'),('2019-05-18 03:59:59','2019-05-18 07:59:59','ICXBTC','4h','0.000051800000000','0.000049800000000','0.001467500000000','0.001410839768340','28.330115830115833','28.330115830115833','test'),('2019-05-18 11:59:59','2019-05-18 23:59:59','ICXBTC','4h','0.000051500000000','0.000051300000000','0.001467500000000','0.001461800970874','28.495145631067963','28.495145631067963','test'),('2019-05-21 19:59:59','2019-05-22 11:59:59','ICXBTC','4h','0.000051400000000','0.000049200000000','0.001467500000000','0.001404688715953','28.55058365758755','28.550583657587548','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','ICXBTC','4h','0.000050100000000','0.000049000000000','0.001467500000000','0.001435279441118','29.291417165668665','29.291417165668665','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','ICXBTC','4h','0.000047400000000','0.000047200000000','0.001467500000000','0.001461308016878','30.959915611814345','30.959915611814345','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','ICXBTC','4h','0.000047600000000','0.000051200000000','0.001467500000000','0.001578487394958','30.82983193277311','30.829831932773111','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:33:46
