-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 19:59:59','2018-05-15 07:59:59','XZCBTC','4h','0.004559000000000','0.004646000000000','0.001467500000000','0.001495504496600','0.3218907655187542','0.321890765518754','test'),('2018-07-03 03:59:59','2018-07-03 11:59:59','XZCBTC','4h','0.002585000000000','0.002492000000000','0.001474501124150','0.001421453308078','0.5704066244294004','0.570406624429400','test'),('2018-07-04 19:59:59','2018-07-05 11:59:59','XZCBTC','4h','0.002606000000000','0.002587000000000','0.001474501124150','0.001463750732224','0.565810101362241','0.565810101362241','test'),('2018-07-07 19:59:59','2018-07-11 07:59:59','XZCBTC','4h','0.002590000000000','0.002594000000000','0.001474501124150','0.001476778345963','0.5693054533397683','0.569305453339768','test'),('2018-07-11 19:59:59','2018-07-12 07:59:59','XZCBTC','4h','0.002656000000000','0.002637000000000','0.001474501124150','0.001463953111590','0.5551585557793675','0.555158555779367','test'),('2018-08-05 23:59:59','2018-08-06 07:59:59','XZCBTC','4h','0.001955000000000','0.001957000000000','0.001474501124150','0.001476009565198','0.7542205238618925','0.754220523861893','test'),('2018-08-06 15:59:59','2018-08-06 19:59:59','XZCBTC','4h','0.001952000000000','0.001947000000000','0.001474501124150','0.001470724225779','0.7553796742571721','0.755379674257172','test'),('2018-08-12 03:59:59','2018-08-12 07:59:59','XZCBTC','4h','0.002067000000000','0.002016000000000','0.001474501124150','0.001438120109476','0.713353228906628','0.713353228906628','test'),('2018-08-13 11:59:59','2018-08-13 19:59:59','XZCBTC','4h','0.002041000000000','0.001921000000000','0.001474501124150','0.001387808260408','0.7224405311856933','0.722440531185693','test'),('2018-08-13 23:59:59','2018-08-14 03:59:59','XZCBTC','4h','0.002046000000000','0.001980000000000','0.001474501124150','0.001426936571758','0.7206750362414467','0.720675036241447','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','XZCBTC','4h','0.002065000000000','0.002060000000000','0.001474501124150','0.001470930903510','0.7140441279176756','0.714044127917676','test'),('2018-08-19 03:59:59','2018-08-19 15:59:59','XZCBTC','4h','0.002156000000000','0.002157000000000','0.001474501124150','0.001475185030052','0.6839059017393321','0.683905901739332','test'),('2018-09-28 15:59:59','2018-10-03 15:59:59','XZCBTC','4h','0.001465000000000','0.001505000000000','0.001474501124150','0.001514760540509','1.0064854089761093','1.006485408976109','test'),('2018-10-05 19:59:59','2018-10-06 03:59:59','XZCBTC','4h','0.001492000000000','0.001476000000000','0.001474501124150','0.001458688779655','0.9882715309316353','0.988271530931635','test'),('2018-10-07 03:59:59','2018-10-07 07:59:59','XZCBTC','4h','0.001500000000000','0.001487000000000','0.001474501124150','0.001461722114407','0.9830007494333333','0.983000749433333','test'),('2018-10-16 15:59:59','2018-10-18 15:59:59','XZCBTC','4h','0.001526000000000','0.001479000000000','0.001474501124150','0.001429087262528','0.9662523749344691','0.966252374934469','test'),('2018-10-19 11:59:59','2018-10-19 15:59:59','XZCBTC','4h','0.001494000000000','0.001471000000000','0.001474501124150','0.001451801307647','0.9869485436077643','0.986948543607764','test'),('2018-10-20 19:59:59','2018-10-22 03:59:59','XZCBTC','4h','0.001530000000000','0.001487000000000','0.001474501124150','0.001433060896478','0.9637262249346406','0.963726224934641','test'),('2018-10-22 19:59:59','2018-10-23 11:59:59','XZCBTC','4h','0.001550000000000','0.001490000000000','0.001474501124150','0.001417423661280','0.9512910478387097','0.951291047838710','test'),('2018-10-24 15:59:59','2018-10-24 19:59:59','XZCBTC','4h','0.001501000000000','0.001534000000000','0.001474501124150','0.001506918537273','0.9823458521985343','0.982345852198534','test'),('2018-10-31 15:59:59','2018-11-01 07:59:59','XZCBTC','4h','0.001618000000000','0.001615000000000','0.001474501124150','0.001471767191287','0.9113109543572311','0.911310954357231','test'),('2018-11-01 15:59:59','2018-11-01 19:59:59','XZCBTC','4h','0.001618000000000','0.001627000000000','0.001474501124150','0.001482702922739','0.9113109543572311','0.911310954357231','test'),('2018-11-07 15:59:59','2018-11-07 23:59:59','XZCBTC','4h','0.001619000000000','0.001623000000000','0.001474501124150','0.001478144116427','0.910748069271155','0.910748069271155','test'),('2018-11-09 23:59:59','2018-11-12 19:59:59','XZCBTC','4h','0.001617000000000','0.001629000000000','0.001474501124150','0.001485443618578','0.9118745356524428','0.911874535652443','test'),('2018-11-13 07:59:59','2018-11-13 11:59:59','XZCBTC','4h','0.001612000000000','0.001633000000000','0.001474501124150','0.001493709885693','0.914702930614144','0.914702930614144','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','XZCBTC','4h','0.001441000000000','0.001407000000000','0.001474501124150','0.001439710674309','1.023248524739764','1.023248524739764','test'),('2018-11-29 11:59:59','2018-11-29 19:59:59','XZCBTC','4h','0.001412000000000','0.001401000000000','0.001474501124150','0.001463014217375','1.044264252230878','1.044264252230878','test'),('2018-11-30 11:59:59','2018-11-30 15:59:59','XZCBTC','4h','0.001435000000000','0.001426000000000','0.001474501124150','0.001465253381908','1.0275269157839722','1.027526915783972','test'),('2018-12-07 19:59:59','2018-12-07 23:59:59','XZCBTC','4h','0.001539000000000','0.001497000000000','0.001474501124150','0.001434261327390','0.9580903990578298','0.958090399057830','test'),('2018-12-08 03:59:59','2018-12-08 07:59:59','XZCBTC','4h','0.001518000000000','0.001525000000000','0.001474501124150','0.001481300536448','0.9713446140645586','0.971344614064559','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','XZCBTC','4h','0.001535000000000','0.001509000000000','0.001474501124150','0.001449525860809','0.960587051563518','0.960587051563518','test'),('2018-12-09 15:59:59','2018-12-09 23:59:59','XZCBTC','4h','0.001531000000000','0.001504000000000','0.001474501124150','0.001448497511902','0.9630967499346832','0.963096749934683','test'),('2018-12-20 19:59:59','2018-12-20 23:59:59','XZCBTC','4h','0.001383000000000','0.001380000000000','0.001474501124150','0.001471302640150','1.0661613334417932','1.066161333441793','test'),('2018-12-22 03:59:59','2018-12-22 07:59:59','XZCBTC','4h','0.001377000000000','0.001372000000000','0.001474501124150','0.001469147089567','1.070806916594045','1.070806916594045','test'),('2018-12-29 15:59:59','2018-12-31 07:59:59','XZCBTC','4h','0.001460000000000','0.001435000000000','0.001474501124150','0.001449252817230','1.0099322768150685','1.009932276815068','test'),('2019-01-03 03:59:59','2019-01-03 07:59:59','XZCBTC','4h','0.001418000000000','0.001458000000000','0.001474501124150','0.001516094949937','1.0398456446755995','1.039845644675599','test'),('2019-01-05 03:59:59','2019-01-05 07:59:59','XZCBTC','4h','0.001428000000000','0.001410000000000','0.001474501124150','0.001455914975526','1.0325638124299719','1.032563812429972','test'),('2019-01-08 11:59:59','2019-01-09 15:59:59','XZCBTC','4h','0.001448000000000','0.001420000000000','0.001474501124150','0.001445988671473','1.0183018813190607','1.018301881319061','test'),('2019-01-17 15:59:59','2019-01-20 15:59:59','XZCBTC','4h','0.001411000000000','0.001424000000000','0.001474501124150','0.001488086180574','1.0450043402905742','1.045004340290574','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','XZCBTC','4h','0.001376000000000','0.001360000000000','0.001474501124150','0.001457355762241','1.071585119295058','1.071585119295058','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','XZCBTC','4h','0.001348000000000','0.001350000000000','0.001474501124150','0.001476688811278','1.0938435639094954','1.093843563909495','test'),('2019-02-22 15:59:59','2019-02-22 23:59:59','XZCBTC','4h','0.001397000000000','0.001383000000000','0.001474501124150','0.001459724448604','1.0554768247315676','1.055476824731568','test'),('2019-02-23 03:59:59','2019-02-23 07:59:59','XZCBTC','4h','0.001386000000000','0.001400000000000','0.001474501124150','0.001489395074899','1.0638536249278499','1.063853624927850','test'),('2019-02-24 03:59:59','2019-02-24 07:59:59','XZCBTC','4h','0.001395000000000','0.001374000000000','0.001474501124150','0.001452304333034','1.0569900531541219','1.056990053154122','test'),('2019-02-24 23:59:59','2019-02-25 07:59:59','XZCBTC','4h','0.001390000000000','0.001390000000000','0.001474501124150','0.001474501124150','1.060792175647482','1.060792175647482','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','XZCBTC','4h','0.001644000000000','0.001661000000000','0.001474501124150','0.001489748398548','0.8968984940085157','0.896898494008516','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','XZCBTC','4h','0.001813000000000','0.001699000000000','0.001474501124150','0.001381785664606','0.8132935047710976','0.813293504771098','test'),('2019-04-05 15:59:59','2019-04-05 19:59:59','XZCBTC','4h','0.001749000000000','0.001748000000000','0.001474501124150','0.001473658070334','0.8430538159805604','0.843053815980560','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','XZCBTC','4h','0.001755000000000','0.001735000000000','0.001474501124150','0.001457697692536','0.8401715807122507','0.840171580712251','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','XZCBTC','4h','0.001606000000000','0.001600000000000','0.001474501124150','0.001468992402640','0.9181202516500623','0.918120251650062','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:47:41
