-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-19 11:59:59','2018-12-19 15:59:59','NASETH','4h','0.006141000000000','0.005808000000000','0.072144500000000','0.068232414264778','11.748005210877707','11.748005210877707','test'),('2019-01-10 03:59:59','2019-01-10 11:59:59','NASETH','4h','0.004253000000000','0.004250000000000','0.072144500000000','0.072093610392664','16.96320244533271','16.963202445332708','test'),('2019-01-11 11:59:59','2019-01-12 07:59:59','NASETH','4h','0.004247000000000','0.004249000000000','0.072144500000000','0.072178474334825','16.98716741229103','16.987167412291029','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','NASETH','4h','0.004290000000000','0.004245000000000','0.072144500000000','0.071387739510490','16.816899766899766','16.816899766899766','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','NASETH','4h','0.004278000000000','0.004248000000000','0.072144500000000','0.071638577840112','16.864071996259934','16.864071996259934','test'),('2019-01-15 23:59:59','2019-01-30 15:59:59','NASETH','4h','0.004342000000000','0.004872000000000','0.072144500000000','0.080950714877936','16.615499769691386','16.615499769691386','test'),('2019-02-01 15:59:59','2019-02-02 15:59:59','NASETH','4h','0.004854000000000','0.004838000000000','0.073048132805201','0.072807347859819','15.049059086362023','15.049059086362023','test'),('2019-02-03 11:59:59','2019-02-04 07:59:59','NASETH','4h','0.004865000000000','0.004852000000000','0.073048132805201','0.072852937383522','15.015032436834737','15.015032436834737','test'),('2019-02-06 03:59:59','2019-02-06 19:59:59','NASETH','4h','0.004893000000000','0.004862000000000','0.073048132805201','0.072585330410564','14.929109504435113','14.929109504435113','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','NASETH','4h','0.004853000000000','0.004838000000000','0.073048132805201','0.072822350404196','15.052160067010306','15.052160067010306','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','NASETH','4h','0.004851000000000','0.004776000000000','0.073048132805201','0.071918755365417','15.05836586378087','15.058365863780869','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','NASETH','4h','0.004600000000000','0.004562000000000','0.073048132805201','0.072444691708115','15.88002887069587','15.880028870695870','test'),('2019-02-23 03:59:59','2019-02-23 19:59:59','NASETH','4h','0.004502000000000','0.004184000000000','0.073048132805201','0.067888357986886','16.225706975833187','16.225706975833187','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','NASETH','4h','0.004421000000000','0.004278000000000','0.073048132805201','0.070685345428783','16.52298864627935','16.522988646279352','test'),('2019-02-24 19:59:59','2019-02-25 15:59:59','NASETH','4h','0.004372000000000','0.004365000000000','0.073048132805201','0.072931175593482','16.70817310274497','16.708173102744968','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','NASETH','4h','0.004599000000000','0.004585000000000','0.073048132805201','0.072825764059980','15.88348180152229','15.883481801522290','test'),('2019-04-10 19:59:59','2019-04-11 03:59:59','NASETH','4h','0.006911000000000','0.006855000000000','0.073048132805201','0.072456222019918','10.56983545148329','10.569835451483289','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','NASETH','4h','0.004498000000000','0.004467000000000','0.073048132805201','0.072544688581777','16.24013623948444','16.240136239484439','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','NASETH','4h','0.004442000000000','0.004391000000000','0.073048132805201','0.072209444202530','16.444874562179425','16.444874562179425','test'),('2019-06-07 03:59:59','2019-06-08 15:59:59','NASETH','4h','0.004419000000000','0.004444000000000','0.073048132805201','0.073461394475292','16.530466803620957','16.530466803620957','test'),('2019-06-18 23:59:59','2019-06-19 11:59:59','NASETH','4h','0.005826000000000','0.005878000000000','0.073048132805201','0.073700124378471','12.538299485959666','12.538299485959666','test'),('2019-06-23 15:59:59','2019-06-23 23:59:59','NASETH','4h','0.005814000000000','0.005788000000000','0.073048132805201','0.072721464168645','12.564178329067941','12.564178329067941','test'),('2019-07-01 11:59:59','2019-07-01 15:59:59','NASETH','4h','0.005413000000000','0.005241000000000','0.073048132805201','0.070727002407548','13.494944172399963','13.494944172399963','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','NASETH','4h','0.005267000000000','0.005479000000000','0.073048132805201','0.075988365224928','13.869020847769319','13.869020847769319','test'),('2019-07-04 07:59:59','2019-07-06 19:59:59','NASETH','4h','0.005416000000000','0.005325000000000','0.073048132805201','0.071820773114419','13.487469129468428','13.487469129468428','test'),('2019-07-06 23:59:59','2019-07-07 03:59:59','NASETH','4h','0.005436000000000','0.005292000000000','0.073048132805201','0.071113082929567','13.437846358572665','13.437846358572665','test'),('2019-07-22 03:59:59','2019-07-22 07:59:59','NASETH','4h','0.004300000000000','0.004232000000000','0.073048132805201','0.071892953030607','16.987937861674652','16.987937861674652','test'),('2019-07-22 11:59:59','2019-07-22 15:59:59','NASETH','4h','0.004277000000000','0.004310000000000','0.073048132805201','0.073611749448309','17.07929221538485','17.079292215384850','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','NASETH','4h','0.004317000000000','0.004294000000000','0.073048132805201','0.072658948868551','16.92104072392889','16.921040723928890','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','NASETH','4h','0.004273000000000','0.004192000000000','0.073048132805201','0.071663415099322','17.095280319494737','17.095280319494737','test'),('2019-07-26 11:59:59','2019-07-27 03:59:59','NASETH','4h','0.004272000000000','0.004280000000000','0.073048132805201','0.073184927061391','17.099282023689376','17.099282023689376','test'),('2019-07-28 15:59:59','2019-07-28 19:59:59','NASETH','4h','0.004270000000000','0.004299000000000','0.073048132805201','0.073544244245798','17.1072910550822','17.107291055082200','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','NASETH','4h','0.004291000000000','0.004218000000000','0.073048132805201','0.071805412298378','17.0235685866234','17.023568586623401','test'),('2019-07-31 19:59:59','2019-07-31 23:59:59','NASETH','4h','0.004264000000000','0.004205000000000','0.073048132805201','0.072037382374735','17.13136322823663','17.131363228236630','test'),('2019-08-01 03:59:59','2019-08-01 19:59:59','NASETH','4h','0.004355000000000','0.004243000000000','0.073048132805201','0.071169512627432','16.77339444436303','16.773394444363031','test'),('2019-08-02 07:59:59','2019-08-02 11:59:59','NASETH','4h','0.004275000000000','0.004253000000000','0.073048132805201','0.072672212589595','17.0872825275324','17.087282527532398','test'),('2019-08-02 23:59:59','2019-08-03 03:59:59','NASETH','4h','0.004292000000000','0.004234000000000','0.073048132805201','0.072060995875401','17.01960223793127','17.019602237931270','test'),('2019-08-03 11:59:59','2019-08-05 03:59:59','NASETH','4h','0.004613000000000','0.004329000000000','0.073048132805201','0.068550914136942','15.835277000910688','15.835277000910688','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','NASETH','4h','0.003631000000000','0.003615000000000','0.073048132805201','0.072726246238172','20.117910439328284','20.117910439328284','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','NASETH','4h','0.003696000000000','0.003584000000000','0.073048132805201','0.070834553023225','19.76410519621239','19.764105196212391','test'),('2019-08-23 19:59:59','2019-08-27 03:59:59','NASETH','4h','0.003666000000000','0.003741000000000','0.073048132805201','0.074542570874047','19.925840917948992','19.925840917948992','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','NASETH','4h','0.003883000000000','0.003849000000000','0.073048132805201','0.072408514851202','18.812292764666754','18.812292764666754','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','NASETH','4h','0.003877000000000','0.003853000000000','0.073048132805201','0.072595939050410','18.84140644962626','18.841406449626259','test'),('2019-09-30 07:59:59','2019-09-30 11:59:59','NASETH','4h','0.002956000000000','0.002893000000000','0.073048132805201','0.071491288296836','24.711817593099124','24.711817593099124','test'),('2019-10-06 11:59:59','2019-10-09 15:59:59','NASETH','4h','0.002877000000000','0.002850000000000','0.073048132805201','0.072362592455621','25.39038331776191','25.390383317761909','test'),('2019-10-09 23:59:59','2019-10-10 03:59:59','NASETH','4h','0.002936000000000','0.002912000000000','0.073048132805201','0.072451009103796','24.880154225204702','24.880154225204702','test'),('2019-10-21 15:59:59','2019-10-22 03:59:59','NASETH','4h','0.002700000000000','0.002732000000000','0.073048132805201','0.073913888453263','27.054864001926298','27.054864001926298','test'),('2019-10-23 03:59:59','2019-10-23 07:59:59','NASETH','4h','0.002711000000000','0.002707000000000','0.073048132805201','0.072940352454327','26.945087718628184','26.945087718628184','test'),('2019-10-27 03:59:59','2019-11-04 23:59:59','NASETH','4h','0.002737000000000','0.003299000000000','0.073048132805201','0.088047420578867','26.689124152430036','26.689124152430036','test'),('2019-11-07 11:59:59','2019-11-08 11:59:59','NASETH','4h','0.003240000000000','0.003276000000000','0.073048132805201','0.073859778725259','22.54572000160525','22.545720001605250','test'),('2019-11-10 07:59:59','2019-11-10 11:59:59','NASETH','4h','0.003255000000000','0.003247000000000','0.073048132805201','0.072868598223806','22.44182267440891','22.441822674408911','test'),('2019-11-12 11:59:59','2019-11-15 15:59:59','NASETH','4h','0.003279000000000','0.003258000000000','0.073048132805201','0.072580303958324','22.277564136993295','22.277564136993295','test'),('2019-11-16 15:59:59','2019-11-16 19:59:59','NASETH','4h','0.003289000000000','0.003265000000000','0.073048132805201','0.072515096871080','22.209830588385834','22.209830588385834','test'),('2019-11-28 07:59:59','2019-11-28 15:59:59','NASETH','4h','0.002935000000000','0.002953000000000','0.073048132805201','0.073496128168231','24.888631279455197','24.888631279455197','test'),('2019-12-07 07:59:59','2019-12-07 11:59:59','NASETH','4h','0.002882000000000','0.002874000000000','0.073048132805201','0.072845362138150','25.346333381402154','25.346333381402154','test'),('2019-12-11 15:59:59','2019-12-11 23:59:59','NASETH','4h','0.002876000000000','0.002885000000000','0.073048132805201','0.073276725710363','25.39921168470132','25.399211684701321','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 15:20:02
