-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-23 11:59:59','2018-04-23 15:59:59','SUBETH','4h','0.001158480000000','0.001140710000000','0.072144500000000','0.071037870826428','62.27513638560873','62.275136385608732','test'),('2018-04-26 11:59:59','2018-04-27 03:59:59','SUBETH','4h','0.001156000000000','0.001137640000000','0.072144500000000','0.070998675588235','62.40873702422146','62.408737024221459','test'),('2018-04-28 19:59:59','2018-04-28 23:59:59','SUBETH','4h','0.001171570000000','0.001155540000000','0.072144500000000','0.071157383280555','61.57933371458812','61.579333714588117','test'),('2018-04-29 15:59:59','2018-05-03 03:59:59','SUBETH','4h','0.001145910000000','0.001140400000000','0.072144500000000','0.071797599986037','62.958260247314364','62.958260247314364','test'),('2018-05-31 15:59:59','2018-05-31 19:59:59','SUBETH','4h','0.000745470000000','0.000747920000000','0.072144500000000','0.072381604142353','96.7772009604679','96.777200960467894','test'),('2018-06-02 03:59:59','2018-06-03 03:59:59','SUBETH','4h','0.000743270000000','0.000739450000000','0.072144500000000','0.071773716852557','97.06365116310359','97.063651163103586','test'),('2018-07-01 23:59:59','2018-07-02 03:59:59','SUBETH','4h','0.000495500000000','0.000460000000000','0.072144500000000','0.066975721493441','145.59939455095864','145.599394550958635','test'),('2018-07-02 07:59:59','2018-07-02 11:59:59','SUBETH','4h','0.000470010000000','0.000472340000000','0.072144500000000','0.072502144911810','153.49567030488714','153.495670304887142','test'),('2018-07-06 19:59:59','2018-07-07 03:59:59','SUBETH','4h','0.000489580000000','0.000489340000000','0.072144500000000','0.072109133604314','147.35998202540955','147.359982025409550','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','SUBETH','4h','0.000493000000000','0.000482080000000','0.072144500000000','0.070546492008114','146.3377281947262','146.337728194726196','test'),('2018-07-08 19:59:59','2018-07-08 23:59:59','SUBETH','4h','0.000492940000000','0.000488790000000','0.072144500000000','0.071537124508054','146.35554022801963','146.355540228019635','test'),('2018-07-09 19:59:59','2018-07-10 03:59:59','SUBETH','4h','0.000494700000000','0.000479480000000','0.072144500000000','0.069924893592076','145.834849403679','145.834849403678987','test'),('2018-07-16 11:59:59','2018-07-22 03:59:59','SUBETH','4h','0.000486720000000','0.000513000000000','0.072144500000000','0.076039876109467','148.22587935568706','148.225879355687056','test'),('2018-07-22 19:59:59','2018-07-22 23:59:59','SUBETH','4h','0.000515650000000','0.000502510000000','0.072144500000000','0.070306084931640','139.909822554058','139.909822554057996','test'),('2018-08-06 07:59:59','2018-08-06 11:59:59','SUBETH','4h','0.000422970000000','0.000410030000000','0.072144500000000','0.069937369872568','170.56647043525547','170.566470435255468','test'),('2018-08-13 07:59:59','2018-08-13 11:59:59','SUBETH','4h','0.000403820000000','0.000403220000000','0.072144500000000','0.072037306943688','178.6550938536972','178.655093853697196','test'),('2018-08-15 03:59:59','2018-08-15 07:59:59','SUBETH','4h','0.000410730000000','0.000412020000000','0.072144500000000','0.072371087794902','175.64945341221727','175.649453412217269','test'),('2018-08-16 19:59:59','2018-08-16 23:59:59','SUBETH','4h','0.000415650000000','0.000395240000000','0.072144500000000','0.068601929941056','173.5703115602069','173.570311560206903','test'),('2018-08-19 11:59:59','2018-08-19 19:59:59','SUBETH','4h','0.000407210000000','0.000409380000000','0.072144500000000','0.072528954126863','177.16780039782913','177.167800397829126','test'),('2018-08-30 23:59:59','2018-08-31 15:59:59','SUBETH','4h','0.000602500000000','0.000573210000000','0.072144500000000','0.068637259493776','119.74190871369295','119.741908713692951','test'),('2018-09-09 03:59:59','2018-09-09 11:59:59','SUBETH','4h','0.000545410000000','0.000543810000000','0.072144500000000','0.071932858849306','132.27571918373334','132.275719183733344','test'),('2018-09-12 15:59:59','2018-09-12 19:59:59','SUBETH','4h','0.000541900000000','0.000530670000000','0.072144500000000','0.070649422061266','133.13249677062188','133.132496770621884','test'),('2018-09-12 23:59:59','2018-09-13 03:59:59','SUBETH','4h','0.000540070000000','0.000520170000000','0.072144500000000','0.069486186170311','133.58360953209768','133.583609532097682','test'),('2018-09-14 23:59:59','2018-09-15 15:59:59','SUBETH','4h','0.000557230000000','0.000532310000000','0.072144500000000','0.068918110645514','129.4698777883459','129.469877788345912','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','SUBETH','4h','0.000543060000000','0.000527550000000','0.072144500000000','0.070084025660148','132.8481199130851','132.848119913085100','test'),('2018-09-16 15:59:59','2018-09-16 19:59:59','SUBETH','4h','0.000535960000000','0.000530460000000','0.072144500000000','0.071404156037764','134.60799313381594','134.607993133815938','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','SUBETH','4h','0.000519670000000','0.000517070000000','0.072144500000000','0.071783548434583','138.82752516019784','138.827525160197837','test'),('2018-09-30 15:59:59','2018-09-30 19:59:59','SUBETH','4h','0.000521330000000','0.000522890000000','0.072144500000000','0.072360381341952','138.3854756104579','138.385475610457888','test'),('2018-10-13 23:59:59','2018-10-14 03:59:59','SUBETH','4h','0.000536880000000','0.000532040000000','0.072144500000000','0.071494113731188','134.3773282670243','134.377328267024296','test'),('2018-10-17 11:59:59','2018-10-17 15:59:59','SUBETH','4h','0.000543500000000','0.000539920000000','0.072144500000000','0.071669288758050','132.7405703771849','132.740570377184895','test'),('2018-10-19 05:59:59','2018-10-19 11:59:59','SUBETH','4h','0.000533540000000','0.000538470000000','0.072144500000000','0.072811127403756','135.2185403156277','135.218540315627706','test'),('2018-10-26 23:59:59','2018-10-27 03:59:59','SUBETH','4h','0.000548600000000','0.000543720000000','0.072144500000000','0.071502747976668','131.50656215822093','131.506562158220930','test'),('2018-10-27 07:59:59','2018-10-27 11:59:59','SUBETH','4h','0.000549400000000','0.000542970000000','0.072144500000000','0.071300144093557','131.31507098653077','131.315070986530770','test'),('2018-10-29 07:59:59','2018-10-29 11:59:59','SUBETH','4h','0.000546530000000','0.000536370000000','0.072144500000000','0.070803332781366','132.00464750333924','132.004647503339243','test'),('2018-10-30 19:59:59','2018-11-03 15:59:59','SUBETH','4h','0.000557070000000','0.000550740000000','0.072144500000000','0.071324720286499','129.50706374423322','129.507063744233221','test'),('2018-11-03 19:59:59','2018-11-03 23:59:59','SUBETH','4h','0.000562530000000','0.000570130000000','0.072144500000000','0.073119200371536','128.25004888628163','128.250048886281633','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','SUBETH','4h','0.000419760000000','0.000424940000000','0.072144500000000','0.073034790904326','171.87083095101963','171.870830951019627','test'),('2018-12-01 07:59:59','2018-12-03 23:59:59','SUBETH','4h','0.000424420000000','0.000421250000000','0.072144500000000','0.071605651536214','169.98374251920268','169.983742519202679','test'),('2018-12-04 15:59:59','2018-12-12 11:59:59','SUBETH','4h','0.000437280000000','0.000470100000000','0.072144500000000','0.077559297132272','164.98467800951335','164.984678009513345','test'),('2018-12-15 15:59:59','2018-12-16 15:59:59','SUBETH','4h','0.000480620000000','0.000466140000000','0.072144500000000','0.069970948420790','150.107153260372','150.107153260372002','test'),('2018-12-17 07:59:59','2018-12-17 11:59:59','SUBETH','4h','0.000468800000000','0.000463670000000','0.072144500000000','0.071355034801621','153.89185153583617','153.891851535836167','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','SUBETH','4h','0.000470000000000','0.000452130000000','0.072144500000000','0.069401474010638','153.49893617021277','153.498936170212772','test'),('2018-12-22 15:59:59','2018-12-22 19:59:59','SUBETH','4h','0.000475580000000','0.000451710000000','0.072144500000000','0.068523470488666','151.69792674208335','151.697926742083354','test'),('2019-01-11 03:59:59','2019-01-11 07:59:59','SUBETH','4h','0.000353660000000','0.000347150000000','0.072144500000000','0.070816499392071','203.9939489905559','203.993948990555907','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','SUBETH','4h','0.000357330000000','0.000355730000000','0.072144500000000','0.071821461911958','201.8988050261663','201.898805026166286','test'),('2019-01-12 23:59:59','2019-01-13 19:59:59','SUBETH','4h','0.000356910000000','0.000358700000000','0.072144500000000','0.072506324143341','202.1363929281892','202.136392928189196','test'),('2019-01-14 11:59:59','2019-01-14 15:59:59','SUBETH','4h','0.000357570000000','0.000344050000000','0.072144500000000','0.069416660304276','201.76329110383983','201.763291103839833','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','SUBETH','4h','0.000355910000000','0.000376470000000','0.072144500000000','0.076312101135118','202.7043353656823','202.704335365682311','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','SUBETH','4h','0.000401380000000','0.000389310000000','0.072144500000000','0.069975024403309','179.74114305645523','179.741143056455229','test'),('2019-02-01 15:59:59','2019-02-02 03:59:59','SUBETH','4h','0.000405460000000','0.000438530000000','0.072144500000000','0.078028726841119','177.93247176046958','177.932471760469582','test'),('2019-02-03 07:59:59','2019-02-03 15:59:59','SUBETH','4h','0.000398610000000','0.000391390000000','0.072144500000000','0.070837750821605','180.99019091342416','180.990190913424158','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','SUBETH','4h','0.000389600000000','0.000383590000000','0.072144500000000','0.071031593313655','185.17582135523614','185.175821355236138','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  4:16:40
