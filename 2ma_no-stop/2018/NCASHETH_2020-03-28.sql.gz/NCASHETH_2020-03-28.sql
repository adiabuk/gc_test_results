-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-17 11:59:59','2018-08-18 07:59:59','NCASHETH','4h','0.000020540000000','0.000019200000000','0.072144500000000','0.067437896786758','3512.390457643622','3512.390457643622085','test'),('2018-08-19 11:59:59','2018-08-19 15:59:59','NCASHETH','4h','0.000019650000000','0.000019800000000','0.072144500000000','0.072695221374046','3671.47582697201','3671.475826972010054','test'),('2018-08-23 19:59:59','2018-08-26 07:59:59','NCASHETH','4h','0.000020990000000','0.000020390000000','0.072144500000000','0.070082246545974','3437.0890900428776','3437.089090042877615','test'),('2018-09-07 07:59:59','2018-09-07 11:59:59','NCASHETH','4h','0.000026110000000','0.000025610000000','0.072144500000000','0.070762950785140','2763.0984297204136','2763.098429720413606','test'),('2018-09-07 15:59:59','2018-09-07 19:59:59','NCASHETH','4h','0.000026190000000','0.000026140000000','0.072144500000000','0.072006767086674','2754.6582665139363','2754.658266513936269','test'),('2018-09-08 07:59:59','2018-09-08 11:59:59','NCASHETH','4h','0.000026250000000','0.000026310000000','0.072144500000000','0.072309401714286','2748.3619047619045','2748.361904761904498','test'),('2018-09-12 03:59:59','2018-09-12 07:59:59','NCASHETH','4h','0.000026600000000','0.000025950000000','0.072144500000000','0.070381570488722','2712.199248120301','2712.199248120301036','test'),('2018-09-12 15:59:59','2018-09-12 19:59:59','NCASHETH','4h','0.000026400000000','0.000026070000000','0.072144500000000','0.071242693750000','2732.746212121212','2732.746212121212011','test'),('2018-09-17 11:59:59','2018-09-18 15:59:59','NCASHETH','4h','0.000026030000000','0.000025300000000','0.072144500000000','0.070121238955052','2771.590472531694','2771.590472531694104','test'),('2018-09-19 03:59:59','2018-09-19 07:59:59','NCASHETH','4h','0.000025830000000','0.000026780000000','0.072144500000000','0.074797898180410','2793.050716221448','2793.050716221448056','test'),('2018-09-23 19:59:59','2018-09-23 23:59:59','NCASHETH','4h','0.000025830000000','0.000025300000000','0.072144500000000','0.070664183120403','2793.050716221448','2793.050716221448056','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','NCASHETH','4h','0.000025310000000','0.000025120000000','0.072144500000000','0.071602917423943','2850.4346108257605','2850.434610825760501','test'),('2018-09-25 07:59:59','2018-09-25 23:59:59','NCASHETH','4h','0.000025320000000','0.000025230000000','0.072144500000000','0.071888062203791','2849.3088467614534','2849.308846761453424','test'),('2018-10-05 15:59:59','2018-10-05 19:59:59','NCASHETH','4h','0.000024250000000','0.000024150000000','0.072144500000000','0.071846996907216','2975.0309278350514','2975.030927835051443','test'),('2018-10-06 11:59:59','2018-10-06 15:59:59','NCASHETH','4h','0.000024630000000','0.000024210000000','0.072144500000000','0.070914264920828','2929.1311408850997','2929.131140885099740','test'),('2018-10-07 11:59:59','2018-10-08 15:59:59','NCASHETH','4h','0.000024120000000','0.000024400000000','0.072144500000000','0.072981998341625','2991.0655058043117','2991.065505804311670','test'),('2018-10-09 03:59:59','2018-10-09 07:59:59','NCASHETH','4h','0.000024150000000','0.000023990000000','0.072144500000000','0.071666524016563','2987.349896480331','2987.349896480331154','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','NCASHETH','4h','0.000024870000000','0.000023930000000','0.072144500000000','0.069417687374347','2900.864495375955','2900.864495375954903','test'),('2018-10-11 23:59:59','2018-10-12 03:59:59','NCASHETH','4h','0.000024350000000','0.000023860000000','0.072144500000000','0.070692721560575','2962.813141683778','2962.813141683778213','test'),('2018-10-14 03:59:59','2018-10-14 07:59:59','NCASHETH','4h','0.000024000000000','0.000023870000000','0.072144500000000','0.071753717291667','3006.0208333333335','3006.020833333333485','test'),('2018-10-14 11:59:59','2018-10-14 15:59:59','NCASHETH','4h','0.000023910000000','0.000024150000000','0.072144500000000','0.072868660602258','3017.335842743622','3017.335842743621924','test'),('2018-10-16 19:59:59','2018-10-16 23:59:59','NCASHETH','4h','0.000023850000000','0.000023690000000','0.072144500000000','0.071660511740042','3024.9266247379455','3024.926624737945531','test'),('2018-10-17 03:59:59','2018-10-17 15:59:59','NCASHETH','4h','0.000024210000000','0.000023840000000','0.072144500000000','0.071041919867823','2979.946303180504','2979.946303180503946','test'),('2018-10-20 11:59:59','2018-10-20 19:59:59','NCASHETH','4h','0.000023990000000','0.000023860000000','0.072144500000000','0.071753554397666','3007.273864110046','3007.273864110045906','test'),('2018-10-23 03:59:59','2018-10-27 11:59:59','NCASHETH','4h','0.000023970000000','0.000024810000000','0.072144500000000','0.074672717772215','3009.7830621610346','3009.783062161034650','test'),('2018-10-28 07:59:59','2018-10-28 15:59:59','NCASHETH','4h','0.000025110000000','0.000025710000000','0.072144500000000','0.073868382915173','2873.1381919553965','2873.138191955396451','test'),('2018-11-27 15:59:59','2018-11-27 23:59:59','NCASHETH','4h','0.000019590000000','0.000018930000000','0.072144500000000','0.069713904287902','3682.7207759060743','3682.720775906074323','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','NCASHETH','4h','0.000019270000000','0.000019470000000','0.072144500000000','0.072893275298391','3743.8764919564087','3743.876491956408699','test'),('2018-12-04 07:59:59','2018-12-04 23:59:59','NCASHETH','4h','0.000019710000000','0.000019590000000','0.072144500000000','0.071705264079148','3660.299340436327','3660.299340436326929','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','NCASHETH','4h','0.000019570000000','0.000019210000000','0.072144500000000','0.070817365610629','3686.484414920797','3686.484414920797008','test'),('2018-12-06 11:59:59','2018-12-07 03:59:59','NCASHETH','4h','0.000022160000000','0.000019900000000','0.072144500000000','0.064786802797834','3255.618231046931','3255.618231046931214','test'),('2018-12-17 19:59:59','2018-12-18 03:59:59','NCASHETH','4h','0.000019020000000','0.000018910000000','0.072144500000000','0.071727260515247','3793.086225026288','3793.086225026288048','test'),('2018-12-19 11:59:59','2018-12-20 19:59:59','NCASHETH','4h','0.000019550000000','0.000018890000000','0.072144500000000','0.069708931202046','3690.2557544757033','3690.255754475703270','test'),('2018-12-21 15:59:59','2018-12-21 23:59:59','NCASHETH','4h','0.000019290000000','0.000019260000000','0.072144500000000','0.072032300155521','3739.994815966822','3739.994815966821989','test'),('2019-01-09 03:59:59','2019-01-09 07:59:59','NCASHETH','4h','0.000014020000000','0.000013800000000','0.072144500000000','0.071012417974322','5145.8273894436525','5145.827389443652464','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','NCASHETH','4h','0.000014130000000','0.000014050000000','0.072144500000000','0.071736038570418','5105.767869780609','5105.767869780608635','test'),('2019-02-05 07:59:59','2019-02-05 15:59:59','NCASHETH','4h','0.000016230000000','0.000015980000000','0.072144500000000','0.071033216882317','4445.1324707332105','4445.132470733210539','test'),('2019-03-02 15:59:59','2019-03-03 03:59:59','NCASHETH','4h','0.000012710000000','0.000012780000000','0.072144500000000','0.072541833988985','5676.1998426435875','5676.199842643587544','test'),('2019-03-08 23:59:59','2019-03-09 03:59:59','NCASHETH','4h','0.000012810000000','0.000012850000000','0.072144500000000','0.072369775565964','5631.889149102264','5631.889149102264128','test'),('2019-03-20 11:59:59','2019-03-20 15:59:59','NCASHETH','4h','0.000013250000000','0.000013100000000','0.072144500000000','0.071327769811321','5444.867924528302','5444.867924528301955','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','NCASHETH','4h','0.000013390000000','0.000013240000000','0.072144500000000','0.071336309185960','5387.938760268858','5387.938760268857550','test'),('2019-03-24 15:59:59','2019-03-25 03:59:59','NCASHETH','4h','0.000013310000000','0.000013350000000','0.072144500000000','0.072361312922615','5420.323065364388','5420.323065364387730','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','NCASHETH','4h','0.000013250000000','0.000013220000000','0.072144500000000','0.071981153962264','5444.867924528302','5444.867924528301955','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','NCASHETH','4h','0.000013250000000','0.000013240000000','0.072144500000000','0.072090051320755','5444.867924528302','5444.867924528301955','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','NCASHETH','4h','0.000013360000000','0.000013360000000','0.072144500000000','0.072144500000000','5400.0374251497005','5400.037425149700539','test'),('2019-04-07 07:59:59','2019-04-07 11:59:59','NCASHETH','4h','0.000014140000000','0.000013700000000','0.072144500000000','0.069899550919378','5102.157001414427','5102.157001414427214','test'),('2019-04-24 15:59:59','2019-04-25 03:59:59','NCASHETH','4h','0.000012640000000','0.000011780000000','0.072144500000000','0.067235934335443','5707.6344936708865','5707.634493670886513','test'),('2019-04-25 11:59:59','2019-04-25 15:59:59','NCASHETH','4h','0.000011960000000','0.000011780000000','0.072144500000000','0.071058713210702','6032.148829431438','6032.148829431437662','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','NCASHETH','4h','0.000012010000000','0.000011600000000','0.072144500000000','0.069681615320566','6007.035803497086','6007.035803497085908','test'),('2019-05-01 11:59:59','2019-05-02 15:59:59','NCASHETH','4h','0.000012390000000','0.000011570000000','0.072144500000000','0.067369803470541','5822.800645682001','5822.800645682001232','test'),('2019-05-03 03:59:59','2019-05-03 07:59:59','NCASHETH','4h','0.000011600000000','0.000011470000000','0.072144500000000','0.071335984051724','6219.353448275861','6219.353448275861410','test'),('2019-05-04 23:59:59','2019-05-06 03:59:59','NCASHETH','4h','0.000011810000000','0.000011510000000','0.072144500000000','0.070311870872142','6108.763759525826','6108.763759525825662','test'),('2019-05-23 23:59:59','2019-05-24 03:59:59','NCASHETH','4h','0.000008930000000','0.000008880000000','0.072144500000000','0.071740555431131','8078.89137737962','8078.891377379620280','test'),('2019-05-28 11:59:59','2019-05-28 19:59:59','NCASHETH','4h','0.000008740000000','0.000008760000000','0.072144500000000','0.072309590389016','8254.519450800915','8254.519450800915365','test'),('2019-05-30 23:59:59','2019-05-31 03:59:59','NCASHETH','4h','0.000008800000000','0.000008830000000','0.072144500000000','0.072390447159091','8198.238636363636','8198.238636363636033','test'),('2019-06-01 19:59:59','2019-06-02 11:59:59','NCASHETH','4h','0.000008710000000','0.000008790000000','0.072144500000000','0.072807136050517','8282.950631458094','8282.950631458093994','test'),('2019-06-07 07:59:59','2019-06-11 11:59:59','NCASHETH','4h','0.000008970000000','0.000008850000000','0.072144500000000','0.071179356187291','8042.865105908584','8042.865105908584155','test'),('2019-06-15 19:59:59','2019-06-15 23:59:59','NCASHETH','4h','0.000009570000000','0.000009130000000','0.072144500000000','0.068827511494253','7538.610240334378','7538.610240334378432','test'),('2019-06-16 19:59:59','2019-06-16 23:59:59','NCASHETH','4h','0.000008860000000','0.000008820000000','0.072144500000000','0.071818791196388','8142.720090293454','8142.720090293453723','test'),('2019-06-25 07:59:59','2019-06-25 11:59:59','NCASHETH','4h','0.000008370000000','0.000007560000000','0.072144500000000','0.065162774193548','8619.414575866189','8619.414575866188898','test'),('2019-06-25 15:59:59','2019-06-29 23:59:59','NCASHETH','4h','0.000008330000000','0.000008170000000','0.072144500000000','0.070758771308523','8660.804321728692','8660.804321728692230','test'),('2019-06-30 03:59:59','2019-06-30 19:59:59','NCASHETH','4h','0.000008850000000','0.000008900000000','0.072144500000000','0.072552096045198','8151.920903954802','8151.920903954802270','test'),('2019-07-05 15:59:59','2019-07-05 19:59:59','NCASHETH','4h','0.000010290000000','0.000009500000000','0.072144500000000','0.066605709426628','7011.127308066084','7011.127308066083970','test'),('2019-07-05 23:59:59','2019-07-06 03:59:59','NCASHETH','4h','0.000009720000000','0.000010150000000','0.072144500000000','0.075336077674897','7422.27366255144','7422.273662551439884','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','NCASHETH','4h','0.000009850000000','0.000009750000000','0.072144500000000','0.071412068527919','7324.314720812183','7324.314720812182713','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:10:58
