-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 19:59:59','2018-05-14 23:59:59','LSKBTC','4h','0.001291300000000','0.001273600000000','0.001467500000000','0.001447384806009','1.1364516378843026','1.136451637884303','test'),('2018-05-17 15:59:59','2018-05-17 23:59:59','LSKBTC','4h','0.001320600000000','0.001265100000000','0.001467500000000','0.001405826328941','1.1112373163713465','1.111237316371346','test'),('2018-05-18 07:59:59','2018-05-18 11:59:59','LSKBTC','4h','0.001289000000000','0.001287100000000','0.001467500000000','0.001465336889061','1.1384794414274633','1.138479441427463','test'),('2018-06-02 07:59:59','2018-06-04 11:59:59','LSKBTC','4h','0.001203500000000','0.001248100000000','0.001467500000000','0.001521883464894','1.2193601994183632','1.219360199418363','test'),('2018-07-02 19:59:59','2018-07-03 19:59:59','LSKBTC','4h','0.000899100000000','0.000879900000000','0.001467500000000','0.001436161995329','1.6321877432988545','1.632187743298855','test'),('2018-07-04 19:59:59','2018-07-04 23:59:59','LSKBTC','4h','0.000884200000000','0.000888400000000','0.001467500000000','0.001474470707985','1.659692377290206','1.659692377290206','test'),('2018-08-16 03:59:59','2018-08-16 23:59:59','LSKBTC','4h','0.000514300000000','0.000610000000000','0.001467500000000','0.001740569706397','2.8533929613066307','2.853392961306631','test'),('2018-09-17 03:59:59','2018-09-17 07:59:59','LSKBTC','4h','0.000562200000000','0.000579100000000','0.001522283474654','0.001568044041573','2.7077258531732475','2.707725853173248','test'),('2018-09-30 23:59:59','2018-10-01 03:59:59','LSKBTC','4h','0.000507700000000','0.000505000000000','0.001533723616384','0.001525567118917','3.020924987953023','3.020924987953023','test'),('2018-10-09 07:59:59','2018-10-09 11:59:59','LSKBTC','4h','0.000503000000000','0.000493000000000','0.001533723616384','0.001503232093195','3.049152318854871','3.049152318854871','test'),('2018-10-10 03:59:59','2018-10-10 07:59:59','LSKBTC','4h','0.000500800000000','0.000495100000000','0.001533723616384','0.001516267097587','3.0625471573162937','3.062547157316294','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','LSKBTC','4h','0.000504200000000','0.000496100000000','0.001533723616384','0.001509084264356','3.0418953121459738','3.041895312145974','test'),('2018-10-22 15:59:59','2018-10-25 03:59:59','LSKBTC','4h','0.000458900000000','0.000453800000000','0.001533723616384','0.001516678529342','3.342173929797341','3.342173929797341','test'),('2018-11-05 19:59:59','2018-11-06 07:59:59','LSKBTC','4h','0.000440300000000','0.000439100000000','0.001533723616384','0.001529543583816','3.4833604732773105','3.483360473277310','test'),('2018-11-08 07:59:59','2018-11-08 11:59:59','LSKBTC','4h','0.000438700000000','0.000436400000000','0.001533723616384','0.001525682667404','3.4960647740688398','3.496064774068840','test'),('2018-11-12 15:59:59','2018-11-12 19:59:59','LSKBTC','4h','0.000436600000000','0.000432200000000','0.001533723616384','0.001518266942284','3.5128804772881357','3.512880477288136','test'),('2018-11-12 23:59:59','2018-11-13 03:59:59','LSKBTC','4h','0.000438100000000','0.000434200000000','0.001533723616384','0.001520070290422','3.5008528107372743','3.500852810737274','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','LSKBTC','4h','0.000363600000000','0.000355200000000','0.001533723616384','0.001498291057590','4.218161761232123','4.218161761232123','test'),('2018-11-28 19:59:59','2018-11-29 07:59:59','LSKBTC','4h','0.000367700000000','0.000358700000000','0.001533723616384','0.001496183468036','4.171127594190916','4.171127594190916','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','LSKBTC','4h','0.000365400000000','0.000360000000000','0.001533723616384','0.001511057750132','4.19738263925561','4.197382639255610','test'),('2018-12-04 19:59:59','2018-12-04 23:59:59','LSKBTC','4h','0.000356200000000','0.000354700000000','0.001533723616384','0.001527264926253','4.305793420505334','4.305793420505334','test'),('2018-12-06 07:59:59','2018-12-06 11:59:59','LSKBTC','4h','0.000362200000000','0.000349000000000','0.001533723616384','0.001477828664048','4.234466086096079','4.234466086096079','test'),('2018-12-08 03:59:59','2018-12-08 07:59:59','LSKBTC','4h','0.000357800000000','0.000354400000000','0.001533723616384','0.001519149384143','4.28653889430967','4.286538894309670','test'),('2018-12-09 15:59:59','2018-12-09 19:59:59','LSKBTC','4h','0.000354700000000','0.000352400000000','0.001533723616384','0.001523778411090','4.324002301618268','4.324002301618268','test'),('2018-12-15 07:59:59','2018-12-15 11:59:59','LSKBTC','4h','0.000348400000000','0.000346200000000','0.001533723616384','0.001524038794467','4.402191780665901','4.402191780665901','test'),('2018-12-16 03:59:59','2018-12-16 07:59:59','LSKBTC','4h','0.000348000000000','0.000351400000000','0.001533723616384','0.001548708272406','4.40725177121839','4.407251771218390','test'),('2018-12-18 19:59:59','2018-12-21 19:59:59','LSKBTC','4h','0.000355600000000','0.000358300000000','0.001533723616384','0.001545368874439','4.313058538762654','4.313058538762654','test'),('2018-12-22 23:59:59','2018-12-23 03:59:59','LSKBTC','4h','0.000363500000000','0.000363800000000','0.001533723616384','0.001534989413041','4.219322190877579','4.219322190877579','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','LSKBTC','4h','0.000371400000000','0.000372800000000','0.001533723616384','0.001539505019354','4.129573549768444','4.129573549768444','test'),('2019-01-17 07:59:59','2019-01-17 15:59:59','LSKBTC','4h','0.000341200000000','0.000339700000000','0.001533723616384','0.001526980986183','4.495086800656506','4.495086800656506','test'),('2019-01-22 19:59:59','2019-01-25 15:59:59','LSKBTC','4h','0.000350200000000','0.000345500000000','0.001533723616384','0.001513139661510','4.379564866887493','4.379564866887493','test'),('2019-02-10 19:59:59','2019-02-11 03:59:59','LSKBTC','4h','0.000319600000000','0.000317600000000','0.001533723616384','0.001524125846569','4.798884907334167','4.798884907334167','test'),('2019-02-11 11:59:59','2019-02-12 03:59:59','LSKBTC','4h','0.000321500000000','0.000317700000000','0.001533723616384','0.001515595623407','4.770524467757387','4.770524467757387','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','LSKBTC','4h','0.000320300000000','0.000319300000000','0.001533723616384','0.001528935219205','4.788397178844833','4.788397178844833','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','LSKBTC','4h','0.000319200000000','0.000318000000000','0.001533723616384','0.001527957738127','4.804898547568922','4.804898547568922','test'),('2019-02-16 15:59:59','2019-02-19 03:59:59','LSKBTC','4h','0.000322000000000','0.000321500000000','0.001533723616384','0.001531342057973','4.763116821068323','4.763116821068323','test'),('2019-02-23 03:59:59','2019-02-23 11:59:59','LSKBTC','4h','0.000320000000000','0.000317700000000','0.001533723616384','0.001522699977891','4.792886301199999','4.792886301199999','test'),('2019-02-23 19:59:59','2019-02-23 23:59:59','LSKBTC','4h','0.000320400000000','0.000314000000000','0.001533723616384','0.001503087439278','4.786902672858926','4.786902672858926','test'),('2019-02-26 19:59:59','2019-02-27 23:59:59','LSKBTC','4h','0.000320500000000','0.000317800000000','0.001533723616384','0.001520803011815','4.7854090994820595','4.785409099482060','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LSKBTC','4h','0.000318400000000','0.000316900000000','0.001533723616384','0.001526498159649','4.816971156984924','4.816971156984924','test'),('2019-02-28 19:59:59','2019-02-28 23:59:59','LSKBTC','4h','0.000318400000000','0.000318900000000','0.001533723616384','0.001536132101962','4.816971156984924','4.816971156984924','test'),('2019-03-02 23:59:59','2019-03-03 07:59:59','LSKBTC','4h','0.000320000000000','0.000319300000000','0.001533723616384','0.001530368595973','4.792886301199999','4.792886301199999','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','LSKBTC','4h','0.000317900000000','0.000318000000000','0.001533723616384','0.001534206071123','4.824547393469644','4.824547393469644','test'),('2019-03-10 23:59:59','2019-03-11 03:59:59','LSKBTC','4h','0.000326000000000','0.000324200000000','0.001533723616384','0.001525255203778','4.70467366988957','4.704673669889570','test'),('2019-03-11 23:59:59','2019-03-21 15:59:59','LSKBTC','4h','0.000333000000000','0.000369300000000','0.001533723616384','0.001700913307900','4.605776625777778','4.605776625777778','test'),('2019-04-03 07:59:59','2019-04-06 19:59:59','LSKBTC','4h','0.000404800000000','0.000419000000000','0.001533723616384','0.001587525185931','3.7888429258498024','3.788842925849802','test'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LSKBTC','4h','0.000397800000000','0.000384700000000','0.001533723616384','0.001483216378137','3.855514369994972','3.855514369994972','test'),('2019-04-16 07:59:59','2019-04-16 15:59:59','LSKBTC','4h','0.000398000000000','0.000391000000000','0.001533723616384','0.001506748577905','3.853576925587939','3.853576925587939','test'),('2019-04-17 07:59:59','2019-04-17 11:59:59','LSKBTC','4h','0.000394400000000','0.000390500000000','0.001533723616384','0.001518557485289','3.8887515628397566','3.888751562839757','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:42:36
