-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-08 15:59:59','2018-10-11 03:59:59','ADABNB','4h','0.008230000000000','0.007920000000000','0.711908500000000','0.685092991494532','86.50164034021873','86.501640340218728','test'),('2018-10-17 19:59:59','2018-10-18 11:59:59','ADABNB','4h','0.007920000000000','0.007800000000000','0.711908500000000','0.701122007575758','89.88743686868688','89.887436868686876','test'),('2018-10-19 19:59:59','2018-10-19 23:59:59','ADABNB','4h','0.007790000000000','0.007780000000000','0.711908500000000','0.710994625160462','91.38748395378691','91.387483953786912','test'),('2018-11-02 19:59:59','2018-11-02 23:59:59','ADABNB','4h','0.007560000000000','0.007590000000000','0.711908500000000','0.714733533730159','94.16779100529101','94.167791005291008','test'),('2018-11-04 03:59:59','2018-11-04 07:59:59','ADABNB','4h','0.007560000000000','0.007780000000000','0.711908500000000','0.732625414021164','94.16779100529101','94.167791005291008','test'),('2018-11-10 07:59:59','2018-11-10 11:59:59','ADABNB','4h','0.007820000000000','0.007820000000000','0.711908500000000','0.711908500000000','91.0368925831202','91.036892583120206','test'),('2018-11-17 23:59:59','2018-11-18 03:59:59','ADABNB','4h','0.007820000000000','0.007980000000000','0.711908500000000','0.726474402813299','91.0368925831202','91.036892583120206','test'),('2018-11-20 11:59:59','2018-11-20 15:59:59','ADABNB','4h','0.008000000000000','0.007870000000000','0.711908500000000','0.700339986875000','88.9885625','88.988562500000000','test'),('2018-11-21 11:59:59','2018-11-21 15:59:59','ADABNB','4h','0.007830000000000','0.007740000000000','0.711908500000000','0.703725643678161','90.92062579821201','90.920625798212015','test'),('2018-11-23 15:59:59','2018-11-23 19:59:59','ADABNB','4h','0.007830000000000','0.007770000000000','0.711908500000000','0.706453262452107','90.92062579821201','90.920625798212015','test'),('2018-11-24 03:59:59','2018-11-24 07:59:59','ADABNB','4h','0.007820000000000','0.007820000000000','0.711908500000000','0.711908500000000','91.0368925831202','91.036892583120206','test'),('2018-11-28 19:59:59','2018-11-30 11:59:59','ADABNB','4h','0.007890000000000','0.007610000000000','0.711908500000000','0.686644320025349','90.22921419518379','90.229214195183786','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','ADABNB','4h','0.007670000000000','0.007600000000000','0.711908500000000','0.705411290743155','92.81727509778358','92.817275097783579','test'),('2018-12-01 11:59:59','2018-12-02 19:59:59','ADABNB','4h','0.007710000000000','0.007870000000000','0.711908500000000','0.726682217250324','92.3357328145266','92.335732814526594','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','ADABNB','4h','0.006550000000000','0.006410000000000','0.711908500000000','0.696692135114504','108.68832061068703','108.688320610687029','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','ADABNB','4h','0.006570000000000','0.006530000000000','0.711908500000000','0.707574201674277','108.35745814307458','108.357458143074581','test'),('2018-12-20 15:59:59','2018-12-27 19:59:59','ADABNB','4h','0.006500000000000','0.006980000000000','0.711908500000000','0.764480204615385','109.52438461538463','109.524384615384633','test'),('2018-12-28 19:59:59','2018-12-28 23:59:59','ADABNB','4h','0.007070000000000','0.006980000000000','0.711908500000000','0.702846015558699','100.69427157001415','100.694271570014152','test'),('2018-12-29 03:59:59','2018-12-29 07:59:59','ADABNB','4h','0.007060000000000','0.007010000000000','0.711908500000000','0.706866655099150','100.83689801699717','100.836898016997168','test'),('2018-12-29 11:59:59','2018-12-29 15:59:59','ADABNB','4h','0.007020000000000','0.007290000000000','0.711908500000000','0.739289596153846','101.41146723646725','101.411467236467246','test'),('2019-01-02 07:59:59','2019-01-04 15:59:59','ADABNB','4h','0.007080000000000','0.007080000000000','0.712832376008833','0.712832376008833','100.68253898429839','100.682538984298390','test'),('2019-01-08 23:59:59','2019-01-09 03:59:59','ADABNB','4h','0.007340000000000','0.007530000000000','0.712832376008833','0.731284440237945','97.11612752163937','97.116127521639370','test'),('2019-01-09 11:59:59','2019-01-10 15:59:59','ADABNB','4h','0.007510000000000','0.007430000000000','0.717445392066111','0.709802831298429','95.53200959602005','95.532009596020046','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','ADABNB','4h','0.007380000000000','0.007340000000000','0.717445392066111','0.713556799155184','97.21482277318577','97.214822773185773','test'),('2019-01-17 03:59:59','2019-01-17 07:59:59','ADABNB','4h','0.007400000000000','0.007300000000000','0.717445392066111','0.707750184065218','96.95208000893392','96.952080008933919','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','ADABNB','4h','0.006490000000000','0.006450000000000','0.717445392066111','0.713023540651220','110.54628537228213','110.546285372282128','test'),('2019-02-18 15:59:59','2019-02-18 23:59:59','ADABNB','4h','0.004740000000000','0.004740000000000','0.717445392066111','0.717445392066111','151.35978735571962','151.359787355719618','test'),('2019-02-24 03:59:59','2019-02-24 11:59:59','ADABNB','4h','0.004570000000000','0.004500000000000','0.717445392066111','0.706456075338621','156.99023896413806','156.990238964138058','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','ADABNB','4h','0.004500000000000','0.004470000000000','0.717445392066111','0.712662422785670','159.4323093480247','159.432309348024688','test'),('2019-02-26 07:59:59','2019-02-26 11:59:59','ADABNB','4h','0.004500000000000','0.004520000000000','0.717445392066111','0.720634038253071','159.4323093480247','159.432309348024688','test'),('2019-03-15 15:59:59','2019-03-16 07:59:59','ADABNB','4h','0.003310000000000','0.003310000000000','0.717445392066111','0.717445392066111','216.7508737359852','216.750873735985209','test'),('2019-03-19 15:59:59','2019-03-24 11:59:59','ADABNB','4h','0.003300000000000','0.003600000000000','0.717445392066111','0.782667700435757','217.40769456548819','217.407694565488185','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','ADABNB','4h','0.003640000000000','0.003510000000000','0.724193005929681','0.698328970003621','198.95412250815414','198.954122508154143','test'),('2019-03-26 03:59:59','2019-04-01 11:59:59','ADABNB','4h','0.003610000000000','0.003860000000000','0.724193005929681','0.774344876146418','200.60748086694767','200.607480866947668','test'),('2019-04-01 19:59:59','2019-04-12 19:59:59','ADABNB','4h','0.003990000000000','0.004570000000000','0.730264964502350','0.836418768866100','183.02380062715545','183.023800627155453','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ADABNB','4h','0.004610000000000','0.004600000000000','0.756803415593288','0.755161759594170','164.16559991177607','164.165599911776070','test'),('2019-05-08 03:59:59','2019-05-08 07:59:59','ADABNB','4h','0.003080000000000','0.003060000000000','0.756803415593288','0.751889107699825','245.71539467314548','245.715394673145482','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','ADABNB','4h','0.003200000000000','0.003110000000000','0.756803415593288','0.735518319529727','236.5010673729025','236.501067372902497','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','ADABNB','4h','0.003130000000000','0.003070000000000','0.756803415593288','0.742296001875845','241.79022862405367','241.790228624053668','test'),('2019-05-13 15:59:59','2019-05-13 19:59:59','ADABNB','4h','0.003270000000000','0.003160000000000','0.756803415593288','0.731345196720119','231.43835339244282','231.438353392442821','test'),('2019-05-14 03:59:59','2019-05-14 11:59:59','ADABNB','4h','0.003260000000000','0.003270000000000','0.756803415593288','0.759124898463206','232.14828699180615','232.148286991806145','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','ADABNB','4h','0.002700000000000','0.002620000000000','0.756803415593288','0.734379610686820','280.2975613308474','280.297561330847373','test'),('2019-05-28 15:59:59','2019-05-29 07:59:59','ADABNB','4h','0.002710000000000','0.002670000000000','0.756803415593288','0.745632885473830','279.2632529864531','279.263252986453097','test'),('2019-05-29 15:59:59','2019-05-29 23:59:59','ADABNB','4h','0.002750000000000','0.002700000000000','0.756803415593288','0.743043353491592','275.20124203392294','275.201242033922938','test'),('2019-06-01 03:59:59','2019-06-01 07:59:59','ADABNB','4h','0.002730000000000','0.002670000000000','0.756803415593288','0.740170373492337','277.21736834918977','277.217368349189769','test'),('2019-06-02 03:59:59','2019-06-04 11:59:59','ADABNB','4h','0.002820000000000','0.002770000000000','0.756803415593288','0.743384915316811','268.37000552953475','268.370005529534751','test'),('2019-06-11 19:59:59','2019-06-12 03:59:59','ADABNB','4h','0.002780000000000','0.002620000000000','0.756803415593288','0.713246384480005','272.2314444580173','272.231444458017279','test'),('2019-06-12 11:59:59','2019-06-12 23:59:59','ADABNB','4h','0.002800000000000','0.002770000000000','0.756803415593288','0.748694807569074','270.28693414046','270.286934140460005','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','ADABNB','4h','0.002780000000000','0.002780000000000','0.756803415593288','0.756803415593288','272.2314444580173','272.231444458017279','test'),('2019-06-23 15:59:59','2019-06-23 23:59:59','ADABNB','4h','0.002670000000000','0.002600000000000','0.756803415593288','0.736962127544026','283.4469721323176','283.446972132317626','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','ADABNB','4h','0.002600000000000','0.002510000000000','0.756803415593288','0.730606374284290','291.07823676664924','291.078236766649241','test'),('2019-07-26 07:59:59','2019-08-01 07:59:59','ADABNB','4h','0.002077000000000','0.002114000000000','0.756803415593288','0.770285228966881','364.3733344214194','364.373334421419372','test'),('2019-08-18 19:59:59','2019-08-19 07:59:59','ADABNB','4h','0.001800000000000','0.001753000000000','0.756803415593288','0.737042437519463','420.44634199627114','420.446341996271144','test'),('2019-08-22 03:59:59','2019-08-22 11:59:59','ADABNB','4h','0.001795000000000','0.001792000000000','0.756803415593288','0.755538563088118','421.61750172328027','421.617501723280270','test'),('2019-09-06 23:59:59','2019-09-07 03:59:59','ADABNB','4h','0.002010000000000','0.001981000000000','0.756803415593288','0.745884361338459','376.51911223546665','376.519112235466650','test'),('2019-09-07 15:59:59','2019-09-18 11:59:59','ADABNB','4h','0.002020000000000','0.002256000000000','0.756803415593288','0.845222032464583','374.655156234301','374.655156234300989','test'),('2019-09-24 23:59:59','2019-09-29 07:59:59','ADABNB','4h','0.002354000000000','0.002406000000000','0.756803415593288','0.773521248053293','321.4967780770127','321.496778077012721','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:28:24
