-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-05 15:59:59','CNDBNB','4h','0.002414000000000','0.002427000000000','0.711908500000000','0.715742307166529','294.9082435791218','294.908243579121802','test'),('2018-07-06 11:59:59','2018-07-06 15:59:59','CNDBNB','4h','0.002418000000000','0.002449000000000','0.712866951791632','0.722006271686396','294.8167707988554','294.816770798855373','test'),('2018-07-08 07:59:59','2018-07-08 11:59:59','CNDBNB','4h','0.002383000000000','0.002330000000000','0.715151781765323','0.699246181919095','300.1056574760064','300.105657476006400','test'),('2018-07-08 19:59:59','2018-07-09 03:59:59','CNDBNB','4h','0.002445000000000','0.002357000000000','0.715151781765323','0.689412167534097','292.4956162639358','292.495616263935801','test'),('2018-07-11 15:59:59','2018-07-12 07:59:59','CNDBNB','4h','0.002464000000000','0.002335000000000','0.715151781765323','0.677710799684265','290.24017117099146','290.240171170991459','test'),('2018-07-12 15:59:59','2018-07-12 19:59:59','CNDBNB','4h','0.002434000000000','0.002395000000000','0.715151781765323','0.703692899477382','293.8174945625814','293.817494562581373','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','CNDBNB','4h','0.002381000000000','0.002373000000000','0.715151781765323','0.712748919835830','300.357741186612','300.357741186611975','test'),('2018-07-13 15:59:59','2018-07-14 03:59:59','CNDBNB','4h','0.002383000000000','0.002413000000000','0.715151781765323','0.724154951489603','300.1056574760063','300.105657476006286','test'),('2018-07-16 15:59:59','2018-07-16 19:59:59','CNDBNB','4h','0.002418000000000','0.002436000000000','0.715151781765323','0.720475492299556','295.7616963462874','295.761696346287408','test'),('2018-08-14 23:59:59','2018-08-15 03:59:59','CNDBNB','4h','0.001735000000000','0.001577000000000','0.715151781765323','0.650025567633380','412.1912286831833','412.191228683183283','test'),('2018-08-17 15:59:59','2018-08-17 19:59:59','CNDBNB','4h','0.001678000000000','0.001755000000000','0.715151781765323','0.747968639450621','426.19295695192073','426.192956951920735','test'),('2018-08-19 23:59:59','2018-08-20 03:59:59','CNDBNB','4h','0.001668000000000','0.001647000000000','0.715151781765323','0.706148072282666','428.74807060271166','428.748070602711664','test'),('2018-08-20 07:59:59','2018-08-20 11:59:59','CNDBNB','4h','0.001656000000000','0.001656000000000','0.715151781765323','0.715151781765323','431.8549406795429','431.854940679542892','test'),('2018-08-25 15:59:59','2018-08-25 23:59:59','CNDBNB','4h','0.001776000000000','0.001778000000000','0.715151781765323','0.715957132870915','402.67555279579','402.675552795789997','test'),('2018-08-26 19:59:59','2018-08-26 23:59:59','CNDBNB','4h','0.001750000000000','0.001712000000000','0.715151781765323','0.699622771646990','408.658161008756','408.658161008755997','test'),('2018-08-27 03:59:59','2018-08-27 07:59:59','CNDBNB','4h','0.001752000000000','0.001681000000000','0.715151781765323','0.686170174170952','408.191656258746','408.191656258745979','test'),('2018-08-28 03:59:59','2018-08-30 19:59:59','CNDBNB','4h','0.001803000000000','0.001745000000000','0.715151781765323','0.692146344526061','396.6454696424421','396.645469642442094','test'),('2018-09-01 19:59:59','2018-09-02 11:59:59','CNDBNB','4h','0.001788000000000','0.001759000000000','0.715151781765323','0.703552563828413','399.97303230722764','399.973032307227641','test'),('2018-09-02 19:59:59','2018-09-03 03:59:59','CNDBNB','4h','0.001811000000000','0.001718000000000','0.715151781765323','0.678426704071135','394.89330853965936','394.893308539659358','test'),('2018-09-03 19:59:59','2018-09-03 23:59:59','CNDBNB','4h','0.001781000000000','0.001752000000000','0.715151781765323','0.703506974538375','401.54507679130995','401.545076791309953','test'),('2018-09-04 15:59:59','2018-09-05 11:59:59','CNDBNB','4h','0.001827000000000','0.001721000000000','0.715151781765323','0.673659669632250','391.4350201233295','391.435020123329480','test'),('2018-09-12 23:59:59','2018-09-19 19:59:59','CNDBNB','4h','0.001929000000000','0.002135000000000','0.715151781765323','0.791523615380490','370.7370563843043','370.737056384304310','test'),('2018-09-25 15:59:59','2018-09-25 23:59:59','CNDBNB','4h','0.002260000000000','0.002178000000000','0.715151781765323','0.689203796763218','316.43884148908097','316.438841489080971','test'),('2018-09-26 07:59:59','2018-09-26 11:59:59','CNDBNB','4h','0.002274000000000','0.002222000000000','0.715151781765323','0.698798266966820','314.490669201989','314.490669201989022','test'),('2018-09-26 23:59:59','2018-09-27 03:59:59','CNDBNB','4h','0.002248000000000','0.002240000000000','0.715151781765323','0.712606757630927','318.12801679952094','318.128016799520935','test'),('2018-09-28 03:59:59','2018-09-28 11:59:59','CNDBNB','4h','0.002253000000000','0.002200000000000','0.715151781765323','0.698328415394457','317.4220069974803','317.422006997480310','test'),('2018-09-30 07:59:59','2018-09-30 11:59:59','CNDBNB','4h','0.002265000000000','0.002172000000000','0.715151781765323','0.685787933772310','315.7403010001426','315.740301000142608','test'),('2018-10-01 19:59:59','2018-10-02 15:59:59','CNDBNB','4h','0.002244000000000','0.002196000000000','0.715151781765323','0.699854417449487','318.69508991324557','318.695089913245567','test'),('2018-10-07 03:59:59','2018-10-07 11:59:59','CNDBNB','4h','0.002202000000000','0.002145000000000','0.715151781765323','0.696639678422624','324.77374285437014','324.773742854370141','test'),('2018-10-09 15:59:59','2018-10-09 19:59:59','CNDBNB','4h','0.002189000000000','0.002134000000000','0.715151781765323','0.697183144032526','326.70250423267385','326.702504232673846','test'),('2018-10-09 23:59:59','2018-10-10 03:59:59','CNDBNB','4h','0.002229000000000','0.002203000000000','0.715151781765323','0.706809948510097','320.83974058560926','320.839740585609263','test'),('2018-10-13 19:59:59','2018-10-14 03:59:59','CNDBNB','4h','0.002177000000000','0.002116000000000','0.715151781765323','0.695113077728720','328.503344862344','328.503344862344022','test'),('2018-10-14 11:59:59','2018-10-14 23:59:59','CNDBNB','4h','0.002184000000000','0.002099000000000','0.715151781765323','0.687318493555592','327.45044952624676','327.450449526246757','test'),('2018-10-16 11:59:59','2018-10-25 07:59:59','CNDBNB','4h','0.002226000000000','0.002459000000000','0.715151781765323','0.790008190189097','321.27213915782704','321.272139157827041','test'),('2018-10-27 07:59:59','2018-10-27 11:59:59','CNDBNB','4h','0.002491000000000','0.002429000000000','0.715151781765323','0.697351938140494','287.09425201337734','287.094252013377343','test'),('2018-10-27 23:59:59','2018-10-29 15:59:59','CNDBNB','4h','0.002528000000000','0.002615000000000','0.715151781765323','0.739763413495380','282.89231873628285','282.892318736282846','test'),('2018-10-30 15:59:59','2018-10-30 19:59:59','CNDBNB','4h','0.002543000000000','0.002539000000000','0.715151781765323','0.714026887102696','281.2236656568317','281.223665656831713','test'),('2018-11-09 11:59:59','2018-11-10 03:59:59','CNDBNB','4h','0.002573000000000','0.002705000000000','0.715151781765323','0.751840485687990','277.9447266868725','277.944726686872514','test'),('2018-11-23 19:59:59','2018-11-23 23:59:59','CNDBNB','4h','0.002347000000000','0.002480000000000','0.715151781765323','0.755678065095015','304.708897215732','304.708897215732009','test'),('2018-11-28 11:59:59','2018-11-30 03:59:59','CNDBNB','4h','0.002371000000000','0.002315000000000','0.715151781765323','0.698260807586134','301.6245389140966','301.624538914096604','test'),('2018-12-07 19:59:59','2018-12-07 23:59:59','CNDBNB','4h','0.002231000000000','0.002123000000000','0.715151781765323','0.680532152706311','320.55212091677413','320.552120916774129','test'),('2018-12-20 19:59:59','2018-12-21 11:59:59','CNDBNB','4h','0.002018000000000','0.001984000000000','0.715151781765323','0.703102643717741','354.38641316418386','354.386413164183864','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','CNDBNB','4h','0.001745000000000','0.001691000000000','0.715151781765323','0.693021010295221','409.82910129817935','409.829101298179353','test'),('2019-01-06 23:59:59','2019-01-07 07:59:59','CNDBNB','4h','0.001797000000000','0.001731000000000','0.715151781765323','0.688885773086129','397.9698284726338','397.969828472633822','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','CNDBNB','4h','0.001655000000000','0.001630000000000','0.715151781765323','0.704348884759805','432.115880220739','432.115880220738973','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','CNDBNB','4h','0.001669000000000','0.001618000000000','0.715151781765323','0.693298731513657','428.49118140522654','428.491181405226541','test'),('2019-01-15 03:59:59','2019-01-17 07:59:59','CNDBNB','4h','0.001651000000000','0.001711000000000','0.715151781765323','0.741141549727721','433.1627993733029','433.162799373302903','test'),('2019-01-18 11:59:59','2019-01-19 19:59:59','CNDBNB','4h','0.001812000000000','0.001747000000000','0.715151781765323','0.689497882309061','394.67537625017826','394.675376250178260','test'),('2019-01-22 07:59:59','2019-01-22 11:59:59','CNDBNB','4h','0.001779000000000','0.001780000000000','0.715151781765323','0.715553778269969','401.99650464605','401.996504646050028','test'),('2019-01-25 03:59:59','2019-01-25 07:59:59','CNDBNB','4h','0.001739000000000','0.001704000000000','0.715151781765323','0.700758272644112','411.2431177488919','411.243117748891905','test'),('2019-01-30 03:59:59','2019-01-30 19:59:59','CNDBNB','4h','0.001651000000000','0.001619000000000','0.715151781765323','0.701290572185377','433.1627993733029','433.162799373302903','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','CNDBNB','4h','0.001634000000000','0.001606000000000','0.715151781765323','0.702897038870936','437.669389085265','437.669389085264982','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','CNDBNB','4h','0.001215000000000','0.001201000000000','0.715151781765323','0.706911349712060','588.6022895187845','588.602289518784460','test'),('2019-02-28 19:59:59','2019-02-28 23:59:59','CNDBNB','4h','0.001251000000000','0.001288000000000','0.715151781765323','0.736303353248390','571.6640941369488','571.664094136948847','test'),('2019-03-14 03:59:59','2019-03-14 15:59:59','CNDBNB','4h','0.001027000000000','0.001012000000000','0.715151781765323','0.704706526919676','696.3503230431578','696.350323043157800','test'),('2019-03-15 15:59:59','2019-03-16 03:59:59','CNDBNB','4h','0.001009000000000','0.001000000000000','0.715151781765323','0.708772826328368','708.7728263283677','708.772826328367728','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','CNDBNB','4h','0.000996000000000','0.001005000000000','0.715151781765323','0.721613996660793','718.0238772744208','718.023877274420784','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','CNDBNB','4h','0.000979000000000','0.000979000000000','0.715151781765323','0.715151781765323','730.4921162056414','730.492116205641423','test'),('2019-03-29 03:59:59','2019-03-29 07:59:59','CNDBNB','4h','0.000976000000000','0.000964000000000','0.715151781765323','0.706358931989520','732.7374813169293','732.737481316929347','test'),('2019-03-29 11:59:59','2019-03-31 03:59:59','CNDBNB','4h','0.000985000000000','0.000972000000000','0.715151781765323','0.705713230330857','726.0424180358609','726.042418035860919','test'),('2019-03-31 11:59:59','2019-04-01 07:59:59','CNDBNB','4h','0.000993000000000','0.001005000000000','0.715151781765323','0.723794099369738','720.1931337012317','720.193133701231659','test'),('2019-04-04 23:59:59','2019-04-06 11:59:59','CNDBNB','4h','0.001009000000000','0.001007000000000','0.715151781765323','0.713734236112666','708.7728263283677','708.772826328367728','test'),('2019-04-09 19:59:59','2019-04-09 23:59:59','CNDBNB','4h','0.001027000000000','0.001024000000000','0.715151781765323','0.713062730796194','696.3503230431578','696.350323043157800','test'),('2019-04-13 15:59:59','2019-04-13 19:59:59','CNDBNB','4h','0.001058000000000','0.001008000000000','0.715151781765323','0.681354438581707','675.946863672328','675.946863672328050','test'),('2019-04-16 03:59:59','2019-04-16 15:59:59','CNDBNB','4h','0.001016000000000','0.001015000000000','0.715151781765323','0.714447892216342','703.8895489816172','703.889548981617168','test'),('2019-05-01 19:59:59','2019-05-01 23:59:59','CNDBNB','4h','0.000800000000000','0.000789000000000','0.715151781765323','0.705318444766050','893.9397272066537','893.939727206653743','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','CNDBNB','4h','0.000730000000000','0.000730000000000','0.715151781765323','0.715151781765323','979.6599750209905','979.659975020990487','test'),('2019-05-11 03:59:59','2019-05-11 07:59:59','CNDBNB','4h','0.000765000000000','0.000739000000000','0.715151781765323','0.690845969574606','934.838930412187','934.838930412186983','test'),('2019-05-11 23:59:59','2019-05-12 11:59:59','CNDBNB','4h','0.000779000000000','0.000724000000000','0.715151781765323','0.664659679073291','918.0382307642144','918.038230764214404','test'),('2019-05-21 11:59:59','2019-05-21 15:59:59','CNDBNB','4h','0.000667000000000','0.000610000000000','0.715151781765323','0.654036861884328','1072.1915768595547','1072.191576859554743','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 19:17:26
