-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-06 03:59:59','2018-09-06 07:59:59','XEMBNB','4h','0.010390000000000','0.010130000000000','0.711908500000000','0.694093657844081','68.51862367661214','68.518623676612137','test'),('2018-09-07 07:59:59','2018-09-07 11:59:59','XEMBNB','4h','0.010290000000000','0.010030000000000','0.711908500000000','0.693920530126336','69.18449951409136','69.184499514091357','test'),('2018-09-08 03:59:59','2018-09-08 11:59:59','XEMBNB','4h','0.010200000000000','0.010160000000000','0.711908500000000','0.709116701960784','69.79495098039216','69.794950980392159','test'),('2018-09-08 19:59:59','2018-09-08 23:59:59','XEMBNB','4h','0.010260000000000','0.010240000000000','0.711908500000000','0.710520764132554','69.38679337231969','69.386793372319687','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','XEMBNB','4h','0.009490000000000','0.009320000000000','0.711908500000000','0.699155660695469','75.01670179135932','75.016701791359324','test'),('2018-09-25 15:59:59','2018-09-25 19:59:59','XEMBNB','4h','0.009700000000000','0.009400000000000','0.711908500000000','0.689890711340206','73.39262886597939','73.392628865979390','test'),('2018-09-26 11:59:59','2018-09-26 23:59:59','XEMBNB','4h','0.009520000000000','0.009530000000000','0.711908500000000','0.712656303046219','74.78030462184874','74.780304621848742','test'),('2018-09-29 11:59:59','2018-09-29 15:59:59','XEMBNB','4h','0.009700000000000','0.009570000000000','0.711908500000000','0.702367458247423','73.39262886597939','73.392628865979390','test'),('2018-10-03 23:59:59','2018-10-05 07:59:59','XEMBNB','4h','0.009860000000000','0.010210000000000','0.711908500000000','0.737179085699797','72.20167342799189','72.201673427991892','test'),('2018-10-06 15:59:59','2018-10-06 19:59:59','XEMBNB','4h','0.009950000000000','0.009890000000000','0.711908500000000','0.707615584422111','71.54859296482412','71.548592964824124','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','XEMBNB','4h','0.009980000000000','0.009890000000000','0.711908500000000','0.705488483466934','71.33351703406815','71.333517034068151','test'),('2018-10-07 07:59:59','2018-10-10 07:59:59','XEMBNB','4h','0.009990000000000','0.010140000000000','0.711908500000000','0.722597816816817','71.2621121121121','71.262112112112106','test'),('2018-10-20 11:59:59','2018-10-20 15:59:59','XEMBNB','4h','0.009790000000000','0.009780000000000','0.711908500000000','0.711181320735444','72.71792645556691','72.717926455566911','test'),('2018-10-25 19:59:59','2018-10-25 23:59:59','XEMBNB','4h','0.009990000000000','0.009960000000000','0.711908500000000','0.709770636636637','71.2621121121121','71.262112112112106','test'),('2018-10-26 07:59:59','2018-10-26 11:59:59','XEMBNB','4h','0.009960000000000','0.010020000000000','0.711908500000000','0.716197105421687','71.47675702811246','71.476757028112459','test'),('2018-10-26 19:59:59','2018-10-26 23:59:59','XEMBNB','4h','0.009990000000000','0.009920000000000','0.711908500000000','0.706920152152152','71.2621121121121','71.262112112112106','test'),('2018-11-02 19:59:59','2018-11-03 07:59:59','XEMBNB','4h','0.009880000000000','0.009840000000000','0.711908500000000','0.709026279352227','72.05551619433199','72.055516194331986','test'),('2018-11-04 15:59:59','2018-11-04 19:59:59','XEMBNB','4h','0.009770000000000','0.009700000000000','0.711908500000000','0.706807824974412','72.86678607983625','72.866786079836245','test'),('2018-11-04 23:59:59','2018-11-05 15:59:59','XEMBNB','4h','0.009810000000000','0.009700000000000','0.711908500000000','0.703925835881753','72.56967380224262','72.569673802242619','test'),('2018-11-06 11:59:59','2018-11-06 15:59:59','XEMBNB','4h','0.009740000000000','0.009830000000000','0.711908500000000','0.718486709958932','73.09122176591376','73.091221765913758','test'),('2018-11-10 19:59:59','2018-11-11 15:59:59','XEMBNB','4h','0.009810000000000','0.009850000000000','0.711908500000000','0.714811286952090','72.56967380224262','72.569673802242619','test'),('2018-12-06 23:59:59','2018-12-07 03:59:59','XEMBNB','4h','0.014010000000000','0.013990000000000','0.711908500000000','0.710892213775874','50.81431120628123','50.814311206281232','test'),('2018-12-21 23:59:59','2018-12-22 03:59:59','XEMBNB','4h','0.013690000000000','0.013050000000000','0.711908500000000','0.678627167640614','52.002081811541274','52.002081811541274','test'),('2019-02-23 23:59:59','2019-02-24 11:59:59','XEMBNB','4h','0.004510000000000','0.004390000000000','0.711908500000000','0.692966366962306','157.85110864745013','157.851108647450133','test'),('2019-02-25 23:59:59','2019-02-27 15:59:59','XEMBNB','4h','0.004430000000000','0.004380000000000','0.711908500000000','0.703873415349887','160.70169300225734','160.701693002257343','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','XEMBNB','4h','0.003280000000000','0.003210000000000','0.711908500000000','0.696715330792683','217.04527439024392','217.045274390243918','test'),('2019-03-14 23:59:59','2019-03-15 03:59:59','XEMBNB','4h','0.003260000000000','0.003320000000000','0.711908500000000','0.725011110429448','218.37684049079758','218.376840490797576','test'),('2019-03-20 07:59:59','2019-03-21 19:59:59','XEMBNB','4h','0.003280000000000','0.003300000000000','0.711908500000000','0.716249405487805','217.04527439024392','217.045274390243918','test'),('2019-03-29 03:59:59','2019-03-30 23:59:59','XEMBNB','4h','0.003230000000000','0.003160000000000','0.711908500000000','0.696480142414861','220.40510835913315','220.405108359133152','test'),('2019-03-31 19:59:59','2019-03-31 23:59:59','XEMBNB','4h','0.003210000000000','0.003190000000000','0.711908500000000','0.707472933021807','221.77834890965732','221.778348909657325','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XEMBNB','4h','0.003270000000000','0.003230000000000','0.711908500000000','0.703200139143731','217.70902140672786','217.709021406727857','test'),('2019-04-12 11:59:59','2019-04-12 15:59:59','XEMBNB','4h','0.003740000000000','0.003640000000000','0.711908500000000','0.692873513368984','190.34986631016045','190.349866310160451','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','XEMBNB','4h','0.002500000000000','0.002520000000000','0.711908500000000','0.717603768000000','284.7634','284.763399999999990','test'),('2019-05-13 15:59:59','2019-05-13 19:59:59','XEMBNB','4h','0.002600000000000','0.002460000000000','0.711908500000000','0.673574965384615','273.8109615384616','273.810961538461584','test'),('2019-05-14 07:59:59','2019-05-15 15:59:59','XEMBNB','4h','0.002690000000000','0.002620000000000','0.711908500000000','0.693383000000000','264.65000000000003','264.650000000000034','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','XEMBNB','4h','0.002750000000000','0.002650000000000','0.711908500000000','0.686020918181818','258.8758181818182','258.875818181818204','test'),('2019-05-28 15:59:59','2019-05-29 07:59:59','XEMBNB','4h','0.002710000000000','0.002700000000000','0.711908500000000','0.709281531365314','262.6968634686347','262.696863468634717','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','XEMBNB','4h','0.002750000000000','0.002680000000000','0.711908500000000','0.693787192727273','258.8758181818182','258.875818181818204','test'),('2019-05-30 03:59:59','2019-05-31 07:59:59','XEMBNB','4h','0.002730000000000','0.003210000000000','0.711908500000000','0.837079225274726','260.77234432234434','260.772344322344338','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','XEMBNB','4h','0.002820000000000','0.002760000000000','0.711908500000000','0.696761510638298','252.44982269503546','252.449822695035465','test'),('2019-06-14 15:59:59','2019-06-14 19:59:59','XEMBNB','4h','0.002670000000000','0.002600000000000','0.711908500000000','0.693244232209738','266.6323970037453','266.632397003745325','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','XEMBNB','4h','0.002660000000000','0.002550000000000','0.711908500000000','0.682468674812030','267.63477443609025','267.634774436090254','test'),('2019-06-16 07:59:59','2019-06-17 15:59:59','XEMBNB','4h','0.002710000000000','0.002660000000000','0.711908500000000','0.698773656826568','262.6968634686347','262.696863468634717','test'),('2019-06-25 15:59:59','2019-06-25 23:59:59','XEMBNB','4h','0.002490000000000','0.002550000000000','0.711908500000000','0.729062921686747','285.90702811244984','285.907028112449836','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','XEMBNB','4h','0.002740000000000','0.002700000000000','0.711908500000000','0.701515675182482','259.8206204379562','259.820620437956222','test'),('2019-07-07 19:59:59','2019-07-08 07:59:59','XEMBNB','4h','0.002740000000000','0.002710000000000','0.711908500000000','0.704113881386861','259.8206204379562','259.820620437956222','test'),('2019-07-08 19:59:59','2019-07-09 11:59:59','XEMBNB','4h','0.002730000000000','0.002710000000000','0.711908500000000','0.706693053113553','260.77234432234434','260.772344322344338','test'),('2019-07-28 03:59:59','2019-07-28 07:59:59','XEMBNB','4h','0.002318000000000','0.002311000000000','0.711908500000000','0.709758646893874','307.1218723037101','307.121872303710120','test'),('2019-07-29 03:59:59','2019-08-01 07:59:59','XEMBNB','4h','0.002311000000000','0.002320000000000','0.711908500000000','0.714680969277369','308.0521419299005','308.052141929900472','test'),('2019-08-04 23:59:59','2019-08-05 07:59:59','XEMBNB','4h','0.002321000000000','0.002321000000000','0.711908500000000','0.711908500000000','306.7249030590263','306.724903059026303','test'),('2019-08-06 11:59:59','2019-08-06 15:59:59','XEMBNB','4h','0.002387000000000','0.002311000000000','0.711908500000000','0.689241953707583','298.24403016338505','298.244030163385048','test'),('2019-08-06 23:59:59','2019-08-07 03:59:59','XEMBNB','4h','0.002318000000000','0.002308000000000','0.711908500000000','0.708837281276963','307.1218723037101','307.121872303710120','test'),('2019-08-07 07:59:59','2019-08-07 11:59:59','XEMBNB','4h','0.002322000000000','0.002339000000000','0.711908500000000','0.717120577734711','306.5928079242033','306.592807924203328','test'),('2019-08-21 03:59:59','2019-08-21 07:59:59','XEMBNB','4h','0.002023000000000','0.002012000000000','0.711908500000000','0.708037519525457','351.9073158675235','351.907315867523494','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','XEMBNB','4h','0.002038000000000','0.002054000000000','0.711908500000000','0.717497575564279','349.3172227674191','349.317222767419082','test'),('2019-08-28 23:59:59','2019-09-03 15:59:59','XEMBNB','4h','0.002097000000000','0.002162000000000','0.711908500000000','0.733975287076776','339.4890319504054','339.489031950405376','test'),('2019-09-03 23:59:59','2019-09-04 03:59:59','XEMBNB','4h','0.002200000000000','0.002196000000000','0.711908500000000','0.710614120909091','323.59477272727275','323.594772727272755','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:46:54
