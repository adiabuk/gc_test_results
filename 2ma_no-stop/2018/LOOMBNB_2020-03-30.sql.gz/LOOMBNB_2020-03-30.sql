-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-19 19:59:59','2018-10-23 15:59:59','LOOMBNB','4h','0.012210000000000','0.012550000000000','0.711908500000000','0.731732323914824','58.30536445536446','58.305364455364462','test'),('2018-10-26 03:59:59','2018-10-26 07:59:59','LOOMBNB','4h','0.012710000000000','0.012370000000000','0.716864455978706','0.697687908769205','56.40160943970937','56.401609439709368','test'),('2018-10-28 19:59:59','2018-10-28 23:59:59','LOOMBNB','4h','0.012490000000000','0.012420000000000','0.716864455978706','0.712846800901163','57.39507253632554','57.395072536325543','test'),('2018-10-31 03:59:59','2018-10-31 15:59:59','LOOMBNB','4h','0.012390000000000','0.012440000000000','0.716864455978706','0.719757371458846','57.85830960280113','57.858309602801128','test'),('2018-11-09 03:59:59','2018-11-09 07:59:59','LOOMBNB','4h','0.011930000000000','0.011900000000000','0.716864455978706','0.715061779224359','60.089225144904105','60.089225144904105','test'),('2018-11-11 23:59:59','2018-11-12 03:59:59','LOOMBNB','4h','0.011800000000000','0.012130000000000','0.716864455978706','0.736912360256077','60.75122508294118','60.751225082941183','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','LOOMBNB','4h','0.009920000000000','0.009900000000000','0.716864455978706','0.715419164736813','72.26456209462762','72.264562094627621','test'),('2018-11-30 15:59:59','2018-12-01 03:59:59','LOOMBNB','4h','0.010190000000000','0.010440000000000','0.716864455978706','0.734451905830980','70.34979940909774','70.349799409097741','test'),('2018-12-07 19:59:59','2018-12-10 03:59:59','LOOMBNB','4h','0.010820000000000','0.009790000000000','0.720385980810331','0.651809496500290','66.57911098062212','66.579110980622119','test'),('2018-12-21 11:59:59','2018-12-21 15:59:59','LOOMBNB','4h','0.008770000000000','0.008680000000000','0.720385980810331','0.712993194234170','82.14207306845279','82.142073068452788','test'),('2018-12-24 03:59:59','2018-12-24 07:59:59','LOOMBNB','4h','0.008700000000000','0.008270000000000','0.720385980810331','0.684780696701315','82.80298630003806','82.802986300038057','test'),('2019-01-02 15:59:59','2019-01-02 19:59:59','LOOMBNB','4h','0.007930000000000','0.008180000000000','0.720385980810331','0.743096762046470','90.84312494455625','90.843124944556251','test'),('2019-01-04 23:59:59','2019-01-05 15:59:59','LOOMBNB','4h','0.008050000000000','0.007980000000000','0.720385980810331','0.714121754890241','89.48894171556907','89.488941715569069','test'),('2019-01-07 15:59:59','2019-01-08 03:59:59','LOOMBNB','4h','0.008390000000000','0.007850000000000','0.720385980810331','0.674020256181299','85.86245301672598','85.862453016725979','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','LOOMBNB','4h','0.007630000000000','0.007890000000000','0.720385980810331','0.744933864822216','94.41493850725178','94.414938507251776','test'),('2019-01-23 15:59:59','2019-01-23 19:59:59','LOOMBNB','4h','0.007140000000000','0.007090000000000','0.720385980810331','0.715341261056757','100.89439507147493','100.894395071474932','test'),('2019-01-23 23:59:59','2019-01-24 03:59:59','LOOMBNB','4h','0.007110000000000','0.007100000000000','0.720385980810331','0.719372779712145','101.32010981861195','101.320109818611954','test'),('2019-01-24 07:59:59','2019-01-24 11:59:59','LOOMBNB','4h','0.007260000000000','0.007250000000000','0.720385980810331','0.719393713619132','99.2267191198803','99.226719119880300','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','LOOMBNB','4h','0.006930000000000','0.006810000000000','0.720385980810331','0.707911764692403','103.95180098273174','103.951800982731740','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','LOOMBNB','4h','0.004870000000000','0.004570000000000','0.720385980810331','0.676009021006820','147.92319934503715','147.923199345037148','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','LOOMBNB','4h','0.004820000000000','0.004760000000000','0.720385980810331','0.711418520468294','149.4576723672886','149.457672367288609','test'),('2019-02-23 19:59:59','2019-02-24 15:59:59','LOOMBNB','4h','0.004680000000000','0.004640000000000','0.720385980810331','0.714228835675200','153.92862837827585','153.928628378275846','test'),('2019-02-25 07:59:59','2019-02-25 11:59:59','LOOMBNB','4h','0.004710000000000','0.004620000000000','0.720385980810331','0.706620643597395','152.94819125484736','152.948191254847359','test'),('2019-02-25 15:59:59','2019-02-28 11:59:59','LOOMBNB','4h','0.004730000000000','0.004810000000000','0.720385980810331','0.732570098879005','152.30147585842093','152.301475858420929','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','LOOMBNB','4h','0.005010000000000','0.004720000000000','0.720385980810331','0.678686991901150','143.7896169282098','143.789616928209796','test'),('2019-03-03 07:59:59','2019-03-03 11:59:59','LOOMBNB','4h','0.004940000000000','0.004870000000000','0.720385980810331','0.710178082296824','145.8271216215245','145.827121621524498','test'),('2019-03-03 23:59:59','2019-03-04 07:59:59','LOOMBNB','4h','0.005020000000000','0.005160000000000','0.720385980810331','0.740476426490300','143.5031834283528','143.503183428352799','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','LOOMBNB','4h','0.004600000000000','0.004900000000000','0.720385980810331','0.767367675211005','156.60564800224589','156.605648002245886','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','LOOMBNB','4h','0.004460000000000','0.004370000000000','0.720385980810331','0.705849043977835','161.52152036106074','161.521520361060738','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','LOOMBNB','4h','0.004480000000000','0.004350000000000','0.720385980810331','0.699481923331460','160.80044214516317','160.800442145163174','test'),('2019-03-15 03:59:59','2019-03-15 07:59:59','LOOMBNB','4h','0.004470000000000','0.004330000000000','0.720385980810331','0.697823556355421','161.1601746779264','161.160174677926392','test'),('2019-03-15 15:59:59','2019-03-16 07:59:59','LOOMBNB','4h','0.004490000000000','0.004350000000000','0.720385980810331','0.697924057132503','160.44231198448352','160.442311984483524','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','LOOMBNB','4h','0.004400000000000','0.004220000000000','0.720385980810331','0.690915645231726','163.7240865478025','163.724086547802500','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','LOOMBNB','4h','0.004390000000000','0.004360000000000','0.720385980810331','0.715463069779737','164.09703435315058','164.097034353150576','test'),('2019-03-28 19:59:59','2019-03-29 03:59:59','LOOMBNB','4h','0.004450000000000','0.004260000000000','0.720385980810331','0.689627927697081','161.8844900697373','161.884490069737296','test'),('2019-03-29 19:59:59','2019-03-29 23:59:59','LOOMBNB','4h','0.004410000000000','0.004370000000000','0.720385980810331','0.713851867605702','163.35283011572133','163.352830115721332','test'),('2019-04-01 03:59:59','2019-04-01 11:59:59','LOOMBNB','4h','0.004670000000000','0.004140000000000','0.720385980810331','0.638629113609159','154.2582400022122','154.258240002212204','test'),('2019-04-07 15:59:59','2019-04-08 07:59:59','LOOMBNB','4h','0.004350000000000','0.004200000000000','0.720385980810331','0.695545084920320','165.60597260007611','165.605972600076115','test'),('2019-04-08 15:59:59','2019-04-09 03:59:59','LOOMBNB','4h','0.004250000000000','0.004200000000000','0.720385980810331','0.711910851624327','169.50258372007787','169.502583720077865','test'),('2019-05-01 03:59:59','2019-05-01 07:59:59','LOOMBNB','4h','0.002870000000000','0.002900000000000','0.720385980810331','0.727916147857129','251.00556822659615','251.005568226596154','test'),('2019-05-06 07:59:59','2019-05-08 03:59:59','LOOMBNB','4h','0.002820000000000','0.002840000000000','0.720385980810331','0.725495101241610','255.45602156394716','255.456021563947161','test'),('2019-05-09 15:59:59','2019-05-09 19:59:59','LOOMBNB','4h','0.002830000000000','0.002780000000000','0.720385980810331','0.707658313304848','254.5533501096576','254.553350109657600','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','LOOMBNB','4h','0.002840000000000','0.002860000000000','0.720385980810331','0.725459121520263','253.65703549659543','253.657035496595427','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','LOOMBNB','4h','0.002960000000000','0.002880000000000','0.720385980810331','0.700916089437079','243.37364216565237','243.373642165652370','test'),('2019-05-17 15:59:59','2019-05-17 23:59:59','LOOMBNB','4h','0.002820000000000','0.002770000000000','0.720385980810331','0.707613179732134','255.45602156394716','255.456021563947161','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','LOOMBNB','4h','0.002390000000000','0.002370000000000','0.720385980810331','0.714357646242881','301.4167283725234','301.416728372523380','test'),('2019-05-28 23:59:59','2019-05-29 15:59:59','LOOMBNB','4h','0.002360000000000','0.002420000000000','0.720385980810331','0.738700878627543','305.2482969535301','305.248296953530087','test'),('2019-05-30 11:59:59','2019-05-30 23:59:59','LOOMBNB','4h','0.002380000000000','0.002370000000000','0.720385980810331','0.717359148958187','302.6831852144248','302.683185214424782','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','LOOMBNB','4h','0.002420000000000','0.002390000000000','0.720385980810331','0.711455576089542','297.68015735964093','297.680157359640930','test'),('2019-06-07 07:59:59','2019-06-10 15:59:59','LOOMBNB','4h','0.002450000000000','0.002520000000000','0.720385980810331','0.740968437404912','294.0350942082984','294.035094208298403','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','LOOMBNB','4h','0.002590000000000','0.002560000000000','0.720385980810331','0.712041741650366','278.14130533217417','278.141305332174170','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','LOOMBNB','4h','0.002520000000000','0.002420000000000','0.720385980810331','0.691799235540080','285.8674527025123','285.867452702512310','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','LOOMBNB','4h','0.002050000000000','0.002020000000000','0.720385980810331','0.709843746944814','351.4077955172346','351.407795517234604','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','LOOMBNB','4h','0.002070000000000','0.002030000000000','0.720385980810331','0.706465478765687','348.012551116102','348.012551116101974','test'),('2019-07-04 15:59:59','2019-07-04 23:59:59','LOOMBNB','4h','0.002030000000000','0.001960000000000','0.720385980810331','0.695545084920320','354.8699412858773','354.869941285877303','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','LOOMBNB','4h','0.001558000000000','0.001583000000000','0.720385980810331','0.731945447768135','462.37867831215084','462.378678312150839','test'),('2019-07-29 19:59:59','2019-07-30 07:59:59','LOOMBNB','4h','0.001561000000000','0.001514000000000','0.720385980810331','0.698695948076131','461.4900581744593','461.490058174459307','test'),('2019-08-21 23:59:59','2019-08-26 11:59:59','LOOMBNB','4h','0.001154000000000','0.001222000000000','0.720385980810331','0.762835068067785','624.2512831978604','624.251283197860403','test'),('2019-08-29 07:59:59','2019-08-29 15:59:59','LOOMBNB','4h','0.001254000000000','0.001215000000000','0.720385980810331','0.697981632124842','574.4704791150965','574.470479115096509','test'),('2019-08-29 19:59:59','2019-09-02 23:59:59','LOOMBNB','4h','0.001275000000000','0.001246000000000','0.720385980810331','0.704000731050723','565.0086124002596','565.008612400259608','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','LOOMBNB','4h','0.001264000000000','0.001256000000000','0.720385980810331','0.715826575868493','569.9256177296922','569.925617729692249','test'),('2019-09-03 19:59:59','2019-09-05 19:59:59','LOOMBNB','4h','0.001280000000000','0.001241000000000','0.720385980810331','0.698436720457516','562.801547508071','562.801547508071053','test'),('2019-09-07 19:59:59','2019-09-09 07:59:59','LOOMBNB','4h','0.001309000000000','0.001273000000000','0.720385980810331','0.700573990505387','550.3330640262269','550.333064026226907','test'),('2019-09-09 19:59:59','2019-09-10 07:59:59','LOOMBNB','4h','0.001300000000000','0.001291000000000','0.720385980810331','0.715398693250875','554.1430621617931','554.143062161793068','test'),('2019-09-20 19:59:59','2019-09-21 07:59:59','LOOMBNB','4h','0.001173000000000','0.001143000000000','0.720385980810331','0.701961786927714','614.1397960872387','614.139796087238665','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','LOOMBNB','4h','0.001163000000000','0.001145000000000','0.720385980810331','0.709236412749638','619.4204478162777','619.420447816277715','test'),('2019-10-02 15:59:59','2019-10-02 23:59:59','LOOMBNB','4h','0.001735000000000','0.001713000000000','0.720385980810331','0.711251403532044','415.20805810393716','415.208058103937162','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 15:11:38
