-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-04 03:59:59','2018-05-04 07:59:59','POWRBTC','4h','0.000059990000000','0.000059050000000','0.001467500000000','0.001444505334222','24.462410401733624','24.462410401733624','test'),('2018-05-14 11:59:59','2018-05-14 15:59:59','POWRBTC','4h','0.000053270000000','0.000052930000000','0.001467500000000','0.001458133564858','27.548338652149425','27.548338652149425','test'),('2018-06-02 23:59:59','2018-06-03 03:59:59','POWRBTC','4h','0.000044970000000','0.000044760000000','0.001467500000000','0.001460647098065','32.632866355348014','32.632866355348014','test'),('2018-06-03 15:59:59','2018-06-03 19:59:59','POWRBTC','4h','0.000045610000000','0.000044830000000','0.001467500000000','0.001442403529928','32.17496163122122','32.174961631221223','test'),('2018-06-06 07:59:59','2018-06-06 11:59:59','POWRBTC','4h','0.000044760000000','0.000045280000000','0.001467500000000','0.001484548704200','32.785969615728334','32.785969615728334','test'),('2018-06-30 03:59:59','2018-07-05 19:59:59','POWRBTC','4h','0.000039040000000','0.000041530000000','0.001467500000000','0.001561098232582','37.58965163934427','37.589651639344268','test'),('2018-07-06 15:59:59','2018-07-07 03:59:59','POWRBTC','4h','0.000042630000000','0.000041050000000','0.001479084115964','0.001424264671835','34.69585071460826','34.695850714608262','test'),('2018-07-08 15:59:59','2018-07-09 03:59:59','POWRBTC','4h','0.000042210000000','0.000040310000000','0.001479084115964','0.001412506058150','35.041083060033166','35.041083060033166','test'),('2018-07-09 07:59:59','2018-07-09 23:59:59','POWRBTC','4h','0.000041940000000','0.000040990000000','0.001479084115964','0.001445580780004','35.26666943166428','35.266669431664283','test'),('2018-07-11 07:59:59','2018-07-20 19:59:59','POWRBTC','4h','0.000046340000000','0.000049700000000','0.001479084115964','0.001586328885702','31.918086231419938','31.918086231419938','test'),('2018-08-17 19:59:59','2018-08-18 07:59:59','POWRBTC','4h','0.000031100000000','0.000029550000000','0.001479084115964','0.001405367705040','47.55897478983923','47.558974789839233','test'),('2018-08-21 07:59:59','2018-08-21 11:59:59','POWRBTC','4h','0.000031030000000','0.000030000000000','0.001479084115964','0.001429987865901','47.66626219671286','47.666262196712857','test'),('2018-08-22 03:59:59','2018-08-22 07:59:59','POWRBTC','4h','0.000030830000000','0.000030500000000','0.001479084115964','0.001463252206841','47.97548219150178','47.975482191501783','test'),('2018-08-28 03:59:59','2018-08-28 07:59:59','POWRBTC','4h','0.000029470000000','0.000029830000000','0.001479084115964','0.001497152330479','50.18948476294537','50.189484762945369','test'),('2018-09-16 15:59:59','2018-09-17 11:59:59','POWRBTC','4h','0.000025970000000','0.000024290000000','0.001479084115964','0.001383402124635','56.95356626738544','56.953566267385440','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','POWRBTC','4h','0.000023480000000','0.000024000000000','0.001479084115964','0.001511840663677','62.99336098654174','62.993360986541738','test'),('2018-09-20 11:59:59','2018-09-20 23:59:59','POWRBTC','4h','0.000023620000000','0.000024430000000','0.001479084115964','0.001529806306224','62.61998797476714','62.619987974767142','test'),('2018-09-25 19:59:59','2018-09-26 23:59:59','POWRBTC','4h','0.000025310000000','0.000025330000000','0.001479084115964','0.001480252890453','58.4387244553141','58.438724455314102','test'),('2018-09-29 11:59:59','2018-09-29 19:59:59','POWRBTC','4h','0.000025490000000','0.000025490000000','0.001479084115964','0.001479084115964','58.026053980541384','58.026053980541384','test'),('2018-10-02 11:59:59','2018-10-02 15:59:59','POWRBTC','4h','0.000025230000000','0.000025040000000','0.001479084115964','0.001467945551476','58.62402362124455','58.624023621244547','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','POWRBTC','4h','0.000025070000000','0.000025230000000','0.001479084115964','0.001488523823126','58.998169763222975','58.998169763222975','test'),('2018-10-12 19:59:59','2018-10-12 23:59:59','POWRBTC','4h','0.000026080000000','0.000025840000000','0.001479084115964','0.001465472912443','56.7133480047546','56.713348004754600','test'),('2018-10-13 11:59:59','2018-10-13 15:59:59','POWRBTC','4h','0.000025820000000','0.000026110000000','0.001479084115964','0.001495696602162','57.2844351651433','57.284435165143300','test'),('2018-10-16 07:59:59','2018-10-16 11:59:59','POWRBTC','4h','0.000026090000000','0.000025970000000','0.001479084115964','0.001472281122713','56.691610424070525','56.691610424070525','test'),('2018-10-22 19:59:59','2018-10-22 23:59:59','POWRBTC','4h','0.000027170000000','0.000027200000000','0.001479084115964','0.001480717260001','54.43813455885168','54.438134558851679','test'),('2018-10-24 15:59:59','2018-10-24 19:59:59','POWRBTC','4h','0.000027140000000','0.000027120000000','0.001479084115964','0.001477994149777','54.498309357553424','54.498309357553424','test'),('2018-11-01 11:59:59','2018-11-01 15:59:59','POWRBTC','4h','0.000026140000000','0.000025810000000','0.001479084115964','0.001460411669205','56.58317199556235','56.583171995562353','test'),('2018-11-11 19:59:59','2018-11-11 23:59:59','POWRBTC','4h','0.000025400000000','0.000025420000000','0.001479084115964','0.001480248749126','58.2316581088189','58.231658108818898','test'),('2018-11-12 11:59:59','2018-11-12 15:59:59','POWRBTC','4h','0.000025180000000','0.000025120000000','0.001479084115964','0.001475559689953','58.7404335172359','58.740433517235900','test'),('2018-11-12 19:59:59','2018-11-12 23:59:59','POWRBTC','4h','0.000025200000000','0.000025060000000','0.001479084115964','0.001470866981986','58.693814125555555','58.693814125555555','test'),('2018-11-13 15:59:59','2018-11-14 01:59:59','POWRBTC','4h','0.000026280000000','0.000025090000000','0.001479084115964','0.001412108845873','56.28173957245053','56.281739572450533','test'),('2018-11-28 23:59:59','2018-11-29 03:59:59','POWRBTC','4h','0.000020760000000','0.000020290000000','0.001479084115964','0.001445598107558','71.24682639518304','71.246826395183035','test'),('2018-11-29 07:59:59','2018-11-30 11:59:59','POWRBTC','4h','0.000021300000000','0.000020340000000','0.001479084115964','0.001412421169892','69.44056882460094','69.440568824600945','test'),('2018-12-18 15:59:59','2018-12-20 07:59:59','POWRBTC','4h','0.000020120000000','0.000020100000000','0.001479084115964','0.001477613853423','73.5131270359841','73.513127035984098','test'),('2018-12-20 15:59:59','2018-12-20 23:59:59','POWRBTC','4h','0.000020200000000','0.000020170000000','0.001479084115964','0.001476887456386','73.22198593881188','73.221985938811883','test'),('2018-12-30 07:59:59','2018-12-30 11:59:59','POWRBTC','4h','0.000021300000000','0.000021110000000','0.001479084115964','0.001465890407887','69.44056882460094','69.440568824600945','test'),('2018-12-31 03:59:59','2019-01-01 03:59:59','POWRBTC','4h','0.000022470000000','0.000021290000000','0.001479084115964','0.001401410806803','65.82483827165109','65.824838271651089','test'),('2019-01-01 15:59:59','2019-01-01 19:59:59','POWRBTC','4h','0.000021430000000','0.000021510000000','0.001479084115964','0.001484605661894','69.01932412337844','69.019324123378439','test'),('2019-01-02 11:59:59','2019-01-02 19:59:59','POWRBTC','4h','0.000021630000000','0.000021590000000','0.001479084115964','0.001476348870257','68.38114267055016','68.381142670550162','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','POWRBTC','4h','0.000021430000000','0.000021400000000','0.001479084115964','0.001477013536240','69.01932412337844','69.019324123378439','test'),('2019-01-04 15:59:59','2019-01-04 19:59:59','POWRBTC','4h','0.000021490000000','0.000021360000000','0.001479084115964','0.001470136655048','68.82662242736157','68.826622427361571','test'),('2019-01-05 07:59:59','2019-01-05 11:59:59','POWRBTC','4h','0.000021540000000','0.000021710000000','0.001479084115964','0.001490757481782','68.66685775134633','68.666857751346328','test'),('2019-01-14 19:59:59','2019-01-15 11:59:59','POWRBTC','4h','0.000020740000000','0.000020240000000','0.001479084115964','0.001443426350391','71.3155311458052','71.315531145805195','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','POWRBTC','4h','0.000023590000000','0.000023190000000','0.001479084115964','0.001454004266605','62.699623398219586','62.699623398219586','test'),('2019-02-08 03:59:59','2019-02-08 15:59:59','POWRBTC','4h','0.000023730000000','0.000023510000000','0.001479084115964','0.001465371578859','62.32971411563421','62.329714115634211','test'),('2019-02-11 23:59:59','2019-02-12 03:59:59','POWRBTC','4h','0.000023370000000','0.000022650000000','0.001479084115964','0.001433515414060','63.28986375541292','63.289863755412917','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','POWRBTC','4h','0.000023180000000','0.000023000000000','0.001479084115964','0.001467598562001','63.80863313045729','63.808633130457288','test'),('2019-02-21 23:59:59','2019-02-22 03:59:59','POWRBTC','4h','0.000024440000000','0.000023950000000','0.001479084115964','0.001449429810857','60.51899001489362','60.518990014893618','test'),('2019-02-23 07:59:59','2019-02-23 11:59:59','POWRBTC','4h','0.000024140000000','0.000024140000000','0.001479084115964','0.001479084115964','61.271090139353774','61.271090139353774','test'),('2019-02-26 19:59:59','2019-02-27 03:59:59','POWRBTC','4h','0.000024410000000','0.000024130000000','0.001479084115964','0.001462117972889','60.593368126341666','60.593368126341666','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','POWRBTC','4h','0.000023980000000','0.000023800000000','0.001479084115964','0.001467981733109','61.67990475246038','61.679904752460381','test'),('2019-03-07 07:59:59','2019-03-08 11:59:59','POWRBTC','4h','0.000025700000000','0.000024480000000','0.001479084115964','0.001408870784389','57.55191112700389','57.551911127003891','test'),('2019-03-17 15:59:59','2019-03-17 23:59:59','POWRBTC','4h','0.000026800000000','0.000026870000000','0.001479084115964','0.001482947395371','55.18970581955224','55.189705819552238','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','POWRBTC','4h','0.000026640000000','0.000026470000000','0.001479084115964','0.001469645516125','55.521175524174176','55.521175524174176','test'),('2019-03-19 23:59:59','2019-03-20 03:59:59','POWRBTC','4h','0.000026520000000','0.000026090000000','0.001479084115964','0.001455101982862','55.7724025627451','55.772402562745100','test'),('2019-03-20 15:59:59','2019-03-21 03:59:59','POWRBTC','4h','0.000026850000000','0.000026510000000','0.001479084115964','0.001460354559188','55.08693169325885','55.086931693258848','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','POWRBTC','4h','0.000026640000000','0.000026510000000','0.001479084115964','0.001471866363146','55.521175524174176','55.521175524174176','test'),('2019-03-24 07:59:59','2019-03-24 11:59:59','POWRBTC','4h','0.000026680000000','0.000029540000000','0.001479084115964','0.001637636611154','55.43793538095952','55.437935380959523','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:56:58
