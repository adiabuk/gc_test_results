-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 07:59:59','2018-06-01 15:59:59','WABIETH','4h','0.001360300000000','0.001299300000000','0.072144500000000','0.068909320627803','53.035727413070646','53.035727413070646','test'),('2018-06-29 15:59:59','2018-06-29 23:59:59','WABIETH','4h','0.000814920000000','0.000801440000000','0.072144500000000','0.070951121680656','88.52954891277672','88.529548912776718','test'),('2018-07-06 15:59:59','2018-07-08 23:59:59','WABIETH','4h','0.000861630000000','0.000847710000000','0.072144500000000','0.070978974844191','83.73025544607314','83.730255446073144','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','WABIETH','4h','0.000868080000000','0.000861600000000','0.072144500000000','0.071605959358584','83.10812367523731','83.108123675237309','test'),('2018-07-16 11:59:59','2018-07-20 07:59:59','WABIETH','4h','0.000842230000000','0.000788550000000','0.072144500000000','0.067546329951438','85.65890552461916','85.658905524619158','test'),('2018-08-17 11:59:59','2018-08-17 15:59:59','WABIETH','4h','0.000511110000000','0.000545810000000','0.072144500000000','0.077042494854337','141.152589462151','141.152589462151013','test'),('2018-08-20 03:59:59','2018-08-20 11:59:59','WABIETH','4h','0.000517860000000','0.000510000000000','0.072144500000000','0.071049501795852','139.31274861931797','139.312748619317972','test'),('2018-09-14 11:59:59','2018-09-14 15:59:59','WABIETH','4h','0.000853690000000','0.000838840000000','0.072144500000000','0.070889541144912','84.50901381063383','84.509013810633832','test'),('2018-09-15 07:59:59','2018-09-15 11:59:59','WABIETH','4h','0.000848980000000','0.000836070000000','0.072144500000000','0.071047435881882','84.97785577987702','84.977855779877018','test'),('2018-09-15 15:59:59','2018-09-19 07:59:59','WABIETH','4h','0.000954220000000','0.000897620000000','0.072144500000000','0.067865215663055','75.60573033472365','75.605730334723646','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','WABIETH','4h','0.000940750000000','0.000873230000000','0.072144500000000','0.066966507292054','76.68828062715919','76.688280627159187','test'),('2018-09-23 11:59:59','2018-09-23 15:59:59','WABIETH','4h','0.000897730000000','0.000901560000000','0.072144500000000','0.072452291245697','80.36324952936852','80.363249529368517','test'),('2018-09-25 03:59:59','2018-09-28 11:59:59','WABIETH','4h','0.000951300000000','0.000976880000000','0.072144500000000','0.074084430947125','75.83780090402607','75.837800904026068','test'),('2018-10-04 07:59:59','2018-10-04 11:59:59','WABIETH','4h','0.000945330000000','0.000941270000000','0.072144500000000','0.071834654052024','76.31673595464018','76.316735954640180','test'),('2018-10-10 11:59:59','2018-10-11 07:59:59','WABIETH','4h','0.000970000000000','0.000903120000000','0.072144500000000','0.067170248288660','74.37577319587629','74.375773195876292','test'),('2018-10-11 19:59:59','2018-10-12 11:59:59','WABIETH','4h','0.000946470000000','0.000923300000000','0.072144500000000','0.070378371052437','76.2248143100151','76.224814310015105','test'),('2018-10-13 15:59:59','2018-10-22 07:59:59','WABIETH','4h','0.001232190000000','0.001210970000000','0.072144500000000','0.070902072866198','58.549817804072426','58.549817804072426','test'),('2018-10-28 03:59:59','2018-10-28 11:59:59','WABIETH','4h','0.001255000000000','0.001268710000000','0.072144500000000','0.072932628362550','57.48565737051793','57.485657370517927','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','WABIETH','4h','0.001391260000000','0.001370880000000','0.072144500000000','0.071087684659949','51.855512269453584','51.855512269453584','test'),('2018-11-07 07:59:59','2018-11-07 11:59:59','WABIETH','4h','0.001381340000000','0.001408980000000','0.072144500000000','0.073588079408401','52.227909131712686','52.227909131712686','test'),('2018-11-11 19:59:59','2018-11-14 15:59:59','WABIETH','4h','0.001510830000000','0.001407720000000','0.072144500000000','0.067220835924624','47.751567019452885','47.751567019452885','test'),('2018-11-23 23:59:59','2018-11-24 03:59:59','WABIETH','4h','0.001232860000000','0.001207570000000','0.072144500000000','0.070664579810360','58.517998799539285','58.517998799539285','test'),('2018-11-24 15:59:59','2018-11-24 19:59:59','WABIETH','4h','0.001216740000000','0.001159670000000','0.072144500000000','0.068760632768710','59.29327547380706','59.293275473807057','test'),('2018-11-25 11:59:59','2018-11-25 19:59:59','WABIETH','4h','0.001201740000000','0.001289150000000','0.072144500000000','0.077392016721587','60.03336828265682','60.033368282656816','test'),('2018-12-16 19:59:59','2018-12-18 03:59:59','WABIETH','4h','0.001411000000000','0.001294980000000','0.072144500000000','0.066212391644224','51.13004961020553','51.130049610205532','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','WABIETH','4h','0.000886710000000','0.000883470000000','0.072144500000000','0.071880887116419','81.36200110520915','81.362001105209146','test'),('2019-01-11 11:59:59','2019-01-12 03:59:59','WABIETH','4h','0.000895560000000','0.000894070000000','0.072144500000000','0.072024468617401','80.5579748983876','80.557974898387599','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','WABIETH','4h','0.001104680000000','0.001038550000000','0.072144500000000','0.067825678454394','65.30805301082667','65.308053010826669','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','WABIETH','4h','0.001112730000000','0.001075350000000','0.072144500000000','0.069720945849397','64.83558455330584','64.835584553305836','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','WABIETH','4h','0.001096330000000','0.001092450000000','0.072144500000000','0.071889174815065','65.80546003484352','65.805460034843520','test'),('2019-02-01 19:59:59','2019-02-01 23:59:59','WABIETH','4h','0.001086620000000','0.001077210000000','0.072144500000000','0.071519737208040','66.39349542618395','66.393495426183947','test'),('2019-02-02 07:59:59','2019-02-02 15:59:59','WABIETH','4h','0.001106880000000','0.001080970000000','0.072144500000000','0.070455731574335','65.1782487713212','65.178248771321194','test'),('2019-02-03 15:59:59','2019-02-03 19:59:59','WABIETH','4h','0.001081700000000','0.001071970000000','0.072144500000000','0.071495552986041','66.69547933807895','66.695479338078954','test'),('2019-02-06 03:59:59','2019-02-06 19:59:59','WABIETH','4h','0.001097280000000','0.001066450000000','0.072144500000000','0.070117474140602','65.74848716827064','65.748487168270643','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','WABIETH','4h','0.001020000000000','0.000980460000000','0.072144500000000','0.069347839676471','70.7299019607843','70.729901960784304','test'),('2019-02-25 23:59:59','2019-03-11 23:59:59','WABIETH','4h','0.001002480000000','0.001437200000000','0.072144500000000','0.103429570066236','71.9660242598356','71.966024259835606','test'),('2019-03-12 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001504020000000','0.001668870000000','0.072144500000000','0.080051988480871','47.9677796837808','47.967779683780797','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','WABIETH','4h','0.001647430000000','0.001593230000000','0.072144500000000','0.069770965525091','43.792148983568346','43.792148983568346','test'),('2019-03-27 07:59:59','2019-04-02 19:59:59','WABIETH','4h','0.001707770000000','0.002100820000000','0.072144500000000','0.088748841172992','42.24485732856298','42.244857328562979','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','WABIETH','4h','0.002109720000000','0.002088000000000','0.073188669132666','0.072435176776542','34.69117661711803','34.691176617118032','test'),('2019-04-04 19:59:59','2019-04-04 23:59:59','WABIETH','4h','0.002083360000000','0.002144850000000','0.073188669132666','0.075348819689923','35.13011151825225','35.130111518252249','test'),('2019-04-12 15:59:59','2019-04-17 23:59:59','WABIETH','4h','0.001964150000000','0.002297230000000','0.073540333682950','0.086011282614099','37.44130218310694','37.441302183106941','test'),('2019-04-24 15:59:59','2019-04-24 19:59:59','WABIETH','4h','0.002275950000000','0.002274400000000','0.076658070915737','0.076605864140580','33.68179042410279','33.681790424102793','test'),('2019-04-27 11:59:59','2019-04-27 15:59:59','WABIETH','4h','0.002160000000000','0.002145760000000','0.076658070915737','0.076152695485255','35.48984764617453','35.489847646174532','test'),('2019-04-28 03:59:59','2019-04-28 07:59:59','WABIETH','4h','0.002181550000000','0.002150000000000','0.076658070915737','0.075549426998618','35.139268371450115','35.139268371450115','test'),('2019-04-28 11:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002182100000000','0.002188890000000','0.076658070915737','0.076896606409765','35.130411491561794','35.130411491561794','test'),('2019-04-30 15:59:59','2019-04-30 23:59:59','WABIETH','4h','0.002225550000000','0.002191720000000','0.076658070915737','0.075492811748754','34.44455119666464','34.444551196664641','test'),('2019-05-05 11:59:59','2019-05-05 19:59:59','WABIETH','4h','0.002254760000000','0.002140860000000','0.076658070915737','0.072785661312363','33.99832838782708','33.998328387827080','test'),('2019-05-06 03:59:59','2019-05-06 07:59:59','WABIETH','4h','0.002123830000000','0.002050000000000','0.076658070915737','0.073993231745131','36.09425938786861','36.094259387868611','test'),('2019-05-22 23:59:59','2019-05-23 03:59:59','WABIETH','4h','0.001449850000000','0.001417310000000','0.076658070915737','0.074937580087308','52.87310474582681','52.873104745826808','test'),('2019-05-23 11:59:59','2019-05-23 15:59:59','WABIETH','4h','0.001420410000000','0.001434560000000','0.076658070915737','0.077421731903380','53.96897439171577','53.968974391715768','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','WABIETH','4h','0.001472840000000','0.001398270000000','0.076658070915737','0.072776867018378','52.047792642606794','52.047792642606794','test'),('2019-05-26 03:59:59','2019-05-26 07:59:59','WABIETH','4h','0.001412160000000','0.001391940000000','0.076658070915737','0.075560443030854','54.284267303801975','54.284267303801975','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:02:00
