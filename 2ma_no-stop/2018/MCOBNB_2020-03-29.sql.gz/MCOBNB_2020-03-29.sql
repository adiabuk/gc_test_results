-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-24 23:59:59','2018-06-25 07:59:59','MCOBNB','4h','0.330310000000000','0.327830000000000','0.711908500000000','0.706563420892495','2.1552738336713997','2.155273833671400','test'),('2018-07-16 03:59:59','2018-07-17 15:59:59','MCOBNB','4h','0.587590000000000','0.585000000000000','0.711908500000000','0.708770524515393','1.2115735461801598','1.211573546180160','test'),('2018-07-21 11:59:59','2018-07-25 03:59:59','MCOBNB','4h','0.581090000000000','0.595690000000000','0.711908500000000','0.729795340420589','1.2251260562047188','1.225126056204719','test'),('2018-07-30 07:59:59','2018-07-30 11:59:59','MCOBNB','4h','0.583590000000000','0.556000000000000','0.714259446457119','0.680491873113244','1.2239062466065547','1.223906246606555','test'),('2018-07-30 15:59:59','2018-07-30 19:59:59','MCOBNB','4h','0.570400000000000','0.562010000000000','0.714259446457119','0.703753421289210','1.2522080057102367','1.252208005710237','test'),('2018-07-30 23:59:59','2018-07-31 07:59:59','MCOBNB','4h','0.569510000000000','0.557380000000000','0.714259446457119','0.699046426342415','1.2541648899178577','1.254164889917858','test'),('2018-08-12 23:59:59','2018-08-13 03:59:59','MCOBNB','4h','0.472090000000000','0.466940000000000','0.714259446457119','0.706467635257445','1.5129730484804147','1.512973048480415','test'),('2018-08-13 23:59:59','2018-08-15 03:59:59','MCOBNB','4h','0.485370000000000','0.474930000000000','0.714259446457119','0.698896180039721','1.4715772430457568','1.471577243045757','test'),('2018-08-15 23:59:59','2018-08-16 03:59:59','MCOBNB','4h','0.478450000000000','0.468390000000000','0.714259446457119','0.699241262673320','1.4928612111132178','1.492861211113218','test'),('2018-08-16 07:59:59','2018-08-16 11:59:59','MCOBNB','4h','0.479850000000000','0.475000000000000','0.714259446457119','0.707040193950467','1.4885056714746672','1.488505671474667','test'),('2018-08-17 15:59:59','2018-08-17 19:59:59','MCOBNB','4h','0.481640000000000','0.472420000000000','0.714259446457119','0.700586429065842','1.4829736866894756','1.482973686689476','test'),('2018-08-19 07:59:59','2018-08-19 11:59:59','MCOBNB','4h','0.480000000000000','0.469800000000000','0.714259446457119','0.699081433219905','1.4880405134523313','1.488040513452331','test'),('2018-09-04 07:59:59','2018-09-05 11:59:59','MCOBNB','4h','0.437550000000000','0.426270000000000','0.714259446457119','0.695845901591306','1.6324064597351595','1.632406459735160','test'),('2018-09-18 15:59:59','2018-09-19 03:59:59','MCOBNB','4h','0.450010000000000','0.440470000000000','0.714259446457119','0.699117482680312','1.5872079430615298','1.587207943061530','test'),('2018-09-19 11:59:59','2018-09-19 23:59:59','MCOBNB','4h','0.447380000000000','0.446950000000000','0.714259446457119','0.713572934851825','1.596538616963474','1.596538616963474','test'),('2018-09-24 03:59:59','2018-09-24 07:59:59','MCOBNB','4h','0.442200000000000','0.434610000000000','0.714259446457119','0.701999769391064','1.615240720165353','1.615240720165353','test'),('2018-09-25 07:59:59','2018-09-25 11:59:59','MCOBNB','4h','0.452000000000000','0.435900000000000','0.714259446457119','0.688817904227120','1.5802200142856615','1.580220014285662','test'),('2018-09-25 15:59:59','2018-09-27 15:59:59','MCOBNB','4h','0.452000000000000','0.441880000000000','0.714259446457119','0.698267619912548','1.5802200142856615','1.580220014285662','test'),('2018-09-29 03:59:59','2018-09-30 11:59:59','MCOBNB','4h','0.454110000000000','0.443500000000000','0.714259446457119','0.697571215132308','1.5728775989454515','1.572877598945452','test'),('2018-10-01 03:59:59','2018-10-01 15:59:59','MCOBNB','4h','0.451140000000000','0.445000000000000','0.714259446457119','0.704538399772616','1.5832323590395865','1.583232359039586','test'),('2018-10-01 23:59:59','2018-10-02 23:59:59','MCOBNB','4h','0.449840000000000','0.445050000000000','0.714259446457119','0.706653847247334','1.587807768222299','1.587807768222299','test'),('2018-10-03 23:59:59','2018-10-04 23:59:59','MCOBNB','4h','0.456170000000000','0.450880000000000','0.714259446457119','0.705976498276050','1.5657747034156542','1.565774703415654','test'),('2018-10-09 19:59:59','2018-10-11 03:59:59','MCOBNB','4h','0.439800000000000','0.441060000000000','0.714259446457119','0.716305755921730','1.624055130643745','1.624055130643745','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','MCOBNB','4h','0.449850000000000','0.433100000000000','0.714259446457119','0.687664257553803','1.5877724718397666','1.587772471839767','test'),('2018-10-13 15:59:59','2018-10-14 03:59:59','MCOBNB','4h','0.443590000000000','0.448630000000000','0.714259446457119','0.722374750251487','1.610179324279445','1.610179324279445','test'),('2018-10-17 19:59:59','2018-10-18 03:59:59','MCOBNB','4h','0.439900000000000','0.438470000000000','0.714259446457119','0.711937575558202','1.6236859432987474','1.623685943298747','test'),('2018-10-28 15:59:59','2018-10-28 19:59:59','MCOBNB','4h','0.488790000000000','0.482610000000000','0.714259446457119','0.705228731059699','1.4612808086440374','1.461280808644037','test'),('2018-11-03 23:59:59','2018-11-04 07:59:59','MCOBNB','4h','0.474820000000000','0.470140000000000','0.714259446457119','0.707219443488796','1.504274138530641','1.504274138530641','test'),('2018-11-10 15:59:59','2018-11-10 19:59:59','MCOBNB','4h','0.461770000000000','0.453230000000000','0.714259446457119','0.701049892625680','1.5467861629320203','1.546786162932020','test'),('2018-11-11 03:59:59','2018-11-11 07:59:59','MCOBNB','4h','0.457720000000000','0.458130000000000','0.714259446457119','0.714899240158612','1.5604724426660819','1.560472442666082','test'),('2018-11-12 15:59:59','2018-11-13 03:59:59','MCOBNB','4h','0.460660000000000','0.450920000000000','0.714259446457119','0.699157447133339','1.5505132775954478','1.550513277595448','test'),('2018-11-16 07:59:59','2018-11-18 23:59:59','MCOBNB','4h','0.486600000000000','0.456060000000000','0.714259446457119','0.669431079225717','1.467857473195888','1.467857473195888','test'),('2018-11-19 03:59:59','2018-11-19 11:59:59','MCOBNB','4h','0.483700000000000','0.461890000000000','0.714259446457119','0.682053536746080','1.476657941817488','1.476657941817488','test'),('2018-11-20 07:59:59','2018-11-20 11:59:59','MCOBNB','4h','0.473460000000000','0.426930000000000','0.714259446457119','0.644064515430950','1.5085951219894373','1.508595121989437','test'),('2018-11-25 15:59:59','2018-11-25 19:59:59','MCOBNB','4h','0.441800000000000','0.437780000000000','0.714259446457119','0.707760299841552','1.6167031382008126','1.616703138200813','test'),('2018-11-26 11:59:59','2018-11-26 15:59:59','MCOBNB','4h','0.448960000000000','0.429340000000000','0.714259446457119','0.683045595914780','1.5909200072548089','1.590920007254809','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','MCOBNB','4h','0.434220000000000','0.425960000000000','0.714259446457119','0.700672363808379','1.6449252601379925','1.644925260137992','test'),('2018-11-29 07:59:59','2018-11-29 19:59:59','MCOBNB','4h','0.438180000000000','0.435590000000000','0.714259446457119','0.710037592501384','1.6300594423687047','1.630059442368705','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','MCOBNB','4h','0.434750000000000','0.437200000000000','0.714259446457119','0.718284600324445','1.6429199458473123','1.642919945847312','test'),('2018-12-07 19:59:59','2018-12-07 23:59:59','MCOBNB','4h','0.442000000000000','0.432170000000000','0.714259446457119','0.698374445645641','1.6159715983192737','1.615971598319274','test'),('2018-12-08 07:59:59','2018-12-08 15:59:59','MCOBNB','4h','0.432580000000000','0.427720000000000','0.714259446457119','0.706234801513336','1.6511615110664362','1.651161511066436','test'),('2018-12-20 19:59:59','2018-12-20 23:59:59','MCOBNB','4h','0.392160000000000','0.387100000000000','0.714259446457119','0.705043430547610','1.821347017689512','1.821347017689512','test'),('2018-12-24 15:59:59','2018-12-27 07:59:59','MCOBNB','4h','0.404060000000000','0.397500000000000','0.714259446457119','0.702663292497908','1.767706396221153','1.767706396221153','test'),('2018-12-30 15:59:59','2018-12-31 03:59:59','MCOBNB','4h','0.398110000000000','0.382610000000000','0.714259446457119','0.686450495614173','1.794125860835244','1.794125860835244','test'),('2019-01-03 03:59:59','2019-01-03 11:59:59','MCOBNB','4h','0.389970000000000','0.388550000000000','0.714259446457119','0.711658609433838','1.8315753685081393','1.831575368508139','test'),('2019-01-04 23:59:59','2019-01-08 11:59:59','MCOBNB','4h','0.399080000000000','0.403850000000000','0.714259446457119','0.722796625868767','1.789765075817177','1.789765075817177','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','MCOBNB','4h','0.404880000000000','0.400000000000000','0.714259446457119','0.705650510232285','1.7641262755807128','1.764126275580713','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','MCOBNB','4h','0.404130000000000','0.387880000000000','0.714259446457119','0.685539193061112','1.7674002089850271','1.767400208985027','test'),('2019-02-15 03:59:59','2019-02-15 23:59:59','MCOBNB','4h','0.269210000000000','0.283050000000000','0.714259446457119','0.750979296161686','2.6531683312548533','2.653168331254853','test'),('2019-02-20 15:59:59','2019-02-22 15:59:59','MCOBNB','4h','0.293740000000000','0.287190000000000','0.714259446457119','0.698332438306053','2.4316042978726733','2.431604297872673','test'),('2019-02-23 19:59:59','2019-02-24 07:59:59','MCOBNB','4h','0.281000000000000','0.276530000000000','0.714259446457119','0.702897383376467','2.5418485639043378','2.541848563904338','test'),('2019-02-25 19:59:59','2019-02-27 19:59:59','MCOBNB','4h','0.278640000000000','0.282320000000000','0.714259446457119','0.723692674862812','2.5633772841556097','2.563377284155610','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','MCOBNB','4h','0.226460000000000','0.196810000000000','0.714259446457119','0.620742743341984','3.1540203411512806','3.154020341151281','test'),('2019-03-15 07:59:59','2019-03-16 11:59:59','MCOBNB','4h','0.236730000000000','0.206980000000000','0.714259446457119','0.624498036698747','3.0171902439788747','3.017190243978875','test'),('2019-03-17 11:59:59','2019-03-18 11:59:59','MCOBNB','4h','0.210090000000000','0.210900000000000','0.476172964304746','0.478008844646918','2.2665189409526683','2.266518940952668','test'),('2019-03-23 11:59:59','2019-03-23 23:59:59','MCOBNB','4h','0.215920000000000','0.215060000000000','0.516337244899671','0.514280696036140','2.391335887827303','2.391335887827303','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','MCOBNB','4h','0.207500000000000','0.203150000000000','0.516337244899671','0.505512825548762','2.488372264576728','2.488372264576728','test'),('2019-03-27 23:59:59','2019-03-30 19:59:59','MCOBNB','4h','0.211600000000000','0.206590000000000','0.516337244899671','0.504112057768540','2.440157112002226','2.440157112002226','test'),('2019-04-06 19:59:59','2019-04-06 23:59:59','MCOBNB','4h','0.199830000000000','0.195570000000000','0.516337244899671','0.505329905344686','2.5838825246443027','2.583882524644303','test'),('2019-04-07 03:59:59','2019-04-07 07:59:59','MCOBNB','4h','0.200510000000000','0.196990000000000','0.516337244899671','0.507272823663589','2.575119669341534','2.575119669341534','test'),('2019-04-07 15:59:59','2019-04-13 23:59:59','MCOBNB','4h','0.199910000000000','0.211540000000000','0.516337244899671','0.546375773028245','2.582848506326202','2.582848506326202','test'),('2019-04-15 03:59:59','2019-04-15 11:59:59','MCOBNB','4h','0.215060000000000','0.208190000000000','0.516337244899671','0.499843071773749','2.400898562725151','2.400898562725151','test'),('2019-04-16 07:59:59','2019-04-16 11:59:59','MCOBNB','4h','0.215310000000000','0.213570000000000','0.516337244899671','0.512164532038562','2.3981108397179463','2.398110839717946','test'),('2019-04-19 03:59:59','2019-04-19 11:59:59','MCOBNB','4h','0.219350000000000','0.213080000000000','0.516337244899671','0.501578026638805','2.3539423063581997','2.353942306358200','test'),('2019-04-21 11:59:59','2019-04-21 15:59:59','MCOBNB','4h','0.210730000000000','0.206960000000000','0.516337244899671','0.507099872844094','2.450231314476681','2.450231314476681','test'),('2019-04-21 23:59:59','2019-04-22 07:59:59','MCOBNB','4h','0.216050000000000','0.213450000000000','0.516337244899671','0.510123512723142','2.389896990972789','2.389896990972789','test'),('2019-04-22 19:59:59','2019-04-22 23:59:59','MCOBNB','4h','0.211570000000000','0.209780000000000','0.516337244899671','0.511968744316552','2.440503119060694','2.440503119060694','test'),('2019-04-24 03:59:59','2019-04-24 07:59:59','MCOBNB','4h','0.211360000000000','0.209560000000000','0.516337244899671','0.511939974645984','2.4429279187153248','2.442927918715325','test'),('2019-04-25 15:59:59','2019-04-25 23:59:59','MCOBNB','4h','0.217260000000000','0.196910000000000','0.516337244899671','0.467973703825804','2.3765867849566003','2.376586784956600','test'),('2019-04-27 07:59:59','2019-04-27 15:59:59','MCOBNB','4h','0.210430000000000','0.208280000000000','0.516337244899671','0.511061737241379','2.453724492228632','2.453724492228632','test'),('2019-04-29 19:59:59','2019-04-29 23:59:59','MCOBNB','4h','0.212280000000000','0.207080000000000','0.516337244899671','0.503689074212473','2.4323405167687535','2.432340516768754','test'),('2019-05-04 07:59:59','2019-05-11 15:59:59','MCOBNB','4h','0.221500000000000','0.228180000000000','0.516337244899671','0.531908950524636','2.3310936564319236','2.331093656431924','test'),('2019-05-26 23:59:59','2019-05-27 03:59:59','MCOBNB','4h','0.176750000000000','0.199840000000000','0.516337244899671','0.583789731376239','2.921285685429539','2.921285685429539','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','MCOBNB','4h','0.194910000000000','0.191470000000000','0.516337244899671','0.507224320357806','2.6491059714723257','2.649105971472326','test'),('2019-06-09 23:59:59','2019-06-10 03:59:59','MCOBNB','4h','0.194950000000000','0.192900000000000','0.516337244899671','0.510907691926887','2.6485624257485045','2.648562425748505','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','MCOBNB','4h','0.194080000000000','0.193640000000000','0.516337244899671','0.515166653454103','2.660435103563845','2.660435103563845','test'),('2019-06-10 19:59:59','2019-06-10 23:59:59','MCOBNB','4h','0.193860000000000','0.193060000000000','0.516337244899671','0.514206481483186','2.663454270605958','2.663454270605958','test'),('2019-06-11 03:59:59','2019-06-11 23:59:59','MCOBNB','4h','0.199810000000000','0.208790000000000','0.516337244899671','0.539542832503890','2.5841411585990244','2.584141158599024','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:46:07
