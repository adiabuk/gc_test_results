-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-23 19:59:59','2018-05-24 07:59:59','XMRETH','4h','0.291130000000000','0.288340000000000','0.072144500000000','0.071453114175798','0.24780853914059012','0.247808539140590','test'),('2018-05-24 15:59:59','2018-05-24 19:59:59','XMRETH','4h','0.289550000000000','0.289670000000000','0.072144500000000','0.072174399292005','0.2491607667069591','0.249160766706959','test'),('2018-05-27 19:59:59','2018-05-29 03:59:59','XMRETH','4h','0.295920000000000','0.288200000000000','0.072144500000000','0.070262384766153','0.24379731008380642','0.243797310083806','test'),('2018-06-03 03:59:59','2018-06-03 07:59:59','XMRETH','4h','0.283450000000000','0.281880000000000','0.072144500000000','0.071744899135650','0.25452284353501503','0.254522843535015','test'),('2018-06-14 11:59:59','2018-06-14 15:59:59','XMRETH','4h','0.273490000000000','0.265770000000000','0.072144500000000','0.070108025028337','0.2637920947749461','0.263792094774946','test'),('2018-06-23 15:59:59','2018-06-23 19:59:59','XMRETH','4h','0.250510000000000','0.244820000000000','0.072144500000000','0.070505834058521','0.2879904993812622','0.287990499381262','test'),('2018-06-24 03:59:59','2018-06-24 07:59:59','XMRETH','4h','0.250470000000000','0.248490000000000','0.072144500000000','0.071574187747036','0.28803649139617515','0.288036491396175','test'),('2018-07-09 03:59:59','2018-07-09 11:59:59','XMRETH','4h','0.288600000000000','0.283000000000000','0.072144500000000','0.070744606722107','0.24998094248094246','0.249980942480942','test'),('2018-07-09 15:59:59','2018-07-10 07:59:59','XMRETH','4h','0.287000000000000','0.280200000000000','0.072144500000000','0.070435152961672','0.25137456445993034','0.251374564459930','test'),('2018-07-11 11:59:59','2018-07-11 15:59:59','XMRETH','4h','0.285920000000000','0.283500000000000','0.072144500000000','0.071533875734471','0.25232407666480133','0.252324076664801','test'),('2018-07-17 03:59:59','2018-07-20 23:59:59','XMRETH','4h','0.293520000000000','0.290170000000000','0.072144500000000','0.071321100998228','0.2457907467974925','0.245790746797492','test'),('2018-07-23 07:59:59','2018-07-27 15:59:59','XMRETH','4h','0.290000000000000','0.301260000000000','0.072144500000000','0.074945696793103','0.2487741379310345','0.248774137931035','test'),('2018-08-01 15:59:59','2018-08-01 19:59:59','XMRETH','4h','0.296530000000000','0.291700000000000','0.072144500000000','0.070969381344215','0.2432957879472566','0.243295787947257','test'),('2018-08-01 23:59:59','2018-08-03 03:59:59','XMRETH','4h','0.307170000000000','0.288700000000000','0.072144500000000','0.067806482241104','0.2348683139629521','0.234868313962952','test'),('2018-08-11 07:59:59','2018-08-24 07:59:59','XMRETH','4h','0.285910000000000','0.323700000000000','0.072144500000000','0.081680160365150','0.2523329019621559','0.252332901962156','test'),('2018-09-20 03:59:59','2018-09-20 15:59:59','XMRETH','4h','0.535630000000000','0.535330000000000','0.072144500000000','0.072104092722588','0.134690924705487','0.134690924705487','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','XMRETH','4h','0.531290000000000','0.534520000000000','0.072144500000000','0.072583105535583','0.1357911874870598','0.135791187487060','test'),('2018-09-25 07:59:59','2018-09-27 23:59:59','XMRETH','4h','0.533870000000000','0.520640000000000','0.072144500000000','0.070356664506340','0.13513495794856428','0.135134957948564','test'),('2018-09-28 07:59:59','2018-09-28 11:59:59','XMRETH','4h','0.526530000000000','0.520230000000000','0.072144500000000','0.071281281664862','0.13701878335517442','0.137018783355174','test'),('2018-09-28 19:59:59','2018-09-28 23:59:59','XMRETH','4h','0.527100000000000','0.524530000000000','0.072144500000000','0.071792742525138','0.13687061278694745','0.136870612786947','test'),('2018-10-02 23:59:59','2018-10-03 11:59:59','XMRETH','4h','0.515050000000000','0.516000000000000','0.072144500000000','0.072277569168042','0.14007280846519754','0.140072808465198','test'),('2018-10-04 23:59:59','2018-10-05 03:59:59','XMRETH','4h','0.517120000000000','0.517880000000000','0.072144500000000','0.072250529200186','0.13951210550742574','0.139512105507426','test'),('2018-10-11 07:59:59','2018-10-11 11:59:59','XMRETH','4h','0.514280000000000','0.519510000000000','0.072144500000000','0.072878177636696','0.1402825309170102','0.140282530917010','test'),('2018-10-15 23:59:59','2018-10-16 03:59:59','XMRETH','4h','0.517230000000000','0.521750000000000','0.072144500000000','0.072774960607467','0.13948243528024284','0.139482435280243','test'),('2018-10-17 11:59:59','2018-10-17 15:59:59','XMRETH','4h','0.512820000000000','0.513600000000000','0.072144500000000','0.072254231894232','0.14068191568191568','0.140681915681916','test'),('2018-10-21 11:59:59','2018-10-21 15:59:59','XMRETH','4h','0.515100000000000','0.515600000000000','0.072144500000000','0.072214529605902','0.14005921180353328','0.140059211803533','test'),('2018-10-30 07:59:59','2018-10-30 11:59:59','XMRETH','4h','0.518420000000000','0.524310000000000','0.072144500000000','0.072964165724702','0.13916226225840053','0.139162262258401','test'),('2018-11-14 15:59:59','2018-11-14 19:59:59','XMRETH','4h','0.516900000000000','0.503290000000000','0.072144500000000','0.070244932104856','0.139571483846005','0.139571483846005','test'),('2018-11-18 03:59:59','2018-11-18 15:59:59','XMRETH','4h','0.510890000000000','0.506710000000000','0.072144500000000','0.071554228101940','0.14121337274168608','0.141213372741686','test'),('2018-11-18 23:59:59','2018-11-19 03:59:59','XMRETH','4h','0.505010000000000','0.507800000000000','0.072144500000000','0.072543072612424','0.1428575671768876','0.142857567176888','test'),('2018-11-20 23:59:59','2018-11-21 03:59:59','XMRETH','4h','0.507310000000000','0.504260000000000','0.072144500000000','0.071710759831267','0.14220989138790877','0.142209891387909','test'),('2018-11-27 15:59:59','2018-11-27 19:59:59','XMRETH','4h','0.514340000000000','0.524010000000000','0.072144500000000','0.073500873828596','0.1402661663491076','0.140266166349108','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','XMRETH','4h','0.516120000000000','0.516460000000000','0.072144500000000','0.072192026021080','0.13978241494226148','0.139782414942261','test'),('2018-12-02 19:59:59','2018-12-02 23:59:59','XMRETH','4h','0.516930000000000','0.509940000000000','0.072144500000000','0.071168951947072','0.13956338382372854','0.139563383823729','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','XMRETH','4h','0.518840000000000','0.516120000000000','0.072144500000000','0.071766285058978','0.13904961066995605','0.139049610669956','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','XMRETH','4h','0.513400000000000','0.501930000000000','0.072144500000000','0.070532701373198','0.1405229840280483','0.140522984028048','test'),('2018-12-07 03:59:59','2018-12-07 15:59:59','XMRETH','4h','0.526500000000000','0.515510000000000','0.072144500000000','0.070638577768281','0.13702659069325737','0.137026590693257','test'),('2018-12-08 07:59:59','2018-12-08 11:59:59','XMRETH','4h','0.515100000000000','0.516000000000000','0.072144500000000','0.072270553290623','0.14005921180353328','0.140059211803533','test'),('2018-12-21 23:59:59','2018-12-22 03:59:59','XMRETH','4h','0.474450000000000','0.467000000000000','0.072144500000000','0.071011658762778','0.15205922647275794','0.152059226472758','test'),('2019-01-08 03:59:59','2019-01-08 15:59:59','XMRETH','4h','0.354570000000000','0.357550000000000','0.072144500000000','0.072750841794286','0.20347040076712639','0.203470400767126','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','XMRETH','4h','0.358000000000000','0.350220000000000','0.072144500000000','0.070576667011173','0.2015209497206704','0.201520949720670','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','XMRETH','4h','0.357530000000000','0.357100000000000','0.072144500000000','0.072057732078427','0.20178586412329036','0.201785864123290','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','XMRETH','4h','0.399460000000000','0.398850000000000','0.072144500000000','0.072034330909227','0.18060506684023434','0.180605066840234','test'),('2019-02-05 07:59:59','2019-02-05 11:59:59','XMRETH','4h','0.400340000000000','0.403000000000000','0.072144500000000','0.072623853474547','0.18020807313783285','0.180208073137833','test'),('2019-02-09 03:59:59','2019-02-09 07:59:59','XMRETH','4h','0.407830000000000','0.404520000000000','0.072144500000000','0.071558966088812','0.17689846259470857','0.176898462594709','test'),('2019-02-10 03:59:59','2019-02-10 07:59:59','XMRETH','4h','0.406520000000000','0.409840000000000','0.072144500000000','0.072733695463938','0.17746851323428123','0.177468513234281','test'),('2019-02-13 11:59:59','2019-02-13 15:59:59','XMRETH','4h','0.404820000000000','0.409480000000000','0.072144500000000','0.072974976186947','0.17821377402302258','0.178213774023023','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XMRETH','4h','0.360210000000000','0.356210000000000','0.072144500000000','0.071343361775076','0.20028455623108743','0.200284556231087','test'),('2019-03-02 03:59:59','2019-03-05 15:59:59','XMRETH','4h','0.357020000000000','0.363350000000000','0.072144500000000','0.073423629138424','0.20207411349504228','0.202074113495042','test'),('2019-03-07 03:59:59','2019-03-08 07:59:59','XMRETH','4h','0.363450000000000','0.363720000000000','0.072144500000000','0.072198094758564','0.19849910579171826','0.198499105791718','test'),('2019-03-08 23:59:59','2019-03-09 11:59:59','XMRETH','4h','0.365890000000000','0.364380000000000','0.072144500000000','0.071846765175326','0.1971753805788625','0.197175380578862','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','XMRETH','4h','0.387050000000000','0.383230000000000','0.072144500000000','0.071432467988632','0.18639581449425138','0.186395814494251','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','XMRETH','4h','0.381880000000000','0.384130000000000','0.072144500000000','0.072569568411543','0.18891929401906357','0.188919294019064','test'),('2019-03-28 23:59:59','2019-03-29 03:59:59','XMRETH','4h','0.382740000000000','0.379430000000000','0.072144500000000','0.071520582209855','0.18849480064795943','0.188494800647959','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','XMRETH','4h','0.383040000000000','0.378580000000000','0.072144500000000','0.071304471621763','0.18834717000835421','0.188347170008354','test'),('2019-03-31 15:59:59','2019-04-05 07:59:59','XMRETH','4h','0.382720000000000','0.401070000000000','0.072144500000000','0.075603560344377','0.18850465091973245','0.188504650919732','test'),('2019-04-11 23:59:59','2019-04-12 23:59:59','XMRETH','4h','0.401340000000000','0.401360000000000','0.072144500000000','0.072148095181143','0.17975905715851898','0.179759057158519','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','XMRETH','4h','0.399910000000000','0.396070000000000','0.072144500000000','0.071451756932810','0.18040184041409318','0.180401840414093','test'),('2019-04-15 11:59:59','2019-04-15 19:59:59','XMRETH','4h','0.399650000000000','0.405390000000000','0.072144500000000','0.073180680232704','0.1805192043037658','0.180519204303766','test'),('2019-04-16 11:59:59','2019-04-16 15:59:59','XMRETH','4h','0.400460000000000','0.406950000000000','0.072144500000000','0.073313699932578','0.1801540728162613','0.180154072816261','test'),('2019-04-20 19:59:59','2019-04-20 23:59:59','XMRETH','4h','0.401280000000000','0.400720000000000','0.072144500000000','0.072043819876396','0.17978593500797446','0.179785935007974','test'),('2019-04-23 15:59:59','2019-04-23 19:59:59','XMRETH','4h','0.401790000000000','0.401750000000000','0.072144500000000','0.072137317690834','0.17955772916200005','0.179557729162000','test'),('2019-04-26 07:59:59','2019-04-26 19:59:59','XMRETH','4h','0.406910000000000','0.402800000000000','0.072144500000000','0.071415803494630','0.17729841979798974','0.177298419797990','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:09:25
