-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-27 11:59:59','2018-08-27 15:59:59','BLZBTC','4h','0.000019470000000','0.000019370000000','0.001467500000000','0.001459962763225','75.3723677452491','75.372367745249093','test'),('2018-08-31 03:59:59','2018-08-31 15:59:59','BLZBTC','4h','0.000019600000000','0.000020100000000','0.001467500000000','0.001504936224490','74.87244897959185','74.872448979591852','test'),('2018-09-16 23:59:59','2018-09-17 03:59:59','BLZBTC','4h','0.000017600000000','0.000017410000000','0.001474974746929','0.001459051724093','83.80538334822444','83.805383348224439','test'),('2018-09-18 15:59:59','2018-09-19 11:59:59','BLZBTC','4h','0.000017860000000','0.000017070000000','0.001474974746929','0.001409732302916','82.58537216847705','82.585372168477051','test'),('2018-09-19 19:59:59','2018-09-19 23:59:59','BLZBTC','4h','0.000017440000000','0.000017500000000','0.001474974746929','0.001480049201334','84.57424007620413','84.574240076204134','test'),('2018-09-26 03:59:59','2018-09-26 07:59:59','BLZBTC','4h','0.000018220000000','0.000018560000000','0.001474974746929','0.001502498973820','80.9536085032382','80.953608503238200','test'),('2018-09-28 15:59:59','2018-09-28 19:59:59','BLZBTC','4h','0.000018310000000','0.000018100000000','0.001474974746929','0.001458058051306','80.5556934423266','80.555693442326600','test'),('2018-09-29 11:59:59','2018-10-05 07:59:59','BLZBTC','4h','0.000018590000000','0.000019010000000','0.001474974746929','0.001508298544331','79.3423747675632','79.342374767563200','test'),('2018-10-16 03:59:59','2018-10-16 07:59:59','BLZBTC','4h','0.000019260000000','0.000019610000000','0.001474974746929','0.001501778545549','76.58228177201454','76.582281772014539','test'),('2018-10-19 19:59:59','2018-10-22 03:59:59','BLZBTC','4h','0.000020010000000','0.000019760000000','0.001474974746929','0.001456546776578','73.71188140574712','73.711881405747121','test'),('2018-10-23 03:59:59','2018-10-23 11:59:59','BLZBTC','4h','0.000020130000000','0.000019820000000','0.001474974746929','0.001452260282371','73.27246631539991','73.272466315399910','test'),('2018-10-26 19:59:59','2018-10-27 11:59:59','BLZBTC','4h','0.000019920000000','0.000019710000000','0.001474974746929','0.001459425314356','74.04491701450803','74.044917014508030','test'),('2018-10-28 11:59:59','2018-10-28 15:59:59','BLZBTC','4h','0.000020140000000','0.000020140000000','0.001474974746929','0.001474974746929','73.23608475317775','73.236084753177749','test'),('2018-11-09 11:59:59','2018-11-09 15:59:59','BLZBTC','4h','0.000021520000000','0.000020800000000','0.001474974746929','0.001425626149448','68.53971872346654','68.539718723466535','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','BLZBTC','4h','0.000021400000000','0.000021200000000','0.001474974746929','0.001461189936210','68.92405359481309','68.924053594813088','test'),('2018-11-29 11:59:59','2018-11-29 15:59:59','BLZBTC','4h','0.000014700000000','0.000014600000000','0.001474974746929','0.001464940905113','100.33841815843537','100.338418158435374','test'),('2018-11-29 19:59:59','2018-11-29 23:59:59','BLZBTC','4h','0.000014730000000','0.000015050000000','0.001474974746929','0.001507017647066','100.13406292797013','100.134062927970135','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','BLZBTC','4h','0.000014750000000','0.000014770000000','0.001474974746929','0.001476974712688','99.99828792738984','99.998287927389839','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','BLZBTC','4h','0.000014350000000','0.000015080000000','0.001474974746929','0.001550008305484','102.78569665010453','102.785696650104526','test'),('2018-12-10 11:59:59','2018-12-10 23:59:59','BLZBTC','4h','0.000014160000000','0.000014040000000','0.001474974746929','0.001462474960938','104.16488325769774','104.164883257697738','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','BLZBTC','4h','0.000012420000000','0.000012110000000','0.001474974746929','0.001438159757271','118.75803115370371','118.758031153703712','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','BLZBTC','4h','0.000012370000000','0.000012650000000','0.001474974746929','0.001508361402478','119.23805553185124','119.238055531851245','test'),('2018-12-24 03:59:59','2018-12-24 11:59:59','BLZBTC','4h','0.000012370000000','0.000012210000000','0.001474974746929','0.001455896658044','119.23805553185124','119.238055531851245','test'),('2018-12-30 19:59:59','2018-12-31 03:59:59','BLZBTC','4h','0.000012360000000','0.000011520000000','0.001474974746929','0.001374733744711','119.33452645056634','119.334526450566344','test'),('2019-01-01 11:59:59','2019-01-01 15:59:59','BLZBTC','4h','0.000011560000000','0.000011440000000','0.001474974746929','0.001459663590386','127.59297118762976','127.592971187629757','test'),('2019-01-02 15:59:59','2019-01-02 19:59:59','BLZBTC','4h','0.000011470000000','0.000011620000000','0.001474974746929','0.001494263867421','128.59413661107234','128.594136611072344','test'),('2019-01-03 11:59:59','2019-01-03 23:59:59','BLZBTC','4h','0.000011570000000','0.000011430000000','0.001474974746929','0.001457127170043','127.48269204226449','127.482692042264489','test'),('2019-01-15 15:59:59','2019-01-15 23:59:59','BLZBTC','4h','0.000011330000000','0.000011270000000','0.001474974746929','0.001467163759743','130.1831197642542','130.183119764254201','test'),('2019-01-25 19:59:59','2019-01-25 23:59:59','BLZBTC','4h','0.000011780000000','0.000011820000000','0.001474974746929','0.001479983150144','125.21008038446519','125.210080384465186','test'),('2019-01-26 19:59:59','2019-01-26 23:59:59','BLZBTC','4h','0.000011770000000','0.000011750000000','0.001474974746929','0.001472468417707','125.31646108147832','125.316461081478323','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','BLZBTC','4h','0.000011450000000','0.000010900000000','0.001474974746929','0.001404124431574','128.81875519030567','128.818755190305666','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','BLZBTC','4h','0.000011020000000','0.000011040000000','0.001474974746929','0.001477651652096','133.84525834201452','133.845258342014517','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','BLZBTC','4h','0.000011000000000','0.000010740000000','0.001474974746929','0.001440111707456','134.08861335718183','134.088613357181828','test'),('2019-02-14 19:59:59','2019-02-14 23:59:59','BLZBTC','4h','0.000010910000000','0.000010760000000','0.001474974746929','0.001454695534093','135.1947522391384','135.194752239138410','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','BLZBTC','4h','0.000010950000000','0.000010970000000','0.001474974746929','0.001477668764732','134.70089013050227','134.700890130502273','test'),('2019-02-19 15:59:59','2019-02-19 19:59:59','BLZBTC','4h','0.000011260000000','0.000011050000000','0.001474974746929','0.001447466336906','130.99242867930727','130.992428679307267','test'),('2019-02-20 15:59:59','2019-02-20 23:59:59','BLZBTC','4h','0.000011200000000','0.000010870000000','0.001474974746929','0.001431515669564','131.69417383294643','131.694173832946433','test'),('2019-02-21 07:59:59','2019-02-21 11:59:59','BLZBTC','4h','0.000011260000000','0.000011110000000','0.001474974746929','0.001455325882627','130.99242867930727','130.992428679307267','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','BLZBTC','4h','0.000011420000000','0.000011280000000','0.001474974746929','0.001456892744778','129.15715822495622','129.157158224956220','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','BLZBTC','4h','0.000011250000000','0.000011210000000','0.001474974746929','0.001469730392273','131.10886639368888','131.108866393688885','test'),('2019-03-01 07:59:59','2019-03-18 23:59:59','BLZBTC','4h','0.000011370000000','0.000013950000000','0.001474974746929','0.001809665586602','129.72513165602462','129.725131656024615','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','BLZBTC','4h','0.000014130000000','0.000013490000000','0.001474974746929','0.001408167681251','104.38604012236377','104.386040122363767','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','BLZBTC','4h','0.000014000000000','0.000014000000000','0.001474974746929','0.001474974746929','105.35533906635715','105.355339066357146','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','BLZBTC','4h','0.000014010000000','0.000014950000000','0.001474974746929','0.001573938077558','105.28013896709493','105.280138967094928','test'),('2019-04-04 11:59:59','2019-04-04 15:59:59','BLZBTC','4h','0.000015360000000','0.000015250000000','0.001474974746929','0.001464411776736','96.0270017531901','96.027001753190106','test'),('2019-04-04 23:59:59','2019-04-08 11:59:59','BLZBTC','4h','0.000015220000000','0.000015840000000','0.001474974746929','0.001535059132152','96.91029874697766','96.910298746977659','test'),('2019-04-10 07:59:59','2019-04-10 11:59:59','BLZBTC','4h','0.000016000000000','0.000015810000000','0.001475284709661','0.001457765703734','92.20529435381252','92.205294353812519','test'),('2019-05-15 19:59:59','2019-05-16 11:59:59','BLZBTC','4h','0.000008210000000','0.000007480000000','0.001475284709661','0.001344108359106','179.69363089658953','179.693630896589525','test'),('2019-05-17 15:59:59','2019-05-17 19:59:59','BLZBTC','4h','0.000007730000000','0.000007660000000','0.001475284709661','0.001461925080984','190.85183824851228','190.851838248512280','test'),('2019-05-19 07:59:59','2019-05-19 23:59:59','BLZBTC','4h','0.000008550000000','0.000007610000000','0.001475284709661','0.001313089665558','172.5479192585965','172.547919258596494','test'),('2019-05-20 19:59:59','2019-05-20 23:59:59','BLZBTC','4h','0.000007800000000','0.000007750000000','0.001475284709661','0.001465827756394','189.13906534115384','189.139065341153838','test'),('2019-06-03 11:59:59','2019-06-03 19:59:59','BLZBTC','4h','0.000007620000000','0.000007740000000','0.001475284709661','0.001498517539734','193.60691727834646','193.606917278346458','test'),('2019-06-06 11:59:59','2019-06-06 19:59:59','BLZBTC','4h','0.000007610000000','0.000007470000000','0.001475284709661','0.001448144123675','193.86132847056504','193.861328470565041','test'),('2019-06-24 15:59:59','2019-06-24 19:59:59','BLZBTC','4h','0.000007100000000','0.000006750000000','0.001475284709661','0.001402559407072','207.78657882549297','207.786578825492967','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','BLZBTC','4h','0.000003700000000','0.000003690000000','0.001475284709661','0.001471297453689','398.7255972056757','398.725597205675683','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  3:52:16
