-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-29 07:59:59','2018-04-29 11:59:59','KMDBTC','4h','0.000427000000000','0.000420600000000','0.001467500000000','0.001445504683841','3.4367681498829037','3.436768149882904','test'),('2018-04-29 15:59:59','2018-04-30 23:59:59','KMDBTC','4h','0.000451600000000','0.000428000000000','0.001467500000000','0.001390810451727','3.24955713020372','3.249557130203720','test'),('2018-05-01 19:59:59','2018-05-02 03:59:59','KMDBTC','4h','0.000434200000000','0.000430200000000','0.001467500000000','0.001453980884385','3.3797789037309998','3.379778903731000','test'),('2018-05-02 19:59:59','2018-05-02 23:59:59','KMDBTC','4h','0.000429600000000','0.000434400000000','0.001467500000000','0.001483896648045','3.4159683426443204','3.415968342644320','test'),('2018-05-17 11:59:59','2018-05-17 15:59:59','KMDBTC','4h','0.000377800000000','0.000379500000000','0.001467500000000','0.001474103361567','3.8843303335097934','3.884330333509793','test'),('2018-05-18 19:59:59','2018-05-18 23:59:59','KMDBTC','4h','0.000383000000000','0.000381900000000','0.001467500000000','0.001463285248042','3.8315926892950394','3.831592689295039','test'),('2018-06-03 11:59:59','2018-06-03 15:59:59','KMDBTC','4h','0.000348500000000','0.000350100000000','0.001467500000000','0.001474237446198','4.21090387374462','4.210903873744620','test'),('2018-07-02 23:59:59','2018-07-03 03:59:59','KMDBTC','4h','0.000257600000000','0.000260900000000','0.001467500000000','0.001486299495342','5.696816770186336','5.696816770186336','test'),('2018-07-12 23:59:59','2018-07-13 07:59:59','KMDBTC','4h','0.000247400000000','0.000243000000000','0.001467500000000','0.001441400565885','5.931689571544059','5.931689571544059','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','KMDBTC','4h','0.000241700000000','0.000245000000000','0.001467500000000','0.001487536201903','6.071576334298718','6.071576334298718','test'),('2018-08-03 19:59:59','2018-08-03 23:59:59','KMDBTC','4h','0.000198900000000','0.000191000000000','0.001467500000000','0.001409213172448','7.378079436902966','7.378079436902966','test'),('2018-08-05 03:59:59','2018-08-08 03:59:59','KMDBTC','4h','0.000193900000000','0.000195300000000','0.001467500000000','0.001478095667870','7.56833419288293','7.568334192882930','test'),('2018-08-09 15:59:59','2018-08-10 15:59:59','KMDBTC','4h','0.000200400000000','0.000199100000000','0.001467500000000','0.001457980289421','7.322854291417166','7.322854291417166','test'),('2018-08-17 23:59:59','2018-08-18 07:59:59','KMDBTC','4h','0.000184100000000','0.000174900000000','0.001467500000000','0.001394164856056','7.971211298207496','7.971211298207496','test'),('2018-08-27 11:59:59','2018-08-27 15:59:59','KMDBTC','4h','0.000172900000000','0.000172500000000','0.001467500000000','0.001464104973973','8.487565066512435','8.487565066512435','test'),('2018-09-02 23:59:59','2018-09-03 11:59:59','KMDBTC','4h','0.000186500000000','0.000182200000000','0.001467500000000','0.001433664879357','7.868632707774799','7.868632707774799','test'),('2018-09-20 19:59:59','2018-09-24 11:59:59','KMDBTC','4h','0.000171200000000','0.000169000000000','0.001467500000000','0.001448641939252','8.571845794392525','8.571845794392525','test'),('2018-09-25 15:59:59','2018-09-25 19:59:59','KMDBTC','4h','0.000170700000000','0.000170600000000','0.001467500000000','0.001466640304628','8.596953719976566','8.596953719976566','test'),('2018-10-05 19:59:59','2018-10-05 23:59:59','KMDBTC','4h','0.000174500000000','0.000174200000000','0.001467500000000','0.001464977077364','8.40974212034384','8.409742120343839','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','KMDBTC','4h','0.000177000000000','0.000166100000000','0.001467500000000','0.001377128531073','8.290960451977401','8.290960451977401','test'),('2018-10-14 19:59:59','2018-10-20 15:59:59','KMDBTC','4h','0.000180100000000','0.000190000000000','0.001467500000000','0.001548167684620','8.1482509716824','8.148250971682399','test'),('2018-10-30 19:59:59','2018-10-30 23:59:59','KMDBTC','4h','0.000208000000000','0.000205800000000','0.001467500000000','0.001451978365385','7.055288461538463','7.055288461538463','test'),('2018-11-02 03:59:59','2018-11-02 23:59:59','KMDBTC','4h','0.000206700000000','0.000205700000000','0.001467500000000','0.001460400338655','7.099661344944364','7.099661344944364','test'),('2018-11-28 23:59:59','2018-11-29 03:59:59','KMDBTC','4h','0.000154400000000','0.000166500000000','0.001467500000000','0.001582504857513','9.504533678756477','9.504533678756477','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','KMDBTC','4h','0.000169600000000','0.000168300000000','0.001467500000000','0.001456251474057','8.652712264150944','8.652712264150944','test'),('2018-12-13 03:59:59','2018-12-13 23:59:59','KMDBTC','4h','0.000171400000000','0.000166100000000','0.001467500000000','0.001422122228705','8.561843640606769','8.561843640606769','test'),('2018-12-14 11:59:59','2018-12-14 15:59:59','KMDBTC','4h','0.000170800000000','0.000164300000000','0.001467500000000','0.001411652517564','8.59192037470726','8.591920374707261','test'),('2018-12-14 23:59:59','2018-12-15 11:59:59','KMDBTC','4h','0.000169300000000','0.000167400000000','0.001467500000000','0.001451030714708','8.668044890726522','8.668044890726522','test'),('2018-12-19 15:59:59','2018-12-19 23:59:59','KMDBTC','4h','0.000167900000000','0.000164500000000','0.001467500000000','0.001437782906492','8.740321620011914','8.740321620011914','test'),('2018-12-25 11:59:59','2018-12-25 15:59:59','KMDBTC','4h','0.000178500000000','0.000174900000000','0.001467500000000','0.001437903361345','8.221288515406163','8.221288515406163','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','KMDBTC','4h','0.000201900000000','0.000196600000000','0.001467500000000','0.001428977216444','7.268449727587915','7.268449727587915','test'),('2019-01-04 07:59:59','2019-01-04 15:59:59','KMDBTC','4h','0.000202900000000','0.000197400000000','0.001467500000000','0.001427720551996','7.232626909807787','7.232626909807787','test'),('2019-01-05 15:59:59','2019-01-05 23:59:59','KMDBTC','4h','0.000203700000000','0.000202000000000','0.001467500000000','0.001455252822779','7.204221894943545','7.204221894943545','test'),('2019-01-16 23:59:59','2019-01-17 07:59:59','KMDBTC','4h','0.000189900000000','0.000187800000000','0.001467500000000','0.001451271721959','7.727751448130595','7.727751448130595','test'),('2019-01-19 19:59:59','2019-01-20 03:59:59','KMDBTC','4h','0.000187500000000','0.000187900000000','0.001467500000000','0.001470630666667','7.826666666666667','7.826666666666667','test'),('2019-01-23 23:59:59','2019-01-24 03:59:59','KMDBTC','4h','0.000185700000000','0.000183000000000','0.001467500000000','0.001446163166397','7.902530963920302','7.902530963920302','test'),('2019-01-24 23:59:59','2019-01-25 03:59:59','KMDBTC','4h','0.000188100000000','0.000188400000000','0.001467500000000','0.001469840510367','7.801701222753855','7.801701222753855','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','KMDBTC','4h','0.000185600000000','0.000184400000000','0.001467500000000','0.001458011853448','7.906788793103448','7.906788793103448','test'),('2019-02-01 19:59:59','2019-02-03 15:59:59','KMDBTC','4h','0.000186900000000','0.000186800000000','0.001467500000000','0.001466714820760','7.851792402354201','7.851792402354201','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','KMDBTC','4h','0.000186000000000','0.000182000000000','0.001467500000000','0.001435940860215','7.88978494623656','7.889784946236560','test'),('2019-02-11 07:59:59','2019-02-11 11:59:59','KMDBTC','4h','0.000182400000000','0.000180400000000','0.001467500000000','0.001451408991228','8.045504385964913','8.045504385964913','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','KMDBTC','4h','0.000247700000000','0.000244400000000','0.001467500000000','0.001447949132015','5.9245054501413','5.924505450141300','test'),('2019-03-13 03:59:59','2019-03-13 15:59:59','KMDBTC','4h','0.000347400000000','0.000272900000000','0.001467500000000','0.001152794329303','4.224237190558434','4.224237190558434','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','KMDBTC','4h','0.000265200000000','0.000264100000000','0.001467500000000','0.001461413084465','5.533559577677225','5.533559577677225','test'),('2019-03-25 03:59:59','2019-03-25 11:59:59','KMDBTC','4h','0.000265900000000','0.000263400000000','0.001467500000000','0.001453702519744','5.518992102294096','5.518992102294096','test'),('2019-03-27 23:59:59','2019-03-28 03:59:59','KMDBTC','4h','0.000261600000000','0.000259400000000','0.001467500000000','0.001455158639144','5.609709480122324','5.609709480122324','test'),('2019-03-28 07:59:59','2019-03-30 03:59:59','KMDBTC','4h','0.000265400000000','0.000263500000000','0.001467500000000','0.001456994159759','5.5293896006028636','5.529389600602864','test'),('2019-04-17 19:59:59','2019-04-18 03:59:59','KMDBTC','4h','0.000226100000000','0.000216800000000','0.001467500000000','0.001407138434321','6.4904909332153915','6.490490933215392','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 12:28:07
