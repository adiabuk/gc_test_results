-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-28 07:59:59','2019-02-28 11:59:59','GOBNB','4h','0.002018000000000','0.001940000000000','0.711908500000000','0.684391719524282','352.7792368681864','352.779236868186388','test'),('2019-03-02 07:59:59','2019-03-02 23:59:59','GOBNB','4h','0.001965000000000','0.001922000000000','0.711908500000000','0.696329840712468','362.2944020356234','362.294402035623420','test'),('2019-03-03 23:59:59','2019-03-04 03:59:59','GOBNB','4h','0.001956000000000','0.001887000000000','0.711908500000000','0.686795163343558','363.961400817996','363.961400817995980','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','GOBNB','4h','0.001666000000000','0.001683000000000','0.711908500000000','0.719172872448980','427.3160264105643','427.316026410564291','test'),('2019-03-17 11:59:59','2019-03-19 07:59:59','GOBNB','4h','0.001700000000000','0.001648000000000','0.711908500000000','0.690132475294118','418.769705882353','418.769705882352980','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','GOBNB','4h','0.001686000000000','0.001645000000000','0.711908500000000','0.694596371589561','422.247034400949','422.247034400949019','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','GOBNB','4h','0.001693000000000','0.001679000000000','0.711908500000000','0.706021483461311','420.50118133490844','420.501181334908438','test'),('2019-03-22 23:59:59','2019-03-24 11:59:59','GOBNB','4h','0.001690000000000','0.001497000000000','0.711908500000000','0.630607706804734','421.2476331360947','421.247633136094692','test'),('2019-03-31 15:59:59','2019-04-03 03:59:59','GOBNB','4h','0.001844000000000','0.001661000000000','0.711908500000000','0.641258144522777','386.0675162689805','386.067516268980512','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GOBNB','4h','0.001688000000000','0.001580000000000','0.711908500000000','0.666359851895735','421.7467417061612','421.746741706161174','test'),('2019-04-04 23:59:59','2019-04-05 03:59:59','GOBNB','4h','0.001664000000000','0.001650000000000','0.711908500000000','0.705918885216346','427.8296274038462','427.829627403846189','test'),('2019-04-05 19:59:59','2019-04-07 23:59:59','GOBNB','4h','0.001695000000000','0.001673000000000','0.711908500000000','0.702668389675516','420.0050147492626','420.005014749262614','test'),('2019-04-17 15:59:59','2019-04-17 19:59:59','GOBNB','4h','0.001528000000000','0.001466000000000','0.711908500000000','0.683022160340314','465.9087041884817','465.908704188481693','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','GOBNB','4h','0.000944000000000','0.000924000000000','0.711908500000000','0.696825692796610','754.1403601694916','754.140360169491601','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','GOBNB','4h','0.000848000000000','0.000755000000000','0.711908500000000','0.633833629127359','839.5147405660377','839.514740566037744','test'),('2019-05-23 15:59:59','2019-05-24 07:59:59','GOBNB','4h','0.000825000000000','0.000773000000000','0.711908500000000','0.667036691515152','862.919393939394','862.919393939394013','test'),('2019-05-30 23:59:59','2019-05-31 03:59:59','GOBNB','4h','0.000756000000000','0.000719000000000','0.711908500000000','0.677066417328042','941.6779100529101','941.677910052910079','test'),('2019-05-31 11:59:59','2019-05-31 15:59:59','GOBNB','4h','0.000754000000000','0.000730000000000','0.711908500000000','0.689248282493369','944.1757294429709','944.175729442970919','test'),('2019-06-02 07:59:59','2019-06-02 11:59:59','GOBNB','4h','0.000745000000000','0.000731000000000','0.711908500000000','0.698530353691275','955.5818791946309','955.581879194630915','test'),('2019-06-05 15:59:59','2019-06-05 23:59:59','GOBNB','4h','0.000770000000000','0.000752000000000','0.711908500000000','0.695266483116883','924.5564935064937','924.556493506493666','test'),('2019-06-06 15:59:59','2019-06-06 19:59:59','GOBNB','4h','0.000763000000000','0.000754000000000','0.711908500000000','0.703511152031455','933.0386631716908','933.038663171690814','test'),('2019-06-07 11:59:59','2019-06-09 19:59:59','GOBNB','4h','0.000763000000000','0.000749000000000','0.711908500000000','0.698845958715596','933.0386631716908','933.038663171690814','test'),('2019-06-11 19:59:59','2019-06-12 03:59:59','GOBNB','4h','0.000799000000000','0.000740000000000','0.711908500000000','0.659339536921151','890.9993742177722','890.999374217772242','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','GOBNB','4h','0.000758000000000','0.000711000000000','0.711908500000000','0.667766416226913','939.1932717678101','939.193271767810074','test'),('2019-06-28 19:59:59','2019-06-29 19:59:59','GOBNB','4h','0.000574000000000','0.000551000000000','0.711908500000000','0.683382549651568','1240.2587108013938','1240.258710801393818','test'),('2019-06-30 03:59:59','2019-06-30 11:59:59','GOBNB','4h','0.000581000000000','0.000569000000000','0.474605666666667','0.464803139988526','816.877223178428','816.877223178428039','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','GOBNB','4h','0.000585000000000','0.000569000000000','0.529511800441733','0.515029426412557','905.1483768234748','905.148376823474791','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','GOBNB','4h','0.000564000000000','0.000576000000000','0.529511800441733','0.540778008961770','938.8507100030725','938.850710003072550','test'),('2019-07-21 07:59:59','2019-07-23 15:59:59','GOBNB','4h','0.000453200000000','0.000435400000000','0.529511800441733','0.508714558500288','1168.3843787328617','1168.384378732861705','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','GOBNB','4h','0.000443000000000','0.000443200000000','0.529511800441733','0.529750857687982','1195.286231245447','1195.286231245446970','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','GOBNB','4h','0.000442900000000','0.000435100000000','0.529511800441733','0.520186462795660','1195.5561084708354','1195.556108470835397','test'),('2019-07-26 19:59:59','2019-07-29 07:59:59','GOBNB','4h','0.000450700000000','0.000456800000000','0.529511800441733','0.536678478903447','1174.8653215924849','1174.865321592484861','test'),('2019-08-04 15:59:59','2019-08-05 11:59:59','GOBNB','4h','0.000433200000000','0.000435700000000','0.529511800441733','0.532567616464596','1222.3264091452745','1222.326409145274511','test'),('2019-08-06 15:59:59','2019-08-07 03:59:59','GOBNB','4h','0.000443200000000','0.000428400000000','0.529511800441733','0.511829547177885','1194.7468421519245','1194.746842151924511','test'),('2019-08-07 07:59:59','2019-08-07 15:59:59','GOBNB','4h','0.000449200000000','0.000409500000000','0.529511800441733','0.482713896440093','1178.7885138952201','1178.788513895220149','test'),('2019-08-16 03:59:59','2019-08-16 23:59:59','GOBNB','4h','0.000417300000000','0.000384200000000','0.529511800441733','0.487511223890999','1268.899593677769','1268.899593677768962','test'),('2019-08-17 15:59:59','2019-08-18 03:59:59','GOBNB','4h','0.000407600000000','0.000385000000000','0.529511800441733','0.500152215824502','1299.0966644792272','1299.096664479227229','test'),('2019-08-18 11:59:59','2019-08-18 19:59:59','GOBNB','4h','0.000398100000000','0.000388900000000','0.529511800441733','0.517274903772394','1330.097464058611','1330.097464058610967','test'),('2019-08-21 19:59:59','2019-09-02 03:59:59','GOBNB','4h','0.000395000000000','0.000441300000000','0.529511800441733','0.591578626670726','1340.5362036499569','1340.536203649956860','test'),('2019-09-04 03:59:59','2019-09-04 15:59:59','GOBNB','4h','0.000457700000000','0.000447200000000','0.529511800441733','0.517364380942851','1156.8970951315991','1156.897095131599144','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','GOBNB','4h','0.000458200000000','0.000430500000000','0.529511800441733','0.497500720406299','1155.6346583189284','1155.634658318928359','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','GOBNB','4h','0.000460000000000','0.000439400000000','0.529511800441733','0.505798880682821','1151.1126096559412','1151.112609655941242','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','GOBNB','4h','0.000461500000000','0.000434000000000','0.529511800441733','0.497959092939788','1147.3711818889121','1147.371181888912133','test'),('2019-09-13 07:59:59','2019-09-13 11:59:59','GOBNB','4h','0.000458000000000','0.000455700000000','0.529511800441733','0.526852680046502','1156.139302274526','1156.139302274526017','test'),('2019-09-15 07:59:59','2019-09-16 03:59:59','GOBNB','4h','0.000451900000000','0.000435800000000','0.529511800441733','0.510646697571381','1171.7455198976168','1171.745519897616759','test'),('2019-09-16 19:59:59','2019-09-17 11:59:59','GOBNB','4h','0.000464800000000','0.000463500000000','0.529511800441733','0.528030807884559','1139.225043979632','1139.225043979631891','test'),('2019-09-17 23:59:59','2019-09-18 07:59:59','GOBNB','4h','0.000457800000000','0.000451400000000','0.529511800441733','0.522109276363911','1156.6443871597487','1156.644387159748703','test'),('2019-10-10 15:59:59','2019-10-10 19:59:59','GOBNB','4h','0.000643700000000','0.000616800000000','0.529511800441733','0.507383685742521','822.6064943944897','822.606494394489687','test'),('2019-10-11 23:59:59','2019-10-12 07:59:59','GOBNB','4h','0.000632100000000','0.000631000000000','0.529511800441733','0.528590327604388','837.7025794047349','837.702579404734934','test'),('2019-11-12 11:59:59','2019-11-12 19:59:59','GOBNB','4h','0.000423400000000','0.000403100000000','0.529511800441733','0.504124248365760','1250.6183288656896','1250.618328865689591','test'),('2019-11-15 15:59:59','2019-11-16 03:59:59','GOBNB','4h','0.000409000000000','0.000448100000000','0.529511800441733','0.580132610704011','1294.6498788306428','1294.649878830642820','test'),('2020-01-01 19:59:59','2020-01-13 19:59:59','GOBNB','4h','0.001027900000000','0.001321300000000','0.529511800441733','0.680653703593406','515.1394108782304','515.139410878230365','test'),('2020-01-14 07:59:59','2020-01-14 11:59:59','GOBNB','4h','0.001350600000000','0.001324900000000','0.529511800441733','0.519435942844108','392.0567158609011','392.056715860901079','test'),('2020-01-20 07:59:59','2020-01-20 11:59:59','GOBNB','4h','0.001234900000000','0.001170000000000','0.529511800441733','0.501683380449290','428.7892140592218','428.789214059221820','test'),('2020-01-23 19:59:59','2020-01-23 23:59:59','GOBNB','4h','0.001165300000000','0.001138700000000','0.529511800441733','0.517424772301554','454.3995541420518','454.399554142051784','test'),('2020-01-24 03:59:59','2020-01-24 23:59:59','GOBNB','4h','0.001150000000000','0.001154200000000','0.529511800441733','0.531445669625955','460.4450438623765','460.445043862376508','test'),('2020-01-25 07:59:59','2020-01-25 15:59:59','GOBNB','4h','0.001160000000000','0.001164900000000','0.529511800441733','0.531748531322909','456.4756900359767','456.475690035976697','test'),('2020-01-29 07:59:59','2020-01-30 11:59:59','GOBNB','4h','0.001177500000000','0.001176000000000','0.529511800441733','0.528837263116330','449.69155026898767','449.691550268987669','test'),('2020-01-31 15:59:59','2020-02-02 23:59:59','GOBNB','4h','0.001193200000000','0.001205000000000','0.529511800441733','0.534748340204734','443.774556186501','443.774556186501002','test'),('2020-02-06 19:59:59','2020-02-07 07:59:59','GOBNB','4h','0.001233500000000','0.001168600000000','0.529511800441733','0.501651795700210','429.27588199573','429.275881995730003','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:39:04
