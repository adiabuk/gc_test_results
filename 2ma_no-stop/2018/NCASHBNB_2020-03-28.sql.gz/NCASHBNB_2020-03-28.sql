-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-17 11:59:59','2018-08-18 15:59:59','NCASHBNB','4h','0.000601000000000','0.000557000000000','0.711908500000000','0.659788742928453','1184.5399334442598','1184.539933444259759','test'),('2018-08-19 07:59:59','2018-08-20 23:59:59','NCASHBNB','4h','0.000572000000000','0.000576000000000','0.711908500000000','0.716886881118881','1244.5952797202797','1244.595279720279677','test'),('2018-08-23 19:59:59','2018-08-24 15:59:59','NCASHBNB','4h','0.000601000000000','0.000575000000000','0.711908500000000','0.681110461730449','1184.5399334442598','1184.539933444259759','test'),('2018-08-25 11:59:59','2018-08-25 15:59:59','NCASHBNB','4h','0.000591000000000','0.000590000000000','0.711908500000000','0.710703917089679','1204.582910321489','1204.582910321488953','test'),('2018-08-26 15:59:59','2018-08-27 15:59:59','NCASHBNB','4h','0.000603000000000','0.000574000000000','0.711908500000000','0.677670777777778','1180.611111111111','1180.611111111111086','test'),('2018-08-27 19:59:59','2018-08-27 23:59:59','NCASHBNB','4h','0.000598000000000','0.000630000000000','0.711908500000000','0.750003938127090','1190.482441471572','1190.482441471571974','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','NCASHBNB','4h','0.000578000000000','0.000555000000000','0.711908500000000','0.683579961072664','1231.6756055363323','1231.675605536332341','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','NCASHBNB','4h','0.000574000000000','0.000545000000000','0.711908500000000','0.675940997386760','1240.2587108013938','1240.258710801393818','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','NCASHBNB','4h','0.000564000000000','0.000562000000000','0.711908500000000','0.709384001773050','1262.2491134751772','1262.249113475177182','test'),('2018-09-21 03:59:59','2018-09-21 07:59:59','NCASHBNB','4h','0.000572000000000','0.000573000000000','0.711908500000000','0.713153095279720','1244.5952797202797','1244.595279720279677','test'),('2018-09-22 03:59:59','2018-09-22 07:59:59','NCASHBNB','4h','0.000567000000000','0.000554000000000','0.711908500000000','0.695586082892416','1255.5705467372134','1255.570546737213363','test'),('2018-09-23 11:59:59','2018-09-23 15:59:59','NCASHBNB','4h','0.000577000000000','0.000565000000000','0.711908500000000','0.697102777296360','1233.810225303293','1233.810225303293009','test'),('2018-09-25 15:59:59','2018-09-25 19:59:59','NCASHBNB','4h','0.000575000000000','0.000577000000000','0.711908500000000','0.714384703478261','1238.101739130435','1238.101739130434908','test'),('2018-10-10 19:59:59','2018-10-10 23:59:59','NCASHBNB','4h','0.000540000000000','0.000542000000000','0.711908500000000','0.714545198148148','1318.3490740740742','1318.349074074074224','test'),('2018-10-17 03:59:59','2018-10-17 07:59:59','NCASHBNB','4h','0.000510000000000','0.000509000000000','0.711908500000000','0.710512600980392','1395.8990196078432','1395.899019607843229','test'),('2018-10-18 07:59:59','2018-10-18 11:59:59','NCASHBNB','4h','0.000505000000000','0.000503000000000','0.711908500000000','0.709089060396040','1409.719801980198','1409.719801980198099','test'),('2018-10-20 11:59:59','2018-10-20 15:59:59','NCASHBNB','4h','0.000506000000000','0.000502000000000','0.711908500000000','0.706280764822134','1406.9337944664032','1406.933794466403242','test'),('2018-10-23 15:59:59','2018-10-27 11:59:59','NCASHBNB','4h','0.000533000000000','0.000518000000000','0.711908500000000','0.691873551594747','1335.6632270168855','1335.663227016885457','test'),('2018-10-28 07:59:59','2018-11-03 15:59:59','NCASHBNB','4h','0.000529000000000','0.000556000000000','0.711908500000000','0.748244094517958','1345.7627599243858','1345.762759924385819','test'),('2018-11-27 15:59:59','2018-11-27 23:59:59','NCASHBNB','4h','0.000429000000000','0.000426000000000','0.711908500000000','0.706930118881119','1659.460372960373','1659.460372960372979','test'),('2018-12-01 11:59:59','2018-12-02 15:59:59','NCASHBNB','4h','0.000454000000000','0.000441000000000','0.711908500000000','0.691523454845815','1568.080396475771','1568.080396475771067','test'),('2018-12-03 07:59:59','2018-12-03 11:59:59','NCASHBNB','4h','0.000437000000000','0.000428000000000','0.711908500000000','0.697246768878719','1629.0812356979407','1629.081235697940656','test'),('2018-12-19 11:59:59','2018-12-19 19:59:59','NCASHBNB','4h','0.000366000000000','0.000361000000000','0.711908500000000','0.702182974043716','1945.1051912568307','1945.105191256830722','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','NCASHBNB','4h','0.000292000000000','0.000282000000000','0.711908500000000','0.687528071917808','2438.0428082191784','2438.042808219178369','test'),('2019-01-24 03:59:59','2019-01-24 07:59:59','NCASHBNB','4h','0.000288000000000','0.000287000000000','0.711908500000000','0.709436595486111','2471.904513888889','2471.904513888889142','test'),('2019-01-28 23:59:59','2019-01-29 03:59:59','NCASHBNB','4h','0.000282000000000','0.000279000000000','0.711908500000000','0.704335005319149','2524.4982269503544','2524.498226950354365','test'),('2019-01-29 07:59:59','2019-01-29 11:59:59','NCASHBNB','4h','0.000280000000000','0.000273000000000','0.711908500000000','0.694110787500000','2542.5303571428576','2542.530357142857611','test'),('2019-01-30 03:59:59','2019-01-30 07:59:59','NCASHBNB','4h','0.000283000000000','0.000281000000000','0.711908500000000','0.706877344522968','2515.5777385159013','2515.577738515901274','test'),('2019-03-16 03:59:59','2019-03-16 07:59:59','NCASHBNB','4h','0.000129000000000','0.000127000000000','0.711908500000000','0.700871158914729','5518.670542635659','5518.670542635659331','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','NCASHBNB','4h','0.000125000000000','0.000123000000000','0.711908500000000','0.700517964000000','5695.268','5695.268000000000029','test'),('2019-03-27 23:59:59','2019-03-28 07:59:59','NCASHBNB','4h','0.000121000000000','0.000118000000000','0.711908500000000','0.694257876033058','5883.54132231405','5883.541322314050376','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','NCASHBNB','4h','0.000116000000000','0.000112000000000','0.711908500000000','0.687359931034483','6137.142241379311','6137.142241379310690','test'),('2019-04-06 15:59:59','2019-04-06 23:59:59','NCASHBNB','4h','0.000115000000000','0.000112000000000','0.711908500000000','0.693336973913043','6190.5086956521745','6190.508695652174538','test'),('2019-04-07 03:59:59','2019-04-10 19:59:59','NCASHBNB','4h','0.000116000000000','0.000119000000000','0.711908500000000','0.730319926724138','6137.142241379311','6137.142241379310690','test'),('2019-04-24 19:59:59','2019-04-24 23:59:59','NCASHBNB','4h','0.000095000000000','0.000089000000000','0.711908500000000','0.666945857894737','7493.773684210527','7493.773684210526881','test'),('2019-05-01 11:59:59','2019-05-02 11:59:59','NCASHBNB','4h','0.000092000000000','0.000084000000000','0.711908500000000','0.650003413043478','7738.135869565218','7738.135869565217945','test'),('2019-05-05 03:59:59','2019-05-05 15:59:59','NCASHBNB','4h','0.000085000000000','0.000084000000000','0.711908500000000','0.703533105882353','8375.394117647058','8375.394117647058010','test'),('2019-05-06 07:59:59','2019-05-07 03:59:59','NCASHBNB','4h','0.000086000000000','0.000083000000000','0.711908500000000','0.687074482558140','8278.005813953489','8278.005813953488541','test'),('2019-05-07 19:59:59','2019-05-08 03:59:59','NCASHBNB','4h','0.000086000000000','0.000084000000000','0.711908500000000','0.695352488372093','8278.005813953489','8278.005813953488541','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','NCASHBNB','4h','0.000085000000000','0.000083000000000','0.711908500000000','0.695157711764706','8375.394117647058','8375.394117647058010','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','NCASHBNB','4h','0.000085000000000','0.000083000000000','0.711908500000000','0.695157711764706','8375.394117647058','8375.394117647058010','test'),('2019-05-09 07:59:59','2019-05-09 11:59:59','NCASHBNB','4h','0.000085000000000','0.000083000000000','0.711908500000000','0.695157711764706','8375.394117647058','8375.394117647058010','test'),('2019-05-09 15:59:59','2019-05-11 15:59:59','NCASHBNB','4h','0.000090000000000','0.000085000000000','0.711908500000000','0.672358027777778','7910.094444444445','7910.094444444444889','test'),('2019-05-21 11:59:59','2019-05-21 15:59:59','NCASHBNB','4h','0.000080000000000','0.000071000000000','0.711908500000000','0.631818793750000','8898.85625','8898.856250000000728','test'),('2019-05-28 11:59:59','2019-05-30 03:59:59','NCASHBNB','4h','0.000071000000000','0.000070000000000','0.711908500000000','0.701881619718310','10026.88028169014','10026.880281690140691','test'),('2019-05-30 11:59:59','2019-05-30 23:59:59','NCASHBNB','4h','0.000071000000000','0.000071000000000','0.711908500000000','0.711908500000000','10026.88028169014','10026.880281690140691','test'),('2019-06-02 03:59:59','2019-06-02 11:59:59','NCASHBNB','4h','0.000071500000000','0.000070300000000','0.711908500000000','0.699960385314685','9956.762237762237','9956.762237762237419','test'),('2019-06-07 11:59:59','2019-06-07 19:59:59','NCASHBNB','4h','0.000070700000000','0.000070200000000','0.711908500000000','0.706873786421499','10069.427157001415','10069.427157001415253','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','NCASHBNB','4h','0.000069900000000','0.000069400000000','0.711908500000000','0.706816164520744','10184.67095851216','10184.670958512160723','test'),('2019-06-09 15:59:59','2019-06-09 19:59:59','NCASHBNB','4h','0.000070000000000','0.000067800000000','0.711908500000000','0.689534232857143','10170.12142857143','10170.121428571430442','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','NCASHBNB','4h','0.000070200000000','0.000068400000000','0.474605666666667','0.462436290598291','6760.76448243115','6760.764482431150100','test'),('2019-06-15 19:59:59','2019-06-17 07:59:59','NCASHBNB','4h','0.000078500000000','0.000068600000000','0.530562544440634','0.463650835014363','6758.758527906164','6758.758527906164090','test'),('2019-06-25 07:59:59','2019-06-29 23:59:59','NCASHBNB','4h','0.000071000000000','0.000073600000000','0.530562544440634','0.549991595363812','7472.711893530056','7472.711893530055931','test'),('2019-07-05 15:59:59','2019-07-05 19:59:59','NCASHBNB','4h','0.000090600000000','0.000085000000000','0.530562544440634','0.497768391583376','5856.098724510309','5856.098724510308784','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','NCASHBNB','4h','0.000087000000000','0.000087400000000','0.530562544440634','0.533001912461051','6098.42005104177','6098.420051041770421','test'),('2019-07-30 07:59:59','2019-07-30 11:59:59','NCASHBNB','4h','0.000058800000000','0.000056800000000','0.530562544440634','0.512516199391633','9023.172524500578','9023.172524500578220','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:07:37
