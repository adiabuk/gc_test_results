-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 15:59:59','2018-03-21 19:59:59','FUNBTC','4h','0.000004810000000','0.000004600000000','0.001467500000000','0.001403430353430','305.0935550935551','305.093555093555096','test'),('2018-03-22 07:59:59','2018-03-22 11:59:59','FUNBTC','4h','0.000004680000000','0.000004560000000','0.001467500000000','0.001429871794872','313.5683760683761','313.568376068376097','test'),('2018-03-23 19:59:59','2018-03-23 23:59:59','FUNBTC','4h','0.000004670000000','0.000004640000000','0.001467500000000','0.001458072805139','314.2398286937902','314.239828693790173','test'),('2018-03-27 15:59:59','2018-03-27 19:59:59','FUNBTC','4h','0.000004850000000','0.000004690000000','0.001467500000000','0.001419087628866','302.5773195876289','302.577319587628892','test'),('2018-03-28 11:59:59','2018-03-28 15:59:59','FUNBTC','4h','0.000004700000000','0.000004720000000','0.001467500000000','0.001473744680851','312.2340425531915','312.234042553191500','test'),('2018-04-11 07:59:59','2018-04-11 11:59:59','FUNBTC','4h','0.000004440000000','0.000004430000000','0.001467500000000','0.001464194819820','330.51801801801804','330.518018018018040','test'),('2018-04-29 19:59:59','2018-04-29 23:59:59','FUNBTC','4h','0.000005080000000','0.000005040000000','0.001467500000000','0.001455944881890','288.87795275590554','288.877952755905540','test'),('2018-04-30 03:59:59','2018-05-01 03:59:59','FUNBTC','4h','0.000005140000000','0.000005130000000','0.001467500000000','0.001464644941634','285.5058365758755','285.505836575875492','test'),('2018-05-04 19:59:59','2018-05-04 23:59:59','FUNBTC','4h','0.000005340000000','0.000005260000000','0.001467500000000','0.001445514981273','274.812734082397','274.812734082397014','test'),('2018-05-06 03:59:59','2018-05-06 07:59:59','FUNBTC','4h','0.000005450000000','0.000005200000000','0.001467500000000','0.001400183486239','269.26605504587155','269.266055045871553','test'),('2018-05-06 23:59:59','2018-05-11 07:59:59','FUNBTC','4h','0.000005530000000','0.000005370000000','0.001467500000000','0.001425040687161','265.370705244123','265.370705244122973','test'),('2018-05-13 15:59:59','2018-05-13 19:59:59','FUNBTC','4h','0.000005710000000','0.000005610000000','0.001467500000000','0.001441799474606','257.00525394045536','257.005253940455361','test'),('2018-05-15 07:59:59','2018-05-15 11:59:59','FUNBTC','4h','0.000005570000000','0.000005570000000','0.001467500000000','0.001467500000000','263.46499102333934','263.464991023339337','test'),('2018-05-17 15:59:59','2018-05-18 07:59:59','FUNBTC','4h','0.000005600000000','0.000005720000000','0.001467500000000','0.001498946428571','262.05357142857144','262.053571428571445','test'),('2018-06-21 23:59:59','2018-06-22 23:59:59','FUNBTC','4h','0.000004430000000','0.000003970000000','0.001467500000000','0.001315118510158','331.2641083521445','331.264108352144490','test'),('2018-06-23 11:59:59','2018-06-23 15:59:59','FUNBTC','4h','0.000003990000000','0.000003970000000','0.001467500000000','0.001460144110276','367.7944862155389','367.794486215538882','test'),('2018-06-23 23:59:59','2018-06-24 07:59:59','FUNBTC','4h','0.000004000000000','0.000003850000000','0.001467500000000','0.001412468750000','366.87500000000006','366.875000000000057','test'),('2018-06-30 15:59:59','2018-06-30 19:59:59','FUNBTC','4h','0.000003910000000','0.000003860000000','0.001467500000000','0.001448734015345','375.3196930946292','375.319693094629201','test'),('2018-07-01 07:59:59','2018-07-01 11:59:59','FUNBTC','4h','0.000003980000000','0.000003970000000','0.001467500000000','0.001463812814070','368.71859296482415','368.718592964824154','test'),('2018-07-18 03:59:59','2018-07-18 19:59:59','FUNBTC','4h','0.000004140000000','0.000003990000000','0.001467500000000','0.001414329710145','354.4685990338164','354.468599033816417','test'),('2018-08-06 03:59:59','2018-08-06 11:59:59','FUNBTC','4h','0.000003130000000','0.000003100000000','0.001467500000000','0.001453434504792','468.84984025559106','468.849840255591062','test'),('2018-08-16 07:59:59','2018-08-17 03:59:59','FUNBTC','4h','0.000002920000000','0.000002950000000','0.001467500000000','0.001482577054795','502.56849315068496','502.568493150684958','test'),('2018-09-16 15:59:59','2018-09-24 23:59:59','FUNBTC','4h','0.000002310000000','0.000002530000000','0.001467500000000','0.001607261904762','635.2813852813854','635.281385281385383','test'),('2018-09-25 15:59:59','2018-09-25 19:59:59','FUNBTC','4h','0.000002610000000','0.000002500000000','0.001467500000000','0.001405651340996','562.2605363984675','562.260536398467480','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','FUNBTC','4h','0.000002600000000','0.000002550000000','0.001467500000000','0.001439278846154','564.4230769230769','564.423076923076906','test'),('2018-10-02 03:59:59','2018-10-02 11:59:59','FUNBTC','4h','0.000002550000000','0.000002450000000','0.001467500000000','0.001409950980392','575.4901960784314','575.490196078431381','test'),('2018-10-08 23:59:59','2018-10-09 03:59:59','FUNBTC','4h','0.000002420000000','0.000002420000000','0.001467500000000','0.001467500000000','606.404958677686','606.404958677685954','test'),('2018-10-10 23:59:59','2018-10-11 03:59:59','FUNBTC','4h','0.000002420000000','0.000002350000000','0.001467500000000','0.001425051652893','606.404958677686','606.404958677685954','test'),('2018-10-18 07:59:59','2018-10-18 15:59:59','FUNBTC','4h','0.000002320000000','0.000002340000000','0.001467500000000','0.001480150862069','632.5431034482759','632.543103448275929','test'),('2018-10-19 19:59:59','2018-10-19 23:59:59','FUNBTC','4h','0.000002300000000','0.000002280000000','0.001467500000000','0.001454739130435','638.0434782608696','638.043478260869620','test'),('2018-10-28 19:59:59','2018-10-29 03:59:59','FUNBTC','4h','0.000002250000000','0.000002300000000','0.001467500000000','0.001500111111111','652.2222222222223','652.222222222222285','test'),('2018-11-04 07:59:59','2018-11-04 11:59:59','FUNBTC','4h','0.000002240000000','0.000002180000000','0.001467500000000','0.001428191964286','655.1339285714286','655.133928571428555','test'),('2018-11-28 19:59:59','2018-11-29 07:59:59','FUNBTC','4h','0.000001530000000','0.000001410000000','0.001467500000000','0.001352401960784','959.1503267973857','959.150326797385674','test'),('2018-12-10 03:59:59','2018-12-10 07:59:59','FUNBTC','4h','0.000001240000000','0.000001220000000','0.001467500000000','0.001443830645161','1183.467741935484','1183.467741935483900','test'),('2018-12-19 11:59:59','2018-12-21 03:59:59','FUNBTC','4h','0.000001170000000','0.000001140000000','0.001467500000000','0.001429871794872','1254.2735042735044','1254.273504273504386','test'),('2018-12-21 11:59:59','2018-12-25 07:59:59','FUNBTC','4h','0.000001170000000','0.000001200000000','0.001467500000000','0.001505128205128','1254.2735042735044','1254.273504273504386','test'),('2018-12-26 19:59:59','2018-12-27 03:59:59','FUNBTC','4h','0.000001190000000','0.000001190000000','0.001467500000000','0.001467500000000','1233.1932773109243','1233.193277310924259','test'),('2019-01-04 19:59:59','2019-01-06 03:59:59','FUNBTC','4h','0.000001160000000','0.000001160000000','0.001467500000000','0.001467500000000','1265.0862068965519','1265.086206896551857','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','FUNBTC','4h','0.000001150000000','0.000001160000000','0.001467500000000','0.001480260869565','1276.0869565217392','1276.086956521739239','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','FUNBTC','4h','0.000001150000000','0.000001160000000','0.001467500000000','0.001480260869565','1276.0869565217392','1276.086956521739239','test'),('2019-01-12 19:59:59','2019-01-13 03:59:59','FUNBTC','4h','0.000001160000000','0.000001150000000','0.001467500000000','0.001454849137931','1265.0862068965519','1265.086206896551857','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','FUNBTC','4h','0.000001150000000','0.000001150000000','0.001467500000000','0.001467500000000','1276.0869565217392','1276.086956521739239','test'),('2019-01-16 07:59:59','2019-01-23 23:59:59','FUNBTC','4h','0.000001160000000','0.000001290000000','0.001467500000000','0.001631961206897','1265.0862068965519','1265.086206896551857','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','FUNBTC','4h','0.000001160000000','0.000001140000000','0.001467500000000','0.001442198275862','1265.0862068965519','1265.086206896551857','test'),('2019-02-04 07:59:59','2019-02-04 11:59:59','FUNBTC','4h','0.000001160000000','0.000001110000000','0.001467500000000','0.001404245689655','1265.0862068965519','1265.086206896551857','test'),('2019-02-27 03:59:59','2019-02-27 07:59:59','FUNBTC','4h','0.000001010000000','0.000001010000000','0.001467500000000','0.001467500000000','1452.970297029703','1452.970297029703033','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','FUNBTC','4h','0.000001010000000','0.000000990000000','0.001467500000000','0.001438440594059','1452.970297029703','1452.970297029703033','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','FUNBTC','4h','0.000001000000000','0.000000990000000','0.001467500000000','0.001452825000000','1467.5000000000002','1467.500000000000227','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','FUNBTC','4h','0.000001000000000','0.000001000000000','0.001467500000000','0.001467500000000','1467.5000000000002','1467.500000000000227','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','FUNBTC','4h','0.000001010000000','0.000001020000000','0.001467500000000','0.001482029702970','1452.970297029703','1452.970297029703033','test'),('2019-03-09 23:59:59','2019-03-10 03:59:59','FUNBTC','4h','0.000001030000000','0.000001040000000','0.001467500000000','0.001481747572816','1424.757281553398','1424.757281553397888','test'),('2019-03-11 15:59:59','2019-03-15 15:59:59','FUNBTC','4h','0.000001030000000','0.000001140000000','0.001467500000000','0.001624223300971','1424.757281553398','1424.757281553397888','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:57:16
