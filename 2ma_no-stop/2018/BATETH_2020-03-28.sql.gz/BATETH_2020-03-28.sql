-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-14 19:59:59','BATETH','4h','0.000560810000000','0.000563710000000','0.072144500000000','0.072517565833348','128.64339080972164','128.643390809721637','test'),('2018-05-16 11:59:59','2018-05-16 23:59:59','BATETH','4h','0.000565900000000','0.000556830000000','0.072237766458337','0.071079970837596','127.65111584791835','127.651115847918348','test'),('2018-05-24 03:59:59','2018-05-24 07:59:59','BATETH','4h','0.000539450000000','0.000516750000000','0.072237766458337','0.069198008744732','133.9100314363463','133.910031436346287','test'),('2018-05-24 19:59:59','2018-05-24 23:59:59','BATETH','4h','0.000529500000000','0.000525350000000','0.072237766458337','0.071671596995066','136.42637669185459','136.426376691854585','test'),('2018-05-30 07:59:59','2018-05-30 11:59:59','BATETH','4h','0.000510300000000','0.000506900000000','0.072237766458337','0.071756464467433','141.5594090894317','141.559409089431711','test'),('2018-06-03 07:59:59','2018-06-03 11:59:59','BATETH','4h','0.000503910000000','0.000501770000000','0.072237766458337','0.071930987826794','143.35450072103552','143.354500721035521','test'),('2018-06-15 11:59:59','2018-06-19 19:59:59','BATETH','4h','0.000465700000000','0.000467440000000','0.072237766458337','0.072507669214698','155.11652664448573','155.116526644485731','test'),('2018-06-20 15:59:59','2018-06-26 15:59:59','BATETH','4h','0.000478430000000','0.000536620000000','0.072237766458337','0.081023828432316','150.9892073204795','150.989207320479494','test'),('2018-06-27 11:59:59','2018-06-27 15:59:59','BATETH','4h','0.000528350000000','0.000525450000000','0.073113806785906','0.072712500758312','138.38138882541116','138.381388825411165','test'),('2018-06-28 03:59:59','2018-06-28 07:59:59','BATETH','4h','0.000529990000000','0.000516020000000','0.073113806785906','0.071186600837116','137.9531817315534','137.953181731553400','test'),('2018-06-30 11:59:59','2018-07-03 23:59:59','BATETH','4h','0.000522520000000','0.000545690000000','0.073113806785906','0.076355877717601','139.92537469552553','139.925374695525534','test'),('2018-07-06 23:59:59','2018-07-08 07:59:59','BATETH','4h','0.000569720000000','0.000547490000000','0.073342196524734','0.070480445087634','128.73375785426833','128.733757854268333','test'),('2018-07-29 03:59:59','2018-07-29 07:59:59','BATETH','4h','0.000704870000000','0.000701340000000','0.073342196524734','0.072974897655819','104.05067108081491','104.050671080814908','test'),('2018-08-02 03:59:59','2018-08-02 07:59:59','BATETH','4h','0.000687310000000','0.000676430000000','0.073342196524734','0.072181202070719','106.70904908226856','106.709049082268564','test'),('2018-08-06 23:59:59','2018-08-07 03:59:59','BATETH','4h','0.000665000000000','0.000680360000000','0.073342196524734','0.075036235830929','110.28901733042707','110.289017330427072','test'),('2018-08-09 19:59:59','2018-08-09 23:59:59','BATETH','4h','0.000669450000000','0.000680000000000','0.073342196524734','0.074498011258226','109.55589890915527','109.555898909155275','test'),('2018-08-11 03:59:59','2018-08-11 07:59:59','BATETH','4h','0.000672420000000','0.000643900000000','0.073342196524734','0.070231462987829','109.07200339777819','109.072003397778190','test'),('2018-08-11 15:59:59','2018-08-12 03:59:59','BATETH','4h','0.000674950000000','0.000665040000000','0.073342196524734','0.072265344657840','108.6631550851678','108.663155085167801','test'),('2018-08-13 03:59:59','2018-08-13 19:59:59','BATETH','4h','0.000672310000000','0.000693070000000','0.073342196524734','0.075606901794406','109.08984921350866','109.089849213508657','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','BATETH','4h','0.000696410000000','0.000667080000000','0.073342196524734','0.070253316950819','105.31468032442672','105.314680324426718','test'),('2018-08-16 15:59:59','2018-08-18 15:59:59','BATETH','4h','0.000673430000000','0.000694910000000','0.073342196524734','0.075681549362225','108.90841887758788','108.908418877587877','test'),('2018-09-11 07:59:59','2018-09-11 19:59:59','BATETH','4h','0.000795750000000','0.000788750000000','0.073342196524734','0.072697024830517','92.16738488813573','92.167384888135729','test'),('2018-09-12 15:59:59','2018-09-12 19:59:59','BATETH','4h','0.000796010000000','0.000801000000000','0.073342196524734','0.073801961553639','92.13728034162135','92.137280341621349','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','BATETH','4h','0.000782710000000','0.000739460000000','0.073342196524734','0.069289546118204','93.70289957293761','93.702899572937611','test'),('2018-09-25 15:59:59','2018-09-25 23:59:59','BATETH','4h','0.000743400000000','0.000758140000000','0.073342196524734','0.074796412258894','98.657783864318','98.657783864318006','test'),('2018-10-01 11:59:59','2018-10-01 15:59:59','BATETH','4h','0.000747070000000','0.000743160000000','0.073342196524734','0.072958339605822','98.17312504147404','98.173125041474037','test'),('2018-10-02 03:59:59','2018-10-06 19:59:59','BATETH','4h','0.000757580000000','0.000763050000000','0.073342196524734','0.073871753555002','96.81115727016818','96.811157270168181','test'),('2018-10-30 03:59:59','2018-11-09 07:59:59','BATETH','4h','0.001205800000000','0.001374940000000','0.073342196524734','0.083630054478121','60.82451196279152','60.824511962791519','test'),('2018-11-16 19:59:59','2018-11-16 23:59:59','BATETH','4h','0.001279030000000','0.001286040000000','0.074201476308775','0.074608153516444','58.01386699981663','58.013866999816628','test'),('2018-11-21 23:59:59','2018-11-24 23:59:59','BATETH','4h','0.001281700000000','0.001298070000000','0.074303145610693','0.075252152783703','57.97233799695149','57.972337996951488','test'),('2018-11-26 03:59:59','2018-11-26 11:59:59','BATETH','4h','0.001285250000000','0.001272750000000','0.074540397403945','0.073815437304704','57.9968079392688','57.996807939268798','test'),('2018-11-27 03:59:59','2018-11-27 11:59:59','BATETH','4h','0.001284300000000','0.001282410000000','0.074540397403945','0.074430702355208','58.03970832667212','58.039708326672120','test'),('2018-12-07 03:59:59','2018-12-07 19:59:59','BATETH','4h','0.001461700000000','0.001401440000000','0.074540397403945','0.071467397234579','50.99568817400629','50.995688174006290','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','BATETH','4h','0.001525090000000','0.001510200000000','0.074540397403945','0.073812632801630','48.87606462828095','48.876064628280950','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','BATETH','4h','0.001518360000000','0.001501140000000','0.074540397403945','0.073695021048340','49.09270357750796','49.092703577507962','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','BATETH','4h','0.000963000000000','0.000967160000000','0.074540397403945','0.074862399536033','77.40435867491692','77.404358674916921','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','BATETH','4h','0.001004180000000','0.001030120000000','0.074540397403945','0.076465926600561','74.23011552106695','74.230115521066949','test'),('2019-02-06 23:59:59','2019-02-08 11:59:59','BATETH','4h','0.001117500000000','0.001045980000000','0.074540397403945','0.069769811970093','66.70281646885458','66.702816468854579','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','BATETH','4h','0.001079190000000','0.001055870000000','0.074540397403945','0.072929668924752','69.07068950226095','69.070689502260947','test'),('2019-02-14 11:59:59','2019-02-17 15:59:59','BATETH','4h','0.001052000000000','0.001036360000000','0.074540397403945','0.073432211267635','70.85589106838879','70.855891068388786','test'),('2019-02-25 23:59:59','2019-03-16 07:59:59','BATETH','4h','0.001081560000000','0.001402780000000','0.074540397403945','0.096678666620720','68.91933633265376','68.919336332653756','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','BATETH','4h','0.001396580000000','0.001393260000000','0.077394273459160','0.077210289020113','55.41699971298474','55.416999712984740','test'),('2019-03-18 11:59:59','2019-03-19 03:59:59','BATETH','4h','0.001410000000000','0.001406240000000','0.077394273459160','0.077187888729936','54.88955564479433','54.889555644794328','test'),('2019-03-21 03:59:59','2019-04-03 19:59:59','BATETH','4h','0.001402330000000','0.001735270000000','0.077394273459160','0.095769156265270','55.18977234970371','55.189772349703709','test'),('2019-04-04 03:59:59','2019-04-04 11:59:59','BATETH','4h','0.001831660000000','0.001795180000000','0.081890401868620','0.080259443142564','44.70829841161568','44.708298411615679','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','BATETH','4h','0.001826250000000','0.001785780000000','0.081890401868620','0.080075697110989','44.84074024291307','44.840740242913071','test'),('2019-04-05 15:59:59','2019-04-05 19:59:59','BATETH','4h','0.001798000000000','0.001911530000000','0.081890401868620','0.087061156776376','45.545273564304786','45.545273564304786','test'),('2019-04-06 23:59:59','2019-04-07 07:59:59','BATETH','4h','0.001829790000000','0.001820710000000','0.082321674724637','0.081913168389757','44.989684458127556','44.989684458127556','test'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BATETH','4h','0.001743100000000','0.001750990000000','0.082321674724637','0.082694297071936','47.227166958084446','47.227166958084446','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:32:17
