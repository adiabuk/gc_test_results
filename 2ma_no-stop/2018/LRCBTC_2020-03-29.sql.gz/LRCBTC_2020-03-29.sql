-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-26 07:59:59','2018-05-03 19:59:59','LRCBTC','4h','0.000085500000000','0.000095510000000','0.001467500000000','0.001639309064327','17.16374269005848','17.163742690058481','test'),('2018-05-04 07:59:59','2018-05-04 15:59:59','LRCBTC','4h','0.000096240000000','0.000092050000000','0.001510452266082','0.001444691719585','15.694641168762988','15.694641168762988','test'),('2018-05-05 19:59:59','2018-05-06 03:59:59','LRCBTC','4h','0.000095570000000','0.000091920000000','0.001510452266082','0.001452765222332','15.804669520581774','15.804669520581774','test'),('2018-05-16 03:59:59','2018-05-16 07:59:59','LRCBTC','4h','0.000082680000000','0.000084870000000','0.001510452266082','0.001550460617107','18.268653435921625','18.268653435921625','test'),('2018-05-31 19:59:59','2018-05-31 23:59:59','LRCBTC','4h','0.000071980000000','0.000069300000000','0.001510452266082','0.001454214254508','20.984332676882467','20.984332676882467','test'),('2018-06-02 07:59:59','2018-06-02 11:59:59','LRCBTC','4h','0.000069240000000','0.000068510000000','0.001510452266082','0.001494527509377','21.81473521204506','21.814735212045061','test'),('2018-06-02 15:59:59','2018-06-02 19:59:59','LRCBTC','4h','0.000068870000000','0.000068040000000','0.001510452266082','0.001492248761205','21.931933586205897','21.931933586205897','test'),('2018-06-03 07:59:59','2018-06-04 07:59:59','LRCBTC','4h','0.000069380000000','0.000068260000000','0.001510452266082','0.001486069064323','21.77071585589507','21.770715855895070','test'),('2018-06-05 19:59:59','2018-06-06 19:59:59','LRCBTC','4h','0.000070790000000','0.000069830000000','0.001510452266082','0.001489968664225','21.3370852674389','21.337085267438901','test'),('2018-06-28 15:59:59','2018-06-28 19:59:59','LRCBTC','4h','0.000054830000000','0.000054270000000','0.001510452266082','0.001495025432797','27.54791658001094','27.547916580010941','test'),('2018-06-30 03:59:59','2018-06-30 07:59:59','LRCBTC','4h','0.000055080000000','0.000053620000000','0.001510452266082','0.001470414860336','27.42288064782135','27.422880647821351','test'),('2018-06-30 11:59:59','2018-06-30 15:59:59','LRCBTC','4h','0.000057160000000','0.000054970000000','0.001510452266082','0.001452581544201','26.424987160286914','26.424987160286914','test'),('2018-07-02 19:59:59','2018-07-03 11:59:59','LRCBTC','4h','0.000055070000000','0.000054700000000','0.001510452266082','0.001500303957775','27.427860288396587','27.427860288396587','test'),('2018-07-04 23:59:59','2018-07-05 03:59:59','LRCBTC','4h','0.000055640000000','0.000054920000000','0.001510452266082','0.001490906514256','27.146877535621854','27.146877535621854','test'),('2018-07-17 11:59:59','2018-07-17 19:59:59','LRCBTC','4h','0.000045860000000','0.000043840000000','0.001510452266082','0.001443921224270','32.93615931273441','32.936159312734411','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','LRCBTC','4h','0.000045730000000','0.000044230000000','0.001510452266082','0.001460907582086','33.029789330461405','33.029789330461405','test'),('2018-08-17 23:59:59','2018-08-18 07:59:59','LRCBTC','4h','0.000020310000000','0.000018010000000','0.001510452266082','0.001339401541710','74.36988016159528','74.369880161595276','test'),('2018-08-26 23:59:59','2018-08-30 11:59:59','LRCBTC','4h','0.000017220000000','0.000016770000000','0.001510452266082','0.001470980516968','87.71499803031358','87.714998030313581','test'),('2018-09-01 15:59:59','2018-09-02 03:59:59','LRCBTC','4h','0.000017680000000','0.000017550000000','0.001510452266082','0.001499345999420','85.43282047975113','85.432820479751129','test'),('2018-09-04 15:59:59','2018-09-04 19:59:59','LRCBTC','4h','0.000017500000000','0.000017250000000','0.001510452266082','0.001488874376567','86.31155806182858','86.311558061828578','test'),('2018-09-16 23:59:59','2018-09-17 07:59:59','LRCBTC','4h','0.000014690000000','0.000014360000000','0.001510452266082','0.001476521071541','102.82180163934649','102.821801639346489','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','LRCBTC','4h','0.000014900000000','0.000014330000000','0.001510452266082','0.001452669863957','101.37263530751677','101.372635307516774','test'),('2018-09-19 15:59:59','2018-09-19 19:59:59','LRCBTC','4h','0.000014400000000','0.000014630000000','0.001510452266082','0.001534577545332','104.89251847791667','104.892518477916667','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','LRCBTC','4h','0.000014880000000','0.000014620000000','0.001510452266082','0.001484059954981','101.50888884959677','101.508888849596772','test'),('2018-09-27 03:59:59','2018-09-27 07:59:59','LRCBTC','4h','0.000014810000000','0.000014470000000','0.001510452266082','0.001475776116827','101.98867427967589','101.988674279675891','test'),('2018-09-28 03:59:59','2018-09-28 07:59:59','LRCBTC','4h','0.000014720000000','0.000014930000000','0.001510452266082','0.001532000837813','102.61224633709239','102.612246337092387','test'),('2018-10-13 11:59:59','2018-10-13 23:59:59','LRCBTC','4h','0.000016790000000','0.000016950000000','0.001510452266082','0.001524846093513','89.96142144621798','89.961421446217983','test'),('2018-10-16 03:59:59','2018-10-16 07:59:59','LRCBTC','4h','0.000017000000000','0.000016630000000','0.001510452266082','0.001477577716761','88.85013329894117','88.850133298941174','test'),('2018-10-19 15:59:59','2018-10-19 19:59:59','LRCBTC','4h','0.000016810000000','0.000016870000000','0.001510452266082','0.001515843529376','89.85438822617489','89.854388226174891','test'),('2018-10-28 23:59:59','2018-10-29 03:59:59','LRCBTC','4h','0.000017710000000','0.000017440000000','0.001510452266082','0.001487424478852','85.28810085160926','85.288100851609258','test'),('2018-10-31 07:59:59','2018-10-31 11:59:59','LRCBTC','4h','0.000017690000000','0.000017360000000','0.001510452266082','0.001482275372481','85.38452606455625','85.384526064556255','test'),('2018-10-31 19:59:59','2018-11-04 11:59:59','LRCBTC','4h','0.000017950000000','0.000017750000000','0.001510452266082','0.001493622714371','84.14775855610029','84.147758556100285','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','LRCBTC','4h','0.000012020000000','0.000011730000000','0.001510452266082','0.001474010406085','125.66158619650582','125.661586196505823','test'),('2018-12-05 15:59:59','2018-12-06 11:59:59','LRCBTC','4h','0.000013330000000','0.000011010000000','0.001510452266082','0.001247567850680','113.31224801815455','113.312248018154548','test'),('2018-12-06 15:59:59','2018-12-06 19:59:59','LRCBTC','4h','0.000012620000000','0.000011270000000','0.001510452266082','0.001348874567254','119.6871843171157','119.687184317115694','test'),('2018-12-17 15:59:59','2018-12-18 03:59:59','LRCBTC','4h','0.000010750000000','0.000010620000000','0.001510452266082','0.001492186331701','140.50718754251162','140.507187542511616','test'),('2018-12-21 11:59:59','2018-12-25 07:59:59','LRCBTC','4h','0.000010870000000','0.000011080000000','0.001510452266082','0.001539633036632','138.9560502375345','138.956050237534498','test'),('2018-12-26 03:59:59','2018-12-26 11:59:59','LRCBTC','4h','0.000011290000000','0.000011080000000','0.001510452266082','0.001482357051212','133.7867374740478','133.786737474047811','test'),('2018-12-28 19:59:59','2018-12-29 03:59:59','LRCBTC','4h','0.000011180000000','0.000011080000000','0.001510452266082','0.001496941959588','135.10306494472272','135.103064944722718','test'),('2019-01-01 23:59:59','2019-01-02 19:59:59','LRCBTC','4h','0.000011000000000','0.000010900000000','0.001510452266082','0.001496720881845','137.3138423710909','137.313842371090914','test'),('2019-01-04 07:59:59','2019-01-04 11:59:59','LRCBTC','4h','0.000010900000000','0.000010880000000','0.001510452266082','0.001507680794034','138.57360239284404','138.573602392844037','test'),('2019-01-05 07:59:59','2019-01-06 23:59:59','LRCBTC','4h','0.000010900000000','0.000011000000000','0.001510452266082','0.001524309626321','138.57360239284404','138.573602392844037','test'),('2019-01-07 23:59:59','2019-01-08 23:59:59','LRCBTC','4h','0.000011820000000','0.000010900000000','0.001510452266082','0.001392887453494','127.78783977005075','127.787839770050752','test'),('2019-01-11 15:59:59','2019-01-12 03:59:59','LRCBTC','4h','0.000011040000000','0.000011000000000','0.001006968177388','0.001003319741963','91.21088563297101','91.210885632971014','test'),('2019-01-14 03:59:59','2019-01-14 07:59:59','LRCBTC','4h','0.000011110000000','0.000011080000000','0.001129285017789','0.001126235643304','101.64581618265079','101.645816182650790','test'),('2019-02-14 11:59:59','2019-02-15 03:59:59','LRCBTC','4h','0.000015860000000','0.000015310000000','0.001129285017789','0.001090123179215','71.20334286185371','71.203342861853713','test'),('2019-02-18 07:59:59','2019-02-18 11:59:59','LRCBTC','4h','0.000015430000000','0.000015280000000','0.001129285017789','0.001118306874389','73.18762266941023','73.187622669410231','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','LRCBTC','4h','0.000014490000000','0.000014280000000','0.001129285017789','0.001112918568256','77.93547396749481','77.935473967494815','test'),('2019-02-26 23:59:59','2019-02-27 03:59:59','LRCBTC','4h','0.000014470000000','0.000014830000000','0.001129285017789','0.001157380567644','78.04319404208707','78.043194042087066','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LRCBTC','4h','0.000014720000000','0.000014810000000','0.001129285017789','0.001136189613686','76.71773218675271','76.717732186752713','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','LRCBTC','4h','0.000015880000000','0.000015870000000','0.001129285017789','0.001128573881128','71.11366610761964','71.113666107619636','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','LRCBTC','4h','0.000015900000000','0.000015080000000','0.001129285017789','0.001071045161526','71.02421495528301','71.024214955283014','test'),('2019-03-27 07:59:59','2019-03-27 23:59:59','LRCBTC','4h','0.000015730000000','0.000015320000000','0.001129285017789','0.001099850379690','71.7918002408773','71.791800240877294','test'),('2019-03-28 03:59:59','2019-03-28 07:59:59','LRCBTC','4h','0.000015550000000','0.000015610000000','0.001129285017789','0.001133642387633','72.6228307259807','72.622830725980705','test'),('2019-03-29 23:59:59','2019-03-30 03:59:59','LRCBTC','4h','0.000015600000000','0.000015770000000','0.001129285017789','0.001141591328880','72.39006524288462','72.390065242884617','test'),('2019-04-03 11:59:59','2019-04-03 23:59:59','LRCBTC','4h','0.000016190000000','0.000015380000000','0.001129285017789','0.001072785890895','69.75200851074737','69.752008510747373','test'),('2019-04-04 03:59:59','2019-04-04 07:59:59','LRCBTC','4h','0.000016000000000','0.000016690000000','0.001129285017789','0.001177985434181','70.5803136118125','70.580313611812500','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  2:48:29
