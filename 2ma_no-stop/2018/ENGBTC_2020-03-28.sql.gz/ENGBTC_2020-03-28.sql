-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-31 15:59:59','2018-03-31 19:59:59','ENGBTC','4h','0.000207430000000','0.000205720000000','0.001467500000000','0.001455402304392','7.074675794243841','7.074675794243841','test'),('2018-03-31 23:59:59','2018-04-01 03:59:59','ENGBTC','4h','0.000207510000000','0.000205770000000','0.001467500000000','0.001455194809889','7.071948339839044','7.071948339839044','test'),('2018-04-02 11:59:59','2018-04-03 15:59:59','ENGBTC','4h','0.000207790000000','0.000210010000000','0.001467500000000','0.001483178569710','7.062418788199626','7.062418788199626','test'),('2018-04-08 07:59:59','2018-04-09 11:59:59','ENGBTC','4h','0.000209150000000','0.000201620000000','0.001467500000000','0.001414665790103','7.016495338273967','7.016495338273967','test'),('2018-04-10 15:59:59','2018-04-11 15:59:59','ENGBTC','4h','0.000206440000000','0.000211560000000','0.001467500000000','0.001503896047278','7.108602983917845','7.108602983917845','test'),('2018-04-25 19:59:59','2018-04-25 23:59:59','ENGBTC','4h','0.000261080000000','0.000253050000000','0.001467500000000','0.001422364313620','5.620882488126245','5.620882488126245','test'),('2018-04-26 11:59:59','2018-04-28 11:59:59','ENGBTC','4h','0.000263640000000','0.000271140000000','0.001467500000000','0.001509247269003','5.566302533758155','5.566302533758155','test'),('2018-05-08 19:59:59','2018-05-09 03:59:59','ENGBTC','4h','0.000294170000000','0.000280990000000','0.001467500000000','0.001401750093483','4.988612027059183','4.988612027059183','test'),('2018-05-09 11:59:59','2018-05-09 15:59:59','ENGBTC','4h','0.000287740000000','0.000281300000000','0.001467500000000','0.001434655418086','5.100090359352193','5.100090359352193','test'),('2018-05-09 23:59:59','2018-05-10 23:59:59','ENGBTC','4h','0.000290460000000','0.000286180000000','0.001467500000000','0.001445876024237','5.052330785650348','5.052330785650348','test'),('2018-05-12 11:59:59','2018-05-16 03:59:59','ENGBTC','4h','0.000290450000000','0.000309690000000','0.001467500000000','0.001564710191083','5.052504734033397','5.052504734033397','test'),('2018-05-17 11:59:59','2018-05-17 15:59:59','ENGBTC','4h','0.000307980000000','0.000300920000000','0.001467500000000','0.001433859666212','4.764919799987012','4.764919799987012','test'),('2018-06-02 11:59:59','2018-06-02 23:59:59','ENGBTC','4h','0.000273640000000','0.000264610000000','0.001467500000000','0.001419073143546','5.362885543049262','5.362885543049262','test'),('2018-06-05 23:59:59','2018-06-06 03:59:59','ENGBTC','4h','0.000262580000000','0.000259960000000','0.001467500000000','0.001452857414883','5.588772945388072','5.588772945388072','test'),('2018-06-06 11:59:59','2018-06-08 07:59:59','ENGBTC','4h','0.000264560000000','0.000266110000000','0.001467500000000','0.001476097766102','5.5469458723918965','5.546945872391897','test'),('2018-06-20 15:59:59','2018-06-22 15:59:59','ENGBTC','4h','0.000228000000000','0.000233170000000','0.001467500000000','0.001500776206140','6.43640350877193','6.436403508771930','test'),('2018-06-24 19:59:59','2018-06-24 23:59:59','ENGBTC','4h','0.000237730000000','0.000233170000000','0.001467500000000','0.001439351259833','6.172969334959829','6.172969334959829','test'),('2018-06-27 23:59:59','2018-06-28 03:59:59','ENGBTC','4h','0.000237950000000','0.000228140000000','0.001467500000000','0.001406999159487','6.167262029838201','6.167262029838201','test'),('2018-06-28 15:59:59','2018-06-28 19:59:59','ENGBTC','4h','0.000234410000000','0.000232470000000','0.001467500000000','0.001455354827012','6.260398447165223','6.260398447165223','test'),('2018-07-01 11:59:59','2018-07-01 19:59:59','ENGBTC','4h','0.000232740000000','0.000231270000000','0.001467500000000','0.001458231180717','6.305319240354043','6.305319240354043','test'),('2018-07-02 03:59:59','2018-07-04 23:59:59','ENGBTC','4h','0.000239750000000','0.000238440000000','0.001467500000000','0.001459481543274','6.120959332638165','6.120959332638165','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','ENGBTC','4h','0.000200690000000','0.000200590000000','0.001467500000000','0.001466768772734','7.312272659325328','7.312272659325328','test'),('2018-07-17 23:59:59','2018-07-18 23:59:59','ENGBTC','4h','0.000205740000000','0.000196860000000','0.001467500000000','0.001404160834062','7.132788956935939','7.132788956935939','test'),('2018-08-18 03:59:59','2018-08-18 07:59:59','ENGBTC','4h','0.000118460000000','0.000111410000000','0.001467500000000','0.001380163557319','12.38814789802465','12.388147898024650','test'),('2018-08-26 15:59:59','2018-08-29 15:59:59','ENGBTC','4h','0.000116750000000','0.000108990000000','0.001467500000000','0.001369959957173','12.569593147751606','12.569593147751606','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ENGBTC','4h','0.000116700000000','0.000117440000000','0.001467500000000','0.001476805484147','12.574978577549272','12.574978577549272','test'),('2018-09-21 15:59:59','2018-09-22 03:59:59','ENGBTC','4h','0.000096390000000','0.000089360000000','0.001467500000000','0.001360471003216','15.224608361863265','15.224608361863265','test'),('2018-09-22 15:59:59','2018-09-22 19:59:59','ENGBTC','4h','0.000091070000000','0.000090540000000','0.001467500000000','0.001458959591523','16.113978258482486','16.113978258482486','test'),('2018-09-23 07:59:59','2018-09-23 15:59:59','ENGBTC','4h','0.000091520000000','0.000089870000000','0.001467500000000','0.001441042668269','16.034746503496503','16.034746503496503','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','ENGBTC','4h','0.000091070000000','0.000091000000000','0.001467500000000','0.001466372021522','16.113978258482486','16.113978258482486','test'),('2018-09-26 23:59:59','2018-09-28 11:59:59','ENGBTC','4h','0.000090340000000','0.000090590000000','0.001467500000000','0.001471561047155','16.244188620765996','16.244188620765996','test'),('2018-10-04 11:59:59','2018-10-04 15:59:59','ENGBTC','4h','0.000093120000000','0.000092340000000','0.001467500000000','0.001455207796392','15.759235395189004','15.759235395189004','test'),('2018-10-07 11:59:59','2018-10-11 07:59:59','ENGBTC','4h','0.000093390000000','0.000090740000000','0.001467500000000','0.001425858764322','15.713673840882322','15.713673840882322','test'),('2018-10-14 11:59:59','2018-10-14 15:59:59','ENGBTC','4h','0.000093910000000','0.000094470000000','0.001467500000000','0.001476250931743','15.62666382706847','15.626663827068469','test'),('2018-10-16 15:59:59','2018-10-16 23:59:59','ENGBTC','4h','0.000092160000000','0.000091830000000','0.001467500000000','0.001462245279948','15.923394097222223','15.923394097222223','test'),('2018-10-17 03:59:59','2018-10-17 07:59:59','ENGBTC','4h','0.000092480000000','0.000091610000000','0.001467500000000','0.001453694582612','15.868295847750867','15.868295847750867','test'),('2018-10-17 15:59:59','2018-10-17 19:59:59','ENGBTC','4h','0.000092120000000','0.000092310000000','0.001467500000000','0.001470526758576','15.930308293530178','15.930308293530178','test'),('2018-10-20 07:59:59','2018-10-20 11:59:59','ENGBTC','4h','0.000092560000000','0.000094360000000','0.001467500000000','0.001496038245462','15.854580812445983','15.854580812445983','test'),('2018-10-30 07:59:59','2018-10-30 11:59:59','ENGBTC','4h','0.000098600000000','0.000097480000000','0.001467500000000','0.001450830628803','14.883367139959432','14.883367139959432','test'),('2018-10-31 23:59:59','2018-11-03 15:59:59','ENGBTC','4h','0.000100460000000','0.000098000000000','0.001467500000000','0.001431564801911','14.60780410113478','14.607804101134780','test'),('2018-11-04 23:59:59','2018-11-06 11:59:59','ENGBTC','4h','0.000102130000000','0.000100820000000','0.001467500000000','0.001448676686576','14.368941545089593','14.368941545089593','test'),('2018-11-07 19:59:59','2018-11-07 23:59:59','ENGBTC','4h','0.000101360000000','0.000099770000000','0.001467500000000','0.001444479824388','14.478097868981846','14.478097868981846','test'),('2018-11-09 03:59:59','2018-11-09 07:59:59','ENGBTC','4h','0.000100860000000','0.000099330000000','0.001467500000000','0.001445238697204','14.549871108467181','14.549871108467181','test'),('2018-11-21 23:59:59','2018-11-22 19:59:59','ENGBTC','4h','0.000092000000000','0.000082850000000','0.001467500000000','0.001321547554348','15.95108695652174','15.951086956521740','test'),('2018-11-29 11:59:59','2018-11-29 15:59:59','ENGBTC','4h','0.000079340000000','0.000080860000000','0.001467500000000','0.001495614444164','18.496344844971013','18.496344844971013','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','ENGBTC','4h','0.000085380000000','0.000077940000000','0.001467500000000','0.001339622276880','17.18786601077536','17.187866010775359','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','ENGBTC','4h','0.000080140000000','0.000080420000000','0.001467500000000','0.001472627277265','18.311704517095084','18.311704517095084','test'),('2018-12-02 15:59:59','2018-12-02 23:59:59','ENGBTC','4h','0.000080110000000','0.000078950000000','0.001467500000000','0.001446250468106','18.318561977281238','18.318561977281238','test'),('2018-12-22 03:59:59','2018-12-22 15:59:59','ENGBTC','4h','0.000069530000000','0.000067360000000','0.001467500000000','0.001421699985618','21.105997411189417','21.105997411189417','test'),('2019-01-16 11:59:59','2019-01-18 15:59:59','ENGBTC','4h','0.000083010000000','0.000077660000000','0.001467500000000','0.001372919527768','17.678592940609565','17.678592940609565','test'),('2019-01-23 03:59:59','2019-01-23 07:59:59','ENGBTC','4h','0.000080250000000','0.000079390000000','0.001467500000000','0.001451773520249','18.286604361370717','18.286604361370717','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','ENGBTC','4h','0.000082790000000','0.000081600000000','0.001467500000000','0.001446406570842','17.725570721101583','17.725570721101583','test'),('2019-02-02 11:59:59','2019-02-02 15:59:59','ENGBTC','4h','0.000079210000000','0.000078690000000','0.001467500000000','0.001457866115389','18.526701174094182','18.526701174094182','test'),('2019-02-04 15:59:59','2019-02-04 19:59:59','ENGBTC','4h','0.000080160000000','0.000075730000000','0.001467500000000','0.001386399388723','18.307135728542914','18.307135728542914','test'),('2019-02-08 11:59:59','2019-02-08 15:59:59','ENGBTC','4h','0.000077200000000','0.000074650000000','0.001467500000000','0.001419026878238','19.009067357512954','19.009067357512954','test'),('2019-02-09 15:59:59','2019-02-16 15:59:59','ENGBTC','4h','0.000078490000000','0.000081660000000','0.001467500000000','0.001526768378137','18.696649254682125','18.696649254682125','test'),('2019-02-20 11:59:59','2019-02-24 07:59:59','ENGBTC','4h','0.000083920000000','0.000085010000000','0.001467500000000','0.001486560712583','17.486892278360344','17.486892278360344','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','ENGBTC','4h','0.000085580000000','0.000085000000000','0.001467500000000','0.001457554335125','17.147698060294463','17.147698060294463','test'),('2019-03-05 15:59:59','2019-03-05 19:59:59','ENGBTC','4h','0.000087190000000','0.000085100000000','0.001467500000000','0.001432323087510','16.831058607638493','16.831058607638493','test'),('2019-03-06 07:59:59','2019-03-18 07:59:59','ENGBTC','4h','0.000088000000000','0.000104150000000','0.001467500000000','0.001736819602273','16.676136363636363','16.676136363636363','test'),('2019-03-18 19:59:59','2019-03-18 23:59:59','ENGBTC','4h','0.000104480000000','0.000104790000000','0.001467500000000','0.001471854182619','14.045750382848393','14.045750382848393','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','ENGBTC','4h','0.000106060000000','0.000106730000000','0.001467500000000','0.001476770460117','13.836507637186498','13.836507637186498','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:19:20
