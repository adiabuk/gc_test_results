-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-10 07:59:59','OSTBNB','4h','0.004745000000000','0.005466000000000','0.711908500000000','0.820082583983140','150.03340358271865','150.033403582718648','test'),('2018-07-15 15:59:59','2018-07-15 19:59:59','OSTBNB','4h','0.005300000000000','0.005258000000000','0.738952020995785','0.733096174791667','139.42490962184624','139.424909621846240','test'),('2018-07-16 11:59:59','2018-07-16 15:59:59','OSTBNB','4h','0.005248000000000','0.005369000000000','0.738952020995785','0.755989596174994','140.80640643974561','140.806406439745615','test'),('2018-07-17 19:59:59','2018-07-20 03:59:59','OSTBNB','4h','0.005542000000000','0.005295000000000','0.741747453239558','0.708688698106001','133.84111390103894','133.841113901038938','test'),('2018-07-20 15:59:59','2018-07-20 19:59:59','OSTBNB','4h','0.005462000000000','0.005324000000000','0.741747453239558','0.723006854823765','135.80143779559833','135.801437795598332','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','OSTBNB','4h','0.005603000000000','0.005479000000000','0.741747453239558','0.725331839425225','132.38398237364947','132.383982373649474','test'),('2018-08-07 07:59:59','2018-08-07 11:59:59','OSTBNB','4h','0.008552000000000','0.005848000000000','0.741747453239558','0.507219259418257','86.73379949012605','86.733799490126046','test'),('2018-08-22 15:59:59','2018-08-22 19:59:59','OSTBNB','4h','0.002973000000000','0.002871000000000','0.741747453239558','0.716299003784316','249.49460250237405','249.494602502374050','test'),('2018-08-24 11:59:59','2018-08-24 15:59:59','OSTBNB','4h','0.002933000000000','0.002793000000000','0.741747453239558','0.706341846879675','252.8971882848817','252.897188284881707','test'),('2018-08-25 07:59:59','2018-08-25 11:59:59','OSTBNB','4h','0.002894000000000','0.002775000000000','0.741747453239558','0.711247126033094','256.30527064255637','256.305270642556366','test'),('2018-08-25 15:59:59','2018-08-25 23:59:59','OSTBNB','4h','0.002885000000000','0.002949000000000','0.741747453239558','0.758202162774162','257.104836478183','257.104836478183017','test'),('2018-08-28 03:59:59','2018-09-05 11:59:59','OSTBNB','4h','0.003412000000000','0.003163000000000','0.741747453239558','0.687616411077586','217.39374362237925','217.393743622379247','test'),('2018-09-07 15:59:59','2018-09-07 19:59:59','OSTBNB','4h','0.003336000000000','0.003274000000000','0.741747453239558','0.727961978988703','222.3463588847596','222.346358884759610','test'),('2018-09-10 23:59:59','2018-09-11 15:59:59','OSTBNB','4h','0.003266000000000','0.003301000000000','0.741747453239558','0.749696369609241','227.11189627665587','227.111896276655870','test'),('2018-09-16 19:59:59','2018-09-17 15:59:59','OSTBNB','4h','0.003230000000000','0.003169000000000','0.741747453239558','0.727739219602526','229.64317437757217','229.643174377572166','test'),('2018-10-04 23:59:59','2018-10-05 03:59:59','OSTBNB','4h','0.004473000000000','0.004352000000000','0.741747453239558','0.721682297451052','165.82773378930426','165.827733789304261','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','OSTBNB','4h','0.004545000000000','0.004206000000000','0.741747453239558','0.686422395671195','163.2007597886816','163.200759788681609','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','OSTBNB','4h','0.004432000000000','0.004224000000000','0.741747453239558','0.706936200921456','167.361789990875','167.361789990874996','test'),('2018-10-13 19:59:59','2018-10-14 03:59:59','OSTBNB','4h','0.004299000000000','0.004255000000000','0.741747453239558','0.734155713778628','172.53953320296768','172.539533202967675','test'),('2018-10-14 07:59:59','2018-10-14 11:59:59','OSTBNB','4h','0.004308000000000','0.004267000000000','0.741747453239558','0.734688111182264','172.17907456814254','172.179074568142539','test'),('2018-10-27 19:59:59','2018-10-27 23:59:59','OSTBNB','4h','0.004918000000000','0.004989000000000','0.741747453239558','0.752455885362374','150.82298764529446','150.822987645294461','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','OSTBNB','4h','0.005365000000000','0.005072000000000','0.741747453239558','0.701238226063567','138.25674804092415','138.256748040924151','test'),('2018-11-07 07:59:59','2018-11-07 15:59:59','OSTBNB','4h','0.005388000000000','0.005183000000000','0.741747453239558','0.713525807375766','137.66656518922753','137.666565189227526','test'),('2018-11-08 23:59:59','2018-11-10 07:59:59','OSTBNB','4h','0.005260000000000','0.005267000000000','0.741747453239558','0.742734569622196','141.01662609117074','141.016626091170735','test'),('2018-11-12 19:59:59','2018-11-13 03:59:59','OSTBNB','4h','0.005256000000000','0.005103000000000','0.741747453239558','0.720155489703475','141.1239446802812','141.123944680281198','test'),('2018-11-13 07:59:59','2018-11-13 11:59:59','OSTBNB','4h','0.005294000000000','0.005265000000000','0.741747453239558','0.737684235229746','140.1109658556022','140.110965855602188','test'),('2018-11-27 23:59:59','2018-12-04 07:59:59','OSTBNB','4h','0.004534000000000','0.004819000000000','0.741747453239558','0.788372513710064','163.5967034052841','163.596703405284103','test'),('2018-12-05 07:59:59','2018-12-05 11:59:59','OSTBNB','4h','0.005265000000000','0.004732000000000','0.741747453239558','0.666656970319010','140.88270716800724','140.882707168007244','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','OSTBNB','4h','0.004911000000000','0.004894000000000','0.741747453239558','0.739179807809896','151.0379664507347','151.037966450734700','test'),('2018-12-07 11:59:59','2018-12-07 15:59:59','OSTBNB','4h','0.005000000000000','0.005008000000000','0.741747453239558','0.742934249164741','148.3494906479116','148.349490647911608','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','OSTBNB','4h','0.005025000000000','0.004856000000000','0.741747453239558','0.716801120981352','147.61143348050908','147.611433480509078','test'),('2018-12-09 23:59:59','2018-12-10 15:59:59','OSTBNB','4h','0.004966000000000','0.004816000000000','0.741747453239558','0.719342677165065','149.3651738299553','149.365173829955296','test'),('2018-12-11 07:59:59','2018-12-11 23:59:59','OSTBNB','4h','0.005105000000000','0.004744000000000','0.741747453239558','0.689294792981090','145.29822786279294','145.298227862792942','test'),('2018-12-12 03:59:59','2018-12-12 11:59:59','OSTBNB','4h','0.004990000000000','0.004864000000000','0.494498302159705','0.482011972285532','99.09785614422954','99.097856144229539','test'),('2018-12-12 15:59:59','2018-12-13 07:59:59','OSTBNB','4h','0.004960000000000','0.004959000000000','0.541422930228201','0.541313772379365','109.15784883633087','109.157848836330871','test'),('2018-12-13 19:59:59','2018-12-14 03:59:59','OSTBNB','4h','0.005024000000000','0.005088000000000','0.541422930228201','0.548320037619643','107.76730299128205','107.767302991282051','test'),('2018-12-15 19:59:59','2018-12-15 23:59:59','OSTBNB','4h','0.004978000000000','0.004910000000000','0.543119917613853','0.535700842805146','109.10404130451037','109.104041304510375','test'),('2018-12-16 11:59:59','2018-12-16 19:59:59','OSTBNB','4h','0.005030000000000','0.004969000000000','0.543119917613853','0.536533373881359','107.97612676219742','107.976126762197424','test'),('2018-12-20 23:59:59','2018-12-21 03:59:59','OSTBNB','4h','0.004900000000000','0.004736000000000','0.543119917613853','0.524942026493716','110.84079951303123','110.840799513031229','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','OSTBNB','4h','0.004880000000000','0.004723000000000','0.543119917613853','0.525646592395538','111.29506508480596','111.295065084805955','test'),('2019-01-04 07:59:59','2019-01-04 11:59:59','OSTBNB','4h','0.004281000000000','0.004116000000000','0.543119917613853','0.522186774328105','126.86753506513736','126.867535065137361','test'),('2019-01-06 15:59:59','2019-01-06 23:59:59','OSTBNB','4h','0.004305000000000','0.004107000000000','0.543119917613853','0.518140186211404','126.16025960832823','126.160259608328232','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','OSTBNB','4h','0.003874000000000','0.003638000000000','0.543119917613853','0.510033624233143','140.19615839283765','140.196158392837646','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','OSTBNB','4h','0.003822000000000','0.003858000000000','0.543119917613853','0.548235646822147','142.10358911927082','142.103589119270822','test'),('2019-02-17 03:59:59','2019-02-18 03:59:59','OSTBNB','4h','0.002465000000000','0.002355000000000','0.543119917613853','0.518883328998225','220.33262377843934','220.332623778439341','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','OSTBNB','4h','0.002390000000000','0.002349000000000','0.543119917613853','0.533802797688260','227.24682745349497','227.246827453494973','test'),('2019-02-25 19:59:59','2019-02-27 23:59:59','OSTBNB','4h','0.002363000000000','0.002312000000000','0.543119917613853','0.531397905003482','229.84338451707703','229.843384517077027','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','OSTBNB','4h','0.001876000000000','0.001839000000000','0.543119917613853','0.532408064228079','289.5095509668726','289.509550966872609','test'),('2019-03-15 23:59:59','2019-03-16 03:59:59','OSTBNB','4h','0.001855000000000','0.001832000000000','0.543119917613853','0.536385816209476','292.7870175815919','292.787017581591897','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','OSTBNB','4h','0.001829000000000','0.001828000000000','0.543119917613853','0.542822968506355','296.9491074980061','296.949107498006072','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','OSTBNB','4h','0.001826000000000','0.001805000000000','0.543119917613853','0.536873741124318','297.43697569214294','297.436975692142937','test'),('2019-03-27 03:59:59','2019-03-28 15:59:59','OSTBNB','4h','0.001817000000000','0.001793000000000','0.543119917613853','0.535946071701507','298.9102463477452','298.910246347745215','test'),('2019-04-08 03:59:59','2019-04-08 07:59:59','OSTBNB','4h','0.001676000000000','0.001651000000000','0.543119917613853','0.535018486861856','324.0572300798646','324.057230079864610','test'),('2019-04-08 23:59:59','2019-04-09 03:59:59','OSTBNB','4h','0.001672000000000','0.001651000000000','0.543119917613853','0.536298435395019','324.8324866111561','324.832486611156128','test'),('2019-05-06 19:59:59','2019-05-07 03:59:59','OSTBNB','4h','0.001031000000000','0.001016000000000','0.543119917613853','0.535218075941489','526.7894448242997','526.789444824299721','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','OSTBNB','4h','0.001035000000000','0.001009000000000','0.543119917613853','0.529476325480558','524.7535435882638','524.753543588263824','test'),('2019-05-11 23:59:59','2019-05-12 03:59:59','OSTBNB','4h','0.001034000000000','0.001013000000000','0.543119917613853','0.532089435728078','525.2610421797418','525.261042179741821','test'),('2019-05-26 11:59:59','2019-05-26 19:59:59','OSTBNB','4h','0.000835000000000','0.000833000000000','0.543119917613853','0.541819031583640','650.4430151064108','650.443015106410826','test'),('2019-05-27 19:59:59','2019-05-27 23:59:59','OSTBNB','4h','0.000824000000000','0.000846000000000','0.543119917613853','0.557620692113252','659.126113609045','659.126113609044978','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','OSTBNB','4h','0.000849000000000','0.000868000000000','0.543119917613853','0.555274544745376','639.7172174485901','639.717217448590077','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','OSTBNB','4h','0.000852000000000','0.000860000000000','0.543119917613853','0.548219635150133','637.4646920350388','637.464692035038752','test'),('2019-06-05 11:59:59','2019-06-05 23:59:59','OSTBNB','4h','0.000910000000000','0.000848000000000','0.543119917613853','0.506116143007195','596.8350743009374','596.835074300937436','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:36:14
