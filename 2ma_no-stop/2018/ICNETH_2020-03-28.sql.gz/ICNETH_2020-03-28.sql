-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-17 11:59:59','2018-02-17 15:59:59','ICNETH','4h','0.001952000000000','0.002010000000000','0.072144500000000','0.074288137807377','36.959272540983605','36.959272540983605','test'),('2018-02-19 03:59:59','2018-02-19 07:59:59','ICNETH','4h','0.001959000000000','0.001946300000000','0.072680409451844','0.072209229666219','37.100770521615246','37.100770521615246','test'),('2018-02-19 11:59:59','2018-02-19 15:59:59','ICNETH','4h','0.001955000000000','0.002000300000000','0.072680409451844','0.074364513057045','37.17668002651867','37.176680026518667','test'),('2018-03-01 19:59:59','2018-03-02 07:59:59','ICNETH','4h','0.001867500000000','0.001838900000000','0.072983640406738','0.071865925753119','39.080931944705895','39.080931944705895','test'),('2018-03-06 19:59:59','2018-03-08 19:59:59','ICNETH','4h','0.002208500000000','0.002135600000000','0.072983640406738','0.070574535862635','33.046701565197196','33.046701565197196','test'),('2018-03-10 07:59:59','2018-03-10 11:59:59','ICNETH','4h','0.002117400000000','0.002099500000000','0.072983640406738','0.072366653931211','34.468518185859075','34.468518185859075','test'),('2018-03-17 03:59:59','2018-03-17 11:59:59','ICNETH','4h','0.002099900000000','0.002025500000000','0.072983640406738','0.070397811154744','34.75576951604267','34.755769516042669','test'),('2018-03-19 19:59:59','2018-03-19 23:59:59','ICNETH','4h','0.002020800000000','0.002000000000000','0.072983640406738','0.072232423205402','36.116211602700915','36.116211602700915','test'),('2018-03-22 03:59:59','2018-03-22 07:59:59','ICNETH','4h','0.001999600000000','0.002023000000000','0.072983640406738','0.073837719815379','36.49912002737448','36.499120027374481','test'),('2018-03-23 15:59:59','2018-03-23 23:59:59','ICNETH','4h','0.002143200000000','0.002025900000000','0.072983640406738','0.068989155048530','34.05358361643244','34.053583616432441','test'),('2018-03-27 03:59:59','2018-03-27 15:59:59','ICNETH','4h','0.002080100000000','0.002049900000000','0.072983640406738','0.071924025032341','35.08660180122975','35.086601801229747','test'),('2018-04-02 15:59:59','2018-04-02 19:59:59','ICNETH','4h','0.002285700000000','0.001989700000000','0.072983640406738','0.063532199902562','31.930542243836904','31.930542243836904','test'),('2018-04-03 15:59:59','2018-04-04 11:59:59','ICNETH','4h','0.001986300000000','0.002004900000000','0.072983640406738','0.073667069753546','36.74351326926346','36.743513269263460','test'),('2018-04-12 19:59:59','2018-04-12 23:59:59','ICNETH','4h','0.002176000000000','0.002125000000000','0.072983640406738','0.071273086334705','33.54027592221416','33.540275922214157','test'),('2018-04-13 11:59:59','2018-04-13 15:59:59','ICNETH','4h','0.002149600000000','0.002187400000000','0.072983640406738','0.074267033413518','33.95219594656587','33.952195946565872','test'),('2018-04-28 23:59:59','2018-04-29 03:59:59','ICNETH','4h','0.002274800000000','0.002281500000000','0.072983640406738','0.073198600135385','32.08354158903552','32.083541589035519','test'),('2018-04-29 15:59:59','2018-04-30 07:59:59','ICNETH','4h','0.002346600000000','0.002286900000000','0.072983640406738','0.071126858964531','31.101866703629938','31.101866703629938','test'),('2018-05-31 11:59:59','2018-06-01 15:59:59','ICNETH','4h','0.001670700000000','0.001626500000000','0.072983640406738','0.071052786928568','43.684467831889634','43.684467831889634','test'),('2018-06-04 15:59:59','2018-06-04 23:59:59','ICNETH','4h','0.001721500000000','0.001586300000000','0.072983640406738','0.067251785522631','42.39537636174151','42.395376361741512','test'),('2018-06-22 11:59:59','2018-06-22 15:59:59','ICNETH','4h','0.001415800000000','0.001389300000000','0.072983640406738','0.071617581308858','51.54939992000141','51.549399920001413','test'),('2018-06-27 15:59:59','2018-06-27 19:59:59','ICNETH','4h','0.001389800000000','0.001341800000000','0.072983640406738','0.070462979347936','52.513772058381065','52.513772058381065','test'),('2018-06-29 15:59:59','2018-06-29 23:59:59','ICNETH','4h','0.001373500000000','0.001339200000000','0.072983640406738','0.071161042033275','53.13697881815654','53.136978818156543','test'),('2018-06-30 03:59:59','2018-06-30 07:59:59','ICNETH','4h','0.001386500000000','0.001343900000000','0.072983640406738','0.070741229240977','52.63875975963794','52.638759759637942','test'),('2018-07-08 15:59:59','2018-07-08 19:59:59','ICNETH','4h','0.001422800000000','0.001414300000000','0.072983640406738','0.072547626249121','51.295783249042735','51.295783249042735','test'),('2018-07-09 03:59:59','2018-07-09 11:59:59','ICNETH','4h','0.001417200000000','0.001407800000000','0.072983640406738','0.072499554730882','51.49847615490969','51.498476154909689','test'),('2018-07-09 15:59:59','2018-07-10 03:59:59','ICNETH','4h','0.001431600000000','0.001438500000000','0.072983640406738','0.073335405647592','50.98046968897597','50.980469688975973','test'),('2018-07-16 23:59:59','2018-07-17 03:59:59','ICNETH','4h','0.001351200000000','0.001315600000000','0.072983640406738','0.071060744019468','54.01394346265394','54.013943462653941','test'),('2018-07-17 19:59:59','2018-07-20 19:59:59','ICNETH','4h','0.001344000000000','0.001377500000000','0.072983640406738','0.074802801086519','54.30330387406102','54.303303874061022','test'),('2018-07-21 11:59:59','2018-07-21 15:59:59','ICNETH','4h','0.001379000000000','0.001370300000000','0.072983640406738','0.072523192494092','52.92504743055693','52.925047430556930','test'),('2018-07-22 19:59:59','2018-07-22 23:59:59','ICNETH','4h','0.001365500000000','0.001336500000000','0.072983640406738','0.071433639987994','53.44829030152912','53.448290301529120','test'),('2018-08-01 19:59:59','2018-08-01 23:59:59','ICNETH','4h','0.001301100000000','0.001241000000000','0.072983640406738','0.069612403154840','56.0937978685251','56.093797868525101','test'),('2018-08-04 07:59:59','2018-08-04 15:59:59','ICNETH','4h','0.001259900000000','0.001212500000000','0.072983640406738','0.070237847442789','57.92812160230019','57.928121602300187','test'),('2018-08-04 19:59:59','2018-08-05 11:59:59','ICNETH','4h','0.001342300000000','0.001329300000000','0.072983640406738','0.072276803391698','54.37207807996573','54.372078079965732','test'),('2018-08-18 03:59:59','2018-08-18 07:59:59','ICNETH','4h','0.001588700000000','0.001580300000000','0.072983640406738','0.072597750950317','45.93922100254171','45.939221002541707','test'),('2018-08-18 19:59:59','2018-08-18 23:59:59','ICNETH','4h','0.001682300000000','0.001556000000000','0.072983640406738','0.067504336011939','43.38324936499911','43.383249364999109','test'),('2018-08-19 19:59:59','2018-08-20 03:59:59','ICNETH','4h','0.001614400000000','0.001569800000000','0.072983640406738','0.070967367883113','45.20790411715684','45.207904117156843','test'),('2018-08-29 15:59:59','2018-08-29 19:59:59','ICNETH','4h','0.001675100000000','0.001646000000000','0.072983640406738','0.071715761512442','43.56972145348816','43.569721453488157','test'),('2018-08-30 03:59:59','2018-08-30 07:59:59','ICNETH','4h','0.001648600000000','0.001656200000000','0.072983640406738','0.073320092952590','44.27007182259978','44.270071822599782','test'),('2018-09-17 07:59:59','2018-09-17 15:59:59','ICNETH','4h','0.001805300000000','0.001812200000000','0.072983640406738','0.073262589677666','40.42743056928932','40.427430569289321','test'),('2018-09-19 19:59:59','2018-09-19 23:59:59','ICNETH','4h','0.001846000000000','0.001807000000000','0.072983640406738','0.071441732510821','39.53609989530769','39.536099895307693','test'),('2018-09-22 23:59:59','2018-09-23 03:59:59','ICNETH','4h','0.001776700000000','0.001776800000000','0.072983640406738','0.072987748226877','41.078201388381835','41.078201388381835','test'),('2018-09-24 11:59:59','2018-09-24 19:59:59','ICNETH','4h','0.001772000000000','0.001767500000000','0.072983640406738','0.072798298204802','41.1871559857438','41.187155985743800','test'),('2018-10-04 15:59:59','2018-10-04 19:59:59','ICNETH','4h','0.001739000000000','0.001733100000000','0.072983640406738','0.072736024835490','41.96874088944106','41.968740889441058','test'),('2018-10-06 07:59:59','2018-10-06 11:59:59','ICNETH','4h','0.001730900000000','0.001757500000000','0.072983640406738','0.074105233124295','42.165139757778036','42.165139757778036','test'),('2018-10-11 15:59:59','2018-10-12 09:59:59','ICNETH','4h','0.001749900000000','0.001832500000000','0.072983640406738','0.076428665092490','41.70732065074462','41.707320650744620','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:16:01
