-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-22 11:59:59','2018-04-22 15:59:59','REQBTC','4h','0.000026170000000','0.000026960000000','0.001467500000000','0.001511799770730','56.07565915170043','56.075659151700428','test'),('2018-04-25 07:59:59','2018-04-25 11:59:59','REQBTC','4h','0.000026750000000','0.000025700000000','0.001478574942683','0.001420537421568','55.273829632990655','55.273829632990655','test'),('2018-04-26 19:59:59','2018-04-26 23:59:59','REQBTC','4h','0.000026670000000','0.000026300000000','0.001478574942683','0.001458062279436','55.4396303968129','55.439630396812902','test'),('2018-04-27 11:59:59','2018-05-04 11:59:59','REQBTC','4h','0.000028050000000','0.000029050000000','0.001478574942683','0.001531287061852','52.712119168734404','52.712119168734404','test'),('2018-06-17 03:59:59','2018-06-18 03:59:59','REQBTC','4h','0.000015940000000','0.000015570000000','0.001478574942683','0.001444254194327','92.75877934021331','92.758779340213309','test'),('2018-07-02 03:59:59','2018-07-02 07:59:59','REQBTC','4h','0.000012550000000','0.000012120000000','0.001478574942683','0.001427914606001','117.81473646876495','117.814736468764949','test'),('2018-07-02 15:59:59','2018-07-03 11:59:59','REQBTC','4h','0.000013020000000','0.000012570000000','0.001478574942683','0.001427472122083','113.5618235547619','113.561823554761901','test'),('2018-07-04 15:59:59','2018-07-04 19:59:59','REQBTC','4h','0.000012740000000','0.000013170000000','0.001478574942683','0.001528479748441','116.05768780871273','116.057687808712728','test'),('2018-07-18 19:59:59','2018-07-19 03:59:59','REQBTC','4h','0.000011770000000','0.000011050000000','0.001478574942683','0.001388126857829','125.62234007502124','125.622340075021242','test'),('2018-08-07 19:59:59','2018-08-08 03:59:59','REQBTC','4h','0.000007890000000','0.000007120000000','0.001478574942683','0.001334278021787','187.39859856565272','187.398598565652719','test'),('2018-08-10 11:59:59','2018-08-10 15:59:59','REQBTC','4h','0.000007400000000','0.000007280000000','0.001478574942683','0.001454598051721','199.8074246868919','199.807424686891892','test'),('2018-08-17 19:59:59','2018-08-18 15:59:59','REQBTC','4h','0.000006390000000','0.000005830000000','0.001478574942683','0.001348997169928','231.38887991909235','231.388879919092346','test'),('2018-08-19 23:59:59','2018-08-20 07:59:59','REQBTC','4h','0.000006140000000','0.000006150000000','0.001478574942683','0.001480983045196','240.81025125130296','240.810251251302958','test'),('2018-08-23 19:59:59','2018-08-24 03:59:59','REQBTC','4h','0.000006170000000','0.000006160000000','0.001478574942683','0.001476178548935','239.63937482706646','239.639374827066462','test'),('2018-08-30 23:59:59','2018-08-31 03:59:59','REQBTC','4h','0.000006580000000','0.000006580000000','0.001478574942683','0.001478574942683','224.7074380977204','224.707438097720399','test'),('2018-09-15 23:59:59','2018-09-16 03:59:59','REQBTC','4h','0.000005650000000','0.000005510000000','0.001478574942683','0.001441937687466','261.694680120885','261.694680120884982','test'),('2018-09-16 23:59:59','2018-09-17 23:59:59','REQBTC','4h','0.000005720000000','0.000005550000000','0.001478574942683','0.001434631281799','258.49212284667834','258.492122846678342','test'),('2018-09-18 07:59:59','2018-09-18 11:59:59','REQBTC','4h','0.000005710000000','0.000005570000000','0.001478574942683','0.001442322667381','258.9448235872154','258.944823587215410','test'),('2018-09-18 15:59:59','2018-09-18 23:59:59','REQBTC','4h','0.000005810000000','0.000005800000000','0.001478574942683','0.001476030063264','254.48794194199655','254.487941941996553','test'),('2018-09-25 19:59:59','2018-10-08 15:59:59','REQBTC','4h','0.000006280000000','0.000006940000000','0.001478574942683','0.001633966576787','235.4418698539809','235.441869853980904','test'),('2018-10-09 19:59:59','2018-10-10 07:59:59','REQBTC','4h','0.000006950000000','0.000006860000000','0.001478574942683','0.001459427929037','212.7445960694964','212.744596069496396','test'),('2018-10-11 19:59:59','2018-10-12 23:59:59','REQBTC','4h','0.000007090000000','0.000006820000000','0.001478574942683','0.001422268139506','208.54371547009876','208.543715470098761','test'),('2018-10-30 23:59:59','2018-10-31 03:59:59','REQBTC','4h','0.000008480000000','0.000008150000000','0.001478574942683','0.001421036059300','174.36025267488208','174.360252674882076','test'),('2018-10-31 19:59:59','2018-10-31 23:59:59','REQBTC','4h','0.000008390000000','0.000008260000000','0.001478574942683','0.001455664961450','176.23062487282482','176.230624872824819','test'),('2018-11-08 19:59:59','2018-11-08 23:59:59','REQBTC','4h','0.000008070000000','0.000007900000000','0.001478574942683','0.001447427762973','183.21870417385378','183.218704173853780','test'),('2018-11-09 07:59:59','2018-11-09 11:59:59','REQBTC','4h','0.000008060000000','0.000007970000000','0.001478574942683','0.001462064800643','183.44602266538462','183.446022665384618','test'),('2018-11-26 23:59:59','2018-11-28 15:59:59','REQBTC','4h','0.000007070000000','0.000006360000000','0.001478574942683','0.001330090047449','209.13365525926451','209.133655259264515','test'),('2018-11-29 07:59:59','2018-11-29 15:59:59','REQBTC','4h','0.000006420000000','0.000006270000000','0.001478574942683','0.001444028799162','230.30762347087227','230.307623470872272','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','REQBTC','4h','0.000006260000000','0.000006270000000','0.001478574942683','0.001480936883486','236.19408030079873','236.194080300798731','test'),('2018-12-02 15:59:59','2018-12-03 03:59:59','REQBTC','4h','0.000006370000000','0.000006170000000','0.001478574942683','0.001432151867560','232.11537561742546','232.115375617425457','test'),('2018-12-03 07:59:59','2018-12-03 15:59:59','REQBTC','4h','0.000006480000000','0.000006200000000','0.001478574942683','0.001414685901950','228.17514547577161','228.175145475771615','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','REQBTC','4h','0.000006280000000','0.000006240000000','0.001478574942683','0.001469157267889','235.4418698539809','235.441869853980904','test'),('2018-12-11 15:59:59','2018-12-12 15:59:59','REQBTC','4h','0.000006100000000','0.000006100000000','0.001478574942683','0.001478574942683','242.38933486606558','242.389334866065582','test'),('2018-12-17 19:59:59','2018-12-18 03:59:59','REQBTC','4h','0.000006130000000','0.000006090000000','0.001478574942683','0.001468926819077','241.20309016035893','241.203090160358926','test'),('2018-12-19 07:59:59','2018-12-19 11:59:59','REQBTC','4h','0.000006030000000','0.000006020000000','0.001478574942683','0.001476122911269','245.20314140679935','245.203141406799347','test'),('2018-12-22 23:59:59','2018-12-25 07:59:59','REQBTC','4h','0.000006010000000','0.000006210000000','0.001478574942683','0.001527778767731','246.01912523843595','246.019125238435947','test'),('2018-12-30 11:59:59','2018-12-30 15:59:59','REQBTC','4h','0.000006100000000','0.000006070000000','0.001478574942683','0.001471303262637','242.38933486606558','242.389334866065582','test'),('2019-01-02 15:59:59','2019-01-02 19:59:59','REQBTC','4h','0.000006000000000','0.000006000000000','0.001478574942683','0.001478574942683','246.42915711383336','246.429157113833355','test'),('2019-01-05 03:59:59','2019-01-05 15:59:59','REQBTC','4h','0.000005980000000','0.000005980000000','0.001478574942683','0.001478574942683','247.25333489682274','247.253334896822736','test'),('2019-01-06 03:59:59','2019-01-06 07:59:59','REQBTC','4h','0.000005960000000','0.000006030000000','0.001478574942683','0.001495940755768','248.08304407432888','248.083044074328882','test'),('2019-01-16 03:59:59','2019-01-20 15:59:59','REQBTC','4h','0.000005900000000','0.000006270000000','0.001478574942683','0.001571299134004','250.60592248864407','250.605922488644069','test'),('2019-01-26 03:59:59','2019-01-26 07:59:59','REQBTC','4h','0.000006250000000','0.000006240000000','0.001478574942683','0.001476209222775','236.57199082928','236.571990829279997','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','REQBTC','4h','0.000006140000000','0.000006050000000','0.001478574942683','0.001456902020070','240.81025125130296','240.810251251302958','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','REQBTC','4h','0.000005770000000','0.000005740000000','0.001478574942683','0.001470887377990','256.25215644419416','256.252156444194156','test'),('2019-02-10 03:59:59','2019-02-10 07:59:59','REQBTC','4h','0.000005720000000','0.000005660000000','0.001478574942683','0.001463065415312','258.49212284667834','258.492122846678342','test'),('2019-02-11 07:59:59','2019-02-11 11:59:59','REQBTC','4h','0.000005720000000','0.000005640000000','0.001478574942683','0.001457895572855','258.49212284667834','258.492122846678342','test'),('2019-02-11 19:59:59','2019-02-12 03:59:59','REQBTC','4h','0.000005740000000','0.000005710000000','0.001478574942683','0.001470847199080','257.5914534290941','257.591453429094088','test'),('2019-02-18 03:59:59','2019-02-18 07:59:59','REQBTC','4h','0.000005690000000','0.000005580000000','0.001478574942683','0.001449990892824','259.8549987140598','259.854998714059775','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','REQBTC','4h','0.000005620000000','0.000005540000000','0.001478574942683','0.001457527612538','263.0916268119217','263.091626811921685','test'),('2019-02-20 11:59:59','2019-02-21 07:59:59','REQBTC','4h','0.000005690000000','0.000005650000000','0.001478574942683','0.001468180742734','259.8549987140598','259.854998714059775','test'),('2019-02-22 19:59:59','2019-02-23 03:59:59','REQBTC','4h','0.000005620000000','0.000005640000000','0.001478574942683','0.001483836775219','263.0916268119217','263.091626811921685','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','REQBTC','4h','0.000005540000000','0.000005490000000','0.001478574942683','0.001465230403489','266.89078387779784','266.890783877797844','test'),('2019-03-05 11:59:59','2019-03-05 19:59:59','REQBTC','4h','0.000005570000000','0.000005510000000','0.001478574942683','0.001462647744019','265.4533110741472','265.453311074147223','test'),('2019-03-07 07:59:59','2019-03-07 15:59:59','REQBTC','4h','0.000005560000000','0.000005520000000','0.001478574942683','0.001467937712880','265.9307450868705','265.930745086870502','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','REQBTC','4h','0.000005550000000','0.000005420000000','0.001478574942683','0.001443941655737','266.40989958252254','266.409899582522542','test'),('2019-03-09 03:59:59','2019-03-21 15:59:59','REQBTC','4h','0.000005660000000','0.000006200000000','0.001478574942683','0.001619640396579','261.2323220287986','261.232322028798592','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','REQBTC','4h','0.000006350000000','0.000006570000000','0.001478574942683','0.001529801161170','232.84644766661418','232.846447666614182','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  4:36:49
