-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-05 19:59:59','2018-04-05 23:59:59','ASTBTC','4h','0.000034860000000','0.000035270000000','0.001467500000000','0.001484759753299','42.09695926563396','42.096959265633963','test'),('2018-04-07 15:59:59','2018-04-08 15:59:59','ASTBTC','4h','0.000035230000000','0.000035200000000','0.001471814938325','0.001470561618764','41.777318714866595','41.777318714866595','test'),('2018-04-28 03:59:59','2018-04-28 11:59:59','ASTBTC','4h','0.000057880000000','0.000056040000000','0.001471814938325','0.001425026073665','25.42873079345197','25.428730793451969','test'),('2018-04-28 15:59:59','2018-04-29 11:59:59','ASTBTC','4h','0.000059000000000','0.000056860000000','0.001471814938325','0.001418430464291','24.94601590381356','24.946015903813560','test'),('2018-05-20 03:59:59','2018-05-20 07:59:59','ASTBTC','4h','0.000045500000000','0.000044600000000','0.001471814938325','0.001442702115369','32.34758106208791','32.347581062087912','test'),('2018-05-20 15:59:59','2018-05-22 03:59:59','ASTBTC','4h','0.000045690000000','0.000045450000000','0.001471814938325','0.001464083802733','32.213064966622895','32.213064966622895','test'),('2018-06-03 15:59:59','2018-06-04 07:59:59','ASTBTC','4h','0.000038960000000','0.000038230000000','0.001471814938325','0.001444237297027','37.77759081943019','37.777590819430188','test'),('2018-07-02 03:59:59','2018-07-02 07:59:59','ASTBTC','4h','0.000022900000000','0.000024270000000','0.001471814938325','0.001559866749046','64.27139468668122','64.271394686681219','test'),('2018-07-04 15:59:59','2018-07-05 11:59:59','ASTBTC','4h','0.000024330000000','0.000023120000000','0.001471814938325','0.001398617401318','60.49383223695027','60.493832236950269','test'),('2018-07-05 19:59:59','2018-07-05 23:59:59','ASTBTC','4h','0.000023850000000','0.000023830000000','0.001471814938325','0.001470580711962','61.71131816876311','61.711318168763107','test'),('2018-07-08 11:59:59','2018-07-08 15:59:59','ASTBTC','4h','0.000023280000000','0.000024130000000','0.001471814938325','0.001525553885815','63.22229116516323','63.222291165163227','test'),('2018-08-07 19:59:59','2018-08-08 07:59:59','ASTBTC','4h','0.000017000000000','0.000015580000000','0.001471814938325','0.001348875102300','86.5773493132353','86.577349313235302','test'),('2018-08-17 11:59:59','2018-08-17 19:59:59','ASTBTC','4h','0.000013430000000','0.000014540000000','0.001471814938325','0.001593461593689','109.59158140915861','109.591581409158607','test'),('2018-08-20 07:59:59','2018-08-20 11:59:59','ASTBTC','4h','0.000013230000000','0.000013120000000','0.001471814938325','0.001459577625913','111.2482946579743','111.248294657974299','test'),('2018-08-22 07:59:59','2018-08-22 11:59:59','ASTBTC','4h','0.000013380000000','0.000013250000000','0.001471814938325','0.001457514793184','110.00111646674141','110.001116466741408','test'),('2018-08-23 15:59:59','2018-08-25 07:59:59','ASTBTC','4h','0.000014370000000','0.000013140000000','0.001471814938325','0.001345834954042','102.42275144919972','102.422751449199723','test'),('2018-08-31 07:59:59','2018-08-31 11:59:59','ASTBTC','4h','0.000014730000000','0.000014600000000','0.001471814938325','0.001458825397118','99.91954774779363','99.919547747793629','test'),('2018-09-17 03:59:59','2018-09-17 07:59:59','ASTBTC','4h','0.000011610000000','0.000011550000000','0.001471814938325','0.001464208659574','126.77131251722653','126.771312517226534','test'),('2018-09-18 19:59:59','2018-09-19 07:59:59','ASTBTC','4h','0.000011990000000','0.000011510000000','0.001471814938325','0.001412893239376','122.7535394766472','122.753539476647205','test'),('2018-09-19 19:59:59','2018-09-21 15:59:59','ASTBTC','4h','0.000011900000000','0.000011660000000','0.001471814938325','0.001442131275703','123.68192759033614','123.681927590336144','test'),('2018-09-29 19:59:59','2018-09-30 03:59:59','ASTBTC','4h','0.000012480000000','0.000012240000000','0.001471814938325','0.001443510804896','117.93388928886218','117.933889288862176','test'),('2018-09-30 11:59:59','2018-09-30 23:59:59','ASTBTC','4h','0.000012430000000','0.000012510000000','0.001471814938325','0.001481287600840','118.40828144207563','118.408281442075634','test'),('2018-10-03 15:59:59','2018-10-10 11:59:59','ASTBTC','4h','0.000013300000000','0.000014060000000','0.001471814938325','0.001555918649086','110.66277731766918','110.662777317669182','test'),('2018-10-13 19:59:59','2018-10-14 03:59:59','ASTBTC','4h','0.000013710000000','0.000013230000000','0.001471814938325','0.001420285312476','107.35338718636034','107.353387186360337','test'),('2018-10-14 15:59:59','2018-10-14 23:59:59','ASTBTC','4h','0.000014030000000','0.000013550000000','0.001471814938325','0.001421460613992','104.90484236101213','104.904842361012129','test'),('2018-10-16 15:59:59','2018-10-18 23:59:59','ASTBTC','4h','0.000014120000000','0.000013670000000','0.001471814938325','0.001424908654880','104.23618543378187','104.236185433781870','test'),('2018-10-19 11:59:59','2018-10-22 07:59:59','ASTBTC','4h','0.000013750000000','0.000014290000000','0.001471814938325','0.001529617124994','107.04108642363636','107.041086423636358','test'),('2018-10-29 15:59:59','2018-11-03 15:59:59','ASTBTC','4h','0.000016780000000','0.000015330000000','0.001471814938325','0.001344631883464','87.7124516284267','87.712451628426706','test'),('2018-11-04 07:59:59','2018-11-04 11:59:59','ASTBTC','4h','0.000015570000000','0.000014890000000','0.001471814938325','0.001407535287839','94.52889777296083','94.528897772960832','test'),('2018-11-07 19:59:59','2018-11-07 23:59:59','ASTBTC','4h','0.000015320000000','0.000015230000000','0.001471814938325','0.001463168505920','96.07147117003917','96.071471170039175','test'),('2018-11-10 23:59:59','2018-11-11 15:59:59','ASTBTC','4h','0.000015260000000','0.000014930000000','0.001471814938325','0.001439986699161','96.44920958879423','96.449209588794233','test'),('2018-11-29 07:59:59','2018-11-29 23:59:59','ASTBTC','4h','0.000009140000000','0.000009020000000','0.001471814938325','0.001452491328631','161.03008077954047','161.030080779540469','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','ASTBTC','4h','0.000009200000000','0.000009470000000','0.001471814938325','0.001515009507167','159.97988460054347','159.979884600543471','test'),('2018-12-02 11:59:59','2018-12-05 15:59:59','ASTBTC','4h','0.000009270000000','0.000009480000000','0.001471814938325','0.001505157024306','158.7718380070119','158.771838007011894','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','ASTBTC','4h','0.000007680000000','0.000007520000000','0.001471814938325','0.001441152127110','191.64257009440107','191.642570094401066','test'),('2018-12-22 07:59:59','2018-12-25 03:59:59','ASTBTC','4h','0.000007820000000','0.000007280000000','0.001471814938325','0.001370180658696','188.21162894181586','188.211628941815860','test'),('2018-12-26 11:59:59','2018-12-26 19:59:59','ASTBTC','4h','0.000007840000000','0.000007740000000','0.001471814938325','0.001453041788601','187.73149723533166','187.731497235331659','test'),('2019-01-03 03:59:59','2019-01-04 03:59:59','ASTBTC','4h','0.000007480000000','0.000007410000000','0.001471814938325','0.001458041269116','196.76670298462565','196.766702984625653','test'),('2019-01-06 03:59:59','2019-01-06 15:59:59','ASTBTC','4h','0.000007420000000','0.000007430000000','0.001471814938325','0.001473798516409','198.35780839959568','198.357808399595683','test'),('2019-01-07 11:59:59','2019-01-07 15:59:59','ASTBTC','4h','0.000007430000000','0.000007320000000','0.001471814938325','0.001450024945968','198.09083961305518','198.090839613055181','test'),('2019-01-07 19:59:59','2019-01-08 03:59:59','ASTBTC','4h','0.000007540000000','0.000007350000000','0.001471814938325','0.001434726763487','195.20092020225465','195.200920202254650','test'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ASTBTC','4h','0.000007090000000','0.000006920000000','0.001471814938325','0.001436524594247','207.5902592842031','207.590259284203114','test'),('2019-01-16 07:59:59','2019-01-18 15:59:59','ASTBTC','4h','0.000007160000000','0.000007810000000','0.001471814938325','0.001605429422949','205.5607455761173','205.560745576117313','test'),('2019-02-07 15:59:59','2019-02-08 15:59:59','ASTBTC','4h','0.000008050000000','0.000007510000000','0.001471814938325','0.001373084495257','182.83415382919256','182.834153829192559','test'),('2019-02-09 03:59:59','2019-02-09 11:59:59','ASTBTC','4h','0.000007580000000','0.000007390000000','0.001471814938325','0.001434922479449','194.17083619063325','194.170836190633253','test'),('2019-02-15 15:59:59','2019-02-15 19:59:59','ASTBTC','4h','0.000007340000000','0.000007340000000','0.001471814938325','0.001471814938325','200.51974636580383','200.519746365803826','test'),('2019-02-16 19:59:59','2019-02-18 19:59:59','ASTBTC','4h','0.000007500000000','0.000007420000000','0.001471814938325','0.001456115578983','196.24199177666668','196.241991776666680','test'),('2019-02-19 11:59:59','2019-02-21 11:59:59','ASTBTC','4h','0.000007550000000','0.000007450000000','0.001471814938325','0.001452320700731','194.9423759370861','194.942375937086098','test'),('2019-02-25 03:59:59','2019-02-25 11:59:59','ASTBTC','4h','0.000008040000000','0.000008110000000','0.001471814938325','0.001484629247490','183.06155949315922','183.061559493159223','test'),('2019-03-07 15:59:59','2019-03-11 07:59:59','ASTBTC','4h','0.000009210000000','0.000009390000000','0.001471814938325','0.001500580051126','159.8061822285559','159.806182228555912','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','ASTBTC','4h','0.000009460000000','0.000009390000000','0.001471814938325','0.001460924130113','155.58297445295986','155.582974452959860','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','ASTBTC','4h','0.000010170000000','0.000010150000000','0.001471814938325','0.001468920513668','144.721232873648','144.721232873648006','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','ASTBTC','4h','0.000009890000000','0.000009890000000','0.001471814938325','0.001471814938325','148.81849730283113','148.818497302831133','test'),('2019-03-23 03:59:59','2019-03-23 15:59:59','ASTBTC','4h','0.000009950000000','0.000010140000000','0.001471814938325','0.001499919947198','147.92109932914573','147.921099329145733','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','ASTBTC','4h','0.000010280000000','0.000010080000000','0.001471814938325','0.001443180406451','143.1726593701362','143.172659370136188','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:33:42
