-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-25 15:59:59','ZECETH','4h','0.443370000000000','0.475450000000000','0.072144500000000','0.077364509382683','0.16271849696641633','0.162718496966416','test'),('2018-06-14 15:59:59','2018-06-14 19:59:59','ZECETH','4h','0.409580000000000','0.382680000000000','0.073449502345671','0.068625556808539','0.17932883037665595','0.179328830376656','test'),('2018-06-25 19:59:59','2018-06-26 19:59:59','ZECETH','4h','0.380580000000000','0.373750000000000','0.073449502345671','0.072131356092529','0.19299359489639764','0.192993594896398','test'),('2018-06-29 15:59:59','2018-06-29 23:59:59','ZECETH','4h','0.374550000000000','0.374810000000000','0.073449502345671','0.073500488517370','0.19610066038091312','0.196100660380913','test'),('2018-07-02 11:59:59','2018-07-05 19:59:59','ZECETH','4h','0.380170000000000','0.376390000000000','0.073449502345671','0.072719199799792','0.1932017317138938','0.193201731713894','test'),('2018-07-13 23:59:59','2018-07-16 15:59:59','ZECETH','4h','0.406500000000000','0.385940000000000','0.073449502345671','0.069734565646466','0.18068758264617715','0.180687582646177','test'),('2018-07-21 15:59:59','2018-07-22 07:59:59','ZECETH','4h','0.407500000000000','0.406650000000000','0.073449502345671','0.073296294794766','0.180244177535389','0.180244177535389','test'),('2018-08-07 07:59:59','2018-08-08 19:59:59','ZECETH','4h','0.451350000000000','0.447650000000000','0.073449502345671','0.072847390550658','0.16273291757100036','0.162732917571000','test'),('2018-08-16 11:59:59','2018-08-17 03:59:59','ZECETH','4h','0.477690000000000','0.480080000000000','0.073449502345671','0.073816988185036','0.15375976542458708','0.153759765424587','test'),('2018-08-18 15:59:59','2018-08-18 23:59:59','ZECETH','4h','0.485000000000000','0.483430000000000','0.073449502345671','0.073211737977253','0.15144227287767217','0.151442272877672','test'),('2018-08-21 19:59:59','2018-08-21 23:59:59','ZECETH','4h','0.483050000000000','0.480000000000000','0.073449502345671','0.072985738797065','0.1520536224938847','0.152053622493885','test'),('2018-08-23 15:59:59','2018-08-23 19:59:59','ZECETH','4h','0.480770000000000','0.476380000000000','0.073449502345671','0.072778821322942','0.15277472043944298','0.152774720439443','test'),('2018-08-24 15:59:59','2018-08-24 19:59:59','ZECETH','4h','0.478150000000000','0.495300000000000','0.073449502345671','0.076083945439320','0.15361184219527554','0.153611842195276','test'),('2018-09-24 15:59:59','2018-09-29 11:59:59','ZECETH','4h','0.593850000000000','0.581990000000000','0.073449502345671','0.071982614919857','0.12368359408212681','0.123683594082127','test'),('2018-10-05 07:59:59','2018-10-05 15:59:59','ZECETH','4h','0.583880000000000','0.566790000000000','0.073449502345671','0.071299656495346','0.1257955441968744','0.125795544196874','test'),('2018-10-11 07:59:59','2018-10-11 11:59:59','ZECETH','4h','0.563020000000000','0.562730000000000','0.073449502345671','0.073411670020567','0.13045629346323578','0.130456293463236','test'),('2018-10-11 19:59:59','2018-10-12 03:59:59','ZECETH','4h','0.565780000000000','0.559300000000000','0.073449502345671','0.072608269401417','0.12981989880460781','0.129819898804608','test'),('2018-10-17 15:59:59','2018-10-26 15:59:59','ZECETH','4h','0.558070000000000','0.593820000000000','0.073449502345671','0.078154682177695','0.13161342187480246','0.131613421874802','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','ZECETH','4h','0.597280000000000','0.598900000000000','0.073449502345671','0.073648719118039','0.12297331627657213','0.122973316276572','test'),('2018-11-06 11:59:59','2018-11-06 15:59:59','ZECETH','4h','0.590370000000000','0.597630000000000','0.073449502345671','0.074352738260486','0.12441266044289347','0.124412660442893','test'),('2018-11-07 19:59:59','2018-11-11 23:59:59','ZECETH','4h','0.593330000000000','0.613640000000000','0.073449502345671','0.075963717694028','0.12379199154883623','0.123791991548836','test'),('2018-11-12 19:59:59','2018-11-14 15:59:59','ZECETH','4h','0.645230000000000','0.632360000000000','0.073449502345671','0.071984450976099','0.1138346052503309','0.113834605250331','test'),('2018-11-16 03:59:59','2018-11-16 07:59:59','ZECETH','4h','0.615810000000000','0.608420000000000','0.073449502345671','0.072568074921085','0.11927299385471332','0.119272993854713','test'),('2018-11-16 11:59:59','2018-11-16 15:59:59','ZECETH','4h','0.610610000000000','0.620000000000000','0.073449502345671','0.074579013534525','0.12028873150729763','0.120288731507298','test'),('2018-11-17 15:59:59','2018-11-17 19:59:59','ZECETH','4h','0.614350000000000','0.614930000000000','0.073449502345671','0.073518845084111','0.11955644558585661','0.119556445585857','test'),('2018-11-22 19:59:59','2018-11-22 23:59:59','ZECETH','4h','0.631950000000000','0.619280000000000','0.073449502345671','0.071976909269131','0.116226762157878','0.116226762157878','test'),('2018-11-23 19:59:59','2018-11-23 23:59:59','ZECETH','4h','0.630380000000000','0.628860000000000','0.073449502345671','0.073272397672989','0.11651623202777849','0.116516232027778','test'),('2018-11-26 11:59:59','2018-11-26 15:59:59','ZECETH','4h','0.628150000000000','0.618200000000000','0.073449502345671','0.072286050067808','0.11692987717212609','0.116929877172126','test'),('2018-11-27 11:59:59','2018-12-03 15:59:59','ZECETH','4h','0.628340000000000','0.650550000000000','0.073449502345671','0.076045729622460','0.11689451944117994','0.116894519441180','test'),('2018-12-04 11:59:59','2018-12-05 07:59:59','ZECETH','4h','0.685580000000000','0.665000000000000','0.073449502345671','0.071244667376340','0.10713483815990987','0.107134838159910','test'),('2019-01-10 11:59:59','2019-01-10 15:59:59','ZECETH','4h','0.418200000000000','0.410500000000000','0.073449502345671','0.072097132264223','0.175632478110165','0.175632478110165','test'),('2019-01-10 19:59:59','2019-01-13 19:59:59','ZECETH','4h','0.425010000000000','0.457000000000000','0.073449502345671','0.078977959511474','0.17281829214764596','0.172818292147646','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','ZECETH','4h','0.431600000000000','0.425750000000000','0.073449502345671','0.072453951862070','0.17017956984631838','0.170179569846318','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','ZECETH','4h','0.441540000000000','0.441160000000000','0.073449502345671','0.073386289928016','0.16634846751295693','0.166348467512957','test'),('2019-02-02 15:59:59','2019-02-02 19:59:59','ZECETH','4h','0.454610000000000','0.453240000000000','0.073449502345671','0.073228156976644','0.16156596279375948','0.161565962793759','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','ZECETH','4h','0.444500000000000','0.434910000000000','0.073449502345671','0.071864843791127','0.16524072518711136','0.165240725187111','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ZECETH','4h','0.384990000000000','0.381550000000000','0.073449502345671','0.072793209226190','0.1907828835701473','0.190782883570147','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','ZECETH','4h','0.384980000000000','0.374510000000000','0.073449502345671','0.071451953668963','0.19078783922715728','0.190787839227157','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','ZECETH','4h','0.382100000000000','0.384620000000000','0.073449502345671','0.073933911521047','0.19222586324436275','0.192225863244363','test'),('2019-03-02 15:59:59','2019-03-03 03:59:59','ZECETH','4h','0.386190000000000','0.382240000000000','0.073449502345671','0.072698251577227','0.19019006796051427','0.190190067960514','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','ZECETH','4h','0.374370000000000','0.374500000000000','0.073449502345671','0.073475007688794','0.19619494709958332','0.196194947099583','test'),('2019-03-12 11:59:59','2019-03-12 15:59:59','ZECETH','4h','0.373820000000000','0.383790000000000','0.073449502345671','0.075408443917514','0.1964836080083222','0.196483608008322','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','ZECETH','4h','0.405840000000000','0.402530000000000','0.073449502345671','0.072850453822203','0.18098142702954614','0.180981427029546','test'),('2019-03-27 15:59:59','2019-03-28 07:59:59','ZECETH','4h','0.404390000000000','0.402360000000000','0.073449502345671','0.073080792709523','0.18163036263426643','0.181630362634266','test'),('2019-03-28 19:59:59','2019-03-29 03:59:59','ZECETH','4h','0.408040000000000','0.403070000000000','0.073449502345671','0.072554874302690','0.18000564245091413','0.180005642450914','test'),('2019-03-29 19:59:59','2019-03-29 23:59:59','ZECETH','4h','0.407410000000000','0.398420000000000','0.073449502345671','0.071828749231885','0.180283994859407','0.180283994859407','test'),('2019-03-31 03:59:59','2019-04-04 11:59:59','ZECETH','4h','0.405430000000000','0.418580000000000','0.073449502345671','0.075831814843132','0.18116444847611426','0.181164448476114','test'),('2019-04-11 19:59:59','2019-04-14 07:59:59','ZECETH','4h','0.423700000000000','0.417070000000000','0.073449502345671','0.072300174518076','0.17335261351350248','0.173352613513502','test'),('2019-04-15 23:59:59','2019-04-16 03:59:59','ZECETH','4h','0.421650000000000','0.417700000000000','0.073449502345671','0.072761430403858','0.17419542830705798','0.174195428307058','test'),('2019-04-17 23:59:59','2019-04-18 03:59:59','ZECETH','4h','0.424490000000000','0.415650000000000','0.073449502345671','0.071919917194700','0.17302999445374687','0.173029994453747','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  3:33:59
