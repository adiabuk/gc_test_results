-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 15:59:59','2018-03-20 19:59:59','LINKETH','4h','0.000701930000000','0.000701500000000','0.072144500000000','0.072100304517544','102.7801917570128','102.780191757012801','test'),('2018-03-30 11:59:59','2018-03-30 15:59:59','LINKETH','4h','0.000757510000000','0.000745100000000','0.072144500000000','0.070962583926285','95.23900674578553','95.239006745785531','test'),('2018-04-04 07:59:59','2018-04-04 11:59:59','LINKETH','4h','0.000737500000000','0.000732030000000','0.072144500000000','0.071609407911864','97.82305084745764','97.823050847457637','test'),('2018-04-04 19:59:59','2018-04-04 23:59:59','LINKETH','4h','0.000743590000000','0.000767000000000','0.072144500000000','0.074415782218696','97.02188033728264','97.021880337282639','test'),('2018-04-13 15:59:59','2018-04-13 23:59:59','LINKETH','4h','0.000795000000000','0.000773920000000','0.072272019643597','0.070355674770532','90.90820080955629','90.908200809556291','test'),('2018-04-14 07:59:59','2018-04-14 15:59:59','LINKETH','4h','0.000810190000000','0.000798000000000','0.072272019643597','0.071184625428098','89.20379126328022','89.203791263280223','test'),('2018-04-15 07:59:59','2018-04-15 11:59:59','LINKETH','4h','0.000801520000000','0.000799970000000','0.072272019643597','0.072132258152371','90.16870401686421','90.168704016864211','test'),('2018-04-22 03:59:59','2018-04-22 11:59:59','LINKETH','4h','0.000818360000000','0.000803530000000','0.072272019643597','0.070962334356786','88.31323579304585','88.313235793045848','test'),('2018-04-29 15:59:59','2018-04-29 23:59:59','LINKETH','4h','0.000763650000000','0.000749980000000','0.072272019643597','0.070978287556217','94.64024048136842','94.640240481368423','test'),('2018-05-07 23:59:59','2018-05-08 23:59:59','LINKETH','4h','0.000765710000000','0.000736540000000','0.072272019643597','0.069518790858543','94.38562855858876','94.385628558588763','test'),('2018-05-10 15:59:59','2018-05-10 19:59:59','LINKETH','4h','0.000759660000000','0.000749900000000','0.072272019643597','0.071343479360152','95.13732412341969','95.137324123419688','test'),('2018-05-15 07:59:59','2018-05-15 11:59:59','LINKETH','4h','0.000723560000000','0.000726300000000','0.072272019643597','0.072545701624115','99.88393449554563','99.883934495545631','test'),('2018-06-02 15:59:59','2018-06-02 23:59:59','LINKETH','4h','0.000622050000000','0.000622350000000','0.072272019643597','0.072306874729029','116.18361810722129','116.183618107221292','test'),('2018-06-29 23:59:59','2018-07-05 15:59:59','LINKETH','4h','0.000419940000000','0.000484080000000','0.072272019643597','0.083310566435854','172.1008230785279','172.100823078527895','test'),('2018-07-06 03:59:59','2018-07-10 03:59:59','LINKETH','4h','0.000476020000000','0.000484350000000','0.072751618852529','0.074024718690858','152.83311384506743','152.833113845067430','test'),('2018-07-10 23:59:59','2018-07-11 03:59:59','LINKETH','4h','0.000488160000000','0.000481200000000','0.073069893812111','0.072028090999647','149.68431213559336','149.684312135593359','test'),('2018-07-17 07:59:59','2018-07-17 11:59:59','LINKETH','4h','0.000464970000000','0.000467710000000','0.073069893812111','0.073500483977165','157.1496952752027','157.149695275202703','test'),('2018-07-21 23:59:59','2018-07-22 03:59:59','LINKETH','4h','0.000485590000000','0.000468030000000','0.073069893812111','0.070427526104084','150.47652095823844','150.476520958238439','test'),('2018-07-25 03:59:59','2018-08-04 15:59:59','LINKETH','4h','0.000501930000000','0.000627750000000','0.073069893812111','0.091386499791909','145.5778570958321','145.577857095832087','test'),('2018-08-07 19:59:59','2018-08-07 23:59:59','LINKETH','4h','0.000632380000000','0.000612420000000','0.076835650218201','0.074410463497629','121.50234071001849','121.502340710018487','test'),('2018-08-08 11:59:59','2018-08-08 15:59:59','LINKETH','4h','0.000625470000000','0.000630040000000','0.076835650218201','0.077397050319720','122.84466116392633','122.844661163926332','test'),('2018-08-08 23:59:59','2018-08-29 19:59:59','LINKETH','4h','0.000645760000000','0.001090000000000','0.076835650218201','0.129693475498388','118.98483990677806','118.984839906778063','test'),('2018-08-31 07:59:59','2018-08-31 11:59:59','LINKETH','4h','0.001132470000000','0.001105440000000','0.089584159883485','0.087445948856570','79.10510643415277','79.105106434152773','test'),('2018-09-05 19:59:59','2018-09-14 03:59:59','LINKETH','4h','0.001129500000000','0.001231530000000','0.089584159883485','0.097676476689959','79.31311189330235','79.313111893302349','test'),('2018-09-14 23:59:59','2018-09-15 07:59:59','LINKETH','4h','0.001283000000000','0.001262810000000','0.091072686328375','0.089639515995585','70.98416705251344','70.984167052513442','test'),('2018-09-16 15:59:59','2018-09-16 19:59:59','LINKETH','4h','0.001263740000000','0.001229380000000','0.091072686328375','0.088596498582286','72.0659995951501','72.065999595150103','test'),('2018-09-17 07:59:59','2018-09-22 03:59:59','LINKETH','4h','0.001281690000000','0.001420980000000','0.091072686328375','0.100970176734541','71.05671911958039','71.056719119580393','test'),('2018-09-24 07:59:59','2018-09-28 19:59:59','LINKETH','4h','0.001437990000000','0.001509950000000','0.092569719410197','0.097202100030895','64.37438327818448','64.374383278184482','test'),('2018-10-04 23:59:59','2018-10-05 03:59:59','LINKETH','4h','0.001446960000000','0.001456510000000','0.093727814565371','0.094346422287146','64.77567767275599','64.775677672755990','test'),('2018-10-05 15:59:59','2018-10-08 23:59:59','LINKETH','4h','0.001535680000000','0.001502140000000','0.093882466495815','0.091832027650307','61.13413373607441','61.134133736074411','test'),('2018-10-09 19:59:59','2018-10-15 07:59:59','LINKETH','4h','0.001489320000000','0.001574720000000','0.093882466495815','0.099265837859083','63.03713540126702','63.037135401267022','test'),('2018-11-08 07:59:59','2018-11-08 11:59:59','LINKETH','4h','0.002407460000000','0.002343030000000','0.094715699625255','0.092180856875280','39.34258497555712','39.342584975557124','test'),('2018-11-09 15:59:59','2018-11-19 19:59:59','LINKETH','4h','0.002385170000000','0.002755250000000','0.094715699625255','0.109411669353750','39.71025110380183','39.710251103801831','test'),('2018-11-22 03:59:59','2018-11-22 07:59:59','LINKETH','4h','0.002753960000000','0.002765220000000','0.097755981369885','0.098155672124371','35.49651460801346','35.496514608013463','test'),('2018-11-23 07:59:59','2018-11-23 11:59:59','LINKETH','4h','0.002746860000000','0.002716780000000','0.097855904058506','0.096784314827865','35.62464197611318','35.624641976113182','test'),('2018-11-23 15:59:59','2018-11-23 19:59:59','LINKETH','4h','0.002767540000000','0.002648410000000','0.097855904058506','0.093643652799088','35.35844253687607','35.358442536876069','test'),('2018-11-27 03:59:59','2018-11-27 23:59:59','LINKETH','4h','0.002688540000000','0.002629340000000','0.097855904058506','0.095701177135989','36.3974142317042','36.397414231704197','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','LINKETH','4h','0.002741280000000','0.002474970000000','0.097855904058506','0.088349394030409','35.697157553590294','35.697157553590294','test'),('2018-12-12 07:59:59','2018-12-12 15:59:59','LINKETH','4h','0.002601070000000','0.002555680000000','0.097855904058506','0.096148268552650','37.621403521822174','37.621403521822174','test'),('2018-12-18 11:59:59','2018-12-22 03:59:59','LINKETH','4h','0.002571230000000','0.002650300000000','0.097855904058506','0.100865151124660','38.05801272484609','38.058012724846087','test'),('2019-01-03 11:59:59','2019-01-26 19:59:59','LINKETH','4h','0.002312050000000','0.004074820000000','0.097855904058506','0.172463915129725','42.32430270041998','42.324302700419977','test'),('2019-01-29 07:59:59','2019-01-29 15:59:59','LINKETH','4h','0.004022410000000','0.004109550000000','0.112597040356217','0.115036300923052','27.992432486051214','27.992432486051214','test'),('2019-02-05 19:59:59','2019-02-06 07:59:59','LINKETH','4h','0.003894150000000','0.003935530000000','0.113206855497926','0.114409813699460','29.071005353652534','29.071005353652534','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','LINKETH','4h','0.003880300000000','0.003839990000000','0.113507595048310','0.112328435922367','29.25227303257725','29.252273032577250','test'),('2019-02-09 15:59:59','2019-02-10 07:59:59','LINKETH','4h','0.004048190000000','0.003979650000000','0.113507595048310','0.111585795289748','28.03909773214943','28.039097732149429','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKETH','4h','0.003348290000000','0.003214830000000','0.113507595048310','0.108983278565823','33.90016845861918','33.900168458619177','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','LINKETH','4h','0.003211970000000','0.003197420000000','0.113507595048310','0.112993413562196','35.33893375352509','35.338933753525090','test'),('2019-03-03 03:59:59','2019-03-03 07:59:59','LINKETH','4h','0.003201150000000','0.003181010000000','0.113507595048310','0.112793463263085','35.458380597069805','35.458380597069805','test'),('2019-03-03 15:59:59','2019-03-03 19:59:59','LINKETH','4h','0.003199200000000','0.003236060000000','0.113507595048310','0.114815387606912','35.47999345095961','35.479993450959611','test'),('2019-03-07 19:59:59','2019-03-15 19:59:59','LINKETH','4h','0.003401970000000','0.003569070000000','0.113507595048310','0.119082929084934','33.36525455789146','33.365254557891461','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:06:32
