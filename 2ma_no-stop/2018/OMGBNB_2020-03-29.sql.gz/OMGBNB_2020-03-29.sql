-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-09-26 19:59:59','2019-09-26 23:59:59','OMGBNB','4h','0.051940000000000','0.052390000000000','0.711908500000000','0.718076363400077','13.70636311128225','13.706363111282251','test'),('2019-09-29 07:59:59','2019-09-29 11:59:59','OMGBNB','4h','0.052290000000000','0.052470000000000','0.713450465850019','0.715906405491499','13.644109119334848','13.644109119334848','test'),('2019-10-02 03:59:59','2019-10-02 11:59:59','OMGBNB','4h','0.052310000000000','0.052000000000000','0.714064450760389','0.709832755487292','13.650629913217152','13.650629913217152','test'),('2019-10-24 11:59:59','2019-10-25 03:59:59','OMGBNB','4h','0.046580000000000','0.044740000000000','0.714064450760389','0.685857525268781','15.329850810656698','15.329850810656698','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','OMGBNB','4h','0.045290000000000','0.045060000000000','0.714064450760389','0.710438157457786','15.766492620013008','15.766492620013008','test'),('2019-10-27 11:59:59','2019-10-31 11:59:59','OMGBNB','4h','0.048000000000000','0.047790000000000','0.714064450760389','0.710940418788312','14.876342724174771','14.876342724174771','test'),('2019-11-01 11:59:59','2019-11-01 15:59:59','OMGBNB','4h','0.048640000000000','0.047260000000000','0.714064450760389','0.693805220866283','14.680601372540892','14.680601372540892','test'),('2019-11-03 15:59:59','2019-11-03 19:59:59','OMGBNB','4h','0.048170000000000','0.047550000000000','0.714064450760389','0.704873668956955','14.823841618442788','14.823841618442788','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','OMGBNB','4h','0.048060000000000','0.046350000000000','0.714064450760389','0.688657663186518','14.857770511035977','14.857770511035977','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','OMGBNB','4h','0.048010000000000','0.047280000000000','0.714064450760389','0.703206982544287','14.873244131647347','14.873244131647347','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','OMGBNB','4h','0.048050000000000','0.047600000000000','0.714064450760389','0.707377062563882','14.860862658905079','14.860862658905079','test'),('2019-11-08 19:59:59','2019-11-08 23:59:59','OMGBNB','4h','0.049030000000000','0.048250000000000','0.714064450760389','0.702704665494366','14.563827264131941','14.563827264131941','test'),('2019-11-09 07:59:59','2019-11-09 15:59:59','OMGBNB','4h','0.048890000000000','0.048240000000000','0.714064450760389','0.704570855076318','14.605531821648373','14.605531821648373','test'),('2019-11-09 23:59:59','2019-11-10 03:59:59','OMGBNB','4h','0.048610000000000','0.047860000000000','0.714064450760389','0.703047204554458','14.689661607907613','14.689661607907613','test'),('2019-11-10 15:59:59','2019-11-10 19:59:59','OMGBNB','4h','0.049300000000000','0.049230000000000','0.714064450760389','0.713050566144705','14.484065938344607','14.484065938344607','test'),('2019-11-15 07:59:59','2019-11-18 19:59:59','OMGBNB','4h','0.048280000000000','0.049200000000000','0.714064450760389','0.727671312705285','14.790067331408222','14.790067331408222','test'),('2019-11-20 07:59:59','2019-11-20 11:59:59','OMGBNB','4h','0.049070000000000','0.048530000000000','0.714064450760389','0.706206394852286','14.55195538537577','14.551955385375770','test'),('2019-11-20 15:59:59','2019-11-20 23:59:59','OMGBNB','4h','0.049410000000000','0.048600000000000','0.714064450760389','0.702358476157760','14.451820497073244','14.451820497073244','test'),('2019-11-21 07:59:59','2019-11-21 11:59:59','OMGBNB','4h','0.049740000000000','0.048800000000000','0.714064450760389','0.700569867251849','14.35593990270183','14.355939902701831','test'),('2019-11-22 11:59:59','2019-11-24 03:59:59','OMGBNB','4h','0.050170000000000','0.048960000000000','0.714064450760389','0.696842645190924','14.2328971648473','14.232897164847300','test'),('2019-11-25 03:59:59','2019-11-25 07:59:59','OMGBNB','4h','0.049430000000000','0.048470000000000','0.714064450760389','0.700196316576088','14.44597310864635','14.445973108646349','test'),('2019-11-27 11:59:59','2019-11-27 15:59:59','OMGBNB','4h','0.049300000000000','0.049290000000000','0.714064450760389','0.713919610101006','14.484065938344607','14.484065938344607','test'),('2019-11-28 11:59:59','2019-11-30 07:59:59','OMGBNB','4h','0.049180000000000','0.049130000000000','0.714064450760389','0.713338480395647','14.519407294843209','14.519407294843209','test'),('2019-12-03 03:59:59','2019-12-03 07:59:59','OMGBNB','4h','0.049140000000000','0.048590000000000','0.714064450760389','0.706072276403079','14.531226104200021','14.531226104200021','test'),('2019-12-10 03:59:59','2019-12-10 07:59:59','OMGBNB','4h','0.048530000000000','0.047830000000000','0.714064450760389','0.703764736861105','14.713876998977726','14.713876998977726','test'),('2019-12-10 11:59:59','2019-12-12 19:59:59','OMGBNB','4h','0.048610000000000','0.048230000000000','0.714064450760389','0.708482379349384','14.689661607907613','14.689661607907613','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','OMGBNB','4h','0.048700000000000','0.048400000000000','0.714064450760389','0.709665696443590','14.66251438933037','14.662514389330370','test'),('2019-12-14 15:59:59','2019-12-16 19:59:59','OMGBNB','4h','0.048700000000000','0.048090000000000','0.714064450760389','0.705120316982898','14.66251438933037','14.662514389330370','test'),('2019-12-16 23:59:59','2019-12-17 07:59:59','OMGBNB','4h','0.048700000000000','0.048570000000000','0.714064450760389','0.712158323889776','14.66251438933037','14.662514389330370','test'),('2019-12-19 07:59:59','2019-12-19 11:59:59','OMGBNB','4h','0.048580000000000','0.047620000000000','0.714064450760389','0.699953667048368','14.698733033355065','14.698733033355065','test'),('2019-12-21 11:59:59','2019-12-22 15:59:59','OMGBNB','4h','0.048700000000000','0.048080000000000','0.714064450760389','0.704973691839004','14.66251438933037','14.662514389330370','test'),('2020-01-03 23:59:59','2020-01-04 07:59:59','OMGBNB','4h','0.046010000000000','0.045710000000000','0.714064450760389','0.709408520848889','15.51976637166679','15.519766371666790','test'),('2020-01-06 15:59:59','2020-01-06 19:59:59','OMGBNB','4h','0.045840000000000','0.045820000000000','0.714064450760389','0.713752904315904','15.577322224266776','15.577322224266776','test'),('2020-01-07 03:59:59','2020-01-07 19:59:59','OMGBNB','4h','0.045860000000000','0.044790000000000','0.714064450760389','0.697403984944567','15.57052879983404','15.570528799834040','test'),('2020-01-15 03:59:59','2020-01-15 07:59:59','OMGBNB','4h','0.045630000000000','0.046010000000000','0.714064450760389','0.720011075596877','15.649012727600024','15.649012727600024','test'),('2020-01-15 19:59:59','2020-01-16 03:59:59','OMGBNB','4h','0.046510000000000','0.045500000000000','0.714064450760389','0.698557998486298','15.352923043654892','15.352923043654892','test'),('2020-01-16 23:59:59','2020-01-17 03:59:59','OMGBNB','4h','0.045410000000000','0.042990000000000','0.714064450760389','0.676010366399232','15.724828248412003','15.724828248412003','test'),('2020-01-17 19:59:59','2020-01-19 11:59:59','OMGBNB','4h','0.045870000000000','0.045500000000000','0.714064450760389','0.708304611066006','15.567134309142991','15.567134309142991','test'),('2020-01-20 15:59:59','2020-01-20 19:59:59','OMGBNB','4h','0.045820000000000','0.045290000000000','0.714064450760389','0.705804866323396','15.584121579231537','15.584121579231537','test'),('2020-01-21 03:59:59','2020-01-21 07:59:59','OMGBNB','4h','0.045580000000000','0.045220000000000','0.714064450760389','0.708424626226081','15.666179261965533','15.666179261965533','test'),('2020-01-21 11:59:59','2020-01-21 15:59:59','OMGBNB','4h','0.045500000000000','0.044510000000000','0.714064450760389','0.698527663809778','15.693724192536024','15.693724192536024','test'),('2020-01-21 23:59:59','2020-01-22 03:59:59','OMGBNB','4h','0.046150000000000','0.045530000000000','0.714064450760389','0.704471385549740','15.472685823627065','15.472685823627065','test'),('2020-01-24 23:59:59','2020-01-25 07:59:59','OMGBNB','4h','0.045570000000000','0.045000000000000','0.714064450760389','0.705132769019476','15.669617089321681','15.669617089321681','test'),('2020-01-27 03:59:59','2020-01-27 23:59:59','OMGBNB','4h','0.046320000000000','0.045900000000000','0.714064450760389','0.707589773098054','15.415899196036033','15.415899196036033','test'),('2020-01-28 19:59:59','2020-01-28 23:59:59','OMGBNB','4h','0.045650000000000','0.045080000000000','0.714064450760389','0.705148421473786','15.642156643162958','15.642156643162958','test'),('2020-01-29 07:59:59','2020-01-29 11:59:59','OMGBNB','4h','0.045720000000000','0.046550000000000','0.714064450760389','0.727027563055471','15.618207584435456','15.618207584435456','test'),('2020-02-08 11:59:59','2020-02-09 03:59:59','OMGBNB','4h','0.051590000000000','0.050190000000000','0.714064450760389','0.694686853724829','13.841140739685773','13.841140739685773','test'),('2020-02-13 11:59:59','2020-02-13 15:59:59','OMGBNB','4h','0.049290000000000','0.048870000000000','0.714064450760389','0.707979908879290','14.487004478806838','14.487004478806838','test'),('2020-02-13 19:59:59','2020-02-16 15:59:59','OMGBNB','4h','0.050190000000000','0.050520000000000','0.714064450760389','0.718759435194558','14.227225558087051','14.227225558087051','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:25:13
