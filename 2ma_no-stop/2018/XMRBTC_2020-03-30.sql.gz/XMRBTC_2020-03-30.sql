-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-15 07:59:59','2018-05-15 11:59:59','XMRBTC','4h','0.024790000000000','0.024645000000000','0.001467500000000','0.001458916397741','0.05919725695845099','0.059197256958451','test'),('2018-05-18 23:59:59','2018-05-19 07:59:59','XMRBTC','4h','0.024744000000000','0.024170000000000','0.001467500000000','0.001433457605884','0.05930730682185581','0.059307306821856','test'),('2018-06-03 07:59:59','2018-06-03 11:59:59','XMRBTC','4h','0.022127000000000','0.022380000000000','0.001467500000000','0.001484279387174','0.06632168843494374','0.066321688434944','test'),('2018-06-05 15:59:59','2018-06-06 03:59:59','XMRBTC','4h','0.021967000000000','0.021811000000000','0.001467500000000','0.001457078458597','0.06680475258342058','0.066804752583421','test'),('2018-06-06 15:59:59','2018-06-06 19:59:59','XMRBTC','4h','0.021899000000000','0.021581000000000','0.001467500000000','0.001446190122837','0.06701219233754967','0.067012192337550','test'),('2018-06-07 03:59:59','2018-06-07 07:59:59','XMRBTC','4h','0.021908000000000','0.021748000000000','0.001467500000000','0.001456782453898','0.0669846631367537','0.066984663136754','test'),('2018-06-07 11:59:59','2018-06-07 15:59:59','XMRBTC','4h','0.021779000000000','0.021536000000000','0.001467500000000','0.001451126314340','0.06738142247118785','0.067381422471188','test'),('2018-06-24 03:59:59','2018-06-24 07:59:59','XMRBTC','4h','0.019148000000000','0.018608000000000','0.001467500000000','0.001426114476708','0.07663985794861083','0.076639857948611','test'),('2018-06-24 11:59:59','2018-06-24 15:59:59','XMRBTC','4h','0.019129000000000','0.018843000000000','0.001467500000000','0.001445559229442','0.07671598097130013','0.076715980971300','test'),('2018-06-24 19:59:59','2018-06-28 23:59:59','XMRBTC','4h','0.019564000000000','0.020066000000000','0.001467500000000','0.001505155131875','0.07501022285831119','0.075010222858311','test'),('2018-07-08 19:59:59','2018-07-08 23:59:59','XMRBTC','4h','0.020547000000000','0.020462000000000','0.001467500000000','0.001461429162408','0.07142161872779482','0.071421618727795','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','XMRBTC','4h','0.020491000000000','0.020584000000000','0.001467500000000','0.001474160363086','0.07161680737884926','0.071616807378849','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','XMRBTC','4h','0.019965000000000','0.020141000000000','0.001467500000000','0.001480436639118','0.07350363135487102','0.073503631354871','test'),('2018-08-06 03:59:59','2018-08-06 07:59:59','XMRBTC','4h','0.016813000000000','0.016512000000000','0.001467500000000','0.001441227621483','0.0872836495568905','0.087283649556890','test'),('2018-08-17 23:59:59','2018-08-18 19:59:59','XMRBTC','4h','0.015117000000000','0.015131000000000','0.001467500000000','0.001468859065952','0.09707613944565721','0.097076139445657','test'),('2018-08-27 19:59:59','2018-08-29 11:59:59','XMRBTC','4h','0.014845000000000','0.014555000000000','0.001467500000000','0.001438832098350','0.09885483327719771','0.098854833277198','test'),('2018-08-30 23:59:59','2018-09-08 19:59:59','XMRBTC','4h','0.014791000000000','0.016750000000000','0.001467500000000','0.001661863633291','0.09921573930092624','0.099215739300926','test'),('2018-09-09 19:59:59','2018-09-09 23:59:59','XMRBTC','4h','0.016979000000000','0.016835000000000','0.001478492040546','0.001465952853678','0.0870776865861358','0.087077686586136','test'),('2018-09-11 03:59:59','2018-09-11 07:59:59','XMRBTC','4h','0.017033000000000','0.017017000000000','0.001478492040546','0.001477103214582','0.08680162276439853','0.086801622764399','test'),('2018-09-13 11:59:59','2018-09-17 23:59:59','XMRBTC','4h','0.017343000000000','0.016976000000000','0.001478492040546','0.001447205263236','0.08525007441307732','0.085250074413077','test'),('2018-09-18 07:59:59','2018-09-18 11:59:59','XMRBTC','4h','0.017529000000000','0.017113000000000','0.001478492040546','0.001443404317980','0.08434548693855896','0.084345486938559','test'),('2018-09-18 15:59:59','2018-09-19 11:59:59','XMRBTC','4h','0.017664000000000','0.017137000000000','0.001478492040546','0.001434381685849','0.08370086280264946','0.083700862802649','test'),('2018-09-20 03:59:59','2018-09-20 11:59:59','XMRBTC','4h','0.017499000000000','0.017539000000000','0.001478492040546','0.001481871644045','0.08449008746476941','0.084490087464769','test'),('2018-09-25 19:59:59','2018-09-26 03:59:59','XMRBTC','4h','0.017796000000000','0.017685000000000','0.001478492040546','0.001469270158297','0.08308002025994606','0.083080020259946','test'),('2018-09-26 15:59:59','2018-09-26 19:59:59','XMRBTC','4h','0.017861000000000','0.017687000000000','0.001478492040546','0.001464088725219','0.08277767429292873','0.082777674292929','test'),('2018-09-26 23:59:59','2018-09-27 03:59:59','XMRBTC','4h','0.017773000000000','0.017660000000000','0.001478492040546','0.001469091849212','0.0831875339304563','0.083187533930456','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','XMRBTC','4h','0.017939000000000','0.018074000000000','0.001478492040546','0.001489618436971','0.08241775129862311','0.082417751298623','test'),('2018-10-02 23:59:59','2018-10-03 03:59:59','XMRBTC','4h','0.017832000000000','0.017672000000000','0.001478492040546','0.001465226073381','0.08291229478162854','0.082912294781629','test'),('2018-10-23 03:59:59','2018-10-25 03:59:59','XMRBTC','4h','0.016475000000000','0.016435000000000','0.001478492040546','0.001474902378536','0.08974155026075872','0.089741550260759','test'),('2018-10-30 15:59:59','2018-10-30 19:59:59','XMRBTC','4h','0.016301000000000','0.016193000000000','0.001478492040546','0.001468696497918','0.0906994687777437','0.090699468777744','test'),('2018-10-30 23:59:59','2018-11-01 07:59:59','XMRBTC','4h','0.016349000000000','0.016374000000000','0.001478492040546','0.001480752870017','0.09043317882108998','0.090433178821090','test'),('2018-11-02 03:59:59','2018-11-02 07:59:59','XMRBTC','4h','0.016325000000000','0.016317000000000','0.001478492040546','0.001477767511522','0.09056612805794793','0.090566128057948','test'),('2018-11-09 11:59:59','2018-11-09 19:59:59','XMRBTC','4h','0.016928000000000','0.016662000000000','0.001478492040546','0.001455259592366','0.08734003075059074','0.087340030750591','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','XMRBTC','4h','0.012748000000000','0.012545000000000','0.001478492040546','0.001454948434943','0.11597835272560401','0.115978352725604','test'),('2018-12-20 19:59:59','2018-12-21 19:59:59','XMRBTC','4h','0.012859000000000','0.013328000000000','0.001478492040546','0.001532416355580','0.11497721755548643','0.114977217555486','test'),('2018-12-25 23:59:59','2018-12-26 11:59:59','XMRBTC','4h','0.013265000000000','0.012810000000000','0.001478492040546','0.001427778593245','0.11145812593637391','0.111458125936374','test'),('2018-12-28 15:59:59','2018-12-28 19:59:59','XMRBTC','4h','0.012946000000000','0.012838000000000','0.001478492040546','0.001466157949678','0.11420454507539009','0.114204545075390','test'),('2019-01-02 07:59:59','2019-01-02 11:59:59','XMRBTC','4h','0.012761000000000','0.012768000000000','0.001478492040546','0.001479303061962','0.11586020222129928','0.115860202221299','test'),('2019-01-09 23:59:59','2019-01-10 03:59:59','XMRBTC','4h','0.013039000000000','0.013073000000000','0.001478492040546','0.001482347300104','0.11338998700406473','0.113389987004065','test'),('2019-01-16 23:59:59','2019-01-17 11:59:59','XMRBTC','4h','0.012697000000000','0.012416000000000','0.001478492040546','0.001445771219612','0.11644420261053792','0.116444202610538','test'),('2019-01-21 23:59:59','2019-01-22 03:59:59','XMRBTC','4h','0.012487000000000','0.012578000000000','0.001478492040546','0.001489266668214','0.11840250184559943','0.118402501845599','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','XMRBTC','4h','0.012682000000000','0.012591000000000','0.001478492040546','0.001467883084885','0.11658193033795931','0.116581930337959','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','XMRBTC','4h','0.012728000000000','0.012757000000000','0.001478492040546','0.001481860697772','0.11616059400895663','0.116160594008957','test'),('2019-02-01 03:59:59','2019-02-01 07:59:59','XMRBTC','4h','0.012743000000000','0.012612000000000','0.001478492040546','0.001463292914962','0.11602385941662088','0.116023859416621','test'),('2019-02-06 19:59:59','2019-02-11 07:59:59','XMRBTC','4h','0.012592000000000','0.013032000000000','0.001478492040546','0.001530154723030','0.11741518746394536','0.117415187463945','test'),('2019-02-15 11:59:59','2019-02-15 15:59:59','XMRBTC','4h','0.013197000000000','0.013078000000000','0.001478492040546','0.001465160180818','0.11203243468561036','0.112032434685610','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','XMRBTC','4h','0.013169000000000','0.013184000000000','0.001478492040546','0.001480176100126','0.11227063866246488','0.112270638662465','test'),('2019-02-18 19:59:59','2019-02-18 23:59:59','XMRBTC','4h','0.013206000000000','0.013092000000000','0.001478492040546','0.001465729047011','0.11195608363970921','0.111956083639709','test'),('2019-02-23 23:59:59','2019-02-24 15:59:59','XMRBTC','4h','0.013038000000000','0.012858000000000','0.001478492040546','0.001458080277446','0.11339868388909342','0.113398683889093','test'),('2019-03-03 19:59:59','2019-03-03 23:59:59','XMRBTC','4h','0.012780000000000','0.012834000000000','0.001478492040546','0.001484739190013','0.1156879530943662','0.115687953094366','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','XMRBTC','4h','0.012780000000000','0.012741000000000','0.001478492040546','0.001473980210375','0.1156879530943662','0.115687953094366','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','XMRBTC','4h','0.012764000000000','0.012712000000000','0.001478492040546','0.001472468726059','0.11583297089830775','0.115832970898308','test'),('2019-03-09 11:59:59','2019-03-09 15:59:59','XMRBTC','4h','0.012776000000000','0.012643000000000','0.001478492040546','0.001463100725471','0.11572417349295555','0.115724173492956','test'),('2019-03-12 11:59:59','2019-03-12 19:59:59','XMRBTC','4h','0.012788000000000','0.012771000000000','0.001478492040546','0.001476526575681','0.11561558027416327','0.115615580274163','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','XMRBTC','4h','0.012993000000000','0.013015000000000','0.001478492040546','0.001480995451990','0.11379142927314709','0.113791429273147','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','XMRBTC','4h','0.013103000000000','0.013231000000000','0.001478492040546','0.001492935067425','0.11283614748881936','0.112836147488819','test'),('2019-03-27 03:59:59','2019-03-27 07:59:59','XMRBTC','4h','0.013131000000000','0.013109000000000','0.001478492040546','0.001476014938658','0.11259554036600411','0.112595540366004','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','XMRBTC','4h','0.013206000000000','0.013066000000000','0.001478492040546','0.001462818188836','0.11195608363970921','0.111956083639709','test'),('2019-03-30 15:59:59','2019-03-30 19:59:59','XMRBTC','4h','0.013180000000000','0.013123000000000','0.001478492040546','0.001472097955090','0.1121769378259484','0.112176937825948','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','XMRBTC','4h','0.013119000000000','0.013630000000000','0.001478492040546','0.001536080990368','0.1126985319419163','0.112698531941916','test'),('2019-04-05 11:59:59','2019-04-06 19:59:59','XMRBTC','4h','0.013577000000000','0.013378000000000','0.001478492040546','0.001456821574606','0.10889681376931575','0.108896813769316','test'),('2019-04-07 07:59:59','2019-04-07 15:59:59','XMRBTC','4h','0.013500000000000','0.013390000000000','0.001478492040546','0.001466445068364','0.10951792892933333','0.109517928929333','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','XMRBTC','4h','0.013472000000000','0.013442000000000','0.001478492040546','0.001475199674066','0.10974554932793944','0.109745549327939','test'),('2019-04-12 15:59:59','2019-04-12 19:59:59','XMRBTC','4h','0.013378000000000','0.013199000000000','0.001478492040546','0.001458709556224','0.11051667218911647','0.110516672189116','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','XMRBTC','4h','0.013146000000000','0.013052000000000','0.001478492040546','0.001467920136407','0.11246706530853492','0.112467065308535','test'),('2019-04-19 07:59:59','2019-04-19 15:59:59','XMRBTC','4h','0.013196000000000','0.013077000000000','0.001478492040546','0.001465159170523','0.11204092456395878','0.112040924563959','test'),('2019-04-20 03:59:59','2019-04-20 07:59:59','XMRBTC','4h','0.013164000000000','0.013150000000000','0.001478492040546','0.001476919654602','0.11231328171877848','0.112313281718778','test'),('2019-04-20 23:59:59','2019-04-21 03:59:59','XMRBTC','4h','0.013084000000000','0.013145000000000','0.001478492040546','0.001485385040735','0.11300000309889942','0.113000003098899','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 10:15:24
