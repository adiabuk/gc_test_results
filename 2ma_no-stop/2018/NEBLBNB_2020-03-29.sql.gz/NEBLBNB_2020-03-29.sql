-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-04 00:22:27','NEBLBNB','4h','0.281710000000000','0.276870000000000','0.711908500000000','0.699677350449043','2.5270970146604665','2.527097014660467','test'),('2018-07-07 23:59:59','2018-07-09 07:59:59','NEBLBNB','4h','0.295270000000000','0.292200000000000','0.711908500000000','0.704506599722288','2.4110424357367837','2.411042435736784','test'),('2018-07-10 15:59:59','2018-07-10 19:59:59','NEBLBNB','4h','0.295640000000000','0.288700000000000','0.711908500000000','0.695196806758219','2.408024962792586','2.408024962792586','test'),('2018-07-11 07:59:59','2018-07-11 11:59:59','NEBLBNB','4h','0.292830000000000','0.289520000000000','0.711908500000000','0.703861451763822','2.4311323976368544','2.431132397636854','test'),('2018-07-11 19:59:59','2018-07-11 23:59:59','NEBLBNB','4h','0.293450000000000','0.289420000000000','0.711908500000000','0.702131736479809','2.4259959107173286','2.425995910717329','test'),('2018-07-12 15:59:59','2018-07-12 19:59:59','NEBLBNB','4h','0.291860000000000','0.291460000000000','0.711908500000000','0.710932815082574','2.4392122935654084','2.439212293565408','test'),('2018-07-14 07:59:59','2018-07-14 11:59:59','NEBLBNB','4h','0.291880000000000','0.292100000000000','0.711908500000000','0.712445089934220','2.4390451555433743','2.439045155543374','test'),('2018-07-16 23:59:59','2018-07-17 15:59:59','NEBLBNB','4h','0.297340000000000','0.305600000000000','0.711908500000000','0.731685066254120','2.3942574157530103','2.394257415753010','test'),('2018-07-20 11:59:59','2018-07-20 19:59:59','NEBLBNB','4h','0.307910000000000','0.310410000000000','0.711908500000000','0.717688667094281','2.312066837712319','2.312066837712319','test'),('2018-07-21 19:59:59','2018-07-21 23:59:59','NEBLBNB','4h','0.305890000000000','0.306970000000000','0.711908500000000','0.714422021788878','2.3273349897021807','2.327334989702181','test'),('2018-08-16 07:59:59','2018-08-16 11:59:59','NEBLBNB','4h','0.187520000000000','0.180930000000000','0.711908500000000','0.686889957897824','3.796440379692833','3.796440379692833','test'),('2018-08-17 07:59:59','2018-08-20 23:59:59','NEBLBNB','4h','0.189490000000000','0.185000000000000','0.711908500000000','0.695039698664837','3.7569713441342554','3.756971344134255','test'),('2018-08-21 15:59:59','2018-08-22 19:59:59','NEBLBNB','4h','0.195800000000000','0.191900000000000','0.711908500000000','0.697728504341165','3.6358963227783456','3.635896322778346','test'),('2018-08-26 11:59:59','2018-08-26 15:59:59','NEBLBNB','4h','0.195470000000000','0.195120000000000','0.711908500000000','0.710633787895841','3.6420345833120176','3.642034583312018','test'),('2018-08-27 07:59:59','2018-08-27 11:59:59','NEBLBNB','4h','0.193000000000000','0.190110000000000','0.711908500000000','0.701248315725389','3.6886450777202073','3.688645077720207','test'),('2018-08-28 07:59:59','2018-08-30 23:59:59','NEBLBNB','4h','0.192900000000000','0.200560000000000','0.711908500000000','0.740178168792120','3.690557283566615','3.690557283566615','test'),('2018-09-17 07:59:59','2018-09-17 15:59:59','NEBLBNB','4h','0.191740000000000','0.179220000000000','0.711908500000000','0.665423184364243','3.7128846354438307','3.712884635443831','test'),('2018-09-18 19:59:59','2018-09-19 03:59:59','NEBLBNB','4h','0.189420000000000','0.181160000000000','0.711908500000000','0.680864448632668','3.7583597297011933','3.758359729701193','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','NEBLBNB','4h','0.184970000000000','0.179420000000000','0.711908500000000','0.690547781099638','3.8487781802454455','3.848778180245445','test'),('2018-09-21 19:59:59','2018-09-24 15:59:59','NEBLBNB','4h','0.189860000000000','0.191300000000000','0.711908500000000','0.717307995628358','3.749649741915096','3.749649741915096','test'),('2018-09-26 15:59:59','2018-09-26 19:59:59','NEBLBNB','4h','0.187600000000000','0.180030000000000','0.711908500000000','0.683181701785714','3.7948214285714292','3.794821428571429','test'),('2018-09-26 23:59:59','2018-09-27 11:59:59','NEBLBNB','4h','0.187440000000000','0.180380000000000','0.711908500000000','0.685094191367905','3.7980607127614174','3.798060712761417','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','NEBLBNB','4h','0.187810000000000','0.193140000000000','0.711908500000000','0.732112282040360','3.79057824396997','3.790578243969970','test'),('2018-09-28 11:59:59','2018-09-29 03:59:59','NEBLBNB','4h','0.187060000000000','0.183160000000000','0.711908500000000','0.697065972736021','3.8057762215331983','3.805776221533198','test'),('2018-09-29 15:59:59','2018-10-01 23:59:59','NEBLBNB','4h','0.187620000000000','0.192630000000000','0.711908500000000','0.730918528701631','3.794416906513165','3.794416906513165','test'),('2018-10-04 07:59:59','2018-10-04 11:59:59','NEBLBNB','4h','0.191150000000000','0.192610000000000','0.711908500000000','0.717346043342925','3.724344755427675','3.724344755427675','test'),('2018-10-14 15:59:59','2018-10-14 19:59:59','NEBLBNB','4h','0.194040000000000','0.196120000000000','0.711908500000000','0.719539759946403','3.6688749742321174','3.668874974232117','test'),('2018-10-16 19:59:59','2018-10-17 03:59:59','NEBLBNB','4h','0.199060000000000','0.191710000000000','0.711908500000000','0.685622317567568','3.576351351351352','3.576351351351352','test'),('2018-11-08 07:59:59','2018-11-08 15:59:59','NEBLBNB','4h','0.253290000000000','0.253230000000000','0.711908500000000','0.711739861246003','2.8106458999565715','2.810645899956572','test'),('2018-11-26 19:59:59','2018-11-26 23:59:59','NEBLBNB','4h','0.221980000000000','0.185190000000000','0.711908500000000','0.593919880687449','3.2070839715289665','3.207083971528967','test'),('2018-11-27 15:59:59','2018-11-28 11:59:59','NEBLBNB','4h','0.198370000000000','0.200530000000000','0.711908500000000','0.719660288879367','3.588791147855019','3.588791147855019','test'),('2018-12-01 03:59:59','2018-12-03 19:59:59','NEBLBNB','4h','0.202970000000000','0.200620000000000','0.711908500000000','0.703665976597527','3.507456767009903','3.507456767009903','test'),('2018-12-03 23:59:59','2018-12-04 03:59:59','NEBLBNB','4h','0.212000000000000','0.207390000000000','0.711908500000000','0.696427848183962','3.3580589622641512','3.358058962264151','test'),('2018-12-07 11:59:59','2018-12-08 07:59:59','NEBLBNB','4h','0.202900000000000','0.197150000000000','0.711908500000000','0.691733665722031','3.5086668309512077','3.508666830951208','test'),('2018-12-14 07:59:59','2018-12-15 15:59:59','NEBLBNB','4h','0.195730000000000','0.196690000000000','0.711908500000000','0.715400208782507','3.637196648444286','3.637196648444286','test'),('2018-12-29 03:59:59','2018-12-29 15:59:59','NEBLBNB','4h','0.221070000000000','0.213660000000000','0.711908500000000','0.688046184964039','3.2202854299543135','3.220285429954314','test'),('2019-01-01 19:59:59','2019-01-02 03:59:59','NEBLBNB','4h','0.219530000000000','0.215500000000000','0.711908500000000','0.698839710973443','3.242875688971895','3.242875688971895','test'),('2019-01-07 19:59:59','2019-01-08 07:59:59','NEBLBNB','4h','0.220430000000000','0.217240000000000','0.711908500000000','0.701605963525836','3.229635258358663','3.229635258358663','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','NEBLBNB','4h','0.116110000000000','0.117410000000000','0.711908500000000','0.719879226466282','6.131328050986134','6.131328050986134','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','NEBLBNB','4h','0.119480000000000','0.112450000000000','0.711908500000000','0.670021014604955','5.958390525610981','5.958390525610981','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','NEBLBNB','4h','0.092670000000000','0.090630000000000','0.711908500000000','0.696236833441243','7.6821894895867056','7.682189489586706','test'),('2019-03-15 11:59:59','2019-03-18 11:59:59','NEBLBNB','4h','0.091900000000000','0.095420000000000','0.711908500000000','0.739176377257889','7.746556039173015','7.746556039173015','test'),('2019-03-23 23:59:59','2019-03-24 07:59:59','NEBLBNB','4h','0.097840000000000','0.095870000000000','0.711908500000000','0.697574283473017','7.276252044153721','7.276252044153721','test'),('2019-03-28 15:59:59','2019-03-28 19:59:59','NEBLBNB','4h','0.090360000000000','0.089220000000000','0.711908500000000','0.702926918658699','7.878580123948651','7.878580123948651','test'),('2019-03-28 23:59:59','2019-03-30 23:59:59','NEBLBNB','4h','0.093820000000000','0.090370000000000','0.711908500000000','0.685729813952249','7.588024941377106','7.588024941377106','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','NEBLBNB','4h','0.094510000000000','0.087340000000000','0.711908500000000','0.657899570310020','7.532626177124115','7.532626177124115','test'),('2019-04-06 07:59:59','2019-04-06 11:59:59','NEBLBNB','4h','0.088770000000000','0.087500000000000','0.711908500000000','0.701723484848485','8.01969696969697','8.019696969696970','test'),('2019-04-06 15:59:59','2019-04-06 23:59:59','NEBLBNB','4h','0.090200000000000','0.090810000000000','0.711908500000000','0.716722958813747','7.892555432372506','7.892555432372506','test'),('2019-05-07 15:59:59','2019-05-07 23:59:59','NEBLBNB','4h','0.061050000000000','0.061800000000000','0.711908500000000','0.720654304668305','11.661072891072893','11.661072891072893','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','NEBLBNB','4h','0.062530000000000','0.060360000000000','0.711908500000000','0.687202895570126','11.385071165840397','11.385071165840397','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','NEBLBNB','4h','0.063040000000000','0.061000000000000','0.711908500000000','0.688870851840102','11.29296478426396','11.292964784263960','test'),('2019-05-12 03:59:59','2019-05-12 07:59:59','NEBLBNB','4h','0.061050000000000','0.061000000000000','0.711908500000000','0.711325446355446','11.661072891072893','11.661072891072893','test'),('2019-06-01 07:59:59','2019-06-01 11:59:59','NEBLBNB','4h','0.042280000000000','0.042790000000000','0.711908500000000','0.720495854186377','16.837949385052035','16.837949385052035','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','NEBLBNB','4h','0.042300000000000','0.042630000000000','0.711908500000000','0.717462396099291','16.829988179669034','16.829988179669034','test'),('2019-06-08 19:59:59','2019-06-08 23:59:59','NEBLBNB','4h','0.042000000000000','0.042100000000000','0.711908500000000','0.713603520238095','16.95020238095238','16.950202380952380','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:16:19
