-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-28 15:59:59','2018-11-28 19:59:59','NXSBNB','4h','0.055200000000000','0.067100000000000','0.711908500000000','0.865381528079710','12.89689311594203','12.896893115942030','test'),('2018-11-30 23:59:59','2018-12-01 07:59:59','NXSBNB','4h','0.056900000000000','0.056900000000000','0.750276757019928','0.750276757019928','13.185883251668324','13.185883251668324','test'),('2018-12-07 15:59:59','2018-12-08 03:59:59','NXSBNB','4h','0.053700000000000','0.054800000000000','0.750276757019928','0.765645554649759','13.971634208937207','13.971634208937207','test'),('2018-12-09 03:59:59','2018-12-09 19:59:59','NXSBNB','4h','0.052600000000000','0.054700000000000','0.754118956427385','0.784226367235322','14.336862289494018','14.336862289494018','test'),('2018-12-13 23:59:59','2018-12-14 03:59:59','NXSBNB','4h','0.053200000000000','0.055000000000000','0.761645809129370','0.787415780114950','14.31665054754454','14.316650547544540','test'),('2018-12-15 11:59:59','2018-12-15 15:59:59','NXSBNB','4h','0.053000000000000','0.051800000000000','0.768088301875764','0.750697623342728','14.492232110863482','14.492232110863482','test'),('2018-12-17 03:59:59','2018-12-17 11:59:59','NXSBNB','4h','0.052000000000000','0.052500000000000','0.768088301875764','0.775473766316877','14.770928882226233','14.770928882226233','test'),('2018-12-24 23:59:59','2018-12-25 11:59:59','NXSBNB','4h','0.056900000000000','0.055800000000000','0.768088301875764','0.753239494633878','13.49891567444225','13.498915674442250','test'),('2019-01-02 07:59:59','2019-01-03 19:59:59','NXSBNB','4h','0.058300000000000','0.057800000000000','0.768088301875764','0.761500923643553','13.174756464421339','13.174756464421339','test'),('2019-01-04 23:59:59','2019-01-08 07:59:59','NXSBNB','4h','0.057900000000000','0.059800000000000','0.768088301875764','0.793293272058216','13.265773780237721','13.265773780237721','test'),('2019-01-09 15:59:59','2019-01-10 07:59:59','NXSBNB','4h','0.060200000000000','0.059800000000000','0.768088301875764','0.762984725119115','12.758941891623989','12.758941891623989','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','NXSBNB','4h','0.059000000000000','0.057600000000000','0.768088301875764','0.749862477763458','13.018445794504476','13.018445794504476','test'),('2019-01-16 19:59:59','2019-01-16 23:59:59','NXSBNB','4h','0.057500000000000','0.055900000000000','0.768088301875764','0.746715409997482','13.358057423926331','13.358057423926331','test'),('2019-01-20 07:59:59','2019-01-20 15:59:59','NXSBNB','4h','0.056600000000000','0.055400000000000','0.768088301875764','0.751803744238822','13.570464697451662','13.570464697451662','test'),('2019-01-21 19:59:59','2019-01-21 23:59:59','NXSBNB','4h','0.058600000000000','0.055800000000000','0.768088301875764','0.731387836939721','13.107308905729761','13.107308905729761','test'),('2019-01-22 15:59:59','2019-01-24 03:59:59','NXSBNB','4h','0.056500000000000','0.057100000000000','0.768088301875764','0.776244991807188','13.594483219040072','13.594483219040072','test'),('2019-01-29 07:59:59','2019-01-29 11:59:59','NXSBNB','4h','0.055800000000000','0.055200000000000','0.768088301875764','0.759829287877100','13.765023331106882','13.765023331106882','test'),('2019-01-30 03:59:59','2019-01-31 07:59:59','NXSBNB','4h','0.055100000000000','0.054800000000000','0.768088301875764','0.763906332900034','13.939896585767041','13.939896585767041','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','NXSBNB','4h','0.031100000000000','0.030600000000000','0.768088301875764','0.755739615350430','24.697373050667654','24.697373050667654','test'),('2019-03-10 07:59:59','2019-03-11 15:59:59','NXSBNB','4h','0.029200000000000','0.028400000000000','0.768088301875764','0.747044786755880','26.304393899854933','26.304393899854933','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','NXSBNB','4h','0.026600000000000','0.025900000000000','0.768088301875764','0.747875451826402','28.875500070517447','28.875500070517447','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','NXSBNB','4h','0.026800000000000','0.025900000000000','0.768088301875764','0.742294291738145','28.660011264021044','28.660011264021044','test'),('2019-03-15 07:59:59','2019-03-16 11:59:59','NXSBNB','4h','0.027500000000000','0.026200000000000','0.768088301875764','0.731778673059819','27.930483704573238','27.930483704573238','test'),('2019-03-17 07:59:59','2019-03-17 11:59:59','NXSBNB','4h','0.027100000000000','0.026400000000000','0.768088301875764','0.748248382639121','28.34274176663336','28.342741766633360','test'),('2019-03-19 23:59:59','2019-03-23 07:59:59','NXSBNB','4h','0.026800000000000','0.026700000000000','0.768088301875764','0.765222300749362','28.660011264021044','28.660011264021044','test'),('2019-03-23 15:59:59','2019-03-23 19:59:59','NXSBNB','4h','0.027300000000000','0.027000000000000','0.768088301875764','0.759647771085920','28.13510263281187','28.135102632811869','test'),('2019-03-23 23:59:59','2019-03-24 11:59:59','NXSBNB','4h','0.027200000000000','0.024100000000000','0.768088301875764','0.680548826294335','28.238540510138385','28.238540510138385','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','NXSBNB','4h','0.022900000000000','0.022500000000000','0.768088301875764','0.754671912323349','33.54097388103773','33.540973881037729','test'),('2019-04-09 07:59:59','2019-04-09 11:59:59','NXSBNB','4h','0.022500000000000','0.021800000000000','0.768088301875764','0.744192221372962','34.13725786114507','34.137257861145073','test'),('2019-04-09 19:59:59','2019-04-09 23:59:59','NXSBNB','4h','0.022600000000000','0.022100000000000','0.768088301875764','0.751095197851964','33.98620804760018','33.986208047600179','test'),('2019-04-10 11:59:59','2019-04-10 15:59:59','NXSBNB','4h','0.022500000000000','0.022400000000000','0.768088301875764','0.764674576089650','34.13725786114507','34.137257861145073','test'),('2019-05-06 23:59:59','2019-05-07 07:59:59','NXSBNB','4h','0.015300000000000','0.015000000000000','0.768088301875764','0.753027746937024','50.20184979580157','50.201849795801571','test'),('2019-05-11 07:59:59','2019-05-11 11:59:59','NXSBNB','4h','0.015100000000000','0.014300000000000','0.768088301875764','0.727394881908836','50.86677495865987','50.866774958659867','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','NXSBNB','4h','0.014300000000000','0.013900000000000','0.768088301875764','0.746603314410708','53.712468662640845','53.712468662640845','test'),('2019-05-29 11:59:59','2019-05-29 15:59:59','NXSBNB','4h','0.012000000000000','0.011300000000000','0.768088301875764','0.723283150933011','64.007358489647','64.007358489647004','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','NXSBNB','4h','0.011800000000000','0.011400000000000','0.768088301875764','0.742051410286755','65.09222897252238','65.092228972522378','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','NXSBNB','4h','0.011400000000000','0.011600000000000','0.768088301875764','0.781563535242005','67.37616683120737','67.376166831207371','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','NXSBNB','4h','0.011400000000000','0.011200000000000','0.768088301875764','0.754613068509522','67.37616683120737','67.376166831207371','test'),('2019-06-04 23:59:59','2019-06-05 03:59:59','NXSBNB','4h','0.011600000000000','0.011300000000000','0.768088301875764','0.748223949241046','66.21450878239345','66.214508782393452','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','NXSBNB','4h','0.011600000000000','0.011600000000000','0.768088301875764','0.768088301875764','66.21450878239345','66.214508782393452','test'),('2019-06-11 15:59:59','2019-06-11 23:59:59','NXSBNB','4h','0.011700000000000','0.011300000000000','0.768088301875764','0.741828872751806','65.64857280989436','65.648572809894361','test'),('2019-06-26 15:59:59','2019-06-26 19:59:59','NXSBNB','4h','0.010400000000000','0.010000000000000','0.768088301875764','0.738546444111312','73.85464441113116','73.854644411131162','test'),('2019-06-26 23:59:59','2019-06-27 03:59:59','NXSBNB','4h','0.010400000000000','0.010100000000000','0.768088301875764','0.745931908552425','73.85464441113116','73.854644411131162','test'),('2019-06-27 11:59:59','2019-06-27 15:59:59','NXSBNB','4h','0.010400000000000','0.009500000000000','0.768088301875764','0.701619121905746','73.85464441113116','73.854644411131162','test'),('2019-07-02 15:59:59','2019-07-02 19:59:59','NXSBNB','4h','0.010100000000000','0.009600000000000','0.768088301875764','0.730064128515578','76.04834672037268','76.048346720372678','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','NXSBNB','4h','0.009900000000000','0.009600000000000','0.768088301875764','0.744812898788620','77.58467695714788','77.584676957147877','test'),('2019-07-16 19:59:59','2019-07-16 23:59:59','NXSBNB','4h','0.009200000000000','0.008400000000000','0.512058867917176','0.467532009837422','55.658572599693045','55.658572599693045','test'),('2019-07-24 03:59:59','2019-07-24 07:59:59','NXSBNB','4h','0.008300000000000','0.008200000000000','0.563458150065662','0.556669497655232','67.88652410429661','67.886524104296612','test'),('2019-07-24 11:59:59','2019-07-27 15:59:59','NXSBNB','4h','0.008300000000000','0.008500000000000','0.563458150065662','0.577035454886521','67.88652410429663','67.886524104296626','test'),('2019-08-09 11:59:59','2019-08-09 15:59:59','NXSBNB','4h','0.009190000000000','0.008420000000000','0.565155313168269','0.517802800530666','61.49676965922405','61.496769659224050','test'),('2019-08-17 19:59:59','2019-08-19 07:59:59','NXSBNB','4h','0.008520000000000','0.007980000000000','0.565155313168269','0.529335610220984','66.33278323571231','66.332783235712313','test'),('2019-08-21 19:59:59','2019-08-22 03:59:59','NXSBNB','4h','0.008210000000000','0.008210000000000','0.565155313168269','0.565155313168269','68.83743156738964','68.837431567389643','test'),('2019-08-22 11:59:59','2019-08-22 15:59:59','NXSBNB','4h','0.008200000000000','0.008210000000000','0.565155313168269','0.565844526964816','68.92137965466694','68.921379654666936','test'),('2019-09-07 07:59:59','2019-09-07 11:59:59','NXSBNB','4h','0.009890000000000','0.009490000000000','0.565155313168269','0.542297666528501','57.14411659942052','57.144116599420521','test'),('2019-09-08 19:59:59','2019-09-08 23:59:59','NXSBNB','4h','0.009900000000000','0.009630000000000','0.565155313168269','0.549741986445498','57.086395269522114','57.086395269522114','test'),('2019-09-09 19:59:59','2019-09-10 07:59:59','NXSBNB','4h','0.010230000000000','0.009640000000000','0.565155313168269','0.532560822965993','55.24489864792463','55.244898647924629','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','NXSBNB','4h','0.009920000000000','0.010000000000000','0.565155313168269','0.569713017306723','56.97130173067227','56.971301730672273','test'),('2019-09-19 19:59:59','2019-09-29 15:59:59','NXSBNB','4h','0.010790000000000','0.011670000000000','0.565155313168269','0.611247683473003','52.377693528106484','52.377693528106484','test'),('2019-10-17 23:59:59','2019-10-18 03:59:59','NXSBNB','4h','0.011290000000000','0.011360000000000','0.565155313168269','0.568659376226000','50.05804368186616','50.058043681866160','test'),('2019-11-21 03:59:59','2019-11-21 03:59:59','NXSBNB','4h','0.013700000000000','0.013700000000000','0.565155313168269','0.565155313168269','41.25221264001963','41.252212640019629','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:56:13
