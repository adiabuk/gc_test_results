-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-01 11:59:59','2018-05-04 03:59:59','ZECBTC','4h','0.031213000000000','0.031274000000000','0.001467500000000','0.001470367955660','0.04701566654919424','0.047015666549194','test'),('2018-05-06 03:59:59','2018-05-06 07:59:59','ZECBTC','4h','0.031310000000000','0.030596000000000','0.001468216988915','0.001434735451704','0.046892909259501764','0.046892909259502','test'),('2018-05-14 15:59:59','2018-05-22 03:59:59','ZECBTC','4h','0.037067000000000','0.038621000000000','0.001468216988915','0.001529770640432','0.03960981436088704','0.039609814360887','test'),('2018-05-24 23:59:59','2018-05-25 03:59:59','ZECBTC','4h','0.039030000000000','0.038550000000000','0.001475235017492','0.001457092234802','0.03779746393777863','0.037797463937779','test'),('2018-07-02 15:59:59','2018-07-04 11:59:59','ZECBTC','4h','0.027711000000000','0.027382000000000','0.001475235017492','0.001457720228392','0.05323644103395763','0.053236441033958','test'),('2018-07-13 23:59:59','2018-07-17 19:59:59','ZECBTC','4h','0.028251000000000','0.028397000000000','0.001475235017492','0.001482858971071','0.05221886012856182','0.052218860128562','test'),('2018-07-24 23:59:59','2018-07-25 03:59:59','ZECBTC','4h','0.026650000000000','0.026111000000000','0.001475235017492','0.001445398181679','0.055355910600075046','0.055355910600075','test'),('2018-07-25 19:59:59','2018-07-29 15:59:59','ZECBTC','4h','0.026905000000000','0.026634000000000','0.001475235017492','0.001460375746362','0.0548312587805984','0.054831258780598','test'),('2018-07-31 23:59:59','2018-08-01 07:59:59','ZECBTC','4h','0.027042000000000','0.026207000000000','0.001475235017492','0.001429682867518','0.054553473023149175','0.054553473023149','test'),('2018-08-01 11:59:59','2018-08-01 15:59:59','ZECBTC','4h','0.026790000000000','0.026600000000000','0.001475235017492','0.001464772357793','0.0550666299922359','0.055066629992236','test'),('2018-08-06 07:59:59','2018-08-06 11:59:59','ZECBTC','4h','0.025835000000000','0.026325000000000','0.001475235017492','0.001503215089432','0.05710218763274627','0.057102187632746','test'),('2018-08-09 19:59:59','2018-08-10 11:59:59','ZECBTC','4h','0.026686000000000','0.026017000000000','0.001475235017492','0.001438251871771','0.05528123426111069','0.055281234261111','test'),('2018-08-10 23:59:59','2018-08-11 03:59:59','ZECBTC','4h','0.026033000000000','0.025824000000000','0.001475235017492','0.001463391429790','0.0566678837434026','0.056667883743403','test'),('2018-08-27 23:59:59','2018-08-28 03:59:59','ZECBTC','4h','0.022007000000000','0.021544000000000','0.001475235017492','0.001444197901434','0.06703480790166765','0.067034807901668','test'),('2018-08-30 11:59:59','2018-08-30 23:59:59','ZECBTC','4h','0.021462000000000','0.021644000000000','0.001475235017492','0.001487745164411','0.06873707098555587','0.068737070985556','test'),('2018-09-01 03:59:59','2018-09-02 11:59:59','ZECBTC','4h','0.021497000000000','0.020965000000000','0.001475235017492','0.001438726433536','0.0686251578123459','0.068625157812346','test'),('2018-09-03 19:59:59','2018-09-04 03:59:59','ZECBTC','4h','0.021889000000000','0.021450000000000','0.001475235017492','0.001445648093801','0.0673961815291699','0.067396181529170','test'),('2018-09-20 23:59:59','2018-09-21 03:59:59','ZECBTC','4h','0.018472000000000','0.018260000000000','0.001475235017492','0.001458303996286','0.07986330757319186','0.079863307573192','test'),('2018-09-22 23:59:59','2018-09-23 03:59:59','ZECBTC','4h','0.018415000000000','0.018917000000000','0.001475235017492','0.001515450492853','0.08011050868813466','0.080110508688135','test'),('2018-10-05 07:59:59','2018-10-05 11:59:59','ZECBTC','4h','0.019720000000000','0.019348000000000','0.001475235017492','0.001447406040489','0.07480907796612575','0.074809077966126','test'),('2018-10-17 19:59:59','2018-10-17 23:59:59','ZECBTC','4h','0.018182000000000','0.018153000000000','0.001475235017492','0.001472882041169','0.08113711459091408','0.081137114590914','test'),('2018-10-27 03:59:59','2018-10-27 07:59:59','ZECBTC','4h','0.018813000000000','0.018786000000000','0.001475235017492','0.001473117792941','0.07841572409993089','0.078415724099931','test'),('2018-10-28 11:59:59','2018-10-28 15:59:59','ZECBTC','4h','0.018776000000000','0.018913000000000','0.001475235017492','0.001485999141767','0.0785702501859821','0.078570250185982','test'),('2018-11-04 11:59:59','2018-11-05 07:59:59','ZECBTC','4h','0.018526000000000','0.018553000000000','0.001475235017492','0.001477385041538','0.07963052021440137','0.079630520214401','test'),('2018-11-12 19:59:59','2018-11-13 19:59:59','ZECBTC','4h','0.021233000000000','0.019950000000000','0.001475235017492','0.001386094221211','0.06947840707822729','0.069478407078227','test'),('2018-11-17 23:59:59','2018-11-18 11:59:59','ZECBTC','4h','0.019986000000000','0.019644000000000','0.001475235017492','0.001449990827760','0.07381342026878815','0.073813420268788','test'),('2018-11-19 23:59:59','2018-11-20 07:59:59','ZECBTC','4h','0.020281000000000','0.019100000000000','0.001475235017492','0.001389329364139','0.07273975728474927','0.072739757284749','test'),('2018-11-27 19:59:59','2018-11-28 11:59:59','ZECBTC','4h','0.018915000000000','0.018764000000000','0.001475235017492','0.001463458095068','0.07799286373206449','0.077992863732064','test'),('2018-12-02 19:59:59','2018-12-02 23:59:59','ZECBTC','4h','0.019284000000000','0.019111000000000','0.001475235017492','0.001462000436595','0.07650046761522505','0.076500467615225','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','ZECBTC','4h','0.018989000000000','0.018729000000000','0.001475235017492','0.001455035896709','0.07768892608836694','0.077688926088367','test'),('2018-12-23 03:59:59','2018-12-25 03:59:59','ZECBTC','4h','0.016286000000000','0.016036000000000','0.001475235017492','0.001452589263202','0.0905830171614884','0.090583017161488','test'),('2018-12-25 19:59:59','2018-12-25 23:59:59','ZECBTC','4h','0.016099000000000','0.016010000000000','0.001475235017492','0.001467079485064','0.0916351958191192','0.091635195819119','test'),('2018-12-26 03:59:59','2018-12-26 07:59:59','ZECBTC','4h','0.016127000000000','0.015997000000000','0.001475235017492','0.001463343124873','0.09147609707273517','0.091476097072735','test'),('2018-12-28 23:59:59','2018-12-29 03:59:59','ZECBTC','4h','0.015957000000000','0.015827000000000','0.001475235017492','0.001463216433029','0.09245064971435733','0.092450649714357','test'),('2019-01-02 19:59:59','2019-01-02 23:59:59','ZECBTC','4h','0.015683000000000','0.015519000000000','0.001475235017492','0.001459808215039','0.09406586861518842','0.094065868615188','test'),('2019-01-11 03:59:59','2019-01-11 23:59:59','ZECBTC','4h','0.015872000000000','0.015297000000000','0.001475235017492','0.001421791208580','0.09294575463029232','0.092945754630292','test'),('2019-01-12 19:59:59','2019-01-13 03:59:59','ZECBTC','4h','0.015471000000000','0.015275000000000','0.001475235017492','0.001456545465205','0.09535485860590782','0.095354858605908','test'),('2019-01-14 15:59:59','2019-01-14 19:59:59','ZECBTC','4h','0.015374000000000','0.015219000000000','0.001475235017492','0.001460361762145','0.09595648611239754','0.095956486112398','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','ZECBTC','4h','0.014830000000000','0.014974000000000','0.001475235017492','0.001489559619145','0.09947640037033041','0.099476400370330','test'),('2019-02-11 19:59:59','2019-02-15 07:59:59','ZECBTC','4h','0.014028000000000','0.014116000000000','0.001475235017492','0.001484489414522','0.10516360261562588','0.105163602615626','test'),('2019-02-15 15:59:59','2019-02-15 19:59:59','ZECBTC','4h','0.014159000000000','0.014115000000000','0.001475235017492','0.001470650630122','0.1041906220419521','0.104190622041952','test'),('2019-02-16 23:59:59','2019-02-17 03:59:59','ZECBTC','4h','0.014186000000000','0.013949000000000','0.001475235017492','0.001450588838220','0.10399231760129704','0.103992317601297','test'),('2019-02-24 07:59:59','2019-02-24 11:59:59','ZECBTC','4h','0.013869000000000','0.014187000000000','0.001475235017492','0.001509060436452','0.10636924201398804','0.106369242013988','test'),('2019-03-12 15:59:59','2019-03-14 03:59:59','ZECBTC','4h','0.013150000000000','0.013147000000000','0.001475235017492','0.001474898461975','0.1121851724328517','0.112185172432852','test'),('2019-03-27 15:59:59','2019-03-28 07:59:59','ZECBTC','4h','0.013923000000000','0.013839000000000','0.001475235017492','0.001466334655396','0.1059566916247935','0.105956691624794','test'),('2019-03-28 19:59:59','2019-03-29 03:59:59','ZECBTC','4h','0.013970000000000','0.013832000000000','0.001475235017492','0.001460662187684','0.1056002159979957','0.105600215997996','test'),('2019-03-29 15:59:59','2019-03-30 03:59:59','ZECBTC','4h','0.013970000000000','0.013736000000000','0.001475235017492','0.001450524566948','0.1056002159979957','0.105600215997996','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','ZECBTC','4h','0.013965000000000','0.013802000000000','0.001475235017492','0.001458016019436','0.1056380248830648','0.105638024883065','test'),('2019-04-05 11:59:59','2019-04-05 23:59:59','ZECBTC','4h','0.014477000000000','0.014330000000000','0.001475235017492','0.001460255425894','0.10190198366318988','0.101901983663190','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','ZECBTC','4h','0.014147000000000','0.014108000000000','0.001475235017492','0.001471168136480','0.10427900031752314','0.104279000317523','test'),('2019-04-07 07:59:59','2019-04-07 15:59:59','ZECBTC','4h','0.014354000000000','0.014142000000000','0.001475235017492','0.001453446678095','0.10277518583614323','0.102775185836143','test'),('2019-04-12 11:59:59','2019-04-12 15:59:59','ZECBTC','4h','0.014109000000000','0.014003000000000','0.001475235017492','0.001464151672687','0.10455985665121553','0.104559856651216','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  8:07:38
