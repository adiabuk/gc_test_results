-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-25 15:59:59','2018-09-25 19:59:59','GRSETH','4h','0.002525530000000','0.002521080000000','0.072144500000000','0.072017380929943','28.566083158782515','28.566083158782515','test'),('2018-09-26 07:59:59','2018-09-26 11:59:59','GRSETH','4h','0.002537610000000','0.002514800000000','0.072144500000000','0.071496009473481','28.430097611532112','28.430097611532112','test'),('2018-09-26 23:59:59','2018-09-27 07:59:59','GRSETH','4h','0.002544100000000','0.002519430000000','0.072144500000000','0.071444918688338','28.35757242246767','28.357572422467669','test'),('2018-09-27 23:59:59','2018-09-28 03:59:59','GRSETH','4h','0.002537910000000','0.002536050000000','0.072144500000000','0.072091626269253','28.426736960727528','28.426736960727528','test'),('2018-09-28 23:59:59','2018-09-29 07:59:59','GRSETH','4h','0.002545950000000','0.002509710000000','0.072144500000000','0.071117568332057','28.33696655472417','28.336966554724171','test'),('2018-10-02 07:59:59','2018-10-02 11:59:59','GRSETH','4h','0.002483490000000','0.002487950000000','0.072144500000000','0.072274061411562','29.049643847972007','29.049643847972007','test'),('2018-10-09 15:59:59','2018-10-10 07:59:59','GRSETH','4h','0.002488200000000','0.002498910000000','0.072144500000000','0.072455032752592','28.994654770516842','28.994654770516842','test'),('2018-10-28 11:59:59','2018-10-28 15:59:59','GRSETH','4h','0.002687160000000','0.002666700000000','0.072144500000000','0.071595192749967','26.847861682966403','26.847861682966403','test'),('2018-10-28 19:59:59','2018-10-28 23:59:59','GRSETH','4h','0.002685040000000','0.002672060000000','0.072144500000000','0.071795739605369','26.869059678812977','26.869059678812977','test'),('2018-11-19 07:59:59','2018-11-19 11:59:59','GRSETH','4h','0.002263190000000','0.002198940000000','0.072144500000000','0.070096380255303','31.87735011201004','31.877350112010038','test'),('2018-11-19 15:59:59','2018-11-19 19:59:59','GRSETH','4h','0.002409300000000','0.002152740000000','0.072144500000000','0.064462022550118','29.944174656539243','29.944174656539243','test'),('2018-11-20 03:59:59','2018-11-20 07:59:59','GRSETH','4h','0.002311100000000','0.002134860000000','0.072144500000000','0.066642900467310','31.216520271732076','31.216520271732076','test'),('2018-11-21 15:59:59','2018-11-21 19:59:59','GRSETH','4h','0.002680440000000','0.002341110000000','0.072144500000000','0.063011375145498','26.91517064362567','26.915170643625672','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','GRSETH','4h','0.002312120000000','0.002213060000000','0.072144500000000','0.069053555684826','31.202748992266837','31.202748992266837','test'),('2018-11-26 07:59:59','2018-11-26 11:59:59','GRSETH','4h','0.002339990000000','0.002299930000000','0.072144500000000','0.070909405546605','30.831114662883174','30.831114662883174','test'),('2018-11-27 03:59:59','2018-11-27 11:59:59','GRSETH','4h','0.002339890000000','0.002317930000000','0.072144500000000','0.071467419786828','30.83243229382578','30.832432293825779','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','GRSETH','4h','0.002534740000000','0.002529590000000','0.072144500000000','0.071997919216567','28.4622880453222','28.462288045322200','test'),('2018-12-09 23:59:59','2018-12-10 03:59:59','GRSETH','4h','0.002564850000000','0.002498420000000','0.072144500000000','0.070275946620660','28.128155642630173','28.128155642630173','test'),('2018-12-12 23:59:59','2018-12-13 03:59:59','GRSETH','4h','0.002561800000000','0.002441870000000','0.072144500000000','0.068767074016317','28.161644156452496','28.161644156452496','test'),('2018-12-13 19:59:59','2018-12-13 23:59:59','GRSETH','4h','0.002520310000000','0.002482220000000','0.072144500000000','0.071054164285346','28.625248481337614','28.625248481337614','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','GRSETH','4h','0.001674190000000','0.001620570000000','0.072144500000000','0.069833897207008','43.092181890944275','43.092181890944275','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','GRSETH','4h','0.001686660000000','0.001680000000000','0.072144500000000','0.071859627903668','42.77358803789738','42.773588037897383','test'),('2019-01-12 11:59:59','2019-01-12 15:59:59','GRSETH','4h','0.001666260000000','0.001642950000000','0.072144500000000','0.071135240763746','43.297264532545945','43.297264532545945','test'),('2019-01-12 19:59:59','2019-01-13 15:59:59','GRSETH','4h','0.001689250000000','0.001681040000000','0.072144500000000','0.071793867266538','42.708006511765575','42.708006511765575','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','GRSETH','4h','0.001712160000000','0.001644310000000','0.072144500000000','0.069285535694678','42.136540977478745','42.136540977478745','test'),('2019-01-15 19:59:59','2019-01-20 15:59:59','GRSETH','4h','0.001705450000000','0.001759450000000','0.072144500000000','0.074428825544578','42.302324899586615','42.302324899586615','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','GRSETH','4h','0.001845510000000','0.001800000000000','0.072144500000000','0.070365427442821','39.091904134900375','39.091904134900375','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','GRSETH','4h','0.001867590000000','0.001832990000000','0.072144500000000','0.070807911294770','38.629731365021236','38.629731365021236','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','GRSETH','4h','0.001857110000000','0.001886060000000','0.072144500000000','0.073269141660968','38.847725767455884','38.847725767455884','test'),('2019-01-30 23:59:59','2019-01-31 03:59:59','GRSETH','4h','0.001854380000000','0.001840890000000','0.072144500000000','0.071619672669571','38.90491700730163','38.904917007301627','test'),('2019-02-02 07:59:59','2019-02-02 15:59:59','GRSETH','4h','0.001856400000000','0.001834530000000','0.072144500000000','0.071294575298966','38.86258349493644','38.862583494936437','test'),('2019-02-06 15:59:59','2019-02-06 19:59:59','GRSETH','4h','0.001819000000000','0.001803360000000','0.072144500000000','0.071524192149533','39.66162726772952','39.661627267729521','test'),('2019-02-06 23:59:59','2019-02-07 03:59:59','GRSETH','4h','0.001814060000000','0.001800060000000','0.072144500000000','0.071587725141396','39.76963275746117','39.769632757461167','test'),('2019-02-07 07:59:59','2019-02-07 11:59:59','GRSETH','4h','0.001836910000000','0.002700000000000','0.072144500000000','0.106042293852176','39.27492364895395','39.274923648953951','test'),('2019-02-16 11:59:59','2019-02-17 03:59:59','GRSETH','4h','0.001900970000000','0.001917190000000','0.072144500000000','0.072760071939589','37.951414277973875','37.951414277973875','test'),('2019-02-26 11:59:59','2019-02-27 07:59:59','GRSETH','4h','0.001722790000000','0.001686770000000','0.072144500000000','0.070636106701920','41.87654908607549','41.876549086075492','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','GRSETH','4h','0.001690730000000','0.001680570000000','0.072144500000000','0.071710966484891','42.670621565832505','42.670621565832505','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','GRSETH','4h','0.001730000000000','0.001681190000000','0.072144500000000','0.070109024251445','41.702023121387285','41.702023121387285','test'),('2019-03-07 07:59:59','2019-03-07 11:59:59','GRSETH','4h','0.001731840000000','0.001779440000000','0.072144500000000','0.074127407312454','41.657716648189215','41.657716648189215','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','GRSETH','4h','0.003152170000000','0.002924770000000','0.072144500000000','0.066939939554339','22.887249101412678','22.887249101412678','test'),('2019-04-15 07:59:59','2019-04-15 15:59:59','GRSETH','4h','0.002806380000000','0.002681240000000','0.072144500000000','0.068927486363215','25.70731689935077','25.707316899350769','test'),('2019-04-17 03:59:59','2019-04-17 07:59:59','GRSETH','4h','0.002738880000000','0.002709840000000','0.072144500000000','0.071379560944620','26.340876562682556','26.340876562682556','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','GRSETH','4h','0.001739340000000','0.001726800000000','0.072144500000000','0.071624364759047','41.478089390228476','41.478089390228476','test'),('2019-06-06 07:59:59','2019-06-06 11:59:59','GRSETH','4h','0.001676780000000','0.001623760000000','0.072144500000000','0.069863281599256','43.02562053459607','43.025620534596072','test'),('2019-06-07 07:59:59','2019-06-07 19:59:59','GRSETH','4h','0.001680050000000','0.001663380000000','0.072144500000000','0.071428658914913','42.94187672985923','42.941876729859231','test'),('2019-07-16 15:59:59','2019-07-16 19:59:59','GRSETH','4h','0.001188580000000','0.001141740000000','0.072144500000000','0.069301402875700','60.69805986976055','60.698059869760549','test'),('2019-07-18 07:59:59','2019-07-18 11:59:59','GRSETH','4h','0.001147150000000','0.001188580000000','0.072144500000000','0.074750041241337','62.890206163099855','62.890206163099855','test'),('2019-07-19 03:59:59','2019-07-19 07:59:59','GRSETH','4h','0.001169840000000','0.001136290000000','0.072144500000000','0.070075458101108','61.67039937085414','61.670399370854142','test'),('2019-07-29 11:59:59','2019-07-31 11:59:59','GRSETH','4h','0.001735060000000','0.001376880000000','0.072144500000000','0.057251230020864','41.580406441275805','41.580406441275805','test'),('2019-08-02 19:59:59','2019-08-02 23:59:59','GRSETH','4h','0.001320720000000','0.001325090000000','0.072144500000000','0.072383211812496','54.62512871766915','54.625128717669149','test'),('2019-08-04 07:59:59','2019-08-04 11:59:59','GRSETH','4h','0.001326020000000','0.001335510000000','0.072144500000000','0.072660820496674','54.40679627758254','54.406796277582536','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','GRSETH','4h','0.001219720000000','0.001164280000000','0.072144500000000','0.068865312088020','59.14841111074672','59.148411110746721','test'),('2019-08-17 23:59:59','2019-08-18 03:59:59','GRSETH','4h','0.001192490000000','0.001191400000000','0.072144500000000','0.072078556046592','60.49903982423333','60.499039824233328','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','GRSETH','4h','0.001201270000000','0.001152270000000','0.072144500000000','0.069201714031816','60.05685649354434','60.056856493544338','test'),('2019-08-22 07:59:59','2019-08-22 19:59:59','GRSETH','4h','0.001176040000000','0.001184800000000','0.072144500000000','0.072681884629774','61.34527737151798','61.345277371517980','test'),('2019-08-29 19:59:59','2019-08-29 23:59:59','GRSETH','4h','0.001226160000000','0.001210000000000','0.072144500000000','0.071193681901220','58.83775363737196','58.837753637371961','test'),('2019-08-30 03:59:59','2019-08-31 23:59:59','GRSETH','4h','0.001294890000000','0.001216390000000','0.072144500000000','0.067770890465599','55.71477113886122','55.714771138861217','test'),('2019-09-02 03:59:59','2019-09-02 19:59:59','GRSETH','4h','0.001242000000000','0.001213780000000','0.072144500000000','0.070505274726248','58.08735909822866','58.087359098228660','test'),('2019-09-04 07:59:59','2019-09-04 15:59:59','GRSETH','4h','0.001239130000000','0.001239300000000','0.072144500000000','0.072154397722596','58.22189762171847','58.221897621718469','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','GRSETH','4h','0.001270410000000','0.001238220000000','0.072144500000000','0.070316482702435','56.78835966341575','56.788359663415747','test'),('2019-09-10 11:59:59','2019-09-10 23:59:59','GRSETH','4h','0.001269840000000','0.001250640000000','0.072144500000000','0.071053674069174','56.813850563850565','56.813850563850565','test'),('2019-09-11 11:59:59','2019-09-11 15:59:59','GRSETH','4h','0.001249040000000','0.001241630000000','0.072144500000000','0.071716498699001','57.75995964901043','57.759959649010433','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:52:11
