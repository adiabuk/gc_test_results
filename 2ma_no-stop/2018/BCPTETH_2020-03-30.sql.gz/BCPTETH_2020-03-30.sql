-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 19:59:59','2018-06-30 23:59:59','BCPTETH','4h','0.000350000000000','0.000342490000000','0.072144500000000','0.070596485157143','206.12714285714287','206.127142857142871','test'),('2018-07-01 11:59:59','2018-07-01 15:59:59','BCPTETH','4h','0.000350150000000','0.000341270000000','0.072144500000000','0.070314875096387','206.0388404969299','206.038840496929907','test'),('2018-07-01 19:59:59','2018-07-06 07:59:59','BCPTETH','4h','0.000384580000000','0.000366040000000','0.072144500000000','0.068666526548442','187.59295855218681','187.592958552186815','test'),('2018-07-06 19:59:59','2018-07-06 23:59:59','BCPTETH','4h','0.000376300000000','0.000374460000000','0.072144500000000','0.071791733909115','191.72070156789798','191.720701567897976','test'),('2018-07-07 11:59:59','2018-07-07 15:59:59','BCPTETH','4h','0.000380260000000','0.000375280000000','0.072144500000000','0.071199673802135','189.72413611739336','189.724136117393357','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','BCPTETH','4h','0.000374870000000','0.000387530000000','0.072144500000000','0.074580942953557','192.45205004401524','192.452050044015238','test'),('2018-07-11 15:59:59','2018-07-11 23:59:59','BCPTETH','4h','0.000405530000000','0.000379620000000','0.072144500000000','0.067535065445220','177.90175819298204','177.901758192982044','test'),('2018-07-13 15:59:59','2018-07-13 19:59:59','BCPTETH','4h','0.000381570000000','0.000378540000000','0.072144500000000','0.071571609481878','189.0727782582488','189.072778258248803','test'),('2018-07-16 15:59:59','2018-07-20 03:59:59','BCPTETH','4h','0.000388190000000','0.000384060000000','0.072144500000000','0.071376946005822','185.84842474046215','185.848424740462150','test'),('2018-07-23 07:59:59','2018-07-23 11:59:59','BCPTETH','4h','0.000394720000000','0.000396920000000','0.072144500000000','0.072546602503040','182.7738650182408','182.773865018240798','test'),('2018-07-28 07:59:59','2018-07-28 15:59:59','BCPTETH','4h','0.000388000000000','0.000378340000000','0.072144500000000','0.070348325077320','185.93943298969072','185.939432989690715','test'),('2018-08-03 03:59:59','2018-08-03 07:59:59','BCPTETH','4h','0.000393280000000','0.000369550000000','0.072144500000000','0.067791395379882','183.44309397884462','183.443093978844615','test'),('2018-08-17 19:59:59','2018-08-17 23:59:59','BCPTETH','4h','0.000312330000000','0.000310300000000','0.072144500000000','0.071675594243268','230.9880575032818','230.988057503281794','test'),('2018-08-20 19:59:59','2018-08-20 23:59:59','BCPTETH','4h','0.000302760000000','0.000285890000000','0.072144500000000','0.068124557752015','238.28940414850047','238.289404148500466','test'),('2018-08-21 07:59:59','2018-08-21 11:59:59','BCPTETH','4h','0.000300070000000','0.000294800000000','0.072144500000000','0.070877457259973','240.42556736761424','240.425567367614235','test'),('2018-08-22 03:59:59','2018-08-22 07:59:59','BCPTETH','4h','0.000301520000000','0.000298040000000','0.072144500000000','0.071311842597506','239.26936853276732','239.269368532767317','test'),('2018-08-23 23:59:59','2018-08-30 11:59:59','BCPTETH','4h','0.000300020000000','0.000309660000000','0.072144500000000','0.074462588727418','240.4656356242917','240.465635624291707','test'),('2018-08-30 23:59:59','2018-09-05 11:59:59','BCPTETH','4h','0.000336960000000','0.000341640000000','0.072144500000000','0.073146506944444','214.1040479582146','214.104047958214608','test'),('2018-09-14 07:59:59','2018-09-15 15:59:59','BCPTETH','4h','0.000384530000000','0.000357150000000','0.072144500000000','0.067007536928198','187.61735105193353','187.617351051933525','test'),('2018-09-16 03:59:59','2018-09-16 15:59:59','BCPTETH','4h','0.000368430000000','0.000368520000000','0.072144500000000','0.072162123442716','195.81603018212417','195.816030182124166','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','BCPTETH','4h','0.000379380000000','0.000375200000000','0.072144500000000','0.071349613580052','190.16421529864516','190.164215298645161','test'),('2018-09-25 03:59:59','2018-09-25 07:59:59','BCPTETH','4h','0.000385320000000','0.000394690000000','0.072144500000000','0.073898870302606','187.2326897124468','187.232689712446813','test'),('2018-10-04 07:59:59','2018-10-06 11:59:59','BCPTETH','4h','0.000404980000000','0.000409620000000','0.072144500000000','0.072971085214085','178.1433651044496','178.143365104449600','test'),('2018-10-07 03:59:59','2018-10-07 11:59:59','BCPTETH','4h','0.000417220000000','0.000417000000000','0.072144500000000','0.072106458223479','172.9171660035473','172.917166003547294','test'),('2018-10-09 19:59:59','2018-10-10 07:59:59','BCPTETH','4h','0.000414670000000','0.000420160000000','0.072144500000000','0.073099653025297','173.98051462608822','173.980514626088222','test'),('2018-10-16 11:59:59','2018-10-16 15:59:59','BCPTETH','4h','0.000482590000000','0.000524950000000','0.072144500000000','0.078477082564910','149.49439482790774','149.494394827907740','test'),('2018-10-27 11:59:59','2018-10-27 15:59:59','BCPTETH','4h','0.000543710000000','0.000531830000000','0.072144500000000','0.070568151100771','132.68930128193338','132.689301281933382','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','BCPTETH','4h','0.000548120000000','0.000531730000000','0.072144500000000','0.069987219924469','131.62172516967087','131.621725169670867','test'),('2018-10-28 15:59:59','2018-10-29 03:59:59','BCPTETH','4h','0.000550740000000','0.000563620000000','0.072144500000000','0.073831722936413','130.99556959726914','130.995569597269139','test'),('2018-11-03 19:59:59','2018-11-03 23:59:59','BCPTETH','4h','0.000572200000000','0.000571430000000','0.072144500000000','0.072047416349179','126.08266340440404','126.082663404404045','test'),('2018-11-05 03:59:59','2018-11-05 07:59:59','BCPTETH','4h','0.000579950000000','0.000556120000000','0.072144500000000','0.069180100594879','124.39779291318217','124.397792913182172','test'),('2018-11-29 07:59:59','2018-11-30 03:59:59','BCPTETH','4h','0.000375940000000','0.000350960000000','0.072144500000000','0.067350730754908','191.9042932382827','191.904293238282690','test'),('2018-12-01 11:59:59','2018-12-02 07:59:59','BCPTETH','4h','0.000361660000000','0.000363800000000','0.072144500000000','0.072571390532544','199.48155726372838','199.481557263728376','test'),('2018-12-04 03:59:59','2018-12-04 07:59:59','BCPTETH','4h','0.000357370000000','0.000360490000000','0.072144500000000','0.072774353765005','201.87620673251814','201.876206732518142','test'),('2018-12-04 15:59:59','2018-12-06 11:59:59','BCPTETH','4h','0.000370500000000','0.000354600000000','0.072144500000000','0.069048420242915','194.72199730094468','194.721997300944679','test'),('2018-12-12 19:59:59','2018-12-12 23:59:59','BCPTETH','4h','0.000348000000000','0.000337490000000','0.072144500000000','0.069965653175287','207.3117816091954','207.311781609195407','test'),('2018-12-14 11:59:59','2018-12-14 19:59:59','BCPTETH','4h','0.000353770000000','0.000347340000000','0.072144500000000','0.070833226757498','203.9305198292676','203.930519829267610','test'),('2018-12-18 15:59:59','2018-12-18 23:59:59','BCPTETH','4h','0.000348130000000','0.000342060000000','0.072144500000000','0.070886587395513','207.23436647229485','207.234366472294852','test'),('2019-01-12 23:59:59','2019-01-13 11:59:59','BCPTETH','4h','0.000233250000000','0.000232560000000','0.072144500000000','0.071931082186495','309.30117899249734','309.301178992497341','test'),('2019-01-14 23:59:59','2019-01-15 11:59:59','BCPTETH','4h','0.000239680000000','0.000228800000000','0.072144500000000','0.068869582777036','301.0034212283044','301.003421228304376','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','BCPTETH','4h','0.000232600000000','0.000241050000000','0.072144500000000','0.074765398645744','310.1655202063629','310.165520206362885','test'),('2019-01-28 07:59:59','2019-01-28 11:59:59','BCPTETH','4h','0.000279330000000','0.000278130000000','0.072144500000000','0.071834567661905','258.27694841227225','258.276948412272247','test'),('2019-01-29 19:59:59','2019-01-30 03:59:59','BCPTETH','4h','0.000276660000000','0.000283650000000','0.072144500000000','0.073967279060941','260.7695366153401','260.769536615340087','test'),('2019-02-01 19:59:59','2019-02-02 15:59:59','BCPTETH','4h','0.000280790000000','0.000278260000000','0.072144500000000','0.071494456960718','256.93400762135406','256.934007621354056','test'),('2019-02-04 15:59:59','2019-02-04 19:59:59','BCPTETH','4h','0.000275490000000','0.000275670000000','0.072144500000000','0.072191637863443','261.877019129551','261.877019129551002','test'),('2019-02-06 15:59:59','2019-02-06 19:59:59','BCPTETH','4h','0.000275960000000','0.000268000000000','0.072144500000000','0.070063509204233','261.4310044934048','261.431004493404828','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','BCPTETH','4h','0.000275400000000','0.000275580000000','0.072144500000000','0.072191653267974','261.9625998547567','261.962599854756718','test'),('2019-02-21 03:59:59','2019-02-21 07:59:59','BCPTETH','4h','0.000251000000000','0.000258680000000','0.072144500000000','0.074351949243028','287.4282868525897','287.428286852589679','test'),('2019-02-26 19:59:59','2019-03-16 07:59:59','BCPTETH','4h','0.000242640000000','0.000338710000000','0.072144500000000','0.100709131202605','297.33143752060664','297.331437520606642','test'),('2019-03-20 15:59:59','2019-03-20 23:59:59','BCPTETH','4h','0.000333570000000','0.000335470000000','0.072144500000000','0.072555431888359','216.27994124171838','216.279941241718376','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','BCPTETH','4h','0.000321950000000','0.000330000000000','0.072144500000000','0.073948392607548','224.08603820469017','224.086038204690169','test'),('2019-04-05 23:59:59','2019-04-06 11:59:59','BCPTETH','4h','0.000354430000000','0.000344700000000','0.072144500000000','0.070163950991733','203.5507716615411','203.550771661541091','test'),('2019-04-07 03:59:59','2019-04-07 23:59:59','BCPTETH','4h','0.000362250000000','0.000353950000000','0.072144500000000','0.070491499723948','199.1566597653554','199.156659765355414','test'),('2019-04-10 03:59:59','2019-04-10 07:59:59','BCPTETH','4h','0.000352660000000','0.000359360000000','0.072144500000000','0.073515135030908','204.57239267282938','204.572392672829380','test'),('2019-04-13 23:59:59','2019-04-14 07:59:59','BCPTETH','4h','0.000352080000000','0.000338870000000','0.072144500000000','0.069437646884231','204.90939559191094','204.909395591910936','test'),('2019-04-14 11:59:59','2019-04-14 23:59:59','BCPTETH','4h','0.000354390000000','0.000342590000000','0.072144500000000','0.069742329792037','203.57374643754056','203.573746437540564','test'),('2019-04-16 07:59:59','2019-04-16 11:59:59','BCPTETH','4h','0.000344670000000','0.000342100000000','0.072144500000000','0.071606561203470','209.3147068210172','209.314706821017211','test'),('2019-04-19 11:59:59','2019-04-21 11:59:59','BCPTETH','4h','0.000358050000000','0.000342230000000','0.072144500000000','0.068956883773216','201.4928082670018','201.492808267001806','test'),('2019-04-21 19:59:59','2019-04-22 03:59:59','BCPTETH','4h','0.000348440000000','0.000349020000000','0.072144500000000','0.072264588996671','207.0499942601309','207.049994260130887','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 17:29:56
