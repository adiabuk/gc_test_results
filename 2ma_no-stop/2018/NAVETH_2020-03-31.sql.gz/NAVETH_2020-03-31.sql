-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 07:59:59','2018-07-03 23:59:59','NAVETH','4h','0.001030000000000','0.001074000000000','0.072144500000000','0.075226400970874','70.04320388349514','70.043203883495138','test'),('2018-07-04 15:59:59','2018-07-05 07:59:59','NAVETH','4h','0.001108000000000','0.001065000000000','0.072914975242719','0.070085242449003','65.80773938873511','65.807739388735115','test'),('2018-07-17 23:59:59','2018-07-20 03:59:59','NAVETH','4h','0.000955000000000','0.000953000000000','0.072914975242719','0.072762273723886','76.3507594164597','76.350759416459695','test'),('2018-07-20 11:59:59','2018-07-21 07:59:59','NAVETH','4h','0.000984000000000','0.000962000000000','0.072914975242719','0.071284762381601','74.10058459625914','74.100584596259139','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','NAVETH','4h','0.000971000000000','0.000986000000000','0.072914975242719','0.074041365179527','75.09266245388157','75.092662453881573','test'),('2018-07-28 07:59:59','2018-07-30 23:59:59','NAVETH','4h','0.000954000000000','0.000989000000000','0.072914975242719','0.075590052950785','76.4307916590346','76.430791659034597','test'),('2018-08-15 15:59:59','2018-08-15 23:59:59','NAVETH','4h','0.000870000000000','0.000821000000000','0.072914975242719','0.068808269740543','83.81031637094138','83.810316370941379','test'),('2018-08-17 07:59:59','2018-08-18 19:59:59','NAVETH','4h','0.000846000000000','0.000851000000000','0.072914975242719','0.073345914812711','86.18791399848583','86.187913998485826','test'),('2018-08-30 07:59:59','2018-08-30 11:59:59','NAVETH','4h','0.000963000000000','0.000951000000000','0.072914975242719','0.072006377420380','75.71648519493147','75.716485194931465','test'),('2018-08-31 07:59:59','2018-09-02 11:59:59','NAVETH','4h','0.000974000000000','0.000973000000000','0.072914975242719','0.072840113871833','74.86137088574846','74.861370885748457','test'),('2018-09-03 15:59:59','2018-09-06 07:59:59','NAVETH','4h','0.001006000000000','0.001000000000000','0.072914975242719','0.072480094674671','72.48009467467098','72.480094674670980','test'),('2018-09-15 07:59:59','2018-09-15 11:59:59','NAVETH','4h','0.001106000000000','0.001106000000000','0.072914975242719','0.072914975242719','65.92674072578572','65.926740725785720','test'),('2018-09-16 23:59:59','2018-09-21 07:59:59','NAVETH','4h','0.001118000000000','0.001185000000000','0.072914975242719','0.077284656227748','65.21911917953399','65.219119179533990','test'),('2018-09-22 19:59:59','2018-09-29 11:59:59','NAVETH','4h','0.001865000000000','0.001472000000000','0.072914975242719','0.057550050164763','39.09650147062681','39.096501470626812','test'),('2018-09-30 07:59:59','2018-09-30 11:59:59','NAVETH','4h','0.001453000000000','0.001449000000000','0.072914975242719','0.072714245785753','50.18236424137577','50.182364241375772','test'),('2018-10-08 07:59:59','2018-10-08 15:59:59','NAVETH','4h','0.001562000000000','0.001541000000000','0.072914975242719','0.071934684282350','46.68052192235532','46.680521922355318','test'),('2018-10-09 03:59:59','2018-10-09 07:59:59','NAVETH','4h','0.001538000000000','0.001546000000000','0.072914975242719','0.073294246895477','47.408956594745774','47.408956594745774','test'),('2018-10-09 23:59:59','2018-10-10 03:59:59','NAVETH','4h','0.001541000000000','0.001525000000000','0.072914975242719','0.072157908660056','47.31666141643024','47.316661416430243','test'),('2018-10-12 19:59:59','2018-10-15 07:59:59','NAVETH','4h','0.001629000000000','0.001567000000000','0.072914975242719','0.070139819647232','44.760574120760594','44.760574120760594','test'),('2018-10-28 15:59:59','2018-10-28 19:59:59','NAVETH','4h','0.001821000000000','0.001784000000000','0.072914975242719','0.071433451857776','40.041172566018126','40.041172566018126','test'),('2018-10-30 19:59:59','2018-10-31 03:59:59','NAVETH','4h','0.001841000000000','0.001774000000000','0.072914975242719','0.070261361260502','39.60617883906519','39.606178839065187','test'),('2018-10-31 19:59:59','2018-11-01 03:59:59','NAVETH','4h','0.001804000000000','0.001853000000000','0.072914975242719','0.074895481776474','40.418500688868626','40.418500688868626','test'),('2018-11-08 15:59:59','2018-11-08 19:59:59','NAVETH','4h','0.001785000000000','0.001789000000000','0.072914975242719','0.073078370145224','40.84872562617311','40.848725626173113','test'),('2018-11-21 03:59:59','2018-11-21 15:59:59','NAVETH','4h','0.001529000000000','0.001473000000000','0.072914975242719','0.070244446391449','47.68801520125507','47.688015201255070','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','NAVETH','4h','0.001448000000000','0.001358000000000','0.072914975242719','0.068382967112992','50.355645885855665','50.355645885855665','test'),('2018-11-28 11:59:59','2018-11-30 11:59:59','NAVETH','4h','0.001463000000000','0.001418000000000','0.072914975242719','0.070672204302239','49.839354232890635','49.839354232890635','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','NAVETH','4h','0.001457000000000','0.001435000000000','0.072914975242719','0.071813994147771','50.04459522492725','50.044595224927249','test'),('2018-12-01 07:59:59','2018-12-02 11:59:59','NAVETH','4h','0.001467000000000','0.001473000000000','0.072914975242719','0.073213196000358','49.70345960648876','49.703459606488757','test'),('2018-12-06 07:59:59','2018-12-06 11:59:59','NAVETH','4h','0.001498000000000','0.001523000000000','0.072914975242719','0.074131847326209','48.6748833395988','48.674883339598800','test'),('2018-12-14 15:59:59','2018-12-14 19:59:59','NAVETH','4h','0.001459000000000','0.001568000000000','0.072914975242719','0.078362358588474','49.9759939977512','49.975993997751203','test'),('2018-12-19 07:59:59','2018-12-20 23:59:59','NAVETH','4h','0.001585000000000','0.001666000000000','0.072914975242719','0.076641229498025','46.003138954396846','46.003138954396846','test'),('2018-12-21 15:59:59','2018-12-21 23:59:59','NAVETH','4h','0.001633000000000','0.001628000000000','0.072914975242719','0.072691720572656','44.6509340126877','44.650934012687699','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','NAVETH','4h','0.001226000000000','0.001214000000000','0.072914975242719','0.072201288698745','59.473878664534254','59.473878664534254','test'),('2019-01-10 07:59:59','2019-01-11 03:59:59','NAVETH','4h','0.001206000000000','0.001192000000000','0.072914975242719','0.072068532744047','60.46017847654975','60.460178476549750','test'),('2019-01-28 15:59:59','2019-01-29 07:59:59','NAVETH','4h','0.001443000000000','0.001393000000000','0.072914975242719','0.070388468824052','50.530128373332644','50.530128373332644','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','NAVETH','4h','0.001418000000000','0.001402000000000','0.072914975242719','0.072092239273831','51.420998055514104','51.420998055514104','test'),('2019-02-03 15:59:59','2019-02-04 15:59:59','NAVETH','4h','0.001389000000000','0.001405000000000','0.072914975242719','0.073754888564449','52.49458260814903','52.494582608149031','test'),('2019-02-05 23:59:59','2019-02-06 03:59:59','NAVETH','4h','0.001374000000000','0.001382000000000','0.072914975242719','0.073339516583288','53.06766757112009','53.067667571120090','test'),('2019-02-07 07:59:59','2019-02-07 11:59:59','NAVETH','4h','0.001371000000000','0.001349000000000','0.072914975242719','0.071744931876315','53.18378938199781','53.183789381997812','test'),('2019-02-07 15:59:59','2019-02-07 19:59:59','NAVETH','4h','0.001379000000000','0.001372000000000','0.072914975242719','0.072544848464837','52.87525398311748','52.875253983117481','test'),('2019-02-26 19:59:59','2019-02-27 15:59:59','NAVETH','4h','0.001158000000000','0.001141000000000','0.072914975242719','0.071844548145028','62.966299864178765','62.966299864178765','test'),('2019-02-28 15:59:59','2019-03-06 03:59:59','NAVETH','4h','0.001148000000000','0.001195000000000','0.072914975242719','0.075900170222168','63.51478679679356','63.514786796793558','test'),('2019-03-16 15:59:59','2019-03-16 19:59:59','NAVETH','4h','0.001314000000000','0.001314000000000','0.072914975242719','0.072914975242719','55.49084873875114','55.490848738751140','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','NAVETH','4h','0.001565000000000','0.001506000000000','0.072914975242719','0.070166103971588','46.59103849375016','46.591038493750162','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','NAVETH','4h','0.001549000000000','0.001549000000000','0.072914975242719','0.072914975242719','47.07228872996708','47.072288729967077','test'),('2019-04-17 23:59:59','2019-04-18 03:59:59','NAVETH','4h','0.001428000000000','0.001354000000000','0.072914975242719','0.069136468122298','51.060907032716386','51.060907032716386','test'),('2019-04-18 23:59:59','2019-04-19 03:59:59','NAVETH','4h','0.001404000000000','0.001384000000000','0.072914975242719','0.071876300381712','51.93374305036966','51.933743050369657','test'),('2019-05-02 23:59:59','2019-05-03 03:59:59','NAVETH','4h','0.001242000000000','0.001233000000000','0.072914975242719','0.072386605856902','58.707709535200486','58.707709535200486','test'),('2019-05-03 19:59:59','2019-05-04 03:59:59','NAVETH','4h','0.001275000000000','0.001212000000000','0.072914975242719','0.069312117642491','57.18821587664235','57.188215876642353','test'),('2019-05-18 15:59:59','2019-05-18 23:59:59','NAVETH','4h','0.001021000000000','0.000947000000000','0.072914975242719','0.067630246380857','71.41525489002841','71.415254890028407','test'),('2019-05-22 23:59:59','2019-05-23 07:59:59','NAVETH','4h','0.000957000000000','0.000940000000000','0.072914975242719','0.071619724898804','76.19119670085581','76.191196700855812','test'),('2019-05-31 23:59:59','2019-06-01 03:59:59','NAVETH','4h','0.000862000000000','0.000835000000000','0.072914975242719','0.070631095507738','84.58813833262066','84.588138332620659','test'),('2019-06-01 15:59:59','2019-06-03 23:59:59','NAVETH','4h','0.000897000000000','0.000861000000000','0.072914975242719','0.069988621721272','81.28759781796991','81.287597817969910','test'),('2019-06-05 11:59:59','2019-06-06 15:59:59','NAVETH','4h','0.000883000000000','0.000875000000000','0.072914975242719','0.072254363915492','82.57641590341903','82.576415903419033','test'),('2019-06-07 07:59:59','2019-06-12 15:59:59','NAVETH','4h','0.000884000000000','0.000903000000000','0.072914975242719','0.074482152312415','82.48300366823416','82.483003668234161','test'),('2019-06-13 15:59:59','2019-06-14 03:59:59','NAVETH','4h','0.000968000000000','0.001008000000000','0.072914975242719','0.075927990748616','75.32538764743698','75.325387647436983','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  5:06:51
