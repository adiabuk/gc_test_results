-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-15 07:59:59','2018-02-15 11:59:59','WTCETH','4h','0.027250000000000','0.027231000000000','0.072144500000000','0.072094197412844','2.6475045871559635','2.647504587155963','test'),('2018-02-18 15:59:59','2018-02-18 19:59:59','WTCETH','4h','0.027599000000000','0.026658000000000','0.072144500000000','0.069684701655857','2.6140258705025547','2.614025870502555','test'),('2018-02-19 07:59:59','2018-02-19 11:59:59','WTCETH','4h','0.027703000000000','0.027601000000000','0.072144500000000','0.071878870320904','2.6042125401581058','2.604212540158106','test'),('2018-03-05 23:59:59','2018-03-06 03:59:59','WTCETH','4h','0.024100000000000','0.024453000000000','0.072144500000000','0.073201222344398','2.9935477178423238','2.993547717842324','test'),('2018-03-19 03:59:59','2018-03-19 07:59:59','WTCETH','4h','0.022589000000000','0.022115000000000','0.072144500000000','0.070630644008146','3.1937890123511443','3.193789012351144','test'),('2018-03-19 11:59:59','2018-03-23 03:59:59','WTCETH','4h','0.022812000000000','0.023474000000000','0.072144500000000','0.074238119980712','3.1625679466947223','3.162567946694722','test'),('2018-03-23 11:59:59','2018-03-30 23:59:59','WTCETH','4h','0.024126000000000','0.026509000000000','0.072144500000000','0.079270436479317','2.9903216446986653','2.990321644698665','test'),('2018-03-31 11:59:59','2018-03-31 19:59:59','WTCETH','4h','0.027000000000000','0.026929000000000','0.073641173050545','0.073447524039931','2.7274508537238704','2.727450853723870','test'),('2018-04-03 15:59:59','2018-04-03 19:59:59','WTCETH','4h','0.028192000000000','0.025176000000000','0.073641173050545','0.065762988532936','2.6121301450959495','2.612130145095950','test'),('2018-04-11 15:59:59','2018-04-11 19:59:59','WTCETH','4h','0.023905000000000','0.023535000000000','0.073641173050545','0.072501359872185','3.080576157730391','3.080576157730391','test'),('2018-04-18 11:59:59','2018-04-19 19:59:59','WTCETH','4h','0.022333000000000','0.022361000000000','0.073641173050545','0.073733500675379','3.2974151726389205','3.297415172638920','test'),('2018-04-23 19:59:59','2018-04-23 23:59:59','WTCETH','4h','0.022250000000000','0.021891000000000','0.073641173050545','0.072452985134808','3.309715642721124','3.309715642721124','test'),('2018-04-26 19:59:59','2018-04-26 23:59:59','WTCETH','4h','0.021800000000000','0.021477000000000','0.073641173050545','0.072550067596631','3.3780354610341745','3.378035461034175','test'),('2018-05-03 07:59:59','2018-05-03 15:59:59','WTCETH','4h','0.023173000000000','0.022818000000000','0.073641173050545','0.072513023202319','3.177886896411557','3.177886896411557','test'),('2018-05-04 07:59:59','2018-05-04 11:59:59','WTCETH','4h','0.023022000000000','0.022400000000000','0.073641173050545','0.071651562693606','3.1987304773931458','3.198730477393146','test'),('2018-05-04 15:59:59','2018-05-04 19:59:59','WTCETH','4h','0.022859000000000','0.022409000000000','0.073641173050545','0.072191480243653','3.2215395708712107','3.221539570871211','test'),('2018-05-21 11:59:59','2018-05-21 15:59:59','WTCETH','4h','0.018557000000000','0.018135000000000','0.073641173050545','0.071966517932405','3.968377057204559','3.968377057204559','test'),('2018-05-21 23:59:59','2018-05-22 03:59:59','WTCETH','4h','0.018237000000000','0.018036000000000','0.073641173050545','0.072829533209389','4.038009159979437','4.038009159979437','test'),('2018-05-24 15:59:59','2018-05-25 19:59:59','WTCETH','4h','0.018296000000000','0.018400000000000','0.073641173050545','0.074059771760496','4.024987595679111','4.024987595679111','test'),('2018-06-05 03:59:59','2018-06-05 07:59:59','WTCETH','4h','0.019424000000000','0.018911000000000','0.073641173050545','0.071696263568722','3.7912465532611717','3.791246553261172','test'),('2018-07-02 07:59:59','2018-07-03 03:59:59','WTCETH','4h','0.014886000000000','0.015294000000000','0.073641173050545','0.075659552642418','4.94700880361044','4.947008803610440','test'),('2018-07-04 19:59:59','2018-07-05 03:59:59','WTCETH','4h','0.015107000000000','0.015357000000000','0.073641173050545','0.074859832828306','4.8746391110442175','4.874639111044218','test'),('2018-07-06 15:59:59','2018-07-06 19:59:59','WTCETH','4h','0.015013000000000','0.014904000000000','0.073641173050545','0.073106510567197','4.905160397691668','4.905160397691668','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','WTCETH','4h','0.015084000000000','0.014945000000000','0.073641173050545','0.072962565051737','4.882071933873309','4.882071933873309','test'),('2018-07-08 19:59:59','2018-07-08 23:59:59','WTCETH','4h','0.015034000000000','0.014800000000000','0.073641173050545','0.072494968813893','4.898308703641413','4.898308703641413','test'),('2018-07-09 03:59:59','2018-07-09 23:59:59','WTCETH','4h','0.015378000000000','0.015038000000000','0.073641173050545','0.072013003013012','4.788735404509365','4.788735404509365','test'),('2018-07-11 07:59:59','2018-07-12 19:59:59','WTCETH','4h','0.015060000000000','0.015007000000000','0.073641173050545','0.073382010887751','4.889852128190239','4.889852128190239','test'),('2018-07-17 23:59:59','2018-07-18 07:59:59','WTCETH','4h','0.015423000000000','0.015107000000000','0.073641173050545','0.072132347874900','4.77476321406633','4.774763214066330','test'),('2018-07-19 19:59:59','2018-07-19 23:59:59','WTCETH','4h','0.015027000000000','0.014845000000000','0.073641173050545','0.072749265584304','4.90059047385007','4.900590473850070','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','WTCETH','4h','0.015030000000000','0.014722000000000','0.073641173050545','0.072132092458425','4.899612312078842','4.899612312078842','test'),('2018-07-29 03:59:59','2018-07-29 07:59:59','WTCETH','4h','0.013775000000000','0.013043000000000','0.073641173050545','0.069727899825645','5.3460016733607985','5.346001673360798','test'),('2018-08-17 07:59:59','2018-08-18 03:59:59','WTCETH','4h','0.009171000000000','0.008638000000000','0.073641173050545','0.069361296784495','8.029786615477592','8.029786615477592','test'),('2018-09-12 03:59:59','2018-09-12 07:59:59','WTCETH','4h','0.017061000000000','0.016389000000000','0.073641173050545','0.070740588777058','4.316345645070336','4.316345645070336','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','WTCETH','4h','0.015779000000000','0.015059000000000','0.073641173050545','0.070280906582683','4.66703676091926','4.667036760919260','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','WTCETH','4h','0.015909000000000','0.015590000000000','0.073641173050545','0.072164553891382','4.6289001854638885','4.628900185463888','test'),('2018-10-06 15:59:59','2018-10-06 19:59:59','WTCETH','4h','0.013041000000000','0.013120000000000','0.073641173050545','0.074087277848566','5.646896177482172','5.646896177482172','test'),('2018-10-07 19:59:59','2018-10-08 03:59:59','WTCETH','4h','0.013099000000000','0.013009000000000','0.073641173050545','0.073135202703606','5.621892743762501','5.621892743762501','test'),('2018-10-22 07:59:59','2018-11-04 15:59:59','WTCETH','4h','0.014545000000000','0.015860000000000','0.073641173050545','0.080299003408845','5.06298886562702','5.062988865627020','test'),('2018-11-29 11:59:59','2018-11-29 23:59:59','WTCETH','4h','0.011433000000000','0.011145000000000','0.073641173050545','0.071786134317180','6.441106713071372','6.441106713071372','test'),('2018-12-04 15:59:59','2018-12-06 03:59:59','WTCETH','4h','0.011069000000000','0.010911000000000','0.073641173050545','0.072590011668127','6.652920141886801','6.652920141886801','test'),('2018-12-14 07:59:59','2018-12-16 03:59:59','WTCETH','4h','0.010855000000000','0.010549000000000','0.073641173050545','0.071565245003243','6.784078585955321','6.784078585955321','test'),('2018-12-17 03:59:59','2018-12-17 07:59:59','WTCETH','4h','0.010599000000000','0.010358000000000','0.073641173050545','0.071966720488494','6.947935942121426','6.947935942121426','test'),('2018-12-18 03:59:59','2018-12-18 11:59:59','WTCETH','4h','0.010962000000000','0.010504000000000','0.073641173050545','0.070564393516049','6.717859245625343','6.717859245625343','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','WTCETH','4h','0.010623000000000','0.010582000000000','0.073641173050545','0.073356951258671','6.932238826183282','6.932238826183282','test'),('2019-01-07 03:59:59','2019-01-07 15:59:59','WTCETH','4h','0.008289000000000','0.008052000000000','0.073641173050545','0.071535616528289','8.884204735256969','8.884204735256969','test'),('2019-01-24 07:59:59','2019-01-24 23:59:59','WTCETH','4h','0.009380000000000','0.009318000000000','0.073641173050545','0.073154419028249','7.850871327350214','7.850871327350214','test'),('2019-01-28 19:59:59','2019-01-29 07:59:59','WTCETH','4h','0.009553000000000','0.009250000000000','0.073641173050545','0.071305438157389','7.708696017015074','7.708696017015074','test'),('2019-01-29 11:59:59','2019-01-29 15:59:59','WTCETH','4h','0.009448000000000','0.009397000000000','0.073641173050545','0.073243660367906','7.7943663262642895','7.794366326264289','test'),('2019-02-05 15:59:59','2019-02-05 23:59:59','WTCETH','4h','0.009141000000000','0.009012000000000','0.073641173050545','0.072601931028499','8.056139705781098','8.056139705781098','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:31:25
