-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-28 23:59:59','2018-07-29 03:59:59','AEBTC','4h','0.000261500000000','0.000239800000000','0.001467500000000','0.001345722753346','5.611854684512428','5.611854684512428','test'),('2018-07-29 15:59:59','2018-07-29 19:59:59','AEBTC','4h','0.000260600000000','0.000249700000000','0.001467500000000','0.001406119531850','5.631235610130468','5.631235610130468','test'),('2018-08-06 23:59:59','2018-08-07 03:59:59','AEBTC','4h','0.000241400000000','0.000240800000000','0.001467500000000','0.001463852526926','6.079121789560895','6.079121789560895','test'),('2018-08-07 15:59:59','2018-08-07 19:59:59','AEBTC','4h','0.000240700000000','0.000240800000000','0.001467500000000','0.001468109680100','6.096800997091816','6.096800997091816','test'),('2018-08-27 23:59:59','2018-08-28 03:59:59','AEBTC','4h','0.000161900000000','0.000161400000000','0.001467500000000','0.001462967881408','9.064237183446572','9.064237183446572','test'),('2018-08-31 11:59:59','2018-08-31 15:59:59','AEBTC','4h','0.000162900000000','0.000161700000000','0.001467500000000','0.001456689686924','9.008594229588706','9.008594229588706','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','AEBTC','4h','0.000163700000000','0.000162000000000','0.001467500000000','0.001452260232132','8.964569334147832','8.964569334147832','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','AEBTC','4h','0.000164400000000','0.000163300000000','0.001467500000000','0.001457680961071','8.92639902676399','8.926399026763990','test'),('2018-09-04 11:59:59','2018-09-04 15:59:59','AEBTC','4h','0.000164600000000','0.000161600000000','0.001467500000000','0.001440753341434','8.915552855407048','8.915552855407048','test'),('2018-09-14 11:59:59','2018-09-17 15:59:59','AEBTC','4h','0.000149800000000','0.000145600000000','0.001467500000000','0.001426355140187','9.796395193591454','9.796395193591454','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','AEBTC','4h','0.000149900000000','0.000149300000000','0.001467500000000','0.001461626084056','9.789859906604402','9.789859906604402','test'),('2018-09-20 23:59:59','2018-09-21 11:59:59','AEBTC','4h','0.000151600000000','0.000151600000000','0.001467500000000','0.001467500000000','9.680079155672823','9.680079155672823','test'),('2018-09-25 07:59:59','2018-09-25 11:59:59','AEBTC','4h','0.000150800000000','0.000147000000000','0.001467500000000','0.001430520557029','9.731432360742705','9.731432360742705','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','AEBTC','4h','0.000150100000000','0.000147500000000','0.001467500000000','0.001442080279813','9.776815456362426','9.776815456362426','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','AEBTC','4h','0.000149900000000','0.000151100000000','0.001467500000000','0.001479247831888','9.789859906604402','9.789859906604402','test'),('2018-10-26 15:59:59','2018-10-27 03:59:59','AEBTC','4h','0.000198800000000','0.000195100000000','0.001467500000000','0.001440187374245','7.381790744466801','7.381790744466801','test'),('2018-10-28 15:59:59','2018-10-28 19:59:59','AEBTC','4h','0.000196300000000','0.000198500000000','0.001467500000000','0.001483946765155','7.475802343352012','7.475802343352012','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','AEBTC','4h','0.000155600000000','0.000148500000000','0.001467500000000','0.001400538239075','9.431233933161955','9.431233933161955','test'),('2018-12-21 03:59:59','2018-12-25 03:59:59','AEBTC','4h','0.000117800000000','0.000107500000000','0.001467500000000','0.001339187181664','12.457555178268251','12.457555178268251','test'),('2019-01-02 19:59:59','2019-01-02 23:59:59','AEBTC','4h','0.000107200000000','0.000105300000000','0.001467500000000','0.001441490205224','13.689365671641792','13.689365671641792','test'),('2019-01-06 03:59:59','2019-01-06 07:59:59','AEBTC','4h','0.000108100000000','0.000103900000000','0.001467500000000','0.001410483348751','13.575393154486587','13.575393154486587','test'),('2019-01-10 03:59:59','2019-01-10 11:59:59','AEBTC','4h','0.000106000000000','0.000103700000000','0.001467500000000','0.001435658018868','13.84433962264151','13.844339622641510','test'),('2019-01-12 23:59:59','2019-01-13 03:59:59','AEBTC','4h','0.000103500000000','0.000102100000000','0.001467500000000','0.001447649758454','14.178743961352659','14.178743961352659','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','AEBTC','4h','0.000103400000000','0.000102500000000','0.001467500000000','0.001454726789168','14.192456479690522','14.192456479690522','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','AEBTC','4h','0.000103800000000','0.000104100000000','0.001467500000000','0.001471741329480','14.13776493256262','14.137764932562620','test'),('2019-01-25 03:59:59','2019-01-25 07:59:59','AEBTC','4h','0.000116700000000','0.000115600000000','0.001467500000000','0.001453667523565','12.574978577549272','12.574978577549272','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','AEBTC','4h','0.000116200000000','0.000115200000000','0.001467500000000','0.001454870912220','12.62908777969019','12.629087779690190','test'),('2019-02-09 11:59:59','2019-02-09 15:59:59','AEBTC','4h','0.000108400000000','0.000110000000000','0.001467500000000','0.001489160516605','13.537822878228782','13.537822878228782','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','AEBTC','4h','0.000108700000000','0.000108400000000','0.001467500000000','0.001463449862006','13.500459981600736','13.500459981600736','test'),('2019-02-13 07:59:59','2019-02-13 11:59:59','AEBTC','4h','0.000108400000000','0.000106800000000','0.001467500000000','0.001445839483395','13.537822878228782','13.537822878228782','test'),('2019-02-15 15:59:59','2019-02-18 11:59:59','AEBTC','4h','0.000107500000000','0.000111300000000','0.001467500000000','0.001519374418605','13.651162790697676','13.651162790697676','test'),('2019-02-20 23:59:59','2019-02-21 03:59:59','AEBTC','4h','0.000110400000000','0.000108600000000','0.001467500000000','0.001443573369565','13.292572463768117','13.292572463768117','test'),('2019-02-22 23:59:59','2019-02-23 03:59:59','AEBTC','4h','0.000110800000000','0.000115300000000','0.001467500000000','0.001527100631769','13.244584837545128','13.244584837545128','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','AEBTC','4h','0.000111800000000','0.000112300000000','0.001467500000000','0.001474063059034','13.126118067978535','13.126118067978535','test'),('2019-02-26 15:59:59','2019-02-27 03:59:59','AEBTC','4h','0.000113800000000','0.000112700000000','0.001467500000000','0.001453315026362','12.89543057996485','12.895430579964851','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','AEBTC','4h','0.000114700000000','0.000114200000000','0.001467500000000','0.001461102877071','12.794245858761988','12.794245858761988','test'),('2019-03-10 03:59:59','2019-03-10 07:59:59','AEBTC','4h','0.000114600000000','0.000111100000000','0.001467500000000','0.001422681064572','12.80541012216405','12.805410122164050','test'),('2019-03-12 15:59:59','2019-03-13 03:59:59','AEBTC','4h','0.000115000000000','0.000113300000000','0.001467500000000','0.001445806521739','12.76086956521739','12.760869565217391','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','AEBTC','4h','0.000113400000000','0.000117500000000','0.001467500000000','0.001520557760141','12.940917107583774','12.940917107583774','test'),('2019-03-19 15:59:59','2019-03-19 23:59:59','AEBTC','4h','0.000115500000000','0.000114300000000','0.001467500000000','0.001452253246753','12.705627705627705','12.705627705627705','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','AEBTC','4h','0.000116600000000','0.000115400000000','0.001467500000000','0.001452397084048','12.585763293310464','12.585763293310464','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','AEBTC','4h','0.000118100000000','0.000117400000000','0.001467500000000','0.001458801862828','12.425910245554615','12.425910245554615','test'),('2019-03-29 23:59:59','2019-03-30 07:59:59','AEBTC','4h','0.000118100000000','0.000117900000000','0.001467500000000','0.001465014817951','12.425910245554615','12.425910245554615','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','AEBTC','4h','0.000121300000000','0.000124400000000','0.001467500000000','0.001505004122012','12.09810387469085','12.098103874690850','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','AEBTC','4h','0.000111400000000','0.000106100000000','0.001467500000000','0.001397681777379','13.173249551166966','13.173249551166966','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','AEBTC','4h','0.000073400000000','0.000072900000000','0.001467500000000','0.001457503405995','19.993188010899186','19.993188010899186','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','AEBTC','4h','0.000072000000000','0.000072100000000','0.001467500000000','0.001469538194444','20.381944444444446','20.381944444444446','test'),('2019-05-22 03:59:59','2019-05-22 11:59:59','AEBTC','4h','0.000071100000000','0.000069000000000','0.001467500000000','0.001424156118143','20.639943741209567','20.639943741209567','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','AEBTC','4h','0.000069700000000','0.000067800000000','0.001467500000000','0.001427496413199','21.0545193687231','21.054519368723099','test'),('2019-05-24 07:59:59','2019-05-24 19:59:59','AEBTC','4h','0.000071900000000','0.000069000000000','0.001467500000000','0.001408310152990','20.410292072322672','20.410292072322672','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','AEBTC','4h','0.000071200000000','0.000068200000000','0.001467500000000','0.001405667134831','20.610955056179776','20.610955056179776','test'),('2019-06-05 19:59:59','2019-06-05 23:59:59','AEBTC','4h','0.000065100000000','0.000065100000000','0.001467500000000','0.001467500000000','22.542242703533027','22.542242703533027','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','AEBTC','4h','0.000066900000000','0.000064600000000','0.001467500000000','0.001417047832586','21.935724962630793','21.935724962630793','test'),('2019-06-11 23:59:59','2019-06-12 03:59:59','AEBTC','4h','0.000064400000000','0.000063700000000','0.001467500000000','0.001451548913043','22.787267080745345','22.787267080745345','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','AEBTC','4h','0.000031000000000','0.000031000000000','0.001467500000000','0.001467500000000','47.33870967741935','47.338709677419352','test'),('2019-07-26 03:59:59','2019-07-26 03:59:59','AEBTC','4h','0.000031000000000','0.000031000000000','0.001467500000000','0.001467500000000','47.33870967741935','47.338709677419352','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:33:55
