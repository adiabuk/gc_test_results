-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-16 23:59:59','2018-09-19 19:59:59','WPRETH','4h','0.000094620000000','0.000097230000000','0.072144500000000','0.074134535351934','762.4656520820123','762.465652082012298','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','WPRETH','4h','0.000092520000000','0.000097860000000','0.072642008837983','0.076834705846142','785.1492524641536','785.149252464153619','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','WPRETH','4h','0.000131500000000','0.000129970000000','0.073690183090023','0.072832799210725','560.3816204564506','560.381620456450605','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','WPRETH','4h','0.000141090000000','0.000129360000000','0.073690183090023','0.067563697530125','522.2920340918776','522.292034091877554','test'),('2018-11-09 19:59:59','2018-11-09 23:59:59','WPRETH','4h','0.000173400000000','0.000171590000000','0.073690183090023','0.072920983370341','424.9722208190484','424.972220819048403','test'),('2018-11-26 19:59:59','2018-11-27 07:59:59','WPRETH','4h','0.000137870000000','0.000130230000000','0.073690183090023','0.069606676897176','534.4903393778413','534.490339377841337','test'),('2018-12-07 07:59:59','2018-12-07 11:59:59','WPRETH','4h','0.000142330000000','0.000143710000000','0.073690183090023','0.074404666703205','517.7417486828004','517.741748682800448','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','WPRETH','4h','0.000142820000000','0.000143660000000','0.073690183090023','0.074123594053443','515.9654326426481','515.965432642648125','test'),('2018-12-11 23:59:59','2018-12-12 07:59:59','WPRETH','4h','0.000143090000000','0.000140450000000','0.073690183090023','0.072330604619426','514.9918449229366','514.991844922936593','test'),('2018-12-14 23:59:59','2018-12-15 07:59:59','WPRETH','4h','0.000146500000000','0.000141400000000','0.073690183090023','0.071124859310097','503.00466273053235','503.004662730532345','test'),('2018-12-15 15:59:59','2018-12-15 19:59:59','WPRETH','4h','0.000141430000000','0.000141920000000','0.073690183090023','0.073945490943478','521.036435622025','521.036435622025010','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','WPRETH','4h','0.000151000000000','0.000143930000000','0.073690183090023','0.070239920875146','488.01445754982115','488.014457549821145','test'),('2018-12-19 07:59:59','2018-12-19 11:59:59','WPRETH','4h','0.000142910000000','0.000143670000000','0.073690183090023','0.074082069865955','515.6404946471415','515.640494647141509','test'),('2019-01-10 11:59:59','2019-01-10 19:59:59','WPRETH','4h','0.000094300000000','0.000093110000000','0.073690183090023','0.072760264554741','781.4441472961081','781.444147296108099','test'),('2019-01-11 11:59:59','2019-01-12 11:59:59','WPRETH','4h','0.000096880000000','0.000093990000000','0.073690183090023','0.071491951988349','760.6335991951177','760.633599195117654','test'),('2019-02-02 07:59:59','2019-02-03 15:59:59','WPRETH','4h','0.000112620000000','0.000111440000000','0.073690183090023','0.072918078525592','654.325902060229','654.325902060229055','test'),('2019-03-01 15:59:59','2019-03-06 11:59:59','WPRETH','4h','0.000079250000000','0.000083870000000','0.073690183090023','0.077986065056911','929.8445815775772','929.844581577577173','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','WPRETH','4h','0.000086120000000','0.000085410000000','0.073690183090023','0.073082658357163','855.6686378312006','855.668637831200613','test'),('2019-03-20 03:59:59','2019-03-21 15:59:59','WPRETH','4h','0.000090520000000','0.000089230000000','0.073690183090023','0.072640024714127','814.0762603846995','814.076260384699481','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','WPRETH','4h','0.000090490000000','0.000088640000000','0.073690183090023','0.072183642713003','814.3461497405569','814.346149740556939','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','WPRETH','4h','0.000090380000000','0.000090260000000','0.073690183090023','0.073592342616790','815.3372769420557','815.337276942055723','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','WPRETH','4h','0.000090620000000','0.000090720000000','0.073690183090023','0.073771500882001','813.1779197751379','813.177919775137866','test'),('2019-03-26 15:59:59','2019-03-30 03:59:59','WPRETH','4h','0.000093820000000','0.000095880000000','0.073690183090023','0.075308193931693','785.4421561503196','785.442156150319647','test'),('2019-04-07 11:59:59','2019-04-07 23:59:59','WPRETH','4h','0.000097690000000','0.000099770000000','0.073690183090023','0.075259182791397','754.326779506838','754.326779506837966','test'),('2019-04-19 23:59:59','2019-04-20 03:59:59','WPRETH','4h','0.000088400000000','0.000085320000000','0.073690183090023','0.071122697072859','833.5993562219796','833.599356221979633','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','WPRETH','4h','0.000048530000000','0.000047310000000','0.073690183090023','0.071837679002452','1518.445973418978','1518.445973418977928','test'),('2019-05-26 03:59:59','2019-05-26 19:59:59','WPRETH','4h','0.000050860000000','0.000048810000000','0.073690183090023','0.070719973193551','1448.882876327625','1448.882876327624899','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','WPRETH','4h','0.000050190000000','0.000050640000000','0.073690183090023','0.074350884074094','1468.224409046085','1468.224409046084929','test'),('2019-06-03 15:59:59','2019-06-03 19:59:59','WPRETH','4h','0.000048620000000','0.000049090000000','0.073690183090023','0.074402531630795','1515.635193130872','1515.635193130872040','test'),('2019-06-05 11:59:59','2019-06-06 15:59:59','WPRETH','4h','0.000048350000000','0.000047760000000','0.073690183090023','0.072790964723464','1524.0989263706927','1524.098926370692652','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','WPRETH','4h','0.000053430000000','0.000052430000000','0.073690183090023','0.072310991941043','1379.191148980404','1379.191148980404023','test'),('2019-06-13 23:59:59','2019-06-14 15:59:59','WPRETH','4h','0.000053970000000','0.000052150000000','0.073690183090023','0.071205170430697','1365.3915710584213','1365.391571058421277','test'),('2019-07-14 19:59:59','2019-07-14 23:59:59','WPRETH','4h','0.000036870000000','0.000033770000000','0.073690183090023','0.067494371655820','1998.6488497429618','1998.648849742961829','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','WPRETH','4h','0.000033200000000','0.000032520000000','0.073690183090023','0.072180866086974','2219.583828012741','2219.583828012740923','test'),('2019-07-22 19:59:59','2019-07-23 03:59:59','WPRETH','4h','0.000033380000000','0.000033110000000','0.073690183090023','0.073094127085400','2207.6148319359795','2207.614831935979510','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','WPRETH','4h','0.000033170000000','0.000032700000000','0.073690183090023','0.072646035183713','2221.5912900217963','2221.591290021796340','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','WPRETH','4h','0.000033040000000','0.000032340000000','0.073690183090023','0.072128950397438','2230.3324179789042','2230.332417978904232','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','WPRETH','4h','0.000033180000000','0.000032470000000','0.073690183090023','0.072113328659827','2220.9217326709763','2220.921732670976326','test'),('2019-07-27 03:59:59','2019-07-27 07:59:59','WPRETH','4h','0.000033180000000','0.000032410000000','0.073690183090023','0.071980073355866','2220.9217326709763','2220.921732670976326','test'),('2019-07-28 19:59:59','2019-07-29 03:59:59','WPRETH','4h','0.000033180000000','0.000032660000000','0.073690183090023','0.072535303789034','2220.9217326709763','2220.921732670976326','test'),('2019-07-29 15:59:59','2019-07-30 11:59:59','WPRETH','4h','0.000034150000000','0.000033040000000','0.073690183090023','0.071294982409791','2157.838450659531','2157.838450659531190','test'),('2019-08-12 19:59:59','2019-08-12 23:59:59','WPRETH','4h','0.000037480000000','0.000029190000000','0.073690183090023','0.057391047075714','1966.1201464787353','1966.120146478735251','test'),('2019-08-17 15:59:59','2019-08-18 23:59:59','WPRETH','4h','0.000029300000000','0.000029850000000','0.073690183090023','0.075073445912532','2515.0233136526617','2515.023313652661727','test'),('2019-08-21 11:59:59','2019-08-21 19:59:59','WPRETH','4h','0.000030910000000','0.000030630000000','0.073690183090023','0.073022656358700','2384.024040440731','2384.024040440730914','test'),('2019-08-24 07:59:59','2019-08-29 15:59:59','WPRETH','4h','0.000031820000000','0.000032770000000','0.073690183090023','0.075890235696419','2315.844848837932','2315.844848837932204','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','WPRETH','4h','0.000035090000000','0.000033850000000','0.073690183090023','0.071086141282339','2100.0337158741236','2100.033715874123573','test'),('2019-09-02 03:59:59','2019-09-02 07:59:59','WPRETH','4h','0.000033170000000','0.000032340000000','0.073690183090023','0.071846262319305','2221.5912900217963','2221.591290021796340','test'),('2019-09-08 23:59:59','2019-09-09 07:59:59','WPRETH','4h','0.000032000000000','0.000031000000000','0.073690183090023','0.071387364868460','2302.8182215632187','2302.818221563218685','test'),('2019-09-09 19:59:59','2019-09-10 03:59:59','WPRETH','4h','0.000033240000000','0.000031840000000','0.073690183090023','0.070586505101875','2216.9128486769855','2216.912848676985504','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  2:58:14
