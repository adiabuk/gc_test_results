-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-27 15:59:59','2018-06-27 19:59:59','ELFETH','4h','0.001278230000000','0.001277000000000','0.072144500000000','0.072075077646433','56.44093785938368','56.440937859383681','test'),('2018-06-29 15:59:59','2018-06-29 19:59:59','ELFETH','4h','0.001243000000000','0.001213660000000','0.072144500000000','0.070441587988737','58.04062751407884','58.040627514078842','test'),('2018-06-29 23:59:59','2018-06-30 11:59:59','ELFETH','4h','0.001245550000000','0.001309300000000','0.072144500000000','0.075837014852876','57.92180161374493','57.921801613744933','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','ELFETH','4h','0.001486320000000','0.001418700000000','0.072624545122011','0.069320497715564','48.861984715277664','48.861984715277664','test'),('2018-07-15 19:59:59','2018-07-15 23:59:59','ELFETH','4h','0.001369850000000','0.001343980000000','0.072624545122011','0.071253010295346','53.01642159507318','53.016421595073183','test'),('2018-07-16 23:59:59','2018-07-17 03:59:59','ELFETH','4h','0.001370260000000','0.001351060000000','0.072624545122011','0.071606934401168','53.0005583772503','53.000558377250300','test'),('2018-07-17 19:59:59','2018-07-21 03:59:59','ELFETH','4h','0.001452720000000','0.001431350000000','0.072624545122011','0.071556213627120','49.99211487555138','49.992114875551380','test'),('2018-07-25 03:59:59','2018-07-26 23:59:59','ELFETH','4h','0.001456750000000','0.001463300000000','0.072624545122011','0.072951087610804','49.85381508289755','49.853815082897547','test'),('2018-08-05 23:59:59','2018-08-06 11:59:59','ELFETH','4h','0.001329020000000','0.001313700000000','0.072624545122011','0.071787380872211','54.64518601827738','54.645186018277379','test'),('2018-08-06 15:59:59','2018-08-06 19:59:59','ELFETH','4h','0.001344780000000','0.001311880000000','0.072624545122011','0.070847787931605','54.00477782389015','54.004777823890151','test'),('2018-08-07 15:59:59','2018-08-08 03:59:59','ELFETH','4h','0.001341070000000','0.001324990000000','0.072624545122011','0.071753745920208','54.15417921660391','54.154179216603907','test'),('2018-08-08 11:59:59','2018-08-10 11:59:59','ELFETH','4h','0.001363120000000','0.001317560000000','0.072624545122011','0.070197191495215','53.27817442485694','53.278174424856942','test'),('2018-08-10 15:59:59','2018-08-10 19:59:59','ELFETH','4h','0.001344120000000','0.001342150000000','0.072624545122011','0.072518103469562','54.031295659621904','54.031295659621904','test'),('2018-08-17 03:59:59','2018-08-18 07:59:59','ELFETH','4h','0.001293710000000','0.001292930000000','0.072624545122011','0.072580758535222','56.13664972985522','56.136649729855222','test'),('2018-08-22 03:59:59','2018-08-22 07:59:59','ELFETH','4h','0.001328280000000','0.001310000000000','0.072624545122011','0.071625074615167','54.675629477226934','54.675629477226934','test'),('2018-08-24 03:59:59','2018-08-24 15:59:59','ELFETH','4h','0.001312200000000','0.001297870000000','0.072624545122011','0.071831442141064','55.34563719098537','55.345637190985371','test'),('2018-09-17 23:59:59','2018-09-18 03:59:59','ELFETH','4h','0.001589010000000','0.001579460000000','0.072624545122011','0.072188069325185','45.704271919000504','45.704271919000504','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','ELFETH','4h','0.001579540000000','0.001543080000000','0.072624545122011','0.070948176739350','45.97828805982185','45.978288059821850','test'),('2018-09-25 11:59:59','2018-09-25 23:59:59','ELFETH','4h','0.001559880000000','0.001512000000000','0.072624545122011','0.070395358761238','46.55777695849103','46.557776958491033','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','ELFETH','4h','0.001540810000000','0.001458740000000','0.072624545122011','0.068756257391426','47.13400427178626','47.134004271786260','test'),('2018-10-01 15:59:59','2018-10-01 19:59:59','ELFETH','4h','0.001522850000000','0.001509590000000','0.072624545122011','0.071992177214260','47.68988746233115','47.689887462331150','test'),('2018-10-06 07:59:59','2018-10-06 11:59:59','ELFETH','4h','0.001539930000000','0.001537320000000','0.072624545122011','0.072501455070666','47.16093921282851','47.160939212828509','test'),('2018-10-06 15:59:59','2018-10-06 19:59:59','ELFETH','4h','0.001542090000000','0.001535020000000','0.072624545122011','0.072291584312971','47.09488105234519','47.094881052345187','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','ELFETH','4h','0.001544070000000','0.001559990000000','0.072624545122011','0.073373334204334','47.03449009566341','47.034490095663408','test'),('2018-10-10 11:59:59','2018-10-12 03:59:59','ELFETH','4h','0.001561480000000','0.001610480000000','0.072624545122011','0.074903538583969','46.510070652208796','46.510070652208796','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','ELFETH','4h','0.001590470000000','0.001586600000000','0.072624545122011','0.072447831955700','45.66231687615044','45.662316876150442','test'),('2018-10-17 07:59:59','2018-10-17 15:59:59','ELFETH','4h','0.001590940000000','0.001574980000000','0.072624545122011','0.071895989840135','45.64882718519303','45.648827185193028','test'),('2018-10-19 03:59:59','2018-10-22 03:59:59','ELFETH','4h','0.001914540000000','0.001609060000000','0.072624545122011','0.061036724526008','37.93315633103043','37.933156331030432','test'),('2018-10-22 15:59:59','2018-10-22 23:59:59','ELFETH','4h','0.001629090000000','0.001629440000000','0.072624545122011','0.072640148060334','44.57982378015395','44.579823780153951','test'),('2018-11-01 19:59:59','2018-11-01 23:59:59','ELFETH','4h','0.001629250000000','0.001597870000000','0.072624545122011','0.071225767631798','44.575445832138094','44.575445832138094','test'),('2018-11-29 11:59:59','2018-11-30 11:59:59','ELFETH','4h','0.001113610000000','0.001101520000000','0.072624545122011','0.071836090680577','65.21542112769372','65.215421127693716','test'),('2018-12-05 19:59:59','2018-12-07 19:59:59','ELFETH','4h','0.001165500000000','0.001117210000000','0.072624545122011','0.069615502407346','62.311922026607455','62.311922026607455','test'),('2018-12-08 03:59:59','2018-12-08 11:59:59','ELFETH','4h','0.001160970000000','0.001171170000000','0.072624545122011','0.073262606708654','62.55505751398485','62.555057513984849','test'),('2018-12-09 11:59:59','2018-12-11 15:59:59','ELFETH','4h','0.001335060000000','0.001246150000000','0.072624545122011','0.067788022189111','54.3979634788032','54.397963478803199','test'),('2018-12-13 19:59:59','2018-12-13 23:59:59','ELFETH','4h','0.001221200000000','0.001197900000000','0.072624545122011','0.071238898298114','59.46982076810596','59.469820768105961','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','ELFETH','4h','0.001177530000000','0.001156690000000','0.072624545122011','0.071339231354767','61.67532472379557','61.675324723795569','test'),('2019-01-10 07:59:59','2019-01-10 11:59:59','ELFETH','4h','0.000827960000000','0.000806330000000','0.072624545122011','0.070727268791042','87.71504072903402','87.715040729034015','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','ELFETH','4h','0.000826420000000','0.000802480000000','0.072624545122011','0.070520733972449','87.87849413374676','87.878494133746756','test'),('2019-01-11 11:59:59','2019-01-12 03:59:59','ELFETH','4h','0.000847830000000','0.000820300000000','0.072624545122011','0.070266343917514','85.65932453677152','85.659324536771521','test'),('2019-01-15 23:59:59','2019-01-27 11:59:59','ELFETH','4h','0.000848620000000','0.000922210000000','0.072624545122011','0.078922346582652','85.57958228890551','85.579582288905513','test'),('2019-01-28 07:59:59','2019-01-28 11:59:59','ELFETH','4h','0.000931770000000','0.000942260000000','0.072624545122011','0.073442162643856','77.94256642949547','77.942566429495471','test'),('2019-02-01 11:59:59','2019-02-01 15:59:59','ELFETH','4h','0.000951920000000','0.000937940000000','0.072624545122011','0.071557973203356','76.29269804396483','76.292698043964833','test'),('2019-02-02 15:59:59','2019-02-02 19:59:59','ELFETH','4h','0.000948810000000','0.000940490000000','0.072624545122011','0.071987709279835','76.54276949232302','76.542769492323018','test'),('2019-02-04 03:59:59','2019-02-04 07:59:59','ELFETH','4h','0.000947630000000','0.000940760000000','0.072624545122011','0.072098041502467','76.63808144741196','76.638081447411963','test'),('2019-02-04 11:59:59','2019-02-04 15:59:59','ELFETH','4h','0.000944150000000','0.000933840000000','0.072624545122011','0.071831494165905','76.92055830324736','76.920558303247361','test'),('2019-02-06 03:59:59','2019-02-06 07:59:59','ELFETH','4h','0.000950150000000','0.000931020000000','0.072624545122011','0.071162346997311','76.43482094617796','76.434820946177965','test'),('2019-02-06 11:59:59','2019-02-06 23:59:59','ELFETH','4h','0.000976430000000','0.000959380000000','0.072624545122011','0.071356406602783','74.37762576120254','74.377625761202538','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','ELFETH','4h','0.000931210000000','0.000924600000000','0.072624545122011','0.072109034932842','77.98943860354915','77.989438603549146','test'),('2019-02-20 11:59:59','2019-02-20 15:59:59','ELFETH','4h','0.000943750000000','0.000936760000000','0.072624545122011','0.072086642530856','76.95316039418384','76.953160394183840','test'),('2019-02-23 03:59:59','2019-02-23 19:59:59','ELFETH','4h','0.000938900000000','0.000929040000000','0.072624545122011','0.071861867504690','77.35067112792736','77.350671127927356','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','ELFETH','4h','0.000946490000000','0.000927300000000','0.072624545122011','0.071152088972563','76.73038819428731','76.730388194287315','test'),('2019-03-05 07:59:59','2019-03-05 15:59:59','ELFETH','4h','0.001094150000000','0.001087820000000','0.072624545122011','0.072204389411530','66.37530971257232','66.375309712572317','test'),('2019-03-06 03:59:59','2019-03-06 07:59:59','ELFETH','4h','0.001088110000000','0.001092090000000','0.072624545122011','0.072890185259116','66.74375304152245','66.743753041522453','test'),('2019-03-17 15:59:59','2019-03-18 03:59:59','ELFETH','4h','0.001220090000000','0.001205690000000','0.072624545122011','0.071767400608281','59.52392456459031','59.523924564590310','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','ELFETH','4h','0.001222690000000','0.001222110000000','0.072624545122011','0.072590094659367','59.39734938701633','59.397349387016327','test'),('2019-04-04 07:59:59','2019-04-07 19:59:59','ELFETH','4h','0.001349670000000','0.001312080000000','0.072624545122011','0.070601860576058','53.80911268829491','53.809112688294910','test'),('2019-04-20 23:59:59','2019-04-21 03:59:59','ELFETH','4h','0.001126820000000','0.001166060000000','0.072624545122011','0.075153597810628','64.45088401165314','64.450884011653145','test'),('2019-04-22 15:59:59','2019-04-23 03:59:59','ELFETH','4h','0.001147870000000','0.001121390000000','0.072624545122011','0.070949182968779','63.26896349064876','63.268963490648758','test'),('2019-05-02 11:59:59','2019-05-02 15:59:59','ELFETH','4h','0.001063310000000','0.001053820000000','0.072624545122011','0.071976373908341','68.30044401163443','68.300444011634426','test'),('2019-05-20 15:59:59','2019-05-20 19:59:59','ELFETH','4h','0.000881800000000','0.000875680000000','0.072624545122011','0.072120505412160','82.35942971423339','82.359429714233386','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','ELFETH','4h','0.000902270000000','0.000868000000000','0.072624545122011','0.069866121189783','80.49092302970396','80.490923029703964','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','ELFETH','4h','0.000889750000000','0.000872720000000','0.072624545122011','0.071234496228021','81.62354045744422','81.623540457444221','test'),('2019-05-23 07:59:59','2019-05-26 19:59:59','ELFETH','4h','0.000899790000000','0.000926250000000','0.072624545122011','0.074760205069252','80.71277200459106','80.712772004591059','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','ELFETH','4h','0.000941280000000','0.000904710000000','0.072624545122011','0.069802983402744','77.15509213200217','77.155092132002167','test'),('2019-05-28 03:59:59','2019-05-28 11:59:59','ELFETH','4h','0.000973190000000','0.000921740000000','0.072624545122011','0.068785076111307','74.62524802146652','74.625248021466518','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','ELFETH','4h','0.000832100000000','0.000794360000000','0.072624545122011','0.069330649757386','87.2786265136534','87.278626513653407','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  5:29:15
