-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-28 19:59:59','2018-11-28 23:59:59','TRXUSDT','4h','0.015230000000000','0.014670000000000','15.000000000000000','14.448456992777412','984.898227183191','984.898227183191011','test'),('2018-11-29 07:59:59','2018-11-30 03:59:59','TRXUSDT','4h','0.014980000000000','0.015220000000000','15.000000000000000','15.240320427236314','1001.3351134846462','1001.335113484646172','test'),('2018-12-01 11:59:59','2018-12-02 07:59:59','TRXUSDT','4h','0.015210000000000','0.015010000000000','15.000000000000000','14.802761341222881','986.1932938856016','986.193293885601634','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','TRXUSDT','4h','0.014880000000000','0.014420000000000','15.000000000000000','14.536290322580646','1008.0645161290322','1008.064516129032199','test'),('2018-12-17 15:59:59','2018-12-27 23:59:59','TRXUSDT','4h','0.013630000000000','0.017980000000000','15.000000000000000','19.787234042553191','1100.5135730007337','1100.513573000733686','test'),('2018-12-28 07:59:59','2018-12-28 11:59:59','TRXUSDT','4h','0.018290000000000','0.018510000000000','15.953765781592612','16.145664549878578','872.2671285725867','872.267128572586671','test'),('2019-01-01 07:59:59','2019-01-01 15:59:59','TRXUSDT','4h','0.019030000000000','0.018820000000000','16.001740473664103','15.825157946103966','840.869178857809','840.869178857808947','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','TRXUSDT','4h','0.023710000000000','0.022870000000000','16.001740473664103','15.434829381387519','674.8941574721259','674.894157472125926','test'),('2019-01-14 15:59:59','2019-01-15 23:59:59','TRXUSDT','4h','0.024100000000000','0.023950000000000','16.001740473664103','15.902144578599803','663.972633761996','663.972633761996008','test'),('2019-01-21 11:59:59','2019-01-28 15:59:59','TRXUSDT','4h','0.025160000000000','0.025900000000000','16.001740473664103','16.472379899360110','635.9992239135177','635.999223913517653','test'),('2019-01-28 23:59:59','2019-01-29 07:59:59','TRXUSDT','4h','0.026730000000000','0.025940000000000','16.001740473664103','15.528812116978932','598.643489474901','598.643489474901003','test'),('2019-01-29 11:59:59','2019-01-31 11:59:59','TRXUSDT','4h','0.026620000000000','0.025860000000000','16.001740473664103','15.544891384258216','601.1172229024831','601.117222902483149','test'),('2019-02-04 11:59:59','2019-02-05 19:59:59','TRXUSDT','4h','0.027060000000000','0.026390000000000','16.001740473664103','15.605540691056751','591.342959115451','591.342959115450981','test'),('2019-02-08 15:59:59','2019-02-09 15:59:59','TRXUSDT','4h','0.026640000000000','0.026400000000000','16.001740473664103','15.857580649577040','600.6659336961','600.665933696099955','test'),('2019-02-18 19:59:59','2019-02-20 03:59:59','TRXUSDT','4h','0.024840000000000','0.024640000000000','16.001740473664103','15.872901983537982','644.1924506306','644.192450630599978','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','TRXUSDT','4h','0.024750000000000','0.024770000000000','16.001740473664103','16.014671173036760','646.5349686328931','646.534968632893083','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','TRXUSDT','4h','0.023600000000000','0.023750000000000','16.001740473664103','16.103446451250953','678.0398505789874','678.039850578987398','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','TRXUSDT','4h','0.023420000000000','0.023320000000000','16.001740473664103','15.933415364895257','683.2510876884758','683.251087688475764','test'),('2019-03-15 15:59:59','2019-03-15 19:59:59','TRXUSDT','4h','0.022740000000000','0.022910000000000','16.001740473664103','16.121366501831336','703.6825186307873','703.682518630787285','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','TRXUSDT','4h','0.022790000000000','0.022690000000000','16.001740473664103','15.931526605855131','702.1386780896929','702.138678089692917','test'),('2019-03-23 11:59:59','2019-03-24 23:59:59','TRXUSDT','4h','0.023960000000000','0.023240000000000','16.001740473664103','15.520886836725952','667.852273525213','667.852273525213036','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','TRXUSDT','4h','0.022980000000000','0.022530000000000','16.001740473664103','15.688390464388698','696.3333539453482','696.333353945348222','test'),('2019-03-27 11:59:59','2019-03-28 07:59:59','TRXUSDT','4h','0.023200000000000','0.022870000000000','16.001740473664103','15.774129510030090','689.7301928303493','689.730192830349324','test'),('2019-04-15 11:59:59','2019-04-15 15:59:59','TRXUSDT','4h','0.026830000000000','0.027130000000000','16.001740473664103','16.180664146496728','596.4122427754045','596.412242775404479','test'),('2019-04-18 03:59:59','2019-04-18 11:59:59','TRXUSDT','4h','0.026920000000000','0.026690000000000','16.001740473664103','15.865024266051073','594.4182939696918','594.418293969691831','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','TRXUSDT','4h','0.026790000000000','0.026720000000000','16.001740473664103','15.959929281683644','597.3027425779807','597.302742577980666','test'),('2019-05-03 23:59:59','2019-05-04 07:59:59','TRXUSDT','4h','0.023810000000000','0.023740000000000','16.001740473664103','15.954696297555053','672.0596587007183','672.059658700718273','test'),('2019-05-06 15:59:59','2019-05-07 15:59:59','TRXUSDT','4h','0.023890000000000','0.023830000000000','16.001740473664103','15.961551924965072','669.8091449838469','669.809144983846863','test'),('2019-05-11 11:59:59','2019-05-12 11:59:59','TRXUSDT','4h','0.024500000000000','0.024020000000000','16.001740473664103','15.688236986833132','653.1322642311878','653.132264231187833','test'),('2019-05-13 03:59:59','2019-05-13 23:59:59','TRXUSDT','4h','0.024470000000000','0.024330000000000','16.001740473664103','15.910189853871993','653.9329985150839','653.932998515083909','test'),('2019-05-17 19:59:59','2019-05-20 15:59:59','TRXUSDT','4h','0.026250000000000','0.027310000000000','16.001740473664103','16.647905993743493','609.5901132824421','609.590113282442076','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','TRXUSDT','4h','0.027000000000000','0.027590000000000','16.001740473664103','16.351408135866393','592.657054580152','592.657054580152021','test'),('2019-06-12 15:59:59','2019-06-12 19:59:59','TRXUSDT','4h','0.032820000000000','0.032420000000000','16.001740473664103','15.806716214387269','487.56064819208115','487.560648192081146','test'),('2019-06-15 19:59:59','2019-06-15 23:59:59','TRXUSDT','4h','0.032450000000000','0.032640000000000','16.001740473664103','16.095433253016836','493.11989133017266','493.119891330172663','test'),('2019-06-21 03:59:59','2019-06-26 23:59:59','TRXUSDT','4h','0.033030000000000','0.036770000000000','16.001740473664103','17.813623893933670','484.46080755870736','484.460807558707359','test'),('2019-07-07 19:59:59','2019-07-10 11:59:59','TRXUSDT','4h','0.034810000000000','0.033510000000000','16.001740473664103','15.404146029086013','459.6880342908389','459.688034290838914','test'),('2019-07-19 23:59:59','2019-07-21 15:59:59','TRXUSDT','4h','0.028060000000000','0.027870000000000','16.001740473664103','15.893389415574431','570.2687267877442','570.268726787744185','test'),('2019-08-05 15:59:59','2019-08-05 23:59:59','TRXUSDT','4h','0.023330000000000','0.022900000000000','16.001740473664103','15.706809123313672','685.886861280073','685.886861280073049','test'),('2019-08-06 07:59:59','2019-08-06 11:59:59','TRXUSDT','4h','0.022860000000000','0.022340000000000','16.001740473664103','15.637746377150311','699.9886471419119','699.988647141911883','test'),('2019-09-08 03:59:59','2019-09-08 07:59:59','TRXUSDT','4h','0.016060000000000','0.015630000000000','16.001740473664103','15.573300348902238','996.3723831671297','996.372383167129669','test'),('2019-09-08 23:59:59','2019-09-09 03:59:59','TRXUSDT','4h','0.015760000000000','0.015410000000000','16.001740473664103','15.646371871774354','1015.3388625421386','1015.338862542138600','test'),('2019-09-09 11:59:59','2019-09-09 15:59:59','TRXUSDT','4h','0.015800000000000','0.015680000000000','16.001740473664103','15.880208267535007','1012.7683844091204','1012.768384409120358','test'),('2019-09-10 03:59:59','2019-09-10 15:59:59','TRXUSDT','4h','0.015980000000000','0.015730000000000','16.001740473664103','15.751400353613038','1001.3604802042618','1001.360480204261762','test'),('2019-09-13 23:59:59','2019-09-14 03:59:59','TRXUSDT','4h','0.015510000000000','0.015290000000000','16.001740473664103','15.774765431484470','1031.7047371801486','1031.704737180148641','test'),('2019-09-14 15:59:59','2019-09-15 19:59:59','TRXUSDT','4h','0.015680000000000','0.015470000000000','16.001740473664103','15.787431449463243','1020.5191628612312','1020.519162861231166','test'),('2019-09-16 23:59:59','2019-09-22 19:59:59','TRXUSDT','4h','0.015650000000000','0.016580000000000','16.001740473664103','16.952642623217308','1022.4754296270992','1022.475429627099174','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','TRXUSDT','4h','0.014630000000000','0.014530000000000','16.001740473664103','15.892364257166056','1093.7621649804582','1093.762164980458238','test'),('2019-10-04 11:59:59','2019-10-05 15:59:59','TRXUSDT','4h','0.014420000000000','0.014710000000000','16.001740473664103','16.323550788321704','1109.6907401986202','1109.690740198620233','test'),('2019-10-19 15:59:59','2019-10-19 19:59:59','TRXUSDT','4h','0.015650000000000','0.015460000000000','16.001740473664103','15.807470142034953','1022.4754296270992','1022.475429627099174','test'),('2019-10-21 11:59:59','2019-10-21 15:59:59','TRXUSDT','4h','0.015630000000000','0.015420000000000','16.001740473664103','15.786745879968038','1023.7837795050609','1023.783779505060920','test'),('2019-10-22 03:59:59','2019-10-22 07:59:59','TRXUSDT','4h','0.015570000000000','0.015540000000000','16.001740473664103','15.970908603772649','1027.7289963817664','1027.728996381766365','test'),('2019-10-25 11:59:59','2019-11-04 07:59:59','TRXUSDT','4h','0.015410000000000','0.019090000000000','16.001740473664103','19.823051631554041','1038.3997711657432','1038.399771165743232','test'),('2019-11-10 07:59:59','2019-11-10 11:59:59','TRXUSDT','4h','0.019330000000000','0.019170000000000','16.226663621829509','16.092350834478619','839.4549209430683','839.454920943068259','test'),('2019-11-10 19:59:59','2019-11-11 03:59:59','TRXUSDT','4h','0.019420000000000','0.019190000000000','16.226663621829509','16.034483774609075','835.5645531323125','835.564553132312540','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','TRXUSDT','4h','0.019600000000000','0.019410000000000','16.226663621829509','16.069364331617898','827.8910011137505','827.891001113750463','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','TRXUSDT','4h','0.019410000000000','0.019030000000000','16.226663621829509','15.908985508676739','835.9950346125455','835.995034612545510','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 21:07:47
