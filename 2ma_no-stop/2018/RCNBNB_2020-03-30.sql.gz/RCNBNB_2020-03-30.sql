-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 19:59:59','2018-04-29 03:59:59','RCNBNB','4h','0.010250000000000','0.009980000000000','0.711908500000000','0.693155788292683','69.45448780487806','69.454487804878056','test'),('2018-04-29 15:59:59','2018-05-02 11:59:59','RCNBNB','4h','0.010290000000000','0.010810000000000','0.711908500000000','0.747884439747328','69.18449951409136','69.184499514091357','test'),('2018-05-08 03:59:59','2018-05-08 07:59:59','RCNBNB','4h','0.011120000000000','0.010930000000000','0.716214307010003','0.703976832339868','64.40776142176284','64.407761421762842','test'),('2018-05-14 07:59:59','2018-05-14 11:59:59','RCNBNB','4h','0.010180000000000','0.010330000000000','0.716214307010003','0.726767563007204','70.35503998133625','70.355039981336247','test'),('2018-07-01 15:59:59','2018-07-01 23:59:59','RCNBNB','4h','0.003258000000000','0.003188000000000','0.716214307010003','0.700826031537105','219.83250675567925','219.832506755679248','test'),('2018-07-10 15:59:59','2018-07-10 23:59:59','RCNBNB','4h','0.003673000000000','0.003393000000000','0.716214307010003','0.661615884477250','194.99436618840267','194.994366188402665','test'),('2018-07-15 11:59:59','2018-07-15 15:59:59','RCNBNB','4h','0.003498000000000','0.003487000000000','0.716214307010003','0.713962060761544','204.7496589508299','204.749658950829911','test'),('2018-07-16 23:59:59','2018-07-17 15:59:59','RCNBNB','4h','0.003537000000000','0.003460000000000','0.716214307010003','0.700622420767489','202.49202912355187','202.492029123551873','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','RCNBNB','4h','0.003624000000000','0.003643000000000','0.716214307010003','0.719969293718941','197.63087941777124','197.630879417771240','test'),('2018-07-22 23:59:59','2018-07-23 03:59:59','RCNBNB','4h','0.003652000000000','0.003510000000000','0.716214307010003','0.688365886529329','196.1156371878431','196.115637187843106','test'),('2018-07-23 15:59:59','2018-07-24 03:59:59','RCNBNB','4h','0.003956000000000','0.003517000000000','0.716214307010003','0.636735520160309','181.04507255055685','181.045072550556853','test'),('2018-07-24 11:59:59','2018-07-24 15:59:59','RCNBNB','4h','0.003584000000000','0.003580000000000','0.716214307010003','0.715414960685215','199.83658119698745','199.836581196987453','test'),('2018-07-24 23:59:59','2018-07-25 03:59:59','RCNBNB','4h','0.003691000000000','0.003475000000000','0.716214307010003','0.674300925727380','194.04343186399433','194.043431863994329','test'),('2018-07-29 15:59:59','2018-07-29 19:59:59','RCNBNB','4h','0.003553000000000','0.003425000000000','0.716214307010003','0.690412046582961','201.58015958626595','201.580159586265950','test'),('2018-07-30 07:59:59','2018-07-30 19:59:59','RCNBNB','4h','0.003541000000000','0.003449000000000','0.716214307010003','0.697606084404829','202.26328918667127','202.263289186671273','test'),('2018-08-19 03:59:59','2018-08-19 11:59:59','RCNBNB','4h','0.002137000000000','0.002107000000000','0.716214307010003','0.706159824459558','335.149418348153','335.149418348153006','test'),('2018-08-19 15:59:59','2018-08-19 23:59:59','RCNBNB','4h','0.002147000000000','0.002102000000000','0.716214307010003','0.701202828754088','333.5884056870065','333.588405687006514','test'),('2018-08-20 03:59:59','2018-08-20 15:59:59','RCNBNB','4h','0.002141000000000','0.002158000000000','0.716214307010003','0.721901202488364','334.52326343297665','334.523263432976648','test'),('2018-08-26 07:59:59','2018-08-27 07:59:59','RCNBNB','4h','0.002109000000000','0.002024000000000','0.716214307010003','0.687348391364744','339.59900759127686','339.599007591276859','test'),('2018-08-28 03:59:59','2018-08-28 11:59:59','RCNBNB','4h','0.002089000000000','0.002030000000000','0.716214307010003','0.695986138453952','342.85031450933604','342.850314509336044','test'),('2018-08-31 15:59:59','2018-08-31 23:59:59','RCNBNB','4h','0.002034000000000','0.001976000000000','0.716214307010003','0.695791283506276','352.12109489184024','352.121094891840244','test'),('2018-09-02 23:59:59','2018-09-03 03:59:59','RCNBNB','4h','0.002013000000000','0.001973000000000','0.716214307010003','0.701982527437027','355.79448932439294','355.794489324392941','test'),('2018-09-03 07:59:59','2018-09-03 11:59:59','RCNBNB','4h','0.002023000000000','0.001929000000000','0.716214307010003','0.682934947218139','354.03574246663516','354.035742466635156','test'),('2018-09-04 15:59:59','2018-09-05 11:59:59','RCNBNB','4h','0.002017000000000','0.001928000000000','0.716214307010003','0.684611395099299','355.08889787308027','355.088897873080271','test'),('2018-09-07 19:59:59','2018-09-07 23:59:59','RCNBNB','4h','0.002000000000000','0.001944000000000','0.716214307010003','0.696160306413723','358.10715350500146','358.107153505001463','test'),('2018-09-09 19:59:59','2018-09-11 19:59:59','RCNBNB','4h','0.002056000000000','0.002015000000000','0.716214307010003','0.701931823261263','348.3532621643983','348.353262164398302','test'),('2018-09-12 23:59:59','2018-09-13 03:59:59','RCNBNB','4h','0.002077000000000','0.002016000000000','0.716214307010003','0.695179606611539','344.83115407318394','344.831154073183939','test'),('2018-09-27 23:59:59','2018-09-28 03:59:59','RCNBNB','4h','0.002808000000000','0.002680000000000','0.716214307010003','0.683566361391313','255.06207514601246','255.062075146012461','test'),('2018-09-28 19:59:59','2018-09-29 03:59:59','RCNBNB','4h','0.002900000000000','0.002873000000000','0.716214307010003','0.709546104841289','246.9704506931045','246.970450693104510','test'),('2018-10-04 15:59:59','2018-10-04 23:59:59','RCNBNB','4h','0.002770000000000','0.002750000000000','0.716214307010003','0.711043084576718','258.561121664261','258.561121664261009','test'),('2018-10-08 15:59:59','2018-10-08 23:59:59','RCNBNB','4h','0.002792000000000','0.002789000000000','0.716214307010003','0.715444735763216','256.52374892908415','256.523748929084149','test'),('2018-10-11 11:59:59','2018-10-11 19:59:59','RCNBNB','4h','0.002839000000000','0.002829000000000','0.716214307010003','0.713691537348115','252.27696618879995','252.276966188799946','test'),('2018-10-12 11:59:59','2018-10-12 15:59:59','RCNBNB','4h','0.002835000000000','0.002709000000000','0.716214307010003','0.684382560031781','252.63291252557426','252.632912525574255','test'),('2018-10-13 19:59:59','2018-10-13 23:59:59','RCNBNB','4h','0.002872000000000','0.002788000000000','0.716214307010003','0.695266534799404','249.37824060236872','249.378240602368720','test'),('2018-10-14 07:59:59','2018-10-15 07:59:59','RCNBNB','4h','0.002890000000000','0.002615000000000','0.716214307010003','0.648062426585176','247.82501972664463','247.825019726644626','test'),('2018-10-17 11:59:59','2018-10-18 19:59:59','RCNBNB','4h','0.002833000000000','0.002812000000000','0.716214307010003','0.710905270494927','252.81126262266255','252.811262622662554','test'),('2018-10-26 19:59:59','2018-10-26 23:59:59','RCNBNB','4h','0.003003000000000','0.002992000000000','0.716214307010003','0.713590811379930','238.49960273393373','238.499602733933727','test'),('2018-10-27 23:59:59','2018-11-04 07:59:59','RCNBNB','4h','0.003588000000000','0.003350000000000','0.716214307010003','0.668706223100198','199.61379794035759','199.613797940357586','test'),('2018-11-06 03:59:59','2018-11-06 07:59:59','RCNBNB','4h','0.003540000000000','0.003430000000000','0.477476204673335','0.462639373454672','134.88028380602694','134.880283806026938','test'),('2018-11-12 15:59:59','2018-11-12 19:59:59','RCNBNB','4h','0.003510000000000','0.003530000000000','0.530569195135176','0.533592381432242','151.15931485332646','151.159314853326464','test'),('2018-11-27 15:59:59','2018-11-27 19:59:59','RCNBNB','4h','0.002938000000000','0.002903000000000','0.531324991709442','0.524995388336457','180.8458106567196','180.845810656719607','test'),('2019-01-15 11:59:59','2019-01-15 23:59:59','RCNBNB','4h','0.001898000000000','0.001889000000000','0.531324991709442','0.528805537059608','279.9394055371138','279.939405537113828','test'),('2019-01-18 03:59:59','2019-01-18 11:59:59','RCNBNB','4h','0.002010000000000','0.001912000000000','0.531324991709442','0.505419594103708','264.34079189524476','264.340791895244763','test'),('2019-01-18 23:59:59','2019-01-19 11:59:59','RCNBNB','4h','0.001935000000000','0.001935000000000','0.531324991709442','0.531324991709442','274.58655902296744','274.586559022967435','test'),('2019-01-20 11:59:59','2019-01-20 15:59:59','RCNBNB','4h','0.001919000000000','0.001936000000000','0.531324991709442','0.536031883246211','276.8759727511423','276.875972751142285','test'),('2019-01-23 07:59:59','2019-01-23 15:59:59','RCNBNB','4h','0.001950000000000','0.001922000000000','0.531324991709442','0.523695709777204','272.4743547227908','272.474354722790792','test'),('2019-01-29 19:59:59','2019-01-31 11:59:59','RCNBNB','4h','0.001835000000000','0.001779000000000','0.531324991709442','0.515110169074168','289.5504042013308','289.550404201330821','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','RCNBNB','4h','0.001278000000000','0.001200000000000','0.531324991709442','0.498896705830462','415.7472548587183','415.747254858718293','test'),('2019-02-21 23:59:59','2019-03-03 15:59:59','RCNBNB','4h','0.001531000000000','0.001731000000000','0.531324991709442','0.600733873709369','347.04440999963555','347.044409999635548','test'),('2019-03-04 15:59:59','2019-03-04 19:59:59','RCNBNB','4h','0.001807000000000','0.001810000000000','0.531324991709442','0.532207102929768','294.03707344186057','294.037073441860571','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','RCNBNB','4h','0.001670000000000','0.001611000000000','0.531324991709442','0.512553629726893','318.15867767032455','318.158677670324550','test'),('2019-03-09 07:59:59','2019-03-09 23:59:59','RCNBNB','4h','0.001712000000000','0.001643000000000','0.531324991709442','0.509910608281900','310.3533830078517','310.353383007851676','test'),('2019-03-10 15:59:59','2019-03-10 19:59:59','RCNBNB','4h','0.001670000000000','0.001653000000000','0.531324991709442','0.525916294189047','318.15867767032455','318.158677670324550','test'),('2019-03-15 15:59:59','2019-03-16 11:59:59','RCNBNB','4h','0.001603000000000','0.001559000000000','0.531324991709442','0.516740899610119','331.4566386209869','331.456638620986894','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','RCNBNB','4h','0.001598000000000','0.001604000000000','0.531324991709442','0.533319954131380','332.4937369896383','332.493736989638307','test'),('2019-03-19 19:59:59','2019-03-20 19:59:59','RCNBNB','4h','0.001595000000000','0.001618000000000','0.531324991709442','0.538986731401804','333.1191170592113','333.119117059211305','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','RCNBNB','4h','0.001594000000000','0.001582000000000','0.531324991709442','0.527325054507113','333.32810019412926','333.328100194129263','test'),('2019-03-27 23:59:59','2019-03-28 03:59:59','RCNBNB','4h','0.001506000000000','0.001488000000000','0.531324991709442','0.524974493800564','352.8054393820996','352.805439382099621','test'),('2019-03-28 07:59:59','2019-03-29 15:59:59','RCNBNB','4h','0.001532000000000','0.001584000000000','0.531324991709442','0.549359521454149','346.8178797059021','346.817879705902101','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','RCNBNB','4h','0.001645000000000','0.001644000000000','0.531324991709442','0.531001997793509','322.99391593279154','322.993915932791538','test'),('2019-04-07 19:59:59','2019-04-09 11:59:59','RCNBNB','4h','0.001647000000000','0.001653000000000','0.531324991709442','0.533260601879604','322.60169502698363','322.601695026983634','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','RCNBNB','4h','0.001681000000000','0.001654000000000','0.531324991709442','0.522790919861640','316.07673510377276','316.076735103772762','test'),('2019-04-16 23:59:59','2019-04-17 07:59:59','RCNBNB','4h','0.001658000000000','0.001647000000000','0.531324991709442','0.527799916372407','320.4613942758999','320.461394275899920','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  1:12:13
