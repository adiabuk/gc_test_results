-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-20 15:59:59','2018-06-20 19:59:59','BRDBNB','4h','0.030360000000000','0.030190000000000','0.711908500000000','0.707922187582345','23.448896574440052','23.448896574440052','test'),('2018-06-25 03:59:59','2018-06-25 07:59:59','BRDBNB','4h','0.029040000000000','0.027900000000000','0.711908500000000','0.683961678719008','24.514755509641876','24.514755509641876','test'),('2018-06-26 23:59:59','2018-06-27 03:59:59','BRDBNB','4h','0.029110000000000','0.027610000000000','0.711908500000000','0.675224791652353','24.455805565097904','24.455805565097904','test'),('2018-06-27 11:59:59','2018-06-27 23:59:59','BRDBNB','4h','0.029010000000000','0.029440000000000','0.711908500000000','0.722460745949673','24.540106859703553','24.540106859703553','test'),('2018-06-28 19:59:59','2018-06-29 03:59:59','BRDBNB','4h','0.029260000000000','0.028240000000000','0.711908500000000','0.687091457279563','24.330434039644565','24.330434039644565','test'),('2018-06-29 11:59:59','2018-07-07 11:59:59','BRDBNB','4h','0.029130000000000','0.033370000000000','0.711908500000000','0.815529922588397','24.439014761414352','24.439014761414352','test'),('2018-07-07 23:59:59','2018-07-08 11:59:59','BRDBNB','4h','0.033960000000000','0.032810000000000','0.717093445942835','0.692810246212733','21.11582585226251','21.115825852262510','test'),('2018-07-12 03:59:59','2018-07-12 07:59:59','BRDBNB','4h','0.033500000000000','0.031860000000000','0.717093445942835','0.681987975753395','21.405774505756266','21.405774505756266','test'),('2018-07-12 11:59:59','2018-07-12 15:59:59','BRDBNB','4h','0.032660000000000','0.031990000000000','0.717093445942835','0.702382710830107','21.956321063773267','21.956321063773267','test'),('2018-07-14 15:59:59','2018-07-16 07:59:59','BRDBNB','4h','0.033230000000000','0.031310000000000','0.717093445942835','0.675660421079451','21.579700449679052','21.579700449679052','test'),('2018-07-18 03:59:59','2018-07-18 15:59:59','BRDBNB','4h','0.034980000000000','0.032500000000000','0.717093445942835','0.666253201633566','20.50009851180203','20.500098511802030','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','BRDBNB','4h','0.033140000000000','0.032530000000000','0.717093445942835','0.703894079557044','21.638305550477817','21.638305550477817','test'),('2018-07-21 07:59:59','2018-07-21 11:59:59','BRDBNB','4h','0.032770000000000','0.032370000000000','0.717093445942835','0.708340398082684','21.88261965037641','21.882619650376409','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','BRDBNB','4h','0.033020000000000','0.032650000000000','0.717093445942835','0.709058177166371','21.71694263909252','21.716942639092519','test'),('2018-07-23 11:59:59','2018-07-24 03:59:59','BRDBNB','4h','0.033060000000000','0.032970000000000','0.717093445942835','0.715141285926657','21.690666846425742','21.690666846425742','test'),('2018-08-07 07:59:59','2018-08-07 15:59:59','BRDBNB','4h','0.028320000000000','0.027340000000000','0.717093445942835','0.692278771612892','25.321096255043607','25.321096255043607','test'),('2018-08-11 15:59:59','2018-08-12 03:59:59','BRDBNB','4h','0.028380000000000','0.028170000000000','0.717093445942835','0.711787257653617','25.267563281988547','25.267563281988547','test'),('2018-08-12 19:59:59','2018-08-13 07:59:59','BRDBNB','4h','0.029910000000000','0.027900000000000','0.717093445942835','0.668903615573557','23.975039984715313','23.975039984715313','test'),('2018-08-13 19:59:59','2018-08-14 15:59:59','BRDBNB','4h','0.030210000000000','0.028750000000000','0.717093445942835','0.682437489932357','23.736956171560244','23.736956171560244','test'),('2018-09-08 07:59:59','2018-09-08 11:59:59','BRDBNB','4h','0.032030000000000','0.032300000000000','0.717093445942835','0.723138254884595','22.388181265776925','22.388181265776925','test'),('2018-09-09 03:59:59','2018-09-10 07:59:59','BRDBNB','4h','0.035290000000000','0.032510000000000','0.717093445942835','0.660603795058134','20.320018303849107','20.320018303849107','test'),('2018-09-12 11:59:59','2018-09-13 19:59:59','BRDBNB','4h','0.035310000000000','0.032890000000000','0.717093445942835','0.667946854632111','20.30850880608425','20.308508806084252','test'),('2018-09-14 15:59:59','2018-09-14 19:59:59','BRDBNB','4h','0.034000000000000','0.032620000000000','0.717093445942835','0.687987888431038','21.090983704201026','21.090983704201026','test'),('2018-09-15 15:59:59','2018-09-15 19:59:59','BRDBNB','4h','0.032720000000000','0.032480000000000','0.717093445942835','0.711833591816115','21.91605886133359','21.916058861333589','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','BRDBNB','4h','0.034390000000000','0.033140000000000','0.717093445942835','0.691028694345611','20.851801277779444','20.851801277779444','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','BRDBNB','4h','0.034160000000000','0.033990000000000','0.717093445942835','0.713524772470637','20.992196895282053','20.992196895282053','test'),('2018-09-18 11:59:59','2018-09-19 03:59:59','BRDBNB','4h','0.033960000000000','0.033630000000000','0.717093445942835','0.710125223411588','21.115825852262514','21.115825852262514','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','BRDBNB','4h','0.034530000000000','0.034990000000000','0.717093445942835','0.726646384985224','20.767258787802927','20.767258787802927','test'),('2018-09-26 19:59:59','2018-09-26 23:59:59','BRDBNB','4h','0.034900000000000','0.033710000000000','0.717093445942835','0.692642408674297','20.54709014162851','20.547090141628509','test'),('2018-09-27 03:59:59','2018-09-27 07:59:59','BRDBNB','4h','0.034900000000000','0.034100000000000','0.717093445942835','0.700655773829532','20.54709014162851','20.547090141628509','test'),('2018-09-27 11:59:59','2018-09-27 19:59:59','BRDBNB','4h','0.035060000000000','0.034990000000000','0.717093445942835','0.715661713449509','20.453321333224043','20.453321333224043','test'),('2018-09-30 03:59:59','2018-09-30 07:59:59','BRDBNB','4h','0.035050000000000','0.034410000000000','0.717093445942835','0.703999585588957','20.45915680293395','20.459156802933951','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','BRDBNB','4h','0.034990000000000','0.035170000000000','0.717093445942835','0.720782409082867','20.494239666842955','20.494239666842955','test'),('2018-10-04 19:59:59','2018-10-05 03:59:59','BRDBNB','4h','0.039130000000000','0.034200000000000','0.717093445942835','0.626746635605545','18.32592501770598','18.325925017705980','test'),('2018-10-06 11:59:59','2018-10-07 15:59:59','BRDBNB','4h','0.035060000000000','0.034680000000000','0.717093445942835','0.709321183836210','20.453321333224043','20.453321333224043','test'),('2018-10-08 11:59:59','2018-10-15 07:59:59','BRDBNB','4h','0.035060000000000','0.036520000000000','0.717093445942835','0.746955295089342','20.453321333224043','20.453321333224043','test'),('2018-10-16 11:59:59','2018-10-18 15:59:59','BRDBNB','4h','0.039480000000000','0.036650000000000','0.717093445942835','0.665690850906912','18.163461143435537','18.163461143435537','test'),('2018-10-19 11:59:59','2018-10-20 03:59:59','BRDBNB','4h','0.038280000000000','0.037640000000000','0.717093445942835','0.705104422813174','18.732848640094957','18.732848640094957','test'),('2018-10-29 15:59:59','2018-10-29 19:59:59','BRDBNB','4h','0.039400000000000','0.039140000000000','0.717093445942835','0.712361357213263','18.200341267584644','18.200341267584644','test'),('2018-11-10 15:59:59','2018-11-11 03:59:59','BRDBNB','4h','0.036690000000000','0.036240000000000','0.717093445942835','0.708298350530617','19.544656471595392','19.544656471595392','test'),('2018-11-11 07:59:59','2018-11-12 03:59:59','BRDBNB','4h','0.038300000000000','0.036200000000000','0.717093445942835','0.677775006348058','18.723066473703263','18.723066473703263','test'),('2018-11-13 15:59:59','2018-11-14 01:59:59','BRDBNB','4h','0.037270000000000','0.036560000000000','0.717093445942835','0.703432690734372','19.240500293609742','19.240500293609742','test'),('2018-11-16 03:59:59','2018-11-16 07:59:59','BRDBNB','4h','0.036850000000000','0.035910000000000','0.478062297295223','0.465867492425277','12.973196670155314','12.973196670155314','test'),('2018-11-16 11:59:59','2018-11-19 19:59:59','BRDBNB','4h','0.037810000000000','0.038500000000000','0.533503424927868','0.543239403854084','14.11011438582037','14.110114385820371','test'),('2018-11-28 07:59:59','2018-11-28 15:59:59','BRDBNB','4h','0.045660000000000','0.044100000000000','0.535937419659422','0.517626811366196','11.73756941873461','11.737569418734610','test'),('2018-11-30 15:59:59','2018-11-30 23:59:59','BRDBNB','4h','0.048800000000000','0.044440000000000','0.535937419659422','0.488054486263621','10.982324173348811','10.982324173348811','test'),('2018-12-01 07:59:59','2018-12-02 15:59:59','BRDBNB','4h','0.044900000000000','0.045210000000000','0.535937419659422','0.539637655741703','11.936245426713183','11.936245426713183','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','BRDBNB','4h','0.043220000000000','0.041900000000000','0.535937419659422','0.519569131969685','12.400217946770523','12.400217946770523','test'),('2018-12-08 23:59:59','2018-12-09 03:59:59','BRDBNB','4h','0.042280000000000','0.041770000000000','0.535937419659422','0.529472706224552','12.675908695823605','12.675908695823605','test'),('2018-12-27 23:59:59','2018-12-28 03:59:59','BRDBNB','4h','0.037170000000000','0.034830000000000','0.535937419659422','0.502198017937521','14.41854774440199','14.418547744401989','test'),('2018-12-30 15:59:59','2018-12-30 19:59:59','BRDBNB','4h','0.037090000000000','0.035120000000000','0.535937419659422','0.507471614409245','14.44964733511518','14.449647335115181','test'),('2019-01-02 15:59:59','2019-01-02 23:59:59','BRDBNB','4h','0.036690000000000','0.035820000000000','0.535937419659422','0.523229173404211','14.607179603690978','14.607179603690978','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','BRDBNB','4h','0.033360000000000','0.034100000000000','0.535937419659422','0.547825719735800','16.065270373483873','16.065270373483873','test'),('2019-01-19 03:59:59','2019-01-19 19:59:59','BRDBNB','4h','0.033620000000000','0.032400000000000','0.535937419659422','0.516489363383857','15.941029734069662','15.941029734069662','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','BRDBNB','4h','0.034040000000000','0.032050000000000','0.535937419659422','0.504606178028334','15.744342528185134','15.744342528185134','test'),('2019-01-24 15:59:59','2019-01-25 11:59:59','BRDBNB','4h','0.033240000000000','0.032340000000000','0.535937419659422','0.521426478693914','16.12326773945313','16.123267739453130','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','BRDBNB','4h','0.032470000000000','0.030140000000000','0.535937419659422','0.497479329489836','16.505618098534708','16.505618098534708','test'),('2019-01-28 23:59:59','2019-01-29 03:59:59','BRDBNB','4h','0.031440000000000','0.031130000000000','0.535937419659422','0.530653049427411','17.046355587131742','17.046355587131742','test'),('2019-01-29 07:59:59','2019-01-31 15:59:59','BRDBNB','4h','0.031700000000000','0.032470000000000','0.535937419659422','0.548955457928752','16.906543206921828','16.906543206921828','test'),('2019-02-25 19:59:59','2019-02-26 07:59:59','BRDBNB','4h','0.022260000000000','0.022010000000000','0.535937419659422','0.529918356096311','24.076254252444834','24.076254252444834','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','BRDBNB','4h','0.022420000000000','0.015660000000000','0.535937419659422','0.374343442991372','23.904434418350668','23.904434418350668','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','BRDBNB','4h','0.017310000000000','0.017020000000000','0.535937419659422','0.526958687614290','30.961144983213288','30.961144983213288','test'),('2019-03-15 15:59:59','2019-03-16 11:59:59','BRDBNB','4h','0.017790000000000','0.016670000000000','0.535937419659422','0.502196559062539','30.12576839007431','30.125768390074310','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','BRDBNB','4h','0.016840000000000','0.016590000000000','0.535937419659422','0.527981104046901','31.82526245008444','31.825262450084441','test'),('2019-03-23 15:59:59','2019-03-24 11:59:59','BRDBNB','4h','0.017010000000000','0.014870000000000','0.535937419659422','0.468512018244304','31.507196922952495','31.507196922952495','test'),('2019-03-27 03:59:59','2019-03-27 11:59:59','BRDBNB','4h','0.016800000000000','0.016480000000000','0.535937419659422','0.525729087856386','31.901036884489407','31.901036884489407','test'),('2019-03-31 19:59:59','2019-03-31 23:59:59','BRDBNB','4h','0.017100000000000','0.016830000000000','0.357291613106281','0.351650166583550','20.894246380484287','20.894246380484287','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','BRDBNB','4h','0.016850000000000','0.016970000000000','0.399454857381104','0.402299639748210','23.706519725881527','23.706519725881527','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','BRDBNB','4h','0.017280000000000','0.016310000000000','0.400166052972880','0.377703028008546','23.15775769518983','23.157757695189829','test'),('2019-04-05 03:59:59','2019-04-11 11:59:59','BRDBNB','4h','0.016780000000000','0.016860000000000','0.400166052972880','0.402073876824956','23.847798150946364','23.847798150946364','test'),('2019-04-12 23:59:59','2019-04-13 03:59:59','BRDBNB','4h','0.018740000000000','0.017420000000000','0.400166052972880','0.371979329924630','21.353578066855924','21.353578066855924','test'),('2019-04-29 15:59:59','2019-05-13 23:59:59','BRDBNB','4h','0.014190000000000','0.019940000000000','0.400166052972880','0.562319316157803','28.200567510421426','28.200567510421426','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','BRDBNB','4h','0.019740000000000','0.019200000000000','0.428518887728984','0.416796486544908','21.708150340880646','21.708150340880646','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  4:29:40
