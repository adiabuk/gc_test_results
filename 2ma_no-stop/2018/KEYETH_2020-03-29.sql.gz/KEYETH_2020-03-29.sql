-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-12 19:59:59','2018-12-13 03:59:59','KEYETH','4h','0.000028880000000','0.000028150000000','0.072144500000000','0.070320902873961','2498.0782548476454','2498.078254847645439','test'),('2018-12-17 03:59:59','2018-12-17 07:59:59','KEYETH','4h','0.000027940000000','0.000028000000000','0.072144500000000','0.072299427344309','2582.122405153901','2582.122405153901127','test'),('2019-01-09 03:59:59','2019-01-09 07:59:59','KEYETH','4h','0.000019880000000','0.000020180000000','0.072144500000000','0.073233199698189','3628.9989939637826','3628.998993963782596','test'),('2019-02-01 11:59:59','2019-02-02 11:59:59','KEYETH','4h','0.000025230000000','0.000024980000000','0.072144500000000','0.071429631787555','2859.4728497820056','2859.472849782005596','test'),('2019-02-06 11:59:59','2019-02-06 19:59:59','KEYETH','4h','0.000025100000000','0.000024820000000','0.072144500000000','0.071339700796813','2874.2828685258964','2874.282868525896447','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','KEYETH','4h','0.000024900000000','0.000023740000000','0.072144500000000','0.068783551405622','2897.3694779116468','2897.369477911646754','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','KEYETH','4h','0.000019550000000','0.000020530000000','0.072144500000000','0.075760950639386','3690.2557544757033','3690.255754475703270','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','KEYETH','4h','0.000019480000000','0.000019390000000','0.072144500000000','0.071811183521561','3703.516427104723','3703.516427104722879','test'),('2019-03-09 07:59:59','2019-03-09 11:59:59','KEYETH','4h','0.000019430000000','0.000019350000000','0.072144500000000','0.071847456253217','3713.04683479156','3713.046834791559832','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','KEYETH','4h','0.000019510000000','0.000020330000000','0.072144500000000','0.075176713736545','3697.821629933367','3697.821629933367149','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','KEYETH','4h','0.000020730000000','0.000020600000000','0.072283929514289','0.071830629425680','3486.923758528196','3486.923758528195776','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','KEYETH','4h','0.000020620000000','0.000020300000000','0.072283929514289','0.071162161451992','3505.5251946793887','3505.525194679388733','test'),('2019-03-18 19:59:59','2019-03-19 15:59:59','KEYETH','4h','0.000020730000000','0.000020600000000','0.072283929514289','0.071830629425680','3486.9237585281717','3486.923758528171675','test'),('2019-03-27 07:59:59','2019-03-29 03:59:59','KEYETH','4h','0.000021640000000','0.000021720000000','0.072283929514289','0.072551152913602','3340.292491418161','3340.292491418160807','test'),('2019-03-31 15:59:59','2019-04-02 15:59:59','KEYETH','4h','0.000022220000000','0.000022140000000','0.072283929514289','0.072023681343220','3253.1021383568404','3253.102138356840442','test'),('2019-04-04 03:59:59','2019-04-04 07:59:59','KEYETH','4h','0.000021880000000','0.000021790000000','0.072283929514289','0.071986600736579','3303.6530856622026','3303.653085662202557','test'),('2019-04-05 07:59:59','2019-04-05 11:59:59','KEYETH','4h','0.000021810000000','0.000021290000000','0.072283929514289','0.070560516247557','3314.2562821773954','3314.256282177395406','test'),('2019-04-30 19:59:59','2019-05-03 23:59:59','KEYETH','4h','0.000017740000000','0.000017700000000','0.072283929514289','0.072120944329364','4074.629623127903','4074.629623127902960','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','KEYETH','4h','0.000018210000000','0.000018050000000','0.072283929514289','0.071648815361500','3969.463454930752','3969.463454930752050','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','KEYETH','4h','0.000017400000000','0.000016570000000','0.072283929514289','0.068835902991481','4154.248822660287','4154.248822660287260','test'),('2019-05-10 23:59:59','2019-05-11 03:59:59','KEYETH','4h','0.000016930000000','0.000016890000000','0.072283929514289','0.072113146455779','4269.576462745954','4269.576462745953904','test'),('2019-05-12 03:59:59','2019-05-12 07:59:59','KEYETH','4h','0.000016900000000','0.000016480000000','0.072283929514289','0.070487524165413','4277.155592561479','4277.155592561479352','test'),('2019-05-12 11:59:59','2019-05-12 15:59:59','KEYETH','4h','0.000017110000000','0.000016620000000','0.072283929514289','0.070213846202658','4224.659819654529','4224.659819654529201','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','KEYETH','4h','0.000016920000000','0.000016440000000','0.072283929514289','0.070233321584806','4272.099853090366','4272.099853090366196','test'),('2019-05-13 03:59:59','2019-05-13 07:59:59','KEYETH','4h','0.000016920000000','0.000017410000000','0.072283929514289','0.074377258442303','4272.099853090366','4272.099853090366196','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','KEYETH','4h','0.000015350000000','0.000015350000000','0.072283929514289','0.072283929514289','4709.0507826898365','4709.050782689836524','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','KEYETH','4h','0.000015270000000','0.000014470000000','0.072283929514289','0.068496952198544','4733.721644681663','4733.721644681662838','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','KEYETH','4h','0.000014690000000','0.000014340000000','0.072283929514289','0.070561711996930','4920.621478168074','4920.621478168073736','test'),('2019-05-31 11:59:59','2019-05-31 15:59:59','KEYETH','4h','0.000014480000000','0.000014680000000','0.072283929514289','0.073282326330785','4991.9840824785215','4991.984082478521486','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','KEYETH','4h','0.000014540000000','0.000014000000000','0.072283929514289','0.069599381925725','4971.384423266093','4971.384423266093108','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','KEYETH','4h','0.000014230000000','0.000014140000000','0.072283929514289','0.071826757788619','5079.685840779269','5079.685840779268801','test'),('2019-06-07 07:59:59','2019-06-07 15:59:59','KEYETH','4h','0.000014250000000','0.000014280000000','0.072283929514289','0.072436106208003','5072.556457143087','5072.556457143086845','test'),('2019-06-10 03:59:59','2019-06-10 11:59:59','KEYETH','4h','0.000014220000000','0.000014160000000','0.072283929514289','0.071978934031106','5083.258053044234','5083.258053044233748','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','KEYETH','4h','0.000011010000000','0.000011280000000','0.072283929514289','0.074056559938345','6565.297866874568','6565.297866874568172','test'),('2019-07-15 03:59:59','2019-07-15 11:59:59','KEYETH','4h','0.000009530000000','0.000009430000000','0.072283929514289','0.071525441271747','7584.882425423819','7584.882425423818859','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','KEYETH','4h','0.000009400000000','0.000009640000000','0.072283929514289','0.074129476650824','7689.77973556266','7689.779735562659880','test'),('2019-07-19 11:59:59','2019-07-20 03:59:59','KEYETH','4h','0.000009620000000','0.000009400000000','0.072283929514289','0.070630866677164','7513.921986932329','7513.921986932328764','test'),('2019-07-20 23:59:59','2019-07-21 07:59:59','KEYETH','4h','0.000009600000000','0.000009490000000','0.072283929514289','0.071455676155271','7529.575991071771','7529.575991071770659','test'),('2019-07-21 19:59:59','2019-07-21 23:59:59','KEYETH','4h','0.000009560000000','0.000009510000000','0.072283929514289','0.071905875489633','7561.080493126464','7561.080493126463807','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','KEYETH','4h','0.000009610000000','0.000009290000000','0.072283929514289','0.069876972444094','7521.740844358897','7521.740844358897448','test'),('2019-07-29 11:59:59','2019-07-31 11:59:59','KEYETH','4h','0.000011360000000','0.000009480000000','0.072283929514289','0.060321448221431','6363.021964286004','6363.021964286003822','test'),('2019-08-01 03:59:59','2019-08-01 07:59:59','KEYETH','4h','0.000009580000000','0.000009390000000','0.072283929514289','0.070850323396573','7545.295356397599','7545.295356397598880','test'),('2019-08-09 11:59:59','2019-08-09 15:59:59','KEYETH','4h','0.000008970000000','0.000009010000000','0.072283929514289','0.072606265877786','8058.40908743467','8058.409087434670255','test'),('2019-08-11 07:59:59','2019-08-11 15:59:59','KEYETH','4h','0.000008920000000','0.000008750000000','0.072283929514289','0.070906320992156','8103.57954196065','8103.579541960650204','test'),('2019-08-12 15:59:59','2019-08-12 19:59:59','KEYETH','4h','0.000008750000000','0.000008630000000','0.072283929514289','0.071292607052379','8261.020515918743','8261.020515918742603','test'),('2019-08-13 03:59:59','2019-08-13 07:59:59','KEYETH','4h','0.000008830000000','0.000008530000000','0.072283929514289','0.069828076869409','8186.175482931936','8186.175482931936131','test'),('2019-08-15 01:59:59','2019-08-15 11:59:59','KEYETH','4h','0.000008710000000','0.000008710000000','0.072283929514289','0.072283929514289','8298.958612432722','8298.958612432721566','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','KEYETH','4h','0.000008370000000','0.000008330000000','0.072283929514289','0.071938486601437','8636.072821300955','8636.072821300955184','test'),('2019-08-22 07:59:59','2019-08-22 11:59:59','KEYETH','4h','0.000008280000000','0.000008110000000','0.072283929514289','0.070799839174020','8729.943178054225','8729.943178054225427','test'),('2019-08-24 07:59:59','2019-08-24 11:59:59','KEYETH','4h','0.000008200000000','0.000008690000000','0.072283929514289','0.076603335058436','8815.113355401098','8815.113355401097579','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','KEYETH','4h','0.000008630000000','0.000008570000000','0.072283929514289','0.071781376122533','8375.889862605909','8375.889862605909002','test'),('2019-09-09 19:59:59','2019-09-10 11:59:59','KEYETH','4h','0.000008420000000','0.000008620000000','0.072283929514289','0.074000887459997','8584.789728537886','8584.789728537885821','test'),('2019-09-18 07:59:59','2019-09-18 15:59:59','KEYETH','4h','0.000008120000000','0.000007960000000','0.072283929514289','0.070859615632234','8901.961762843472','8901.961762843471661','test'),('2019-09-23 11:59:59','2019-09-23 15:59:59','KEYETH','4h','0.000007600000000','0.000007440000000','0.072283929514289','0.070762162577146','9511.04335714329','9511.043357143289541','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','KEYETH','4h','0.000007480000000','0.000007290000000','0.072283929514289','0.070447840395611','9663.626940412967','9663.626940412967087','test'),('2019-09-25 03:59:59','2019-09-25 07:59:59','KEYETH','4h','0.000007430000000','0.000007340000000','0.072283929514289','0.071408350287333','9728.65807729327','9728.658077293270253','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','KEYETH','4h','0.000007540000000','0.000007300000000','0.072283929514289','0.069983114781739','9586.72805229297','9586.728052292970460','test'),('2019-10-01 11:59:59','2019-10-01 19:59:59','KEYETH','4h','0.000007330000000','0.000007160000000','0.072283929514289','0.070607494586945','9861.381925551023','9861.381925551022505','test'),('2019-10-03 15:59:59','2019-10-06 23:59:59','KEYETH','4h','0.000007380000000','0.000007460000000','0.072283929514289','0.073067495145880','9794.570394890108','9794.570394890108219','test'),('2019-10-19 03:59:59','2019-10-23 15:59:59','KEYETH','4h','0.000008090000000','0.000008060000000','0.072283929514289','0.072015880331912','8934.972745894807','8934.972745894807304','test'),('2019-11-01 03:59:59','2019-11-01 11:59:59','KEYETH','4h','0.000007630000000','0.000007680000000','0.072283929514289','0.072757611883321','9473.64738064076','9473.647380640759366','test'),('2019-11-02 23:59:59','2019-11-03 19:59:59','KEYETH','4h','0.000007610000000','0.000007640000000','0.072283929514289','0.072568885872427','9498.545271260053','9498.545271260052687','test'),('2019-11-07 03:59:59','2019-11-14 07:59:59','KEYETH','4h','0.000008120000000','0.000008730000000','0.072283929514289','0.077714126189624','8901.961762843472','8901.961762843471661','test'),('2019-11-15 07:59:59','2019-11-17 15:59:59','KEYETH','4h','0.000009740000000','0.000008990000000','0.072283929514289','0.066717918514729','7421.347999413655','7421.347999413655089','test'),('2019-11-18 19:59:59','2019-11-19 07:59:59','KEYETH','4h','0.000009100000000','0.000008820000000','0.072283929514289','0.070059808606157','7943.288957614176','7943.288957614176070','test'),('2019-11-20 07:59:59','2019-11-25 15:59:59','KEYETH','4h','0.000009330000000','0.000011840000000','0.072283929514289','0.091730088472581','7747.473688562593','7747.473688562593452','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','KEYETH','4h','0.000013920000000','0.000014000000000','0.072283929514289','0.072699354396555','5192.811028325359','5192.811028325359075','test'),('2019-12-08 15:59:59','2019-12-10 03:59:59','KEYETH','4h','0.000014550000000','0.000013150000000','0.072283929514289','0.065328774784392','4967.967664212302','4967.967664212302225','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:24:02
