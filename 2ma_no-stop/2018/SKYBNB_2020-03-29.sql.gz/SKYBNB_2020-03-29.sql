-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-08 03:59:59','2018-11-08 07:59:59','SKYBNB','4h','0.332000000000000','0.314000000000000','0.711908500000000','0.673311051204819','2.1443027108433736','2.144302710843374','test'),('2018-11-11 19:59:59','2018-11-11 23:59:59','SKYBNB','4h','0.318000000000000','0.307000000000000','0.711908500000000','0.687282734276730','2.2387059748427673','2.238705974842767','test'),('2018-11-12 03:59:59','2018-11-12 19:59:59','SKYBNB','4h','0.327000000000000','0.319000000000000','0.711908500000000','0.694491778287462','2.1770902140672783','2.177090214067278','test'),('2018-11-24 11:59:59','2018-11-24 23:59:59','SKYBNB','4h','0.275000000000000','0.244000000000000','0.711908500000000','0.631656996363636','2.5887581818181817','2.588758181818182','test'),('2018-11-27 11:59:59','2018-11-27 15:59:59','SKYBNB','4h','0.268000000000000','0.268000000000000','0.711908500000000','0.711908500000000','2.656375','2.656375000000000','test'),('2018-12-19 03:59:59','2018-12-21 11:59:59','SKYBNB','4h','0.205000000000000','0.214000000000000','0.711908500000000','0.743163019512195','3.472724390243903','3.472724390243903','test'),('2019-01-03 11:59:59','2019-01-03 15:59:59','SKYBNB','4h','0.184000000000000','0.176000000000000','0.711908500000000','0.680955956521739','3.869067934782609','3.869067934782609','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','SKYBNB','4h','0.178000000000000','0.172000000000000','0.711908500000000','0.687911584269663','3.9994859550561803','3.999485955056180','test'),('2019-01-06 19:59:59','2019-01-07 11:59:59','SKYBNB','4h','0.180000000000000','0.177000000000000','0.711908500000000','0.700043358333333','3.955047222222223','3.955047222222223','test'),('2019-01-14 15:59:59','2019-01-14 23:59:59','SKYBNB','4h','0.170000000000000','0.167000000000000','0.711908500000000','0.699345408823529','4.187697058823529','4.187697058823529','test'),('2019-01-19 03:59:59','2019-01-19 15:59:59','SKYBNB','4h','0.170000000000000','0.166000000000000','0.711908500000000','0.695157711764706','4.187697058823529','4.187697058823529','test'),('2019-01-24 15:59:59','2019-01-25 03:59:59','SKYBNB','4h','0.162000000000000','0.160000000000000','0.711908500000000','0.703119506172839','4.394496913580247','4.394496913580247','test'),('2019-01-30 07:59:59','2019-01-30 11:59:59','SKYBNB','4h','0.156000000000000','0.153000000000000','0.711908500000000','0.698217951923077','4.563516025641026','4.563516025641026','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','SKYBNB','4h','0.103000000000000','0.103000000000000','0.711908500000000','0.711908500000000','6.911733009708739','6.911733009708739','test'),('2019-02-27 23:59:59','2019-02-28 07:59:59','SKYBNB','4h','0.104000000000000','0.104000000000000','0.711908500000000','0.711908500000000','6.84527403846154','6.845274038461540','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','SKYBNB','4h','0.106000000000000','0.099000000000000','0.711908500000000','0.664895674528302','6.7161179245283025','6.716117924528302','test'),('2019-03-03 23:59:59','2019-03-04 07:59:59','SKYBNB','4h','0.108000000000000','0.102000000000000','0.711908500000000','0.672358027777778','6.591745370370371','6.591745370370371','test'),('2019-03-20 15:59:59','2019-03-20 23:59:59','SKYBNB','4h','0.075000000000000','0.073000000000000','0.711908500000000','0.692924273333333','9.492113333333334','9.492113333333334','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','SKYBNB','4h','0.074000000000000','0.073000000000000','0.711908500000000','0.702288114864865','9.620385135135136','9.620385135135136','test'),('2019-03-27 19:59:59','2019-03-28 03:59:59','SKYBNB','4h','0.070000000000000','0.070000000000000','0.711908500000000','0.711908500000000','10.170121428571429','10.170121428571429','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','SKYBNB','4h','0.072000000000000','0.078000000000000','0.711908500000000','0.771234208333333','9.887618055555556','9.887618055555556','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','SKYBNB','4h','0.076000000000000','0.075000000000000','0.711908500000000','0.702541282894737','9.367217105263158','9.367217105263158','test'),('2019-05-06 23:59:59','2019-05-07 11:59:59','SKYBNB','4h','0.052000000000000','0.052000000000000','0.711908500000000','0.711908500000000','13.69054807692308','13.690548076923079','test'),('2019-05-11 23:59:59','2019-05-12 11:59:59','SKYBNB','4h','0.057000000000000','0.053000000000000','0.711908500000000','0.661950008771930','12.489622807017545','12.489622807017545','test'),('2019-05-15 19:59:59','2019-05-16 07:59:59','SKYBNB','4h','0.066000000000000','0.064000000000000','0.711908500000000','0.690335515151515','10.786492424242425','10.786492424242425','test'),('2019-05-20 03:59:59','2019-05-20 19:59:59','SKYBNB','4h','0.064000000000000','0.060000000000000','0.711908500000000','0.667414218750000','11.1235703125','11.123570312500000','test'),('2019-05-26 19:59:59','2019-05-26 23:59:59','SKYBNB','4h','0.055000000000000','0.055000000000000','0.711908500000000','0.711908500000000','12.943790909090911','12.943790909090911','test'),('2019-06-09 07:59:59','2019-06-09 11:59:59','SKYBNB','4h','0.057000000000000','0.056000000000000','0.711908500000000','0.699418877192982','12.489622807017545','12.489622807017545','test'),('2019-06-23 03:59:59','2019-06-23 07:59:59','SKYBNB','4h','0.051000000000000','0.052000000000000','0.711908500000000','0.725867490196078','13.958990196078433','13.958990196078433','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','SKYBNB','4h','0.052000000000000','0.047000000000000','0.711908500000000','0.643455759615385','13.69054807692308','13.690548076923079','test'),('2019-06-27 07:59:59','2019-06-27 19:59:59','SKYBNB','4h','0.054000000000000','0.050000000000000','0.711908500000000','0.659174537037037','13.183490740740742','13.183490740740742','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','SKYBNB','4h','0.053000000000000','0.053000000000000','0.711908500000000','0.711908500000000','13.432235849056605','13.432235849056605','test'),('2019-07-09 19:59:59','2019-07-10 15:59:59','SKYBNB','4h','0.052000000000000','0.050000000000000','0.711908500000000','0.684527403846154','13.69054807692308','13.690548076923079','test'),('2019-07-21 15:59:59','2019-07-21 19:59:59','SKYBNB','4h','0.045980000000000','0.046880000000000','0.711908500000000','0.725843203131797','15.483003479773815','15.483003479773815','test'),('2019-07-22 11:59:59','2019-07-22 15:59:59','SKYBNB','4h','0.045530000000000','0.047890000000000','0.711908500000000','0.748809533604217','15.636031188227543','15.636031188227543','test'),('2019-07-24 07:59:59','2019-07-26 19:59:59','SKYBNB','4h','0.046890000000000','0.046630000000000','0.711908500000000','0.707961044039241','15.182522925997015','15.182522925997015','test'),('2019-08-24 03:59:59','2019-08-25 19:59:59','SKYBNB','4h','0.029480000000000','0.030070000000000','0.711908500000000','0.726156329545455','24.14886363636364','24.148863636363640','test'),('2019-08-27 03:59:59','2019-08-27 11:59:59','SKYBNB','4h','0.030650000000000','0.029810000000000','0.711908500000000','0.692397793964111','23.227030995106038','23.227030995106038','test'),('2019-08-28 11:59:59','2019-08-28 19:59:59','SKYBNB','4h','0.030290000000000','0.029390000000000','0.711908500000000','0.690755721855398','23.503086827335757','23.503086827335757','test'),('2019-08-29 23:59:59','2019-08-30 03:59:59','SKYBNB','4h','0.029990000000000','0.029990000000000','0.711908500000000','0.711908500000000','23.738196065355122','23.738196065355122','test'),('2019-08-30 19:59:59','2019-08-30 23:59:59','SKYBNB','4h','0.030170000000000','0.029890000000000','0.711908500000000','0.705301460556845','23.596569439840906','23.596569439840906','test'),('2019-09-10 15:59:59','2019-09-10 19:59:59','SKYBNB','4h','0.025060000000000','0.023790000000000','0.711908500000000','0.675830136272945','28.408160415003994','28.408160415003994','test'),('2019-09-11 07:59:59','2019-09-11 11:59:59','SKYBNB','4h','0.026150000000000','0.024510000000000','0.711908500000000','0.667261083556405','27.224034416826008','27.224034416826008','test'),('2019-09-14 23:59:59','2019-09-16 15:59:59','SKYBNB','4h','0.024590000000000','0.024410000000000','0.711908500000000','0.706697295038634','28.95113867425783','28.951138674257830','test'),('2019-09-17 15:59:59','2019-09-17 19:59:59','SKYBNB','4h','0.024700000000000','0.024460000000000','0.711908500000000','0.704991170445344','28.822206477732795','28.822206477732795','test'),('2019-09-18 15:59:59','2019-09-19 11:59:59','SKYBNB','4h','0.025270000000000','0.025040000000000','0.711908500000000','0.705428921250495','28.172081519588446','28.172081519588446','test'),('2019-10-20 07:59:59','2019-10-20 15:59:59','SKYBNB','4h','0.040370000000000','0.039800000000000','0.711908500000000','0.701856782264058','17.634592519197422','17.634592519197422','test'),('2019-11-01 15:59:59','2019-11-01 19:59:59','SKYBNB','4h','0.034440000000000','0.033760000000000','0.711908500000000','0.697852234610918','20.670978513356566','20.670978513356566','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  8:19:46
