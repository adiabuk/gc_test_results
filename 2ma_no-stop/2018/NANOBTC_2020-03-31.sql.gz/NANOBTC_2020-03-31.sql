-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-16 19:59:59','2018-08-30 11:59:59','NANOBTC','4h','0.000209800000000','0.000371200000000','0.001467500000000','0.002596453765491','6.994756911344138','6.994756911344138','test'),('2018-09-03 23:59:59','2018-09-04 03:59:59','NANOBTC','4h','0.000402200000000','0.000415800000000','0.001749738441373','0.001808904137053','4.350418800031701','4.350418800031701','test'),('2018-09-13 15:59:59','2018-09-17 15:59:59','NANOBTC','4h','0.000365700000000','0.000354000000000','0.001764529865293','0.001708076489783','4.8250748298954065','4.825074829895406','test'),('2018-09-18 15:59:59','2018-09-19 07:59:59','NANOBTC','4h','0.000375900000000','0.000365700000000','0.001764529865293','0.001716649565676','4.6941470212636345','4.694147021263634','test'),('2018-09-19 19:59:59','2018-09-19 23:59:59','NANOBTC','4h','0.000364900000000','0.000360600000000','0.001764529865293','0.001743736556384','4.835653234565634','4.835653234565634','test'),('2018-09-20 03:59:59','2018-09-20 07:59:59','NANOBTC','4h','0.000364200000000','0.000372700000000','0.001764529865293','0.001805711918711','4.8449474609912135','4.844947460991214','test'),('2018-10-17 07:59:59','2018-10-17 11:59:59','NANOBTC','4h','0.000314300000000','0.000324400000000','0.001764529865293','0.001821232861282','5.6141580187496025','5.614158018749603','test'),('2018-10-19 15:59:59','2018-10-19 23:59:59','NANOBTC','4h','0.000314700000000','0.000308800000000','0.001764529865293','0.001731448434708','5.607022133120432','5.607022133120432','test'),('2018-10-23 03:59:59','2018-10-23 07:59:59','NANOBTC','4h','0.000316600000000','0.000313300000000','0.001764529865293','0.001746137734669','5.573372916276058','5.573372916276058','test'),('2018-10-24 19:59:59','2018-10-24 23:59:59','NANOBTC','4h','0.000312500000000','0.000313500000000','0.001764529865293','0.001770176360862','5.6464955689376','5.646495568937600','test'),('2018-10-26 11:59:59','2018-10-27 15:59:59','NANOBTC','4h','0.000315500000000','0.000314600000000','0.001764529865293','0.001759496341113','5.592804644351822','5.592804644351822','test'),('2018-10-31 11:59:59','2018-11-01 11:59:59','NANOBTC','4h','0.000319600000000','0.000310800000000','0.001764529865293','0.001715944562369','5.521057150478723','5.521057150478723','test'),('2018-11-21 11:59:59','2018-11-21 15:59:59','NANOBTC','4h','0.000267400000000','0.000262600000000','0.001764529865293','0.001732855432408','6.59884018434181','6.598840184341810','test'),('2018-11-27 23:59:59','2018-11-28 19:59:59','NANOBTC','4h','0.000256200000000','0.000254700000000','0.001764529865293','0.001754198894185','6.887314072181889','6.887314072181889','test'),('2018-12-01 11:59:59','2018-12-01 23:59:59','NANOBTC','4h','0.000259900000000','0.000256500000000','0.001764529865293','0.001741446365709','6.7892645836591','6.789264583659100','test'),('2018-12-08 03:59:59','2018-12-08 07:59:59','NANOBTC','4h','0.000252700000000','0.000250800000000','0.001764529865293','0.001751262723449','6.982706233846457','6.982706233846457','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','NANOBTC','4h','0.000245900000000','0.000243000000000','0.001764529865293','0.001743720037683','7.175802624209028','7.175802624209028','test'),('2018-12-25 23:59:59','2018-12-26 11:59:59','NANOBTC','4h','0.000257000000000','0.000256000000000','0.001764529865293','0.001757663990331','6.865874962229571','6.865874962229571','test'),('2018-12-26 23:59:59','2018-12-27 03:59:59','NANOBTC','4h','0.000255300000000','0.000250000000000','0.001764529865293','0.001727898418814','6.91159367525656','6.911593675256560','test'),('2018-12-28 19:59:59','2018-12-28 23:59:59','NANOBTC','4h','0.000257000000000','0.000254600000000','0.001764529865293','0.001748051765384','6.865874962229571','6.865874962229571','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','NANOBTC','4h','0.000247900000000','0.000243800000000','0.001764529865293','0.001735346434685','7.117909904368696','7.117909904368696','test'),('2019-01-09 07:59:59','2019-01-10 11:59:59','NANOBTC','4h','0.000246700000000','0.000241700000000','0.001764529865293','0.001728767200816','7.152532895391164','7.152532895391164','test'),('2019-01-11 19:59:59','2019-01-11 23:59:59','NANOBTC','4h','0.000249900000000','0.000246300000000','0.001764529865293','0.001739110467474','7.060943838707483','7.060943838707483','test'),('2019-01-16 07:59:59','2019-01-16 15:59:59','NANOBTC','4h','0.000248000000000','0.000239400000000','0.001764529865293','0.001703340523190','7.115039779407257','7.115039779407257','test'),('2019-01-17 11:59:59','2019-01-17 15:59:59','NANOBTC','4h','0.000244500000000','0.000241500000000','0.001764529865293','0.001742879192099','7.216891064593048','7.216891064593048','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','NANOBTC','4h','0.000242400000000','0.000240400000000','0.001764529865293','0.001749971038022','7.279413635697194','7.279413635697194','test'),('2019-01-19 11:59:59','2019-01-19 15:59:59','NANOBTC','4h','0.000243000000000','0.000242300000000','0.001764529865293','0.001759446857451','7.261439774868313','7.261439774868313','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','NANOBTC','4h','0.000242600000000','0.000243300000000','0.001764529865293','0.001769621254022','7.273412470292663','7.273412470292663','test'),('2019-01-28 23:59:59','2019-01-29 07:59:59','NANOBTC','4h','0.000261500000000','0.000251800000000','0.001764529865293','0.001699076941035','6.747724150260038','6.747724150260038','test'),('2019-02-12 19:59:59','2019-02-14 11:59:59','NANOBTC','4h','0.000240000000000','0.000232800000000','0.001764529865293','0.001711593969334','7.352207772054166','7.352207772054166','test'),('2019-02-17 11:59:59','2019-02-17 15:59:59','NANOBTC','4h','0.000235500000000','0.000235600000000','0.001764529865293','0.001765279134875','7.492695818653927','7.492695818653927','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','NANOBTC','4h','0.000234600000000','0.000235600000000','0.001764529865293','0.001772051305469','7.521440176014492','7.521440176014492','test'),('2019-02-23 23:59:59','2019-02-24 03:59:59','NANOBTC','4h','0.000232400000000','0.000238500000000','0.001764529865293','0.001810844977936','7.592641416923407','7.592641416923407','test'),('2019-03-01 11:59:59','2019-03-02 11:59:59','NANOBTC','4h','0.000231500000000','0.000233600000000','0.001764529865293','0.001780536399708','7.622159245326134','7.622159245326134','test'),('2019-03-05 03:59:59','2019-03-05 15:59:59','NANOBTC','4h','0.000233200000000','0.000228400000000','0.001764529865293','0.001728210211119','7.566594619609776','7.566594619609776','test'),('2019-03-09 19:59:59','2019-03-11 23:59:59','NANOBTC','4h','0.000230000000000','0.000232200000000','0.001764529865293','0.001781407977048','7.671868979534782','7.671868979534782','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOBTC','4h','0.000247600000000','0.000244700000000','0.001764529865293','0.001743862916144','7.126534189390145','7.126534189390145','test'),('2019-03-27 07:59:59','2019-04-04 23:59:59','NANOBTC','4h','0.000246800000000','0.000268700000000','0.001764529865293','0.001921106867116','7.149634786438412','7.149634786438412','test'),('2019-04-16 07:59:59','2019-04-16 11:59:59','NANOBTC','4h','0.000300800000000','0.000297600000000','0.001764529865293','0.001745758270981','5.866123222383644','5.866123222383644','test'),('2019-04-17 07:59:59','2019-04-21 11:59:59','NANOBTC','4h','0.000312500000000','0.000306000000000','0.001764529865293','0.001727827644095','5.6464955689376','5.646495568937600','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','NANOBTC','4h','0.000241300000000','0.000230900000000','0.001764529865293','0.001688478847477','7.312597866941566','7.312597866941566','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','NANOBTC','4h','0.000215600000000','0.000205200000000','0.001764529865293','0.001679413396837','8.184275813047309','8.184275813047309','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','NANOBTC','4h','0.000203800000000','0.000198100000000','0.001764529865293','0.001715178441190','8.658144579455348','8.658144579455348','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','NANOBTC','4h','0.000201900000000','0.000199600000000','0.001764529865293','0.001744428732603','8.739622908831103','8.739622908831103','test'),('2019-06-10 15:59:59','2019-06-10 19:59:59','NANOBTC','4h','0.000200400000000','0.000199700000000','0.001764529865293','0.001758366337819','8.805039247969061','8.805039247969061','test'),('2019-06-12 03:59:59','2019-06-12 07:59:59','NANOBTC','4h','0.000200200000000','0.000197200000000','0.001764529865293','0.001738088358820','8.813835490974027','8.813835490974027','test'),('2019-06-13 07:59:59','2019-06-13 19:59:59','NANOBTC','4h','0.000204100000000','0.000200700000000','0.001764529865293','0.001735135443235','8.645418252292993','8.645418252292993','test'),('2019-07-08 03:59:59','2019-07-08 11:59:59','NANOBTC','4h','0.000122000000000','0.000110400000000','0.001764529865293','0.001596754894495','14.463359551581966','14.463359551581966','test'),('2019-07-17 19:59:59','2019-07-18 19:59:59','NANOBTC','4h','0.000114500000000','0.000104400000000','0.001764529865293','0.001608881379359','15.410741181598253','15.410741181598253','test'),('2019-07-19 19:59:59','2019-07-19 23:59:59','NANOBTC','4h','0.000105800000000','0.000105000000000','0.001764529865293','0.001751187484459','16.67797604246692','16.677976042466920','test'),('2019-07-20 19:59:59','2019-07-21 11:59:59','NANOBTC','4h','0.000105700000000','0.000114500000000','0.001764529865293','0.001911434906112','16.693754638533587','16.693754638533587','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  4:45:22
