-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-28 07:59:59','2018-05-28 15:59:59','ADXETH','4h','0.001134600000000','0.001152700000000','0.072144500000000','0.073295403798696','63.58584523179976','63.585845231799759','test'),('2018-06-27 03:59:59','2018-06-28 23:59:59','ADXETH','4h','0.000816100000000','0.000824900000000','0.072432225949674','0.073213262082938','88.75410605278029','88.754106052780287','test'),('2018-07-06 19:59:59','2018-07-06 23:59:59','ADXETH','4h','0.000884700000000','0.000870800000000','0.072627484982990','0.071486395301444','82.09278284502092','82.092782845020920','test'),('2018-07-10 23:59:59','2018-07-11 11:59:59','ADXETH','4h','0.000852000000000','0.000833200000000','0.072627484982990','0.071024906675854','85.24352697534037','85.243526975340373','test'),('2018-07-11 15:59:59','2018-07-11 19:59:59','ADXETH','4h','0.000862500000000','0.000854900000000','0.072627484982990','0.071987521057343','84.20577969042319','84.205779690423185','test'),('2018-07-17 23:59:59','2018-07-18 03:59:59','ADXETH','4h','0.000832100000000','0.000868700000000','0.072627484982990','0.075822012023463','87.28215957576012','87.282159575760119','test'),('2018-07-23 11:59:59','2018-07-25 03:59:59','ADXETH','4h','0.001244600000000','0.000932100000000','0.072627484982990','0.054391835732480','58.35407760163105','58.354077601631047','test'),('2018-07-30 03:59:59','2018-07-30 07:59:59','ADXETH','4h','0.000896300000000','0.000877100000000','0.072627484982990','0.071071702642620','81.03033022759121','81.030330227591207','test'),('2018-08-20 23:59:59','2018-08-21 03:59:59','ADXETH','4h','0.000645100000000','0.000636300000000','0.072627484982990','0.071636751968186','112.5832971368625','112.583297136862498','test'),('2018-08-21 11:59:59','2018-08-21 15:59:59','ADXETH','4h','0.000641800000000','0.000630900000000','0.072627484982990','0.071394017257352','113.16217666405423','113.162176664054229','test'),('2018-08-23 15:59:59','2018-08-23 19:59:59','ADXETH','4h','0.000648900000000','0.000641100000000','0.072627484982990','0.071754477766366','111.92400213128371','111.924002131283714','test'),('2018-09-06 11:59:59','2018-09-06 15:59:59','ADXETH','4h','0.000737800000000','0.000728800000000','0.072627484982990','0.071741543854165','98.43790320275141','98.437903202751414','test'),('2018-09-15 23:59:59','2018-09-19 19:59:59','ADXETH','4h','0.000893800000000','0.000834500000000','0.072627484982990','0.067808946317191','81.2569758144887','81.256975814488698','test'),('2018-09-20 15:59:59','2018-09-20 19:59:59','ADXETH','4h','0.000829400000000','0.000823600000000','0.072627484982990','0.072119600472619','87.56629489147576','87.566294891475764','test'),('2018-09-21 15:59:59','2018-09-21 19:59:59','ADXETH','4h','0.000846400000000','0.000833400000000','0.072627484982990','0.071511987222145','85.80752006496928','85.807520064969282','test'),('2018-09-22 03:59:59','2018-09-22 07:59:59','ADXETH','4h','0.000832500000000','0.000821000000000','0.072627484982990','0.071624222427669','87.24022220178979','87.240222201789791','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','ADXETH','4h','0.000848700000000','0.000838900000000','0.072627484982990','0.071788850185260','85.57497936018618','85.574979360186177','test'),('2018-09-24 07:59:59','2018-09-24 11:59:59','ADXETH','4h','0.000827500000000','0.000804400000000','0.072627484982990','0.070600059118208','87.76735345376436','87.767353453764358','test'),('2018-09-24 23:59:59','2018-09-25 03:59:59','ADXETH','4h','0.000827200000000','0.000823800000000','0.072627484982990','0.072328967757480','87.79918397363394','87.799183973633944','test'),('2018-09-29 23:59:59','2018-09-30 23:59:59','ADXETH','4h','0.000901600000000','0.000878100000000','0.072627484982990','0.070734466019924','80.5539984283385','80.553998428338502','test'),('2018-10-04 11:59:59','2018-10-04 15:59:59','ADXETH','4h','0.000877300000000','0.000888300000000','0.072627484982990','0.073538122546894','82.78523308217257','82.785233082172567','test'),('2018-10-15 15:59:59','2018-10-15 23:59:59','ADXETH','4h','0.000968500000000','0.000973000000000','0.072627484982990','0.072964938449612','74.98965924934436','74.989659249344356','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','ADXETH','4h','0.001123900000000','0.001123900000000','0.072627484982990','0.072627484982990','64.6209493575852','64.620949357585204','test'),('2018-10-30 15:59:59','2018-10-31 15:59:59','ADXETH','4h','0.001136400000000','0.001121900000000','0.072627484982990','0.071700787928913','63.91014166049806','63.910141660498063','test'),('2018-11-27 23:59:59','2018-11-30 11:59:59','ADXETH','4h','0.000863500000000','0.000814700000000','0.072627484982990','0.068523001755231','84.1082628639143','84.108262863914305','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','ADXETH','4h','0.000834300000000','0.000838600000000','0.072627484982990','0.073001808590118','87.05200165766512','87.052001657665116','test'),('2018-12-07 07:59:59','2018-12-07 11:59:59','ADXETH','4h','0.000977200000000','0.000960000000000','0.072627484982990','0.071349146115095','74.3220272032235','74.322027203223499','test'),('2018-12-09 23:59:59','2018-12-12 07:59:59','ADXETH','4h','0.001000300000000','0.000995700000000','0.072627484982990','0.072293498747939','72.6057032720084','72.605703272008398','test'),('2018-12-17 03:59:59','2018-12-17 19:59:59','ADXETH','4h','0.001126000000000','0.000996000000000','0.072627484982990','0.064242428990282','64.50043071313499','64.500430713134989','test'),('2018-12-18 07:59:59','2018-12-18 11:59:59','ADXETH','4h','0.001010200000000','0.000985500000000','0.072627484982990','0.070851699119716','71.89416450503862','71.894164505038617','test'),('2019-01-13 03:59:59','2019-01-13 07:59:59','ADXETH','4h','0.000734000000000','0.000733300000000','0.072627484982990','0.072558221713933','98.94752722478202','98.947527224782021','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','ADXETH','4h','0.000744100000000','0.000738500000000','0.072627484982990','0.072080899959600','97.6044684625588','97.604468462558799','test'),('2019-01-29 15:59:59','2019-01-30 03:59:59','ADXETH','4h','0.000877500000000','0.000873300000000','0.072627484982990','0.072279866251447','82.76636465298006','82.766364652980059','test'),('2019-02-02 23:59:59','2019-02-03 03:59:59','ADXETH','4h','0.000859900000000','0.000862100000000','0.072627484982990','0.072813297829789','84.46038490869869','84.460384908698686','test'),('2019-02-05 07:59:59','2019-02-05 11:59:59','ADXETH','4h','0.000862000000000','0.000853800000000','0.072627484982990','0.071936597074799','84.2546229501044','84.254622950104405','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','ADXETH','4h','0.000943600000000','0.000917700000000','0.072627484982990','0.070634000602893','76.96850888405045','76.968508884050451','test'),('2019-02-11 07:59:59','2019-02-11 15:59:59','ADXETH','4h','0.000938700000000','0.000928000000000','0.072627484982990','0.071799622951118','77.37028335249813','77.370283352498134','test'),('2019-02-12 23:59:59','2019-02-13 03:59:59','ADXETH','4h','0.000921900000000','0.000902800000000','0.072627484982990','0.071122782777572','78.78022017896735','78.780220178967355','test'),('2019-02-16 15:59:59','2019-02-17 11:59:59','ADXETH','4h','0.000917300000000','0.000913300000000','0.072627484982990','0.072310783860204','79.17528069659872','79.175280696598719','test'),('2019-02-25 23:59:59','2019-02-27 15:59:59','ADXETH','4h','0.000842000000000','0.000853000000000','0.072627484982990','0.073576300107471','86.25592040735155','86.255920407351553','test'),('2019-03-07 07:59:59','2019-03-16 11:59:59','ADXETH','4h','0.000906300000000','0.001016900000000','0.072627484982990','0.081490554429220','80.1362517742359','80.136251774235902','test'),('2019-03-19 19:59:59','2019-03-21 15:59:59','ADXETH','4h','0.001034400000000','0.000999800000000','0.072627484982990','0.070198143354595','70.21218579175367','70.212185791753669','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','ADXETH','4h','0.001039300000000','0.001028700000000','0.072627484982990','0.071886744733957','69.88115556912345','69.881155569123450','test'),('2019-03-22 15:59:59','2019-03-23 07:59:59','ADXETH','4h','0.001056500000000','0.001026900000000','0.072627484982990','0.070592678020854','68.7434784505348','68.743478450534795','test'),('2019-03-24 11:59:59','2019-03-25 15:59:59','ADXETH','4h','0.001052300000000','0.001043200000000','0.072627484982990','0.071999422535641','69.01785135701796','69.017851357017960','test'),('2019-03-30 23:59:59','2019-03-31 03:59:59','ADXETH','4h','0.001115700000000','0.001103600000000','0.072627484982990','0.071839824708459','65.09589045710317','65.095890457103167','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','ADXETH','4h','0.001134100000000','0.001146200000000','0.072627484982990','0.073402366006087','64.03975397494929','64.039753974949292','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','ADXETH','4h','0.001111400000000','0.001113000000000','0.072627484982990','0.072732041376703','65.34774607071262','65.347746070712617','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADXETH','4h','0.001115000000000','0.001004600000000','0.072627484982990','0.065436386918306','65.13675783227802','65.136757832278022','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','ADXETH','4h','0.001044400000000','0.001035800000000','0.072627484982990','0.072029441732460','69.53991285234585','69.539912852345850','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','ADXETH','4h','0.001023700000000','0.001015200000000','0.072627484982990','0.072024443445083','70.94606328317866','70.946063283178660','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','ADXETH','4h','0.001062600000000','0.000996300000000','0.072627484982990','0.068095956416858','68.34884715131753','68.348847151317528','test'),('2019-04-21 23:59:59','2019-04-22 07:59:59','ADXETH','4h','0.001042500000000','0.001023200000000','0.072627484982990','0.071282918594336','69.6666522618609','69.666652261860904','test'),('2019-04-23 11:59:59','2019-04-23 15:59:59','ADXETH','4h','0.001041000000000','0.001034800000000','0.072627484982990','0.072194929356770','69.7670364870221','69.767036487022096','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  9:18:05
