-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-15 19:59:59','XZCBNB','4h','3.012000000000000','3.035000000000000','0.711908500000000','0.717344720285525','0.2363574037184595','0.236357403718460','test'),('2018-05-16 15:59:59','2018-05-16 23:59:59','XZCBNB','4h','3.035000000000000','2.994000000000000','0.713267555071381','0.703631980192328','0.23501402144032332','0.235014021440323','test'),('2018-07-02 19:59:59','2018-07-07 11:59:59','XZCBNB','4h','1.153000000000000','1.174000000000000','0.713267555071381','0.726258551304251','0.6186188682319002','0.618618868231900','test'),('2018-07-17 19:59:59','2018-07-17 23:59:59','XZCBNB','4h','1.287000000000000','1.285000000000000','0.714106410409836','0.712996687938337','0.554861235749678','0.554861235749678','test'),('2018-08-07 15:59:59','2018-08-07 19:59:59','XZCBNB','4h','1.165000000000000','1.086000000000000','0.714106410409836','0.665682027214663','0.6129668758882713','0.612966875888271','test'),('2018-08-08 19:59:59','2018-08-09 11:59:59','XZCBNB','4h','1.143000000000000','1.065000000000000','0.714106410409836','0.665374739358246','0.6247650134819213','0.624765013481921','test'),('2018-08-12 03:59:59','2018-08-12 23:59:59','XZCBNB','4h','1.123000000000000','1.051000000000000','0.714106410409836','0.668322206002438','0.6358917278805307','0.635891727880531','test'),('2018-08-13 03:59:59','2018-08-22 03:59:59','XZCBNB','4h','1.083000000000000','1.321000000000000','0.714106410409836','0.871038382411259','0.6593780336194238','0.659378033619424','test'),('2018-08-24 03:59:59','2018-08-24 11:59:59','XZCBNB','4h','1.336000000000000','1.312000000000000','0.717326908128776','0.704440796006702','0.5369213384197428','0.536921338419743','test'),('2018-09-14 03:59:59','2018-09-14 07:59:59','XZCBNB','4h','1.140000000000000','1.062000000000000','0.717326908128776','0.668246645993649','0.6292341299375228','0.629234129937523','test'),('2018-09-27 23:59:59','2018-09-28 03:59:59','XZCBNB','4h','0.960000000000000','0.931000000000000','0.717326908128776','0.695657657779053','0.7472155293008084','0.747215529300808','test'),('2018-09-28 15:59:59','2018-10-02 23:59:59','XZCBNB','4h','0.991000000000000','0.960000000000000','0.717326908128776','0.694887822203456','0.7238414814619334','0.723841481461933','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','XZCBNB','4h','0.961000000000000','0.943000000000000','0.717326908128776','0.703891024313669','0.7464379897281748','0.746437989728175','test'),('2018-10-08 03:59:59','2018-10-08 07:59:59','XZCBNB','4h','0.967000000000000','0.950000000000000','0.717326908128776','0.704716197230959','0.7418065234010093','0.741806523401009','test'),('2018-10-08 19:59:59','2018-10-09 03:59:59','XZCBNB','4h','0.966000000000000','0.964000000000000','0.717326908128776','0.715841759250663','0.742574439056704','0.742574439056704','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','XZCBNB','4h','1.000000000000000','0.946000000000000','0.717326908128776','0.678591255089822','0.717326908128776','0.717326908128776','test'),('2018-10-11 15:59:59','2018-10-12 15:59:59','XZCBNB','4h','0.973000000000000','0.956000000000000','0.717326908128776','0.704793961121387','0.7372321769052168','0.737232176905217','test'),('2018-10-13 07:59:59','2018-10-13 11:59:59','XZCBNB','4h','0.985000000000000','0.958000000000000','0.717326908128776','0.697664140088698','0.7282506681510416','0.728250668151042','test'),('2018-10-14 19:59:59','2018-10-14 23:59:59','XZCBNB','4h','0.965000000000000','0.956000000000000','0.717326908128776','0.710636812612549','0.7433439462474363','0.743343946247436','test'),('2018-10-16 15:59:59','2018-10-18 19:59:59','XZCBNB','4h','1.001000000000000','0.984000000000000','0.717326908128776','0.705144533065650','0.7166102978309451','0.716610297830945','test'),('2018-10-20 15:59:59','2018-10-22 07:59:59','XZCBNB','4h','0.989000000000000','0.980000000000000','0.717326908128776','0.710799160734278','0.7253052660553853','0.725305266055385','test'),('2018-10-24 15:59:59','2018-10-25 07:59:59','XZCBNB','4h','1.003000000000000','1.009000000000000','0.717326908128776','0.721617996312996','0.7151813640366661','0.715181364036666','test'),('2018-11-07 15:59:59','2018-11-07 23:59:59','XZCBNB','4h','1.070000000000000','1.085000000000000','0.717326908128776','0.727382892822170','0.6703989795596037','0.670398979559604','test'),('2018-11-09 19:59:59','2018-11-14 11:59:59','XZCBNB','4h','1.074000000000000','1.096000000000000','0.717326908128776','0.732020755408881','0.6679021490956946','0.667902149095695','test'),('2018-11-17 23:59:59','2018-11-18 03:59:59','XZCBNB','4h','1.078000000000000','1.058000000000000','0.717326908128776','0.704018431169058','0.6654238479858775','0.665423847985878','test'),('2018-11-21 07:59:59','2018-11-23 23:59:59','XZCBNB','4h','1.091000000000000','1.041000000000000','0.717326908128776','0.684452164401518','0.6574948745451659','0.657494874545166','test'),('2018-11-24 03:59:59','2018-11-24 11:59:59','XZCBNB','4h','1.073000000000000','1.055000000000000','0.717326908128776','0.705293465121956','0.6685246114900056','0.668524611490006','test'),('2018-11-24 15:59:59','2018-11-24 19:59:59','XZCBNB','4h','1.078000000000000','1.060000000000000','0.717326908128776','0.705349278865030','0.6654238479858775','0.665423847985878','test'),('2018-11-25 03:59:59','2018-11-25 15:59:59','XZCBNB','4h','1.080000000000000','1.057000000000000','0.717326908128776','0.702050501751959','0.6641915816007185','0.664191581600718','test'),('2018-11-25 19:59:59','2018-11-25 23:59:59','XZCBNB','4h','1.068000000000000','1.053000000000000','0.717326908128776','0.707252092003372','0.6716544083602771','0.671654408360277','test'),('2018-11-27 11:59:59','2018-11-27 23:59:59','XZCBNB','4h','1.069000000000000','1.061000000000000','0.717326908128776','0.711958699274678','0.6710261067621852','0.671026106762185','test'),('2018-12-07 19:59:59','2018-12-08 03:59:59','XZCBNB','4h','1.159000000000000','1.097000000000000','0.717326908128776','0.678953941516193','0.6189188163319896','0.618918816331990','test'),('2018-12-10 07:59:59','2018-12-10 11:59:59','XZCBNB','4h','1.157000000000000','1.111000000000000','0.717326908128776','0.688807428635324','0.6199886846402558','0.619988684640256','test'),('2018-12-20 19:59:59','2018-12-21 15:59:59','XZCBNB','4h','1.000000000000000','0.950000000000000','0.717326908128776','0.681460562722337','0.717326908128776','0.717326908128776','test'),('2018-12-21 19:59:59','2018-12-21 23:59:59','XZCBNB','4h','0.974000000000000','0.951000000000000','0.717326908128776','0.700387977033333','0.7364752650192772','0.736475265019277','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','XZCBNB','4h','0.983000000000000','0.956000000000000','0.717326908128776','0.697624134456877','0.7297323582184904','0.729732358218490','test'),('2018-12-24 07:59:59','2018-12-25 07:59:59','XZCBNB','4h','1.151000000000000','1.000000000000000','0.717326908128776','0.623220597852977','0.6232205978529765','0.623220597852976','test'),('2018-12-30 03:59:59','2018-12-30 11:59:59','XZCBNB','4h','0.994000000000000','0.965000000000000','0.717326908128776','0.696398859501276','0.7216568492241207','0.721656849224121','test'),('2019-01-03 07:59:59','2019-01-03 11:59:59','XZCBNB','4h','0.944000000000000','0.930000000000000','0.717326908128776','0.706688585338731','0.7598801992889577','0.759880199288958','test'),('2019-01-19 11:59:59','2019-01-19 19:59:59','XZCBNB','4h','0.851000000000000','0.830000000000000','0.717326908128776','0.699625539068019','0.8429223362265288','0.842922336226529','test'),('2019-01-19 23:59:59','2019-01-20 03:59:59','XZCBNB','4h','0.855000000000000','0.840000000000000','0.717326908128776','0.704742225530026','0.8389788399166971','0.838978839916697','test'),('2019-01-30 07:59:59','2019-01-30 19:59:59','XZCBNB','4h','0.770000000000000','0.785000000000000','0.717326908128776','0.731300808936479','0.9315933871802285','0.931593387180229','test'),('2019-02-18 19:59:59','2019-02-18 23:59:59','XZCBNB','4h','0.577000000000000','0.578000000000000','0.717326908128776','0.718570109009415','1.2432008806391266','1.243200880639127','test'),('2019-02-25 19:59:59','2019-02-27 15:59:59','XZCBNB','4h','0.553000000000000','0.547000000000000','0.717326908128776','0.709543976033346','1.2971553492382928','1.297155349238293','test'),('2019-03-12 15:59:59','2019-03-12 23:59:59','XZCBNB','4h','0.602000000000000','0.452000000000000','0.717326908128776','0.538590967565127','1.19157293709099','1.191572937090990','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','XZCBNB','4h','0.452000000000000','0.455000000000000','0.478217938752517','0.481391951620343','1.0580042892754808','1.058004289275481','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','XZCBNB','4h','0.440000000000000','0.442000000000000','0.526002450109958','0.528393370337731','1.1954601138862688','1.195460113886269','test'),('2019-03-27 11:59:59','2019-03-28 07:59:59','XZCBNB','4h','0.434000000000000','0.435000000000000','0.526600180166901','0.527813544637332','1.2133644704306485','1.213364470430649','test'),('2019-03-29 07:59:59','2019-03-29 19:59:59','XZCBNB','4h','0.434000000000000','0.430000000000000','0.526903521284509','0.522047267632117','1.2140634130979475','1.214063413097948','test'),('2019-03-31 19:59:59','2019-03-31 23:59:59','XZCBNB','4h','0.437000000000000','0.473000000000000','0.526903521284509','0.570309761024194','1.2057288816579153','1.205728881657915','test'),('2019-04-01 23:59:59','2019-04-02 07:59:59','XZCBNB','4h','0.435000000000000','0.426000000000000','0.536541017806332','0.525440169162063','1.233427627140994','1.233427627140994','test'),('2019-04-03 15:59:59','2019-04-04 19:59:59','XZCBNB','4h','0.459000000000000','0.437000000000000','0.536541017806332','0.510824454861366','1.1689346793166275','1.168934679316628','test'),('2019-04-11 15:59:59','2019-04-12 03:59:59','XZCBNB','4h','0.459000000000000','0.463000000000000','0.536541017806332','0.541216756523599','1.1689346793166275','1.168934679316628','test'),('2019-05-07 03:59:59','2019-05-09 03:59:59','XZCBNB','4h','0.304000000000000','0.313000000000000','0.536541017806332','0.552425455833493','1.7649375585734606','1.764937558573461','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:16:19
