-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-26 11:59:59','2018-04-27 11:59:59','EVXBTC','4h','0.000179560000000','0.000177850000000','0.001467500000000','0.001453524587881','8.172755624860772','8.172755624860772','test'),('2018-05-05 03:59:59','2018-05-05 11:59:59','EVXBTC','4h','0.000187640000000','0.000190400000000','0.001467500000000','0.001489085482839','7.820827115753571','7.820827115753571','test'),('2018-05-09 19:59:59','2018-05-09 23:59:59','EVXBTC','4h','0.000183470000000','0.000177490000000','0.001469402517680','0.001421508981648','8.008952513653458','8.008952513653458','test'),('2018-05-13 23:59:59','2018-05-14 03:59:59','EVXBTC','4h','0.000179450000000','0.000171470000000','0.001469402517680','0.001404059346373','8.18836733173586','8.188367331735860','test'),('2018-05-15 07:59:59','2018-05-15 11:59:59','EVXBTC','4h','0.000173870000000','0.000175400000000','0.001469402517680','0.001482332786571','8.451156137804107','8.451156137804107','test'),('2018-05-15 23:59:59','2018-05-16 03:59:59','EVXBTC','4h','0.000173170000000','0.000168000000000','0.001469402517680','0.001425533423631','8.485317997805625','8.485317997805625','test'),('2018-06-03 07:59:59','2018-06-03 19:59:59','EVXBTC','4h','0.000147440000000','0.000146940000000','0.001469402517680','0.001464419465192','9.966104976125882','9.966104976125882','test'),('2018-06-22 15:59:59','2018-06-22 19:59:59','EVXBTC','4h','0.000126000000000','0.000109570000000','0.001469402517680','0.001277797094144','11.661924743492063','11.661924743492063','test'),('2018-07-01 19:59:59','2018-07-01 23:59:59','EVXBTC','4h','0.000103360000000','0.000094610000000','0.001469402517680','0.001345009405938','14.216355627708978','14.216355627708978','test'),('2018-07-02 15:59:59','2018-07-06 03:59:59','EVXBTC','4h','0.000104850000000','0.000105430000000','0.001469402517680','0.001477530829175','14.014330163853124','14.014330163853124','test'),('2018-07-16 11:59:59','2018-07-17 11:59:59','EVXBTC','4h','0.000103380000000','0.000103450000000','0.001469402517680','0.001470397470052','14.213605317082608','14.213605317082608','test'),('2018-07-18 03:59:59','2018-07-18 11:59:59','EVXBTC','4h','0.000105670000000','0.000103910000000','0.001469402517680','0.001444928698894','13.905578855682787','13.905578855682787','test'),('2018-08-07 19:59:59','2018-08-07 23:59:59','EVXBTC','4h','0.000081720000000','0.000079700000000','0.001469402517680','0.001433081016386','17.98094123445913','17.980941234459131','test'),('2018-08-08 23:59:59','2018-08-10 19:59:59','EVXBTC','4h','0.000080650000000','0.000076440000000','0.001469402517680','0.001392698430892','18.219498049349042','18.219498049349042','test'),('2018-08-17 23:59:59','2018-08-18 07:59:59','EVXBTC','4h','0.000071560000000','0.000069130000000','0.001469402517680','0.001419505254992','20.53385295807714','20.533852958077141','test'),('2018-08-24 19:59:59','2018-08-25 03:59:59','EVXBTC','4h','0.000069350000000','0.000066220000000','0.001469402517680','0.001403083413421','21.188212223215572','21.188212223215572','test'),('2018-08-25 11:59:59','2018-08-25 15:59:59','EVXBTC','4h','0.000067370000000','0.000066160000000','0.001469402517680','0.001443011289442','21.810932428083717','21.810932428083717','test'),('2018-08-28 15:59:59','2018-08-28 19:59:59','EVXBTC','4h','0.000066090000000','0.000067820000000','0.001469402517680','0.001507866224074','22.233356297170527','22.233356297170527','test'),('2018-08-31 03:59:59','2018-08-31 07:59:59','EVXBTC','4h','0.000067590000000','0.000065340000000','0.001469402517680','0.001420487653576','21.739939601716234','21.739939601716234','test'),('2018-09-03 07:59:59','2018-09-03 19:59:59','EVXBTC','4h','0.000067700000000','0.000065850000000','0.001469402517680','0.001429248977684','21.704616213884783','21.704616213884783','test'),('2018-09-04 07:59:59','2018-09-04 11:59:59','EVXBTC','4h','0.000066330000000','0.000065910000000','0.001469402517680','0.001460098295497','22.15290996050053','22.152909960500530','test'),('2018-09-16 23:59:59','2018-09-17 15:59:59','EVXBTC','4h','0.000061030000000','0.000059720000000','0.001469402517680','0.001437862008125','24.07672485138457','24.076724851384569','test'),('2018-09-18 11:59:59','2018-09-25 07:59:59','EVXBTC','4h','0.000060490000000','0.000061800000000','0.001469402517680','0.001501224592373','24.291660070755498','24.291660070755498','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','EVXBTC','4h','0.000063840000000','0.000061630000000','0.001469402517680','0.001418535043305','23.016956730576442','23.016956730576442','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','EVXBTC','4h','0.000062950000000','0.000063150000000','0.001469402517680','0.001474070992716','23.342375181572677','23.342375181572677','test'),('2018-10-04 03:59:59','2018-10-04 07:59:59','EVXBTC','4h','0.000067050000000','0.000066770000000','0.001469402517680','0.001463266310298','21.915026363609247','21.915026363609247','test'),('2018-10-23 11:59:59','2018-10-23 15:59:59','EVXBTC','4h','0.000083000000000','0.000082980000000','0.001469402517680','0.001469048444784','17.703644791325303','17.703644791325303','test'),('2018-10-26 11:59:59','2018-10-27 15:59:59','EVXBTC','4h','0.000086290000000','0.000083620000000','0.001469402517680','0.001423936012613','17.028653583033957','17.028653583033957','test'),('2018-10-28 23:59:59','2018-10-29 03:59:59','EVXBTC','4h','0.000084440000000','0.000084900000000','0.001469402517680','0.001477407315858','17.401735169114165','17.401735169114165','test'),('2018-10-31 11:59:59','2018-11-01 07:59:59','EVXBTC','4h','0.000086080000000','0.000084390000000','0.001469402517680','0.001440553885537','17.070196534386618','17.070196534386618','test'),('2018-11-01 23:59:59','2018-11-02 03:59:59','EVXBTC','4h','0.000084530000000','0.000084870000000','0.001469402517680','0.001475312808181','17.38320735454868','17.383207354548681','test'),('2018-11-03 07:59:59','2018-11-03 11:59:59','EVXBTC','4h','0.000084110000000','0.000083450000000','0.001469402517680','0.001457872311264','17.470009721555105','17.470009721555105','test'),('2018-11-09 23:59:59','2018-11-10 03:59:59','EVXBTC','4h','0.000082510000000','0.000081580000000','0.001469402517680','0.001452840351380','17.808780968125077','17.808780968125077','test'),('2018-11-10 11:59:59','2018-11-10 15:59:59','EVXBTC','4h','0.000081450000000','0.000081130000000','0.001469402517680','0.001463629542779','18.04054656451811','18.040546564518110','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','EVXBTC','4h','0.000081430000000','0.000081080000000','0.001469402517680','0.001463086775556','18.044977498219332','18.044977498219332','test'),('2018-11-28 23:59:59','2018-11-29 07:59:59','EVXBTC','4h','0.000065490000000','0.000065950000000','0.001469402517680','0.001479723561475','22.437051728202782','22.437051728202782','test'),('2018-12-04 11:59:59','2018-12-04 23:59:59','EVXBTC','4h','0.000067280000000','0.000066490000000','0.001469402517680','0.001452148831756','21.840108764565993','21.840108764565993','test'),('2018-12-22 03:59:59','2018-12-22 07:59:59','EVXBTC','4h','0.000058950000000','0.000059700000000','0.001469402517680','0.001488097206200','24.92625136013571','24.926251360135709','test'),('2018-12-26 11:59:59','2018-12-26 15:59:59','EVXBTC','4h','0.000059850000000','0.000060020000000','0.001469402517680','0.001473576259167','24.55142051261487','24.551420512614872','test'),('2018-12-31 23:59:59','2019-01-01 03:59:59','EVXBTC','4h','0.000058970000000','0.000060930000000','0.001469402517680','0.001518241400750','24.917797484822792','24.917797484822792','test'),('2019-01-12 03:59:59','2019-01-12 07:59:59','EVXBTC','4h','0.000060460000000','0.000060150000000','0.001469402517680','0.001461868366498','24.303713491233875','24.303713491233875','test'),('2019-01-12 23:59:59','2019-01-13 07:59:59','EVXBTC','4h','0.000060320000000','0.000060170000000','0.001469402517680','0.001465748499483','24.36012131432361','24.360121314323610','test'),('2019-01-15 15:59:59','2019-01-18 11:59:59','EVXBTC','4h','0.000060040000000','0.000061090000000','0.001469402517680','0.001495099930131','24.473726143904063','24.473726143904063','test'),('2019-02-08 19:59:59','2019-02-08 23:59:59','EVXBTC','4h','0.000082530000000','0.000080580000000','0.001469402517680','0.001434683810428','17.804465257239794','17.804465257239794','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','EVXBTC','4h','0.000068700000000','0.000067050000000','0.001469402517680','0.001434111190836','21.3886829356623','21.388682935662299','test'),('2019-03-01 03:59:59','2019-03-02 11:59:59','EVXBTC','4h','0.000069390000000','0.000068310000000','0.001469402517680','0.001446532439584','21.175998237209974','21.175998237209974','test'),('2019-03-12 11:59:59','2019-03-18 07:59:59','EVXBTC','4h','0.000075510000000','0.000075770000000','0.001469402517680','0.001474462041645','19.45970755767448','19.459707557674481','test'),('2019-03-19 07:59:59','2019-03-20 03:59:59','EVXBTC','4h','0.000076570000000','0.000077450000000','0.001469402517680','0.001486289996008','19.19031628157242','19.190316281572422','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','EVXBTC','4h','0.000229540000000','0.000162480000000','0.001469402517680','0.001040117282707','6.401509617844384','6.401509617844384','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','EVXBTC','4h','0.000223920000000','0.000219590000000','0.001469402517680','0.001440988294290','6.562176302608075','6.562176302608075','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 14:43:41
