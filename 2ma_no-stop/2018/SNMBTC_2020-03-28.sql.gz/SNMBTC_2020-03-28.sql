-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-17 03:59:59','2018-03-17 07:59:59','SNMBTC','4h','0.000017620000000','0.000016700000000','0.001467500000000','0.001390876844495','83.28603859250852','83.286038592508518','test'),('2018-03-24 15:59:59','2018-03-24 19:59:59','SNMBTC','4h','0.000016000000000','0.000015950000000','0.001467500000000','0.001462914062500','91.71875000000001','91.718750000000014','test'),('2018-03-25 19:59:59','2018-03-26 15:59:59','SNMBTC','4h','0.000016110000000','0.000015820000000','0.001467500000000','0.001441083178150','91.09248913718187','91.092489137181872','test'),('2018-03-27 19:59:59','2018-03-28 07:59:59','SNMBTC','4h','0.000016340000000','0.000015820000000','0.001467500000000','0.001420798653611','89.81028151774787','89.810281517747867','test'),('2018-03-28 19:59:59','2018-03-28 23:59:59','SNMBTC','4h','0.000015890000000','0.000015490000000','0.001467500000000','0.001430558527376','92.35368156073002','92.353681560730024','test'),('2018-04-06 19:59:59','2018-04-10 11:59:59','SNMBTC','4h','0.000015930000000','0.000015530000000','0.001467500000000','0.001430651286880','92.1217827997489','92.121782799748900','test'),('2018-05-22 03:59:59','2018-05-22 07:59:59','SNMBTC','4h','0.000035320000000','0.000034700000000','0.001467500000000','0.001441739807475','41.548697621744054','41.548697621744054','test'),('2018-06-17 15:59:59','2018-06-28 07:59:59','SNMBTC','4h','0.000024440000000','0.000025680000000','0.001467500000000','0.001541955810147','60.04500818330606','60.045008183306059','test'),('2018-06-28 19:59:59','2018-06-28 23:59:59','SNMBTC','4h','0.000026780000000','0.000024900000000','0.001467500000000','0.001364479088872','54.798356982823','54.798356982823002','test'),('2018-06-30 19:59:59','2018-06-30 23:59:59','SNMBTC','4h','0.000027010000000','0.000026480000000','0.001467500000000','0.001438704183636','54.33172898926323','54.331728989263233','test'),('2018-07-02 23:59:59','2018-07-03 03:59:59','SNMBTC','4h','0.000026290000000','0.000026500000000','0.001467500000000','0.001479222137695','55.81970330924306','55.819703309243060','test'),('2018-08-06 15:59:59','2018-08-06 19:59:59','SNMBTC','4h','0.000013430000000','0.000013120000000','0.001467500000000','0.001433626209978','109.27029039463888','109.270290394638877','test'),('2018-08-25 23:59:59','2018-08-26 03:59:59','SNMBTC','4h','0.000008800000000','0.000008440000000','0.001467500000000','0.001407465909091','166.76136363636363','166.761363636363626','test'),('2018-08-27 23:59:59','2018-08-28 03:59:59','SNMBTC','4h','0.000008870000000','0.000008830000000','0.001467500000000','0.001460882187148','165.44532130777904','165.445321307779039','test'),('2018-09-05 03:59:59','2018-09-05 07:59:59','SNMBTC','4h','0.000008400000000','0.000008320000000','0.001467500000000','0.001453523809524','174.70238095238096','174.702380952380963','test'),('2018-09-14 03:59:59','2018-09-14 23:59:59','SNMBTC','4h','0.000007570000000','0.000007340000000','0.001467500000000','0.001422912813738','193.8573315719947','193.857331571994706','test'),('2018-09-15 15:59:59','2018-09-15 19:59:59','SNMBTC','4h','0.000007370000000','0.000007350000000','0.001467500000000','0.001463517639077','199.11804613297153','199.118046132971529','test'),('2018-09-16 19:59:59','2018-09-16 23:59:59','SNMBTC','4h','0.000007390000000','0.000007440000000','0.001467500000000','0.001477428958051','198.57916102841676','198.579161028416763','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','SNMBTC','4h','0.000008070000000','0.000007950000000','0.001467500000000','0.001445678438662','181.84634448574968','181.846344485749682','test'),('2018-10-04 23:59:59','2018-10-05 03:59:59','SNMBTC','4h','0.000008430000000','0.000008550000000','0.001467500000000','0.001488389679715','174.08066429418741','174.080664294187414','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','SNMBTC','4h','0.000008440000000','0.000008420000000','0.001467500000000','0.001464022511848','173.87440758293837','173.874407582938375','test'),('2018-10-07 11:59:59','2018-10-07 15:59:59','SNMBTC','4h','0.000008430000000','0.000008270000000','0.001467500000000','0.001439647093713','174.08066429418741','174.080664294187414','test'),('2018-10-08 15:59:59','2018-10-08 19:59:59','SNMBTC','4h','0.000008450000000','0.000008460000000','0.001467500000000','0.001469236686391','173.66863905325442','173.668639053254424','test'),('2018-10-13 15:59:59','2018-10-14 11:59:59','SNMBTC','4h','0.000008750000000','0.000008400000000','0.001467500000000','0.001408800000000','167.71428571428572','167.714285714285722','test'),('2018-10-16 11:59:59','2018-10-16 19:59:59','SNMBTC','4h','0.000008480000000','0.000008350000000','0.001467500000000','0.001445002948113','173.05424528301887','173.054245283018872','test'),('2018-10-17 11:59:59','2018-10-18 03:59:59','SNMBTC','4h','0.000008440000000','0.000008490000000','0.001467500000000','0.001476193720379','173.87440758293837','173.874407582938375','test'),('2018-10-22 15:59:59','2018-10-22 19:59:59','SNMBTC','4h','0.000008530000000','0.000008390000000','0.001467500000000','0.001443414419695','172.0398593200469','172.039859320046901','test'),('2018-10-23 07:59:59','2018-10-27 23:59:59','SNMBTC','4h','0.000008800000000','0.000008910000000','0.001467500000000','0.001485843750000','166.76136363636363','166.761363636363626','test'),('2018-11-06 03:59:59','2018-11-06 07:59:59','SNMBTC','4h','0.000009930000000','0.000009350000000','0.001467500000000','0.001381784994965','147.7844914400806','147.784491440080586','test'),('2018-11-06 23:59:59','2018-11-07 03:59:59','SNMBTC','4h','0.000010070000000','0.000009870000000','0.001467500000000','0.001438354021847','145.72989076464748','145.729890764647479','test'),('2018-11-09 15:59:59','2018-11-09 19:59:59','SNMBTC','4h','0.000010320000000','0.000010140000000','0.001467500000000','0.001441904069767','142.1996124031008','142.199612403100787','test'),('2018-11-29 07:59:59','2018-11-29 15:59:59','SNMBTC','4h','0.000007100000000','0.000006930000000','0.001467500000000','0.001432362676056','206.69014084507043','206.690140845070431','test'),('2018-12-01 15:59:59','2018-12-01 19:59:59','SNMBTC','4h','0.000007090000000','0.000006890000000','0.001467500000000','0.001426103667137','206.98166431593796','206.981664315937962','test'),('2018-12-02 03:59:59','2018-12-02 07:59:59','SNMBTC','4h','0.000007040000000','0.000006860000000','0.001467500000000','0.001429978693182','208.45170454545453','208.451704545454533','test'),('2018-12-21 15:59:59','2018-12-21 23:59:59','SNMBTC','4h','0.000005740000000','0.000005490000000','0.001467500000000','0.001403584494774','255.66202090592336','255.662020905923356','test'),('2018-12-22 03:59:59','2018-12-22 15:59:59','SNMBTC','4h','0.000005660000000','0.000005560000000','0.001467500000000','0.001441572438163','259.2756183745583','259.275618374558292','test'),('2018-12-23 03:59:59','2018-12-25 11:59:59','SNMBTC','4h','0.000005730000000','0.000005740000000','0.001467500000000','0.001470061082024','256.10820244328096','256.108202443280959','test'),('2018-12-25 19:59:59','2018-12-25 23:59:59','SNMBTC','4h','0.000005760000000','0.000005700000000','0.001467500000000','0.001452213541667','254.77430555555557','254.774305555555571','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','SNMBTC','4h','0.000006020000000','0.000006070000000','0.001467500000000','0.001479688538206','243.77076411960135','243.770764119601353','test'),('2018-12-31 15:59:59','2018-12-31 19:59:59','SNMBTC','4h','0.000005900000000','0.000005800000000','0.001467500000000','0.001442627118644','248.72881355932202','248.728813559322020','test'),('2019-01-02 07:59:59','2019-01-02 15:59:59','SNMBTC','4h','0.000005920000000','0.000005930000000','0.001467500000000','0.001469978885135','247.88851351351352','247.888513513513516','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','SNMBTC','4h','0.000005600000000','0.000005490000000','0.001467500000000','0.001438674107143','262.05357142857144','262.053571428571445','test'),('2019-01-22 15:59:59','2019-01-23 03:59:59','SNMBTC','4h','0.000005970000000','0.000005910000000','0.001467500000000','0.001452751256281','245.81239530988276','245.812395309882760','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','SNMBTC','4h','0.000005910000000','0.000005870000000','0.001467500000000','0.001457567681895','248.30795262267344','248.307952622673440','test'),('2019-02-17 15:59:59','2019-02-17 19:59:59','SNMBTC','4h','0.000005220000000','0.000005190000000','0.001467500000000','0.001459066091954','281.13026819923374','281.130268199233740','test'),('2019-02-18 03:59:59','2019-02-21 11:59:59','SNMBTC','4h','0.000005250000000','0.000005130000000','0.001467500000000','0.001433957142857','279.5238095238096','279.523809523809575','test'),('2019-02-26 23:59:59','2019-02-27 03:59:59','SNMBTC','4h','0.000005200000000','0.000005120000000','0.001467500000000','0.001444923076923','282.21153846153845','282.211538461538453','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','SNMBTC','4h','0.000005230000000','0.000005140000000','0.001467500000000','0.001442246653920','280.5927342256214','280.592734225621427','test'),('2019-03-01 03:59:59','2019-03-04 07:59:59','SNMBTC','4h','0.000005270000000','0.000005300000000','0.001467500000000','0.001475853889943','278.46299810246677','278.462998102466770','test'),('2019-03-04 15:59:59','2019-03-07 11:59:59','SNMBTC','4h','0.000005300000000','0.000005280000000','0.001467500000000','0.001461962264151','276.8867924528302','276.886792452830207','test'),('2019-03-07 23:59:59','2019-03-08 07:59:59','SNMBTC','4h','0.000005320000000','0.000005390000000','0.001467500000000','0.001486809210526','275.84586466165416','275.845864661654161','test'),('2019-03-11 23:59:59','2019-03-12 11:59:59','SNMBTC','4h','0.000005450000000','0.000005720000000','0.001467500000000','0.001540201834862','269.26605504587155','269.266055045871553','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:52:41
