-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 07:59:59','2018-07-07 23:59:59','GTOBNB','4h','0.009370000000000','0.011560000000000','0.711908500000000','0.878299067235859','75.97742796157952','75.977427961579522','test'),('2018-07-10 19:59:59','2018-07-21 03:59:59','GTOBNB','4h','0.011520000000000','0.013890000000000','0.753506141808965','0.908524332441538','65.40851925425041','65.408519254250407','test'),('2018-08-17 11:59:59','2018-08-18 19:59:59','GTOBNB','4h','0.008130000000000','0.008160000000000','0.792260689467108','0.795184160645954','97.44903929484724','97.449039294847239','test'),('2018-08-21 11:59:59','2018-08-22 11:59:59','GTOBNB','4h','0.008430000000000','0.008440000000000','0.792991557261820','0.793932235265689','94.06780038692996','94.067800386929960','test'),('2018-08-24 03:59:59','2018-08-24 15:59:59','GTOBNB','4h','0.008470000000000','0.008050000000000','0.793226726762787','0.753893170063806','93.65132547376467','93.651325473764672','test'),('2018-08-24 19:59:59','2018-08-24 23:59:59','GTOBNB','4h','0.008350000000000','0.008170000000000','0.793226726762787','0.776127228461314','94.99721278596252','94.997212785962518','test'),('2018-08-25 03:59:59','2018-08-25 07:59:59','GTOBNB','4h','0.008360000000000','0.008350000000000','0.793226726762787','0.792277890965224','94.88357975631425','94.883579756314248','test'),('2018-08-25 19:59:59','2018-08-25 23:59:59','GTOBNB','4h','0.008300000000000','0.008310000000000','0.793226726762787','0.794182421614308','95.56948515214302','95.569485152143017','test'),('2018-08-28 15:59:59','2018-08-28 19:59:59','GTOBNB','4h','0.008260000000000','0.008130000000000','0.793226726762787','0.780742528883954','96.03229137564009','96.032291375640085','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','GTOBNB','4h','0.008130000000000','0.007900000000000','0.793226726762787','0.770786118256583','97.56786307045351','97.567863070453512','test'),('2018-09-04 19:59:59','2018-09-04 23:59:59','GTOBNB','4h','0.007990000000000','0.007840000000000','0.793226726762787','0.778335111116427','99.27743764240138','99.277437642401381','test'),('2018-09-16 23:59:59','2018-09-17 07:59:59','GTOBNB','4h','0.006660000000000','0.006340000000000','0.793226726762787','0.755113730882293','119.1031121265446','119.103112126544602','test'),('2018-09-20 11:59:59','2018-09-20 15:59:59','GTOBNB','4h','0.006500000000000','0.006300000000000','0.793226726762787','0.768819750554701','122.03488104042879','122.034881040428786','test'),('2018-09-21 15:59:59','2018-09-21 19:59:59','GTOBNB','4h','0.006440000000000','0.006490000000000','0.793226726762787','0.799385319361877','123.17185198179922','123.171851981799222','test'),('2018-09-25 15:59:59','2018-09-27 11:59:59','GTOBNB','4h','0.006620000000000','0.006580000000000','0.793226726762787','0.788433816027060','119.82276839317025','119.822768393170250','test'),('2018-10-02 03:59:59','2018-10-02 23:59:59','GTOBNB','4h','0.006820000000000','0.006510000000000','0.793226726762787','0.757170966455388','116.30890421741746','116.308904217417464','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','GTOBNB','4h','0.006610000000000','0.006570000000000','0.793226726762787','0.788426565027460','120.00404338317503','120.004043383175031','test'),('2018-10-08 23:59:59','2018-10-11 03:59:59','GTOBNB','4h','0.006580000000000','0.006730000000000','0.793226726762787','0.811309402904796','120.55117428005882','120.551174280058817','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','GTOBNB','4h','0.006760000000000','0.006680000000000','0.793226726762787','0.783839428221216','117.34123176964304','117.341231769643045','test'),('2018-10-12 03:59:59','2018-10-12 07:59:59','GTOBNB','4h','0.006840000000000','0.006690000000000','0.793226726762787','0.775831403807463','115.96881970216185','115.968819702161852','test'),('2018-10-13 15:59:59','2018-10-14 15:59:59','GTOBNB','4h','0.006760000000000','0.006710000000000','0.793226726762787','0.787359665174305','117.34123176964304','117.341231769643045','test'),('2018-10-15 23:59:59','2018-10-25 03:59:59','GTOBNB','4h','0.006980000000000','0.007180000000000','0.793226726762787','0.815955286268884','113.64279753048525','113.642797530485254','test'),('2018-10-25 07:59:59','2018-10-25 19:59:59','GTOBNB','4h','0.007510000000000','0.007340000000000','0.793226726762787','0.775270862109036','105.62273325736179','105.622733257361787','test'),('2018-10-28 19:59:59','2018-10-29 15:59:59','GTOBNB','4h','0.007360000000000','0.007100000000000','0.793226726762787','0.765205130436928','107.77537048407433','107.775370484074330','test'),('2018-11-01 15:59:59','2018-11-01 23:59:59','GTOBNB','4h','0.007270000000000','0.007180000000000','0.793226726762787','0.783406863570400','109.10959102651816','109.109591026518160','test'),('2018-11-02 15:59:59','2018-11-02 19:59:59','GTOBNB','4h','0.007180000000000','0.007140000000000','0.793226726762787','0.788807636362994','110.47725999481715','110.477259994817146','test'),('2018-11-11 19:59:59','2018-11-11 23:59:59','GTOBNB','4h','0.006860000000000','0.006790000000000','0.793226726762787','0.785132576489697','115.6307181869952','115.630718186995196','test'),('2018-11-28 03:59:59','2018-11-30 11:59:59','GTOBNB','4h','0.005790000000000','0.005830000000000','0.793226726762787','0.798706704149749','136.9994346740565','136.999434674056488','test'),('2018-12-22 03:59:59','2018-12-22 15:59:59','GTOBNB','4h','0.004690000000000','0.004630000000000','0.793226726762787','0.783078836868167','169.13149824366462','169.131498243664623','test'),('2018-12-25 03:59:59','2018-12-25 07:59:59','GTOBNB','4h','0.004650000000000','0.004540000000000','0.793226726762787','0.774462223549044','170.58639285221227','170.586392852212271','test'),('2018-12-27 15:59:59','2018-12-27 19:59:59','GTOBNB','4h','0.004730000000000','0.004470000000000','0.793226726762787','0.749624411972444','167.7012107320903','167.701210732090289','test'),('2019-01-03 11:59:59','2019-01-03 23:59:59','GTOBNB','4h','0.004470000000000','0.004400000000000','0.793226726762787','0.780804831712811','177.4556435710933','177.455643571093304','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','GTOBNB','4h','0.004340000000000','0.004350000000000','0.793226726762787','0.795054438114775','182.77113519879885','182.771135198798845','test'),('2019-01-07 23:59:59','2019-01-08 03:59:59','GTOBNB','4h','0.004390000000000','0.004320000000000','0.793226726762787','0.780578464604838','180.68945939926812','180.689459399268117','test'),('2019-01-15 03:59:59','2019-01-18 11:59:59','GTOBNB','4h','0.004380000000000','0.004390000000000','0.793226726762787','0.795037746686903','181.1019924115952','181.101992411595205','test'),('2019-01-19 11:59:59','2019-01-19 15:59:59','GTOBNB','4h','0.004570000000000','0.004450000000000','0.793226726762787','0.772398016213217','173.5725879130825','173.572587913082486','test'),('2019-01-22 11:59:59','2019-01-22 15:59:59','GTOBNB','4h','0.004430000000000','0.004410000000000','0.793226726762787','0.789645567725483','179.05795186518895','179.057951865188954','test'),('2019-01-25 03:59:59','2019-01-25 11:59:59','GTOBNB','4h','0.004570000000000','0.004410000000000','0.793226726762787','0.765455112696694','173.5725879130825','173.572587913082486','test'),('2019-02-17 07:59:59','2019-02-17 15:59:59','GTOBNB','4h','0.003210000000000','0.003110000000000','0.793226726762787','0.768515613779523','247.11112983264394','247.111129832643940','test'),('2019-02-26 03:59:59','2019-02-27 23:59:59','GTOBNB','4h','0.003040000000000','0.003020000000000','0.793226726762787','0.788008129876190','260.9298443298641','260.929844329864125','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','GTOBNB','4h','0.003000000000000','0.003010000000000','0.793226726762787','0.795870815851996','264.40890892092904','264.408908920929036','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','GTOBNB','4h','0.002430000000000','0.002380000000000','0.793226726762787','0.776905189175075','326.43075175423337','326.430751754233370','test'),('2019-03-13 23:59:59','2019-03-14 15:59:59','GTOBNB','4h','0.002430000000000','0.002420000000000','0.793226726762787','0.789962419245245','326.43075175423337','326.430751754233370','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','GTOBNB','4h','0.002360000000000','0.002370000000000','0.793226726762787','0.796587856960934','336.11301981474026','336.113019814740255','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','GTOBNB','4h','0.002370000000000','0.002330000000000','0.793226726762787','0.779838933906031','334.69482141889745','334.694821418897448','test'),('2019-03-29 19:59:59','2019-03-29 23:59:59','GTOBNB','4h','0.002190000000000','0.002220000000000','0.793226726762787','0.804092846307483','362.2039848231904','362.203984823190410','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','GTOBNB','4h','0.002210000000000','0.002140000000000','0.793226726762787','0.768101898313287','358.9261207071434','358.926120707143411','test'),('2019-04-08 03:59:59','2019-04-08 07:59:59','GTOBNB','4h','0.002090000000000','0.002050000000000','0.793226726762787','0.778045354001777','379.534319025257','379.534319025256991','test'),('2019-04-08 23:59:59','2019-04-09 03:59:59','GTOBNB','4h','0.002080000000000','0.002070000000000','0.793226726762787','0.789413136730274','381.35900325133997','381.359003251339971','test'),('2019-04-10 07:59:59','2019-04-10 23:59:59','GTOBNB','4h','0.002080000000000','0.002030000000000','0.793226726762787','0.774158776600220','381.35900325133997','381.359003251339971','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','GTOBNB','4h','0.001910000000000','0.001780000000000','0.793226726762787','0.739237473108775','415.3019511847053','415.301951184705274','test'),('2019-04-24 07:59:59','2019-04-24 11:59:59','GTOBNB','4h','0.001770000000000','0.001620000000000','0.793226726762787','0.726004122799839','448.15069308632036','448.150693086320359','test'),('2019-05-21 03:59:59','2019-05-21 23:59:59','GTOBNB','4h','0.001230000000000','0.001040000000000','0.793226726762787','0.670695768970161','644.8997778559244','644.899777855924413','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','GTOBNB','4h','0.001110000000000','0.001040000000000','0.793226726762787','0.743203419669638','714.6186727592675','714.618672759267497','test'),('2019-05-26 03:59:59','2019-05-26 07:59:59','GTOBNB','4h','0.001090000000000','0.001050000000000','0.528817817841858','0.509411659388946','485.15396132280546','485.153961322805458','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  8:40:38
