-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-26 19:59:59','2018-07-26 23:59:59','VIABTC','4h','0.000168700000000','0.000165600000000','0.001467500000000','0.001440533491405','8.698873740367516','8.698873740367516','test'),('2018-07-28 11:59:59','2018-07-30 11:59:59','VIABTC','4h','0.000179500000000','0.000166200000000','0.001467500000000','0.001358766016713','8.175487465181059','8.175487465181059','test'),('2018-08-20 03:59:59','2018-08-20 07:59:59','VIABTC','4h','0.000137600000000','0.000134600000000','0.001467500000000','0.001435505087209','10.664970930232558','10.664970930232558','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','VIABTC','4h','0.000131800000000','0.000127600000000','0.001467500000000','0.001420735963581','11.134294385432474','11.134294385432474','test'),('2018-08-28 07:59:59','2018-08-30 07:59:59','VIABTC','4h','0.000136500000000','0.000131500000000','0.001467500000000','0.001413745421245','10.75091575091575','10.750915750915750','test'),('2018-09-01 19:59:59','2018-09-02 03:59:59','VIABTC','4h','0.000133100000000','0.000131100000000','0.001467500000000','0.001445448910594','11.025544703230652','11.025544703230652','test'),('2018-09-03 23:59:59','2018-09-04 03:59:59','VIABTC','4h','0.000131100000000','0.000130400000000','0.001467500000000','0.001459664378337','11.193745232646837','11.193745232646837','test'),('2018-09-05 19:59:59','2018-09-05 23:59:59','VIABTC','4h','0.000133300000000','0.000128600000000','0.001467500000000','0.001415757689422','11.009002250562641','11.009002250562641','test'),('2018-09-28 11:59:59','2018-09-28 19:59:59','VIABTC','4h','0.000101200000000','0.000094300000000','0.001467500000000','0.001367443181818','14.500988142292492','14.500988142292492','test'),('2018-09-30 19:59:59','2018-10-02 15:59:59','VIABTC','4h','0.000114600000000','0.000098100000000','0.001467500000000','0.001256210732984','12.80541012216405','12.805410122164050','test'),('2018-10-08 19:59:59','2018-10-08 23:59:59','VIABTC','4h','0.000095600000000','0.000095400000000','0.001467500000000','0.001464429916318','15.35041841004184','15.350418410041840','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','VIABTC','4h','0.000099200000000','0.000095800000000','0.001467500000000','0.001417202620968','14.79334677419355','14.793346774193550','test'),('2018-10-13 19:59:59','2018-10-13 23:59:59','VIABTC','4h','0.000097500000000','0.000098200000000','0.001467500000000','0.001478035897436','15.051282051282053','15.051282051282053','test'),('2018-10-22 19:59:59','2018-11-04 11:59:59','VIABTC','4h','0.000100100000000','0.000115700000000','0.001467500000000','0.001696201298701','14.660339660339663','14.660339660339663','test'),('2018-11-09 11:59:59','2018-11-09 23:59:59','VIABTC','4h','0.000116000000000','0.000115200000000','0.001467500000000','0.001457379310345','12.650862068965518','12.650862068965518','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','VIABTC','4h','0.000116200000000','0.000116500000000','0.001467500000000','0.001471288726334','12.62908777969019','12.629087779690190','test'),('2018-11-29 19:59:59','2018-11-29 23:59:59','VIABTC','4h','0.000088100000000','0.000086200000000','0.001467500000000','0.001435851305335','16.657207718501702','16.657207718501702','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','VIABTC','4h','0.000086400000000','0.000086500000000','0.001467500000000','0.001469198495370','16.984953703703706','16.984953703703706','test'),('2018-12-02 15:59:59','2018-12-03 03:59:59','VIABTC','4h','0.000092600000000','0.000084800000000','0.001467500000000','0.001343887688985','15.847732181425487','15.847732181425487','test'),('2018-12-03 19:59:59','2018-12-04 07:59:59','VIABTC','4h','0.000087900000000','0.000085900000000','0.001467500000000','0.001434109783845','16.69510807736064','16.695108077360640','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','VIABTC','4h','0.000080900000000','0.000079400000000','0.001467500000000','0.001440290482077','18.139678615574784','18.139678615574784','test'),('2018-12-20 03:59:59','2018-12-20 11:59:59','VIABTC','4h','0.000082100000000','0.000081600000000','0.001467500000000','0.001458562728380','17.87454323995128','17.874543239951279','test'),('2018-12-26 03:59:59','2018-12-26 07:59:59','VIABTC','4h','0.000084200000000','0.000083500000000','0.001467500000000','0.001455299881235','17.42874109263658','17.428741092636582','test'),('2018-12-26 23:59:59','2018-12-27 07:59:59','VIABTC','4h','0.000083600000000','0.000083500000000','0.001467500000000','0.001465744617225','17.553827751196174','17.553827751196174','test'),('2018-12-27 15:59:59','2018-12-27 19:59:59','VIABTC','4h','0.000085200000000','0.000081900000000','0.001467500000000','0.001410660211268','17.224178403755868','17.224178403755868','test'),('2018-12-28 19:59:59','2018-12-29 03:59:59','VIABTC','4h','0.000084300000000','0.000084000000000','0.001467500000000','0.001462277580071','17.408066429418742','17.408066429418742','test'),('2019-01-02 19:59:59','2019-01-02 23:59:59','VIABTC','4h','0.000082600000000','0.000081300000000','0.001467500000000','0.001444403753027','17.76634382566586','17.766343825665860','test'),('2019-01-03 07:59:59','2019-01-03 11:59:59','VIABTC','4h','0.000082600000000','0.000083100000000','0.001467500000000','0.001476383171913','17.76634382566586','17.766343825665860','test'),('2019-01-04 03:59:59','2019-01-04 11:59:59','VIABTC','4h','0.000082700000000','0.000081500000000','0.001467500000000','0.001446206166868','17.744860943168078','17.744860943168078','test'),('2019-01-05 07:59:59','2019-01-05 23:59:59','VIABTC','4h','0.000082400000000','0.000093700000000','0.001467500000000','0.001668746966019','17.809466019417478','17.809466019417478','test'),('2019-01-10 07:59:59','2019-01-10 11:59:59','VIABTC','4h','0.000083700000000','0.000082700000000','0.001467500000000','0.001449967144564','17.532855436081242','17.532855436081242','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','VIABTC','4h','0.000081000000000','0.000080700000000','0.001467500000000','0.001462064814815','18.117283950617285','18.117283950617285','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','VIABTC','4h','0.000085400000000','0.000085100000000','0.001467500000000','0.001462344847775','17.18384074941452','17.183840749414522','test'),('2019-01-30 15:59:59','2019-01-31 11:59:59','VIABTC','4h','0.000086600000000','0.000083100000000','0.001467500000000','0.001408189953811','16.945727482678983','16.945727482678983','test'),('2019-02-04 03:59:59','2019-02-04 07:59:59','VIABTC','4h','0.000085800000000','0.000087000000000','0.001467500000000','0.001488024475524','17.103729603729604','17.103729603729604','test'),('2019-02-05 11:59:59','2019-02-05 15:59:59','VIABTC','4h','0.000084900000000','0.000083500000000','0.001467500000000','0.001443300942285','17.285041224970552','17.285041224970552','test'),('2019-02-07 15:59:59','2019-02-07 19:59:59','VIABTC','4h','0.000084300000000','0.000082200000000','0.001467500000000','0.001430943060498','17.408066429418742','17.408066429418742','test'),('2019-02-08 11:59:59','2019-02-08 19:59:59','VIABTC','4h','0.000084800000000','0.000083800000000','0.001467500000000','0.001450194575472','17.305424528301888','17.305424528301888','test'),('2019-02-09 19:59:59','2019-02-09 23:59:59','VIABTC','4h','0.000083600000000','0.000083400000000','0.001467500000000','0.001463989234450','17.553827751196174','17.553827751196174','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','VIABTC','4h','0.000083400000000','0.000083200000000','0.001467500000000','0.001463980815348','17.59592326139089','17.595923261390890','test'),('2019-02-11 07:59:59','2019-02-11 11:59:59','VIABTC','4h','0.000083800000000','0.000083500000000','0.001467500000000','0.001462246420048','17.511933174224342','17.511933174224342','test'),('2019-02-19 11:59:59','2019-02-19 19:59:59','VIABTC','4h','0.000085700000000','0.000085900000000','0.001467500000000','0.001470924737456','17.123687281213538','17.123687281213538','test'),('2019-02-20 11:59:59','2019-02-20 15:59:59','VIABTC','4h','0.000085700000000','0.000086900000000','0.001467500000000','0.001488048424737','17.123687281213538','17.123687281213538','test'),('2019-02-24 11:59:59','2019-02-24 15:59:59','VIABTC','4h','0.000088100000000','0.000085200000000','0.001467500000000','0.001419194097616','16.657207718501702','16.657207718501702','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','VIABTC','4h','0.000087000000000','0.000087100000000','0.001467500000000','0.001469186781609','16.867816091954023','16.867816091954023','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','VIABTC','4h','0.000087400000000','0.000086900000000','0.001467500000000','0.001459104691076','16.790617848970253','16.790617848970253','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','VIABTC','4h','0.000087400000000','0.000087500000000','0.001467500000000','0.001469179061785','16.790617848970253','16.790617848970253','test'),('2019-04-02 19:59:59','2019-04-02 23:59:59','VIABTC','4h','0.000132800000000','0.000130800000000','0.001467500000000','0.001445399096386','11.050451807228916','11.050451807228916','test'),('2019-04-17 19:59:59','2019-04-17 23:59:59','VIABTC','4h','0.000119100000000','0.000109900000000','0.001467500000000','0.001354141477750','12.3215785054576','12.321578505457600','test'),('2019-04-30 23:59:59','2019-05-01 03:59:59','VIABTC','4h','0.000093700000000','0.000095000000000','0.001467500000000','0.001487860192102','15.661686232657418','15.661686232657418','test'),('2019-05-02 19:59:59','2019-05-08 03:59:59','VIABTC','4h','0.000099600000000','0.000103500000000','0.001467500000000','0.001524962349398','14.73393574297189','14.733935742971889','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','VIABTC','4h','0.000106100000000','0.000100800000000','0.001467500000000','0.001394194156456','13.83129123468426','13.831291234684260','test'),('2019-05-18 23:59:59','2019-05-19 03:59:59','VIABTC','4h','0.000094900000000','0.000090000000000','0.001467500000000','0.001391728134879','15.463645943097998','15.463645943097998','test'),('2019-05-21 15:59:59','2019-05-22 11:59:59','VIABTC','4h','0.000094800000000','0.000092700000000','0.001467500000000','0.001434992088608','15.479957805907173','15.479957805907173','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','VIABTC','4h','0.000071800000000','0.000071300000000','0.001467500000000','0.001457280640669','20.43871866295265','20.438718662952649','test'),('2019-06-09 11:59:59','2019-06-09 15:59:59','VIABTC','4h','0.000072600000000','0.000070300000000','0.001467500000000','0.001421008953168','20.213498622589533','20.213498622589533','test'),('2019-06-10 11:59:59','2019-06-10 15:59:59','VIABTC','4h','0.000071700000000','0.000075700000000','0.001467500000000','0.001549368898187','20.467224546722456','20.467224546722456','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','VIABTC','4h','0.000074500000000','0.000069300000000','0.001467500000000','0.001365070469799','19.69798657718121','19.697986577181211','test'),('2019-07-02 07:59:59','2019-07-02 15:59:59','VIABTC','4h','0.000045500000000','0.000044100000000','0.001467500000000','0.001422346153846','32.252747252747255','32.252747252747255','test'),('2019-07-07 11:59:59','2019-07-07 15:59:59','VIABTC','4h','0.000042400000000','0.000041600000000','0.001467500000000','0.001439811320755','34.610849056603776','34.610849056603776','test'),('2019-07-23 19:59:59','2019-07-23 23:59:59','VIABTC','4h','0.000033500000000','0.000033300000000','0.001467500000000','0.001458738805970','43.80597014925373','43.805970149253731','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  4:18:17
