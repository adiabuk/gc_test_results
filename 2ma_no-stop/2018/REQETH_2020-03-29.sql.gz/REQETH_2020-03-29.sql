-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-13 15:59:59','2018-04-13 19:59:59','REQETH','4h','0.000400880000000','0.000394520000000','0.072144500000000','0.070999920524845','179.9653262821792','179.965326282179205','test'),('2018-04-14 11:59:59','2018-04-15 15:59:59','REQETH','4h','0.000423150000000','0.000400930000000','0.072144500000000','0.068356125215645','170.49391468746308','170.493914687463075','test'),('2018-04-16 15:59:59','2018-04-16 19:59:59','REQETH','4h','0.000400000000000','0.000414450000000','0.072144500000000','0.074750720062500','180.36124999999998','180.361249999999984','test'),('2018-04-23 19:59:59','2018-04-23 23:59:59','REQETH','4h','0.000395230000000','0.000391440000000','0.072144500000000','0.071452680919971','182.53801583887864','182.538015838878636','test'),('2018-04-24 11:59:59','2018-04-24 15:59:59','REQETH','4h','0.000397280000000','0.000396040000000','0.072144500000000','0.071919320831655','181.59610350382601','181.596103503826015','test'),('2018-04-27 15:59:59','2018-04-27 19:59:59','REQETH','4h','0.000394990000000','0.000392890000000','0.072144500000000','0.071760937251576','182.64892782095748','182.648927820957482','test'),('2018-04-28 23:59:59','2018-04-29 11:59:59','REQETH','4h','0.000386310000000','0.000386660000000','0.072144500000000','0.072209863503404','186.75286686857706','186.752866868577058','test'),('2018-04-30 15:59:59','2018-05-03 07:59:59','REQETH','4h','0.000425650000000','0.000404590000000','0.072144500000000','0.068574987090332','169.49254081992245','169.492540819922453','test'),('2018-06-17 03:59:59','2018-06-18 03:59:59','REQETH','4h','0.000205250000000','0.000204000000000','0.072144500000000','0.071705130328867','351.49573690621196','351.495736906211960','test'),('2018-06-19 03:59:59','2018-06-19 07:59:59','REQETH','4h','0.000202690000000','0.000191920000000','0.072144500000000','0.068311078198234','355.9351719374414','355.935171937441396','test'),('2018-07-01 23:59:59','2018-07-02 03:59:59','REQETH','4h','0.000179760000000','0.000176250000000','0.072144500000000','0.070735803988652','401.33789497107256','401.337894971072558','test'),('2018-07-04 11:59:59','2018-07-05 19:59:59','REQETH','4h','0.000173600000000','0.000171220000000','0.072144500000000','0.071155422177419','415.57891705069125','415.578917050691246','test'),('2018-07-06 03:59:59','2018-07-06 07:59:59','REQETH','4h','0.000175340000000','0.000169400000000','0.072144500000000','0.069700457967378','411.4548876468575','411.454887646857514','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','REQETH','4h','0.000157540000000','0.000155960000000','0.072144500000000','0.071420948457535','457.94401421861113','457.944014218611130','test'),('2018-07-18 15:59:59','2018-07-20 15:59:59','REQETH','4h','0.000159150000000','0.000164510000000','0.072144500000000','0.074574248790449','453.31134150172795','453.311341501727952','test'),('2018-08-07 19:59:59','2018-08-08 03:59:59','REQETH','4h','0.000140000000000','0.000124780000000','0.072144500000000','0.064301362214286','515.3178571428572','515.317857142857179','test'),('2018-08-09 15:59:59','2018-08-09 19:59:59','REQETH','4h','0.000127600000000','0.000125010000000','0.072144500000000','0.070680124960815','565.3957680250783','565.395768025078269','test'),('2018-08-10 07:59:59','2018-08-11 11:59:59','REQETH','4h','0.000130000000000','0.000125850000000','0.072144500000000','0.069841425576923','554.9576923076924','554.957692307692355','test'),('2018-08-17 07:59:59','2018-09-05 11:59:59','REQETH','4h','0.000127820000000','0.000169710000000','0.072144500000000','0.095788163785010','564.4226255672039','564.422625567203909','test'),('2018-09-06 11:59:59','2018-09-06 15:59:59','REQETH','4h','0.000167780000000','0.000166750000000','0.072144500000000','0.071701605525092','429.994635832638','429.994635832637982','test'),('2018-09-12 19:59:59','2018-09-12 23:59:59','REQETH','4h','0.000172660000000','0.000169130000000','0.072144500000000','0.070669519778756','417.84142244874323','417.841422448743231','test'),('2018-09-13 11:59:59','2018-09-13 15:59:59','REQETH','4h','0.000173370000000','0.000170270000000','0.072144500000000','0.070854496250793','416.1302416796447','416.130241679644712','test'),('2018-09-17 03:59:59','2018-09-21 19:59:59','REQETH','4h','0.000172870000000','0.000172880000000','0.072144500000000','0.072148673338347','417.3338346734541','417.333834673454078','test'),('2018-09-22 03:59:59','2018-09-22 07:59:59','REQETH','4h','0.000176910000000','0.000174630000000','0.072144500000000','0.071214708241479','407.8034028602114','407.803402860211406','test'),('2018-09-25 03:59:59','2018-09-25 07:59:59','REQETH','4h','0.000174600000000','0.000178780000000','0.072144500000000','0.073871670733104','413.1987399770905','413.198739977090497','test'),('2018-10-09 19:59:59','2018-10-10 07:59:59','REQETH','4h','0.000202980000000','0.000199270000000','0.072144500000000','0.070825867154399','355.42664301901664','355.426643019016637','test'),('2018-10-11 15:59:59','2018-10-23 19:59:59','REQETH','4h','0.000215300000000','0.000276900000000','0.072144500000000','0.092785936135625','335.0882489549466','335.088248954946607','test'),('2018-10-24 15:59:59','2018-10-24 19:59:59','REQETH','4h','0.000281000000000','0.000278720000000','0.075746924750773','0.075132323368454','269.56200978922686','269.562009789226863','test'),('2018-10-30 23:59:59','2018-10-31 03:59:59','REQETH','4h','0.000272400000000','0.000262780000000','0.075746924750773','0.073071868157152','278.0724109793429','278.072410979342919','test'),('2018-10-31 15:59:59','2018-11-02 23:59:59','REQETH','4h','0.000262550000000','0.000258390000000','0.075746924750773','0.074546744948971','288.5047600486498','288.504760048649814','test'),('2018-11-09 19:59:59','2018-11-10 03:59:59','REQETH','4h','0.000250540000000','0.000248440000000','0.075746924750773','0.075112021972867','302.33465614581706','302.334656145817064','test'),('2018-11-26 19:59:59','2018-11-28 23:59:59','REQETH','4h','0.000215920000000','0.000210000000000','0.075746924750773','0.073670128740563','350.8101368598231','350.810136859823103','test'),('2018-11-30 15:59:59','2018-12-02 11:59:59','REQETH','4h','0.000218570000000','0.000217300000000','0.075746924750773','0.075306797585867','346.55682276054813','346.556822760548130','test'),('2018-12-05 11:59:59','2018-12-05 15:59:59','REQETH','4h','0.000220470000000','0.000223340000000','0.075746924750773','0.076732971260660','343.57021250407314','343.570212504073140','test'),('2018-12-08 03:59:59','2018-12-08 19:59:59','REQETH','4h','0.000222710000000','0.000228140000000','0.075746924750773','0.077593747082041','340.1146098099457','340.114609809945705','test'),('2018-12-15 23:59:59','2018-12-16 03:59:59','REQETH','4h','0.000229850000000','0.000227160000000','0.075746924750773','0.074860436921408','329.5493789461519','329.549378946151876','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','REQETH','4h','0.000228290000000','0.000227240000000','0.075746924750773','0.075398533358297','331.8013261674756','331.801326167475622','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','REQETH','4h','0.000229030000000','0.000226770000000','0.075746924750773','0.074999476600152','330.7292701863206','330.729270186320605','test'),('2018-12-18 03:59:59','2018-12-18 07:59:59','REQETH','4h','0.000228060000000','0.000225050000000','0.075746924750773','0.074747195541355','332.1359499726958','332.135949972695812','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','REQETH','4h','0.000164250000000','0.000162870000000','0.075746924750773','0.075110512232319','461.1684916333212','461.168491633321196','test'),('2019-01-11 07:59:59','2019-01-11 19:59:59','REQETH','4h','0.000165670000000','0.000166990000000','0.075746924750773','0.076350449472636','457.21569838095616','457.215698380956155','test'),('2019-01-12 23:59:59','2019-01-13 07:59:59','REQETH','4h','0.000166970000000','0.000166210000000','0.075746924750773','0.075402146270743','453.65589477614543','453.655894776145431','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','REQETH','4h','0.000166430000000','0.000166220000000','0.075746924750773','0.075651347906468','455.1278300232711','455.127830023271088','test'),('2019-01-29 19:59:59','2019-01-31 07:59:59','REQETH','4h','0.000196000000000','0.000190140000000','0.075746924750773','0.073482246286286','386.4639017896582','386.463901789658223','test'),('2019-02-07 19:59:59','2019-02-08 11:59:59','REQETH','4h','0.000187860000000','0.000183930000000','0.075746924750773','0.074162311665121','403.20943655260834','403.209436552608338','test'),('2019-02-28 15:59:59','2019-03-04 07:59:59','REQETH','4h','0.000155840000000','0.000159190000000','0.075746924750773','0.077375211441707','486.0557286368904','486.055728636890422','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','REQETH','4h','0.000156890000000','0.000156930000000','0.075746924750773','0.075766236861105','482.8027583069221','482.802758306922101','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','REQETH','4h','0.000158460000000','0.000156790000000','0.075746924750773','0.074948632662336','478.01921463317564','478.019214633175636','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','REQETH','4h','0.000186950000000','0.000188750000000','0.075746924750773','0.076476234537087','405.1721035077454','405.172103507745419','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','REQETH','4h','0.000194250000000','0.000193740000000','0.075746924750773','0.075548052515906','389.945558562538','389.945558562537997','test'),('2019-04-04 19:59:59','2019-04-04 23:59:59','REQETH','4h','0.000191890000000','0.000195660000000','0.075746924750773','0.077235099779750','394.7413869965762','394.741386996576182','test'),('2019-04-07 15:59:59','2019-04-07 23:59:59','REQETH','4h','0.000196970000000','0.000182610000000','0.075746924750773','0.070224632831084','384.5607186412804','384.560718641280403','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:27:46
