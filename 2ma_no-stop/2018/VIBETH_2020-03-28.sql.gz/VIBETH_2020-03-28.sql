-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-20 11:59:59','2018-04-20 15:59:59','VIBETH','4h','0.000333600000000','0.000330250000000','0.072144500000000','0.071420027353118','216.26049160671465','216.260491606714652','test'),('2018-04-26 19:59:59','2018-04-27 15:59:59','VIBETH','4h','0.000322360000000','0.000313570000000','0.072144500000000','0.070177288947140','223.80102990445465','223.801029904454651','test'),('2018-04-27 23:59:59','2018-04-28 03:59:59','VIBETH','4h','0.000323020000000','0.000308970000000','0.072144500000000','0.069006520230945','223.34375580459417','223.343755804594167','test'),('2018-04-28 19:59:59','2018-04-28 23:59:59','VIBETH','4h','0.000318010000000','0.000317670000000','0.072144500000000','0.072067366796642','226.86236281877927','226.862362818779275','test'),('2018-04-29 19:59:59','2018-04-30 07:59:59','VIBETH','4h','0.000317060000000','0.000310500000000','0.072144500000000','0.070651823787296','227.5421055951555','227.542105595155505','test'),('2018-04-30 15:59:59','2018-05-01 03:59:59','VIBETH','4h','0.000324870000000','0.000317890000000','0.072144500000000','0.070594438098316','222.07190568535106','222.071905685351055','test'),('2018-05-14 15:59:59','2018-05-14 19:59:59','VIBETH','4h','0.000268450000000','0.000266570000000','0.072144500000000','0.071639260067052','268.7446451853232','268.744645185323179','test'),('2018-05-15 03:59:59','2018-05-16 07:59:59','VIBETH','4h','0.000278000000000','0.000262000000000','0.072144500000000','0.067992298561151','259.5125899280576','259.512589928057594','test'),('2018-05-17 15:59:59','2018-05-18 15:59:59','VIBETH','4h','0.000274490000000','0.000278650000000','0.072144500000000','0.073237877245073','262.8310685270866','262.831068527086586','test'),('2018-05-20 15:59:59','2018-05-20 19:59:59','VIBETH','4h','0.000280930000000','0.000276310000000','0.072144500000000','0.070958056437547','256.8059658989784','256.805965898978400','test'),('2018-07-02 15:59:59','2018-07-03 11:59:59','VIBETH','4h','0.000161310000000','0.000159590000000','0.072144500000000','0.071375244901122','447.24133655694004','447.241336556940041','test'),('2018-07-13 23:59:59','2018-07-14 03:59:59','VIBETH','4h','0.000174890000000','0.000172740000000','0.072144500000000','0.071257595803076','412.51357996454914','412.513579964549137','test'),('2018-07-18 15:59:59','2018-07-18 23:59:59','VIBETH','4h','0.000169780000000','0.000167840000000','0.072144500000000','0.071320137118624','424.92932029685477','424.929320296854769','test'),('2018-07-22 19:59:59','2018-07-22 23:59:59','VIBETH','4h','0.000165630000000','0.000162430000000','0.072144500000000','0.070750655889634','435.5762844895248','435.576284489524824','test'),('2018-07-23 07:59:59','2018-07-23 11:59:59','VIBETH','4h','0.000168900000000','0.000154520000000','0.072144500000000','0.066002179632919','427.1432800473653','427.143280047365295','test'),('2018-07-29 15:59:59','2018-07-30 19:59:59','VIBETH','4h','0.000158960000000','0.000151660000000','0.072144500000000','0.068831371854555','453.8531706089582','453.853170608958180','test'),('2018-08-10 07:59:59','2018-08-10 11:59:59','VIBETH','4h','0.000130590000000','0.000124200000000','0.072144500000000','0.068614341833218','552.4504173367026','552.450417336702571','test'),('2018-08-10 15:59:59','2018-08-10 23:59:59','VIBETH','4h','0.000134070000000','0.000129300000000','0.072144500000000','0.069577712016111','538.110688446334','538.110688446334052','test'),('2018-08-13 11:59:59','2018-08-13 15:59:59','VIBETH','4h','0.000126340000000','0.000129680000000','0.072144500000000','0.074051755263574','571.03451005224','571.034510052239966','test'),('2018-08-17 15:59:59','2018-08-17 23:59:59','VIBETH','4h','0.000124250000000','0.000122080000000','0.072144500000000','0.070884511549296','580.6398390342051','580.639839034205124','test'),('2018-08-19 23:59:59','2018-08-20 03:59:59','VIBETH','4h','0.000121950000000','0.000120870000000','0.072144500000000','0.071505581918819','591.5908159081591','591.590815908159129','test'),('2018-08-20 07:59:59','2018-08-30 03:59:59','VIBETH','4h','0.000121810000000','0.000136020000000','0.072144500000000','0.080560667350792','592.2707495279534','592.270749527953399','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','VIBETH','4h','0.000151490000000','0.000148230000000','0.072144500000000','0.070591981219883','476.2327546372698','476.232754637269807','test'),('2018-09-16 15:59:59','2018-09-16 19:59:59','VIBETH','4h','0.000151290000000','0.000151610000000','0.072144500000000','0.072297095941569','476.86231740366185','476.862317403661848','test'),('2018-09-23 07:59:59','2018-09-23 15:59:59','VIBETH','4h','0.000163630000000','0.000155500000000','0.072144500000000','0.068559981360386','440.90020167450956','440.900201674509560','test'),('2018-09-24 07:59:59','2018-09-24 11:59:59','VIBETH','4h','0.000160700000000','0.000152610000000','0.072144500000000','0.068512583354076','448.93901680149344','448.939016801493437','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','VIBETH','4h','0.000160170000000','0.000158520000000','0.072144500000000','0.071401299494287','450.4245489167759','450.424548916775905','test'),('2018-09-30 07:59:59','2018-09-30 11:59:59','VIBETH','4h','0.000171660000000','0.000169830000000','0.072144500000000','0.071375395753233','420.27554468134684','420.275544681346844','test'),('2018-10-01 15:59:59','2018-10-01 19:59:59','VIBETH','4h','0.000170440000000','0.000171970000000','0.072144500000000','0.072792124295940','423.2838535555034','423.283853555503413','test'),('2018-11-08 11:59:59','2018-11-08 19:59:59','VIBETH','4h','0.000247720000000','0.000252620000000','0.072144500000000','0.073571546867431','291.2340545777491','291.234054577749077','test'),('2018-11-09 23:59:59','2018-11-10 03:59:59','VIBETH','4h','0.000246950000000','0.000243610000000','0.072144500000000','0.071168745272322','292.1421340352298','292.142134035229788','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','VIBETH','4h','0.000247450000000','0.000248600000000','0.072144500000000','0.072479784602950','291.55182865225294','291.551828652252937','test'),('2018-11-11 19:59:59','2018-11-13 15:59:59','VIBETH','4h','0.000255690000000','0.000249110000000','0.072144500000000','0.070287912687238','282.15612655950565','282.156126559505651','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','VIBETH','4h','0.000199070000000','0.000198160000000','0.072144500000000','0.071814708996835','362.4076957854021','362.407695785402097','test'),('2018-12-08 03:59:59','2018-12-14 03:59:59','VIBETH','4h','0.000221140000000','0.000226400000000','0.072144500000000','0.073860517319345','326.23903409604776','326.239034096047760','test'),('2018-12-15 03:59:59','2018-12-15 07:59:59','VIBETH','4h','0.000230390000000','0.000230510000000','0.072144500000000','0.072182076891358','313.1407613177655','313.140761317765509','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','VIBETH','4h','0.000230290000000','0.000231800000000','0.072144500000000','0.072617547874419','313.2767380259673','313.276738025967290','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','VIBETH','4h','0.000229850000000','0.000222210000000','0.072144500000000','0.069746483989558','313.8764411572765','313.876441157276474','test'),('2019-01-07 23:59:59','2019-01-08 03:59:59','VIBETH','4h','0.000173720000000','0.000176670000000','0.072144500000000','0.073369610954409','415.2918489523371','415.291848952337091','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','VIBETH','4h','0.000176500000000','0.000173250000000','0.072144500000000','0.070816060198300','408.75070821529744','408.750708215297436','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','VIBETH','4h','0.000177850000000','0.000175780000000','0.072144500000000','0.071304808602755','405.6480179926904','405.648017992690427','test'),('2019-01-28 19:59:59','2019-01-29 07:59:59','VIBETH','4h','0.000207100000000','0.000203070000000','0.072144500000000','0.070740625857074','348.3558667310478','348.355866731047797','test'),('2019-01-29 11:59:59','2019-01-31 03:59:59','VIBETH','4h','0.000211210000000','0.000201390000000','0.072144500000000','0.068790212845036','341.5771033568486','341.577103356848625','test'),('2019-02-01 07:59:59','2019-02-01 11:59:59','VIBETH','4h','0.000208150000000','0.000212880000000','0.072144500000000','0.073783911410041','346.5986067739611','346.598606773961080','test'),('2019-02-03 15:59:59','2019-02-03 19:59:59','VIBETH','4h','0.000208160000000','0.000206190000000','0.072144500000000','0.071461733546311','346.58195618754803','346.581956187548030','test'),('2019-02-04 11:59:59','2019-02-04 15:59:59','VIBETH','4h','0.000207560000000','0.000206210000000','0.072144500000000','0.071675261827905','347.58383118134515','347.583831181345147','test'),('2019-02-04 19:59:59','2019-02-04 23:59:59','VIBETH','4h','0.000209390000000','0.000209110000000','0.072144500000000','0.072048027102536','344.546062371651','344.546062371650976','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','VIBETH','4h','0.000210080000000','0.000210130000000','0.072144500000000','0.072161670720678','343.4144135567403','343.414413556740328','test'),('2019-02-26 07:59:59','2019-02-27 11:59:59','VIBETH','4h','0.000173570000000','0.000171150000000','0.072144500000000','0.071138625194446','415.6507460966757','415.650746096675675','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','VIBETH','4h','0.000177960000000','0.000175290000000','0.072144500000000','0.071062089261632','405.3972802877051','405.397280287705087','test'),('2019-03-07 07:59:59','2019-03-07 11:59:59','VIBETH','4h','0.000179800000000','0.000181150000000','0.072144500000000','0.072686185622914','401.24860956618465','401.248609566184655','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','VIBETH','4h','0.000204270000000','0.000203740000000','0.072144500000000','0.071957313506633','353.18206295589175','353.182062955891752','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','VIBETH','4h','0.000204800000000','0.000205060000000','0.072144500000000','0.072236089697266','352.26806640625','352.268066406250000','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','VIBETH','4h','0.000204920000000','0.000203390000000','0.072144500000000','0.071605845476283','352.06178020691','352.061780206909987','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','VIBETH','4h','0.000206190000000','0.000212710000000','0.072144500000000','0.074425804330957','349.89330229400065','349.893302294000648','test'),('2019-04-05 23:59:59','2019-04-06 07:59:59','VIBETH','4h','0.000237920000000','0.000232890000000','0.072144500000000','0.070619252710995','303.23007733692','303.230077336919976','test'),('2019-04-07 15:59:59','2019-04-07 19:59:59','VIBETH','4h','0.000238000000000','0.000228960000000','0.072144500000000','0.069404221512605','303.1281512605042','303.128151260504183','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','VIBETH','4h','0.000237680000000','0.000221090000000','0.072144500000000','0.067108833326321','303.53626725008417','303.536267250084165','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','VIBETH','4h','0.000234710000000','0.000244880000000','0.072144500000000','0.075270526010822','307.37718887137316','307.377188871373164','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','VIBETH','4h','0.000227250000000','0.000223890000000','0.072144500000000','0.071077809042904','317.4675467546755','317.467546754675482','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','VIBETH','4h','0.000225470000000','0.000219000000000','0.072144500000000','0.070074269304120','319.9738324389054','319.973832438905390','test'),('2019-04-16 15:59:59','2019-04-16 15:59:59','VIBETH','4h','0.000227680000000','0.000227680000000','0.072144500000000','0.072144500000000','316.86797259311317','316.867972593113166','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:42:05
