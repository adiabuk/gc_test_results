-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-21 07:59:59','2018-09-21 11:59:59','ZILETH','4h','0.000161270000000','0.000158130000000','0.072144500000000','0.070739813883549','447.3522663855646','447.352266385564576','test'),('2018-09-25 07:59:59','2018-09-25 11:59:59','ZILETH','4h','0.000157760000000','0.000157840000000','0.072144500000000','0.072181084432049','457.3054006085193','457.305400608519278','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','ZILETH','4h','0.000157710000000','0.000150550000000','0.072144500000000','0.068869155253313','457.4503836154968','457.450383615496776','test'),('2018-10-01 07:59:59','2018-10-01 15:59:59','ZILETH','4h','0.000156550000000','0.000155850000000','0.072144500000000','0.071821912008943','460.8399872245289','460.839987224528898','test'),('2018-10-05 23:59:59','2018-10-06 03:59:59','ZILETH','4h','0.000160110000000','0.000161600000000','0.072144500000000','0.072815884079695','450.59334207732184','450.593342077321836','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','ZILETH','4h','0.000161240000000','0.000160510000000','0.072144500000000','0.071817872085091','447.43549987596134','447.435499875961341','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','ZILETH','4h','0.000166150000000','0.000165140000000','0.072144500000000','0.071705944808908','434.2130604875113','434.213060487511314','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','ZILETH','4h','0.000164080000000','0.000163800000000','0.072144500000000','0.072021386518771','439.6910043881034','439.691004388103408','test'),('2018-11-04 11:59:59','2018-11-04 15:59:59','ZILETH','4h','0.000176050000000','0.000175360000000','0.072144500000000','0.071861741096279','409.79551263845497','409.795512638454966','test'),('2018-11-27 11:59:59','2018-11-30 11:59:59','ZILETH','4h','0.000149630000000','0.000145690000000','0.072144500000000','0.070244818585845','482.1526431865268','482.152643186526802','test'),('2018-12-06 19:59:59','2018-12-06 23:59:59','ZILETH','4h','0.000151190000000','0.000149500000000','0.072144500000000','0.071338069647463','477.17772339440444','477.177723394404438','test'),('2018-12-08 07:59:59','2018-12-08 11:59:59','ZILETH','4h','0.000151710000000','0.000152950000000','0.072144500000000','0.072734172269461','475.54215279151015','475.542152791510148','test'),('2018-12-10 11:59:59','2018-12-10 15:59:59','ZILETH','4h','0.000150020000000','0.000149700000000','0.072144500000000','0.071990612251700','480.8992134382082','480.899213438208221','test'),('2018-12-11 03:59:59','2018-12-11 07:59:59','ZILETH','4h','0.000150660000000','0.000150500000000','0.072144500000000','0.072067882981548','478.8563653258994','478.856365325899390','test'),('2018-12-15 11:59:59','2018-12-15 15:59:59','ZILETH','4h','0.000152000000000','0.000151550000000','0.072144500000000','0.071930914309211','474.6348684210526','474.634868421052602','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','ZILETH','4h','0.000151600000000','0.000153450000000','0.072144500000000','0.073024891325858','475.8872031662269','475.887203166226925','test'),('2018-12-18 19:59:59','2018-12-20 19:59:59','ZILETH','4h','0.000168960000000','0.000151440000000','0.072144500000000','0.064663607244318','426.9915956439394','426.991595643939377','test'),('2018-12-21 11:59:59','2018-12-23 03:59:59','ZILETH','4h','0.000159220000000','0.000146120000000','0.072144500000000','0.066208732194448','453.11204622534854','453.112046225348536','test'),('2018-12-23 19:59:59','2018-12-23 23:59:59','ZILETH','4h','0.000155130000000','0.000152750000000','0.072144500000000','0.071037661155160','465.05833816798815','465.058338167988154','test'),('2018-12-29 11:59:59','2018-12-30 23:59:59','ZILETH','4h','0.000157560000000','0.000149660000000','0.072144500000000','0.068527201510536','457.8858847423204','457.885884742320400','test'),('2019-01-01 07:59:59','2019-01-01 11:59:59','ZILETH','4h','0.000150390000000','0.000148080000000','0.072144500000000','0.071036355874726','479.7160715473103','479.716071547310321','test'),('2019-01-07 03:59:59','2019-01-14 19:59:59','ZILETH','4h','0.000141260000000','0.000159480000000','0.072144500000000','0.081449843267733','510.72136485912495','510.721364859124947','test'),('2019-02-26 23:59:59','2019-02-27 03:59:59','ZILETH','4h','0.000130930000000','0.000129410000000','0.072144500000000','0.071306955968838','551.0158099747957','551.015809974795729','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','ZILETH','4h','0.000128910000000','0.000127050000000','0.072144500000000','0.071103550733070','559.6501435109766','559.650143510976591','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ZILETH','4h','0.000129220000000','0.000127930000000','0.072144500000000','0.071424283276583','558.3075375328896','558.307537532889569','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','ZILETH','4h','0.000128820000000','0.000126930000000','0.072144500000000','0.071086022240335','560.0411426797081','560.041142679708059','test'),('2019-03-08 15:59:59','2019-03-16 03:59:59','ZILETH','4h','0.000130100000000','0.000131000000000','0.072144500000000','0.072643578016910','554.5311299000768','554.531129900076849','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','ZILETH','4h','0.000131550000000','0.000131180000000','0.072144500000000','0.071941585024705','548.4188521474724','548.418852147472421','test'),('2019-03-19 23:59:59','2019-03-21 15:59:59','ZILETH','4h','0.000132210000000','0.000134110000000','0.072144500000000','0.073181294115422','545.6811133802283','545.681113380228339','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','ZILETH','4h','0.000138440000000','0.000137110000000','0.072144500000000','0.071451404182317','521.1246749494366','521.124674949436553','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ZILETH','4h','0.000139560000000','0.000138220000000','0.072144500000000','0.071451797004872','516.9425336772714','516.942533677271399','test'),('2019-03-28 03:59:59','2019-03-28 07:59:59','ZILETH','4h','0.000139120000000','0.000137900000000','0.072144500000000','0.071511835465785','518.5774870615296','518.577487061529609','test'),('2019-03-31 03:59:59','2019-04-01 23:59:59','ZILETH','4h','0.000138020000000','0.000145820000000','0.072144500000000','0.076221641718592','522.7104767425011','522.710476742501100','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','ZILETH','4h','0.000142310000000','0.000139040000000','0.072144500000000','0.070486763263298','506.9531304897758','506.953130489775788','test'),('2019-04-04 03:59:59','2019-04-07 23:59:59','ZILETH','4h','0.000140900000000','0.000141670000000','0.072144500000000','0.072538760220014','512.0262597586941','512.026259758694096','test'),('2019-04-18 03:59:59','2019-04-18 07:59:59','ZILETH','4h','0.000131220000000','0.000128780000000','0.072144500000000','0.070802992760250','549.7980490778845','549.798049077884457','test'),('2019-05-21 15:59:59','2019-05-21 23:59:59','ZILETH','4h','0.000083780000000','0.000082320000000','0.072144500000000','0.070887267128193','861.1184053473382','861.118405347338239','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','ZILETH','4h','0.000080010000000','0.000076760000000','0.072144500000000','0.069213996000500','901.6935383077115','901.693538307711492','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','ZILETH','4h','0.000080010000000','0.000079550000000','0.072144500000000','0.071729720972378','901.6935383077115','901.693538307711492','test'),('2019-06-02 15:59:59','2019-06-03 07:59:59','ZILETH','4h','0.000078710000000','0.000077220000000','0.072144500000000','0.070778786558252','916.5862025155635','916.586202515563514','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','ZILETH','4h','0.000093060000000','0.000090840000000','0.072144500000000','0.070423451321728','775.247152374812','775.247152374812003','test'),('2019-06-16 23:59:59','2019-06-18 11:59:59','ZILETH','4h','0.000093620000000','0.000086980000000','0.072144500000000','0.067027650181585','770.6099124118778','770.609912411877758','test'),('2019-07-30 23:59:59','2019-07-31 15:59:59','ZILETH','4h','0.000051330000000','0.000049900000000','0.072144500000000','0.070134629846094','1405.5036041301385','1405.503604130138456','test'),('2019-08-11 15:59:59','2019-08-11 19:59:59','ZILETH','4h','0.000043510000000','0.000042320000000','0.072144500000000','0.070171345437830','1658.1130774534588','1658.113077453458800','test'),('2019-08-13 07:59:59','2019-08-13 15:59:59','ZILETH','4h','0.000043980000000','0.000042390000000','0.072144500000000','0.069536274556617','1640.3933606184628','1640.393360618462793','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  8:27:38
