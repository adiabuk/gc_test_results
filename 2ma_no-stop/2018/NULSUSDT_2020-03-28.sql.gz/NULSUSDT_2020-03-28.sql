-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-17 07:59:59','2019-01-18 19:59:59','NULSUSDT','4h','0.404200000000000','0.395400000000000','15.000000000000000','14.673428995546757','37.11034141514102','37.110341415141022','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','NULSUSDT','4h','0.405000000000000','0.396600000000000','15.000000000000000','14.688888888888888','37.03703703703704','37.037037037037038','test'),('2019-01-24 11:59:59','2019-01-27 15:59:59','NULSUSDT','4h','0.399600000000000','0.432300000000000','15.000000000000000','16.227477477477478','37.53753753753754','37.537537537537538','test'),('2019-02-08 19:59:59','2019-02-08 23:59:59','NULSUSDT','4h','0.403000000000000','0.397700000000000','15.147448840478281','14.948239215529062','37.58672168853171','37.586721688531711','test'),('2019-02-12 19:59:59','2019-02-14 15:59:59','NULSUSDT','4h','0.404200000000000','0.402100000000000','15.147448840478281','15.068751060752886','37.475133202568735','37.475133202568735','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','NULSUSDT','4h','0.426100000000000','0.423800000000000','15.147448840478281','15.065686032843690','35.549046797649105','35.549046797649105','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','NULSUSDT','4h','0.423500000000000','0.421900000000000','15.147448840478281','15.090221170714964','35.76729360207386','35.767293602073863','test'),('2019-03-05 03:59:59','2019-03-08 23:59:59','NULSUSDT','4h','0.424800000000000','0.429000000000000','15.147448840478281','15.297211752742898','35.65783625347994','35.657836253479942','test'),('2019-04-15 07:59:59','2019-04-15 19:59:59','NULSUSDT','4h','0.887700000000000','0.838800000000000','15.147448840478281','14.313033780999417','17.063702647829537','17.063702647829537','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','NULSUSDT','4h','0.851100000000000','0.882800000000000','15.147448840478281','15.711629463487521','17.79749599398224','17.797495993982238','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','NULSUSDT','4h','0.869400000000000','0.853600000000000','15.147448840478281','14.872167391571500','17.422876513087513','17.422876513087513','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','NULSUSDT','4h','0.863900000000000','0.866700000000000','15.147448840478281','15.196543477303539','17.533798866163075','17.533798866163075','test'),('2019-04-22 11:59:59','2019-04-22 15:59:59','NULSUSDT','4h','0.877400000000000','0.863000000000000','15.147448840478281','14.898846990349620','17.26401737004591','17.264017370045909','test'),('2019-04-23 03:59:59','2019-04-23 07:59:59','NULSUSDT','4h','0.864600000000000','0.907900000000000','15.147448840478281','15.906047654719213','17.519603100252464','17.519603100252464','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','NULSUSDT','4h','0.696400000000000','0.651000000000000','15.147448840478281','14.159950021756693','21.751075302237624','21.751075302237624','test'),('2019-05-14 07:59:59','2019-05-14 11:59:59','NULSUSDT','4h','0.701100000000000','0.676700000000000','15.147448840478281','14.620280459779851','21.605261504034065','21.605261504034065','test'),('2019-05-18 03:59:59','2019-05-18 11:59:59','NULSUSDT','4h','0.713400000000000','0.690900000000000','15.147448840478281','14.669711808083044','21.23275699534382','21.232756995343820','test'),('2019-05-19 03:59:59','2019-05-19 15:59:59','NULSUSDT','4h','0.706400000000000','0.704000000000000','15.147448840478281','15.095985254383791','21.443160872704247','21.443160872704247','test'),('2019-05-21 03:59:59','2019-05-22 23:59:59','NULSUSDT','4h','0.714400000000000','0.712300000000000','15.147448840478281','15.102922465107335','21.203035890927044','21.203035890927044','test'),('2019-05-23 15:59:59','2019-05-29 07:59:59','NULSUSDT','4h','0.723100000000000','0.761000000000000','15.147448840478281','15.941375421938838','20.947930909249457','20.947930909249457','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','NULSUSDT','4h','0.761300000000000','0.772100000000000','15.147448840478281','15.362334493278974','19.896819703767612','19.896819703767612','test'),('2019-06-05 15:59:59','2019-06-05 23:59:59','NULSUSDT','4h','0.770000000000000','0.765500000000000','15.147448840478281','15.058924788813147','19.672011481140625','19.672011481140625','test'),('2019-06-07 07:59:59','2019-06-09 19:59:59','NULSUSDT','4h','0.772200000000000','0.833800000000000','15.147448840478281','16.355792337724413','19.615965864385238','19.615965864385238','test'),('2019-06-22 19:59:59','2019-06-22 23:59:59','NULSUSDT','4h','0.967500000000000','0.968100000000000','15.147448840478281','15.156842607201058','15.65627787129538','15.656277871295380','test'),('2019-06-24 07:59:59','2019-06-24 11:59:59','NULSUSDT','4h','0.975700000000000','0.951900000000000','15.147448840478281','14.777961003639721','15.524699026830257','15.524699026830257','test'),('2019-06-25 03:59:59','2019-06-25 07:59:59','NULSUSDT','4h','0.966900000000000','0.959700000000000','15.147448840478281','15.034653689323619','15.665993215925413','15.665993215925413','test'),('2019-07-01 11:59:59','2019-07-01 15:59:59','NULSUSDT','4h','0.913700000000000','0.848800000000000','15.147448840478281','14.071527389512932','16.578142541838986','16.578142541838986','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','NULSUSDT','4h','0.894900000000000','0.928600000000000','15.147448840478281','15.717869028123959','16.92641506367','16.926415063669999','test'),('2019-07-05 11:59:59','2019-07-08 11:59:59','NULSUSDT','4h','0.914000000000000','0.903400000000000','15.147448840478281','14.971778208411465','16.572701138378864','16.572701138378864','test'),('2019-08-04 15:59:59','2019-08-05 07:59:59','NULSUSDT','4h','0.554000000000000','0.541400000000000','15.147448840478281','14.802940076236355','27.341965416025776','27.341965416025776','test'),('2019-08-17 07:59:59','2019-08-18 23:59:59','NULSUSDT','4h','0.453900000000000','0.448900000000000','15.147448840478281','14.980589963627892','33.37177537007773','33.371775370077728','test'),('2019-08-19 15:59:59','2019-08-19 23:59:59','NULSUSDT','4h','0.451600000000000','0.452300000000000','15.147448840478281','15.170928057015781','33.54173791071364','33.541737910713643','test'),('2019-08-23 07:59:59','2019-08-23 11:59:59','NULSUSDT','4h','0.441700000000000','0.442400000000000','15.147448840478281','15.171454306152576','34.293522391845784','34.293522391845784','test'),('2019-08-24 19:59:59','2019-08-27 03:59:59','NULSUSDT','4h','0.514400000000000','0.456700000000000','15.147448840478281','13.448366806855425','29.44682900559542','29.446829005595418','test'),('2019-09-02 19:59:59','2019-09-02 23:59:59','NULSUSDT','4h','0.468400000000000','0.440600000000000','15.147448840478281','14.248432875992167','32.338703758493345','32.338703758493345','test'),('2019-09-09 07:59:59','2019-09-10 19:59:59','NULSUSDT','4h','0.443600000000000','0.434300000000000','15.147448840478281','14.829885102388904','34.146638504234176','34.146638504234176','test'),('2019-09-17 03:59:59','2019-09-17 07:59:59','NULSUSDT','4h','0.427700000000000','0.421500000000000','15.147448840478281','14.927869268790262','35.41605994968034','35.416059949680339','test'),('2019-09-19 19:59:59','2019-09-19 23:59:59','NULSUSDT','4h','0.435500000000000','0.433500000000000','15.147448840478281','15.077885355562193','34.78174245804428','34.781742458044278','test'),('2019-10-01 03:59:59','2019-10-01 07:59:59','NULSUSDT','4h','0.367800000000000','0.370400000000000','15.147448840478281','15.254527054141260','41.18392833191485','41.183928331914849','test'),('2019-10-02 23:59:59','2019-10-03 03:59:59','NULSUSDT','4h','0.369800000000000','0.376500000000000','15.147448840478281','15.421888827582675','40.961192105133264','40.961192105133264','test'),('2019-10-03 23:59:59','2019-10-04 03:59:59','NULSUSDT','4h','0.369700000000000','0.364100000000000','15.147448840478281','14.918004119064491','40.97227168103404','40.972271681034037','test'),('2019-10-04 11:59:59','2019-10-05 15:59:59','NULSUSDT','4h','0.371700000000000','0.380800000000000','15.147448840478281','15.518290337514474','40.751812861119944','40.751812861119944','test'),('2019-10-07 19:59:59','2019-10-08 07:59:59','NULSUSDT','4h','0.372500000000000','0.370700000000000','15.147448840478281','15.074253114537713','40.664292189203444','40.664292189203444','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','NULSUSDT','4h','0.329100000000000','0.316000000000000','15.147448840478281','14.544496607691087','46.02688799902243','46.026887999022428','test'),('2019-10-26 07:59:59','2019-10-26 11:59:59','NULSUSDT','4h','0.332400000000000','0.322900000000000','15.147448840478281','14.714534388057874','45.569942360042965','45.569942360042965','test'),('2019-10-27 07:59:59','2019-10-27 11:59:59','NULSUSDT','4h','0.327000000000000','0.317300000000000','15.147448840478281','14.698120847350944','46.3224735182822','46.322473518282202','test'),('2019-10-27 15:59:59','2019-11-05 07:59:59','NULSUSDT','4h','0.375800000000000','0.396300000000000','15.147448840478281','15.973746608519273','40.307208197121554','40.307208197121554','test'),('2019-11-10 03:59:59','2019-11-10 15:59:59','NULSUSDT','4h','0.414600000000000','0.399800000000000','15.147448840478281','14.606729489684556','36.53509126984631','36.535091269846312','test'),('2019-11-12 07:59:59','2019-11-12 15:59:59','NULSUSDT','4h','0.421900000000000','0.401700000000000','15.147448840478281','14.422209526475765','35.902936336758195','35.902936336758195','test'),('2019-12-08 19:59:59','2019-12-09 03:59:59','NULSUSDT','4h','0.304100000000000','0.302000000000000','15.147448840478281','15.042846267097799','49.81074922880067','49.810749228800667','test'),('2019-12-27 11:59:59','2019-12-28 15:59:59','NULSUSDT','4h','0.253900000000000','0.252100000000000','15.147448840478281','15.040062436725382','59.65911319605467','59.659113196054669','test'),('2019-12-29 19:59:59','2019-12-29 23:59:59','NULSUSDT','4h','0.251200000000000','0.246300000000000','15.147448840478281','14.851977107523092','60.300353664324376','60.300353664324376','test'),('2020-01-06 11:59:59','2020-01-06 11:59:59','NULSUSDT','4h','0.239200000000000','0.239200000000000','15.147448840478281','15.147448840478281','63.32545501872191','63.325455018721911','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:47:50
