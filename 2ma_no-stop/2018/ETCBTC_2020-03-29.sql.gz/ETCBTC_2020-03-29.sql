-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-11 07:59:59','2018-04-11 11:59:59','ETCBTC','4h','0.002035000000000','0.002015000000000','0.001467500000000','0.001453077395577','0.7211302211302212','0.721130221130221','test'),('2018-04-12 23:59:59','2018-04-13 07:59:59','ETCBTC','4h','0.002038000000000','0.002017000000000','0.001467500000000','0.001452378557409','0.7200686947988224','0.720068694798822','test'),('2018-04-15 23:59:59','2018-04-16 03:59:59','ETCBTC','4h','0.002015000000000','0.001998000000000','0.001467500000000','0.001455119106700','0.728287841191067','0.728287841191067','test'),('2018-04-17 03:59:59','2018-04-17 07:59:59','ETCBTC','4h','0.002017000000000','0.002011000000000','0.001467500000000','0.001463134605850','0.7275656916212196','0.727565691621220','test'),('2018-04-22 07:59:59','2018-04-25 03:59:59','ETCBTC','4h','0.002139000000000','0.002117000000000','0.001467500000000','0.001452406498364','0.6860682561944835','0.686068256194484','test'),('2018-04-26 15:59:59','2018-05-04 07:59:59','ETCBTC','4h','0.002172000000000','0.002279000000000','0.001467500000000','0.001539793968692','0.6756445672191529','0.675644567219153','test'),('2018-05-04 23:59:59','2018-05-05 03:59:59','ETCBTC','4h','0.002304000000000','0.002292000000000','0.001470227533148','0.001462570098080','0.6381195890399305','0.638119589039930','test'),('2018-06-02 11:59:59','2018-06-04 07:59:59','ETCBTC','4h','0.002072000000000','0.002050000000000','0.001470227533148','0.001454617009147','0.7095692727548263','0.709569272754826','test'),('2018-06-12 03:59:59','2018-06-13 11:59:59','ETCBTC','4h','0.002242000000000','0.002091000000000','0.001470227533148','0.001371206856295','0.6557660718768956','0.655766071876896','test'),('2018-06-24 19:59:59','2018-06-27 03:59:59','ETCBTC','4h','0.002409000000000','0.002359000000000','0.001470227533148','0.001439712225279','0.6103061573881279','0.610306157388128','test'),('2018-07-12 23:59:59','2018-07-13 23:59:59','ETCBTC','4h','0.002614000000000','0.002616000000000','0.001470227533148','0.001471352420319','0.5624435857490436','0.562443585749044','test'),('2018-07-14 23:59:59','2018-07-15 03:59:59','ETCBTC','4h','0.002623000000000','0.002618000000000','0.001470227533148','0.001467424964461','0.5605137373800991','0.560513737380099','test'),('2018-07-31 19:59:59','2018-07-31 23:59:59','ETCBTC','4h','0.002155000000000','0.002094000000000','0.001470227533148','0.001428610883718','0.6822401545930395','0.682240154593040','test'),('2018-08-03 23:59:59','2018-08-08 23:59:59','ETCBTC','4h','0.002231000000000','0.002407000000000','0.001470227533148','0.001586211417430','0.6589993425136711','0.658999342513671','test'),('2018-08-10 15:59:59','2018-08-10 19:59:59','ETCBTC','4h','0.002343000000000','0.002347000000000','0.001470227533148','0.001472737524669','0.6274978801314555','0.627497880131455','test'),('2018-08-16 07:59:59','2018-08-16 15:59:59','ETCBTC','4h','0.002189000000000','0.002172000000000','0.001470227533148','0.001458809594334','0.671643459638191','0.671643459638191','test'),('2018-08-17 19:59:59','2018-08-17 23:59:59','ETCBTC','4h','0.002186000000000','0.002197000000000','0.001470227533148','0.001477625750378','0.6725652027209515','0.672565202720952','test'),('2018-09-03 03:59:59','2018-09-04 19:59:59','ETCBTC','4h','0.001923000000000','0.001893000000000','0.001470227533148','0.001447291066172','0.7645488991929278','0.764548899192928','test'),('2018-09-21 23:59:59','2018-09-22 03:59:59','ETCBTC','4h','0.001731000000000','0.001716000000000','0.001470227533148','0.001457487259897','0.8493515500566148','0.849351550056615','test'),('2018-09-23 07:59:59','2018-09-23 15:59:59','ETCBTC','4h','0.001724000000000','0.001721000000000','0.001470227533148','0.001467669132568','0.8528001932412993','0.852800193241299','test'),('2018-09-26 19:59:59','2018-09-26 23:59:59','ETCBTC','4h','0.001708000000000','0.001696000000000','0.001470227533148','0.001459898065702','0.8607889538337237','0.860788953833724','test'),('2018-09-27 03:59:59','2018-09-27 07:59:59','ETCBTC','4h','0.001709000000000','0.001693000000000','0.001470227533148','0.001456462968765','0.8602852739309538','0.860285273930954','test'),('2018-09-27 15:59:59','2018-09-27 23:59:59','ETCBTC','4h','0.001723000000000','0.001711000000000','0.001470227533148','0.001459987991420','0.8532951440208939','0.853295144020894','test'),('2018-09-29 07:59:59','2018-09-30 07:59:59','ETCBTC','4h','0.001710000000000','0.001715000000000','0.001470227533148','0.001474526444064','0.8597821831274854','0.859782183127485','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','ETCBTC','4h','0.001715000000000','0.001707000000000','0.001470227533148','0.001463369328912','0.8572755295323616','0.857275529532362','test'),('2018-10-02 15:59:59','2018-10-02 19:59:59','ETCBTC','4h','0.001715000000000','0.001704000000000','0.001470227533148','0.001460797502323','0.8572755295323616','0.857275529532362','test'),('2018-10-22 11:59:59','2018-10-23 11:59:59','ETCBTC','4h','0.001552000000000','0.001518000000000','0.001470227533148','0.001438018940283','0.9473115548634021','0.947311554863402','test'),('2018-11-04 11:59:59','2018-11-05 03:59:59','ETCBTC','4h','0.001463000000000','0.001455000000000','0.001470227533148','0.001462188011436','1.0049402140451127','1.004940214045113','test'),('2018-11-05 23:59:59','2018-11-07 23:59:59','ETCBTC','4h','0.001468000000000','0.001480000000000','0.001470227533148','0.001482245741866','1.0015173931525887','1.001517393152589','test'),('2018-11-08 19:59:59','2018-11-08 23:59:59','ETCBTC','4h','0.001468000000000','0.001469000000000','0.001470227533148','0.001471229050541','1.0015173931525887','1.001517393152589','test'),('2018-12-02 15:59:59','2018-12-03 15:59:59','ETCBTC','4h','0.001239000000000','0.001213000000000','0.001470227533148','0.001439375300814','1.1866243205391445','1.186624320539144','test'),('2018-12-11 03:59:59','2018-12-11 15:59:59','ETCBTC','4h','0.001140000000000','0.001112000000000','0.001470227533148','0.001434116681457','1.2896732746912283','1.289673274691228','test'),('2018-12-13 15:59:59','2018-12-14 11:59:59','ETCBTC','4h','0.001133000000000','0.001132000000000','0.001470227533148','0.001468929891901','1.2976412472621361','1.297641247262136','test'),('2018-12-16 03:59:59','2018-12-16 23:59:59','ETCBTC','4h','0.001144000000000','0.001118000000000','0.001470227533148','0.001436813271031','1.285163927576923','1.285163927576923','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','ETCBTC','4h','0.001146000000000','0.001127000000000','0.001470227533148','0.001445852033035','1.2829210585933681','1.282921058593368','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','ETCBTC','4h','0.001160000000000','0.001139000000000','0.001470227533148','0.001443611345048','1.2674375285758621','1.267437528575862','test'),('2019-01-25 11:59:59','2019-01-25 19:59:59','ETCBTC','4h','0.001220000000000','0.001208000000000','0.001470227533148','0.001455766278724','1.2051045353672132','1.205104535367213','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','ETCBTC','4h','0.001209000000000','0.001200000000000','0.001470227533148','0.001459282911313','1.2160690927609596','1.216069092760960','test'),('2019-02-08 07:59:59','2019-02-08 19:59:59','ETCBTC','4h','0.001138000000000','0.001135000000000','0.001470227533148','0.001466351713641','1.2919398358066785','1.291939835806678','test'),('2019-02-12 03:59:59','2019-02-12 07:59:59','ETCBTC','4h','0.001130000000000','0.001127000000000','0.001470227533148','0.001466324274210','1.3010863125203542','1.301086312520354','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','ETCBTC','4h','0.001143000000000','0.001120000000000','0.001470227533148','0.001440642902122','1.2862883054663168','1.286288305466317','test'),('2019-02-13 07:59:59','2019-02-13 15:59:59','ETCBTC','4h','0.001129000000000','0.001126000000000','0.001470227533148','0.001466320816939','1.3022387361806909','1.302238736180691','test'),('2019-02-17 15:59:59','2019-02-17 19:59:59','ETCBTC','4h','0.001131000000000','0.001134000000000','0.001470227533148','0.001474127340928','1.299935926744474','1.299935926744474','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','ETCBTC','4h','0.001139000000000','0.001125000000000','0.001470227533148','0.001452156255304','1.2908055602704127','1.290805560270413','test'),('2019-02-19 03:59:59','2019-02-20 03:59:59','ETCBTC','4h','0.001147000000000','0.001150000000000','0.001470227533148','0.001474072940820','1.2818025572345249','1.281802557234525','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','ETCBTC','4h','0.001145000000000','0.001140000000000','0.001470227533148','0.001463807325580','1.2840415136663756','1.284041513666376','test'),('2019-02-22 15:59:59','2019-02-24 15:59:59','ETCBTC','4h','0.001154000000000','0.001133000000000','0.001470227533148','0.001443472959321','1.274027325084922','1.274027325084922','test'),('2019-03-02 15:59:59','2019-03-02 19:59:59','ETCBTC','4h','0.001132000000000','0.001103000000000','0.001470227533148','0.001432562693518','1.298787573452297','1.298787573452297','test'),('2019-03-07 03:59:59','2019-03-07 07:59:59','ETCBTC','4h','0.001143000000000','0.001124000000000','0.001470227533148','0.001445788055344','1.2862883054663168','1.286288305466317','test'),('2019-03-14 19:59:59','2019-03-17 07:59:59','ETCBTC','4h','0.001116000000000','0.001108000000000','0.001470227533148','0.001459688267677','1.3174081838243727','1.317408183824373','test'),('2019-03-18 03:59:59','2019-03-18 07:59:59','ETCBTC','4h','0.001111000000000','0.001101000000000','0.001470227533148','0.001456994162013','1.3233371135445546','1.323337113544555','test'),('2019-03-19 15:59:59','2019-03-25 19:59:59','ETCBTC','4h','0.001135000000000','0.001186000000000','0.001470227533148','0.001536290620541','1.2953546547559474','1.295354654755947','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','ETCBTC','4h','0.001204000000000','0.001202000000000','0.001470227533148','0.001467785294721','1.221119213578073','1.221119213578073','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:27:11
