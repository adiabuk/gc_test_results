-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-21 07:59:59','2018-11-21 11:59:59','CVCETH','4h','0.000591390000000','0.000553130000000','0.072144500000000','0.067477108650806','121.99141006780636','121.991410067806356','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','CVCETH','4h','0.000549320000000','0.000536460000000','0.072144500000000','0.070455542252239','131.33419500473315','131.334195004733147','test'),('2018-11-28 11:59:59','2018-12-03 15:59:59','CVCETH','4h','0.000550020000000','0.000565590000000','0.072144500000000','0.074186770944693','131.1670484709647','131.167048470964687','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','CVCETH','4h','0.000565250000000','0.000569960000000','0.072144500000000','0.072745650986289','127.63290579389651','127.632905793896512','test'),('2019-01-10 11:59:59','2019-01-10 19:59:59','CVCETH','4h','0.000385310000000','0.000384320000000','0.072144500000000','0.071959134826503','187.23754898653033','187.237548986530328','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','CVCETH','4h','0.000398550000000','0.000396040000000','0.072144500000000','0.071690146230084','181.01743821352403','181.017438213524031','test'),('2019-01-31 15:59:59','2019-01-31 23:59:59','CVCETH','4h','0.000454760000000','0.000445800000000','0.072144500000000','0.070723058536371','158.64302049432666','158.643020494326663','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CVCETH','4h','0.000447410000000','0.000439220000000','0.072144500000000','0.070823869135692','161.24918978118507','161.249189781185066','test'),('2019-02-08 03:59:59','2019-02-08 11:59:59','CVCETH','4h','0.000456150000000','0.000443990000000','0.072144500000000','0.070221279305053','158.15959662391757','158.159596623917565','test'),('2019-02-10 07:59:59','2019-02-10 23:59:59','CVCETH','4h','0.000474720000000','0.000427020000000','0.072144500000000','0.064895400214863','151.97274182676105','151.972741826761052','test'),('2019-02-11 03:59:59','2019-02-11 15:59:59','CVCETH','4h','0.000459900000000','0.000438490000000','0.072144500000000','0.068785913905197','156.86997173298542','156.869971732985420','test'),('2019-02-16 15:59:59','2019-02-16 19:59:59','CVCETH','4h','0.000430770000000','0.000432440000000','0.072144500000000','0.072424188267521','167.47800450356337','167.478004503563369','test'),('2019-02-17 03:59:59','2019-02-17 23:59:59','CVCETH','4h','0.000464940000000','0.000431590000000','0.072144500000000','0.066969597700779','155.16948423452487','155.169484234524873','test'),('2019-02-26 11:59:59','2019-03-02 03:59:59','CVCETH','4h','0.000413330000000','0.000448650000000','0.072144500000000','0.078309413604142','174.54455277865145','174.544552778651450','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','CVCETH','4h','0.000440460000000','0.000435980000000','0.072144500000000','0.071410704967534','163.79353403260228','163.793534032602281','test'),('2019-03-08 03:59:59','2019-03-08 07:59:59','CVCETH','4h','0.000437970000000','0.000438360000000','0.072144500000000','0.072208742653606','164.72475283695232','164.724752836952320','test'),('2019-03-08 15:59:59','2019-03-26 15:59:59','CVCETH','4h','0.000440690000000','0.000600180000000','0.072144500000000','0.098254296693821','163.7080487417459','163.708048741745898','test'),('2019-04-23 11:59:59','2019-04-23 15:59:59','CVCETH','4h','0.000498010000000','0.000481960000000','0.073915579718798','0.071533408568647','148.42187851408255','148.421878514082550','test'),('2019-05-08 15:59:59','2019-05-08 19:59:59','CVCETH','4h','0.000443240000000','0.000426470000000','0.073915579718798','0.071118981325412','166.76197933128327','166.761979331283271','test'),('2019-05-23 15:59:59','2019-05-24 11:59:59','CVCETH','4h','0.000339410000000','0.000329460000000','0.073915579718798','0.071748701847781','217.77667045401728','217.776670454017278','test'),('2019-05-25 19:59:59','2019-05-26 19:59:59','CVCETH','4h','0.000334910000000','0.000328720000000','0.073915579718798','0.072549429294925','220.70281484219043','220.702814842190435','test'),('2019-06-02 19:59:59','2019-06-03 07:59:59','CVCETH','4h','0.000337580000000','0.000317880000000','0.073915579718798','0.069602122403613','218.95722412109131','218.957224121091315','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','CVCETH','4h','0.000322650000000','0.000323680000000','0.073915579718798','0.074151541433072','229.08904298403223','229.089042984032233','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','CVCETH','4h','0.000323500000000','0.000319650000000','0.073915579718798','0.073035904349656','228.487108868','228.487108868000007','test'),('2019-06-05 11:59:59','2019-06-05 23:59:59','CVCETH','4h','0.000322990000000','0.000324790000000','0.073915579718798','0.074327505919280','228.84788915693366','228.847889156933661','test'),('2019-06-07 07:59:59','2019-06-12 23:59:59','CVCETH','4h','0.000328250000000','0.000342850000000','0.073915579718798','0.077203218603473','225.18074552566034','225.180745525660342','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','CVCETH','4h','0.000255190000000','0.000240870000000','0.073915579718798','0.069767803153991','289.6492014530272','289.649201453027217','test'),('2019-07-11 11:59:59','2019-07-11 15:59:59','CVCETH','4h','0.000255920000000','0.000231240000000','0.073915579718798','0.066787428314219','288.8229904610738','288.822990461073800','test'),('2019-07-14 23:59:59','2019-07-15 03:59:59','CVCETH','4h','0.000239100000000','0.000230360000000','0.073915579718798','0.071213688599006','309.14086038811377','309.140860388113765','test'),('2019-07-19 19:59:59','2019-07-19 23:59:59','CVCETH','4h','0.000231530000000','0.000231480000000','0.073915579718798','0.073899617299302','319.24838992267956','319.248389922679564','test'),('2019-07-20 11:59:59','2019-07-20 15:59:59','CVCETH','4h','0.000231650000000','0.000226600000000','0.073915579718798','0.072304210508438','319.08301195250596','319.083011952505956','test'),('2019-07-21 03:59:59','2019-07-21 07:59:59','CVCETH','4h','0.000231300000000','0.000228790000000','0.073915579718798','0.073113469450341','319.5658440069088','319.565844006908776','test'),('2019-07-22 03:59:59','2019-07-22 07:59:59','CVCETH','4h','0.000232570000000','0.000233300000000','0.073915579718798','0.074147588891068','317.82078393085095','317.820783930850951','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','CVCETH','4h','0.000235260000000','0.000235360000000','0.073915579718798','0.073946998395887','314.1867708866701','314.186770886670104','test'),('2019-07-27 03:59:59','2019-07-27 07:59:59','CVCETH','4h','0.000234850000000','0.000235810000000','0.073915579718798','0.074217725584372','314.73527663954866','314.735276639548658','test'),('2019-08-01 03:59:59','2019-08-01 11:59:59','CVCETH','4h','0.000245280000000','0.000237250000000','0.073915579718798','0.071495724430385','301.35184164545825','301.351841645458251','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','CVCETH','4h','0.000227090000000','0.000215540000000','0.073915579718798','0.070156167389976','325.4902449196266','325.490244919626605','test'),('2019-08-21 19:59:59','2019-08-22 19:59:59','CVCETH','4h','0.000217040000000','0.000204410000000','0.073915579718798','0.069614281470326','340.5620149225857','340.562014922585718','test'),('2019-08-29 15:59:59','2019-08-29 19:59:59','CVCETH','4h','0.000233640000000','0.000240350000000','0.073915579718798','0.076038390624093','316.3652615938966','316.365261593896605','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','CVCETH','4h','0.000240440000000','0.000241200000000','0.073915579718798','0.074149217385519','307.41798252702546','307.417982527025458','test'),('2019-09-04 07:59:59','2019-09-04 15:59:59','CVCETH','4h','0.000247020000000','0.000238960000000','0.073915579718798','0.071503792930143','299.22913010605623','299.229130106056232','test'),('2019-09-09 03:59:59','2019-09-10 03:59:59','CVCETH','4h','0.000265900000000','0.000239680000000','0.073915579718798','0.066626875317794','277.9826239894622','277.982623989462184','test'),('2019-09-11 07:59:59','2019-09-12 19:59:59','CVCETH','4h','0.000237500000000','0.000239190000000','0.073915579718798','0.074441547422902','311.2234935528337','311.223493552833702','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','CVCETH','4h','0.000223900000000','0.000220030000000','0.073915579718798','0.072637985732591','330.1276450147298','330.127645014729808','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','CVCETH','4h','0.000224510000000','0.000213900000000','0.073915579718798','0.070422442215718','329.23067889536327','329.230678895363269','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','CVCETH','4h','0.000222530000000','0.000208270000000','0.073915579718798','0.069178977162783','332.1600670417382','332.160067041738216','test'),('2019-10-03 03:59:59','2019-10-04 07:59:59','CVCETH','4h','0.000215190000000','0.000212000000000','0.073915579718798','0.072819847113645','343.48984487568197','343.489844875681968','test'),('2019-10-12 19:59:59','2019-10-13 03:59:59','CVCETH','4h','0.000225330000000','0.000220560000000','0.073915579718798','0.072350864344642','328.0325731984112','328.032573198411228','test'),('2019-10-13 07:59:59','2019-10-13 11:59:59','CVCETH','4h','0.000222980000000','0.000222910000000','0.073915579718798','0.073892375437785','331.48972875952103','331.489728759521029','test'),('2019-10-15 07:59:59','2019-10-15 11:59:59','CVCETH','4h','0.000224330000000','0.000224330000000','0.073915579718798','0.073915579718798','329.49485008156734','329.494850081567336','test'),('2019-10-19 07:59:59','2019-10-19 11:59:59','CVCETH','4h','0.000223820000000','0.000221840000000','0.073915579718798','0.073261693346520','330.2456425645519','330.245642564551872','test'),('2019-10-21 15:59:59','2019-10-25 15:59:59','CVCETH','4h','0.000223990000000','0.000218670000000','0.073915579718798','0.072160006326664','329.99499852135364','329.994998521353637','test'),('2019-10-27 07:59:59','2019-10-27 11:59:59','CVCETH','4h','0.000225960000000','0.000228100000000','0.073915579718798','0.074615612205071','327.1179842396796','327.117984239679572','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','CVCETH','4h','0.000230780000000','0.000227480000000','0.073915579718798','0.072858636252848','320.2858987728486','320.285898772848611','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','CVCETH','4h','0.000228530000000','0.000226840000000','0.073915579718798','0.073368967327756','323.43928464008224','323.439284640082235','test'),('2019-10-31 15:59:59','2019-11-02 15:59:59','CVCETH','4h','0.000233020000000','0.000231360000000','0.073915579718798','0.073389016066179','317.2070196498069','317.207019649806909','test'),('2019-11-04 23:59:59','2019-11-05 19:59:59','CVCETH','4h','0.000235060000000','0.000234520000000','0.073915579718798','0.073745774507158','314.4540956300434','314.454095630043412','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:10:15
