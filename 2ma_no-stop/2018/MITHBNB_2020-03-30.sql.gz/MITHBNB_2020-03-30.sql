-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-19 15:59:59','2019-05-19 19:59:59','MITHBNB','4h','0.001720000000000','0.001640000000000','0.711908500000000','0.678796476744186','413.90029069767445','413.900290697674450','test'),('2019-05-20 19:59:59','2019-05-20 23:59:59','MITHBNB','4h','0.001680000000000','0.001840000000000','0.711908500000000','0.779709309523809','423.75505952380956','423.755059523809564','test'),('2019-05-26 15:59:59','2019-05-26 23:59:59','MITHBNB','4h','0.001730000000000','0.001740000000000','0.720580696566999','0.724745902905537','416.5206338537565','416.520633853756522','test'),('2019-05-27 15:59:59','2019-05-27 19:59:59','MITHBNB','4h','0.001670000000000','0.001620000000000','0.721621998151633','0.700016549105177','432.10898092912174','432.108980929121742','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','MITHBNB','4h','0.001600000000000','0.001530000000000','0.721621998151633','0.690051035732499','451.0137488447706','451.013748844770589','test'),('2019-06-10 11:59:59','2019-06-18 03:59:59','MITHBNB','4h','0.001830000000000','0.001770000000000','0.721621998151633','0.697962260507317','394.32896073859723','394.328960738597232','test'),('2019-07-03 19:59:59','2019-07-04 03:59:59','MITHBNB','4h','0.001360000000000','0.001340000000000','0.721621998151633','0.711009909943521','530.6044104056124','530.604410405612384','test'),('2019-07-08 03:59:59','2019-07-08 07:59:59','MITHBNB','4h','0.001270000000000','0.001250000000000','0.721621998151633','0.710257872196489','568.2062977571912','568.206297757191237','test'),('2019-07-25 23:59:59','2019-07-26 07:59:59','MITHBNB','4h','0.000966000000000','0.000955000000000','0.721621998151633','0.713404770429410','747.020702020324','747.020702020324052','test'),('2019-07-27 07:59:59','2019-07-27 11:59:59','MITHBNB','4h','0.000949000000000','0.000928000000000','0.721621998151633','0.705653545083999','760.4025270301718','760.402527030171768','test'),('2019-07-28 07:59:59','2019-07-28 15:59:59','MITHBNB','4h','0.000960000000000','0.000935000000000','0.721621998151633','0.702829758616434','751.689581407951','751.689581407950982','test'),('2019-07-30 03:59:59','2019-07-30 11:59:59','MITHBNB','4h','0.000951000000000','0.000936000000000','0.721621998151633','0.710239947707601','758.803362935471','758.803362935471000','test'),('2019-07-30 19:59:59','2019-07-30 23:59:59','MITHBNB','4h','0.000950000000000','0.000936000000000','0.721621998151633','0.710987568705188','759.6021033175084','759.602103317508409','test'),('2019-08-17 15:59:59','2019-08-17 19:59:59','MITHBNB','4h','0.000723000000000','0.000697000000000','0.721621998151633','0.695671552851574','998.0940500022585','998.094050002258541','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','MITHBNB','4h','0.000709000000000','0.000718000000000','0.721621998151633','0.730782220977253','1017.8025361800183','1017.802536180018251','test'),('2019-08-21 07:59:59','2019-08-21 11:59:59','MITHBNB','4h','0.000705000000000','0.000705000000000','0.721621998151633','0.721621998151633','1023.5773023427417','1023.577302342741746','test'),('2019-08-22 15:59:59','2019-08-28 19:59:59','MITHBNB','4h','0.000704000000000','0.000778000000000','0.721621998151633','0.797474310457345','1025.0312473744787','1025.031247374478653','test'),('2019-08-29 03:59:59','2019-08-29 07:59:59','MITHBNB','4h','0.000802000000000','0.000814000000000','0.721621998151633','0.732419334782331','899.7780525581459','899.778052558145873','test'),('2019-09-02 07:59:59','2019-09-02 11:59:59','MITHBNB','4h','0.000816000000000','0.000801000000000','0.721621998151633','0.708356887891493','884.3406840093542','884.340684009354163','test'),('2019-09-03 19:59:59','2019-09-04 19:59:59','MITHBNB','4h','0.000839000000000','0.000805000000000','0.721621998151633','0.692378675222961','860.0977331962252','860.097733196225249','test'),('2019-09-10 15:59:59','2019-09-10 19:59:59','MITHBNB','4h','0.000787000000000','0.000772000000000','0.721621998151633','0.707868084590928','916.9275707136378','916.927570713637806','test'),('2019-09-10 23:59:59','2019-09-11 11:59:59','MITHBNB','4h','0.000785000000000','0.000780000000000','0.721621998151633','0.717025679692068','919.2636919129083','919.263691912908257','test'),('2019-09-12 07:59:59','2019-09-12 11:59:59','MITHBNB','4h','0.000793000000000','0.000774000000000','0.721621998151633','0.704332189873094','909.9899093967629','909.989909396762869','test'),('2019-09-15 23:59:59','2019-09-16 03:59:59','MITHBNB','4h','0.000780000000000','0.000754000000000','0.721621998151633','0.697567931546579','925.156407886709','925.156407886708962','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','MITHBNB','4h','0.000801000000000','0.000739000000000','0.721621998151633','0.665766113151132','900.9013709758215','900.901370975821465','test'),('2019-09-26 19:59:59','2019-09-26 23:59:59','MITHBNB','4h','0.000759000000000','0.000756000000000','0.721621998151633','0.718769737289374','950.7536207531396','950.753620753139558','test'),('2019-09-27 07:59:59','2019-10-01 19:59:59','MITHBNB','4h','0.000821000000000','0.000792000000000','0.721621998151633','0.696132305159675','878.9549307571656','878.954930757165585','test'),('2019-10-02 03:59:59','2019-10-08 03:59:59','MITHBNB','4h','0.000795000000000','0.000844000000000','0.721621998151633','0.766099328855319','907.7006266058276','907.700626605827551','test'),('2019-10-11 23:59:59','2019-10-12 03:59:59','MITHBNB','4h','0.000823000000000','0.000815000000000','0.721621998151633','0.714607446529260','876.818952796638','876.818952796637973','test'),('2019-10-24 11:59:59','2019-10-24 19:59:59','MITHBNB','4h','0.000717000000000','0.000710000000000','0.721621998151633','0.714576874041366','1006.4463014667127','1006.446301466712725','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','MITHBNB','4h','0.000687000000000','0.000687000000000','0.721621998151633','0.721621998151633','1050.3959216180974','1050.395921618097418','test'),('2019-11-16 23:59:59','2019-11-17 03:59:59','MITHBNB','4h','0.000605000000000','0.000602000000000','0.721621998151633','0.718043707251708','1192.7636333084843','1192.763633308484259','test'),('2019-11-18 03:59:59','2019-11-18 07:59:59','MITHBNB','4h','0.000603000000000','0.000606000000000','0.721621998151633','0.725212157346417','1196.7197315947478','1196.719731594747827','test'),('2019-11-19 19:59:59','2019-11-20 11:59:59','MITHBNB','4h','0.000602000000000','0.000593000000000','0.721621998151633','0.710833629408502','1198.707638125636','1198.707638125636095','test'),('2019-11-20 15:59:59','2019-11-20 19:59:59','MITHBNB','4h','0.000602000000000','0.000606000000000','0.721621998151633','0.726416828704136','1198.707638125636','1198.707638125636095','test'),('2019-11-23 07:59:59','2019-11-23 11:59:59','MITHBNB','4h','0.000605000000000','0.000605000000000','0.721621998151633','0.721621998151633','1192.7636333084843','1192.763633308484259','test'),('2019-11-25 15:59:59','2019-11-27 19:59:59','MITHBNB','4h','0.000634000000000','0.000606000000000','0.721621998151633','0.689752256908343','1138.2050444032066','1138.205044403206557','test'),('2019-11-28 11:59:59','2019-11-29 15:59:59','MITHBNB','4h','0.000608000000000','0.000601000000000','0.721621998151633','0.713313850146598','1186.8782864336067','1186.878286433606718','test'),('2019-11-29 19:59:59','2019-11-29 23:59:59','MITHBNB','4h','0.000606000000000','0.000608000000000','0.721621998151633','0.724003588904609','1190.7953764878432','1190.795376487843214','test'),('2019-12-03 15:59:59','2019-12-03 19:59:59','MITHBNB','4h','0.000605000000000','0.000600000000000','0.721621998151633','0.715658179985091','1192.7636333084843','1192.763633308484259','test'),('2019-12-07 07:59:59','2019-12-10 03:59:59','MITHBNB','4h','0.000600000000000','0.000588000000000','0.721621998151633','0.707189558188600','1202.7033302527218','1202.703330252721798','test'),('2019-12-10 15:59:59','2019-12-10 19:59:59','MITHBNB','4h','0.000613000000000','0.000626000000000','0.721621998151633','0.736925564180950','1177.1973868705268','1177.197386870526771','test'),('2019-12-18 07:59:59','2019-12-18 11:59:59','MITHBNB','4h','0.000635000000000','0.000629000000000','0.721621998151633','0.714803522578547','1136.4125955143825','1136.412595514382474','test'),('2019-12-18 15:59:59','2019-12-20 15:59:59','MITHBNB','4h','0.000647000000000','0.000646000000000','0.721621998151633','0.720506662760363','1115.335391269912','1115.335391269911952','test'),('2019-12-21 07:59:59','2019-12-21 15:59:59','MITHBNB','4h','0.000641000000000','0.000636000000000','0.721621998151633','0.715993121410981','1125.7753481304728','1125.775348130472821','test'),('2019-12-21 23:59:59','2019-12-22 07:59:59','MITHBNB','4h','0.000648000000000','0.000640000000000','0.721621998151633','0.712713084594205','1113.614194678446','1113.614194678445983','test'),('2019-12-22 15:59:59','2019-12-23 03:59:59','MITHBNB','4h','0.000667000000000','0.000641000000000','0.721621998151633','0.693492804820385','1081.8920512018485','1081.892051201848517','test'),('2020-01-22 11:59:59','2020-01-23 07:59:59','MITHBNB','4h','0.000447000000000','0.000423000000000','0.721621998151633','0.682877192881747','1614.366886245264','1614.366886245263913','test'),('2020-01-23 19:59:59','2020-01-24 15:59:59','MITHBNB','4h','0.000434000000000','0.000420000000000','0.721621998151633','0.698343869179000','1662.7234980452374','1662.723498045237420','test'),('2020-01-25 11:59:59','2020-01-25 15:59:59','MITHBNB','4h','0.000427000000000','0.000435000000000','0.721621998151633','0.735141848234099','1689.981260308274','1689.981260308273932','test'),('2020-01-31 23:59:59','2020-02-01 03:59:59','MITHBNB','4h','0.000441000000000','0.000415000000000','0.721621998151633','0.679077390550856','1636.3310615683288','1636.331061568328778','test'),('2020-02-01 19:59:59','2020-02-02 19:59:59','MITHBNB','4h','0.000429000000000','0.000429000000000','0.721621998151633','0.721621998151633','1682.102559794016','1682.102559794016088','test'),('2020-02-03 07:59:59','2020-02-03 19:59:59','MITHBNB','4h','0.000430000000000','0.000429000000000','0.721621998151633','0.719943807458257','1678.1906933758908','1678.190693375890760','test'),('2020-02-05 23:59:59','2020-02-06 03:59:59','MITHBNB','4h','0.000437000000000','0.000436000000000','0.721621998151633','0.719970689231378','1651.3089202554531','1651.308920255453131','test'),('2020-02-08 03:59:59','2020-02-08 07:59:59','MITHBNB','4h','0.000443000000000','0.000433000000000','0.721621998151633','0.705332562527443','1628.9435624190362','1628.943562419036198','test'),('2020-02-08 11:59:59','2020-02-08 15:59:59','MITHBNB','4h','0.000441000000000','0.000452000000000','0.721621998151633','0.739621639828885','1636.3310615683288','1636.331061568328778','test'),('2020-02-13 11:59:59','2020-02-15 19:59:59','MITHBNB','4h','0.000422000000000','0.000422000000000','0.721621998151633','0.721621998151633','1710.004734956476','1710.004734956476113','test'),('2020-02-16 11:59:59','2020-02-16 15:59:59','MITHBNB','4h','0.000431000000000','0.000407000000000','0.721621998151633','0.681438870644349','1674.296979470146','1674.296979470145970','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  5:53:16
