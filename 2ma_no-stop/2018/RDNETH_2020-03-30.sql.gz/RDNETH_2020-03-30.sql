-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-26 23:59:59','2018-04-27 07:59:59','RDNETH','4h','0.003249300000000','0.003242100000000','0.072144500000000','0.071984637752747','22.203089896285352','22.203089896285352','test'),('2018-04-28 07:59:59','2018-04-30 03:59:59','RDNETH','4h','0.003329600000000','0.003297400000000','0.072144500000000','0.071446802709034','21.667617731859686','21.667617731859686','test'),('2018-04-30 19:59:59','2018-05-01 03:59:59','RDNETH','4h','0.003438800000000','0.003282900000000','0.072144500000000','0.068873787091427','20.97955682214726','20.979556822147259','test'),('2018-05-02 23:59:59','2018-05-03 03:59:59','RDNETH','4h','0.003276500000000','0.003311000000000','0.072144500000000','0.072904147566000','22.018770028994354','22.018770028994354','test'),('2018-05-27 19:59:59','2018-05-27 23:59:59','RDNETH','4h','0.002410100000000','0.002365800000000','0.072144500000000','0.070818413385337','29.934235093979503','29.934235093979503','test'),('2018-05-28 15:59:59','2018-05-28 23:59:59','RDNETH','4h','0.002405600000000','0.002400800000000','0.072144500000000','0.072000546890589','29.990231127369473','29.990231127369473','test'),('2018-06-01 15:59:59','2018-06-03 15:59:59','RDNETH','4h','0.002414300000000','0.002319700000000','0.072144500000000','0.069317647620428','29.88216046058899','29.882160460588992','test'),('2018-06-14 19:59:59','2018-06-14 23:59:59','RDNETH','4h','0.002096800000000','0.001938000000000','0.072144500000000','0.066680675791683','34.406953452880586','34.406953452880586','test'),('2018-06-24 19:59:59','2018-06-24 23:59:59','RDNETH','4h','0.001767200000000','0.001725700000000','0.072144500000000','0.070450296316206','40.82418515165233','40.824185151652330','test'),('2018-06-30 07:59:59','2018-07-03 23:59:59','RDNETH','4h','0.001765100000000','0.001815100000000','0.072144500000000','0.074188137754235','40.87275508469775','40.872755084697751','test'),('2018-07-04 15:59:59','2018-07-04 23:59:59','RDNETH','4h','0.001845000000000','0.001809900000000','0.072144500000000','0.070771994878049','39.10271002710027','39.102710027100272','test'),('2018-07-09 15:59:59','2018-07-09 23:59:59','RDNETH','4h','0.001807300000000','0.001746800000000','0.072144500000000','0.069729437614121','39.918386543462624','39.918386543462624','test'),('2018-07-10 03:59:59','2018-07-10 07:59:59','RDNETH','4h','0.001769500000000','0.001718000000000','0.072144500000000','0.070044787228031','40.771121785815204','40.771121785815204','test'),('2018-07-17 19:59:59','2018-07-24 07:59:59','RDNETH','4h','0.001763800000000','0.001879500000000','0.072144500000000','0.076876963232793','40.90288014514117','40.902880145141168','test'),('2018-07-30 11:59:59','2018-07-30 15:59:59','RDNETH','4h','0.001870400000000','0.001846200000000','0.072144500000000','0.071211064959367','38.57169589392643','38.571695893926432','test'),('2018-08-17 19:59:59','2018-08-17 23:59:59','RDNETH','4h','0.001342000000000','0.001318100000000','0.072144500000000','0.070859661289121','53.758941877794335','53.758941877794335','test'),('2018-08-25 15:59:59','2018-09-11 11:59:59','RDNETH','4h','0.001244000000000','0.002239200000000','0.072144500000000','0.129860100000000','57.99397106109324','57.993971061093241','test'),('2018-09-12 07:59:59','2018-09-12 11:59:59','RDNETH','4h','0.002135600000000','0.002050000000000','0.082535150519792','0.079226942576125','38.647289061524624','38.647289061524624','test'),('2018-09-13 03:59:59','2018-09-13 07:59:59','RDNETH','4h','0.002170600000000','0.002600000000000','0.082535150519792','0.098862706786814','38.024117994928595','38.024117994928595','test'),('2018-09-14 23:59:59','2018-09-15 03:59:59','RDNETH','4h','0.002195000000000','0.002193100000000','0.085789987600631','0.085715727474690','39.084276811221294','39.084276811221294','test'),('2018-09-18 07:59:59','2018-09-18 11:59:59','RDNETH','4h','0.002155700000000','0.002108300000000','0.085789987600631','0.083903618712442','39.79681198711834','39.796811987118339','test'),('2018-09-20 15:59:59','2018-09-21 07:59:59','RDNETH','4h','0.002141700000000','0.002135000000000','0.085789987600631','0.085521605979991','40.05695830444554','40.056958304445537','test'),('2018-09-25 07:59:59','2018-09-25 11:59:59','RDNETH','4h','0.002128600000000','0.002105900000000','0.085789987600631','0.084875098603856','40.30348003412149','40.303480034121492','test'),('2018-09-27 07:59:59','2018-09-27 11:59:59','RDNETH','4h','0.002110000000000','0.002031000000000','0.085789987600631','0.082577945410844','40.65876189603365','40.658761896033653','test'),('2018-09-30 23:59:59','2018-10-01 23:59:59','RDNETH','4h','0.002067200000000','0.002044800000000','0.085789987600631','0.084860374731894','41.50057449720927','41.500574497209271','test'),('2018-10-13 11:59:59','2018-10-15 07:59:59','RDNETH','4h','0.002659700000000','0.002487300000000','0.085789987600631','0.080229137180528','32.25551287762943','32.255512877629428','test'),('2018-10-26 19:59:59','2018-10-26 23:59:59','RDNETH','4h','0.002851100000000','0.002837900000000','0.085789987600631','0.085392797801491','30.090136298492162','30.090136298492162','test'),('2018-10-28 07:59:59','2018-10-29 03:59:59','RDNETH','4h','0.002945000000000','0.002860200000000','0.085789987600631','0.083319702049346','29.130725840621732','29.130725840621732','test'),('2018-10-31 03:59:59','2018-10-31 07:59:59','RDNETH','4h','0.002902700000000','0.002829000000000','0.085789987600631','0.083611766604260','29.55523739987977','29.555237399879768','test'),('2018-11-01 15:59:59','2018-11-02 03:59:59','RDNETH','4h','0.002856700000000','0.002828900000000','0.085789987600631','0.084955121617049','30.031150488546572','30.031150488546572','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','RDNETH','4h','0.002166400000000','0.002057100000000','0.085789987600631','0.081461679972885','39.600252769862905','39.600252769862905','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','RDNETH','4h','0.002216400000000','0.002089300000000','0.085789987600631','0.080870339782529','38.70690651535418','38.706906515354177','test'),('2018-12-11 03:59:59','2018-12-11 11:59:59','RDNETH','4h','0.002286600000000','0.002062600000000','0.085789987600631','0.077385825428611','37.51858112509009','37.518581125090087','test'),('2018-12-21 23:59:59','2018-12-24 03:59:59','RDNETH','4h','0.001982000000000','0.002025800000000','0.085789987600631','0.087685851100584','43.284554793456614','43.284554793456614','test'),('2018-12-30 11:59:59','2018-12-30 15:59:59','RDNETH','4h','0.002039400000000','0.001909200000000','0.085789987600631','0.080312956912388','42.06628792813132','42.066287928131317','test'),('2019-01-03 03:59:59','2019-01-03 07:59:59','RDNETH','4h','0.001897600000000','0.001821700000000','0.085789987600631','0.082358568935534','45.20973208296322','45.209732082963221','test'),('2019-01-03 11:59:59','2019-01-03 15:59:59','RDNETH','4h','0.001845000000000','0.001841800000000','0.085789987600631','0.085641191958180','46.49863826592466','46.498638265924662','test'),('2019-01-11 15:59:59','2019-01-12 03:59:59','RDNETH','4h','0.001777400000000','0.001770000000000','0.085789987600631','0.085432810877190','48.26712478937268','48.267124789372680','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','RDNETH','4h','0.001765300000000','0.001729700000000','0.085789987600631','0.084059900046911','48.597964992143545','48.597964992143545','test'),('2019-01-15 23:59:59','2019-01-16 11:59:59','RDNETH','4h','0.001765600000000','0.001784100000000','0.085789987600631','0.086688897189786','48.58970752187982','48.589707521879816','test'),('2019-01-27 19:59:59','2019-01-28 03:59:59','RDNETH','4h','0.001957000000000','0.001875800000000','0.085789987600631','0.082230382596456','43.83750005142105','43.837500051421053','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','RDNETH','4h','0.001955900000000','0.001943000000000','0.085789987600631','0.085224165810126','43.86215430268981','43.862154302689810','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','RDNETH','4h','0.001967500000000','0.001907100000000','0.085789987600631','0.083156333089283','43.60355151239187','43.603551512391867','test'),('2019-02-03 07:59:59','2019-02-03 11:59:59','RDNETH','4h','0.001940800000000','0.001975000000000','0.085789987600631','0.087301744389554','44.203414880786795','44.203414880786795','test'),('2019-02-07 15:59:59','2019-02-08 07:59:59','RDNETH','4h','0.001977100000000','0.002060300000000','0.085789987600631','0.089400187877993','43.391830256755355','43.391830256755355','test'),('2019-02-16 19:59:59','2019-02-17 23:59:59','RDNETH','4h','0.002054900000000','0.001846400000000','0.085789987600631','0.077085324398173','41.74898418445228','41.748984184452283','test'),('2019-02-23 03:59:59','2019-02-23 19:59:59','RDNETH','4h','0.001826500000000','0.001813300000000','0.085789987600631','0.085169988785231','46.96960722728223','46.969607227282232','test'),('2019-02-24 19:59:59','2019-02-25 07:59:59','RDNETH','4h','0.001843700000000','0.001826600000000','0.085789987600631','0.084994300239362','46.531424635586596','46.531424635586596','test'),('2019-04-24 03:59:59','2019-04-24 07:59:59','RDNETH','4h','0.001990000000000','0.001919300000000','0.085789987600631','0.082742071960749','43.1105465329804','43.110546532980401','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 14:09:56
