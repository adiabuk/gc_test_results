-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-21 15:59:59','2018-04-21 23:59:59','ENJBTC','4h','0.000014970000000','0.000014800000000','0.001467500000000','0.001450835003340','98.02939211756846','98.029392117568463','test'),('2018-04-22 03:59:59','2018-04-25 03:59:59','ENJBTC','4h','0.000015270000000','0.000015200000000','0.001467500000000','0.001460772757040','96.10347085789128','96.103470857891281','test'),('2018-04-26 15:59:59','2018-05-05 15:59:59','ENJBTC','4h','0.000015850000000','0.000016850000000','0.001467500000000','0.001560086750789','92.58675078864354','92.586750788643542','test'),('2018-05-07 23:59:59','2018-05-08 07:59:59','ENJBTC','4h','0.000016750000000','0.000016930000000','0.001484798627792','0.001500754672747','88.64469419655224','88.644694196552237','test'),('2018-05-10 07:59:59','2018-05-10 15:59:59','ENJBTC','4h','0.000016770000000','0.000016870000000','0.001488787639031','0.001497665323223','88.77684192194396','88.776841921943955','test'),('2018-05-13 07:59:59','2018-05-13 11:59:59','ENJBTC','4h','0.000016560000000','0.000016580000000','0.001491007060079','0.001492807793243','90.03665821733092','90.036658217330924','test'),('2018-05-14 15:59:59','2018-05-14 19:59:59','ENJBTC','4h','0.000016910000000','0.000016550000000','0.001491457243370','0.001459705344635','88.1997187090479','88.199718709047900','test'),('2018-05-15 03:59:59','2018-05-15 07:59:59','ENJBTC','4h','0.000016590000000','0.000016660000000','0.001491457243370','0.001497750311907','89.90097910608802','89.900979106088016','test'),('2018-05-15 23:59:59','2018-05-16 03:59:59','ENJBTC','4h','0.000016720000000','0.000016040000000','0.001491457243370','0.001430799891367','89.20198823983254','89.201988239832545','test'),('2018-05-16 23:59:59','2018-05-17 03:59:59','ENJBTC','4h','0.000016770000000','0.000016540000000','0.001491457243370','0.001471001956192','88.93603120870603','88.936031208706027','test'),('2018-05-19 03:59:59','2018-05-19 11:59:59','ENJBTC','4h','0.000016620000000','0.000016300000000','0.001491457243370','0.001462740858419','89.73870297051745','89.738702970517451','test'),('2018-05-19 15:59:59','2018-05-21 03:59:59','ENJBTC','4h','0.000017080000000','0.000016580000000','0.001491457243370','0.001447796317042','87.32185265632319','87.321852656323188','test'),('2018-06-07 15:59:59','2018-06-07 19:59:59','ENJBTC','4h','0.000014400000000','0.000014080000000','0.001491457243370','0.001458313749073','103.57341967847222','103.573419678472220','test'),('2018-06-09 03:59:59','2018-06-09 11:59:59','ENJBTC','4h','0.000014400000000','0.000014000000000','0.001491457243370','0.001450027875499','103.57341967847222','103.573419678472220','test'),('2018-06-09 19:59:59','2018-06-09 23:59:59','ENJBTC','4h','0.000014140000000','0.000013770000000','0.001491457243370','0.001452430427242','105.47788142644978','105.477881426449784','test'),('2018-07-02 15:59:59','2018-07-03 03:59:59','ENJBTC','4h','0.000009520000000','0.000009530000000','0.001491457243370','0.001493023900138','156.66567682457983','156.665676824579833','test'),('2018-07-04 00:22:26','2018-07-04 11:59:59','ENJBTC','4h','0.000009380000000','0.000009490000000','0.001491457243370','0.001508947680126','159.0039705085288','159.003970508528795','test'),('2018-07-07 11:59:59','2018-07-07 15:59:59','ENJBTC','4h','0.000009800000000','0.000009340000000','0.001491457243370','0.001421450066640','152.18951462959186','152.189514629591855','test'),('2018-07-07 23:59:59','2018-07-08 03:59:59','ENJBTC','4h','0.000009700000000','0.000009880000000','0.001491457243370','0.001519133769536','153.75847869793813','153.758478697938131','test'),('2018-07-09 11:59:59','2018-07-09 15:59:59','ENJBTC','4h','0.000009630000000','0.000009870000000','0.001491457243370','0.001528627517348','154.87614157528557','154.876141575285573','test'),('2018-08-07 11:59:59','2018-08-07 19:59:59','ENJBTC','4h','0.000007310000000','0.000007070000000','0.001491457243370','0.001442490110893','204.02971865526675','204.029718655266748','test'),('2018-08-07 23:59:59','2018-08-08 03:59:59','ENJBTC','4h','0.000007190000000','0.000007210000000','0.001491457243370','0.001495605942239','207.4349434450626','207.434943445062601','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','ENJBTC','4h','0.000006520000000','0.000006450000000','0.001491457243370','0.001475444665604','228.75111094631902','228.751110946319017','test'),('2018-08-27 23:59:59','2018-08-28 03:59:59','ENJBTC','4h','0.000005870000000','0.000005810000000','0.001491457243370','0.001476212365244','254.0813021073254','254.081302107325399','test'),('2018-09-15 03:59:59','2018-09-15 23:59:59','ENJBTC','4h','0.000006500000000','0.000006500000000','0.001491457243370','0.001491457243370','229.45496051846155','229.454960518461547','test'),('2018-09-18 15:59:59','2018-09-18 19:59:59','ENJBTC','4h','0.000006420000000','0.000006350000000','0.001491457243370','0.001475195248505','232.31421236292834','232.314212362928345','test'),('2018-09-20 07:59:59','2018-09-20 11:59:59','ENJBTC','4h','0.000006390000000','0.000006490000000','0.001491457243370','0.001514797732312','233.40488941627544','233.404889416275438','test'),('2018-09-21 19:59:59','2018-09-21 23:59:59','ENJBTC','4h','0.000006520000000','0.000006450000000','0.001491457243370','0.001475444665604','228.75111094631902','228.751110946319017','test'),('2018-09-22 15:59:59','2018-09-22 19:59:59','ENJBTC','4h','0.000006410000000','0.000006630000000','0.001491457243370','0.001542646103517','232.67663703120127','232.676637031201267','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','ENJBTC','4h','0.000006450000000','0.000006290000000','0.001491457243370','0.001454459854387','231.23368114263565','231.233681142635646','test'),('2018-09-27 07:59:59','2018-09-27 11:59:59','ENJBTC','4h','0.000006460000000','0.000006530000000','0.001491457243370','0.001507618544769','230.87573426780185','230.875734267801846','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','ENJBTC','4h','0.000008220000000','0.000008180000000','0.001491457243370','0.001484199543889','181.44248702798055','181.442487027980548','test'),('2018-10-08 15:59:59','2018-10-08 19:59:59','ENJBTC','4h','0.000008220000000','0.000008160000000','0.001491457243370','0.001480570694148','181.44248702798055','181.442487027980548','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','ENJBTC','4h','0.000008310000000','0.000008080000000','0.001491457243370','0.001450177440004','179.4774059410349','179.477405941034903','test'),('2018-10-14 15:59:59','2018-10-14 19:59:59','ENJBTC','4h','0.000008030000000','0.000007970000000','0.001491457243370','0.001480313104565','185.7356467459527','185.735646745952693','test'),('2018-10-20 15:59:59','2018-10-21 23:59:59','ENJBTC','4h','0.000008040000000','0.000007670000000','0.001491457243370','0.001422820529434','185.50463225995026','185.504632259950256','test'),('2018-10-27 07:59:59','2018-10-27 11:59:59','ENJBTC','4h','0.000007870000000','0.000007870000000','0.001491457243370','0.001491457243370','189.5117208856417','189.511720885641694','test'),('2018-10-31 19:59:59','2018-11-02 23:59:59','ENJBTC','4h','0.000007730000000','0.000007810000000','0.001491457243370','0.001506892764647','192.9440159598965','192.944015959896490','test'),('2018-11-08 19:59:59','2018-11-09 11:59:59','ENJBTC','4h','0.000007710000000','0.000007800000000','0.001491457243370','0.001508867250102','193.44451924383915','193.444519243839153','test'),('2018-11-28 11:59:59','2018-11-28 19:59:59','ENJBTC','4h','0.000006960000000','0.000006380000000','0.001491457243370','0.001367169139756','214.28983381752872','214.289833817528717','test'),('2018-11-29 11:59:59','2018-11-29 15:59:59','ENJBTC','4h','0.000006480000000','0.000006220000000','0.001491457243370','0.001431614823111','230.1631548410494','230.163154841049391','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','ENJBTC','4h','0.000006460000000','0.000006400000000','0.001491457243370','0.001477604699314','230.87573426780185','230.875734267801846','test'),('2018-12-07 03:59:59','2018-12-30 23:59:59','ENJBTC','4h','0.000006810000000','0.000010470000000','0.001491457243370','0.002293033382979','219.00987420998533','219.009874209985327','test'),('2019-01-01 23:59:59','2019-01-02 07:59:59','ENJBTC','4h','0.000010550000000','0.000010490000000','0.001532438431429','0.001523723141772','145.25482762362557','145.254827623625573','test'),('2019-01-12 07:59:59','2019-01-12 23:59:59','ENJBTC','4h','0.000010340000000','0.000009890000000','0.001532438431429','0.001465746236638','148.20487731421665','148.204877314216645','test'),('2019-01-21 23:59:59','2019-01-22 03:59:59','ENJBTC','4h','0.000009420000000','0.000009450000000','0.001532438431429','0.001537318808599','162.6792390052017','162.679239005201708','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENJBTC','4h','0.000009350000000','0.000009050000000','0.001532438431429','0.001483269283897','163.8971584416043','163.897158441604290','test'),('2019-02-10 23:59:59','2019-02-11 03:59:59','ENJBTC','4h','0.000008240000000','0.000008090000000','0.001532438431429','0.001504542100760','185.97553779478153','185.975537794781530','test'),('2019-02-11 07:59:59','2019-02-17 03:59:59','ENJBTC','4h','0.000008340000000','0.000008460000000','0.001532438431429','0.001554487905263','183.7456152792566','183.745615279256612','test'),('2019-04-13 19:59:59','2019-04-14 23:59:59','ENJBTC','4h','0.000033070000000','0.000031420000000','0.001532438431429','0.001455978697173','46.33923288264288','46.339232882642882','test'),('2019-04-15 07:59:59','2019-04-15 11:59:59','ENJBTC','4h','0.000031700000000','0.000031030000000','0.001532438431429','0.001500049354172','48.341906354227135','48.341906354227135','test'),('2019-04-17 11:59:59','2019-04-20 11:59:59','ENJBTC','4h','0.000031460000000','0.000037730000000','0.001532438431429','0.001837854482448','48.71069394243484','48.710693942434837','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 16:13:01
