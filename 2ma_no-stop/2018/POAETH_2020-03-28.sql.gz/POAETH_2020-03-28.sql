-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-17 15:59:59','2018-08-17 19:59:59','POAETH','4h','0.000256980000000','0.000263720000000','0.072144500000000','0.074036685889953','280.7397462837575','280.739746283757484','test'),('2018-08-19 23:59:59','2018-08-20 07:59:59','POAETH','4h','0.000257830000000','0.000248510000000','0.072617546472488','0.069992578341845','281.64894105607664','281.648941056076637','test'),('2018-08-20 19:59:59','2018-08-20 23:59:59','POAETH','4h','0.000253640000000','0.000248500000000','0.072617546472488','0.071145956073227','286.30163409749247','286.301634097492467','test'),('2018-08-21 11:59:59','2018-08-21 15:59:59','POAETH','4h','0.000252360000000','0.000250480000000','0.072617546472488','0.072076569347079','287.7537901113013','287.753790111301328','test'),('2018-08-21 23:59:59','2018-08-22 03:59:59','POAETH','4h','0.000256450000000','0.000249300000000','0.072617546472488','0.070592920006205','283.16454073888866','283.164540738888661','test'),('2018-08-23 15:59:59','2018-08-24 11:59:59','POAETH','4h','0.000253510000000','0.000292120000000','0.072617546472488','0.083677321113736','286.44844965677095','286.448449656770947','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','POAETH','4h','0.000321480000000','0.000323340000000','0.073716949602401','0.074143456776286','229.30493219609696','229.304932196096956','test'),('2018-09-13 07:59:59','2018-09-13 11:59:59','POAETH','4h','0.000316910000000','0.000314980000000','0.073823576395873','0.073373986599262','232.9480811456644','232.948081145664389','test'),('2018-09-16 11:59:59','2018-09-19 19:59:59','POAETH','4h','0.000339000000000','0.000326170000000','0.073823576395873','0.071029604463250','217.7686619347286','217.768661934728613','test'),('2018-09-23 11:59:59','2018-09-24 03:59:59','POAETH','4h','0.000328540000000','0.000320060000000','0.073823576395873','0.071918103918132','224.7019431298259','224.701943129825906','test'),('2018-10-03 19:59:59','2018-10-05 03:59:59','POAETH','4h','0.000356500000000','0.000351730000000','0.073823576395873','0.072835810731334','207.07875566864797','207.078755668647972','test'),('2018-10-30 23:59:59','2018-10-31 11:59:59','POAETH','4h','0.000504550000000','0.000518110000000','0.073823576395873','0.075807617018067','146.31568010281043','146.315680102810433','test'),('2018-11-28 07:59:59','2018-11-29 11:59:59','POAETH','4h','0.000341800000000','0.000354840000000','0.073823576395873','0.076640017110332','215.98471736650964','215.984717366509642','test'),('2018-12-01 07:59:59','2018-12-02 07:59:59','POAETH','4h','0.000344860000000','0.000353440000000','0.073823576395873','0.075660281973431','214.06824913261323','214.068249132613232','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','POAETH','4h','0.000346260000000','0.000320050000000','0.073948673156547','0.068351160526058','213.56400726779518','213.564007267795176','test'),('2019-01-10 03:59:59','2019-01-10 19:59:59','POAETH','4h','0.000207470000000','0.000199510000000','0.073948673156547','0.071111484944631','356.43067988888515','356.430679888885152','test'),('2019-01-11 07:59:59','2019-01-11 11:59:59','POAETH','4h','0.000201320000000','0.000205400000000','0.073948673156547','0.075447334921293','367.31905998682197','367.319059986821969','test'),('2019-02-01 11:59:59','2019-02-01 23:59:59','POAETH','4h','0.000251000000000','0.000252510000000','0.073948673156547','0.074393543660397','294.6162277153267','294.616227715326715','test'),('2019-02-03 07:59:59','2019-02-03 11:59:59','POAETH','4h','0.000251220000000','0.000250640000000','0.073948673156547','0.073777945386342','294.3582244906735','294.358224490673479','test'),('2019-02-04 03:59:59','2019-02-04 15:59:59','POAETH','4h','0.000255230000000','0.000250000000000','0.073948673156547','0.072433367116470','289.73346846588174','289.733468465881742','test'),('2019-02-26 03:59:59','2019-02-27 15:59:59','POAETH','4h','0.000203470000000','0.000200170000000','0.073948673156547','0.072749328676198','363.43772131787','363.437721317870000','test'),('2019-03-06 15:59:59','2019-03-16 07:59:59','POAETH','4h','0.000215540000000','0.000237990000000','0.073948673156547','0.081650945181992','343.08561360558133','343.085613605581329','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','POAETH','4h','0.000236160000000','0.000236390000000','0.073948673156547','0.074020692951711','313.1295441926957','313.129544192695676','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','POAETH','4h','0.000234910000000','0.000240500000000','0.073948673156547','0.075708381482906','314.79576500169003','314.795765001690029','test'),('2019-04-11 03:59:59','2019-04-11 11:59:59','POAETH','4h','0.000252010000000','0.000234830000000','0.073988036477179','0.068944131605634','293.59166889083264','293.591668890832636','test'),('2019-04-12 03:59:59','2019-04-12 07:59:59','POAETH','4h','0.000248440000000','0.000245620000000','0.073988036477179','0.073148210914203','297.8104833246619','297.810483324661902','test'),('2019-04-13 23:59:59','2019-04-16 15:59:59','POAETH','4h','0.000247520000000','0.000246180000000','0.073988036477179','0.073587487152359','298.91740658200956','298.917406582009562','test'),('2019-04-17 07:59:59','2019-04-18 03:59:59','POAETH','4h','0.000248410000000','0.000247160000000','0.073988036477179','0.073615728415521','297.8464493264321','297.846449326432094','test'),('2019-04-18 23:59:59','2019-04-19 03:59:59','POAETH','4h','0.000248390000000','0.000250090000000','0.073988036477179','0.074494416210708','297.8704314874954','297.870431487495409','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','POAETH','4h','0.000134520000000','0.000125510000000','0.073988036477179','0.069032400076202','550.0151388431385','550.015138843138516','test'),('2019-05-22 19:59:59','2019-05-23 03:59:59','POAETH','4h','0.000139780000000','0.000133770000000','0.073988036477179','0.070806836740251','529.3177598882459','529.317759888245860','test'),('2019-05-26 03:59:59','2019-05-26 19:59:59','POAETH','4h','0.000135960000000','0.000127760000000','0.073988036477179','0.069525680643751','544.1897357838997','544.189735783899664','test'),('2019-05-26 23:59:59','2019-05-30 03:59:59','POAETH','4h','0.000154040000000','0.000143360000000','0.073988036477179','0.068858250515245','480.3170376342443','480.317037634244286','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','POAETH','4h','0.000140040000000','0.000138930000000','0.073988036477179','0.073401584602788','528.3350219735719','528.335021973571884','test'),('2019-06-08 23:59:59','2019-06-09 11:59:59','POAETH','4h','0.000142780000000','0.000139020000000','0.073988036477179','0.072039619211776','518.196081224114','518.196081224113982','test'),('2019-06-10 07:59:59','2019-06-11 07:59:59','POAETH','4h','0.000141380000000','0.000141260000000','0.073988036477179','0.073925237181824','523.3274612899914','523.327461289991447','test'),('2019-06-12 19:59:59','2019-06-13 19:59:59','POAETH','4h','0.000157260000000','0.000140000000000','0.073988036477179','0.065867513079010','470.48223627864047','470.482236278640471','test'),('2019-06-16 11:59:59','2019-06-16 15:59:59','POAETH','4h','0.000142830000000','0.000135610000000','0.073988036477179','0.070247970501087','518.0146781290974','518.014678129097433','test'),('2019-06-19 23:59:59','2019-06-20 03:59:59','POAETH','4h','0.000140430000000','0.000137790000000','0.073988036477179','0.072597105648298','526.867738212483','526.867738212483005','test'),('2019-06-24 19:59:59','2019-06-24 23:59:59','POAETH','4h','0.000134000000000','0.000129000000000','0.073988036477179','0.071227288847433','552.149525949097','552.149525949096983','test'),('2019-06-25 11:59:59','2019-06-25 15:59:59','POAETH','4h','0.000130550000000','0.000124570000000','0.073988036477179','0.070598925346321','566.7409917822979','566.740991782297897','test'),('2019-07-22 15:59:59','2019-07-24 23:59:59','POAETH','4h','0.000096470000000','0.000096470000000','0.073988036477179','0.073988036477179','766.9538351526795','766.953835152679517','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','POAETH','4h','0.000097630000000','0.000096730000000','0.073988036477179','0.073305979396062','757.8412012412066','757.841201241206591','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','POAETH','4h','0.000097750000000','0.000096750000000','0.073988036477179','0.073231125618077','756.9108591015754','756.910859101575397','test'),('2019-08-12 11:59:59','2019-08-12 19:59:59','POAETH','4h','0.000081430000000','0.000075470000000','0.073988036477179','0.068572726426780','908.6090688588849','908.609068858884939','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:11:39
