-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-04 19:59:59','2018-10-04 23:59:59','ADAUSDT','4h','0.082410000000000','0.081640000000000','15.000000000000000','14.859847105933747','182.01674554058974','182.016745540589739','test'),('2018-10-05 19:59:59','2018-10-06 11:59:59','ADAUSDT','4h','0.082160000000000','0.082280000000000','15.000000000000000','15.021908471275561','182.57059396299903','182.570593962999027','test'),('2018-10-07 15:59:59','2018-10-11 03:59:59','ADAUSDT','4h','0.083570000000000','0.078050000000000','15.000000000000000','14.009213832715087','179.49024769654181','179.490247696541815','test'),('2018-10-17 03:59:59','2018-10-17 07:59:59','ADAUSDT','4h','0.079000000000000','0.078110000000000','15.000000000000000','14.831012658227849','189.873417721519','189.873417721518990','test'),('2018-10-17 15:59:59','2018-10-18 15:59:59','ADAUSDT','4h','0.079440000000000','0.078020000000000','15.000000000000000','14.731873111782480','188.82175226586102','188.821752265861022','test'),('2018-10-20 11:59:59','2018-10-20 15:59:59','ADAUSDT','4h','0.078370000000000','0.078000000000000','15.000000000000000','14.929182084981498','191.39977032027562','191.399770320275621','test'),('2018-10-21 03:59:59','2018-10-21 07:59:59','ADAUSDT','4h','0.078650000000000','0.078490000000000','15.000000000000000','14.969485060394152','190.71837253655437','190.718372536554369','test'),('2018-11-04 07:59:59','2018-11-09 11:59:59','ADAUSDT','4h','0.074360000000000','0.075900000000000','15.000000000000000','15.310650887573964','201.72135556750942','201.721355567509420','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','ADAUSDT','4h','0.076060000000000','0.075480000000000','15.000000000000000','14.885616618459112','197.2127267946358','197.212726794635813','test'),('2018-11-11 07:59:59','2018-11-11 15:59:59','ADAUSDT','4h','0.076870000000000','0.075100000000000','15.000000000000000','14.654611682060622','195.1346429036035','195.134642903603492','test'),('2018-11-11 19:59:59','2018-11-12 07:59:59','ADAUSDT','4h','0.076750000000000','0.075770000000000','15.000000000000000','14.808469055374594','195.4397394136808','195.439739413680797','test'),('2018-12-17 19:59:59','2018-12-26 15:59:59','ADAUSDT','4h','0.033040000000000','0.039230000000000','15.000000000000000','17.810230024213073','453.9951573849879','453.995157384987920','test'),('2018-12-28 15:59:59','2019-01-01 03:59:59','ADAUSDT','4h','0.039220000000000','0.040200000000000','15.205525148247935','15.585469427831896','387.6982444734303','387.698244473430293','test'),('2019-01-16 15:59:59','2019-01-17 11:59:59','ADAUSDT','4h','0.044130000000000','0.044340000000000','15.300511218143924','15.373321264729245','346.7145075491485','346.714507549148493','test'),('2019-02-08 15:59:59','2019-02-14 11:59:59','ADAUSDT','4h','0.039880000000000','0.040140000000000','15.318713729790256','15.418584982792902','384.12020385632536','384.120203856325361','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ADAUSDT','4h','0.043160000000000','0.042920000000000','15.343681543040917','15.258359866249219','355.506986632088','355.506986632088001','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','ADAUSDT','4h','0.042840000000000','0.042540000000000','15.343681543040917','15.236232792739509','358.16250100468994','358.162501004689943','test'),('2019-03-07 03:59:59','2019-03-07 07:59:59','ADAUSDT','4h','0.043000000000000','0.042640000000000','15.343681543040917','15.215222813843365','356.829803326533','356.829803326533010','test'),('2019-03-07 15:59:59','2019-03-07 23:59:59','ADAUSDT','4h','0.042840000000000','0.042750000000000','15.343681543040917','15.311446917950494','358.16250100468994','358.162501004689943','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','ADAUSDT','4h','0.043070000000000','0.042430000000000','15.343681543040917','15.115681631558537','356.24986169122167','356.249861691221668','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADAUSDT','4h','0.083750000000000','0.082970000000000','15.343681543040917','15.200779195535580','183.20813782735422','183.208137827354221','test'),('2019-04-12 11:59:59','2019-04-12 23:59:59','ADAUSDT','4h','0.083440000000000','0.082500000000000','15.343681543040917','15.170826070240601','183.88880085140121','183.888800851401214','test'),('2019-04-14 23:59:59','2019-04-15 11:59:59','ADAUSDT','4h','0.084160000000000','0.082360000000000','15.343681543040917','15.015513449202114','182.31560768822382','182.315607688223821','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','ADAUSDT','4h','0.082710000000000','0.082160000000000','15.343681543040917','15.241650049283541','185.5118068315913','185.511806831591286','test'),('2019-04-17 19:59:59','2019-04-17 23:59:59','ADAUSDT','4h','0.082710000000000','0.082440000000000','15.343681543040917','15.293593355196387','185.5118068315913','185.511806831591286','test'),('2019-05-11 11:59:59','2019-05-12 15:59:59','ADAUSDT','4h','0.069500000000000','0.069000000000000','15.343681543040917','15.233295344889545','220.77239630274698','220.772396302746984','test'),('2019-05-24 07:59:59','2019-05-24 23:59:59','ADAUSDT','4h','0.080360000000000','0.080620000000000','15.343681543040917','15.393325111995503','190.93680367148977','190.936803671489770','test'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ADAUSDT','4h','0.082760000000000','0.083920000000000','15.343681543040917','15.558745228274454','185.39972864960026','185.399728649600263','test'),('2019-05-31 19:59:59','2019-06-01 15:59:59','ADAUSDT','4h','0.086540000000000','0.087350000000000','15.343681543040917','15.487295849140560','177.3016124686956','177.301612468695595','test'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ADAUSDT','4h','0.085080000000000','0.083640000000000','15.343681543040917','15.083985945697489','180.34416482182553','180.344164821825530','test'),('2019-06-11 19:59:59','2019-06-14 15:59:59','ADAUSDT','4h','0.088420000000000','0.086400000000000','15.343681543040917','14.993147311906077','173.53179759150552','173.531797591505523','test'),('2019-06-14 23:59:59','2019-06-18 07:59:59','ADAUSDT','4h','0.090080000000000','0.089290000000000','15.343681543040917','15.209117728442758','170.33394252931748','170.333942529317483','test'),('2019-06-21 07:59:59','2019-06-21 11:59:59','ADAUSDT','4h','0.089430000000000','0.089960000000000','15.343681543040917','15.434614688716996','171.57197297373273','171.571972973732727','test'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ADAUSDT','4h','0.064740000000000','0.062620000000000','15.343681543040917','14.841231668600896','237.0046577547253','237.004657754725287','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','ADAUSDT','4h','0.061410000000000','0.061230000000000','15.343681543040917','15.298707390985108','249.85640031006216','249.856400310062156','test'),('2019-07-29 15:59:59','2019-07-29 23:59:59','ADAUSDT','4h','0.061570000000000','0.060350000000000','15.343681543040917','15.039648873193428','249.2071064323683','249.207106432368306','test'),('2019-07-30 11:59:59','2019-07-30 15:59:59','ADAUSDT','4h','0.060900000000000','0.060470000000000','15.343681543040917','15.235343561702532','251.94879381019567','251.948793810195667','test'),('2019-07-31 03:59:59','2019-07-31 07:59:59','ADAUSDT','4h','0.060490000000000','0.060100000000000','15.343681543040917','15.244755508956176','253.65649765318096','253.656497653180963','test'),('2019-08-11 19:59:59','2019-08-12 03:59:59','ADAUSDT','4h','0.055350000000000','0.053280000000000','15.343681543040917','14.769852802406866','277.2119519971259','277.211951997125880','test'),('2019-08-19 07:59:59','2019-08-19 11:59:59','ADAUSDT','4h','0.050730000000000','0.050250000000000','15.343681543040917','15.198501824123914','302.45774774375946','302.457747743759455','test'),('2019-08-23 23:59:59','2019-08-24 03:59:59','ADAUSDT','4h','0.049640000000000','0.049530000000000','15.343681543040917','15.309680637123623','309.0991447026776','309.099144702677620','test'),('2019-08-24 19:59:59','2019-08-25 19:59:59','ADAUSDT','4h','0.050280000000000','0.049780000000000','15.343681543040917','15.191099188794288','305.1647084932561','305.164708493256114','test'),('2019-08-26 15:59:59','2019-08-26 19:59:59','ADAUSDT','4h','0.049990000000000','0.049930000000000','15.343681543040917','15.325265441969055','306.9350178643912','306.935017864391227','test'),('2019-09-07 23:59:59','2019-09-09 03:59:59','ADAUSDT','4h','0.045970000000000','0.045700000000000','15.343681543040917','15.253562029953663','333.77597439723553','333.775974397235530','test'),('2019-09-09 11:59:59','2019-09-10 19:59:59','ADAUSDT','4h','0.046180000000000','0.045970000000000','15.343681543040917','15.273907330740384','332.25815381205973','332.258153812059732','test'),('2019-09-14 19:59:59','2019-09-16 15:59:59','ADAUSDT','4h','0.046780000000000','0.045870000000000','15.343681543040917','15.045204625465731','327.99661271998536','327.996612719985364','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:30:36
