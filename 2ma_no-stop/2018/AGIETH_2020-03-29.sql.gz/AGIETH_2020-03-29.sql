-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-21 15:59:59','2018-11-21 19:59:59','AGIETH','4h','0.000296060000000','0.000294280000000','0.072144500000000','0.071710745997433','243.68202391407146','243.682023914071465','test'),('2018-11-22 03:59:59','2018-11-22 07:59:59','AGIETH','4h','0.000294030000000','0.000294220000000','0.072144500000000','0.072191119239533','245.36441859674184','245.364418596741842','test'),('2018-11-25 23:59:59','2018-11-26 03:59:59','AGIETH','4h','0.000299840000000','0.000293960000000','0.072144500000000','0.070729713247065','240.60999199573106','240.609991995731065','test'),('2018-11-26 19:59:59','2018-11-26 23:59:59','AGIETH','4h','0.000296240000000','0.000298660000000','0.072144500000000','0.072733852180664','243.5339589522009','243.533958952200891','test'),('2018-12-11 19:59:59','2018-12-12 11:59:59','AGIETH','4h','0.000398100000000','0.000397080000000','0.072144500000000','0.071959653504145','181.22205476011052','181.222054760110524','test'),('2018-12-14 11:59:59','2018-12-14 19:59:59','AGIETH','4h','0.000402630000000','0.000400000000000','0.072144500000000','0.071673248391824','179.1831209795594','179.183120979559391','test'),('2018-12-15 15:59:59','2018-12-15 19:59:59','AGIETH','4h','0.000401460000000','0.000409170000000','0.072144500000000','0.073530028060081','179.7053255616998','179.705325561699794','test'),('2018-12-17 11:59:59','2018-12-17 23:59:59','AGIETH','4h','0.000404410000000','0.000412090000000','0.072144500000000','0.073514569385030','178.39445117578694','178.394451175786941','test'),('2019-01-05 15:59:59','2019-01-10 03:59:59','AGIETH','4h','0.000353870000000','0.000353480000000','0.072366232501444','0.072286477702576','204.4994842779658','204.499484277965792','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','AGIETH','4h','0.000420000000000','0.000405970000000','0.072366232501444','0.069948855734789','172.30055357486665','172.300553574866655','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','AGIETH','4h','0.000337640000000','0.000334360000000','0.072366232501444','0.071663231545974','214.3295595943727','214.329559594372711','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','AGIETH','4h','0.000336420000000','0.000333620000000','0.072366232501444','0.071763933437762','215.10680845801085','215.106808458010846','test'),('2019-03-01 07:59:59','2019-03-01 19:59:59','AGIETH','4h','0.000342380000000','0.000347120000000','0.072366232501444','0.073368089917347','211.36232403015364','211.362324030153644','test'),('2019-03-10 07:59:59','2019-03-10 11:59:59','AGIETH','4h','0.000336160000000','0.000335920000000','0.072366232501444','0.072314566938021','215.2731809300452','215.273180930045214','test'),('2019-03-13 07:59:59','2019-03-16 07:59:59','AGIETH','4h','0.000350170000000','0.000386410000000','0.072366232501444','0.079855601281900','206.660286436428','206.660286436428009','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','AGIETH','4h','0.000381180000000','0.000383000000000','0.073525514763509','0.073876573152904','192.88922494230806','192.889224942308061','test'),('2019-03-25 03:59:59','2019-03-25 07:59:59','AGIETH','4h','0.000383310000000','0.000379340000000','0.073613279360858','0.072850855424455','192.0463315876386','192.046331587638605','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','AGIETH','4h','0.000383050000000','0.000379260000000','0.073613279360858','0.072884929723010','192.17668544800418','192.176685448004179','test'),('2019-03-28 03:59:59','2019-03-29 03:59:59','AGIETH','4h','0.000382580000000','0.000375550000000','0.073613279360858','0.072260617554421','192.41277474216636','192.412774742166363','test'),('2019-04-16 11:59:59','2019-04-16 15:59:59','AGIETH','4h','0.000291000000000','0.000287320000000','0.073613279360858','0.072682362288528','252.96659574178005','252.966595741780054','test'),('2019-04-16 19:59:59','2019-04-16 23:59:59','AGIETH','4h','0.000291770000000','0.000277220000000','0.073613279360858','0.069942328904332','252.2990004484971','252.299000448497111','test'),('2019-04-20 15:59:59','2019-04-20 19:59:59','AGIETH','4h','0.000285230000000','0.000275350000000','0.073613279360858','0.071063410132217','258.08393002439436','258.083930024394363','test'),('2019-04-28 07:59:59','2019-04-28 11:59:59','AGIETH','4h','0.000255800000000','0.000250640000000','0.073613279360858','0.072128351598927','287.77669804870214','287.776698048702144','test'),('2019-05-01 19:59:59','2019-05-01 23:59:59','AGIETH','4h','0.000253670000000','0.000240810000000','0.073613279360858','0.069881396313668','290.1930829852091','290.193082985209116','test'),('2019-05-05 03:59:59','2019-05-05 19:59:59','AGIETH','4h','0.000256980000000','0.000231960000000','0.073613279360858','0.066446168108587','286.45528586216045','286.455285862160451','test'),('2019-05-07 19:59:59','2019-05-08 07:59:59','AGIETH','4h','0.000246760000000','0.000241950000000','0.073613279360858','0.072178363354513','298.31933603849086','298.319336038490860','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','AGIETH','4h','0.000198500000000','0.000191300000000','0.073613279360858','0.070943175525099','370.847754966539','370.847754966539014','test'),('2019-05-22 07:59:59','2019-05-22 23:59:59','AGIETH','4h','0.000196090000000','0.000193480000000','0.073613279360858','0.072633470807990','375.4055758114029','375.405575811402912','test'),('2019-05-31 19:59:59','2019-06-01 03:59:59','AGIETH','4h','0.000190750000000','0.000188810000000','0.073613279360858','0.072864604330923','385.91496388392136','385.914963883921359','test'),('2019-06-02 15:59:59','2019-06-02 23:59:59','AGIETH','4h','0.000190520000000','0.000194150000000','0.073613279360858','0.075015841842907','386.3808490492232','386.380849049223173','test'),('2019-06-07 03:59:59','2019-06-09 19:59:59','AGIETH','4h','0.000196200000000','0.000199920000000','0.073613279360858','0.075009005146905','375.19510377603467','375.195103776034671','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','AGIETH','4h','0.000200960000000','0.000197170000000','0.073613279360858','0.072224971594249','366.30811783866443','366.308117838664430','test'),('2019-06-12 15:59:59','2019-06-12 19:59:59','AGIETH','4h','0.000202950000000','0.000199360000000','0.073613279360858','0.072311127732844','362.7163309231732','362.716330923173189','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','AGIETH','4h','0.000200060000000','0.000196180000000','0.073613279360858','0.072185610042053','367.9560100012896','367.956010001289599','test'),('2019-06-19 23:59:59','2019-06-20 03:59:59','AGIETH','4h','0.000186130000000','0.000185150000000','0.073613279360858','0.073225695340154','395.49389867758015','395.493898677580148','test'),('2019-07-14 23:59:59','2019-07-15 03:59:59','AGIETH','4h','0.000107620000000','0.000105400000000','0.073613279360858','0.072094774620279','684.0111444049247','684.011144404924721','test'),('2019-07-15 07:59:59','2019-07-15 11:59:59','AGIETH','4h','0.000108010000000','0.000108710000000','0.073613279360858','0.074090358293851','681.5413328474956','681.541332847495596','test'),('2019-07-30 19:59:59','2019-07-31 03:59:59','AGIETH','4h','0.000140910000000','0.000135400000000','0.073613279360858','0.070734781246613','522.4134508612448','522.413450861244769','test'),('2019-08-03 07:59:59','2019-08-05 03:59:59','AGIETH','4h','0.000139650000000','0.000134430000000','0.073613279360858','0.070861676652203','527.1269556810455','527.126955681045501','test'),('2019-08-07 03:59:59','2019-08-19 11:59:59','AGIETH','4h','0.000137220000000','0.000167200000000','0.073613279360858','0.089696402194545','536.4617356133072','536.461735613307155','test'),('2019-08-20 11:59:59','2019-08-23 15:59:59','AGIETH','4h','0.000177420000000','0.000171010000000','0.073613279360858','0.070953708169881','414.9097021804645','414.909702180464478','test'),('2019-08-24 03:59:59','2019-08-25 11:59:59','AGIETH','4h','0.000174070000000','0.000177460000000','0.073613279360858','0.075046892373056','422.8946938637215','422.894693863721500','test'),('2019-08-29 11:59:59','2019-08-29 15:59:59','AGIETH','4h','0.000187480000000','0.000180400000000','0.073613279360858','0.070833345405903','392.6460388353851','392.646038835385127','test'),('2019-08-31 11:59:59','2019-08-31 15:59:59','AGIETH','4h','0.000180460000000','0.000178410000000','0.073613279360858','0.072777042950076','407.9202003815694','407.920200381569373','test'),('2019-08-31 19:59:59','2019-08-31 23:59:59','AGIETH','4h','0.000183720000000','0.000179220000000','0.073613279360858','0.071810210793887','400.6819037712715','400.681903771271493','test'),('2019-09-05 11:59:59','2019-09-05 19:59:59','AGIETH','4h','0.000179250000000','0.000173050000000','0.073613279360858','0.071067101776270','410.67380396573503','410.673803965735033','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','AGIETH','4h','0.000133860000000','0.000130400000000','0.073613279360858','0.071710530618974','549.927382047348','549.927382047348033','test'),('2019-10-04 11:59:59','2019-10-04 23:59:59','AGIETH','4h','0.000126040000000','0.000124170000000','0.073613279360858','0.072521111537907','584.0469641451762','584.046964145176162','test'),('2019-10-05 19:59:59','2019-10-06 07:59:59','AGIETH','4h','0.000124090000000','0.000122410000000','0.073613279360858','0.072616661508281','593.2249122480296','593.224912248029568','test'),('2019-10-06 15:59:59','2019-10-08 07:59:59','AGIETH','4h','0.000124580000000','0.000126120000000','0.073613279360858','0.074523252472238','590.8916307662386','590.891630766238563','test'),('2019-10-11 19:59:59','2019-10-11 23:59:59','AGIETH','4h','0.000125460000000','0.000124750000000','0.073613279360858','0.073196688986665','586.747005905133','586.747005905133051','test'),('2019-10-17 07:59:59','2019-10-17 23:59:59','AGIETH','4h','0.000124000000000','0.000122530000000','0.073613279360858','0.072740605807145','593.6554787165968','593.655478716596804','test'),('2019-10-18 03:59:59','2019-10-18 07:59:59','AGIETH','4h','0.000124000000000','0.000122670000000','0.073613279360858','0.072823717574165','593.6554787165968','593.655478716596804','test'),('2019-10-18 15:59:59','2019-10-19 15:59:59','AGIETH','4h','0.000125040000000','0.000125410000000','0.073613279360858','0.073831104963573','588.7178451764075','588.717845176407536','test'),('2019-10-28 03:59:59','2019-10-28 15:59:59','AGIETH','4h','0.000122830000000','0.000122010000000','0.073613279360858','0.073121844946823','599.3102610181389','599.310261018138931','test'),('2019-10-31 15:59:59','2019-10-31 19:59:59','AGIETH','4h','0.000120650000000','0.000121210000000','0.073613279360858','0.073954957242682','610.1390746859345','610.139074685934474','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','AGIETH','4h','0.000121060000000','0.000120680000000','0.073613279360858','0.073382211740198','608.0726859479432','608.072685947943228','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','AGIETH','4h','0.000120850000000','0.000120260000000','0.073613279360858','0.073253893056986','609.1293285962598','609.129328596259825','test'),('2019-11-07 11:59:59','2019-11-07 15:59:59','AGIETH','4h','0.000119790000000','0.000117690000000','0.073613279360858','0.072322788613235','614.5194036301694','614.519403630169450','test'),('2019-11-12 15:59:59','2019-11-12 19:59:59','AGIETH','4h','0.000116430000000','0.000116800000000','0.073613279360858','0.073847213169700','632.2535374118183','632.253537411818343','test'),('2019-11-13 11:59:59','2019-11-13 15:59:59','AGIETH','4h','0.000115320000000','0.000115530000000','0.073613279360858','0.073747330597988','638.3392244264481','638.339224426448141','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','AGIETH','4h','0.000115290000000','0.000124840000000','0.073613279360858','0.079711005251188','638.5053288304102','638.505328830410235','test'),('2019-11-18 03:59:59','2019-11-20 03:59:59','AGIETH','4h','0.000125010000000','0.000131210000000','0.073613279360858','0.077264205943030','588.8591261567715','588.859126156771481','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:22:26
