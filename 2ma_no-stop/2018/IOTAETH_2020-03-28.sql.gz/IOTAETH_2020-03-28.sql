-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-17 23:59:59','2018-04-01 11:59:59','IOTAETH','4h','0.002078000000000','0.002761520000000','0.072144500000000','0.095875110510106','34.71823869104909','34.718238691049088','test'),('2018-04-12 11:59:59','2018-04-12 15:59:59','IOTAETH','4h','0.002582500000000','0.002629080000000','0.078077152627526','0.079485413525644','30.233166554705324','30.233166554705324','test'),('2018-04-26 23:59:59','2018-04-27 03:59:59','IOTAETH','4h','0.003094190000000','0.003026510000000','0.078429217852056','0.076713715745131','25.34725335291498','25.347253352914979','test'),('2018-04-27 07:59:59','2018-04-27 11:59:59','IOTAETH','4h','0.003100000000000','0.003021340000000','0.078429217852056','0.076439139698429','25.299747694211614','25.299747694211614','test'),('2018-05-02 11:59:59','2018-05-04 11:59:59','IOTAETH','4h','0.003004830000000','0.002987910000000','0.078429217852056','0.077987588087292','26.10104992696958','26.101049926969580','test'),('2018-05-04 19:59:59','2018-05-04 23:59:59','IOTAETH','4h','0.003099360000000','0.003125090000000','0.078429217852056','0.079080314780239','25.30497194648444','25.304971946484439','test'),('2018-05-08 07:59:59','2018-05-09 23:59:59','IOTAETH','4h','0.003060780000000','0.003026630000000','0.078429217852056','0.077554160582456','25.6239317598965','25.623931759896500','test'),('2018-05-28 07:59:59','2018-05-29 03:59:59','IOTAETH','4h','0.002652170000000','0.002578980000000','0.078429217852056','0.076264863962753','29.571715935274135','29.571715935274135','test'),('2018-06-04 11:59:59','2018-06-04 23:59:59','IOTAETH','4h','0.002901120000000','0.002909340000000','0.078429217852056','0.078651438294762','27.034117117546327','27.034117117546327','test'),('2018-06-05 11:59:59','2018-06-05 15:59:59','IOTAETH','4h','0.002910880000000','0.002872330000000','0.078429217852056','0.077390546952467','26.943473400502945','26.943473400502945','test'),('2018-06-05 19:59:59','2018-06-05 23:59:59','IOTAETH','4h','0.002906580000000','0.002860050000000','0.078429217852056','0.077173683338416','26.983333626480604','26.983333626480604','test'),('2018-07-01 07:59:59','2018-07-06 07:59:59','IOTAETH','4h','0.002281540000000','0.002410690000000','0.078429217852056','0.082868821578308','34.375561178877426','34.375561178877426','test'),('2018-07-16 15:59:59','2018-07-16 19:59:59','IOTAETH','4h','0.002267500000000','0.002238940000000','0.078429217852056','0.077441372885417','34.58840919605557','34.588409196055572','test'),('2018-07-16 23:59:59','2018-07-17 07:59:59','IOTAETH','4h','0.002278610000000','0.002272980000000','0.078429217852056','0.078235434582209','34.419763738444054','34.419763738444054','test'),('2018-07-19 11:59:59','2018-07-19 15:59:59','IOTAETH','4h','0.002271620000000','0.002215340000000','0.078429217852056','0.076486112763743','34.52567676462437','34.525676764624372','test'),('2018-07-26 11:59:59','2018-07-26 15:59:59','IOTAETH','4h','0.002175830000000','0.002178110000000','0.078429217852056','0.078511401945805','36.04565515323164','36.045655153231642','test'),('2018-07-28 03:59:59','2018-07-28 11:59:59','IOTAETH','4h','0.002182900000000','0.002162270000000','0.078429217852056','0.077688004436742','35.92891009760227','35.928910097602270','test'),('2018-07-28 23:59:59','2018-07-29 23:59:59','IOTAETH','4h','0.002195000000000','0.002165670000000','0.078429217852056','0.077381231993468','35.73085095765649','35.730850957656493','test'),('2018-07-31 11:59:59','2018-07-31 15:59:59','IOTAETH','4h','0.002187090000000','0.002189000000000','0.078429217852056','0.078497710600913','35.86007793554724','35.860077935547238','test'),('2018-08-03 15:59:59','2018-08-04 11:59:59','IOTAETH','4h','0.002230000000000','0.002148200000000','0.078429217852056','0.075552307529052','35.170052848455605','35.170052848455605','test'),('2018-08-05 07:59:59','2018-08-06 11:59:59','IOTAETH','4h','0.002250000000000','0.002165570000000','0.078429217852056','0.075486205023945','34.85743015646934','34.857430156469341','test'),('2018-08-06 15:59:59','2018-08-06 19:59:59','IOTAETH','4h','0.002196050000000','0.002148000000000','0.078429217852056','0.076713171351388','35.713766923365135','35.713766923365135','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','IOTAETH','4h','0.001776320000000','0.001761330000000','0.078429217852056','0.077767369775357','44.15264020675104','44.152640206751038','test'),('2018-08-19 11:59:59','2018-08-20 11:59:59','IOTAETH','4h','0.001815400000000','0.001781040000000','0.078429217852056','0.076944791320495','43.20216913741104','43.202169137411040','test'),('2018-09-17 23:59:59','2018-09-18 03:59:59','IOTAETH','4h','0.002728720000000','0.002701000000000','0.078429217852056','0.077632486080801','28.74212739015216','28.742127390152159','test'),('2018-09-25 19:59:59','2018-09-26 19:59:59','IOTAETH','4h','0.002604960000000','0.002569020000000','0.078429217852056','0.077347148995105','30.107647661405935','30.107647661405935','test'),('2018-09-27 15:59:59','2018-09-27 23:59:59','IOTAETH','4h','0.002611000000000','0.002550060000000','0.078429217852056','0.076598702135509','30.037999943338185','30.037999943338185','test'),('2018-09-28 23:59:59','2018-09-29 03:59:59','IOTAETH','4h','0.002580600000000','0.002564620000000','0.078429217852056','0.077943556028730','30.391853775112764','30.391853775112764','test'),('2018-10-03 23:59:59','2018-10-04 03:59:59','IOTAETH','4h','0.002514350000000','0.002486510000000','0.078429217852056','0.077560814716056','31.192641379305194','31.192641379305194','test'),('2018-10-04 15:59:59','2018-10-04 23:59:59','IOTAETH','4h','0.002540070000000','0.002503440000000','0.078429217852056','0.077298200891925','30.876793888379453','30.876793888379453','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','IOTAETH','4h','0.002555740000000','0.002510010000000','0.078429217852056','0.077025879432508','30.687479106660305','30.687479106660305','test'),('2018-10-18 03:59:59','2018-10-18 07:59:59','IOTAETH','4h','0.002497390000000','0.002470000000000','0.078429217852056','0.077569049325327','31.404473411063552','31.404473411063552','test'),('2018-10-25 15:59:59','2018-10-25 23:59:59','IOTAETH','4h','0.002448370000000','0.002458270000000','0.078429217852056','0.078746346903929','32.033237562972914','32.033237562972914','test'),('2018-10-26 15:59:59','2018-10-26 19:59:59','IOTAETH','4h','0.002440070000000','0.002418150000000','0.078429217852056','0.077724660828972','32.14219995822087','32.142199958220871','test'),('2018-11-01 23:59:59','2018-11-02 03:59:59','IOTAETH','4h','0.002382970000000','0.002381380000000','0.078429217852056','0.078376887165398','32.91238154574166','32.912381545741660','test'),('2018-11-05 07:59:59','2018-11-05 11:59:59','IOTAETH','4h','0.002401020000000','0.002379240000000','0.078429217852056','0.077717775063234','32.66495816447011','32.664958164470107','test'),('2018-11-05 19:59:59','2018-11-05 23:59:59','IOTAETH','4h','0.002388390000000','0.002411970000000','0.078429217852056','0.079203530655640','32.83769311211989','32.837693112119887','test'),('2018-11-12 11:59:59','2018-11-12 23:59:59','IOTAETH','4h','0.002366000000000','0.002341380000000','0.078429217852056','0.077613103167560','33.14844372445309','33.148443724453088','test'),('2018-11-16 15:59:59','2018-11-16 19:59:59','IOTAETH','4h','0.002344150000000','0.002326850000000','0.078429217852056','0.077850404436174','33.4574228833718','33.457422883371798','test'),('2018-11-16 23:59:59','2018-11-17 03:59:59','IOTAETH','4h','0.002349520000000','0.002356090000000','0.078429217852056','0.078648530716508','33.380953493503355','33.380953493503355','test'),('2018-11-19 07:59:59','2018-11-19 11:59:59','IOTAETH','4h','0.002367000000000','0.002345370000000','0.078429217852056','0.077712519929732','33.134439312233205','33.134439312233205','test'),('2018-11-19 23:59:59','2018-11-20 03:59:59','IOTAETH','4h','0.002359970000000','0.002334750000000','0.078429217852056','0.077591078013741','33.233141884030736','33.233141884030736','test'),('2018-11-21 07:59:59','2018-11-21 11:59:59','IOTAETH','4h','0.002347790000000','0.002340610000000','0.078429217852056','0.078189365998109','33.405550688969626','33.405550688969626','test'),('2018-11-21 19:59:59','2018-11-24 23:59:59','IOTAETH','4h','0.002362590000000','0.002458610000000','0.078429217852056','0.081616725417124','33.196287909479004','33.196287909479004','test'),('2018-11-26 19:59:59','2018-11-27 23:59:59','IOTAETH','4h','0.002459170000000','0.002437700000000','0.078429217852056','0.077744484666760','31.892556371481437','31.892556371481437','test'),('2018-12-04 15:59:59','2018-12-05 11:59:59','IOTAETH','4h','0.002513260000000','0.002479240000000','0.078429217852056','0.077367583961680','31.206169617172918','31.206169617172918','test'),('2018-12-06 03:59:59','2018-12-06 15:59:59','IOTAETH','4h','0.002517710000000','0.002477870000000','0.078429217852056','0.077188161479707','31.15101336216483','31.151013362164829','test'),('2018-12-10 07:59:59','2018-12-11 07:59:59','IOTAETH','4h','0.002505750000000','0.002534820000000','0.078429217852056','0.079339100068143','31.29969783580006','31.299697835800060','test'),('2018-12-13 19:59:59','2018-12-13 23:59:59','IOTAETH','4h','0.002517350000000','0.002530530000000','0.078429217852056','0.078839846922821','31.15546819157289','31.155468191572890','test'),('2018-12-14 19:59:59','2018-12-14 23:59:59','IOTAETH','4h','0.002506510000000','0.002525460000000','0.078429217852056','0.079022167283056','31.290207440646956','31.290207440646956','test'),('2018-12-27 19:59:59','2018-12-28 07:59:59','IOTAETH','4h','0.002715280000000','0.002676680000000','0.078429217852056','0.077314280236381','28.88439418846528','28.884394188465279','test'),('2018-12-31 19:59:59','2018-12-31 23:59:59','IOTAETH','4h','0.002644250000000','0.002651980000000','0.078429217852056','0.078658491882120','29.660288494679403','29.660288494679403','test'),('2019-01-10 11:59:59','2019-01-10 15:59:59','IOTAETH','4h','0.002491000000000','0.002476150000000','0.078429217852056','0.077961665108137','31.485033260560417','31.485033260560417','test'),('2019-01-11 15:59:59','2019-01-11 23:59:59','IOTAETH','4h','0.002485910000000','0.002472600000000','0.078429217852056','0.078009294005412','31.549500123518552','31.549500123518552','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','IOTAETH','4h','0.002478080000000','0.002464220000000','0.078429217852056','0.077990560117266','31.649187214317536','31.649187214317536','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','IOTAETH','4h','0.002452060000000','0.002431990000000','0.078429217852056','0.077787278257474','31.985032116692093','31.985032116692093','test'),('2019-01-17 15:59:59','2019-01-21 15:59:59','IOTAETH','4h','0.002469370000000','0.002582220000000','0.078429217852056','0.082013426469883','31.76082071623775','31.760820716237749','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','IOTAETH','4h','0.002456350000000','0.002413330000000','0.078429217852056','0.077055624938996','31.92917045700165','31.929170457001650','test'),('2019-02-07 15:59:59','2019-02-08 11:59:59','IOTAETH','4h','0.002429000000000','0.002382190000000','0.078429217852056','0.076917784468913','32.288685818055164','32.288685818055164','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','IOTAETH','4h','0.002110850000000','0.002152810000000','0.078429217852056','0.079988253302738','37.15527766163205','37.155277661632049','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','IOTAETH','4h','0.002093220000000','0.002062390000000','0.078429217852056','0.077274072771090','37.46821540595638','37.468215405956379','test'),('2019-03-11 03:59:59','2019-03-11 07:59:59','IOTAETH','4h','0.002090500000000','0.002085160000000','0.078429217852056','0.078228877252520','37.516966205240855','37.516966205240855','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:30:47
