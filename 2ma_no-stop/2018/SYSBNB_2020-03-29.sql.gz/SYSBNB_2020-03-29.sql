-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-18 11:59:59','2018-09-18 15:59:59','SYSBNB','4h','0.008810000000000','0.008680000000000','0.711908500000000','0.701403607264472','80.80686719636778','80.806867196367776','test'),('2018-09-20 15:59:59','2018-09-20 23:59:59','SYSBNB','4h','0.008740000000000','0.008530000000000','0.711908500000000','0.694803147025172','81.45406178489704','81.454061784897036','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','SYSBNB','4h','0.008780000000000','0.008470000000000','0.711908500000000','0.686772778473804','81.08297266514808','81.082972665148077','test'),('2018-09-22 03:59:59','2018-09-22 11:59:59','SYSBNB','4h','0.008890000000000','0.008760000000000','0.711908500000000','0.701498139482565','80.07969628796401','80.079696287964012','test'),('2018-09-23 07:59:59','2018-09-25 07:59:59','SYSBNB','4h','0.008970000000000','0.008800000000000','0.711908500000000','0.698416365663322','79.3654960981048','79.365496098104799','test'),('2018-09-26 11:59:59','2018-10-03 07:59:59','SYSBNB','4h','0.008860000000000','0.008990000000000','0.711908500000000','0.722354110045147','80.35084650112867','80.350846501128672','test'),('2018-10-04 03:59:59','2018-10-04 07:59:59','SYSBNB','4h','0.009400000000000','0.009210000000000','0.711908500000000','0.697518860106383','75.73494680851064','75.734946808510642','test'),('2018-10-04 23:59:59','2018-10-05 07:59:59','SYSBNB','4h','0.009290000000000','0.008910000000000','0.711908500000000','0.682788453713671','76.6317007534984','76.631700753498393','test'),('2018-10-06 23:59:59','2018-10-07 11:59:59','SYSBNB','4h','0.009150000000000','0.009080000000000','0.711908500000000','0.706462205464481','77.80420765027323','77.804207650273227','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','SYSBNB','4h','0.009200000000000','0.009040000000000','0.711908500000000','0.699527482608696','77.38135869565218','77.381358695652182','test'),('2018-10-08 19:59:59','2018-10-08 23:59:59','SYSBNB','4h','0.009250000000000','0.009310000000000','0.711908500000000','0.716526284864865','76.96308108108109','76.963081081081086','test'),('2018-10-09 19:59:59','2018-10-10 03:59:59','SYSBNB','4h','0.009180000000000','0.009050000000000','0.711908500000000','0.701827007080610','77.54994553376906','77.549945533769062','test'),('2018-10-10 15:59:59','2018-10-10 19:59:59','SYSBNB','4h','0.009230000000000','0.009270000000000','0.711908500000000','0.714993693932828','77.1298483206934','77.129848320693398','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','SYSBNB','4h','0.009520000000000','0.009130000000000','0.711908500000000','0.682744181197479','74.78030462184874','74.780304621848742','test'),('2018-10-28 07:59:59','2018-10-28 15:59:59','SYSBNB','4h','0.010120000000000','0.010030000000000','0.711908500000000','0.705577297924901','70.34668972332015','70.346689723320154','test'),('2018-10-31 07:59:59','2018-10-31 11:59:59','SYSBNB','4h','0.010040000000000','0.009780000000000','0.711908500000000','0.693472622509960','70.90722111553785','70.907221115537851','test'),('2018-10-31 15:59:59','2018-10-31 23:59:59','SYSBNB','4h','0.009970000000000','0.009950000000000','0.711908500000000','0.710480398696088','71.40506519558677','71.405065195586772','test'),('2018-11-11 07:59:59','2018-11-12 11:59:59','SYSBNB','4h','0.009520000000000','0.009490000000000','0.711908500000000','0.709665090861345','74.78030462184874','74.780304621848742','test'),('2018-11-12 23:59:59','2018-11-13 03:59:59','SYSBNB','4h','0.009500000000000','0.009400000000000','0.711908500000000','0.704414726315790','74.93773684210527','74.937736842105267','test'),('2018-11-27 23:59:59','2018-11-28 07:59:59','SYSBNB','4h','0.007740000000000','0.007710000000000','0.711908500000000','0.709149164728682','91.97784237726098','91.977842377260984','test'),('2018-11-30 23:59:59','2018-12-01 07:59:59','SYSBNB','4h','0.008040000000000','0.007730000000000','0.711908500000000','0.684459291666667','88.54583333333333','88.545833333333334','test'),('2018-12-13 23:59:59','2018-12-18 23:59:59','SYSBNB','4h','0.007740000000000','0.008510000000000','0.711908500000000','0.782731438630491','91.97784237726098','91.977842377260984','test'),('2018-12-21 15:59:59','2018-12-22 03:59:59','SYSBNB','4h','0.008680000000000','0.008310000000000','0.711908500000000','0.681562169930876','82.01710829493088','82.017108294930878','test'),('2018-12-27 15:59:59','2018-12-27 19:59:59','SYSBNB','4h','0.008470000000000','0.008000000000000','0.711908500000000','0.672404722550177','84.05059031877214','84.050590318772137','test'),('2018-12-27 23:59:59','2018-12-28 15:59:59','SYSBNB','4h','0.008160000000000','0.008030000000000','0.711908500000000','0.700566820465686','87.2436887254902','87.243688725490202','test'),('2018-12-29 19:59:59','2018-12-31 07:59:59','SYSBNB','4h','0.009450000000000','0.007970000000000','0.711908500000000','0.600413835449735','75.33423280423281','75.334232804232812','test'),('2019-01-03 19:59:59','2019-01-04 03:59:59','SYSBNB','4h','0.008570000000000','0.007900000000000','0.711908500000000','0.656251709451575','83.06983663943991','83.069836639439913','test'),('2019-01-07 23:59:59','2019-01-08 11:59:59','SYSBNB','4h','0.008170000000000','0.007560000000000','0.711908500000000','0.658754988984088','87.13690330477357','87.136903304773568','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','SYSBNB','4h','0.007950000000000','0.007320000000000','0.711908500000000','0.655493109433962','89.5482389937107','89.548238993710697','test'),('2019-01-21 03:59:59','2019-01-21 07:59:59','SYSBNB','4h','0.007150000000000','0.006810000000000','0.711908500000000','0.678055508391608','99.56762237762238','99.567622377622385','test'),('2019-01-24 19:59:59','2019-01-25 03:59:59','SYSBNB','4h','0.006880000000000','0.006720000000000','0.711908500000000','0.695352488372093','103.47507267441861','103.475072674418612','test'),('2019-01-28 19:59:59','2019-01-29 03:59:59','SYSBNB','4h','0.006730000000000','0.006640000000000','0.711908500000000','0.702388178306092','105.78135215453196','105.781352154531959','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','SYSBNB','4h','0.004960000000000','0.004870000000000','0.711908500000000','0.698990805443549','143.52993951612905','143.529939516129048','test'),('2019-02-19 11:59:59','2019-02-19 19:59:59','SYSBNB','4h','0.005420000000000','0.004700000000000','0.711908500000000','0.617337629151292','131.34843173431736','131.348431734317359','test'),('2019-02-20 15:59:59','2019-02-22 11:59:59','SYSBNB','4h','0.004970000000000','0.005140000000000','0.711908500000000','0.736259494969819','143.24114688128776','143.241146881287762','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','SYSBNB','4h','0.004970000000000','0.004920000000000','0.711908500000000','0.704746442655936','143.24114688128776','143.241146881287762','test'),('2019-02-26 11:59:59','2019-02-27 07:59:59','SYSBNB','4h','0.005240000000000','0.004980000000000','0.711908500000000','0.676584795801527','135.8604007633588','135.860400763358797','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','SYSBNB','4h','0.005060000000000','0.005290000000000','0.711908500000000','0.744267977272727','140.6933794466403','140.693379446640307','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','SYSBNB','4h','0.003770000000000','0.003700000000000','0.711908500000000','0.698690039787799','188.83514588859418','188.835145888594184','test'),('2019-03-20 11:59:59','2019-03-23 15:59:59','SYSBNB','4h','0.003810000000000','0.003870000000000','0.711908500000000','0.723119657480315','186.85262467191603','186.852624671916033','test'),('2019-03-27 23:59:59','2019-03-28 03:59:59','SYSBNB','4h','0.003800000000000','0.003680000000000','0.711908500000000','0.689427178947368','187.34434210526317','187.344342105263166','test'),('2019-03-28 07:59:59','2019-03-28 11:59:59','SYSBNB','4h','0.003740000000000','0.003690000000000','0.711908500000000','0.702391006684492','190.34986631016045','190.349866310160451','test'),('2019-03-28 19:59:59','2019-03-30 11:59:59','SYSBNB','4h','0.003710000000000','0.003790000000000','0.711908500000000','0.727259626684636','191.8890835579515','191.889083557951494','test'),('2019-04-03 11:59:59','2019-04-03 19:59:59','SYSBNB','4h','0.003670000000000','0.003510000000000','0.711908500000000','0.680871617166213','193.98051771117167','193.980517711171672','test'),('2019-05-01 19:59:59','2019-05-02 11:59:59','SYSBNB','4h','0.002560000000000','0.002480000000000','0.474605666666667','0.459774239583334','185.39283854166666','185.392838541666663','test'),('2019-05-04 11:59:59','2019-05-05 03:59:59','SYSBNB','4h','0.002670000000000','0.002540000000000','0.529401181138912','0.503625093667729','198.27759593217687','198.277595932176865','test'),('2019-05-18 07:59:59','2019-05-18 11:59:59','SYSBNB','4h','0.002580000000000','0.002520000000000','0.529401181138912','0.517089525763588','205.19425625539225','205.194256255392247','test'),('2019-05-19 03:59:59','2019-05-19 19:59:59','SYSBNB','4h','0.002640000000000','0.002530000000000','0.529401181138912','0.507342798591457','200.53075043140606','200.530750431406062','test'),('2019-05-21 11:59:59','2019-05-21 15:59:59','SYSBNB','4h','0.002540000000000','0.002250000000000','0.529401181138912','0.468957739197855','208.42566186571338','208.425661865713380','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','SYSBNB','4h','0.002390000000000','0.002230000000000','0.529401181138912','0.493960097882751','221.50677035100918','221.506770351009180','test'),('2019-05-31 11:59:59','2019-05-31 15:59:59','SYSBNB','4h','0.002320000000000','0.002170000000000','0.529401181138912','0.495172656496310','228.19016428401378','228.190164284013775','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','SYSBNB','4h','0.002230000000000','0.002160000000000','0.529401181138912','0.512783206843072','237.39963279771837','237.399632797718368','test'),('2019-06-01 11:59:59','2019-06-02 03:59:59','SYSBNB','4h','0.002330000000000','0.002270000000000','0.529401181138912','0.515768532697567','227.2108073557562','227.210807355756202','test'),('2019-06-29 15:59:59','2019-06-30 03:59:59','SYSBNB','4h','0.001520000000000','0.001440000000000','0.529401181138912','0.501537961078969','348.2902507492842','348.290250749284212','test'),('2019-07-18 19:59:59','2019-07-19 03:59:59','SYSBNB','4h','0.001166000000000','0.001160000000000','0.529401181138912','0.526676989812297','454.03188776922127','454.031887769221271','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','SYSBNB','4h','0.001130000000000','0.001094000000000','0.529401181138912','0.512535302801743','468.4966204769133','468.496620476913279','test'),('2019-07-26 03:59:59','2019-07-26 07:59:59','SYSBNB','4h','0.001114000000000','0.001116000000000','0.529401181138912','0.530351632092483','475.2254767853788','475.225476785378817','test'),('2019-08-16 19:59:59','2019-08-17 19:59:59','SYSBNB','4h','0.001018000000000','0.000944000000000','0.529401181138912','0.490918187618009','520.0404529851787','520.040452985178717','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','SYSBNB','4h','0.000950000000000','0.000934000000000','0.529401181138912','0.520484950719730','557.2644011988548','557.264401198854785','test'),('2019-08-20 19:59:59','2019-08-20 23:59:59','SYSBNB','4h','0.000937000000000','0.000926000000000','0.529401181138912','0.523186225970792','564.9959243745059','564.995924374505876','test'),('2019-08-21 07:59:59','2019-08-21 15:59:59','SYSBNB','4h','0.000932000000000','0.000916000000000','0.529401181138912','0.520312748844682','568.0270183893906','568.027018389390605','test'),('2019-08-22 11:59:59','2019-08-23 15:59:59','SYSBNB','4h','0.000962000000000','0.000938000000000','0.529401181138912','0.516193667264345','550.3130781069772','550.313078106977173','test'),('2019-09-03 23:59:59','2019-09-05 19:59:59','SYSBNB','4h','0.001142000000000','0.001106000000000','0.529401181138912','0.512712527442764','463.5737137818844','463.573713781884408','test'),('2019-09-05 23:59:59','2019-09-06 11:59:59','SYSBNB','4h','0.001142000000000','0.001129000000000','0.529401181138912','0.523374722859748','463.5737137818844','463.573713781884408','test'),('2019-09-07 19:59:59','2019-09-08 07:59:59','SYSBNB','4h','0.001144000000000','0.001113000000000','0.529401181138912','0.515055519761896','462.76327022632165','462.763270226321652','test'),('2019-09-08 15:59:59','2019-09-09 03:59:59','SYSBNB','4h','0.001146000000000','0.001126000000000','0.529401181138912','0.520162068030030','461.95565544407674','461.955655444076740','test'),('2019-09-09 11:59:59','2019-09-09 15:59:59','SYSBNB','4h','0.001140000000000','0.001139000000000','0.529401181138912','0.528936794137913','464.3870009990456','464.387000999045597','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:31:30
