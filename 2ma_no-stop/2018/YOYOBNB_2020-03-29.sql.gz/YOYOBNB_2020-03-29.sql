-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 23:59:59','2018-04-29 03:59:59','YOYOBNB','4h','0.008860000000000','0.008740000000000','0.711908500000000','0.702266398419865','80.35084650112867','80.350846501128672','test'),('2018-04-29 15:59:59','2018-05-06 07:59:59','YOYOBNB','4h','0.008890000000000','0.011510000000000','0.711908500000000','0.921717304274466','80.07969628796401','80.079696287964012','test'),('2018-05-07 15:59:59','2018-05-08 15:59:59','YOYOBNB','4h','0.012740000000000','0.012020000000000','0.761950175673583','0.718888627283867','59.80770609682754','59.807706096827538','test'),('2018-05-12 15:59:59','2018-05-12 19:59:59','YOYOBNB','4h','0.012240000000000','0.010910000000000','0.761950175673583','0.679156569983561','62.25083134588097','62.250831345880968','test'),('2018-05-13 19:59:59','2018-05-13 23:59:59','YOYOBNB','4h','0.011340000000000','0.010720000000000','0.761950175673583','0.720291524093546','67.19137351618899','67.191373516188989','test'),('2018-07-02 11:59:59','2018-07-04 00:22:26','YOYOBNB','4h','0.004416000000000','0.004457000000000','0.761950175673583','0.769024441344466','172.54306514347442','172.543065143474422','test'),('2018-07-07 23:59:59','2018-07-09 07:59:59','YOYOBNB','4h','0.004481000000000','0.004799000000000','0.761950175673583','0.816022962074877','170.04020880910133','170.040208809101330','test'),('2018-07-15 23:59:59','2018-07-16 03:59:59','YOYOBNB','4h','0.004413000000000','0.004440000000000','0.761950175673583','0.766612005436372','172.6603615847684','172.660361584768395','test'),('2018-07-17 03:59:59','2018-07-17 07:59:59','YOYOBNB','4h','0.004444000000000','0.004335000000000','0.761950175673583','0.743261478745496','171.45593512006818','171.455935120068176','test'),('2018-07-17 15:59:59','2018-07-20 19:59:59','YOYOBNB','4h','0.004445000000000','0.004417000000000','0.761950175673583','0.757150489527608','171.41736235626163','171.417362356261634','test'),('2018-07-20 23:59:59','2018-07-21 03:59:59','YOYOBNB','4h','0.004710000000000','0.004443000000000','0.761950175673583','0.718756821765972','161.77286107719385','161.772861077193852','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','YOYOBNB','4h','0.004526000000000','0.004477000000000','0.761950175673583','0.753701046506989','168.34957482845405','168.349574828454053','test'),('2018-07-22 07:59:59','2018-07-22 11:59:59','YOYOBNB','4h','0.004555000000000','0.004449000000000','0.761950175673583','0.744218733605219','167.27775536192823','167.277755361928229','test'),('2018-07-23 07:59:59','2018-07-23 11:59:59','YOYOBNB','4h','0.004559000000000','0.004348000000000','0.761950175673583','0.726685537141641','167.1309883030452','167.130988303045200','test'),('2018-08-15 15:59:59','2018-08-15 19:59:59','YOYOBNB','4h','0.002472000000000','0.002255000000000','0.761950175673583','0.695063772711946','308.23227171261453','308.232271712614533','test'),('2018-08-16 07:59:59','2018-08-16 11:59:59','YOYOBNB','4h','0.002408000000000','0.002380000000000','0.761950175673583','0.753090289909937','316.42449155879694','316.424491558796944','test'),('2018-08-17 07:59:59','2018-08-24 07:59:59','YOYOBNB','4h','0.002419000000000','0.002884000000000','0.761950175673583','0.908418481456227','314.9856038336432','314.985603833643211','test'),('2018-09-04 15:59:59','2018-09-04 19:59:59','YOYOBNB','4h','0.002515000000000','0.002462000000000','0.761950175673583','0.745893173959587','302.9622964904903','302.962296490490303','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','YOYOBNB','4h','0.002197000000000','0.002151000000000','0.761950175673583','0.745996735491068','346.81391701118935','346.813917011189346','test'),('2018-10-13 15:59:59','2018-10-14 23:59:59','YOYOBNB','4h','0.003159000000000','0.002967000000000','0.761950175673583','0.715639813619348','241.1998023658066','241.199802365806590','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','YOYOBNB','4h','0.003046000000000','0.003037000000000','0.761950175673583','0.759698845541915','250.14779240761098','250.147792407610979','test'),('2018-10-20 07:59:59','2018-10-27 23:59:59','YOYOBNB','4h','0.003105000000000','0.003359000000000','0.761950175673583','0.824280399384079','245.39458153738582','245.394581537385818','test'),('2018-11-07 23:59:59','2018-11-08 03:59:59','YOYOBNB','4h','0.003760000000000','0.003691000000000','0.761950175673583','0.747967579364680','202.6463233174423','202.646323317442295','test'),('2018-11-10 07:59:59','2018-11-10 11:59:59','YOYOBNB','4h','0.003758000000000','0.003790000000000','0.761950175673583','0.768438309154571','202.75417128088958','202.754171280889580','test'),('2018-11-12 19:59:59','2018-11-12 23:59:59','YOYOBNB','4h','0.003750000000000','0.003622000000000','0.761950175673583','0.735942276343925','203.1867135129555','203.186713512955492','test'),('2018-11-18 19:59:59','2018-11-19 07:59:59','YOYOBNB','4h','0.004330000000000','0.003517000000000','0.761950175673583','0.618886551465125','175.97001747657808','175.970017476578079','test'),('2018-11-20 15:59:59','2018-11-20 19:59:59','YOYOBNB','4h','0.003650000000000','0.003474000000000','0.761950175673583','0.725209564463021','208.75347278728302','208.753472787283016','test'),('2018-11-21 07:59:59','2018-11-21 11:59:59','YOYOBNB','4h','0.003589000000000','0.003418000000000','0.761950175673583','0.725646614781919','212.3015256822466','212.301525682246591','test'),('2018-11-21 15:59:59','2018-11-21 19:59:59','YOYOBNB','4h','0.003473000000000','0.003424000000000','0.761950175673583','0.751199942846631','219.39250667249726','219.392506672497262','test'),('2018-11-28 03:59:59','2018-11-30 11:59:59','YOYOBNB','4h','0.003384000000000','0.003286000000000','0.761950175673583','0.739884242690128','225.16258146382478','225.162581463824779','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','YOYOBNB','4h','0.003411000000000','0.003319000000000','0.761950175673583','0.741399188818711','223.38029190078657','223.380291900786574','test'),('2018-12-01 07:59:59','2018-12-01 11:59:59','YOYOBNB','4h','0.003420000000000','0.003465000000000','0.761950175673583','0.771975835879815','222.79244902736346','222.792449027363460','test'),('2018-12-09 19:59:59','2018-12-09 23:59:59','YOYOBNB','4h','0.003227000000000','0.003122000000000','0.761950175673583','0.737157870608282','236.11719109810446','236.117191098104456','test'),('2018-12-24 03:59:59','2018-12-24 07:59:59','YOYOBNB','4h','0.002727000000000','0.002590000000000','0.761950175673583','0.723671050603073','279.40967204751854','279.409672047518541','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','YOYOBNB','4h','0.002426000000000','0.002440000000000','0.761950175673583','0.766347250059168','314.076741827528','314.076741827527997','test'),('2019-01-15 15:59:59','2019-01-17 07:59:59','YOYOBNB','4h','0.002482000000000','0.002319000000000','0.761950175673583','0.711910740284867','306.99040115776916','306.990401157769156','test'),('2019-01-18 23:59:59','2019-01-19 19:59:59','YOYOBNB','4h','0.002377000000000','0.002262000000000','0.761950175673583','0.725086788966615','320.5511887562402','320.551188756240208','test'),('2019-01-21 15:59:59','2019-01-21 19:59:59','YOYOBNB','4h','0.002346000000000','0.002307000000000','0.761950175673583','0.749283484773639','324.78694615242244','324.786946152422445','test'),('2019-01-22 07:59:59','2019-01-25 07:59:59','YOYOBNB','4h','0.002459000000000','0.002414000000000','0.761950175673583','0.748006394500215','309.86180385261616','309.861803852616163','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','YOYOBNB','4h','0.002436000000000','0.002329000000000','0.761950175673583','0.728481920830778','312.78742843743146','312.787428437431458','test'),('2019-02-17 03:59:59','2019-02-17 15:59:59','YOYOBNB','4h','0.001681000000000','0.001683000000000','0.761950175673583','0.762856719606568','453.2719664923159','453.271966492315926','test'),('2019-02-19 23:59:59','2019-02-20 03:59:59','YOYOBNB','4h','0.001658000000000','0.001549000000000','0.761950175673583','0.711858155680567','459.5598164496882','459.559816449688185','test'),('2019-02-20 15:59:59','2019-02-21 23:59:59','YOYOBNB','4h','0.001900000000000','0.001688000000000','0.761950175673583','0.676932577124741','401.02640824925425','401.026408249254246','test'),('2019-02-22 15:59:59','2019-02-22 19:59:59','YOYOBNB','4h','0.001720000000000','0.001655000000000','0.507966783782389','0.488770364627822','295.32952545487717','295.329525454877171','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','YOYOBNB','4h','0.001677000000000','0.001665000000000','0.554660472338405','0.550691524414695','330.7456603091264','330.745660309126379','test'),('2019-03-15 19:59:59','2019-03-16 11:59:59','YOYOBNB','4h','0.001500000000000','0.001308000000000','0.554660472338405','0.483663931879089','369.7736482256033','369.773648225603324','test'),('2019-03-17 15:59:59','2019-03-18 03:59:59','YOYOBNB','4h','0.001331000000000','0.001319000000000','0.554660472338405','0.549659776870290','416.72462234290384','416.724622342903842','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','YOYOBNB','4h','0.001313000000000','0.001320000000000','0.554660472338405','0.557617535024139','422.4375265334387','422.437526533438700','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','YOYOBNB','4h','0.001321000000000','0.001283000000000','0.554660472338405','0.538705061324885','419.8792371978842','419.879237197884208','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','YOYOBNB','4h','0.001356000000000','0.001231000000000','0.554660472338405','0.503530266554997','409.0416462672603','409.041646267260319','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','YOYOBNB','4h','0.001311000000000','0.001281000000000','0.554660472338405','0.541968013017160','423.08197737483215','423.081977374832150','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','YOYOBNB','4h','0.001298000000000','0.001312000000000','0.554660472338405','0.560642942764243','427.3193161312828','427.319316131282790','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','YOYOBNB','4h','0.001307000000000','0.001289000000000','0.554660472338405','0.547021690010868','424.3767959742961','424.376795974296101','test'),('2019-04-05 03:59:59','2019-04-06 23:59:59','YOYOBNB','4h','0.001318000000000','0.001334000000000','0.554660472338405','0.561393831638416','420.8349562506867','420.834956250686673','test'),('2019-04-13 19:59:59','2019-04-13 23:59:59','YOYOBNB','4h','0.001449000000000','0.001220000000000','0.554660472338405','0.467001915978505','382.78845572008623','382.788455720086233','test'),('2019-04-15 19:59:59','2019-04-16 07:59:59','YOYOBNB','4h','0.001676000000000','0.001286000000000','0.554660472338405','0.425592701328872','330.94300258854713','330.943002588547131','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 13:06:03
