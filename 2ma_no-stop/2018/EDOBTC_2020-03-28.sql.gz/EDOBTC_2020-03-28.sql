-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 11:59:59','2018-07-01 15:59:59','EDOBTC','4h','0.000151400000000','0.000148700000000','0.001467500000000','0.001441329260238','9.692866578599737','9.692866578599737','test'),('2018-07-02 03:59:59','2018-07-03 23:59:59','EDOBTC','4h','0.000159900000000','0.000151800000000','0.001467500000000','0.001393161350844','9.1776110068793','9.177611006879300','test'),('2018-07-04 15:59:59','2018-07-04 23:59:59','EDOBTC','4h','0.000153400000000','0.000153700000000','0.001467500000000','0.001470369947849','9.566492829204694','9.566492829204694','test'),('2018-07-16 07:59:59','2018-07-16 11:59:59','EDOBTC','4h','0.000143700000000','0.000142500000000','0.001467500000000','0.001455245302714','10.212247738343772','10.212247738343772','test'),('2018-08-14 07:59:59','2018-08-14 11:59:59','EDOBTC','4h','0.000106200000000','0.000106300000000','0.001467500000000','0.001468881826742','13.818267419962336','13.818267419962336','test'),('2018-08-17 15:59:59','2018-08-18 19:59:59','EDOBTC','4h','0.000105100000000','0.000105500000000','0.001467500000000','0.001473085156993','13.962892483349192','13.962892483349192','test'),('2018-08-19 07:59:59','2018-08-29 15:59:59','EDOBTC','4h','0.000106600000000','0.000128000000000','0.001467500000000','0.001762101313321','13.76641651031895','13.766416510318949','test'),('2018-09-11 15:59:59','2018-09-11 19:59:59','EDOBTC','4h','0.000123000000000','0.000113100000000','0.001515418539675','0.001393445827945','12.320475932319104','12.320475932319104','test'),('2018-09-15 15:59:59','2018-09-15 23:59:59','EDOBTC','4h','0.000116400000000','0.000114500000000','0.001515418539675','0.001490682326399','13.01905961920103','13.019059619201030','test'),('2018-09-16 23:59:59','2018-09-17 03:59:59','EDOBTC','4h','0.000115400000000','0.000114800000000','0.001515418539675','0.001507539413819','13.131876426993067','13.131876426993067','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','EDOBTC','4h','0.000115400000000','0.000113700000000','0.001515418539675','0.001493094349749','13.131876426993067','13.131876426993067','test'),('2018-09-18 15:59:59','2018-09-18 19:59:59','EDOBTC','4h','0.000116700000000','0.000115000000000','0.001515418539675','0.001493343033956','12.985591599614395','12.985591599614395','test'),('2018-10-11 19:59:59','2018-10-12 03:59:59','EDOBTC','4h','0.000158100000000','0.000155100000000','0.001515418539675','0.001486662969662','9.58519000426945','9.585190004269450','test'),('2018-10-13 11:59:59','2018-10-13 15:59:59','EDOBTC','4h','0.000157500000000','0.000165200000000','0.001515418539675','0.001589505668281','9.621705013809523','9.621705013809523','test'),('2018-10-17 15:59:59','2018-10-17 19:59:59','EDOBTC','4h','0.000156200000000','0.000157700000000','0.001515418539675','0.001529971214512','9.701783224551855','9.701783224551855','test'),('2018-10-30 07:59:59','2018-10-30 11:59:59','EDOBTC','4h','0.000183800000000','0.000181800000000','0.001515418539675','0.001498928675261','8.244932207154516','8.244932207154516','test'),('2018-10-30 19:59:59','2018-10-30 23:59:59','EDOBTC','4h','0.000184300000000','0.000183800000000','0.001515418539675','0.001511307257690','8.222563970021703','8.222563970021703','test'),('2018-10-31 11:59:59','2018-11-05 11:59:59','EDOBTC','4h','0.000185400000000','0.000196100000000','0.001515418539675','0.001602877969958','8.173778531148866','8.173778531148866','test'),('2018-11-13 15:59:59','2018-11-13 19:59:59','EDOBTC','4h','0.000208600000000','0.000208100000000','0.001515418539675','0.001511786184594','7.264710161433365','7.264710161433365','test'),('2018-11-21 07:59:59','2018-11-21 15:59:59','EDOBTC','4h','0.000189200000000','0.000186900000000','0.001515418539675','0.001496996432692','8.009611731897463','8.009611731897463','test'),('2018-11-23 03:59:59','2018-11-23 07:59:59','EDOBTC','4h','0.000186500000000','0.000180400000000','0.001515418539675','0.001465852571353','8.125568577345843','8.125568577345843','test'),('2018-11-24 23:59:59','2018-11-25 03:59:59','EDOBTC','4h','0.000189300000000','0.000183500000000','0.001515418539675','0.001468987332437','8.005380558240887','8.005380558240887','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','EDOBTC','4h','0.000188000000000','0.000197800000000','0.001515418539675','0.001594413761424','8.060736913164893','8.060736913164893','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','EDOBTC','4h','0.000187200000000','0.000184300000000','0.001515418539675','0.001491942504605','8.095184506810897','8.095184506810897','test'),('2018-11-28 23:59:59','2018-11-29 23:59:59','EDOBTC','4h','0.000188900000000','0.000185600000000','0.001515418539675','0.001488944843640','8.022332131683429','8.022332131683429','test'),('2018-12-03 15:59:59','2018-12-03 19:59:59','EDOBTC','4h','0.000188100000000','0.000187700000000','0.001515418539675','0.001512195959048','8.056451566586922','8.056451566586922','test'),('2018-12-06 23:59:59','2018-12-07 03:59:59','EDOBTC','4h','0.000193100000000','0.000188800000000','0.001515418539675','0.001481672813520','7.847843291947177','7.847843291947177','test'),('2018-12-08 03:59:59','2018-12-08 07:59:59','EDOBTC','4h','0.000189900000000','0.000187700000000','0.001515418539675','0.001497862348062','7.980087096761452','7.980087096761452','test'),('2018-12-09 19:59:59','2018-12-11 19:59:59','EDOBTC','4h','0.000190800000000','0.000189700000000','0.001515418539675','0.001506681849981','7.9424451764937105','7.942445176493711','test'),('2018-12-12 15:59:59','2018-12-12 23:59:59','EDOBTC','4h','0.000190900000000','0.000199500000000','0.001515418539675','0.001583687787665','7.938284649947616','7.938284649947616','test'),('2018-12-27 23:59:59','2018-12-28 03:59:59','EDOBTC','4h','0.000213900000000','0.000201700000000','0.001515418539675','0.001428985130680','7.084705655329593','7.084705655329593','test'),('2018-12-29 19:59:59','2018-12-29 23:59:59','EDOBTC','4h','0.000206200000000','0.000206300000000','0.001515418539675','0.001516153466222','7.3492654688409305','7.349265468840930','test'),('2018-12-31 11:59:59','2018-12-31 15:59:59','EDOBTC','4h','0.000206200000000','0.000206500000000','0.001515418539675','0.001517623319316','7.3492654688409305','7.349265468840930','test'),('2019-01-01 15:59:59','2019-01-01 19:59:59','EDOBTC','4h','0.000215000000000','0.000204500000000','0.001515418539675','0.001441409727272','7.048458324069768','7.048458324069768','test'),('2019-01-02 23:59:59','2019-01-05 03:59:59','EDOBTC','4h','0.000210300000000','0.000202900000000','0.001515418539675','0.001462094254399','7.2059844967902995','7.205984496790300','test'),('2019-01-05 15:59:59','2019-01-13 19:59:59','EDOBTC','4h','0.000216600000000','0.000218700000000','0.001515418539675','0.001530110963190','6.996392149930747','6.996392149930747','test'),('2019-01-16 03:59:59','2019-01-16 07:59:59','EDOBTC','4h','0.000221800000000','0.000219400000000','0.001515418539675','0.001499020863862','6.832364921889089','6.832364921889089','test'),('2019-01-16 11:59:59','2019-01-16 15:59:59','EDOBTC','4h','0.000221600000000','0.000221400000000','0.001515418539675','0.001514050833412','6.838531316222924','6.838531316222924','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','EDOBTC','4h','0.000195900000000','0.000194700000000','0.001515418539675','0.001506135730856','7.735674015696784','7.735674015696784','test'),('2019-02-08 11:59:59','2019-02-08 19:59:59','EDOBTC','4h','0.000196600000000','0.000194900000000','0.001515418539675','0.001502314717104','7.7081309240844345','7.708130924084434','test'),('2019-02-10 15:59:59','2019-02-10 19:59:59','EDOBTC','4h','0.000196400000000','0.000191200000000','0.001515418539675','0.001475295441883','7.7159803445773925','7.715980344577392','test'),('2019-02-11 15:59:59','2019-02-11 23:59:59','EDOBTC','4h','0.000196500000000','0.000194700000000','0.001515418539675','0.001501536843128','7.7120536370229','7.712053637022900','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','EDOBTC','4h','0.000196000000000','0.000194000000000','0.001515418539675','0.001499955085189','7.731727243239796','7.731727243239796','test'),('2019-02-15 15:59:59','2019-02-15 23:59:59','EDOBTC','4h','0.000197400000000','0.000197400000000','0.001515418539675','0.001515418539675','7.676892298252279','7.676892298252279','test'),('2019-02-20 15:59:59','2019-02-20 19:59:59','EDOBTC','4h','0.000199900000000','0.000199600000000','0.001515418539675','0.001513144274733','7.580883139944972','7.580883139944972','test'),('2019-02-22 11:59:59','2019-02-23 19:59:59','EDOBTC','4h','0.000201900000000','0.000198800000000','0.001515418539675','0.001492150597758','7.505787715081723','7.505787715081723','test'),('2019-02-26 07:59:59','2019-02-26 11:59:59','EDOBTC','4h','0.000200000000000','0.000200000000000','0.001515418539675','0.001515418539675','7.577092698374999','7.577092698374999','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','EDOBTC','4h','0.000200900000000','0.000201000000000','0.001515418539675','0.001516172854528','7.543148529990044','7.543148529990044','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','EDOBTC','4h','0.000200200000000','0.000201100000000','0.001515418539675','0.001522231110533','7.569523175199801','7.569523175199801','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','EDOBTC','4h','0.000201400000000','0.000200500000000','0.001515418539675','0.001508646560103','7.524421746151937','7.524421746151937','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','EDOBTC','4h','0.000202200000000','0.000202000000000','0.001515418539675','0.001513919609369','7.49465153152819','7.494651531528190','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','EDOBTC','4h','0.000202000000000','0.000200700000000','0.001515418539675','0.001505665846103','7.502071978589108','7.502071978589108','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','EDOBTC','4h','0.000202400000000','0.000200600000000','0.001515418539675','0.001501941497326','7.487245749382411','7.487245749382411','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','EDOBTC','4h','0.000202400000000','0.000203000000000','0.001515418539675','0.001519910887125','7.487245749382411','7.487245749382411','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','EDOBTC','4h','0.000130500000000','0.000127700000000','0.001515418539675','0.001482903812387','11.612402602873562','11.612402602873562','test'),('2019-04-19 23:59:59','2019-04-20 07:59:59','EDOBTC','4h','0.000132800000000','0.000130400000000','0.001515418539675','0.001488031457633','11.411284184299697','11.411284184299697','test'),('2019-05-06 07:59:59','2019-05-06 15:59:59','EDOBTC','4h','0.000105500000000','0.000104100000000','0.001515418539675','0.001495308720191','14.364156774170615','14.364156774170615','test'),('2019-05-17 15:59:59','2019-05-18 03:59:59','EDOBTC','4h','0.000089000000000','0.000088200000000','0.001515418539675','0.001501796799993','17.02717460308989','17.027174603089890','test'),('2019-05-20 03:59:59','2019-05-20 23:59:59','EDOBTC','4h','0.000090800000000','0.000087400000000','0.001515418539675','0.001458673792595','16.689631494218062','16.689631494218062','test'),('2019-06-03 11:59:59','2019-06-03 19:59:59','EDOBTC','4h','0.000106800000000','0.000102000000000','0.001515418539675','0.001447309841263','14.189312169241573','14.189312169241573','test'),('2019-06-07 23:59:59','2019-06-11 23:59:59','EDOBTC','4h','0.000101000000000','0.000108900000000','0.001515418539675','0.001633951276937','15.004143957178217','15.004143957178217','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:08:22
