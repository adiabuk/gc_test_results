-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-17 11:59:59','2018-03-17 15:59:59','FUNETH','4h','0.000065890000000','0.000061520000000','0.072144500000000','0.067359684929428','1094.9233571103355','1094.923357110335473','test'),('2018-03-18 07:59:59','2018-03-18 11:59:59','FUNETH','4h','0.000064670000000','0.000063610000000','0.072144500000000','0.070961986160507','1115.5790938611412','1115.579093861141246','test'),('2018-03-18 23:59:59','2018-03-30 23:59:59','FUNETH','4h','0.000066420000000','0.000077530000000','0.072144500000000','0.084212030788919','1086.1863896416742','1086.186389641674168','test'),('2018-04-01 19:59:59','2018-04-01 23:59:59','FUNETH','4h','0.000077710000000','0.000078210000000','0.073669550469714','0.074143553496800','948.006054172095','948.006054172094991','test'),('2018-04-05 07:59:59','2018-04-05 11:59:59','FUNETH','4h','0.000078780000000','0.000079070000000','0.073788051226485','0.074059675177433','936.634313613671','936.634313613670997','test'),('2018-04-06 19:59:59','2018-04-06 23:59:59','FUNETH','4h','0.000078400000000','0.000078800000000','0.073855957214222','0.074232773322458','942.0402705895664','942.040270589566376','test'),('2018-04-11 23:59:59','2018-04-12 03:59:59','FUNETH','4h','0.000077580000000','0.000077630000000','0.073950161241281','0.073997821824705','953.2116684877676','953.211668487767611','test'),('2018-04-13 19:59:59','2018-04-13 23:59:59','FUNETH','4h','0.000078770000000','0.000075810000000','0.073962076387137','0.071182747377286','938.9625033278786','938.962503327878608','test'),('2018-04-30 19:59:59','2018-04-30 23:59:59','FUNETH','4h','0.000073550000000','0.000071760000000','0.073962076387137','0.072162047607627','1005.6026701174304','1005.602670117430421','test'),('2018-05-02 11:59:59','2018-05-02 15:59:59','FUNETH','4h','0.000072810000000','0.000072330000000','0.073962076387137','0.073474481322368','1015.8230516019365','1015.823051601936527','test'),('2018-05-07 07:59:59','2018-05-09 15:59:59','FUNETH','4h','0.000078140000000','0.000072200000000','0.073962076387137','0.068339671297048','946.5328434494114','946.532843449411416','test'),('2018-05-17 19:59:59','2018-05-18 07:59:59','FUNETH','4h','0.000073160000000','0.000068310000000','0.073962076387137','0.069058904292036','1010.9633185775972','1010.963318577597192','test'),('2018-05-19 07:59:59','2018-05-19 15:59:59','FUNETH','4h','0.000070000000000','0.000067810000000','0.073962076387137','0.071648119997311','1056.6010912448144','1056.601091244814370','test'),('2018-05-20 15:59:59','2018-05-20 19:59:59','FUNETH','4h','0.000067870000000','0.000068150000000','0.073962076387137','0.074267209456069','1089.7609604705615','1089.760960470561486','test'),('2018-06-21 23:59:59','2018-06-23 07:59:59','FUNETH','4h','0.000056420000000','0.000050800000000','0.073962076387137','0.066594708976720','1310.9194680456753','1310.919468045675330','test'),('2018-06-23 23:59:59','2018-06-24 07:59:59','FUNETH','4h','0.000052000000000','0.000051400000000','0.073962076387137','0.073108667813439','1422.3476228295578','1422.347622829557849','test'),('2018-07-17 23:59:59','2018-07-20 15:59:59','FUNETH','4h','0.000058700000000','0.000056860000000','0.073962076387137','0.071643673992719','1260.0013013140888','1260.001301314088778','test'),('2018-07-25 11:59:59','2018-07-26 07:59:59','FUNETH','4h','0.000057820000000','0.000056200000000','0.073962076387137','0.071889807903098','1279.178076567572','1279.178076567571907','test'),('2018-07-28 11:59:59','2018-07-28 15:59:59','FUNETH','4h','0.000056700000000','0.000055920000000','0.073962076387137','0.072944608669642','1304.4457916602646','1304.445791660264604','test'),('2018-08-09 19:59:59','2018-08-10 07:59:59','FUNETH','4h','0.000053970000000','0.000053630000000','0.073962076387137','0.073496130380622','1370.4294309271263','1370.429430927126305','test'),('2018-08-10 15:59:59','2018-08-10 19:59:59','FUNETH','4h','0.000053430000000','0.000053070000000','0.073962076387137','0.073463735614175','1384.2799248949466','1384.279924894946589','test'),('2018-08-10 23:59:59','2018-08-11 03:59:59','FUNETH','4h','0.000053720000000','0.000053500000000','0.073962076387137','0.073659178829334','1376.8070809221333','1376.807080922133309','test'),('2018-08-14 19:59:59','2018-08-14 23:59:59','FUNETH','4h','0.000054770000000','0.000054850000000','0.073962076387137','0.074070109363419','1350.4122035263283','1350.412203526328312','test'),('2018-08-24 23:59:59','2018-08-25 03:59:59','FUNETH','4h','0.000061970000000','0.000060500000000','0.073962076387137','0.072207610479616','1193.5142228035663','1193.514222803566327','test'),('2018-08-25 15:59:59','2018-08-25 19:59:59','FUNETH','4h','0.000062620000000','0.000061270000000','0.073962076387137','0.072367557014371','1181.12546130848','1181.125461308479998','test'),('2018-08-26 19:59:59','2018-08-27 07:59:59','FUNETH','4h','0.000061860000000','0.000061920000000','0.073962076387137','0.074033814579559','1195.6365403675559','1195.636540367555881','test'),('2018-08-31 11:59:59','2018-08-31 15:59:59','FUNETH','4h','0.000062430000000','0.000062130000000','0.073962076387137','0.073606660354522','1184.720108715954','1184.720108715953984','test'),('2018-09-01 07:59:59','2018-09-01 11:59:59','FUNETH','4h','0.000062500000000','0.000062680000000','0.073962076387137','0.074175087167132','1183.393222194192','1183.393222194192049','test'),('2018-09-02 19:59:59','2018-09-02 23:59:59','FUNETH','4h','0.000062350000000','0.000061670000000','0.073962076387137','0.073155433052041','1186.2401986710024','1186.240198671002418','test'),('2018-09-03 03:59:59','2018-09-03 07:59:59','FUNETH','4h','0.000062800000000','0.000062520000000','0.073962076387137','0.073632309167577','1177.7400698588697','1177.740069858869674','test'),('2018-09-14 11:59:59','2018-09-14 15:59:59','FUNETH','4h','0.000068320000000','0.000068690000000','0.073962076387137','0.074362632128695','1082.583085291818','1082.583085291817952','test'),('2018-09-16 15:59:59','2018-09-16 19:59:59','FUNETH','4h','0.000068630000000','0.000068560000000','0.073962076387137','0.073886637871224','1077.6930844694305','1077.693084469430460','test'),('2018-09-24 03:59:59','2018-09-24 11:59:59','FUNETH','4h','0.000074110000000','0.000074300000000','0.073962076387137','0.074151697147001','998.0039992866956','998.003999286695603','test'),('2018-09-25 07:59:59','2018-09-25 23:59:59','FUNETH','4h','0.000074940000000','0.000073790000000','0.073962076387137','0.072827083221335','986.9505789583268','986.950578958326787','test'),('2018-10-02 07:59:59','2018-10-02 11:59:59','FUNETH','4h','0.000074850000000','0.000071030000000','0.073962076387137','0.070187391927566','988.1372930813227','988.137293081322696','test'),('2018-10-10 23:59:59','2018-10-11 03:59:59','FUNETH','4h','0.000071120000000','0.000072500000000','0.073962076387137','0.075397223538631','1039.9617039811164','1039.961703981116443','test'),('2018-10-11 23:59:59','2018-10-12 03:59:59','FUNETH','4h','0.000071930000000','0.000071750000000','0.073962076387137','0.073776991252288','1028.2507491608092','1028.250749160809164','test'),('2018-10-17 11:59:59','2018-10-17 15:59:59','FUNETH','4h','0.000072050000000','0.000069880000000','0.073962076387137','0.071734488520932','1026.5381871913532','1026.538187191353245','test'),('2018-10-17 23:59:59','2018-10-18 03:59:59','FUNETH','4h','0.000070990000000','0.000071350000000','0.073962076387137','0.074337148193016','1041.8661274424146','1041.866127442414609','test'),('2018-10-21 23:59:59','2018-10-22 03:59:59','FUNETH','4h','0.000071720000000','0.000069410000000','0.073962076387137','0.071579862270373','1031.2615224084914','1031.261522408491373','test'),('2018-10-26 11:59:59','2018-10-26 15:59:59','FUNETH','4h','0.000070990000000','0.000069360000000','0.073962076387137','0.072263834599406','1041.8661274424146','1041.866127442414609','test'),('2018-10-28 19:59:59','2018-10-28 23:59:59','FUNETH','4h','0.000071530000000','0.000070160000000','0.073962076387137','0.072545495307165','1034.0007883005312','1034.000788300531212','test'),('2018-11-04 03:59:59','2018-11-04 07:59:59','FUNETH','4h','0.000071430000000','0.000070570000000','0.073962076387137','0.073071590797148','1035.448360452709','1035.448360452709039','test'),('2018-11-28 19:59:59','2018-11-30 11:59:59','FUNETH','4h','0.000053070000000','0.000043820000000','0.073962076387137','0.061070627233547','1393.6701787664783','1393.670178766478330','test'),('2018-12-06 07:59:59','2018-12-06 11:59:59','FUNETH','4h','0.000045080000000','0.000046200000000','0.073962076387137','0.075799643502345','1640.6849242931899','1640.684924293189852','test'),('2018-12-06 23:59:59','2018-12-07 03:59:59','FUNETH','4h','0.000045220000000','0.000044710000000','0.073962076387137','0.073127917630891','1635.6054044037376','1635.605404403737566','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','FUNETH','4h','0.000044810000000','0.000044610000000','0.073962076387137','0.073631962232318','1650.5707740936623','1650.570774093662294','test'),('2018-12-09 11:59:59','2018-12-11 03:59:59','FUNETH','4h','0.000045940000000','0.000045260000000','0.073962076387137','0.072867295979143','1609.9711882267525','1609.971188226752474','test'),('2018-12-19 19:59:59','2018-12-19 23:59:59','FUNETH','4h','0.000043820000000','0.000043480000000','0.073962076387137','0.073388203589975','1687.8611681227067','1687.861168122706658','test'),('2019-01-09 23:59:59','2019-01-10 03:59:59','FUNETH','4h','0.000031230000000','0.000031080000000','0.073962076387137','0.073606831063472','2368.3021577693567','2368.302157769356654','test'),('2019-02-03 19:59:59','2019-02-04 11:59:59','FUNETH','4h','0.000037480000000','0.000035810000000','0.073962076387137','0.070666540966472','1973.3745033921293','1973.374503392129327','test'),('2019-02-04 23:59:59','2019-02-05 03:59:59','FUNETH','4h','0.000036610000000','0.000036370000000','0.073962076387137','0.073477211641633','2020.2697729346357','2020.269772934635739','test'),('2019-02-06 03:59:59','2019-02-06 15:59:59','FUNETH','4h','0.000037480000000','0.000036420000000','0.073962076387137','0.071870299413541','1973.3745033921293','1973.374503392129327','test'),('2019-02-27 03:59:59','2019-02-27 07:59:59','FUNETH','4h','0.000028130000000','0.000027620000000','0.073962076387137','0.072621135791423','2629.2952857140776','2629.295285714077636','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','FUNETH','4h','0.000028460000000','0.000027800000000','0.073962076387137','0.072246863090738','2598.808024846697','2598.808024846697208','test'),('2019-03-01 15:59:59','2019-03-01 19:59:59','FUNETH','4h','0.000028100000000','0.000027820000000','0.073962076387137','0.073225087725628','2632.102362531566','2632.102362531566087','test'),('2019-03-01 23:59:59','2019-03-02 07:59:59','FUNETH','4h','0.000028090000000','0.000028500000000','0.073962076387137','0.075041622535899','2633.0393872245286','2633.039387224528582','test'),('2019-03-08 23:59:59','2019-03-09 03:59:59','FUNETH','4h','0.000029280000000','0.000029130000000','0.073962076387137','0.073583172307285','2526.027199014242','2526.027199014241887','test'),('2019-03-09 19:59:59','2019-03-15 03:59:59','FUNETH','4h','0.000029510000000','0.000033980000000','0.073962076387137','0.085165413610129','2506.3394234882076','2506.339423488207558','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:59:13
