-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 07:59:59','2018-06-30 11:59:59','APPCETH','4h','0.000384600000000','0.000376000000000','0.072144500000000','0.070531284451378','187.58320332813312','187.583203328133123','test'),('2018-06-30 15:59:59','2018-07-01 03:59:59','APPCETH','4h','0.000393100000000','0.000394000000000','0.072144500000000','0.072309674383109','183.5270923429153','183.527092342915296','test'),('2018-07-01 19:59:59','2018-07-07 11:59:59','APPCETH','4h','0.000384000000000','0.000419000000000','0.072144500000000','0.078720170572917','187.87630208333334','187.876302083333343','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','APPCETH','4h','0.000428400000000','0.000415300000000','0.073426407351851','0.071181108714341','171.39684255800884','171.396842558008842','test'),('2018-07-08 15:59:59','2018-07-08 23:59:59','APPCETH','4h','0.000468300000000','0.000442900000000','0.073426407351851','0.069443851838853','156.7935241337839','156.793524133783905','test'),('2018-07-13 15:59:59','2018-07-13 23:59:59','APPCETH','4h','0.000441900000000','0.000431000000000','0.073426407351851','0.071615255869309','166.16068647171534','166.160686471715337','test'),('2018-07-16 15:59:59','2018-07-16 19:59:59','APPCETH','4h','0.000441600000000','0.000429700000000','0.073426407351851','0.071447751900114','166.273567372851','166.273567372851005','test'),('2018-07-16 23:59:59','2018-07-17 03:59:59','APPCETH','4h','0.000435600000000','0.000432800000000','0.073426407351851','0.072954428608543','168.56383689589302','168.563836895893019','test'),('2018-07-17 15:59:59','2018-07-19 15:59:59','APPCETH','4h','0.000452000000000','0.000443600000000','0.073426407351851','0.072061845799294','162.44780387577657','162.447803875776572','test'),('2018-07-29 23:59:59','2018-07-30 03:59:59','APPCETH','4h','0.000403100000000','0.000390700000000','0.073426407351851','0.071167693754324','182.15432238117342','182.154322381173415','test'),('2018-08-17 19:59:59','2018-08-18 07:59:59','APPCETH','4h','0.000292600000000','0.000277200000000','0.073426407351851','0.069561859596490','250.94465943899866','250.944659438998656','test'),('2018-08-19 15:59:59','2018-08-20 23:59:59','APPCETH','4h','0.000289900000000','0.000285500000000','0.073426407351851','0.072311967226469','253.28184667765095','253.281846677650947','test'),('2018-09-06 19:59:59','2018-09-06 23:59:59','APPCETH','4h','0.000353200000000','0.000350600000000','0.073426407351851','0.072885895859453','207.889035537517','207.889035537517003','test'),('2018-09-09 03:59:59','2018-09-09 07:59:59','APPCETH','4h','0.000351000000000','0.000348900000000','0.073426407351851','0.072987104060002','209.19204373746723','209.192043737467230','test'),('2018-09-15 03:59:59','2018-09-15 07:59:59','APPCETH','4h','0.000364800000000','0.000367400000000','0.073426407351851','0.073949731527056','201.27852892503017','201.278528925030173','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','APPCETH','4h','0.000369300000000','0.000359000000000','0.073426407351851','0.071378500512631','198.82590672041974','198.825906720419738','test'),('2018-09-22 19:59:59','2018-09-22 23:59:59','APPCETH','4h','0.000415000000000','0.000497900000000','0.073426407351851','0.088093995712016','176.93110205265302','176.931102052653017','test'),('2018-10-08 23:59:59','2018-10-09 03:59:59','APPCETH','4h','0.000494200000000','0.000487800000000','0.073426407351851','0.072475519033252','148.57629978116353','148.576299781163527','test'),('2018-10-14 03:59:59','2018-10-14 07:59:59','APPCETH','4h','0.000483000000000','0.000492000000000','0.073426407351851','0.074794601277662','152.02154731232093','152.021547312320934','test'),('2018-10-15 15:59:59','2018-10-18 15:59:59','APPCETH','4h','0.000499700000000','0.000496200000000','0.073426407351851','0.072912113924332','146.9409792912768','146.940979291276790','test'),('2018-10-27 11:59:59','2018-10-27 15:59:59','APPCETH','4h','0.000547900000000','0.000530400000000','0.073426407351851','0.071081157983978','134.01424959271947','134.014249592719466','test'),('2018-11-27 15:59:59','2018-11-27 19:59:59','APPCETH','4h','0.000416800000000','0.000393400000000','0.073426407351851','0.069304099453499','176.16700420309743','176.167004203097434','test'),('2018-11-28 11:59:59','2018-11-28 15:59:59','APPCETH','4h','0.000413700000000','0.000418300000000','0.073426407351851','0.074242847946046','177.48708569458788','177.487085694587876','test'),('2018-12-07 11:59:59','2018-12-07 15:59:59','APPCETH','4h','0.000439800000000','0.000440400000000','0.073426407351851','0.073526579803900','166.95408674818327','166.954086748183272','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','APPCETH','4h','0.000439200000000','0.000428900000000','0.073426407351851','0.071704431041004','167.1821661016644','167.182166101664393','test'),('2018-12-09 07:59:59','2018-12-09 11:59:59','APPCETH','4h','0.000435200000000','0.000438900000000','0.073426407351851','0.074050666789355','168.71876689304','168.718766893039998','test'),('2018-12-09 23:59:59','2018-12-10 03:59:59','APPCETH','4h','0.000438000000000','0.000437900000000','0.073426407351851','0.073409643331908','167.64019943344977','167.640199433449766','test'),('2018-12-12 23:59:59','2018-12-13 07:59:59','APPCETH','4h','0.000436100000000','0.000429800000000','0.073426407351851','0.072365672735211','168.37057406982575','168.370574069825750','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','APPCETH','4h','0.000426200000000','0.000414600000000','0.073426407351851','0.071427941079487','172.28157520377994','172.281575203779937','test'),('2018-12-19 07:59:59','2018-12-19 19:59:59','APPCETH','4h','0.000428700000000','0.000426900000000','0.073426407351851','0.073118108930500','171.27690075076046','171.276900750760461','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','APPCETH','4h','0.000425600000000','0.000405500000000','0.073426407351851','0.069958665839228','172.52445336431157','172.524453364311569','test'),('2019-01-06 07:59:59','2019-01-06 11:59:59','APPCETH','4h','0.000330400000000','0.000331700000000','0.073426407351851','0.073715312707654','222.2348890794522','222.234889079452188','test'),('2019-01-07 11:59:59','2019-01-07 15:59:59','APPCETH','4h','0.000320200000000','0.000316700000000','0.073426407351851','0.072623807646256','229.31420159853533','229.314201598535334','test'),('2019-01-07 23:59:59','2019-01-08 03:59:59','APPCETH','4h','0.000317600000000','0.000310200000000','0.073426407351851','0.071715590555870','231.19145891640744','231.191458916407441','test'),('2019-01-09 11:59:59','2019-01-09 15:59:59','APPCETH','4h','0.000317700000000','0.000310000000000','0.073426407351851','0.071646793450028','231.11868854847654','231.118688548476541','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','APPCETH','4h','0.000318700000000','0.000314900000000','0.073426407351851','0.072550912064945','230.39349655428617','230.393496554286173','test'),('2019-02-01 15:59:59','2019-02-01 23:59:59','APPCETH','4h','0.000401000000000','0.000390600000000','0.073426407351851','0.071522081575145','183.10824776022696','183.108247760226959','test'),('2019-02-11 15:59:59','2019-02-18 03:59:59','APPCETH','4h','0.000407400000000','0.000457400000000','0.073426407351851','0.082437993919334','180.23173134965884','180.231731349658844','test'),('2019-02-26 15:59:59','2019-02-27 19:59:59','APPCETH','4h','0.000433500000000','0.000418900000000','0.073426407351851','0.070953453378755','169.38040911614993','169.380409116149934','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','APPCETH','4h','0.000408000000000','0.000409800000000','0.073426407351851','0.073750347384286','179.96668468590934','179.966684685909343','test'),('2019-03-12 11:59:59','2019-03-13 11:59:59','APPCETH','4h','0.000567600000000','0.000557900000000','0.073426407351851','0.072171586789284','129.36294459452256','129.362944594522560','test'),('2019-03-13 19:59:59','2019-03-13 23:59:59','APPCETH','4h','0.000556000000000','0.000558300000000','0.073426407351851','0.073730149684422','132.06188372635074','132.061883726350743','test'),('2019-03-18 15:59:59','2019-03-20 03:59:59','APPCETH','4h','0.000583800000000','0.000556000000000','0.073426407351851','0.069929911763668','125.7732225965245','125.773222596524505','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','APPCETH','4h','0.000598900000000','0.000558800000000','0.073426407351851','0.068510062494931','122.60211613266156','122.602116132661564','test'),('2019-04-27 19:59:59','2019-04-27 23:59:59','APPCETH','4h','0.000441000000000','0.000424000000000','0.073426407351851','0.070595910923322','166.49978991349434','166.499789913494340','test'),('2019-04-28 11:59:59','2019-04-28 15:59:59','APPCETH','4h','0.000433600000000','0.000427000000000','0.073426407351851','0.072308754472418','169.34134536866006','169.341345368660058','test'),('2019-05-06 11:59:59','2019-05-06 15:59:59','APPCETH','4h','0.000437300000000','0.000406800000000','0.073426407351851','0.068305196685875','167.90854642545392','167.908546425453920','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','APPCETH','4h','0.000333300000000','0.000323200000000','0.073426407351851','0.071201364704825','220.3012521807711','220.301252180771087','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','APPCETH','4h','0.000356700000000','0.000344400000000','0.073426407351851','0.070894462270753','205.8491935852285','205.849193585228505','test'),('2019-05-28 03:59:59','2019-05-28 07:59:59','APPCETH','4h','0.000365200000000','0.000361200000000','0.073426407351851','0.072622175069793','201.05807051437844','201.058070514378443','test'),('2019-05-29 07:59:59','2019-05-30 03:59:59','APPCETH','4h','0.000358400000000','0.000349800000000','0.073426407351851','0.071664501371868','204.87278837012','204.872788370119991','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','APPCETH','4h','0.000362100000000','0.000345400000000','0.073426407351851','0.070039991989311','202.7793630263767','202.779363026376700','test'),('2019-05-30 23:59:59','2019-05-31 03:59:59','APPCETH','4h','0.000359400000000','0.000355000000000','0.073426407351851','0.072527475264071','204.30274722273512','204.302747222735121','test'),('2019-05-31 07:59:59','2019-05-31 11:59:59','APPCETH','4h','0.000358000000000','0.000364400000000','0.073426407351851','0.074739058209538','205.1016965135503','205.101696513550309','test'),('2019-06-01 19:59:59','2019-06-03 23:59:59','APPCETH','4h','0.000367100000000','0.000366800000000','0.073426407351851','0.073366402115660','200.01745396853994','200.017453968539940','test'),('2019-06-04 11:59:59','2019-06-04 19:59:59','APPCETH','4h','0.000382100000000','0.000363700000000','0.073426407351851','0.069890563606041','192.16542096794296','192.165420967942964','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','APPCETH','4h','0.000370000000000','0.000365800000000','0.073426407351851','0.072592918403533','198.4497495995973','198.449749599597311','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','APPCETH','4h','0.000366100000000','0.000358000000000','0.073426407351851','0.071801840568049','200.56380046941','200.563800469410012','test'),('2019-06-07 07:59:59','2019-06-12 15:59:59','APPCETH','4h','0.000372900000000','0.000389800000000','0.073426407351851','0.076754126000943','196.90642894033522','196.906428940335218','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','APPCETH','4h','0.000384700000000','0.000383800000000','0.073426407351851','0.073254627350248','190.8666684477541','190.866668447754108','test'),('2019-06-19 15:59:59','2019-06-19 19:59:59','APPCETH','4h','0.000368500000000','0.000378600000000','0.073426407351851','0.075438908611698','199.25755047992132','199.257550479921321','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:23:16
