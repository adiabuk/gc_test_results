-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 15:59:59','2018-07-10 07:59:59','RLCBNB','4h','0.055980000000000','0.054890000000000','0.711908500000000','0.698046758931761','12.717193640585924','12.717193640585924','test'),('2018-07-11 07:59:59','2018-07-12 03:59:59','RLCBNB','4h','0.060550000000000','0.057270000000000','0.711908500000000','0.673344340132122','11.757365813377374','11.757365813377374','test'),('2018-07-14 03:59:59','2018-07-14 07:59:59','RLCBNB','4h','0.057570000000000','0.056430000000000','0.711908500000000','0.697811301980198','12.365963175264895','12.365963175264895','test'),('2018-07-15 15:59:59','2018-07-15 19:59:59','RLCBNB','4h','0.056700000000000','0.056170000000000','0.711908500000000','0.705253976102293','12.555705467372135','12.555705467372135','test'),('2018-07-15 23:59:59','2018-07-16 03:59:59','RLCBNB','4h','0.057080000000000','0.056380000000000','0.711908500000000','0.703178017344079','12.472118079887878','12.472118079887878','test'),('2018-07-16 15:59:59','2018-07-17 15:59:59','RLCBNB','4h','0.056990000000000','0.057120000000000','0.711908500000000','0.713532435865941','12.491814353395334','12.491814353395334','test'),('2018-07-21 07:59:59','2018-07-21 15:59:59','RLCBNB','4h','0.059550000000000','0.059540000000000','0.711908500000000','0.711788951973132','11.954802686817802','11.954802686817802','test'),('2018-07-21 23:59:59','2018-07-22 07:59:59','RLCBNB','4h','0.060370000000000','0.058590000000000','0.711908500000000','0.690917989315886','11.792421732648668','11.792421732648668','test'),('2018-07-22 15:59:59','2018-07-22 19:59:59','RLCBNB','4h','0.060370000000000','0.057600000000000','0.711908500000000','0.679243491800563','11.792421732648668','11.792421732648668','test'),('2018-07-22 23:59:59','2018-07-23 07:59:59','RLCBNB','4h','0.059840000000000','0.058820000000000','0.711908500000000','0.699773696022727','11.896866644385028','11.896866644385028','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','RLCBNB','4h','0.033940000000000','0.030290000000000','0.711908500000000','0.635347921773718','20.97550088391279','20.975500883912790','test'),('2018-08-17 15:59:59','2018-08-18 03:59:59','RLCBNB','4h','0.034750000000000','0.033070000000000','0.711908500000000','0.677491053093525','20.486575539568346','20.486575539568346','test'),('2018-08-31 15:59:59','2018-09-01 03:59:59','RLCBNB','4h','0.039790000000000','0.037450000000000','0.711908500000000','0.670042053908017','17.891643629052528','17.891643629052528','test'),('2018-09-01 23:59:59','2018-09-02 03:59:59','RLCBNB','4h','0.038640000000000','0.037990000000000','0.711908500000000','0.699932813535197','18.424133022774328','18.424133022774328','test'),('2018-09-04 19:59:59','2018-09-04 23:59:59','RLCBNB','4h','0.038440000000000','0.037210000000000','0.711908500000000','0.689128909599376','18.519992195629552','18.519992195629552','test'),('2018-09-07 07:59:59','2018-09-07 15:59:59','RLCBNB','4h','0.040970000000000','0.038280000000000','0.711908500000000','0.665166155235538','17.3763363436661','17.376336343666100','test'),('2018-09-14 03:59:59','2018-09-14 11:59:59','RLCBNB','4h','0.037480000000000','0.035800000000000','0.711908500000000','0.679997980256137','18.99435699039488','18.994356990394881','test'),('2018-09-16 23:59:59','2018-09-17 15:59:59','RLCBNB','4h','0.037350000000000','0.036070000000000','0.711908500000000','0.687511100267738','19.060468540829987','19.060468540829987','test'),('2018-09-22 19:59:59','2018-09-24 23:59:59','RLCBNB','4h','0.039110000000000','0.037430000000000','0.711908500000000','0.681327925210944','18.202723088724113','18.202723088724113','test'),('2018-09-26 19:59:59','2018-10-02 23:59:59','RLCBNB','4h','0.038700000000000','0.038390000000000','0.711908500000000','0.706205873772610','18.395568475452198','18.395568475452198','test'),('2018-10-04 07:59:59','2018-10-04 11:59:59','RLCBNB','4h','0.038880000000000','0.039940000000000','0.711908500000000','0.731317528034980','18.310403806584365','18.310403806584365','test'),('2018-10-05 03:59:59','2018-10-05 07:59:59','RLCBNB','4h','0.039480000000000','0.038230000000000','0.711908500000000','0.689368337259372','18.032130192502535','18.032130192502535','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','RLCBNB','4h','0.039130000000000','0.038420000000000','0.711908500000000','0.698991172246358','18.19341937132635','18.193419371326350','test'),('2018-10-07 15:59:59','2018-10-07 19:59:59','RLCBNB','4h','0.038720000000000','0.037950000000000','0.711908500000000','0.697751228693182','18.386066632231408','18.386066632231408','test'),('2018-10-08 07:59:59','2018-10-11 03:59:59','RLCBNB','4h','0.039120000000000','0.038670000000000','0.711908500000000','0.703719368481595','18.198070040899797','18.198070040899797','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','RLCBNB','4h','0.040110000000000','0.038900000000000','0.711908500000000','0.690432327349788','17.748903016704066','17.748903016704066','test'),('2018-10-12 19:59:59','2018-10-15 07:59:59','RLCBNB','4h','0.040440000000000','0.040190000000000','0.711908500000000','0.707507483061325','17.60406775469832','17.604067754698320','test'),('2018-10-15 15:59:59','2018-10-15 23:59:59','RLCBNB','4h','0.041750000000000','0.040210000000000','0.711908500000000','0.685648881077844','17.051700598802395','17.051700598802395','test'),('2018-10-16 07:59:59','2018-10-27 11:59:59','RLCBNB','4h','0.041760000000000','0.049920000000000','0.711908500000000','0.851017057471264','17.047617337164752','17.047617337164752','test'),('2018-10-28 15:59:59','2018-10-29 03:59:59','RLCBNB','4h','0.048750000000000','0.047750000000000','0.711908500000000','0.697305248717949','14.603251282051282','14.603251282051282','test'),('2018-11-01 07:59:59','2018-11-03 07:59:59','RLCBNB','4h','0.048230000000000','0.046890000000000','0.711908500000000','0.692129163694796','14.760698735227038','14.760698735227038','test'),('2018-11-03 11:59:59','2018-11-03 15:59:59','RLCBNB','4h','0.048650000000000','0.046940000000000','0.711908500000000','0.686885611305242','14.63326824254882','14.633268242548819','test'),('2018-11-16 07:59:59','2018-11-18 15:59:59','RLCBNB','4h','0.046230000000000','0.044590000000000','0.711908500000000','0.686653688405797','15.399275362318841','15.399275362318841','test'),('2018-11-20 23:59:59','2018-11-22 07:59:59','RLCBNB','4h','0.045300000000000','0.044200000000000','0.711908500000000','0.694621538631347','15.715419426048566','15.715419426048566','test'),('2018-11-24 11:59:59','2018-11-24 15:59:59','RLCBNB','4h','0.044100000000000','0.043240000000000','0.711908500000000','0.698025477097506','16.143049886621316','16.143049886621316','test'),('2018-11-27 11:59:59','2018-11-30 11:59:59','RLCBNB','4h','0.043590000000000','0.043550000000000','0.711908500000000','0.711255223101629','16.331922459279653','16.331922459279653','test'),('2018-12-01 07:59:59','2018-12-01 11:59:59','RLCBNB','4h','0.045700000000000','0.046450000000000','0.711908500000000','0.723591899890591','15.577866520787747','15.577866520787747','test'),('2018-12-09 23:59:59','2018-12-10 03:59:59','RLCBNB','4h','0.041040000000000','0.038140000000000','0.711908500000000','0.661603074805068','17.34669834307992','17.346698343079922','test'),('2018-12-24 15:59:59','2018-12-24 19:59:59','RLCBNB','4h','0.035520000000000','0.035930000000000','0.711908500000000','0.720125912302928','20.04246903153153','20.042469031531532','test'),('2018-12-26 15:59:59','2018-12-26 23:59:59','RLCBNB','4h','0.035810000000000','0.034330000000000','0.711908500000000','0.682485864423345','19.880159173415247','19.880159173415247','test'),('2019-01-06 11:59:59','2019-01-06 19:59:59','RLCBNB','4h','0.033120000000000','0.033390000000000','0.711908500000000','0.717712101902174','21.494821859903386','21.494821859903386','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','RLCBNB','4h','0.032980000000000','0.032110000000000','0.711908500000000','0.693128621437235','21.586067313523348','21.586067313523348','test'),('2019-01-24 15:59:59','2019-02-01 07:59:59','RLCBNB','4h','0.032030000000000','0.036270000000000','0.711908500000000','0.806148026693724','22.226303465501093','22.226303465501093','test'),('2019-02-01 15:59:59','2019-02-01 19:59:59','RLCBNB','4h','0.037210000000000','0.038340000000000','0.711908500000000','0.733527865896265','19.13218220908358','19.132182209083581','test'),('2019-02-03 11:59:59','2019-02-04 03:59:59','RLCBNB','4h','0.037700000000000','0.036880000000000','0.711908500000000','0.696424018037135','18.88351458885942','18.883514588859420','test'),('2019-02-17 23:59:59','2019-02-18 03:59:59','RLCBNB','4h','0.028600000000000','0.027220000000000','0.711908500000000','0.677557670279720','24.891905594405596','24.891905594405596','test'),('2019-02-23 03:59:59','2019-02-24 07:59:59','RLCBNB','4h','0.027860000000000','0.027920000000000','0.711908500000000','0.713441684134961','25.553068916008616','25.553068916008616','test'),('2019-02-25 11:59:59','2019-02-28 11:59:59','RLCBNB','4h','0.033410000000000','0.029360000000000','0.711908500000000','0.625610103561808','21.30824603412152','21.308246034121520','test'),('2019-03-03 15:59:59','2019-03-03 19:59:59','RLCBNB','4h','0.030030000000000','0.029830000000000','0.711908500000000','0.707167184648685','23.70657675657676','23.706576756576759','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','RLCBNB','4h','0.029880000000000','0.029220000000000','0.711908500000000','0.696183613453815','23.825585676037484','23.825585676037484','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','RLCBNB','4h','0.029830000000000','0.027870000000000','0.711908500000000','0.665132078276903','23.865521287294673','23.865521287294673','test'),('2019-03-12 19:59:59','2019-03-13 23:59:59','RLCBNB','4h','0.034830000000000','0.027510000000000','0.711908500000000','0.562291209732989','20.43952052828022','20.439520528280219','test'),('2019-03-17 07:59:59','2019-03-17 11:59:59','RLCBNB','4h','0.026790000000000','0.026860000000000','0.474605666666667','0.475845771058853','17.71577703123056','17.715777031230559','test'),('2019-03-18 15:59:59','2019-03-18 23:59:59','RLCBNB','4h','0.027060000000000','0.026310000000000','0.499858778655251','0.486004599645959','18.47223867905585','18.472238679055849','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','RLCBNB','4h','0.026750000000000','0.027520000000000','0.499858778655251','0.514247236956729','18.68630948243929','18.686309482439292','test'),('2019-03-26 11:59:59','2019-03-26 19:59:59','RLCBNB','4h','0.026960000000000','0.025410000000000','0.499992348478298','0.471246497582847','18.545710255129737','18.545710255129737','test'),('2019-03-27 03:59:59','2019-03-27 07:59:59','RLCBNB','4h','0.025650000000000','0.025360000000000','0.499992348478298','0.494339413544235','19.492879082974582','19.492879082974582','test'),('2019-03-27 11:59:59','2019-03-30 07:59:59','RLCBNB','4h','0.025960000000000','0.025720000000000','0.499992348478298','0.495369923068637','19.26010587358621','19.260105873586209','test'),('2019-03-30 19:59:59','2019-03-31 03:59:59','RLCBNB','4h','0.026250000000000','0.025490000000000','0.499992348478298','0.485516379531879','19.04732756107802','19.047327561078021','test'),('2019-03-31 15:59:59','2019-04-01 07:59:59','RLCBNB','4h','0.026680000000000','0.025940000000000','0.499992348478298','0.486124494734897','18.74034289648793','18.740342896487931','test'),('2019-04-01 15:59:59','2019-04-03 03:59:59','RLCBNB','4h','0.026730000000000','0.026200000000000','0.499992348478298','0.490078545833573','18.705288008915','18.705288008915002','test'),('2019-04-04 11:59:59','2019-04-09 15:59:59','RLCBNB','4h','0.026630000000000','0.028250000000000','0.499992348478298','0.530408706140140','18.775529420889896','18.775529420889896','test'),('2019-04-30 19:59:59','2019-04-30 23:59:59','RLCBNB','4h','0.022400000000000','0.021650000000000','0.499992348478298','0.483251533239069','22.321086985638303','22.321086985638303','test'),('2019-05-03 07:59:59','2019-05-03 11:59:59','RLCBNB','4h','0.021950000000000','0.021700000000000','0.499992348478298','0.494297674805424','22.778694691494213','22.778694691494213','test'),('2019-05-03 15:59:59','2019-05-12 11:59:59','RLCBNB','4h','0.022610000000000','0.027250000000000','0.499992348478298','0.602600243079771','22.113770388248472','22.113770388248472','test'),('2019-05-12 19:59:59','2019-05-13 23:59:59','RLCBNB','4h','0.030200000000000','0.029690000000000','0.508319830172671','0.499735621120086','16.8317824560487','16.831782456048700','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','RLCBNB','4h','0.014210000000000','0.014220000000000','0.508319830172671','0.508677549968711','35.77197960398811','35.771979603988107','test'),('2019-06-26 19:59:59','2019-06-27 03:59:59','RLCBNB','4h','0.013810000000000','0.010210000000000','0.508319830172671','0.375810678208760','36.808097767753154','36.808097767753154','test'),('2019-06-28 15:59:59','2019-06-29 11:59:59','RLCBNB','4h','0.011370000000000','0.011370000000000','0.508319830172671','0.508319830172671','44.707109074113546','44.707109074113546','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 21:47:31
