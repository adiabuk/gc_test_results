-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-02 03:59:59','VIBEBTC','4h','0.000012480000000','0.000012870000000','0.001467500000000','0.001513359375000','117.58814102564102','117.588141025641022','test'),('2018-07-04 15:59:59','2018-07-05 03:59:59','VIBEBTC','4h','0.000012750000000','0.000012800000000','0.001478964843750','0.001484764705882','115.99724264705884','115.997242647058840','test'),('2018-07-07 03:59:59','2018-07-07 07:59:59','VIBEBTC','4h','0.000012500000000','0.000011950000000','0.001480414809283','0.001415276557675','118.43318474264','118.433184742639995','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','VIBEBTC','4h','0.000011510000000','0.000011510000000','0.001480414809283','0.001480414809283','128.61987917315378','128.619879173153777','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','VIBEBTC','4h','0.000004870000000','0.000004780000000','0.001480414809283','0.001453056014040','303.9866138158111','303.986613815811097','test'),('2018-08-26 23:59:59','2018-08-27 03:59:59','VIBEBTC','4h','0.000004830000000','0.000004870000000','0.001480414809283','0.001492674973335','306.50410130082815','306.504101300828154','test'),('2018-09-03 15:59:59','2018-09-05 11:59:59','VIBEBTC','4h','0.000005340000000','0.000004840000000','0.001480414809283','0.001341799190436','277.2312376934457','277.231237693445678','test'),('2018-09-10 07:59:59','2018-09-10 19:59:59','VIBEBTC','4h','0.000005280000000','0.000004830000000','0.001480414809283','0.001354243092583','280.3815926672348','280.381592667234827','test'),('2018-09-11 03:59:59','2018-09-11 07:59:59','VIBEBTC','4h','0.000004900000000','0.000004740000000','0.001480414809283','0.001432074733878','302.1254712822449','302.125471282244916','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','VIBEBTC','4h','0.000004830000000','0.000004600000000','0.001480414809283','0.001409918865984','306.50410130082815','306.504101300828154','test'),('2018-09-15 03:59:59','2018-09-28 07:59:59','VIBEBTC','4h','0.000004990000000','0.000011880000000','0.001480414809283','0.003524514616089','296.67631448557114','296.676314485571140','test'),('2018-09-30 07:59:59','2018-09-30 15:59:59','VIBEBTC','4h','0.000012600000000','0.000011580000000','0.001875474701722','0.001723650559202','148.8471985493651','148.847198549365089','test'),('2018-09-30 19:59:59','2018-09-30 23:59:59','VIBEBTC','4h','0.000011920000000','0.000011750000000','0.001875474701722','0.001848727159835','157.33848168808726','157.338481688087256','test'),('2018-10-01 03:59:59','2018-10-01 07:59:59','VIBEBTC','4h','0.000012360000000','0.000011930000000','0.001875474701722','0.001810227604494','151.7374354144013','151.737435414401290','test'),('2018-10-07 11:59:59','2018-10-07 15:59:59','VIBEBTC','4h','0.000012290000000','0.000011580000000','0.001875474701722','0.001767127505772','152.60168443628967','152.601684436289673','test'),('2018-10-08 23:59:59','2018-10-09 03:59:59','VIBEBTC','4h','0.000011610000000','0.000011750000000','0.001875474701722','0.001898090245067','161.53959532489233','161.539595324892332','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','VIBEBTC','4h','0.000012600000000','0.000011600000000','0.001875474701722','0.001726627503173','148.8471985493651','148.847198549365089','test'),('2018-10-14 15:59:59','2018-10-14 19:59:59','VIBEBTC','4h','0.000011430000000','0.000011050000000','0.001875474701722','0.001813122961857','164.08352595993','164.083525959930000','test'),('2018-10-17 11:59:59','2018-10-17 15:59:59','VIBEBTC','4h','0.000011270000000','0.000011150000000','0.001875474701722','0.001855505139681','166.4130170117125','166.413017011712498','test'),('2018-10-18 07:59:59','2018-10-18 11:59:59','VIBEBTC','4h','0.000011260000000','0.000011480000000','0.001875474701722','0.001912118079553','166.56080832344583','166.560808323445826','test'),('2018-10-20 11:59:59','2018-10-20 15:59:59','VIBEBTC','4h','0.000011240000000','0.000011370000000','0.001875474701722','0.001897166135105','166.8571798685053','166.857179868505312','test'),('2018-10-26 11:59:59','2018-10-26 15:59:59','VIBEBTC','4h','0.000011560000000','0.000011400000000','0.001875474701722','0.001849516574363','162.23829599671282','162.238295996712822','test'),('2018-10-27 07:59:59','2018-10-27 11:59:59','VIBEBTC','4h','0.000011420000000','0.000011110000000','0.001875474701722','0.001824564267612','164.22720680577933','164.227206805779332','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','VIBEBTC','4h','0.000007530000000','0.000006900000000','0.001875474701722','0.001718562475682','249.06702546108897','249.067025461088974','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','VIBEBTC','4h','0.000007150000000','0.000007060000000','0.001875474701722','0.001851867327854','262.304154086993','262.304154086992980','test'),('2018-12-17 23:59:59','2018-12-25 07:59:59','VIBEBTC','4h','0.000006870000000','0.000007180000000','0.001875474701722','0.001960103108932','272.9948619682678','272.994861968267799','test'),('2018-12-27 23:59:59','2018-12-28 03:59:59','VIBEBTC','4h','0.000007310000000','0.000007320000000','0.001875474701722','0.001878040330589','256.56288669247607','256.562886692476070','test'),('2019-01-03 03:59:59','2019-01-03 23:59:59','VIBEBTC','4h','0.000007600000000','0.000007380000000','0.001875474701722','0.001821184644567','246.77298706868422','246.772987068684216','test'),('2019-01-11 19:59:59','2019-01-11 23:59:59','VIBEBTC','4h','0.000008140000000','0.000007960000000','0.001875474701722','0.001834002288170','230.4022975088452','230.402297508845209','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','VIBEBTC','4h','0.000008010000000','0.000008150000000','0.001875474701722','0.001908254534212','234.1416606394507','234.141660639450691','test'),('2019-01-14 15:59:59','2019-01-27 11:59:59','VIBEBTC','4h','0.000009810000000','0.000011120000000','0.001875474701722','0.002125920355061','191.1798880450561','191.179888045056089','test'),('2019-02-03 03:59:59','2019-02-03 07:59:59','VIBEBTC','4h','0.000010750000000','0.000010430000000','0.001875474701722','0.001819646617578','174.4627629508837','174.462762950883700','test'),('2019-02-11 19:59:59','2019-02-12 03:59:59','VIBEBTC','4h','0.000010080000000','0.000010340000000','0.001875474701722','0.001923850041251','186.05899818670633','186.058998186706333','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','VIBEBTC','4h','0.000010150000000','0.000009810000000','0.001875474701722','0.001812650918610','184.77583268197046','184.775832681970456','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','VIBEBTC','4h','0.000010140000000','0.000009950000000','0.001875474701722','0.001840332670822','184.95805736903353','184.958057369033526','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','VIBEBTC','4h','0.000009950000000','0.000009700000000','0.001875474701722','0.001828352221779','188.48991977105527','188.489919771055270','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','VIBEBTC','4h','0.000009880000000','0.000009770000000','0.001875474701722','0.001854593910508','189.82537466821861','189.825374668218615','test'),('2019-02-28 03:59:59','2019-02-28 07:59:59','VIBEBTC','4h','0.000009810000000','0.000009660000000','0.001875474701722','0.001846797718515','191.1798880450561','191.179888045056089','test'),('2019-03-02 15:59:59','2019-03-04 03:59:59','VIBEBTC','4h','0.000010190000000','0.000009670000000','0.001875474701722','0.001779768436276','184.05051047320902','184.050510473209016','test'),('2019-03-05 11:59:59','2019-03-05 15:59:59','VIBEBTC','4h','0.000009780000000','0.000010110000000','0.001875474701722','0.001938757590430','191.76632941942742','191.766329419427421','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIBEBTC','4h','0.000010900000000','0.000011170000000','0.001875474701722','0.001921931414517','172.06189924055045','172.061899240550446','test'),('2019-05-06 11:59:59','2019-05-06 23:59:59','VIBEBTC','4h','0.000007120000000','0.000007060000000','0.001875474701722','0.001859670139629','263.40936821938203','263.409368219382031','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','VIBEBTC','4h','0.000006150000000','0.000005660000000','0.001875474701722','0.001726046636056','304.9552360523577','304.955236052357691','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','VIBEBTC','4h','0.000005500000000','0.000005680000000','0.001875474701722','0.001936853873778','340.9954003130909','340.995400313090897','test'),('2019-05-22 15:59:59','2019-05-24 19:59:59','VIBEBTC','4h','0.000005930000000','0.000005890000000','0.001875474701722','0.001862823944881','316.26892103237776','316.268921032377762','test'),('2019-05-25 19:59:59','2019-05-25 23:59:59','VIBEBTC','4h','0.000005810000000','0.000005740000000','0.001875474701722','0.001852878620978','322.80115348055074','322.801153480550738','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEBTC','4h','0.000005760000000','0.000005660000000','0.001875474701722','0.001842914377039','325.6032468267361','325.603246826736097','test'),('2019-05-29 07:59:59','2019-05-29 15:59:59','VIBEBTC','4h','0.000005680000000','0.000005620000000','0.001875474701722','0.001855663349239','330.1892080496479','330.189208049647902','test'),('2019-05-31 07:59:59','2019-05-31 15:59:59','VIBEBTC','4h','0.000005730000000','0.000005750000000','0.001875474701722','0.001882020861239','327.30797586771376','327.307975867713765','test'),('2019-06-05 11:59:59','2019-06-05 15:59:59','VIBEBTC','4h','0.000005860000000','0.000005740000000','0.001875474701722','0.001837069076431','320.04687742696245','320.046877426962453','test'),('2019-06-07 11:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005910000000','0.000005930000000','0.001875474701722','0.001881821485823','317.3392050291032','317.339205029103198','test'),('2019-06-10 07:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006000000000','0.000006010000000','0.001875474701722','0.001878600492892','312.57911695366664','312.579116953666642','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:02:46
