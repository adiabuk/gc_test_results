-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-23 15:59:59','2018-11-24 07:59:59','IOTXETH','4h','0.000078950000000','0.000078780000000','0.072144500000000','0.071989154021533','913.7998733375555','913.799873337555482','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','IOTXETH','4h','0.000077320000000','0.000075730000000','0.072144500000000','0.070660928414382','933.0638903259182','933.063890325918237','test'),('2018-11-26 19:59:59','2018-11-26 23:59:59','IOTXETH','4h','0.000078090000000','0.000076610000000','0.072144500000000','0.070777182033551','923.863490843898','923.863490843898035','test'),('2018-11-28 07:59:59','2018-11-28 23:59:59','IOTXETH','4h','0.000079520000000','0.000077480000000','0.072144500000000','0.070293710513078','907.2497484909456','907.249748490945649','test'),('2018-11-30 19:59:59','2018-12-05 23:59:59','IOTXETH','4h','0.000082140000000','0.000081190000000','0.072144500000000','0.071310104151449','878.3114195276357','878.311419527635735','test'),('2018-12-14 11:59:59','2018-12-14 15:59:59','IOTXETH','4h','0.000080330000000','0.000081560000000','0.072144500000000','0.073249164944604','898.1015809784639','898.101580978463858','test'),('2018-12-15 03:59:59','2018-12-16 23:59:59','IOTXETH','4h','0.000080480000000','0.000083560000000','0.072144500000000','0.074905497266402','896.4276838966202','896.427683896620238','test'),('2018-12-17 23:59:59','2018-12-18 03:59:59','IOTXETH','4h','0.000081160000000','0.000080320000000','0.072144500000000','0.071397809758502','888.9169541646131','888.916954164613117','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','IOTXETH','4h','0.000082110000000','0.000078940000000','0.072144500000000','0.069359235537693','878.6323224942151','878.632322494215146','test'),('2018-12-19 23:59:59','2018-12-20 03:59:59','IOTXETH','4h','0.000081540000000','0.000081200000000','0.072144500000000','0.071843676723081','884.7743438803042','884.774343880304173','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','IOTXETH','4h','0.000056140000000','0.000053530000000','0.072144500000000','0.068790436141788','1285.0819380121125','1285.081938012112460','test'),('2019-01-12 11:59:59','2019-01-12 15:59:59','IOTXETH','4h','0.000055720000000','0.000055550000000','0.072144500000000','0.071924389357502','1294.7684852835607','1294.768485283560722','test'),('2019-01-16 03:59:59','2019-01-25 15:59:59','IOTXETH','4h','0.000055860000000','0.000063290000000','0.072144500000000','0.081740519244540','1291.5234514858575','1291.523451485857549','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','IOTXETH','4h','0.000063250000000','0.000062240000000','0.072235327027026','0.071081845915606','1142.0605063561463','1142.060506356146334','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','IOTXETH','4h','0.000053530000000','0.000052220000000','0.072235327027026','0.070467565427822','1349.4363352704277','1349.436335270427662','test'),('2019-02-26 07:59:59','2019-02-27 15:59:59','IOTXETH','4h','0.000053200000000','0.000052940000000','0.072235327027026','0.071882297233285','1357.806899004248','1357.806899004247953','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','IOTXETH','4h','0.000067000000000','0.000066900000000','0.072235327027026','0.072127513106090','1078.1392093585969','1078.139209358596872','test'),('2019-03-25 23:59:59','2019-03-28 07:59:59','IOTXETH','4h','0.000067560000000','0.000068340000000','0.072235327027026','0.073069305047764','1069.202590690142','1069.202590690141960','test'),('2019-04-03 15:59:59','2019-04-03 23:59:59','IOTXETH','4h','0.000075700000000','0.000079890000000','0.072235327027026','0.076233557149130','954.2315327216116','954.231532721611643','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','IOTXETH','4h','0.000084500000000','0.000081580000000','0.072597857456412','0.070089150429516','859.1462420877102','859.146242087710220','test'),('2019-04-14 19:59:59','2019-04-18 07:59:59','IOTXETH','4h','0.000086470000000','0.000089740000000','0.072597857456412','0.075343260415617','839.5727703991209','839.572770399120941','test'),('2019-04-19 03:59:59','2019-04-19 07:59:59','IOTXETH','4h','0.000088540000000','0.000092000000000','0.072657031439489','0.075496350716433','820.6125077873138','820.612507787313803','test'),('2019-04-21 07:59:59','2019-04-21 11:59:59','IOTXETH','4h','0.000089530000000','0.000082680000000','0.073366861258725','0.067753513781653','819.4667849740283','819.466784974028315','test'),('2019-04-22 03:59:59','2019-04-22 07:59:59','IOTXETH','4h','0.000093090000000','0.000085620000000','0.073366861258725','0.067479543033323','788.1282764929101','788.128276492910118','test'),('2019-05-22 15:59:59','2019-05-22 19:59:59','IOTXETH','4h','0.000046370000000','0.000046600000000','0.073366861258725','0.073730768485154','1582.2053322994395','1582.205332299439533','test'),('2019-05-23 07:59:59','2019-05-24 15:59:59','IOTXETH','4h','0.000047580000000','0.000046000000000','0.073366861258725','0.070930551027771','1541.96850060372','1541.968500603720031','test'),('2019-05-25 03:59:59','2019-05-25 11:59:59','IOTXETH','4h','0.000048890000000','0.000046520000000','0.073366861258725','0.069810316746899','1500.6516927536306','1500.651692753630641','test'),('2019-06-07 23:59:59','2019-06-08 15:59:59','IOTXETH','4h','0.000043100000000','0.000042720000000','0.073366861258725','0.072720007261548','1702.2473609912995','1702.247360991299502','test'),('2019-06-17 07:59:59','2019-06-17 11:59:59','IOTXETH','4h','0.000043000000000','0.000040570000000','0.073366861258725','0.069220780494569','1706.2060757843024','1706.206075784302357','test'),('2019-06-17 23:59:59','2019-06-18 11:59:59','IOTXETH','4h','0.000046390000000','0.000042380000000','0.073366861258725','0.067024953225798','1581.523200231192','1581.523200231192050','test'),('2019-07-10 15:59:59','2019-07-10 19:59:59','IOTXETH','4h','0.000029560000000','0.000029700000000','0.073366861258725','0.073714336244389','2481.964183312754','2481.964183312753903','test'),('2019-07-11 03:59:59','2019-07-11 07:59:59','IOTXETH','4h','0.000029780000000','0.000030870000000','0.073366861258725','0.076052216489484','2463.6286520727','2463.628652072699879','test'),('2019-08-11 03:59:59','2019-08-11 11:59:59','IOTXETH','4h','0.000030000000000','0.000025950000000','0.073366861258725','0.063462334988797','2445.5620419575002','2445.562041957500242','test'),('2019-08-13 07:59:59','2019-08-13 11:59:59','IOTXETH','4h','0.000026610000000','0.000026050000000','0.073366861258725','0.071822876204051','2757.116169061443','2757.116169061443088','test'),('2019-08-16 11:59:59','2019-08-16 15:59:59','IOTXETH','4h','0.000026000000000','0.000026270000000','0.073366861258725','0.074128747894873','2821.802356104808','2821.802356104808041','test'),('2019-08-24 19:59:59','2019-08-25 15:59:59','IOTXETH','4h','0.000024900000000','0.000025510000000','0.073366861258725','0.075164202036549','2946.460291515061','2946.460291515060817','test'),('2019-09-04 15:59:59','2019-09-04 19:59:59','IOTXETH','4h','0.000027970000000','0.000024260000000','0.073366861258725','0.063635325496484','2623.055461520379','2623.055461520379140','test'),('2019-09-11 03:59:59','2019-09-12 15:59:59','IOTXETH','4h','0.000024430000000','0.000023880000000','0.073366861258725','0.071715130857894','3003.146183328899','3003.146183328899042','test'),('2019-09-13 15:59:59','2019-09-13 19:59:59','IOTXETH','4h','0.000025880000000','0.000024810000000','0.073366861258725','0.070333532760006','2834.8864474005027','2834.886447400502675','test'),('2019-10-04 19:59:59','2019-10-04 23:59:59','IOTXETH','4h','0.000020850000000','0.000021110000000','0.073366861258725','0.074281747778018','3518.7943049748205','3518.794304974820534','test'),('2019-11-01 03:59:59','2019-11-01 19:59:59','IOTXETH','4h','0.000024310000000','0.000023520000000','0.073366861258725','0.070982664615599','3017.970434336693','3017.970434336692961','test'),('2019-11-05 11:59:59','2019-11-05 15:59:59','IOTXETH','4h','0.000023910000000','0.000023700000000','0.073366861258725','0.072722484811032','3068.4592747271017','3068.459274727101729','test'),('2019-11-06 07:59:59','2019-11-07 23:59:59','IOTXETH','4h','0.000027680000000','0.000027150000000','0.073366861258725','0.071962076704277','2650.536895185152','2650.536895185151934','test'),('2019-11-13 11:59:59','2019-11-14 15:59:59','IOTXETH','4h','0.000025480000000','0.000025210000000','0.073366861258725','0.072589425915717','2879.3901592906204','2879.390159290620431','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:44:43
