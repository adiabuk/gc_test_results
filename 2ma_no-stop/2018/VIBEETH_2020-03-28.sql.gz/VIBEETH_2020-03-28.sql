-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 19:59:59','2018-06-30 23:59:59','VIBEETH','4h','0.000167300000000','0.000167600000000','0.072144500000000','0.072273868499701','431.22833233711896','431.228332337118957','test'),('2018-07-01 19:59:59','2018-07-01 23:59:59','VIBEETH','4h','0.000170800000000','0.000177400000000','0.072176842124925','0.074965877007972','422.58104288597923','422.581042885979230','test'),('2018-07-06 23:59:59','2018-07-07 03:59:59','VIBEETH','4h','0.000173300000000','0.000174700000000','0.072874100845687','0.073462812566310','420.50837187355444','420.508371873554438','test'),('2018-07-17 23:59:59','2018-07-19 19:59:59','VIBEETH','4h','0.000168000000000','0.000164500000000','0.073021278775843','0.071500002134680','434.65046890382587','434.650468903825868','test'),('2018-08-16 23:59:59','2018-08-17 03:59:59','VIBEETH','4h','0.000107300000000','0.000106000000000','0.073021278775843','0.072136584811178','680.5338189733736','680.533818973373627','test'),('2018-08-19 15:59:59','2018-08-20 23:59:59','VIBEETH','4h','0.000106000000000','0.000105700000000','0.073021278775843','0.072814614779308','688.879988451349','688.879988451349050','test'),('2018-08-21 11:59:59','2018-08-21 15:59:59','VIBEETH','4h','0.000106600000000','0.000106000000000','0.073021278775843','0.072610277206748','685.0026151580018','685.002615158001845','test'),('2018-08-22 03:59:59','2018-08-22 11:59:59','VIBEETH','4h','0.000107400000000','0.000106600000000','0.073021278775843','0.072477358635986','679.9001748216294','679.900174821629435','test'),('2018-08-23 11:59:59','2018-08-23 15:59:59','VIBEETH','4h','0.000107800000000','0.000106500000000','0.073021278775843','0.072140688215466','677.3773541358348','677.377354135834821','test'),('2018-08-24 03:59:59','2018-09-05 19:59:59','VIBEETH','4h','0.000106600000000','0.000132900000000','0.073021278775843','0.091036847554498','685.0026151580018','685.002615158001845','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','VIBEETH','4h','0.000149900000000','0.000142600000000','0.076413134252584','0.072691880883379','509.7607355075617','509.760735507561719','test'),('2018-09-14 23:59:59','2018-09-15 19:59:59','VIBEETH','4h','0.000145900000000','0.000154000000000','0.076413134252584','0.080655398731309','523.7363553981083','523.736355398108344','test'),('2018-09-30 07:59:59','2018-09-30 11:59:59','VIBEETH','4h','0.000359200000000','0.000349000000000','0.076543387029963','0.074369827598711','213.09406188742622','213.094061887426221','test'),('2018-10-01 03:59:59','2018-10-01 07:59:59','VIBEETH','4h','0.000353800000000','0.000342400000000','0.076543387029963','0.074077037080439','216.34648680034766','216.346486800347662','test'),('2018-10-07 11:59:59','2018-10-07 15:59:59','VIBEETH','4h','0.000361100000000','0.000341900000000','0.076543387029963','0.072473508794086','211.97282478527555','211.972824785275549','test'),('2018-10-10 11:59:59','2018-10-10 19:59:59','VIBEETH','4h','0.000367700000000','0.000345000000000','0.076543387029963','0.071817972600863','208.16803652423985','208.168036524239852','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','VIBEETH','4h','0.000350100000000','0.000337700000000','0.076543387029963','0.073832338760407','218.6329249641902','218.632924964190209','test'),('2018-10-12 19:59:59','2018-10-12 23:59:59','VIBEETH','4h','0.000342300000000','0.000339100000000','0.076543387029963','0.075827819286767','223.61491974865027','223.614919748650266','test'),('2018-10-14 03:59:59','2018-10-14 11:59:59','VIBEETH','4h','0.000344500000000','0.000340100000000','0.076543387029963','0.075565764670219','222.18689994183742','222.186899941837424','test'),('2018-10-16 03:59:59','2018-10-16 07:59:59','VIBEETH','4h','0.000342100000000','0.000345100000000','0.076543387029963','0.077214623981410','223.74565048220694','223.745650482206941','test'),('2018-10-30 19:59:59','2018-10-30 23:59:59','VIBEETH','4h','0.000358700000000','0.000358500000000','0.076543387029963','0.076500708810264','213.39109849446055','213.391098494460550','test'),('2018-11-02 03:59:59','2018-11-02 07:59:59','VIBEETH','4h','0.000356000000000','0.000353200000000','0.076543387029963','0.075941360390402','215.00951412910956','215.009514129109562','test'),('2018-11-27 15:59:59','2018-11-28 03:59:59','VIBEETH','4h','0.000247000000000','0.000245100000000','0.076543387029963','0.075954591745117','309.8922551820364','309.892255182036422','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','VIBEETH','4h','0.000265000000000','0.000261500000000','0.076543387029963','0.075532436635228','288.8429699243887','288.842969924388683','test'),('2018-12-05 23:59:59','2018-12-06 03:59:59','VIBEETH','4h','0.000264400000000','0.000267200000000','0.076543387029963','0.077353982656604','289.4984380860931','289.498438086093074','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','VIBEETH','4h','0.000267800000000','0.000273500000000','0.076543387029963','0.078172577866672','285.82295380867436','285.822953808674356','test'),('2018-12-09 23:59:59','2018-12-10 11:59:59','VIBEETH','4h','0.000271200000000','0.000268100000000','0.076543387029963','0.075668444184119','282.23962769160397','282.239627691603971','test'),('2018-12-18 03:59:59','2018-12-18 19:59:59','VIBEETH','4h','0.000268200000000','0.000268400000000','0.076543387029963','0.076600466364064','285.3966705069463','285.396670506946293','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','VIBEETH','4h','0.000262100000000','0.000259000000000','0.076543387029963','0.075638066542390','292.03886695903475','292.038866959034749','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','VIBEETH','4h','0.000239300000000','0.000231900000000','0.076543387029963','0.074176395538021','319.86371512730045','319.863715127300452','test'),('2019-01-05 07:59:59','2019-01-05 23:59:59','VIBEETH','4h','0.000225900000000','0.000210600000000','0.076543387029963','0.071359173565782','338.837481319004','338.837481319003984','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','VIBEETH','4h','0.000213800000000','0.000213500000000','0.076543387029963','0.076435982838621','358.01397114108045','358.013971141080447','test'),('2019-02-02 23:59:59','2019-02-03 11:59:59','VIBEETH','4h','0.000335300000000','0.000324900000000','0.076543387029963','0.074169240817283','228.2832896807724','228.283289680772413','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','VIBEETH','4h','0.000329900000000','0.000321000000000','0.076543387029963','0.074478409325911','232.0199667473871','232.019966747387087','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','VIBEETH','4h','0.000324700000000','0.000316100000000','0.076543387029963','0.074516059871177','235.73571613785955','235.735716137859555','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','VIBEETH','4h','0.000270600000000','0.000270100000000','0.076543387029963','0.076401954311874','282.865436178725','282.865436178725020','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','VIBEETH','4h','0.000272400000000','0.000275000000000','0.076543387029963','0.077273977361380','280.9962813141079','280.996281314107875','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','VIBEETH','4h','0.000270000000000','0.000268800000000','0.076543387029963','0.076203194198719','283.4940260369','283.494026036899982','test'),('2019-03-01 15:59:59','2019-03-01 19:59:59','VIBEETH','4h','0.000272500000000','0.000270500000000','0.076543387029963','0.075981600703138','280.89316341270825','280.893163412708248','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','VIBEETH','4h','0.000304800000000','0.000303100000000','0.076543387029963','0.076116471813589','251.12659786733266','251.126597867332663','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','VIBEETH','4h','0.000314700000000','0.000313200000000','0.076543387029963','0.076178547244310','243.22652376855098','243.226523768550976','test'),('2019-03-23 15:59:59','2019-03-23 23:59:59','VIBEETH','4h','0.000315800000000','0.000314800000000','0.076543387029963','0.076301007717012','242.37931295111778','242.379312951117782','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','VIBEETH','4h','0.000316400000000','0.000322100000000','0.076543387029963','0.077922329210971','241.91968087851768','241.919680878517681','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','VIBEETH','4h','0.000275400000000','0.000249200000000','0.076543387029963','0.069261481655290','277.93531964401956','277.935319644019557','test'),('2019-05-01 19:59:59','2019-05-02 03:59:59','VIBEETH','4h','0.000241300000000','0.000235600000000','0.076543387029963','0.074735275525318','317.2125446745255','317.212544674525475','test'),('2019-05-02 15:59:59','2019-05-02 19:59:59','VIBEETH','4h','0.000239100000000','0.000241200000000','0.076543387029963','0.077215662700239','320.13127155986194','320.131271559861943','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','VIBEETH','4h','0.000245100000000','0.000237000000000','0.076543387029963','0.074013801412082','312.2945207260832','312.294520726083192','test'),('2019-05-22 15:59:59','2019-05-24 19:59:59','VIBEETH','4h','0.000182900000000','0.000189000000000','0.076543387029963','0.079096228259502','418.4985622195899','418.498562219589928','test'),('2019-05-26 07:59:59','2019-05-26 19:59:59','VIBEETH','4h','0.000187900000000','0.000175500000000','0.076543387029963','0.071492093793286','407.3623577965035','407.362357796503488','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEETH','4h','0.000188100000000','0.000182200000000','0.076543387029963','0.074142504608502','406.9292239764115','406.929223976411492','test'),('2019-05-29 07:59:59','2019-05-29 15:59:59','VIBEETH','4h','0.000183500000000','0.000180300000000','0.076543387029963','0.075208570471402','417.1301745502071','417.130174550207073','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEETH','4h','0.000185600000000','0.000184300000000','0.076543387029963','0.076007253392361','412.41049046316266','412.410490463162660','test'),('2019-06-07 11:59:59','2019-06-12 15:59:59','VIBEETH','4h','0.000190000000000','0.000192400000000','0.076543387029963','0.077510250866131','402.8599317366473','402.859931736647297','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:04:06
