-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-16 11:59:59','2018-04-16 15:59:59','BTGETH','4h','0.101626000000000','0.102501000000000','0.072144500000000','0.072765664244386','0.709901993584319','0.709901993584319','test'),('2018-04-28 23:59:59','2018-04-29 11:59:59','BTGETH','4h','0.112438000000000','0.110598000000000','0.072299791061097','0.071116635761711','0.6430191844491765','0.643019184449176','test'),('2018-04-29 15:59:59','2018-04-29 19:59:59','BTGETH','4h','0.111821000000000','0.112814000000000','0.072299791061097','0.072941832292383','0.6465672016982231','0.646567201698223','test'),('2018-07-01 15:59:59','2018-07-01 19:59:59','BTGETH','4h','0.057906000000000','0.058160000000000','0.072299791061097','0.072616928265005','1.248571668930629','1.248571668930629','test'),('2018-07-06 15:59:59','2018-07-06 19:59:59','BTGETH','4h','0.060430000000000','0.060429000000000','0.072299791061097','0.072298594638938','1.196422158879646','1.196422158879646','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','BTGETH','4h','0.062415000000000','0.061180000000000','0.072299791061097','0.070869201588046','1.1583720429559723','1.158372042955972','test'),('2018-07-23 03:59:59','2018-07-25 11:59:59','BTGETH','4h','0.063398000000000','0.064399000000000','0.072299791061097','0.073441342700773','1.1404112284472225','1.140411228447223','test'),('2018-08-05 23:59:59','2018-08-06 07:59:59','BTGETH','4h','0.061702000000000','0.060403000000000','0.072299791061097','0.070777677862362','1.1717576587646592','1.171757658764659','test'),('2018-08-06 15:59:59','2018-08-07 19:59:59','BTGETH','4h','0.067658000000000','0.061000000000000','0.072299791061097','0.065185007755578','1.0686066845176774','1.068606684517677','test'),('2018-08-09 23:59:59','2018-08-10 03:59:59','BTGETH','4h','0.061053000000000','0.060674000000000','0.072299791061097','0.071850974118242','1.1842135695395313','1.184213569539531','test'),('2018-08-10 23:59:59','2018-08-12 07:59:59','BTGETH','4h','0.062365000000000','0.060241000000000','0.072299791061097','0.069837436275339','1.159300746590187','1.159300746590187','test'),('2018-08-12 15:59:59','2018-08-13 15:59:59','BTGETH','4h','0.061427000000000','0.060919000000000','0.072299791061097','0.071701873307356','1.1770034522457062','1.177003452245706','test'),('2018-08-17 19:59:59','2018-09-02 11:59:59','BTGETH','4h','0.060773000000000','0.073497000000000','0.072299791061097','0.087437147147869','1.1896696075740378','1.189669607574038','test'),('2018-09-16 07:59:59','2018-09-16 11:59:59','BTGETH','4h','0.093624000000000','0.093027000000000','0.072919080806206','0.072454107175072','0.77885030340731','0.778850303407310','test'),('2018-09-24 11:59:59','2018-09-24 15:59:59','BTGETH','4h','0.095975000000000','0.095910000000000','0.072919080806206','0.072869695651193','0.7597716155895389','0.759771615589539','test'),('2018-10-29 15:59:59','2018-10-31 03:59:59','BTGETH','4h','0.133789000000000','0.131638000000000','0.072919080806206','0.071746720277208','0.5450304644343407','0.545030464434341','test'),('2018-11-14 15:59:59','2018-11-14 19:59:59','BTGETH','4h','0.142890000000000','0.141541000000000','0.072919080806206','0.072230664261958','0.5103161929190707','0.510316192919071','test'),('2018-11-30 03:59:59','2018-11-30 07:59:59','BTGETH','4h','0.161198000000000','0.158766000000000','0.072919080806206','0.071818948022172','0.4523572302770878','0.452357230277088','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','BTGETH','4h','0.163252000000000','0.160106000000000','0.072919080806206','0.071513870283723','0.4466657731985274','0.446665773198527','test'),('2018-12-15 23:59:59','2018-12-16 03:59:59','BTGETH','4h','0.142255000000000','0.127352000000000','0.072919080806206','0.065279890188970','0.5125941499856315','0.512594149985631','test'),('2018-12-21 07:59:59','2018-12-21 15:59:59','BTGETH','4h','0.139316000000000','0.128820000000000','0.072919080806206','0.067425392556888','0.5234077981438313','0.523407798143831','test'),('2019-01-10 11:59:59','2019-01-11 07:59:59','BTGETH','4h','0.093916000000000','0.092824000000000','0.072919080806206','0.072071220630726','0.7764287321245156','0.776428732124516','test'),('2019-01-15 19:59:59','2019-01-16 15:59:59','BTGETH','4h','0.094964000000000','0.098324000000000','0.072919080806206','0.075499091247098','0.7678602502654268','0.767860250265427','test'),('2019-01-21 03:59:59','2019-01-21 07:59:59','BTGETH','4h','0.094787000000000','0.095845000000000','0.072919080806206','0.073732993974604','0.7692941100172598','0.769294110017260','test'),('2019-01-23 15:59:59','2019-01-24 03:59:59','BTGETH','4h','0.095427000000000','0.096009000000000','0.072919080806206','0.073363807194222','0.7641346873128779','0.764134687312878','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','BTGETH','4h','0.096532000000000','0.085159000000000','0.072919080806206','0.064328057041973','0.7553876518274354','0.755387651827435','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','BTGETH','4h','0.094396000000000','0.092552000000000','0.072919080806206','0.071494626539006','0.7724806221260012','0.772480622126001','test'),('2019-01-30 11:59:59','2019-01-30 23:59:59','BTGETH','4h','0.099208000000000','0.093830000000000','0.072919080806206','0.068966185711297','0.7350121039251472','0.735012103925147','test'),('2019-02-01 23:59:59','2019-02-02 03:59:59','BTGETH','4h','0.093687000000000','0.093788000000000','0.072919080806206','0.072997691789175','0.7783265640505727','0.778326564050573','test'),('2019-02-18 07:59:59','2019-02-18 11:59:59','BTGETH','4h','0.086446000000000','0.085107000000000','0.072919080806206','0.071789605189063','0.8435217454388405','0.843521745438841','test'),('2019-02-19 15:59:59','2019-02-20 15:59:59','BTGETH','4h','0.085553000000000','0.084882000000000','0.072919080806206','0.072347169789398','0.852326403588489','0.852326403588489','test'),('2019-02-20 23:59:59','2019-02-21 11:59:59','BTGETH','4h','0.085157000000000','0.084215000000000','0.072919080806206','0.072112455700584','0.8562899210423806','0.856289921042381','test'),('2019-02-22 19:59:59','2019-02-22 23:59:59','BTGETH','4h','0.084873000000000','0.084997000000000','0.072919080806206','0.073025616053222','0.8591552178691221','0.859155217869122','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','BTGETH','4h','0.086858000000000','0.084142000000000','0.072919080806206','0.070638942839989','0.8395206061181008','0.839520606118101','test'),('2019-02-24 15:59:59','2019-03-04 07:59:59','BTGETH','4h','0.087384000000000','0.091500000000000','0.072919080806206','0.076353747754370','0.8344671885723474','0.834467188572347','test'),('2019-03-06 19:59:59','2019-03-06 23:59:59','BTGETH','4h','0.091365000000000','0.090751000000000','0.072919080806206','0.072429042874668','0.7981073803557818','0.798107380355782','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','BTGETH','4h','0.090865000000000','0.090045000000000','0.072919080806206','0.072261031543442','0.8024991009322181','0.802499100932218','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','BTGETH','4h','0.090689000000000','0.090802000000000','0.072919080806206','0.073009939191800','0.8040565096781969','0.804056509678197','test'),('2019-03-12 11:59:59','2019-03-17 07:59:59','BTGETH','4h','0.092203000000000','0.094618000000000','0.072919080806206','0.074828992415882','0.7908536686030391','0.790853668603039','test'),('2019-03-19 15:59:59','2019-03-19 19:59:59','BTGETH','4h','0.095193000000000','0.094786000000000','0.072919080806206','0.072607313492558','0.7660130556470118','0.766013055647012','test'),('2019-03-19 23:59:59','2019-03-20 03:59:59','BTGETH','4h','0.095005000000000','0.095462000000000','0.072919080806206','0.073269841502258','0.7675288753876743','0.767528875387674','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','BTGETH','4h','0.095195000000000','0.094522000000000','0.072919080806206','0.072403564850719','0.7659969620905089','0.765996962090509','test'),('2019-03-23 03:59:59','2019-03-23 07:59:59','BTGETH','4h','0.095752000000000','0.095837000000000','0.072919080806206','0.072983811797397','0.7615410728361391','0.761541072836139','test'),('2019-03-24 19:59:59','2019-03-25 07:59:59','BTGETH','4h','0.095830000000000','0.094799000000000','0.072919080806206','0.072134571025227','0.7609212230638214','0.760921223063821','test'),('2019-04-01 07:59:59','2019-04-02 07:59:59','BTGETH','4h','0.093577000000000','0.092681000000000','0.072919080806206','0.072220880432157','0.7792414888937026','0.779241488893703','test'),('2019-04-03 03:59:59','2019-04-08 15:59:59','BTGETH','4h','0.094732000000000','0.099821000000000','0.072919080806206','0.076836291487103','0.7697407508149939','0.769740750814994','test'),('2019-04-09 19:59:59','2019-04-09 23:59:59','BTGETH','4h','0.100782000000000','0.100260000000000','0.072919080806206','0.072541396694154','0.723532781709095','0.723532781709095','test'),('2019-04-10 03:59:59','2019-04-10 03:59:59','BTGETH','4h','0.100406000000000','0.100406000000000','0.072919080806206','0.072919080806206','0.7262422644683186','0.726242264468319','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  7:13:48
