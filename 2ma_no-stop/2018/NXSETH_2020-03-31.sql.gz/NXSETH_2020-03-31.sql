-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-28 15:59:59','2018-11-28 19:59:59','NXSETH','4h','0.002442000000000','0.002969000000000','0.072144500000000','0.087713767608518','29.54320229320229','29.543202293202292','test'),('2018-11-30 23:59:59','2018-12-01 11:59:59','NXSETH','4h','0.002534000000000','0.002547000000000','0.076036816902130','0.076426903176687','30.006636504392073','30.006636504392073','test'),('2018-12-04 03:59:59','2018-12-04 07:59:59','NXSETH','4h','0.002541000000000','0.002487000000000','0.076134338470769','0.074516371419442','29.96235280234898','29.962352802348981','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','NXSETH','4h','0.002578000000000','0.002544000000000','0.076134338470769','0.075130239359828','29.532326792385184','29.532326792385184','test'),('2018-12-28 03:59:59','2018-12-28 11:59:59','NXSETH','4h','0.002770000000000','0.002720000000000','0.076134338470769','0.074760072433391','27.48532074757004','27.485320747570039','test'),('2018-12-31 11:59:59','2018-12-31 15:59:59','NXSETH','4h','0.002729000000000','0.002569000000000','0.076134338470769','0.071670617637012','27.898255210981677','27.898255210981677','test'),('2019-01-05 23:59:59','2019-01-07 19:59:59','NXSETH','4h','0.002544000000000','0.002484000000000','0.076134338470769','0.074338717280421','29.92701983913876','29.927019839138762','test'),('2019-01-14 23:59:59','2019-01-15 11:59:59','NXSETH','4h','0.002647000000000','0.002636000000000','0.076134338470769','0.075817950966735','28.762500366743105','28.762500366743105','test'),('2019-03-02 15:59:59','2019-03-05 19:59:59','NXSETH','4h','0.002213000000000','0.002305000000000','0.076134338470769','0.079299435235031','34.4032256984948','34.403225698494801','test'),('2019-03-27 07:59:59','2019-03-27 11:59:59','NXSETH','4h','0.002954000000000','0.002934000000000','0.076134338470769','0.075618872401231','25.773303476902168','25.773303476902168','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','NXSETH','4h','0.002972000000000','0.002872000000000','0.076134338470769','0.073572617795440','25.617206753287014','25.617206753287014','test'),('2019-03-28 23:59:59','2019-03-29 11:59:59','NXSETH','4h','0.002949000000000','0.002901000000000','0.076134338470769','0.074895122381723','25.817001855126826','25.817001855126826','test'),('2019-04-27 03:59:59','2019-04-27 07:59:59','NXSETH','4h','0.002224000000000','0.002199000000000','0.076134338470769','0.075278511824290','34.23306585915873','34.233065859158728','test'),('2019-04-28 11:59:59','2019-04-28 15:59:59','NXSETH','4h','0.002195000000000','0.002180000000000','0.076134338470769','0.075614058253429','34.685347822673805','34.685347822673805','test'),('2019-04-29 19:59:59','2019-04-29 23:59:59','NXSETH','4h','0.002207000000000','0.002150000000000','0.076134338470769','0.074168023430971','34.496755084172634','34.496755084172634','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','NXSETH','4h','0.001529000000000','0.001522000000000','0.076134338470769','0.075785783618385','49.79355034059451','49.793550340594507','test'),('2019-06-02 15:59:59','2019-06-03 03:59:59','NXSETH','4h','0.001446000000000','0.001406000000000','0.076134338470769','0.074028271016529','52.65168635599516','52.651686355995160','test'),('2019-06-05 23:59:59','2019-06-06 15:59:59','NXSETH','4h','0.001408000000000','0.001421000000000','0.076134338470769','0.076837283357218','54.07268357298935','54.072683572989348','test'),('2019-06-19 15:59:59','2019-06-19 23:59:59','NXSETH','4h','0.001415000000000','0.001383000000000','0.076134338470769','0.074412572512419','53.80518619842332','53.805186198423321','test'),('2019-06-20 07:59:59','2019-06-20 15:59:59','NXSETH','4h','0.001424000000000','0.001388000000000','0.076134338470769','0.074209593958868','53.465125330596216','53.465125330596216','test'),('2019-07-12 15:59:59','2019-07-12 23:59:59','NXSETH','4h','0.001042000000000','0.001018000000000','0.076134338470769','0.074380764456087','73.06558394507582','73.065583945075815','test'),('2019-07-13 23:59:59','2019-07-14 03:59:59','NXSETH','4h','0.001035000000000','0.000993000000000','0.076134338470769','0.073044829083549','73.55974731475267','73.559747314752670','test'),('2019-07-14 07:59:59','2019-07-14 11:59:59','NXSETH','4h','0.001066000000000','0.001043000000000','0.076134338470769','0.074491665126653','71.42058017895778','71.420580178957778','test'),('2019-07-16 11:59:59','2019-07-17 11:59:59','NXSETH','4h','0.001074000000000','0.001053000000000','0.076134338470769','0.074645678221341','70.88858330611639','70.888583306116388','test'),('2019-07-19 03:59:59','2019-07-20 07:59:59','NXSETH','4h','0.001080000000000','0.001080000000000','0.076134338470769','0.076134338470769','70.49475784330463','70.494757843304626','test'),('2019-08-08 23:59:59','2019-08-09 23:59:59','NXSETH','4h','0.001188000000000','0.001178000000000','0.076134338470769','0.075493477035830','64.0861434939133','64.086143493913298','test'),('2019-08-11 23:59:59','2019-08-12 03:59:59','NXSETH','4h','0.001157000000000','0.001143000000000','0.076134338470769','0.075213093234303','65.80323117611842','65.803231176118416','test'),('2019-08-15 11:59:59','2019-08-19 07:59:59','NXSETH','4h','0.001173000000000','0.001136000000000','0.076134338470769','0.073732829073140','64.90565939537','64.905659395369995','test'),('2019-08-21 03:59:59','2019-08-21 11:59:59','NXSETH','4h','0.001168000000000','0.001151000000000','0.076134338470769','0.075026218818369','65.18350896469948','65.183508964699485','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','NXSETH','4h','0.001192000000000','0.001160000000000','0.076134338470769','0.074090463612493','63.87108932111494','63.871089321114937','test'),('2019-08-22 19:59:59','2019-08-25 15:59:59','NXSETH','4h','0.001173000000000','0.001227000000000','0.076134338470769','0.079639244078119','64.90565939537','64.905659395369995','test'),('2019-09-02 23:59:59','2019-09-03 03:59:59','NXSETH','4h','0.001308000000000','0.001271000000000','0.076134338470769','0.073980691281611','58.2066807880497','58.206680788049702','test'),('2019-09-03 07:59:59','2019-09-03 11:59:59','NXSETH','4h','0.001303000000000','0.001296000000000','0.076134338470769','0.075725328210373','58.430037199362246','58.430037199362246','test'),('2019-09-10 19:59:59','2019-09-10 23:59:59','NXSETH','4h','0.001275000000000','0.001244000000000','0.076134338470769','0.074283229064813','59.71320664374039','59.713206643740392','test'),('2019-09-11 11:59:59','2019-09-11 15:59:59','NXSETH','4h','0.001257000000000','0.001240000000000','0.076134338470769','0.075104677568619','60.56828836178918','60.568288361789179','test'),('2019-09-22 03:59:59','2019-09-22 07:59:59','NXSETH','4h','0.001146000000000','0.001102000000000','0.076134338470769','0.073211205056534','66.43485032353315','66.434850323533155','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','NXSETH','4h','0.001140000000000','0.001097000000000','0.076134338470769','0.073262604651258','66.78450743049913','66.784507430499133','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','NXSETH','4h','0.001129000000000','0.001059000000000','0.076134338470769','0.071413874615185','67.43519793690788','67.435197936907883','test'),('2019-09-29 07:59:59','2019-09-29 15:59:59','NXSETH','4h','0.001089000000000','0.001028000000000','0.076134338470769','0.071869696921901','69.91215653881451','69.912156538814514','test'),('2019-10-01 15:59:59','2019-10-03 03:59:59','NXSETH','4h','0.001098000000000','0.001080000000000','0.076134338470769','0.074886234561412','69.33910607538161','69.339106075381608','test'),('2019-10-08 15:59:59','2019-10-08 19:59:59','NXSETH','4h','0.001116000000000','0.001195000000000','0.076134338470769','0.081523776409112','68.22073339674641','68.220733396746411','test'),('2019-10-13 11:59:59','2019-10-13 15:59:59','NXSETH','4h','0.001107000000000','0.001054000000000','0.076134338470769','0.072489243674969','68.77537350566305','68.775373505663055','test'),('2019-10-16 07:59:59','2019-10-16 11:59:59','NXSETH','4h','0.001082000000000','0.001074000000000','0.076134338470769','0.075571422844368','70.36445330015619','70.364453300156185','test'),('2019-10-17 07:59:59','2019-11-04 23:59:59','NXSETH','4h','0.001127000000000','0.001791000000000','0.076134338470769','0.120990772139439','67.55486998293613','67.554869982936125','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  4:34:38
