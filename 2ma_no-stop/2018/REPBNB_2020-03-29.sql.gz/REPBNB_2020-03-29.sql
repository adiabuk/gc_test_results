-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-06 19:59:59','2018-11-07 03:59:59','REPBNB','4h','1.504000000000000','1.495000000000000','0.711908500000000','0.707648409242021','0.47334341755319154','0.473343417553192','test'),('2018-11-08 19:59:59','2018-11-11 03:59:59','REPBNB','4h','1.522000000000000','1.506000000000000','0.711908500000000','0.704424573587385','0.4677454007884363','0.467745400788436','test'),('2018-11-20 19:59:59','2018-11-20 23:59:59','REPBNB','4h','1.446000000000000','1.463000000000000','0.711908500000000','0.720278102005533','0.4923295297372061','0.492329529737206','test'),('2018-12-02 23:59:59','2018-12-03 07:59:59','REPBNB','4h','1.599000000000000','1.567000000000000','0.711908500000000','0.697661425578487','0.44522107567229524','0.445221075672295','test'),('2018-12-19 07:59:59','2018-12-19 15:59:59','REPBNB','4h','1.342000000000000','1.253000000000000','0.711908500000000','0.664695492175857','0.5304832339791357','0.530483233979136','test'),('2018-12-20 19:59:59','2018-12-21 07:59:59','REPBNB','4h','1.308000000000000','1.273000000000000','0.711908500000000','0.692858960626911','0.5442725535168196','0.544272553516820','test'),('2018-12-21 19:59:59','2018-12-21 23:59:59','REPBNB','4h','1.294000000000000','1.299000000000000','0.711908500000000','0.714659305641422','0.5501611282843896','0.550161128284390','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','REPBNB','4h','1.321000000000000','1.368000000000000','0.711908500000000','0.737237568508706','0.5389163512490538','0.538916351249054','test'),('2018-12-29 03:59:59','2018-12-29 19:59:59','REPBNB','4h','1.483000000000000','1.371000000000000','0.711908500000000','0.658143326702630','0.48004619015509103','0.480046190155091','test'),('2019-01-02 03:59:59','2019-01-08 11:59:59','REPBNB','4h','1.381000000000000','1.465000000000000','0.711908500000000','0.755210682476466','0.515502172338885','0.515502172338885','test'),('2019-01-14 19:59:59','2019-01-23 15:59:59','REPBNB','4h','1.728000000000000','2.325000000000000','0.711908500000000','0.957862999131945','0.4119840856481482','0.411984085648148','test'),('2019-01-24 23:59:59','2019-01-25 03:59:59','REPBNB','4h','2.302000000000000','2.190000000000000','0.756830336419341','0.720008009017531','0.32877078037330176','0.328770780373302','test'),('2019-02-02 03:59:59','2019-02-04 07:59:59','REPBNB','4h','2.036000000000000','2.043000000000000','0.756830336419341','0.759432405355950','0.3717241338012481','0.371724133801248','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','REPBNB','4h','0.996000000000000','0.976000000000000','0.756830336419341','0.741632940105700','0.7598698156820693','0.759869815682069','test'),('2019-03-18 11:59:59','2019-03-18 15:59:59','REPBNB','4h','0.975000000000000','0.954000000000000','0.756830336419341','0.740529375327232','0.7762362424813755','0.776236242481375','test'),('2019-03-18 19:59:59','2019-03-19 03:59:59','REPBNB','4h','0.979000000000000','0.960000000000000','0.756830336419341','0.742142107214063','0.7730646950146487','0.773064695014649','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','REPBNB','4h','0.983000000000000','0.971000000000000','0.756830336419341','0.747591308914731','0.7699189587175392','0.769918958717539','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','REPBNB','4h','0.980000000000000','0.962000000000000','0.756830336419341','0.742929371056537','0.7722758534891235','0.772275853489124','test'),('2019-03-30 03:59:59','2019-03-31 03:59:59','REPBNB','4h','1.013000000000000','0.894000000000000','0.756830336419341','0.667923317629705','0.7471178049549271','0.747117804954927','test'),('2019-04-03 03:59:59','2019-04-11 03:59:59','REPBNB','4h','1.166000000000000','1.037000000000000','0.756830336419341','0.673098678273462','0.6490826212858843','0.649082621285884','test'),('2019-04-12 03:59:59','2019-04-12 19:59:59','REPBNB','4h','1.073000000000000','1.083000000000000','0.756830336419341','0.763883741232196','0.7053404812854996','0.705340481285500','test'),('2019-04-18 03:59:59','2019-04-18 07:59:59','REPBNB','4h','1.139000000000000','1.060000000000000','0.756830336419341','0.704337275333188','0.6644691276728192','0.664469127672819','test'),('2019-04-25 11:59:59','2019-04-25 23:59:59','REPBNB','4h','0.973000000000000','0.964000000000000','0.756830336419341','0.749829850265411','0.7778317948811316','0.777831794881132','test'),('2019-04-26 15:59:59','2019-04-26 19:59:59','REPBNB','4h','0.996000000000000','0.961000000000000','0.756830336419341','0.730234892870469','0.7598698156820693','0.759869815682069','test'),('2019-04-30 11:59:59','2019-04-30 15:59:59','REPBNB','4h','0.970000000000000','0.953000000000000','0.756830336419341','0.743566299595497','0.7802374602261248','0.780237460226125','test'),('2019-04-30 23:59:59','2019-05-01 03:59:59','REPBNB','4h','0.962000000000000','0.940000000000000','0.756830336419341','0.739522366147797','0.7867259214338265','0.786725921433826','test'),('2019-05-06 23:59:59','2019-05-07 23:59:59','REPBNB','4h','0.940000000000000','0.975000000000000','0.756830336419341','0.785010189371125','0.8051386557652565','0.805138655765256','test'),('2019-06-08 19:59:59','2019-06-08 23:59:59','REPBNB','4h','0.601000000000000','0.606000000000000','0.756830336419341','0.763126761847123','1.259285085556308','1.259285085556308','test'),('2019-06-16 19:59:59','2019-06-17 07:59:59','REPBNB','4h','0.582000000000000','0.558000000000000','0.756830336419341','0.725620838010296','1.3003957670435413','1.300395767043541','test'),('2019-06-27 11:59:59','2019-06-27 19:59:59','REPBNB','4h','0.549000000000000','0.501000000000000','0.756830336419341','0.690659378043879','1.3785616328221146','1.378561632822115','test'),('2019-07-09 15:59:59','2019-07-12 03:59:59','REPBNB','4h','0.494000000000000','0.459600000000000','0.756830336419341','0.704127981008764','1.5320452154237674','1.532045215423767','test'),('2019-07-12 23:59:59','2019-07-13 23:59:59','REPBNB','4h','0.483500000000000','0.467400000000000','0.756830336419341','0.731628747140434','1.5653161042799195','1.565316104279920','test'),('2019-07-14 03:59:59','2019-07-14 11:59:59','REPBNB','4h','0.472100000000000','0.475100000000000','0.756830336419341','0.761639679798409','1.6031144596893476','1.603114459689348','test'),('2019-07-29 19:59:59','2019-07-31 11:59:59','REPBNB','4h','0.414100000000000','0.411500000000000','0.756830336419341','0.752078443459451','1.82765113841908','1.827651138419080','test'),('2019-07-31 19:59:59','2019-08-01 07:59:59','REPBNB','4h','0.419000000000000','0.417000000000000','0.756830336419341','0.753217781114237','1.8062776525521267','1.806277652552127','test'),('2019-08-05 07:59:59','2019-08-06 03:59:59','REPBNB','4h','0.446600000000000','0.400000000000000','0.756830336419341','0.677859683313337','1.694649208283343','1.694649208283343','test'),('2019-08-06 15:59:59','2019-08-06 19:59:59','REPBNB','4h','0.417000000000000','0.396400000000000','0.756830336419341','0.719442554812055','1.8149408547226404','1.814940854722640','test'),('2019-08-07 11:59:59','2019-08-07 15:59:59','REPBNB','4h','0.421100000000000','0.383500000000000','0.756830336419341','0.689252989828585','1.7972698561371196','1.797269856137120','test'),('2019-08-20 03:59:59','2019-08-20 19:59:59','REPBNB','4h','0.370100000000000','0.361500000000000','0.756830336419341','0.739243897907570','2.044934710671011','2.044934710671011','test'),('2019-08-21 19:59:59','2019-08-23 15:59:59','REPBNB','4h','0.368400000000000','0.359400000000000','0.756830336419341','0.738340995953070','2.0543711629189496','2.054371162918950','test'),('2019-08-24 03:59:59','2019-08-26 03:59:59','REPBNB','4h','0.364100000000000','0.366100000000000','0.756830336419341','0.760987602755069','2.078633167864161','2.078633167864161','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','REPBNB','4h','0.372000000000000','0.369000000000000','0.756830336419341','0.750726865964346','2.034490151664895','2.034490151664895','test'),('2019-08-29 07:59:59','2019-08-29 11:59:59','REPBNB','4h','0.369900000000000','0.363900000000000','0.756830336419341','0.744554094141655','2.046040379614331','2.046040379614331','test'),('2019-08-29 15:59:59','2019-08-29 19:59:59','REPBNB','4h','0.366700000000000','0.367900000000000','0.504553557612894','0.506204673699983','1.3759300725740222','1.375930072574022','test'),('2019-08-31 11:59:59','2019-08-31 15:59:59','REPBNB','4h','0.369300000000000','0.366100000000000','0.566145529788603','0.561239855011123','1.5330233679626402','1.533023367962640','test'),('2019-08-31 19:59:59','2019-09-02 15:59:59','REPBNB','4h','0.368800000000000','0.360600000000000','0.566145529788603','0.553557695341026','1.5351017618996827','1.535101761899683','test'),('2019-09-02 19:59:59','2019-09-02 23:59:59','REPBNB','4h','0.371600000000000','0.358600000000000','0.566145529788603','0.546339577454771','1.5235347949101266','1.523534794910127','test'),('2019-09-03 15:59:59','2019-09-03 23:59:59','REPBNB','4h','0.376100000000000','0.366100000000000','0.566145529788603','0.551092471299143','1.505305848946033','1.505305848946033','test'),('2019-09-04 03:59:59','2019-09-05 19:59:59','REPBNB','4h','0.391400000000000','0.391400000000000','0.566145529788603','0.566145529788603','1.4464627741149794','1.446462774114979','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','REPBNB','4h','0.504900000000000','0.483200000000000','0.566145529788603','0.541813269942272','1.1213022970659596','1.121302297065960','test'),('2019-10-01 19:59:59','2019-10-01 23:59:59','REPBNB','4h','0.526000000000000','0.522000000000000','0.566145529788603','0.561840240588690','1.0763222999783326','1.076322299978333','test'),('2019-10-03 03:59:59','2019-10-03 07:59:59','REPBNB','4h','0.536300000000000','0.522000000000000','0.566145529788603','0.551049723195321','1.0556508107190061','1.055650810719006','test'),('2019-10-03 15:59:59','2019-10-04 03:59:59','REPBNB','4h','0.527400000000000','0.526000000000000','0.566145529788603','0.564642678552911','1.0734651683515415','1.073465168351541','test'),('2019-10-06 11:59:59','2019-10-07 11:59:59','REPBNB','4h','0.528200000000000','0.522000000000000','0.566145529788603','0.559500125993280','1.071839321826208','1.071839321826208','test'),('2019-10-08 07:59:59','2019-10-08 11:59:59','REPBNB','4h','0.526900000000000','0.526000000000000','0.566145529788603','0.565178494342010','1.0744838295475478','1.074483829547548','test'),('2019-10-08 23:59:59','2019-10-09 03:59:59','REPBNB','4h','0.528000000000000','0.532000000000000','0.566145529788603','0.570434511074880','1.0722453215693237','1.072245321569324','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 21:28:52
