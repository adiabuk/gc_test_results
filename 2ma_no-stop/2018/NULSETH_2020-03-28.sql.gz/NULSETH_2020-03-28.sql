-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-26 15:59:59','2018-04-26 23:59:59','NULSETH','4h','0.004693010000000','0.004596240000000','0.072144500000000','0.070656878353125','15.372756503821641','15.372756503821641','test'),('2018-05-09 11:59:59','2018-05-17 07:59:59','NULSETH','4h','0.005200000000000','0.006110090000000','0.072144500000000','0.084771036154808','13.873942307692309','13.873942307692309','test'),('2018-05-18 07:59:59','2018-05-19 07:59:59','NULSETH','4h','0.006166510000000','0.006141870000000','0.074929228626983','0.074629828124370','12.150994424234007','12.150994424234007','test'),('2018-05-20 19:59:59','2018-05-21 03:59:59','NULSETH','4h','0.006215670000000','0.005898390000000','0.074929228626983','0.071104452591774','12.054891689388754','12.054891689388754','test'),('2018-05-22 11:59:59','2018-05-23 19:59:59','NULSETH','4h','0.006229900000000','0.006167180000000','0.074929228626983','0.074174872823602','12.027356559011059','12.027356559011059','test'),('2018-05-24 23:59:59','2018-05-25 03:59:59','NULSETH','4h','0.006191970000000','0.005990000000000','0.074929228626983','0.072485183144561','12.101032244501022','12.101032244501022','test'),('2018-05-25 15:59:59','2018-05-25 23:59:59','NULSETH','4h','0.006326880000000','0.006390410000000','0.074929228626983','0.075681614304390','11.842998227717768','11.842998227717768','test'),('2018-05-29 11:59:59','2018-06-03 11:59:59','NULSETH','4h','0.006375310000000','0.006470950000000','0.074929228626983','0.076053288700279','11.753032970472493','11.753032970472493','test'),('2018-06-07 07:59:59','2018-06-07 11:59:59','NULSETH','4h','0.006440670000000','0.006239250000000','0.074929228626983','0.072585956074586','11.633763044370072','11.633763044370072','test'),('2018-06-10 19:59:59','2018-06-10 23:59:59','NULSETH','4h','0.006426690000000','0.006105280000000','0.074929228626983','0.071181886935848','11.659070007575128','11.659070007575128','test'),('2018-06-30 19:59:59','2018-07-01 11:59:59','NULSETH','4h','0.004829200000000','0.004805920000000','0.074929228626983','0.074568019225335','15.515867768363911','15.515867768363911','test'),('2018-07-07 19:59:59','2018-07-07 23:59:59','NULSETH','4h','0.004919210000000','0.005179440000000','0.074929228626983','0.078893042565725','15.231963796419139','15.231963796419139','test'),('2018-07-19 15:59:59','2018-07-20 03:59:59','NULSETH','4h','0.005600980000000','0.005480610000000','0.074929228626983','0.073318933419746','13.377878268978463','13.377878268978463','test'),('2018-07-22 19:59:59','2018-07-22 23:59:59','NULSETH','4h','0.005428440000000','0.005372420000000','0.074929228626983','0.074155979703225','13.803086821809396','13.803086821809396','test'),('2018-07-23 03:59:59','2018-07-23 19:59:59','NULSETH','4h','0.005817070000000','0.005390050000000','0.074929228626983','0.069428817043781','12.880922634072308','12.880922634072308','test'),('2018-07-24 15:59:59','2018-07-24 19:59:59','NULSETH','4h','0.005497020000000','0.005301610000000','0.074929228626983','0.072265618058712','13.630881573467622','13.630881573467622','test'),('2018-07-25 23:59:59','2018-07-26 07:59:59','NULSETH','4h','0.005447480000000','0.005480340000000','0.074929228626983','0.075381212746738','13.754842354076196','13.754842354076196','test'),('2018-07-27 07:59:59','2018-07-27 11:59:59','NULSETH','4h','0.005454000000000','0.005365960000000','0.074929228626983','0.073719699971259','13.738399088189036','13.738399088189036','test'),('2018-07-27 19:59:59','2018-07-27 23:59:59','NULSETH','4h','0.005450780000000','0.005408090000000','0.074929228626983','0.074342389904803','13.746514925750626','13.746514925750626','test'),('2018-07-28 15:59:59','2018-07-28 19:59:59','NULSETH','4h','0.005420000000000','0.005495040000000','0.074929228626983','0.075966625179782','13.824580927487636','13.824580927487636','test'),('2018-07-29 15:59:59','2018-07-30 11:59:59','NULSETH','4h','0.005433730000000','0.005413750000000','0.074929228626983','0.074653711443029','13.78964884655347','13.789648846553471','test'),('2018-08-12 11:59:59','2018-08-15 15:59:59','NULSETH','4h','0.004820970000000','0.004680000000000','0.074929228626983','0.072738222800449','15.54235529924123','15.542355299241230','test'),('2018-08-19 11:59:59','2018-08-20 07:59:59','NULSETH','4h','0.005013030000000','0.004996170000000','0.074929228626983','0.074677223992131','14.946894119321646','14.946894119321646','test'),('2018-08-22 07:59:59','2018-08-22 19:59:59','NULSETH','4h','0.005500000000000','0.004991930000000','0.074929228626983','0.068007538956345','13.623496113996909','13.623496113996909','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','NULSETH','4h','0.005510620000000','0.005261580000000','0.074929228626983','0.071542971709020','13.59724107758891','13.597241077588910','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','NULSETH','4h','0.005313700000000','0.005266910000000','0.074929228626983','0.074269436277498','14.101140189883319','14.101140189883319','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','NULSETH','4h','0.005313700000000','0.005207080000000','0.074929228626983','0.073425765059938','14.101140189883319','14.101140189883319','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','NULSETH','4h','0.005349240000000','0.005160370000000','0.074929228626983','0.072283640952701','14.007453138573515','14.007453138573515','test'),('2018-10-03 03:59:59','2018-10-03 07:59:59','NULSETH','4h','0.005244420000000','0.005223650000000','0.074929228626983','0.074632478923759','14.287419510066508','14.287419510066508','test'),('2018-10-03 15:59:59','2018-10-03 19:59:59','NULSETH','4h','0.005223930000000','0.005269350000000','0.074929228626983','0.075580708559570','14.34345954616218','14.343459546162180','test'),('2018-10-04 19:59:59','2018-10-04 23:59:59','NULSETH','4h','0.005248830000000','0.005349240000000','0.074929228626983','0.076362623087546','14.27541540247693','14.275415402476931','test'),('2018-10-07 15:59:59','2018-10-07 19:59:59','NULSETH','4h','0.005259200000000','0.005208070000000','0.074929228626983','0.074200765845629','14.247267384199686','14.247267384199686','test'),('2018-10-07 23:59:59','2018-10-08 03:59:59','NULSETH','4h','0.005293110000000','0.005234310000000','0.074929228626983','0.074096856232820','14.15599309800533','14.155993098005331','test'),('2018-10-15 19:59:59','2018-10-16 07:59:59','NULSETH','4h','0.005545040000000','0.005438790000000','0.074929228626983','0.073493489562591','13.51283825310241','13.512838253102410','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','NULSETH','4h','0.005468110000000','0.005443170000000','0.074929228626983','0.074587477096389','13.70294829968362','13.702948299683619','test'),('2018-10-16 23:59:59','2018-10-17 03:59:59','NULSETH','4h','0.005489750000000','0.005454300000000','0.074929228626983','0.074445373960591','13.64893276141591','13.648932761415910','test'),('2018-10-17 07:59:59','2018-10-18 23:59:59','NULSETH','4h','0.005495130000000','0.005505400000000','0.074929228626983','0.075069265928739','13.635569791248432','13.635569791248432','test'),('2018-10-26 15:59:59','2018-10-26 23:59:59','NULSETH','4h','0.005620000000000','0.005612570000000','0.074929228626983','0.074830167387001','13.3326029585379','13.332602958537899','test'),('2018-10-31 19:59:59','2018-11-03 03:59:59','NULSETH','4h','0.005749460000000','0.005643300000000','0.074929228626983','0.073545709668500','13.032394107791514','13.032394107791514','test'),('2018-11-23 15:59:59','2018-11-24 03:59:59','NULSETH','4h','0.004732710000000','0.004411830000000','0.074929228626983','0.069848991113629','15.832203669141569','15.832203669141569','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','NULSETH','4h','0.004447470000000','0.004335090000000','0.074929228626983','0.073035894503740','16.847607432311626','16.847607432311626','test'),('2018-11-29 03:59:59','2018-11-29 07:59:59','NULSETH','4h','0.004442610000000','0.004469570000000','0.074929228626983','0.075383937008719','16.866037898213662','16.866037898213662','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','NULSETH','4h','0.004427000000000','0.004488580000000','0.074929228626983','0.075971501475153','16.925509064147953','16.925509064147953','test'),('2018-12-01 15:59:59','2018-12-01 19:59:59','NULSETH','4h','0.004455920000000','0.004408000000000','0.074929228626983','0.074123422275925','16.815658411053832','16.815658411053832','test'),('2018-12-07 03:59:59','2018-12-07 11:59:59','NULSETH','4h','0.004579790000000','0.004636080000000','0.074929228626983','0.075850180522029','16.360843756369395','16.360843756369395','test'),('2018-12-11 19:59:59','2018-12-11 23:59:59','NULSETH','4h','0.004427090000000','0.004449130000000','0.074929228626983','0.075302259263121','16.925164979023016','16.925164979023016','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','NULSETH','4h','0.003000000000000','0.002915530000000','0.074929228626983','0.072819471312943','24.976409542327666','24.976409542327666','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','NULSETH','4h','0.002962680000000','0.002901590000000','0.074929228626983','0.073384199607034','25.29102995496746','25.291029954967460','test'),('2019-01-11 15:59:59','2019-01-14 15:59:59','NULSETH','4h','0.003000000000000','0.003000090000000','0.074929228626983','0.074931476503842','24.976409542327666','24.976409542327666','test'),('2019-01-15 19:59:59','2019-01-31 11:59:59','NULSETH','4h','0.003055700000000','0.003616280000000','0.074929228626983','0.088675285826222','24.52113382432274','24.521133824322739','test'),('2019-02-01 19:59:59','2019-02-02 19:59:59','NULSETH','4h','0.003804500000000','0.003768920000000','0.074929228626983','0.074228484257277','19.694895157572084','19.694895157572084','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','NULSETH','4h','0.003088870000000','0.003079630000000','0.074929228626983','0.074705086441487','24.257812283127162','24.257812283127162','test'),('2019-02-28 19:59:59','2019-03-01 19:59:59','NULSETH','4h','0.003081690000000','0.003087340000000','0.074929228626983','0.075066604593333','24.314330327509577','24.314330327509577','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','NULSETH','4h','0.003171020000000','0.003138760000000','0.074929228626983','0.074166944908966','23.62937749587924','23.629377495879240','test'),('2019-03-07 15:59:59','2019-03-07 23:59:59','NULSETH','4h','0.003149990000000','0.003158570000000','0.074929228626983','0.075133322221445','23.787132221684193','23.787132221684193','test'),('2019-04-15 07:59:59','2019-04-15 23:59:59','NULSETH','4h','0.005302640000000','0.005274420000000','0.074929228626983','0.074530464458219','14.130551692549936','14.130551692549936','test'),('2019-04-17 03:59:59','2019-04-17 11:59:59','NULSETH','4h','0.005312600000000','0.005192210000000','0.074929228626983','0.073231240855571','14.104059900422204','14.104059900422204','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','NULSETH','4h','0.005218180000000','0.005123170000000','0.074929228626983','0.073564954874094','14.359264844636058','14.359264844636058','test'),('2019-04-22 11:59:59','2019-04-22 15:59:59','NULSETH','4h','0.005202090000000','0.005074600000000','0.074929228626983','0.073092903734939','14.4036778731208','14.403677873120801','test'),('2019-04-23 07:59:59','2019-04-24 07:59:59','NULSETH','4h','0.005217480000000','0.005087380000000','0.074929228626983','0.073060837632792','14.361191346585516','14.361191346585516','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:33:38
