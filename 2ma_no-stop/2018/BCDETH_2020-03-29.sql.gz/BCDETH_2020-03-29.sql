-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-28 07:59:59','2018-05-28 19:59:59','BCDETH','4h','0.035840000000000','0.035220000000000','0.072144500000000','0.070896464564732','2.012960379464286','2.012960379464286','test'),('2018-06-04 19:59:59','2018-06-04 23:59:59','BCDETH','4h','0.034530000000000','0.034130000000000','0.072144500000000','0.071308768751810','2.0893281204749496','2.089328120474950','test'),('2018-07-01 19:59:59','2018-07-05 11:59:59','BCDETH','4h','0.028770000000000','0.027190000000000','0.072144500000000','0.068182445429267','2.5076294751477235','2.507629475147723','test'),('2018-07-07 11:59:59','2018-07-18 11:59:59','BCDETH','4h','0.028180000000000','0.033970000000000','0.072144500000000','0.086967660220014','2.5601312987934706','2.560131298793471','test'),('2018-07-29 19:59:59','2018-07-30 07:59:59','BCDETH','4h','0.038200000000000','0.037690000000000','0.074338834741456','0.073346352916374','1.9460427942789464','1.946042794278946','test'),('2018-08-12 11:59:59','2018-08-12 15:59:59','BCDETH','4h','0.033260000000000','0.032500000000000','0.074338834741456','0.072640172251874','2.2350822231345764','2.235082223134576','test'),('2018-08-12 23:59:59','2018-08-13 03:59:59','BCDETH','4h','0.033500000000000','0.032600000000000','0.074338834741456','0.072341672017059','2.219069693774806','2.219069693774806','test'),('2018-08-13 07:59:59','2018-08-13 11:59:59','BCDETH','4h','0.033170000000000','0.033250000000000','0.074338834741456','0.074518126474327','2.241146660882002','2.241146660882002','test'),('2018-08-14 11:59:59','2018-08-15 23:59:59','BCDETH','4h','0.033970000000000','0.032710000000000','0.074338834741456','0.071581492033942','2.18836722818534','2.188367228185340','test'),('2018-08-16 23:59:59','2018-08-18 07:59:59','BCDETH','4h','0.033520000000000','0.032860000000000','0.074338834741456','0.072875122601559','2.217745666511217','2.217745666511217','test'),('2018-08-18 19:59:59','2018-08-18 23:59:59','BCDETH','4h','0.033840000000000','0.034870000000000','0.074338834741456','0.076601512040029','2.1967740762841608','2.196774076284161','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','BCDETH','4h','0.008950000000000','0.008780000000000','0.074338834741456','0.072926812182121','8.306015054911285','8.306015054911285','test'),('2018-10-02 19:59:59','2018-10-02 23:59:59','BCDETH','4h','0.008740000000000','0.008720000000000','0.074338834741456','0.074168722991476','8.505587499022425','8.505587499022425','test'),('2018-10-06 11:59:59','2018-10-06 15:59:59','BCDETH','4h','0.008900000000000','0.008850000000000','0.074338834741456','0.073921200838414','8.352678060837754','8.352678060837754','test'),('2018-10-13 07:59:59','2018-10-13 11:59:59','BCDETH','4h','0.008740000000000','0.008590000000000','0.074338834741456','0.073062996616603','8.505587499022425','8.505587499022425','test'),('2018-10-14 03:59:59','2018-10-14 19:59:59','BCDETH','4h','0.008780000000000','0.008640000000000','0.074338834741456','0.073153477467674','8.466837669869705','8.466837669869705','test'),('2018-10-20 19:59:59','2018-10-20 23:59:59','BCDETH','4h','0.008540000000000','0.008560000000000','0.074338834741456','0.074512930373169','8.704781585650585','8.704781585650585','test'),('2018-10-21 11:59:59','2018-10-21 15:59:59','BCDETH','4h','0.008540000000000','0.008460000000000','0.074338834741456','0.073642452214604','8.704781585650585','8.704781585650585','test'),('2018-10-22 11:59:59','2018-10-27 03:59:59','BCDETH','4h','0.008790000000000','0.008970000000000','0.074338834741456','0.075861131698619','8.457205317571788','8.457205317571788','test'),('2018-11-04 07:59:59','2018-11-04 19:59:59','BCDETH','4h','0.009690000000000','0.008500000000000','0.074338834741456','0.065209504159172','7.671706371667286','7.671706371667286','test'),('2018-11-23 07:59:59','2018-11-23 11:59:59','BCDETH','4h','0.007630000000000','0.007520000000000','0.074338834741456','0.073267108421461','9.742966545407079','9.742966545407079','test'),('2018-11-23 15:59:59','2018-11-29 15:59:59','BCDETH','4h','0.008110000000000','0.008890000000000','0.074338834741456','0.081488562373803','9.166317477368189','9.166317477368189','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','BCDETH','4h','0.008760000000000','0.008790000000000','0.074338834741456','0.074593419791940','8.486168349481279','8.486168349481279','test'),('2018-12-03 11:59:59','2018-12-03 15:59:59','BCDETH','4h','0.008880000000000','0.008800000000000','0.074338834741456','0.073669115509551','8.371490398812613','8.371490398812613','test'),('2018-12-04 19:59:59','2018-12-04 23:59:59','BCDETH','4h','0.008750000000000','0.008750000000000','0.074338834741456','0.074338834741456','8.49586682759497','8.495866827594970','test'),('2018-12-14 07:59:59','2018-12-14 11:59:59','BCDETH','4h','0.008200000000000','0.007980000000000','0.074338834741456','0.072344378199612','9.065711553836097','9.065711553836097','test'),('2018-12-14 15:59:59','2018-12-16 19:59:59','BCDETH','4h','0.008830000000000','0.008350000000000','0.074338834741456','0.070297765582238','8.418894081705098','8.418894081705098','test'),('2018-12-20 11:59:59','2018-12-22 03:59:59','BCDETH','4h','0.009630000000000','0.008520000000000','0.074338834741456','0.065770184008017','7.7195051652602285','7.719505165260228','test'),('2019-01-10 07:59:59','2019-01-10 15:59:59','BCDETH','4h','0.006420000000000','0.006450000000000','0.074338834741456','0.074686212473893','11.579257747890342','11.579257747890342','test'),('2019-01-11 07:59:59','2019-01-14 15:59:59','BCDETH','4h','0.006390000000000','0.006530000000000','0.074338834741456','0.075967541605901','11.633620460321753','11.633620460321753','test'),('2019-01-15 23:59:59','2019-01-16 11:59:59','BCDETH','4h','0.006690000000000','0.006640000000000','0.074338834741456','0.073783238069248','11.111933444163826','11.111933444163826','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','BCDETH','4h','0.006530000000000','0.006570000000000','0.074338834741456','0.074794202795002','11.384201338660949','11.384201338660949','test'),('2019-01-19 07:59:59','2019-01-19 11:59:59','BCDETH','4h','0.006550000000000','0.006470000000000','0.074338834741456','0.073430879507973','11.349440418542901','11.349440418542901','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','BCDETH','4h','0.006550000000000','0.006820000000000','0.074338834741456','0.077403183654463','11.349440418542901','11.349440418542901','test'),('2019-01-27 19:59:59','2019-01-28 07:59:59','BCDETH','4h','0.006740000000000','0.006690000000000','0.074338834741456','0.073787359706282','11.029500703480117','11.029500703480117','test'),('2019-02-01 15:59:59','2019-02-01 23:59:59','BCDETH','4h','0.006740000000000','0.006710000000000','0.074338834741456','0.074007949720352','11.029500703480117','11.029500703480117','test'),('2019-02-26 03:59:59','2019-02-26 15:59:59','BCDETH','4h','0.005540000000000','0.005500000000000','0.074338834741456','0.073802092252348','13.41856222769964','13.418562227699640','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','BCDETH','4h','0.005470000000000','0.005430000000000','0.074338834741456','0.073795223518484','13.590280574306398','13.590280574306398','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','BCDETH','4h','0.005500000000000','0.005380000000000','0.074338834741456','0.072716896528915','13.516151771173819','13.516151771173819','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','BCDETH','4h','0.005470000000000','0.005480000000000','0.074338834741456','0.074474737547199','13.590280574306398','13.590280574306398','test'),('2019-03-10 07:59:59','2019-03-10 11:59:59','BCDETH','4h','0.005490000000000','0.005440000000000','0.074338834741456','0.073661796173683','13.540771355456465','13.540771355456465','test'),('2019-03-10 19:59:59','2019-03-10 23:59:59','BCDETH','4h','0.005530000000000','0.005490000000000','0.074338834741456','0.073801121651102','13.442827258852802','13.442827258852802','test'),('2019-03-28 19:59:59','2019-03-28 23:59:59','BCDETH','4h','0.006160000000000','0.006080000000000','0.074338834741456','0.073373395329229','12.067992652833768','12.067992652833768','test'),('2019-03-31 15:59:59','2019-04-02 15:59:59','BCDETH','4h','0.006360000000000','0.006170000000000','0.074338834741456','0.072118020496035','11.688496028530817','11.688496028530817','test'),('2019-04-03 03:59:59','2019-04-08 03:59:59','BCDETH','4h','0.006660000000000','0.006600000000000','0.074338834741456','0.073669115509551','11.161987198416817','11.161987198416817','test'),('2019-04-10 19:59:59','2019-04-11 03:59:59','BCDETH','4h','0.006950000000000','0.006700000000000','0.074338834741456','0.071664775937807','10.696235214597987','10.696235214597987','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','BCDETH','4h','0.006680000000000','0.006650000000000','0.074338834741456','0.074004977699204','11.128568075068264','11.128568075068264','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','BCDETH','4h','0.006670000000000','0.006650000000000','0.074338834741456','0.074115929689757','11.145252584925938','11.145252584925938','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 11:26:57
