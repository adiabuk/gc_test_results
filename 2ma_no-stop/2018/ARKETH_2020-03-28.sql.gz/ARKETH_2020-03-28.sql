-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-22 23:59:59','2018-04-23 03:59:59','ARKETH','4h','0.005336000000000','0.005563000000000','0.072144500000000','0.075213615723388','13.520333583208396','13.520333583208396','test'),('2018-04-26 15:59:59','2018-04-26 19:59:59','ARKETH','4h','0.005391000000000','0.005359000000000','0.072911778930847','0.072478987811243','13.524722487636245','13.524722487636245','test'),('2018-04-27 07:59:59','2018-04-27 11:59:59','ARKETH','4h','0.005245000000000','0.005122000000000','0.072911778930847','0.071201931684232','13.901197126948903','13.901197126948903','test'),('2018-04-27 19:59:59','2018-04-27 23:59:59','ARKETH','4h','0.005286000000000','0.005254000000000','0.072911778930847','0.072470390938833','13.793374750444002','13.793374750444002','test'),('2018-05-02 07:59:59','2018-05-02 11:59:59','ARKETH','4h','0.005365000000000','0.005354000000000','0.072911778930847','0.072762286001073','13.590266343121527','13.590266343121527','test'),('2018-05-02 19:59:59','2018-05-03 03:59:59','ARKETH','4h','0.005408000000000','0.005252000000000','0.072911778930847','0.070808554538611','13.482207642538276','13.482207642538276','test'),('2018-05-12 03:59:59','2018-05-12 07:59:59','ARKETH','4h','0.004700000000000','0.004663000000000','0.072911778930847','0.072337792586072','15.5131444533717','15.513144453371700','test'),('2018-05-30 07:59:59','2018-05-30 15:59:59','ARKETH','4h','0.004303000000000','0.004242000000000','0.072911778930847','0.071878170166082','16.944405979745987','16.944405979745987','test'),('2018-05-31 07:59:59','2018-05-31 11:59:59','ARKETH','4h','0.004271000000000','0.004167000000000','0.072911778930847','0.071136357481817','17.07136008682908','17.071360086829081','test'),('2018-05-31 15:59:59','2018-06-01 19:59:59','ARKETH','4h','0.004399000000000','0.004289000000000','0.072911778930847','0.071088570091931','16.574625808330754','16.574625808330754','test'),('2018-07-01 03:59:59','2018-07-02 07:59:59','ARKETH','4h','0.003247000000000','0.003036000000000','0.072911778930847','0.068173748332015','22.45512132148044','22.455121321480441','test'),('2018-07-17 19:59:59','2018-07-20 07:59:59','ARKETH','4h','0.003086000000000','0.003011000000000','0.072911778930847','0.071139781711206','23.626629595219374','23.626629595219374','test'),('2018-08-10 15:59:59','2018-08-10 19:59:59','ARKETH','4h','0.002354000000000','0.002337000000000','0.072911778930847','0.072385228275866','30.973567940036954','30.973567940036954','test'),('2018-08-11 19:59:59','2018-08-12 03:59:59','ARKETH','4h','0.002345000000000','0.002330000000000','0.072911778930847','0.072445392285234','31.09244304087292','31.092443040872919','test'),('2018-08-17 07:59:59','2018-08-17 11:59:59','ARKETH','4h','0.002265000000000','0.002281000000000','0.072911778930847','0.073426829024840','32.19063087454613','32.190630874546130','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','ARKETH','4h','0.002283000000000','0.002260000000000','0.072911778930847','0.072177231880733','31.93682826581121','31.936828265811211','test'),('2018-08-19 15:59:59','2018-08-19 19:59:59','ARKETH','4h','0.002341000000000','0.002266000000000','0.072911778930847','0.070575861194916','31.14556981240794','31.145569812407938','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ARKETH','4h','0.002999000000000','0.002993000000000','0.072911778930847','0.072765906748925','24.312030320389127','24.312030320389127','test'),('2018-09-04 07:59:59','2018-09-05 15:59:59','ARKETH','4h','0.003020000000000','0.003035000000000','0.072911778930847','0.073273923528186','24.1429731559096','24.142973155909601','test'),('2018-09-06 23:59:59','2018-09-07 03:59:59','ARKETH','4h','0.003030000000000','0.002990000000000','0.072911778930847','0.071949247195786','24.06329337651716','24.063293376517159','test'),('2018-09-07 07:59:59','2018-09-13 07:59:59','ARKETH','4h','0.003044000000000','0.003223000000000','0.072911778930847','0.077199298125532','23.952621199358408','23.952621199358408','test'),('2018-09-14 15:59:59','2018-09-14 19:59:59','ARKETH','4h','0.003311000000000','0.003035000000000','0.072911778930847','0.066833962263703','22.021074880956505','22.021074880956505','test'),('2018-09-16 07:59:59','2018-09-16 11:59:59','ARKETH','4h','0.003184000000000','0.003082000000000','0.072911778930847','0.070576037269118','22.899428056170535','22.899428056170535','test'),('2018-09-16 15:59:59','2018-09-17 15:59:59','ARKETH','4h','0.003381000000000','0.003171000000000','0.072911778930847','0.068383097009676','21.565152005574387','21.565152005574387','test'),('2018-09-20 03:59:59','2018-09-20 07:59:59','ARKETH','4h','0.003198000000000','0.003214000000000','0.072911778930847','0.073276565817305','22.799180403641962','22.799180403641962','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','ARKETH','4h','0.003182000000000','0.003110000000000','0.072911778930847','0.071261983807333','22.913821159914203','22.913821159914203','test'),('2018-09-25 03:59:59','2018-09-25 11:59:59','ARKETH','4h','0.003170000000000','0.003195000000000','0.072911778930847','0.073486792960270','23.00056117692334','23.000561176923341','test'),('2018-09-28 23:59:59','2018-09-29 11:59:59','ARKETH','4h','0.003203000000000','0.003069000000000','0.072911778930847','0.069861457864118','22.763590050217605','22.763590050217605','test'),('2018-10-01 23:59:59','2018-10-02 03:59:59','ARKETH','4h','0.003154000000000','0.003160000000000','0.072911778930847','0.073050482378401','23.117241258987633','23.117241258987633','test'),('2018-10-04 23:59:59','2018-10-05 03:59:59','ARKETH','4h','0.003153000000000','0.003184000000000','0.072911778930847','0.073628640696421','23.124573083046936','23.124573083046936','test'),('2018-10-07 11:59:59','2018-10-08 19:59:59','ARKETH','4h','0.003187000000000','0.003160000000000','0.072911778930847','0.072294076379503','22.87787227199466','22.877872271994661','test'),('2018-10-15 15:59:59','2018-10-27 23:59:59','ARKETH','4h','0.003468000000000','0.003842000000000','0.072911778930847','0.080774813913585','21.024157707856688','21.024157707856688','test'),('2018-10-28 19:59:59','2018-10-29 03:59:59','ARKETH','4h','0.003862000000000','0.003833000000000','0.072911778930847','0.072364279814070','18.87927988887804','18.879279888878042','test'),('2018-11-21 03:59:59','2018-11-21 23:59:59','ARKETH','4h','0.003116000000000','0.003089000000000','0.072911778930847','0.072280001642293','23.39915883531675','23.399158835316751','test'),('2018-11-25 23:59:59','2018-11-26 19:59:59','ARKETH','4h','0.003411000000000','0.003453000000000','0.072911778930847','0.073809549295871','21.375484881514804','21.375484881514804','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','ARKETH','4h','0.003453000000000','0.003510000000000','0.072911778930847','0.074115361728142','21.115487671835215','21.115487671835215','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','ARKETH','4h','0.003712000000000','0.003784000000000','0.072911778930847','0.074326016022178','19.642181824042833','19.642181824042833','test'),('2018-12-09 11:59:59','2018-12-09 15:59:59','ARKETH','4h','0.003652000000000','0.003691000000000','0.072911778930847','0.073690409647797','19.964890178216592','19.964890178216592','test'),('2018-12-14 11:59:59','2018-12-14 15:59:59','ARKETH','4h','0.003599000000000','0.003543000000000','0.072911778930847','0.071777280564599','20.258899397290076','20.258899397290076','test'),('2018-12-16 23:59:59','2018-12-18 03:59:59','ARKETH','4h','0.003653000000000','0.003588000000000','0.072911778930847','0.071614416316419','19.95942483735204','19.959424837352039','test'),('2018-12-19 15:59:59','2018-12-19 19:59:59','ARKETH','4h','0.003585000000000','0.003680000000000','0.072911778930847','0.074843890227480','20.338013648771824','20.338013648771824','test'),('2018-12-22 03:59:59','2018-12-22 07:59:59','ARKETH','4h','0.003596000000000','0.003606000000000','0.072911778930847','0.073114536936773','20.275800592560344','20.275800592560344','test'),('2018-12-22 19:59:59','2018-12-22 23:59:59','ARKETH','4h','0.003598000000000','0.003502000000000','0.072911778930847','0.070966384051091','20.264529997456084','20.264529997456084','test'),('2019-01-04 11:59:59','2019-01-04 15:59:59','ARKETH','4h','0.003107000000000','0.002999000000000','0.072911778930847','0.070377349537692','23.466938825505952','23.466938825505952','test'),('2019-01-06 19:59:59','2019-01-07 07:59:59','ARKETH','4h','0.002998000000000','0.002920000000000','0.072911778930847','0.071014808031379','24.320139736773516','24.320139736773516','test'),('2019-01-07 15:59:59','2019-01-07 19:59:59','ARKETH','4h','0.002948000000000','0.002973000000000','0.072911778930847','0.073530094559501','24.732625146148912','24.732625146148912','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','ARKETH','4h','0.003105000000000','0.003116000000000','0.072911778930847','0.073170081529314','23.482054406069885','23.482054406069885','test'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ARKETH','4h','0.003100000000000','0.003123000000000','0.072911778930847','0.073452737290657','23.519928687369998','23.519928687369998','test'),('2019-02-08 15:59:59','2019-02-09 11:59:59','ARKETH','4h','0.004223000000000','0.003526000000000','0.072911778930847','0.060877796000513','17.265398752272553','17.265398752272553','test'),('2019-02-10 11:59:59','2019-02-15 11:59:59','ARKETH','4h','0.004389000000000','0.003962000000000','0.072911778930847','0.065818288476650','16.61238982247596','16.612389822475961','test'),('2019-02-17 03:59:59','2019-02-18 03:59:59','ARKETH','4h','0.003966000000000','0.004236000000000','0.072911778930847','0.077875515771827','18.384210522150024','18.384210522150024','test'),('2019-02-21 15:59:59','2019-02-21 19:59:59','ARKETH','4h','0.004287000000000','0.004269000000000','0.072911778930847','0.072605641300627','17.007646123360622','17.007646123360622','test'),('2019-02-22 15:59:59','2019-02-22 19:59:59','ARKETH','4h','0.004290000000000','0.004311000000000','0.072911778930847','0.073268689736802','16.995752664533097','16.995752664533097','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ARKETH','4h','0.004223000000000','0.004144000000000','0.072911778930847','0.071547812429417','17.265398752272553','17.265398752272553','test'),('2019-02-27 03:59:59','2019-02-27 11:59:59','ARKETH','4h','0.004336000000000','0.004505000000000','0.072911778930847','0.075753589502644','16.815447170398294','16.815447170398294','test'),('2019-02-28 23:59:59','2019-03-01 15:59:59','ARKETH','4h','0.004281000000000','0.004190000000000','0.072911778930847','0.071361913973429','17.03148304855104','17.031483048551038','test'),('2019-03-01 23:59:59','2019-03-02 15:59:59','ARKETH','4h','0.004232000000000','0.004209000000000','0.072911778930847','0.072515519262745','17.228681221844756','17.228681221844756','test'),('2019-03-05 03:59:59','2019-03-05 07:59:59','ARKETH','4h','0.004238000000000','0.004215000000000','0.072911778930847','0.072516080272185','17.20428950704271','17.204289507042709','test'),('2019-03-09 15:59:59','2019-03-11 07:59:59','ARKETH','4h','0.004184000000000','0.004257000000000','0.072911778930847','0.074183901268790','17.426333396473947','17.426333396473947','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','ARKETH','4h','0.004569000000000','0.004560000000000','0.072911778930847','0.072768157567227','15.957929291058655','15.957929291058655','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','ARKETH','4h','0.004616000000000','0.004551000000000','0.072911778930847','0.071885074938103','15.79544604221122','15.795446042211220','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','ARKETH','4h','0.004575000000000','0.004555000000000','0.072911778930847','0.072593038913663','15.937000859201529','15.937000859201529','test'),('2019-03-21 03:59:59','2019-03-21 07:59:59','ARKETH','4h','0.004602000000000','0.004608000000000','0.072911778930847','0.073006839920327','15.843498246598651','15.843498246598651','test'),('2019-03-22 03:59:59','2019-03-22 19:59:59','ARKETH','4h','0.004625000000000','0.004624000000000','0.072911778930847','0.072896014221889','15.764708958020972','15.764708958020972','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','ARKETH','4h','0.004604000000000','0.004609000000000','0.072911778930847','0.072990962009616','15.836615753876412','15.836615753876412','test'),('2019-03-26 07:59:59','2019-03-26 15:59:59','ARKETH','4h','0.004583000000000','0.004484000000000','0.072911778930847','0.071336769959834','15.909181525386645','15.909181525386645','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','ARKETH','4h','0.004621000000000','0.004617000000000','0.072911778930847','0.072848665510435','15.778355102974896','15.778355102974896','test'),('2019-03-30 15:59:59','2019-04-02 07:59:59','ARKETH','4h','0.004756000000000','0.004775000000000','0.072911778930847','0.073203058114969','15.330483374862698','15.330483374862698','test'),('2019-04-14 15:59:59','2019-04-14 23:59:59','ARKETH','4h','0.004068000000000','0.003997000000000','0.072911778930847','0.071639228216961','17.923249491358654','17.923249491358654','test'),('2019-04-15 11:59:59','2019-04-15 15:59:59','ARKETH','4h','0.003988000000000','0.003867000000000','0.072911778930847','0.070699560964289','18.28279311204789','18.282793112047891','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:19:31
