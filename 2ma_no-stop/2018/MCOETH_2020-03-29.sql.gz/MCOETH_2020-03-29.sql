-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-14 19:59:59','2018-02-14 23:59:59','MCOETH','4h','0.009331000000000','0.009314000000000','0.072144500000000','0.072013061086700','7.731700782338441','7.731700782338441','test'),('2018-02-27 19:59:59','2018-02-28 19:59:59','MCOETH','4h','0.009874000000000','0.009038000000000','0.072144500000000','0.066036255924651','7.3065120518533515','7.306512051853352','test'),('2018-03-01 11:59:59','2018-03-07 19:59:59','MCOETH','4h','0.009317000000000','0.009212000000000','0.072144500000000','0.071331451540195','7.743318664806267','7.743318664806267','test'),('2018-03-10 23:59:59','2018-03-11 03:59:59','MCOETH','4h','0.009887000000000','0.009730000000000','0.072144500000000','0.070998885910792','7.296905026802873','7.296905026802873','test'),('2018-03-18 03:59:59','2018-03-18 15:59:59','MCOETH','4h','0.011365000000000','0.011290000000000','0.072144500000000','0.071668403431588','6.347954245490541','6.347954245490541','test'),('2018-03-30 11:59:59','2018-03-30 19:59:59','MCOETH','4h','0.012280000000000','0.011720000000000','0.072144500000000','0.068854522801303','5.874959283387622','5.874959283387622','test'),('2018-03-31 23:59:59','2018-04-01 03:59:59','MCOETH','4h','0.011934000000000','0.012000000000000','0.072144500000000','0.072543489190548','6.045290765879001','6.045290765879001','test'),('2018-04-02 19:59:59','2018-04-02 23:59:59','MCOETH','4h','0.012073000000000','0.011925000000000','0.072144500000000','0.071260097945830','5.975689555205831','5.975689555205831','test'),('2018-04-10 07:59:59','2018-04-10 11:59:59','MCOETH','4h','0.012953000000000','0.012980000000000','0.072144500000000','0.072294882266656','5.5697135798656685','5.569713579865669','test'),('2018-04-12 19:59:59','2018-04-12 23:59:59','MCOETH','4h','0.012968000000000','0.012643000000000','0.072144500000000','0.070336436883097','5.563271128932757','5.563271128932757','test'),('2018-04-27 07:59:59','2018-04-27 11:59:59','MCOETH','4h','0.019183000000000','0.017833000000000','0.072144500000000','0.067067344445603','3.760855966220091','3.760855966220091','test'),('2018-05-14 15:59:59','2018-05-14 19:59:59','MCOETH','4h','0.014962000000000','0.015466000000000','0.072144500000000','0.074574711736399','4.821848683331106','4.821848683331106','test'),('2018-05-16 07:59:59','2018-05-16 11:59:59','MCOETH','4h','0.015309000000000','0.014437000000000','0.072144500000000','0.068035152296035','4.712554706381867','4.712554706381867','test'),('2018-06-22 19:59:59','2018-06-23 03:59:59','MCOETH','4h','0.010300000000000','0.010248000000000','0.072144500000000','0.071780275339806','7.004320388349514','7.004320388349514','test'),('2018-06-23 15:59:59','2018-06-23 19:59:59','MCOETH','4h','0.010201000000000','0.010129000000000','0.072144500000000','0.071635294627978','7.072296833643761','7.072296833643761','test'),('2018-06-23 23:59:59','2018-06-24 03:59:59','MCOETH','4h','0.010221000000000','0.010023000000000','0.072144500000000','0.070746925300851','7.058458076509148','7.058458076509148','test'),('2018-06-24 07:59:59','2018-06-24 11:59:59','MCOETH','4h','0.010232000000000','0.010324000000000','0.072144500000000','0.072793180023456','7.05086982017201','7.050869820172010','test'),('2018-07-16 07:59:59','2018-07-16 15:59:59','MCOETH','4h','0.016147000000000','0.015918000000000','0.072144500000000','0.071121332197931','4.467981668421378','4.467981668421378','test'),('2018-07-19 11:59:59','2018-07-19 15:59:59','MCOETH','4h','0.016246000000000','0.016051000000000','0.072144500000000','0.071278552843777','4.440754647297797','4.440754647297797','test'),('2018-07-21 23:59:59','2018-07-22 03:59:59','MCOETH','4h','0.016283000000000','0.016110000000000','0.072144500000000','0.071377995148314','4.430663882576921','4.430663882576921','test'),('2018-07-25 11:59:59','2018-07-25 15:59:59','MCOETH','4h','0.016507000000000','0.016039000000000','0.072144500000000','0.070099087387169','4.370539771006239','4.370539771006239','test'),('2018-07-26 07:59:59','2018-07-26 11:59:59','MCOETH','4h','0.016257000000000','0.016181000000000','0.072144500000000','0.071807231008181','4.437749892354063','4.437749892354063','test'),('2018-07-26 19:59:59','2018-07-26 23:59:59','MCOETH','4h','0.016395000000000','0.015742000000000','0.072144500000000','0.069271041110095','4.4003964623360785','4.400396462336079','test'),('2018-07-27 23:59:59','2018-07-28 03:59:59','MCOETH','4h','0.016274000000000','0.015920000000000','0.072144500000000','0.070575177583876','4.433114169841465','4.433114169841465','test'),('2018-07-29 07:59:59','2018-07-29 11:59:59','MCOETH','4h','0.016130000000000','0.015936000000000','0.072144500000000','0.071276798016119','4.472690638561687','4.472690638561687','test'),('2018-07-30 03:59:59','2018-07-30 19:59:59','MCOETH','4h','0.016436000000000','0.016503000000000','0.072144500000000','0.072438591110976','4.389419566804576','4.389419566804576','test'),('2018-08-01 07:59:59','2018-08-01 15:59:59','MCOETH','4h','0.016338000000000','0.016454000000000','0.072144500000000','0.072656726833150','4.415748561635452','4.415748561635452','test'),('2018-08-11 03:59:59','2018-08-11 07:59:59','MCOETH','4h','0.015894000000000','0.015593000000000','0.072144500000000','0.070778230055367','4.539102806090349','4.539102806090349','test'),('2018-08-11 19:59:59','2018-08-11 23:59:59','MCOETH','4h','0.015854000000000','0.016591000000000','0.072144500000000','0.075498259082881','4.550555064967831','4.550555064967831','test'),('2018-08-17 15:59:59','2018-08-17 19:59:59','MCOETH','4h','0.016717000000000','0.016079000000000','0.072144500000000','0.069391123736316','4.315636776933661','4.315636776933661','test'),('2018-08-26 15:59:59','2018-08-27 11:59:59','MCOETH','4h','0.015843000000000','0.015900000000000','0.072144500000000','0.072404061730733','4.553714574259926','4.553714574259926','test'),('2018-08-29 15:59:59','2018-08-29 19:59:59','MCOETH','4h','0.016000000000000','0.015935000000000','0.072144500000000','0.071851412968750','4.50903125','4.509031250000000','test'),('2018-08-29 23:59:59','2018-08-30 03:59:59','MCOETH','4h','0.016079000000000','0.015894000000000','0.072144500000000','0.071314427700728','4.4868772933640155','4.486877293364016','test'),('2018-09-02 19:59:59','2018-09-02 23:59:59','MCOETH','4h','0.015907000000000','0.015751000000000','0.072144500000000','0.071436978657195','4.535393223109323','4.535393223109323','test'),('2018-09-03 03:59:59','2018-09-03 07:59:59','MCOETH','4h','0.015780000000000','0.015518000000000','0.072144500000000','0.070946663561470','4.571894803548796','4.571894803548796','test'),('2018-09-03 11:59:59','2018-09-03 15:59:59','MCOETH','4h','0.015857000000000','0.015719000000000','0.072144500000000','0.071516642208488','4.549694141388661','4.549694141388661','test'),('2018-09-03 19:59:59','2018-09-14 03:59:59','MCOETH','4h','0.015850000000000','0.020616000000000','0.072144500000000','0.093837918738170','4.551703470031546','4.551703470031546','test'),('2018-09-14 23:59:59','2018-09-15 03:59:59','MCOETH','4h','0.020991000000000','0.020572000000000','0.072144500000000','0.070704428278786','3.4369253489590776','3.436925348959078','test'),('2018-09-17 19:59:59','2018-09-18 15:59:59','MCOETH','4h','0.021044000000000','0.020506000000000','0.072144500000000','0.070300091094849','3.4282693404295763','3.428269340429576','test'),('2018-09-19 23:59:59','2018-09-20 11:59:59','MCOETH','4h','0.020552000000000','0.020442000000000','0.072144500000000','0.071758362641105','3.5103396263137405','3.510339626313741','test'),('2018-09-25 07:59:59','2018-09-27 19:59:59','MCOETH','4h','0.020250000000000','0.019700000000000','0.072144500000000','0.070185019753086','3.5626913580246913','3.562691358024691','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','MCOETH','4h','0.020071000000000','0.019280000000000','0.072144500000000','0.069301278461462','3.594464650490758','3.594464650490758','test'),('2018-10-02 07:59:59','2018-10-02 11:59:59','MCOETH','4h','0.020007000000000','0.020003000000000','0.072144500000000','0.072130076148348','3.605962912980457','3.605962912980457','test'),('2018-10-09 15:59:59','2018-10-09 19:59:59','MCOETH','4h','0.020047000000000','0.020055000000000','0.072144500000000','0.072173290143164','3.598767895445703','3.598767895445703','test'),('2018-10-17 15:59:59','2018-10-19 11:59:59','MCOETH','4h','0.020676000000000','0.021922000000000','0.072144500000000','0.076492151721803','3.4892870961501257','3.489287096150126','test'),('2018-11-04 03:59:59','2018-11-04 07:59:59','MCOETH','4h','0.022722000000000','0.022246000000000','0.072144500000000','0.070633154959951','3.175094621952293','3.175094621952293','test'),('2018-11-16 07:59:59','2018-11-17 07:59:59','MCOETH','4h','0.021553000000000','0.020923000000000','0.072144500000000','0.070035696817148','3.347306639446945','3.347306639446945','test'),('2018-11-18 07:59:59','2018-11-18 15:59:59','MCOETH','4h','0.021008000000000','0.020881000000000','0.072144500000000','0.071708363694783','3.434144135567403','3.434144135567403','test'),('2018-11-19 03:59:59','2018-11-19 11:59:59','MCOETH','4h','0.021616000000000','0.021145000000000','0.072144500000000','0.070572513531643','3.33755088823094','3.337550888230940','test'),('2018-11-20 07:59:59','2018-11-20 11:59:59','MCOETH','4h','0.021090000000000','0.018289000000000','0.072144500000000','0.062562862043623','3.4207918444760548','3.420791844476055','test'),('2018-11-26 11:59:59','2018-11-26 15:59:59','MCOETH','4h','0.019971000000000','0.018879000000000','0.072144500000000','0.068199690325973','3.612463071453608','3.612463071453608','test'),('2018-11-29 11:59:59','2018-11-30 03:59:59','MCOETH','4h','0.019981000000000','0.019391000000000','0.072144500000000','0.070014213477804','3.610655122366248','3.610655122366248','test'),('2018-11-30 23:59:59','2018-12-07 07:59:59','MCOETH','4h','0.019628000000000','0.022635000000000','0.072144500000000','0.083197002114326','3.6755909924597514','3.675590992459751','test'),('2018-12-08 07:59:59','2018-12-08 15:59:59','MCOETH','4h','0.021665000000000','0.021625000000000','0.072144500000000','0.072011299907685','3.330002307869836','3.330002307869836','test'),('2018-12-09 11:59:59','2018-12-09 15:59:59','MCOETH','4h','0.021252000000000','0.021479000000000','0.072144500000000','0.072915100484660','3.3947157914549217','3.394715791454922','test'),('2018-12-10 11:59:59','2018-12-10 15:59:59','MCOETH','4h','0.021311000000000','0.021281000000000','0.072144500000000','0.072042940476749','3.385317441696776','3.385317441696776','test'),('2018-12-13 03:59:59','2018-12-13 07:59:59','MCOETH','4h','0.021374000000000','0.021142000000000','0.072144500000000','0.071361421306260','3.3753391971554225','3.375339197155423','test'),('2018-12-20 07:59:59','2018-12-20 11:59:59','MCOETH','4h','0.020778000000000','0.020270000000000','0.072144500000000','0.070380643709693','3.4721580517855424','3.472158051785542','test'),('2018-12-25 03:59:59','2018-12-25 07:59:59','MCOETH','4h','0.021423000000000','0.019655000000000','0.072144500000000','0.066190549759604','3.3676189142510387','3.367618914251039','test'),('2019-01-05 07:59:59','2019-01-05 15:59:59','MCOETH','4h','0.017319000000000','0.016476000000000','0.072144500000000','0.068632876147584','4.165627345689705','4.165627345689705','test'),('2019-01-06 19:59:59','2019-01-07 03:59:59','MCOETH','4h','0.016965000000000','0.016780000000000','0.072144500000000','0.071357778367227','4.252549366342469','4.252549366342469','test'),('2019-01-14 23:59:59','2019-01-15 03:59:59','MCOETH','4h','0.017706000000000','0.017673000000000','0.072144500000000','0.072010038885124','4.074579238676155','4.074579238676155','test'),('2019-01-28 15:59:59','2019-01-28 23:59:59','MCOETH','4h','0.019400000000000','0.018990000000000','0.072144500000000','0.070619796649485','3.7187886597938142','3.718788659793814','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','MCOETH','4h','0.019142000000000','0.018667000000000','0.072144500000000','0.070354267135096','3.7689112945355765','3.768911294535576','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','MCOETH','4h','0.018974000000000','0.018838000000000','0.072144500000000','0.071627389638453','3.802282070201328','3.802282070201328','test'),('2019-02-05 03:59:59','2019-02-05 07:59:59','MCOETH','4h','0.018804000000000','0.018486000000000','0.072144500000000','0.070924443044033','3.8366570942352687','3.836657094235269','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','MCOETH','4h','0.018664000000000','0.018422000000000','0.072144500000000','0.071209064455637','3.8654361337333905','3.865436133733390','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 12:58:27
