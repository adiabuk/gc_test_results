-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-03 15:59:59','2018-06-03 19:59:59','POEETH','4h','0.000049980000000','0.000049170000000','0.072144500000000','0.070975291416567','1443.467386954782','1443.467386954781887','test'),('2018-06-30 07:59:59','2018-06-30 11:59:59','POEETH','4h','0.000032290000000','0.000032870000000','0.072144500000000','0.073440375193558','2234.2675751006504','2234.267575100650447','test'),('2018-07-07 03:59:59','2018-07-07 07:59:59','POEETH','4h','0.000039910000000','0.000039520000000','0.072176166652531','0.071470862092409','1808.4732310832185','1808.473231083218479','test'),('2018-07-08 19:59:59','2018-07-09 03:59:59','POEETH','4h','0.000039360000000','0.000040920000000','0.072176166652531','0.075036807404003','1833.7440714565803','1833.744071456580286','test'),('2018-07-17 19:59:59','2018-07-20 03:59:59','POEETH','4h','0.000038000000000','0.000038130000000','0.072715000700369','0.072963762544870','1913.552650009704','1913.552650009703939','test'),('2018-07-21 07:59:59','2018-07-21 11:59:59','POEETH','4h','0.000038660000000','0.000038850000000','0.072777191161494','0.073134864889396','1882.493304746353','1882.493304746353033','test'),('2018-07-24 19:59:59','2018-07-24 23:59:59','POEETH','4h','0.000039370000000','0.000037940000000','0.072866609593469','0.070219943306482','1850.8155853052958','1850.815585305295826','test'),('2018-07-25 07:59:59','2018-07-25 11:59:59','POEETH','4h','0.000038990000000','0.000038260000000','0.072866609593469','0.071502346320752','1868.8537982423443','1868.853798242344283','test'),('2018-07-27 19:59:59','2018-07-27 23:59:59','POEETH','4h','0.000039210000000','0.000038550000000','0.072866609593469','0.071640086708193','1858.3680079946187','1858.368007994618665','test'),('2018-07-28 11:59:59','2018-07-30 11:59:59','POEETH','4h','0.000039580000000','0.000039070000000','0.072866609593469','0.071927701789208','1840.9956946303437','1840.995694630343678','test'),('2018-07-31 03:59:59','2018-07-31 07:59:59','POEETH','4h','0.000039050000000','0.000038280000000','0.072866609593469','0.071429803207119','1865.9823199351856','1865.982319935185615','test'),('2018-08-07 11:59:59','2018-08-07 15:59:59','POEETH','4h','0.000036500000000','0.000035420000000','0.072866609593469','0.070710556487690','1996.345468314219','1996.345468314219033','test'),('2018-08-17 15:59:59','2018-08-18 07:59:59','POEETH','4h','0.000032730000000','0.000030990000000','0.072866609593469','0.068992857662744','2226.2942130604642','2226.294213060464244','test'),('2018-08-20 03:59:59','2018-08-20 11:59:59','POEETH','4h','0.000032150000000','0.000032090000000','0.072866609593469','0.072730622141662','2266.457530123452','2266.457530123452216','test'),('2018-08-30 23:59:59','2018-09-08 19:59:59','POEETH','4h','0.000036460000000','0.000039390000000','0.072866609593469','0.078722319031452','1998.535644362836','1998.535644362835910','test'),('2018-09-16 03:59:59','2018-09-19 15:59:59','POEETH','4h','0.000041950000000','0.000040630000000','0.072866609593469','0.070573786597918','1736.9871178419305','1736.987117841930512','test'),('2018-09-24 15:59:59','2018-09-28 07:59:59','POEETH','4h','0.000042320000000','0.000046120000000','0.072866609593469','0.079409452609896','1721.8007937965262','1721.800793796526250','test'),('2018-09-30 15:59:59','2018-09-30 19:59:59','POEETH','4h','0.000044220000000','0.000043530000000','0.072866609593469','0.071729613650016','1647.8202079029622','1647.820207902962238','test'),('2018-10-01 11:59:59','2018-10-01 15:59:59','POEETH','4h','0.000044020000000','0.000043530000000','0.072866609593469','0.072055509214078','1655.3068967166967','1655.306896716696656','test'),('2018-10-01 19:59:59','2018-10-01 23:59:59','POEETH','4h','0.000044080000000','0.000043820000000','0.072866609593469','0.072436815616738','1653.0537566576452','1653.053756657645181','test'),('2018-10-02 03:59:59','2018-10-02 15:59:59','POEETH','4h','0.000044180000000','0.000045640000000','0.072866609593469','0.075274605293027','1649.312122984812','1649.312122984812049','test'),('2018-10-08 03:59:59','2018-10-08 19:59:59','POEETH','4h','0.000045720000000','0.000045730000000','0.072866609593469','0.072882547172120','1593.7578651239937','1593.757865123993724','test'),('2018-10-09 19:59:59','2018-10-10 03:59:59','POEETH','4h','0.000045940000000','0.000045870000000','0.072866609593469','0.072755580802186','1586.1255897577057','1586.125589757705711','test'),('2018-10-10 11:59:59','2018-10-11 07:59:59','POEETH','4h','0.000046600000000','0.000045600000000','0.072866609593469','0.071302948443395','1563.6611500744418','1563.661150074441821','test'),('2018-10-15 15:59:59','2018-10-15 23:59:59','POEETH','4h','0.000047840000000','0.000046330000000','0.072866609593469','0.070566681071602','1523.1314714353887','1523.131471435388676','test'),('2018-10-27 23:59:59','2018-11-04 19:59:59','POEETH','4h','0.000057160000000','0.000059210000000','0.072866609593469','0.075479915220946','1274.7832329158325','1274.783232915832514','test'),('2018-11-13 03:59:59','2018-11-13 19:59:59','POEETH','4h','0.000058600000000','0.000057520000000','0.072866609593469','0.071523675491746','1243.457501595034','1243.457501595034046','test'),('2018-11-27 15:59:59','2018-11-27 19:59:59','POEETH','4h','0.000050830000000','0.000050950000000','0.072866609593469','0.073038633853772','1433.5355025274246','1433.535502527424569','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','POEETH','4h','0.000050830000000','0.000049850000000','0.072866609593469','0.071461744800992','1433.5355025274246','1433.535502527424569','test'),('2018-12-01 11:59:59','2018-12-03 03:59:59','POEETH','4h','0.000050750000000','0.000049930000000','0.072866609593469','0.071689257477870','1435.7952629254974','1435.795262925497354','test'),('2018-12-03 11:59:59','2018-12-03 15:59:59','POEETH','4h','0.000051180000000','0.000049990000000','0.072866609593469','0.071172368377833','1423.7321139794644','1423.732113979464430','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','POEETH','4h','0.000050720000000','0.000050650000000','0.072866609593469','0.072766044477705','1436.6445109122435','1436.644510912243504','test'),('2018-12-08 07:59:59','2018-12-08 11:59:59','POEETH','4h','0.000054610000000','0.000055000000000','0.072866609593469','0.073386990068500','1334.3089103363668','1334.308910336366807','test'),('2018-12-10 03:59:59','2018-12-10 07:59:59','POEETH','4h','0.000054400000000','0.000054350000000','0.072866609593469','0.072799636606710','1339.4597351740624','1339.459735174062416','test'),('2018-12-12 15:59:59','2018-12-12 19:59:59','POEETH','4h','0.000054250000000','0.000054800000000','0.072866609593469','0.073605349414232','1343.1633104786913','1343.163310478691301','test'),('2019-01-07 23:59:59','2019-01-14 19:59:59','POEETH','4h','0.000039110000000','0.000040120000000','0.072866609593469','0.074748360442086','1863.1196520958576','1863.119652095857646','test'),('2019-03-02 11:59:59','2019-03-05 19:59:59','POEETH','4h','0.000033990000000','0.000034420000000','0.072866609593469','0.073788429014628','2143.766095718417','2143.766095718417091','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','POEETH','4h','0.000034360000000','0.000033930000000','0.072866609593469','0.071954716632899','2120.6813036516005','2120.681303651600501','test'),('2019-03-09 23:59:59','2019-03-11 15:59:59','POEETH','4h','0.000034680000000','0.000035620000000','0.072866609593469','0.074841656104941','2101.1133100769607','2101.113310076960715','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','POEETH','4h','0.000036150000000','0.000035890000000','0.072866609593469','0.072342534393073','2015.673847675491','2015.673847675491061','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','POEETH','4h','0.000036170000000','0.000035810000000','0.072866609593469','0.072141368248331','2014.5592920505667','2014.559292050566683','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','POEETH','4h','0.000036170000000','0.000035950000000','0.072866609593469','0.072423406549218','2014.5592920505667','2014.559292050566683','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','POEETH','4h','0.000035970000000','0.000035870000000','0.072866609593469','0.072664033531213','2025.7606225596048','2025.760622559604826','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','POEETH','4h','0.000038890000000','0.000036440000000','0.072866609593469','0.068276144345230','1873.6592849953456','1873.659284995345615','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','POEETH','4h','0.000036760000000','0.000035880000000','0.072866609593469','0.071122251148359','1982.2255058071','1982.225505807100035','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','POEETH','4h','0.000036750000000','0.000036220000000','0.072866609593469','0.071815744203414','1982.7648868971155','1982.764886897115503','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','POEETH','4h','0.000036760000000','0.000036300000000','0.072866609593469','0.071954785860798','1982.2255058071','1982.225505807100035','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','POEETH','4h','0.000036490000000','0.000035750000000','0.072866609593469','0.071388909097466','1996.8925621668677','1996.892562166867719','test'),('2019-04-19 19:59:59','2019-04-19 23:59:59','POEETH','4h','0.000036300000000','0.000036020000000','0.072866609593469','0.072304553100737','2007.3446168999722','2007.344616899972152','test'),('2019-04-20 19:59:59','2019-04-22 23:59:59','POEETH','4h','0.000036590000000','0.000037140000000','0.072866609593469','0.073961898887714','1991.4350804446294','1991.435080444629421','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  8:41:11
