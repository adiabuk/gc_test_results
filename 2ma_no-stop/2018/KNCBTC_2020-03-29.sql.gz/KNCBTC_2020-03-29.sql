-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 03:59:59','2018-03-20 11:59:59','KNCBTC','4h','0.000144700000000','0.000140510000000','0.001467500000000','0.001425006392536','10.141672425708363','10.141672425708363','test'),('2018-03-23 15:59:59','2018-03-26 15:59:59','KNCBTC','4h','0.000151560000000','0.000163260000000','0.001467500000000','0.001580786817102','9.682633940353655','9.682633940353655','test'),('2018-03-27 11:59:59','2018-03-27 15:59:59','KNCBTC','4h','0.000151840000000','0.000151910000000','0.001485198302410','0.001485882996043','9.781337608070995','9.781337608070995','test'),('2018-03-29 03:59:59','2018-03-29 07:59:59','KNCBTC','4h','0.000151020000000','0.000147870000000','0.001485369475818','0.001454387394976','9.835581219823533','9.835581219823533','test'),('2018-04-07 19:59:59','2018-04-07 23:59:59','KNCBTC','4h','0.000140890000000','0.000142260000000','0.001485369475818','0.001499813057207','10.542760137823835','10.542760137823835','test'),('2018-05-05 07:59:59','2018-05-05 11:59:59','KNCBTC','4h','0.000268020000000','0.000249500000000','0.001485369475818','0.001382731453685','5.542009834407881','5.542009834407881','test'),('2018-05-10 03:59:59','2018-05-10 23:59:59','KNCBTC','4h','0.000266790000000','0.000252750000000','0.001485369475818','0.001407200925871','5.567560537568875','5.567560537568875','test'),('2018-05-12 23:59:59','2018-05-13 11:59:59','KNCBTC','4h','0.000254550000000','0.000250460000000','0.001485369475818','0.001461503197460','5.835275882215676','5.835275882215676','test'),('2018-05-14 11:59:59','2018-05-15 15:59:59','KNCBTC','4h','0.000261350000000','0.000252580000000','0.001485369475818','0.001435525625415','5.6834493048326005','5.683449304832600','test'),('2018-06-01 11:59:59','2018-06-04 07:59:59','KNCBTC','4h','0.000189980000000','0.000191330000000','0.001485369475818','0.001495924527889','7.818557089262028','7.818557089262028','test'),('2018-06-04 15:59:59','2018-06-04 19:59:59','KNCBTC','4h','0.000193130000000','0.000195000000000','0.001485369475818','0.001499751710167','7.691034411111687','7.691034411111687','test'),('2018-07-02 03:59:59','2018-07-02 07:59:59','KNCBTC','4h','0.000143050000000','0.000139720000000','0.001485369475818','0.001450792192669','10.383568513233135','10.383568513233135','test'),('2018-07-04 11:59:59','2018-07-09 11:59:59','KNCBTC','4h','0.000144770000000','0.000147910000000','0.001485369475818','0.001517586510798','10.260202222960558','10.260202222960558','test'),('2018-07-13 11:59:59','2018-07-13 15:59:59','KNCBTC','4h','0.000142690000000','0.000146050000000','0.001485369475818','0.001520346288760','10.409765756661294','10.409765756661294','test'),('2018-07-14 07:59:59','2018-07-14 11:59:59','KNCBTC','4h','0.000142830000000','0.000141350000000','0.001485369475818','0.001469978123692','10.399562247553035','10.399562247553035','test'),('2018-07-14 15:59:59','2018-07-14 19:59:59','KNCBTC','4h','0.000141960000000','0.000138880000000','0.001485369475818','0.001453142524666','10.463295828529164','10.463295828529164','test'),('2018-07-16 15:59:59','2018-07-17 03:59:59','KNCBTC','4h','0.000143160000000','0.000142460000000','0.001485369475818','0.001478106562762','10.375590079756915','10.375590079756915','test'),('2018-07-18 03:59:59','2018-07-18 11:59:59','KNCBTC','4h','0.000143400000000','0.000140500000000','0.001485369475818','0.001455330623099','10.358225075439332','10.358225075439332','test'),('2018-07-19 03:59:59','2018-07-19 07:59:59','KNCBTC','4h','0.000141910000000','0.000144030000000','0.001485369475818','0.001507559478557','10.466982424198436','10.466982424198436','test'),('2018-08-21 23:59:59','2018-08-22 03:59:59','KNCBTC','4h','0.000076720000000','0.000074330000000','0.001485369475818','0.001439096886569','19.360916003884256','19.360916003884256','test'),('2018-08-24 07:59:59','2018-08-24 11:59:59','KNCBTC','4h','0.000075560000000','0.000076000000000','0.001485369475818','0.001494019059849','19.65814552432504','19.658145524325040','test'),('2018-08-31 19:59:59','2018-08-31 23:59:59','KNCBTC','4h','0.000078030000000','0.000077400000000','0.001485369475818','0.001473376873360','19.035876916801232','19.035876916801232','test'),('2018-09-01 03:59:59','2018-09-01 07:59:59','KNCBTC','4h','0.000077670000000','0.000077530000000','0.001485369475818','0.001482692100685','19.124108096021633','19.124108096021633','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','KNCBTC','4h','0.000077860000000','0.000075350000000','0.001485369475818','0.001437485101501','19.077439966837915','19.077439966837915','test'),('2018-09-21 19:59:59','2018-09-22 03:59:59','KNCBTC','4h','0.000060590000000','0.000059220000000','0.001485369475818','0.001451783798613','24.51509285060241','24.515092850602411','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','KNCBTC','4h','0.000059850000000','0.000061180000000','0.001485369475818','0.001518377686392','24.818203438897246','24.818203438897246','test'),('2018-09-30 07:59:59','2018-09-30 23:59:59','KNCBTC','4h','0.000058300000000','0.000059050000000','0.001485369475818','0.001504478002522','25.4780356057976','25.478035605797601','test'),('2018-10-03 23:59:59','2018-10-04 03:59:59','KNCBTC','4h','0.000058700000000','0.000058350000000','0.001485369475818','0.001476512928688','25.304420371686543','25.304420371686543','test'),('2018-10-04 07:59:59','2018-10-04 11:59:59','KNCBTC','4h','0.000058480000000','0.000057950000000','0.001485369475818','0.001471907679953','25.399614839569082','25.399614839569082','test'),('2018-10-06 03:59:59','2018-10-06 15:59:59','KNCBTC','4h','0.000059030000000','0.000058640000000','0.001485369475818','0.001475555921768','25.16295910245638','25.162959102456380','test'),('2018-10-14 19:59:59','2018-10-15 03:59:59','KNCBTC','4h','0.000060710000000','0.000058930000000','0.001485369475818','0.001441818863613','24.466636070136715','24.466636070136715','test'),('2018-10-15 11:59:59','2018-10-29 11:59:59','KNCBTC','4h','0.000062900000000','0.000067600000000','0.001485369475818','0.001596358927906','23.6147770400318','23.614777040031800','test'),('2018-11-01 15:59:59','2018-11-01 19:59:59','KNCBTC','4h','0.000067980000000','0.000068810000000','0.001485369475818','0.001503505054884','21.850095260635484','21.850095260635484','test'),('2018-11-29 15:59:59','2018-11-29 23:59:59','KNCBTC','4h','0.000046210000000','0.000045460000000','0.001485369475818','0.001461261553142','32.143896901493186','32.143896901493186','test'),('2018-12-01 03:59:59','2018-12-03 03:59:59','KNCBTC','4h','0.000053580000000','0.000045510000000','0.001485369475818','0.001261649213223','27.722461288129903','27.722461288129903','test'),('2018-12-04 19:59:59','2018-12-04 23:59:59','KNCBTC','4h','0.000046020000000','0.000045400000000','0.001485369475818','0.001465357979186','32.27660747105606','32.276607471056060','test'),('2018-12-19 07:59:59','2018-12-19 15:59:59','KNCBTC','4h','0.000039000000000','0.000039170000000','0.001485369475818','0.001491844163277','38.08639681584616','38.086396815846157','test'),('2018-12-20 07:59:59','2018-12-20 11:59:59','KNCBTC','4h','0.000043040000000','0.000039570000000','0.001485369475818','0.001365615012967','34.5113725794145','34.511372579414498','test'),('2018-12-26 03:59:59','2018-12-27 07:59:59','KNCBTC','4h','0.000041360000000','0.000040730000000','0.001485369475818','0.001462744167071','35.91318848689556','35.913188486895557','test'),('2018-12-28 07:59:59','2018-12-30 11:59:59','KNCBTC','4h','0.000041320000000','0.000041250000000','0.001485369475818','0.001482853119010','35.94795440024202','35.947954400242018','test'),('2018-12-31 19:59:59','2018-12-31 23:59:59','KNCBTC','4h','0.000041070000000','0.000041040000000','0.001485369475818','0.001484284472549','36.166775646895545','36.166775646895545','test'),('2019-01-04 19:59:59','2019-01-04 23:59:59','KNCBTC','4h','0.000041670000000','0.000041200000000','0.001485369475818','0.001468615848421','35.64601573837293','35.646015738372931','test'),('2019-01-05 15:59:59','2019-01-05 19:59:59','KNCBTC','4h','0.000041430000000','0.000041480000000','0.001485369475818','0.001487162101302','35.85250967458364','35.852509674583636','test'),('2019-01-19 19:59:59','2019-01-20 11:59:59','KNCBTC','4h','0.000038770000000','0.000038610000000','0.001485369475818','0.001479239501195','38.312341393293785','38.312341393293785','test'),('2019-01-24 07:59:59','2019-01-24 11:59:59','KNCBTC','4h','0.000038590000000','0.000038700000000','0.001485369475818','0.001489603490908','38.49104627670381','38.491046276703813','test'),('2019-01-26 11:59:59','2019-01-26 19:59:59','KNCBTC','4h','0.000038670000000','0.000038750000000','0.001485369475818','0.001488442389138','38.41141649387122','38.411416493871222','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','KNCBTC','4h','0.000035100000000','0.000035570000000','0.001485369475818','0.001505259038600','42.31821868427351','42.318218684273511','test'),('2019-02-10 11:59:59','2019-02-12 15:59:59','KNCBTC','4h','0.000041000000000','0.000036170000000','0.001485369475818','0.001310385705862','36.22852380043903','36.228523800439028','test'),('2019-02-22 11:59:59','2019-02-23 19:59:59','KNCBTC','4h','0.000038630000000','0.000038410000000','0.001485369475818','0.001476910213983','38.451190158374324','38.451190158374324','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','KNCBTC','4h','0.000038690000000','0.000038360000000','0.001485369475818','0.001472700260852','38.3915605018868','38.391560501886801','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 10:59:05
