-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-18 03:59:59','2018-04-19 07:59:59','MTHETH','4h','0.000198150000000','0.000196440000000','0.072144500000000','0.071521905526117','364.09033560434017','364.090335604340169','test'),('2018-04-20 15:59:59','2018-04-20 19:59:59','MTHETH','4h','0.000195360000000','0.000193320000000','0.072144500000000','0.071391148341523','369.2900286650287','369.290028665028672','test'),('2018-04-23 03:59:59','2018-04-23 11:59:59','MTHETH','4h','0.000189650000000','0.000189600000000','0.072144500000000','0.072125479567625','380.40864750856844','380.408647508568436','test'),('2018-04-26 23:59:59','2018-04-27 03:59:59','MTHETH','4h','0.000189740000000','0.000186740000000','0.072144500000000','0.071003815378940','380.2282070201328','380.228207020132800','test'),('2018-04-29 03:59:59','2018-05-03 07:59:59','MTHETH','4h','0.000192350000000','0.000196730000000','0.072144500000000','0.073787301715623','375.068884845334','375.068884845334026','test'),('2018-05-31 15:59:59','2018-05-31 19:59:59','MTHETH','4h','0.000133370000000','0.000132840000000','0.072144500000000','0.071857804453775','540.9349928769589','540.934992876958859','test'),('2018-06-01 03:59:59','2018-06-01 07:59:59','MTHETH','4h','0.000133010000000','0.000132680000000','0.072144500000000','0.071965508307646','542.3990677392677','542.399067739267707','test'),('2018-06-01 23:59:59','2018-06-03 11:59:59','MTHETH','4h','0.000134990000000','0.000134110000000','0.072144500000000','0.071674189902956','534.4432920957107','534.443292095710717','test'),('2018-07-01 07:59:59','2018-07-01 19:59:59','MTHETH','4h','0.000089080000000','0.000086640000000','0.072144500000000','0.070168382128424','809.884373596767','809.884373596766977','test'),('2018-07-02 11:59:59','2018-07-02 15:59:59','MTHETH','4h','0.000087280000000','0.000092630000000','0.072144500000000','0.076566739631072','826.5868469294226','826.586846929422563','test'),('2018-07-07 07:59:59','2018-07-07 23:59:59','MTHETH','4h','0.000093360000000','0.000090700000000','0.072298818738425','0.070238890955175','774.408941071393','774.408941071392974','test'),('2018-07-13 07:59:59','2018-07-13 11:59:59','MTHETH','4h','0.000089110000000','0.000089020000000','0.072298818738425','0.072225797823977','811.3434938662888','811.343493866288782','test'),('2018-07-14 23:59:59','2018-07-15 03:59:59','MTHETH','4h','0.000089240000000','0.000088040000000','0.072298818738425','0.071326624851310','810.1615725955289','810.161572595528924','test'),('2018-07-15 11:59:59','2018-07-15 15:59:59','MTHETH','4h','0.000088640000000','0.000086570000000','0.072298818738425','0.070610432515630','815.6455182584048','815.645518258404763','test'),('2018-07-17 19:59:59','2018-07-20 03:59:59','MTHETH','4h','0.000088310000000','0.000088950000000','0.072298818738425','0.072822782547649','818.6934519128638','818.693451912863793','test'),('2018-07-20 15:59:59','2018-07-20 19:59:59','MTHETH','4h','0.000094490000000','0.000083010000000','0.072298818738425','0.063514921615797','765.1478329815325','765.147832981532474','test'),('2018-07-29 15:59:59','2018-07-29 19:59:59','MTHETH','4h','0.000083760000000','0.000086700000000','0.072298818738425','0.074836527992138','863.1664128274236','863.166412827423642','test'),('2018-08-11 07:59:59','2018-08-11 15:59:59','MTHETH','4h','0.000077900000000','0.000072610000000','0.072298818738425','0.067389181368383','928.0978015202184','928.097801520218354','test'),('2018-08-14 11:59:59','2018-08-14 15:59:59','MTHETH','4h','0.000073630000000','0.000068340000000','0.072298818738425','0.067104458408040','981.9206673696184','981.920667369618400','test'),('2018-08-15 03:59:59','2018-08-15 07:59:59','MTHETH','4h','0.000075460000000','0.000071570000000','0.072298818738425','0.068571779182469','958.1078550016565','958.107855001656503','test'),('2018-08-15 15:59:59','2018-08-15 19:59:59','MTHETH','4h','0.000072860000000','0.000072040000000','0.072298818738425','0.071485134530828','992.2978141425336','992.297814142533639','test'),('2018-08-17 07:59:59','2018-08-18 19:59:59','MTHETH','4h','0.000071990000000','0.000077780000000','0.072298818738425','0.078113656361643','1004.2897449427005','1004.289744942700509','test'),('2018-08-23 23:59:59','2018-08-24 07:59:59','MTHETH','4h','0.000076860000000','0.000077240000000','0.072298818738425','0.072656268011397','940.6559815043586','940.655981504358579','test'),('2018-09-16 03:59:59','2018-09-16 11:59:59','MTHETH','4h','0.000095270000000','0.000097360000000','0.072298818738425','0.073884884983448','758.8833708242364','758.883370824236408','test'),('2018-09-22 15:59:59','2018-09-22 19:59:59','MTHETH','4h','0.000119990000000','0.000114640000000','0.072298818738425','0.069075227770423','602.5403678508626','602.540367850862594','test'),('2018-09-22 23:59:59','2018-09-23 03:59:59','MTHETH','4h','0.000121660000000','0.000124480000000','0.072298818738425','0.073974658528351','594.2694290516604','594.269429051660381','test'),('2018-09-24 07:59:59','2018-09-24 11:59:59','MTHETH','4h','0.000118020000000','0.000114160000000','0.072298818738425','0.069934190367553','612.5980235419844','612.598023541984389','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','MTHETH','4h','0.000117310000000','0.000119500000000','0.072298818738425','0.073648528166753','616.3056750355895','616.305675035589502','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','MTHETH','4h','0.000134050000000','0.000139530000000','0.072298818738425','0.075254413864770','539.342176340358','539.342176340358037','test'),('2018-10-28 07:59:59','2018-11-04 11:59:59','MTHETH','4h','0.000187390000000','0.000204040000000','0.072298818738425','0.078722722532623','385.82004769958377','385.820047699583768','test'),('2018-11-08 19:59:59','2018-11-13 11:59:59','MTHETH','4h','0.000244640000000','0.000232300000000','0.072298818738425','0.068651960402780','295.53146966328075','295.531469663280745','test'),('2018-11-17 11:59:59','2018-11-19 03:59:59','MTHETH','4h','0.000233690000000','0.000222480000000','0.072298818738425','0.068830678218686','309.37917214440074','309.379172144400741','test'),('2018-11-28 07:59:59','2018-11-28 15:59:59','MTHETH','4h','0.000196000000000','0.000187500000000','0.072298818738425','0.069163410782932','368.8715241756378','368.871524175637774','test'),('2018-11-28 23:59:59','2018-11-29 03:59:59','MTHETH','4h','0.000199480000000','0.000190770000000','0.072298818738425','0.069141997447009','362.43642840598056','362.436428405980564','test'),('2018-12-01 03:59:59','2018-12-01 23:59:59','MTHETH','4h','0.000197070000000','0.000195490000000','0.072298818738425','0.071719166160119','366.8687204466687','366.868720446668704','test'),('2018-12-07 07:59:59','2018-12-07 15:59:59','MTHETH','4h','0.000199230000000','0.000196580000000','0.072298818738425','0.071337156992419','362.8912249080209','362.891224908020888','test'),('2018-12-08 03:59:59','2018-12-08 07:59:59','MTHETH','4h','0.000199670000000','0.000195480000000','0.072298818738425','0.070781655165960','362.0915447409476','362.091544740947597','test'),('2018-12-08 15:59:59','2018-12-08 23:59:59','MTHETH','4h','0.000199510000000','0.000197170000000','0.072298818738425','0.071450845023584','362.3819294192021','362.381929419202095','test'),('2018-12-09 07:59:59','2018-12-09 11:59:59','MTHETH','4h','0.000198800000000','0.000198620000000','0.072298818738425','0.072233357031318','363.6761505956992','363.676150595699198','test'),('2018-12-10 11:59:59','2018-12-10 15:59:59','MTHETH','4h','0.000199400000000','0.000195650000000','0.072298818738425','0.070939136841388','362.58183920975426','362.581839209754264','test'),('2018-12-11 19:59:59','2018-12-11 23:59:59','MTHETH','4h','0.000206330000000','0.000191110000000','0.072298818738425','0.066965672704408','350.4038130103475','350.403813010347505','test'),('2018-12-12 19:59:59','2018-12-12 23:59:59','MTHETH','4h','0.000197660000000','0.000197270000000','0.072298818738425','0.072156167016741','365.7736453426338','365.773645342633813','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','MTHETH','4h','0.000125500000000','0.000124500000000','0.072298818738425','0.071722732533338','576.0862050870519','576.086205087051894','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','MTHETH','4h','0.000126480000000','0.000123580000000','0.072298818738425','0.070641113375194','571.622539045106','571.622539045106009','test'),('2019-01-12 23:59:59','2019-01-13 11:59:59','MTHETH','4h','0.000122940000000','0.000124150000000','0.072298818738425','0.073010398132223','588.0821436344964','588.082143634496447','test'),('2019-01-15 07:59:59','2019-01-23 23:59:59','MTHETH','4h','0.000124700000000','0.000150090000000','0.072298818738425','0.087019484398157','579.782026771652','579.782026771651999','test'),('2019-01-29 15:59:59','2019-01-30 15:59:59','MTHETH','4h','0.000156370000000','0.000151840000000','0.072298818738425','0.070204339945274','462.3573494815182','462.357349481518213','test'),('2019-02-02 11:59:59','2019-02-03 15:59:59','MTHETH','4h','0.000156440000000','0.000149820000000','0.072298818738425','0.069239382660386','462.150464960528','462.150464960527984','test'),('2019-02-06 11:59:59','2019-02-06 19:59:59','MTHETH','4h','0.000150240000000','0.000149220000000','0.072298818738425','0.071807972125584','481.2221694517106','481.222169451710613','test'),('2019-02-07 03:59:59','2019-02-07 11:59:59','MTHETH','4h','0.000152250000000','0.000149440000000','0.072298818738425','0.070964436599476','474.8690885939245','474.869088593924516','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','MTHETH','4h','0.000127950000000','0.000126660000000','0.072298818738425','0.071569897470957','565.0552460994529','565.055246099452916','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','MTHETH','4h','0.000135200000000','0.000133830000000','0.072298818738425','0.071566204968664','534.7545764676405','534.754576467640504','test'),('2019-03-09 11:59:59','2019-03-10 03:59:59','MTHETH','4h','0.000136890000000','0.000137820000000','0.072298818738425','0.072790000719773','528.1526681161882','528.152668116188238','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','MTHETH','4h','0.000142400000000','0.000141920000000','0.072298818738425','0.072055114855037','507.7164237248947','507.716423724894696','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','MTHETH','4h','0.000141930000000','0.000143510000000','0.072298818738425','0.073103667139797','509.3977223872684','509.397722387268402','test'),('2019-03-24 15:59:59','2019-03-24 23:59:59','MTHETH','4h','0.000143760000000','0.000142210000000','0.072298818738425','0.071519303093986','502.91331899293965','502.913318992939651','test'),('2019-03-25 15:59:59','2019-03-29 23:59:59','MTHETH','4h','0.000146230000000','0.000152890000000','0.072298818738425','0.075591646015987','494.4185101444643','494.418510144464278','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  2:44:05
