-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-19 19:59:59','2018-09-20 07:59:59','QLCBNB','4h','0.005537000000000','0.005676000000000','0.711908500000000','0.729780141954127','128.57296369875385','128.572963698753853','test'),('2018-09-23 07:59:59','2018-09-25 03:59:59','QLCBNB','4h','0.006109000000000','0.005681000000000','0.716376410488532','0.666186673430242','117.26574079039642','117.265740790396421','test'),('2018-09-26 11:59:59','2018-09-26 23:59:59','QLCBNB','4h','0.005827000000000','0.005700000000000','0.716376410488532','0.700762920848573','122.94086330676711','122.940863306767113','test'),('2018-09-30 15:59:59','2018-09-30 19:59:59','QLCBNB','4h','0.005813000000000','0.005812000000000','0.716376410488532','0.716253173535068','123.23695346439567','123.236953464395668','test'),('2018-10-08 19:59:59','2018-10-10 11:59:59','QLCBNB','4h','0.005567000000000','0.005644000000000','0.716376410488532','0.726284975893169','128.6826675926948','128.682667592694798','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','QLCBNB','4h','0.005342000000000','0.005278000000000','0.716376410488532','0.707793840239324','134.10266014386596','134.102660143865961','test'),('2018-10-18 11:59:59','2018-10-18 15:59:59','QLCBNB','4h','0.005300000000000','0.005190000000000','0.716376410488532','0.701508220836883','135.16536046953433','135.165360469534335','test'),('2018-10-21 07:59:59','2018-10-21 11:59:59','QLCBNB','4h','0.005249000000000','0.005251000000000','0.716376410488532','0.716649367779631','136.4786455493488','136.478645549348812','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','QLCBNB','4h','0.005217000000000','0.005263000000000','0.716376410488532','0.722692936247105','137.31577736027063','137.315777360270630','test'),('2018-10-23 15:59:59','2018-10-23 19:59:59','QLCBNB','4h','0.005221000000000','0.005198000000000','0.716376410488532','0.713220567270521','137.21057469613714','137.210574696137144','test'),('2018-10-23 23:59:59','2018-10-24 11:59:59','QLCBNB','4h','0.005308000000000','0.005196000000000','0.716376410488532','0.701260706273250','134.96164477930142','134.961644779301423','test'),('2018-10-25 03:59:59','2018-10-25 07:59:59','QLCBNB','4h','0.005224000000000','0.005217000000000','0.716376410488532','0.715416488039562','137.13177842429783','137.131778424297835','test'),('2018-10-25 19:59:59','2018-10-31 15:59:59','QLCBNB','4h','0.005238000000000','0.005666000000000','0.716376410488532','0.774911940020623','136.76525591610005','136.765255916100045','test'),('2018-11-07 07:59:59','2018-11-07 11:59:59','QLCBNB','4h','0.005647000000000','0.005779000000000','0.716376410488532','0.733121883515712','126.85964414530405','126.859644145304046','test'),('2018-11-10 23:59:59','2018-11-11 07:59:59','QLCBNB','4h','0.005596000000000','0.005629000000000','0.716376410488532','0.720600931851313','128.01579887214652','128.015798872146519','test'),('2018-11-18 19:59:59','2018-11-19 03:59:59','QLCBNB','4h','0.005341000000000','0.005261000000000','0.716376410488532','0.705646189024558','134.12776829966896','134.127768299668958','test'),('2018-11-28 11:59:59','2018-12-03 19:59:59','QLCBNB','4h','0.004852000000000','0.005601000000000','0.716376410488532','0.826962958603930','147.64559160934294','147.645591609342944','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','QLCBNB','4h','0.004304000000000','0.004086000000000','0.738189211886770','0.700799516675033','171.51236335659152','171.512363356591521','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','QLCBNB','4h','0.004120000000000','0.004106000000000','0.738189211886770','0.735680801943465','179.17213880746843','179.172138807468428','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','QLCBNB','4h','0.004195000000000','0.003946000000000','0.738189211886770','0.694372974995279','175.9688228573945','175.968822857394514','test'),('2018-12-20 15:59:59','2018-12-22 15:59:59','QLCBNB','4h','0.004100000000000','0.004066000000000','0.738189211886770','0.732067642812587','180.0461492406756','180.046149240675589','test'),('2018-12-23 15:59:59','2018-12-23 23:59:59','QLCBNB','4h','0.004157000000000','0.004127000000000','0.738189211886770','0.732861890174813','177.57739039854943','177.577390398549426','test'),('2019-01-02 07:59:59','2019-01-02 23:59:59','QLCBNB','4h','0.004330000000000','0.004291000000000','0.738189211886770','0.731540394504880','170.48249697154043','170.482496971540428','test'),('2019-01-03 07:59:59','2019-01-03 19:59:59','QLCBNB','4h','0.004356000000000','0.004357000000000','0.738189211886770','0.738358676811446','169.46492467556706','169.464924675567062','test'),('2019-01-05 15:59:59','2019-01-05 19:59:59','QLCBNB','4h','0.004359000000000','0.004337000000000','0.738189211886770','0.734463549427144','169.34829361935536','169.348293619355360','test'),('2019-01-09 15:59:59','2019-01-10 07:59:59','QLCBNB','4h','0.004537000000000','0.004533000000000','0.738189211886770','0.737538394860641','162.70425653223936','162.704256532239356','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','QLCBNB','4h','0.004767000000000','0.005425000000000','0.738189211886770','0.840083170649408','154.8540406727019','154.854040672701899','test'),('2019-01-30 07:59:59','2019-01-30 15:59:59','QLCBNB','4h','0.003889000000000','0.003718000000000','0.738189211886770','0.705730905064287','189.81465978060427','189.814659780604273','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','QLCBNB','4h','0.002625000000000','0.002565000000000','0.738189211886770','0.721316315615072','281.21493786162665','281.214937861626652','test'),('2019-02-24 03:59:59','2019-02-24 15:59:59','QLCBNB','4h','0.002578000000000','0.002486000000000','0.738189211886770','0.711845764449383','286.34181997159425','286.341819971594248','test'),('2019-02-26 03:59:59','2019-02-27 23:59:59','QLCBNB','4h','0.002578000000000','0.002531000000000','0.738189211886770','0.724731146348105','286.34181997159425','286.341819971594248','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','QLCBNB','4h','0.002591000000000','0.002510000000000','0.738189211886770','0.715111895729754','284.90513774093785','284.905137740937846','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','QLCBNB','4h','0.002594000000000','0.002447000000000','0.738189211886770','0.696356592708915','284.5756406656785','284.575640665678520','test'),('2019-03-02 07:59:59','2019-03-03 03:59:59','QLCBNB','4h','0.002672000000000','0.002565000000000','0.738189211886770','0.708628491201185','276.2684176222942','276.268417622294180','test'),('2019-03-03 11:59:59','2019-03-04 23:59:59','QLCBNB','4h','0.002694000000000','0.002543000000000','0.738189211886770','0.696813350344490','274.0123280945694','274.012328094569398','test'),('2019-03-10 19:59:59','2019-03-10 23:59:59','QLCBNB','4h','0.002469000000000','0.002433000000000','0.738189211886770','0.727425821190973','298.98307488326043','298.983074883260429','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','QLCBNB','4h','0.002379000000000','0.002266000000000','0.738189211886770','0.703126000056923','310.2939099986423','310.293909998642278','test'),('2019-03-15 11:59:59','2019-03-16 11:59:59','QLCBNB','4h','0.002388000000000','0.002238000000000','0.738189211886770','0.691820542798405','309.12446058909967','309.124460589099670','test'),('2019-03-20 07:59:59','2019-03-24 11:59:59','QLCBNB','4h','0.002335000000000','0.002117000000000','0.738189211886770','0.669270476044665','316.14099010140046','316.140990101400462','test'),('2019-03-26 03:59:59','2019-03-28 11:59:59','QLCBNB','4h','0.002500000000000','0.002371000000000','0.738189211886770','0.700098648553413','295.275684754708','295.275684754707981','test'),('2019-05-06 07:59:59','2019-05-10 03:59:59','QLCBNB','4h','0.001496000000000','0.001548000000000','0.738189211886770','0.763848195187647','493.44198655532756','493.441986555327560','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','QLCBNB','4h','0.001420000000000','0.001308000000000','0.738189211886770','0.679965837428095','519.8515576667394','519.851557666739382','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','QLCBNB','4h','0.001451000000000','0.001383000000000','0.738189211886770','0.703594541722538','508.74514947399723','508.745149473997230','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','QLCBNB','4h','0.001298000000000','0.001283000000000','0.738189211886770','0.729658519915814','568.7127980637674','568.712798063767423','test'),('2019-06-06 15:59:59','2019-06-06 19:59:59','QLCBNB','4h','0.001309000000000','0.001303000000000','0.738189211886770','0.734805609693248','563.9336989203744','563.933698920374354','test'),('2019-06-10 15:59:59','2019-06-11 03:59:59','QLCBNB','4h','0.001311000000000','0.001318000000000','0.738189211886770','0.742130725603938','563.0733881668725','563.073388166872519','test'),('2019-06-26 03:59:59','2019-06-26 07:59:59','QLCBNB','4h','0.001097000000000','0.001078000000000','0.738189211886770','0.725403801653544','672.9163280645123','672.916328064512300','test'),('2019-07-01 11:59:59','2019-07-01 15:59:59','QLCBNB','4h','0.001024000000000','0.000995000000000','0.738189211886770','0.717283462722008','720.8879022331739','720.887902233173918','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','QLCBNB','4h','0.001024000000000','0.001019000000000','0.738189211886770','0.734584772375604','720.8879022331739','720.887902233173918','test'),('2019-07-07 03:59:59','2019-07-07 07:59:59','QLCBNB','4h','0.000974000000000','0.000963000000000','0.738189211886770','0.729852372738151','757.894468056232','757.894468056231972','test'),('2019-07-07 11:59:59','2019-07-07 23:59:59','QLCBNB','4h','0.000972000000000','0.000965000000000','0.738189211886770','0.732873034434911','759.4539216942078','759.453921694207793','test'),('2019-07-26 23:59:59','2019-07-29 03:59:59','QLCBNB','4h','0.000806000000000','0.000792000000000','0.738189211886770','0.725367066767149','915.8675085443797','915.867508544379689','test'),('2019-07-30 23:59:59','2019-07-31 11:59:59','QLCBNB','4h','0.000792000000000','0.000785000000000','0.738189211886770','0.731664812286761','932.0570857156188','932.057085715618769','test'),('2019-08-20 15:59:59','2019-08-20 19:59:59','QLCBNB','4h','0.000520000000000','0.000506000000000','0.738189211886770','0.718314886951357','1419.5946382437885','1419.594638243788495','test'),('2019-08-21 19:59:59','2019-08-28 19:59:59','QLCBNB','4h','0.000520000000000','0.000592000000000','0.738189211886770','0.840400025840323','1419.5946382437885','1419.594638243788495','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','QLCBNB','4h','0.000643000000000','0.000622000000000','0.738189211886770','0.714080388481448','1148.0392097772472','1148.039209777247152','test'),('2019-09-03 23:59:59','2019-09-05 19:59:59','QLCBNB','4h','0.000659000000000','0.000605000000000','0.738189211886770','0.677700262809554','1120.1657236521548','1120.165723652154838','test'),('2019-09-07 23:59:59','2019-09-09 03:59:59','QLCBNB','4h','0.000657000000000','0.000624000000000','0.738189211886770','0.701111214942686','1123.5756649722525','1123.575664972252525','test'),('2019-09-09 11:59:59','2019-09-12 11:59:59','QLCBNB','4h','0.000655000000000','0.000663000000000','0.738189211886770','0.747205263329662','1127.0064303614809','1127.006430361480852','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  6:34:22
