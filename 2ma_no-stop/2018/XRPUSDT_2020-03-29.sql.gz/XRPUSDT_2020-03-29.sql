-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-20 07:59:59','2018-10-20 15:59:59','XRPUSDT','4h','0.469130000000000','0.466520000000000','15.000000000000000','14.916547652036749','31.97407967940656','31.974079679406561','test'),('2018-10-23 23:59:59','2018-10-24 23:59:59','XRPUSDT','4h','0.470060000000000','0.464020000000000','15.000000000000000','14.807258647832192','31.910819895332512','31.910819895332512','test'),('2018-10-25 19:59:59','2018-10-25 23:59:59','XRPUSDT','4h','0.467690000000000','0.463510000000000','15.000000000000000','14.865936838504137','32.07252667365135','32.072526673651353','test'),('2018-10-26 11:59:59','2018-10-26 15:59:59','XRPUSDT','4h','0.466940000000000','0.465060000000000','15.000000000000000','14.939606801730413','32.12404163275796','32.124041632757958','test'),('2018-11-01 23:59:59','2018-11-03 03:59:59','XRPUSDT','4h','0.461410000000000','0.459940000000000','15.000000000000000','14.952211698922866','32.50904835179125','32.509048351791250','test'),('2018-11-04 15:59:59','2018-11-14 11:59:59','XRPUSDT','4h','0.466780000000000','0.507740000000000','15.000000000000000','16.316251767427911','32.13505291572047','32.135052915720472','test'),('2018-11-17 19:59:59','2018-11-17 23:59:59','XRPUSDT','4h','0.504250000000000','0.498130000000000','15.199453351613567','15.014980065521600','30.14269380587718','30.142693805877180','test'),('2018-11-19 15:59:59','2018-11-19 19:59:59','XRPUSDT','4h','0.499730000000000','0.499620000000000','15.199453351613567','15.196107665205551','30.41533098195739','30.415330981957389','test'),('2018-12-17 19:59:59','2018-12-26 15:59:59','XRPUSDT','4h','0.329150000000000','0.361730000000000','15.199453351613567','16.703929092751558','46.17789260705929','46.177892607059292','test'),('2018-12-28 19:59:59','2018-12-29 23:59:59','XRPUSDT','4h','0.366970000000000','0.355930000000000','15.528617543773070','15.061451460215137','42.31576843821857','42.315768438218569','test'),('2018-12-30 11:59:59','2018-12-30 15:59:59','XRPUSDT','4h','0.360500000000000','0.358690000000000','15.528617543773070','15.450651391888940','43.075222035431544','43.075222035431544','test'),('2019-01-01 23:59:59','2019-01-02 07:59:59','XRPUSDT','4h','0.360800000000000','0.356850000000000','15.528617543773070','15.358611891617016','43.03940560912713','43.039405609127130','test'),('2019-01-06 19:59:59','2019-01-08 03:59:59','XRPUSDT','4h','0.361950000000000','0.356740000000000','15.528617543773070','15.305094688674140','42.902659328009584','42.902659328009584','test'),('2019-01-30 15:59:59','2019-01-31 11:59:59','XRPUSDT','4h','0.318430000000000','0.306010000000000','15.528617543773070','14.922941477153527','48.76618893877169','48.766188938771691','test'),('2019-02-02 23:59:59','2019-02-03 03:59:59','XRPUSDT','4h','0.310300000000000','0.308090000000000','15.528617543773070','15.418020557721702','50.04388509111527','50.043885091115271','test'),('2019-02-08 15:59:59','2019-02-10 07:59:59','XRPUSDT','4h','0.307260000000000','0.301860000000000','15.528617543773070','15.255706866378114','50.5390143323995','50.539014332399503','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','XRPUSDT','4h','0.303830000000000','0.309880000000000','15.528617543773070','15.837830380358751','51.10955976622806','51.109559766228060','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','XRPUSDT','4h','0.304290000000000','0.302550000000000','15.528617543773070','15.439821347624115','51.03229663732975','51.032296637329750','test'),('2019-02-12 23:59:59','2019-02-13 11:59:59','XRPUSDT','4h','0.305140000000000','0.302320000000000','15.528617543773070','15.385107346901338','50.89014073465645','50.890140734656448','test'),('2019-02-13 23:59:59','2019-02-14 03:59:59','XRPUSDT','4h','0.303820000000000','0.302890000000000','15.528617543773070','15.481084088715113','51.111241997804854','51.111241997804854','test'),('2019-02-18 03:59:59','2019-02-22 07:59:59','XRPUSDT','4h','0.313910000000000','0.317190000000000','15.528617543773070','15.690873813224748','49.4683748328281','49.468374832828097','test'),('2019-02-25 19:59:59','2019-02-26 07:59:59','XRPUSDT','4h','0.332460000000000','0.318220000000000','15.528617543773070','14.863492374359220','46.708228189174854','46.708228189174854','test'),('2019-03-01 07:59:59','2019-03-01 23:59:59','XRPUSDT','4h','0.321830000000000','0.315640000000000','15.528617543773070','15.229943888128924','48.25099444978115','48.250994449781153','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','XRPUSDT','4h','0.315500000000000','0.314710000000000','15.528617543773070','15.489734476072339','49.219073038900376','49.219073038900376','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','XRPUSDT','4h','0.313200000000000','0.314380000000000','15.528617543773070','15.587122552399034','49.58051578471606','49.580515784716063','test'),('2019-03-09 07:59:59','2019-03-09 11:59:59','XRPUSDT','4h','0.315830000000000','0.312920000000000','15.528617543773070','15.385539694764489','49.1676457074156','49.167645707415602','test'),('2019-03-10 19:59:59','2019-03-10 23:59:59','XRPUSDT','4h','0.313380000000000','0.312890000000000','15.528617543773070','15.504337045347999','49.55203760218607','49.552037602186068','test'),('2019-03-13 15:59:59','2019-03-14 07:59:59','XRPUSDT','4h','0.315770000000000','0.310840000000000','15.528617543773070','15.286174992261522','49.17698813621646','49.176988136216458','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','XRPUSDT','4h','0.312740000000000','0.311330000000000','15.528617543773070','15.458606190135159','49.653442296390196','49.653442296390196','test'),('2019-03-15 11:59:59','2019-03-18 11:59:59','XRPUSDT','4h','0.314610000000000','0.313350000000000','15.528617543773070','15.466426074636189','49.35830883879429','49.358308838794287','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','XRPUSDT','4h','0.314520000000000','0.313940000000000','15.528617543773070','15.499981532786840','49.37243273487558','49.372432734875581','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','XRPUSDT','4h','0.315210000000000','0.313070000000000','15.528617543773070','15.423191822686574','49.26435564789528','49.264355647895279','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','XRPUSDT','4h','0.318250000000000','0.308860000000000','15.528617543773070','15.070444036354285','48.79377075812434','48.793770758124339','test'),('2019-03-27 23:59:59','2019-03-28 03:59:59','XRPUSDT','4h','0.310120000000000','0.307600000000000','15.528617543773070','15.402433756173725','50.07293158704073','50.072931587040728','test'),('2019-03-30 03:59:59','2019-03-31 03:59:59','XRPUSDT','4h','0.315320000000000','0.308920000000000','15.528617543773070','15.213435657815479','49.24716968087362','49.247169680873618','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','XRPUSDT','4h','0.310230000000000','0.309240000000000','15.528617543773070','15.479062918597119','50.05517694540524','50.055176945405243','test'),('2019-04-17 19:59:59','2019-04-19 03:59:59','XRPUSDT','4h','0.333810000000000','0.329330000000000','15.528617543773070','15.320210945420405','46.51932998943432','46.519329989434318','test'),('2019-04-30 23:59:59','2019-05-01 03:59:59','XRPUSDT','4h','0.308700000000000','0.306080000000000','15.528617543773070','15.396822992543122','50.30326382822504','50.303263828225042','test'),('2019-05-03 15:59:59','2019-05-03 19:59:59','XRPUSDT','4h','0.306600000000000','0.307300000000000','15.528617543773070','15.564071008484882','50.64780673115809','50.647806731158092','test'),('2019-05-07 03:59:59','2019-05-07 07:59:59','XRPUSDT','4h','0.306740000000000','0.304920000000000','15.528617543773070','15.436480607182906','50.624690434156186','50.624690434156186','test'),('2019-05-11 11:59:59','2019-05-12 15:59:59','XRPUSDT','4h','0.310740000000000','0.306460000000000','15.528617543773070','15.314733000143834','49.973024212438276','49.973024212438276','test'),('2019-05-23 23:59:59','2019-05-24 03:59:59','XRPUSDT','4h','0.379560000000000','0.376680000000000','15.528617543773070','15.410790537433975','40.91215497885201','40.912154978852008','test'),('2019-06-06 23:59:59','2019-06-07 03:59:59','XRPUSDT','4h','0.419370000000000','0.418300000000000','15.528617543773070','15.488997111286633','37.028441576109564','37.028441576109564','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','XRPUSDT','4h','0.405000000000000','0.404170000000000','15.528617543773070','15.496793463374718','38.34226554018041','38.342265540180414','test'),('2019-07-09 03:59:59','2019-07-09 07:59:59','XRPUSDT','4h','0.406370000000000','0.397540000000000','15.528617543773070','15.191196737828939','38.213001805677266','38.213001805677266','test'),('2019-07-20 19:59:59','2019-07-20 23:59:59','XRPUSDT','4h','0.335480000000000','0.332790000000000','15.528617543773070','15.404103470824607','46.28775946039427','46.287759460394270','test'),('2019-07-30 19:59:59','2019-07-30 23:59:59','XRPUSDT','4h','0.318840000000000','0.318230000000000','15.528617543773070','15.498908421010237','48.70347993906997','48.703479939069972','test'),('2019-07-31 23:59:59','2019-08-01 03:59:59','XRPUSDT','4h','0.319590000000000','0.315720000000000','15.528617543773070','15.340577398917469','48.58918471720977','48.589184717209768','test'),('2019-08-04 15:59:59','2019-08-06 03:59:59','XRPUSDT','4h','0.318170000000000','0.319530000000000','15.528617543773070','15.594993757305241','48.806039361891656','48.806039361891656','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','XRPUSDT','4h','0.287190000000000','0.287710000000000','15.528617543773070','15.556734404119050','54.07088528073077','54.070885280730771','test'),('2019-09-07 19:59:59','2019-09-08 11:59:59','XRPUSDT','4h','0.261060000000000','0.259380000000000','15.528617543773070','15.428686196674553','59.482944701498006','59.482944701498006','test'),('2019-09-09 11:59:59','2019-09-09 19:59:59','XRPUSDT','4h','0.261810000000000','0.258740000000000','15.528617543773070','15.346528029012815','59.31254552451423','59.312545524514228','test'),('2019-09-10 03:59:59','2019-09-10 11:59:59','XRPUSDT','4h','0.261140000000000','0.260790000000000','15.528617543773070','15.507804891018532','59.46472215582856','59.464722155828561','test'),('2019-09-14 15:59:59','2019-09-15 15:59:59','XRPUSDT','4h','0.263360000000000','0.260640000000000','15.528617543773070','15.368236925155729','58.963462726963364','58.963462726963364','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','XRPUSDT','4h','0.279220000000000','0.267860000000000','15.528617543773070','14.896839392862452','55.614273847765446','55.614273847765446','test'),('2019-09-30 15:59:59','2019-09-30 23:59:59','XRPUSDT','4h','0.257270000000000','0.256600000000000','15.528617543773070','15.488176863731370','60.359223942834646','60.359223942834646','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','XRPUSDT','4h','0.253030000000000','0.253340000000000','15.528617543773070','15.547642447691855','61.37065780252567','61.370657802525670','test'),('2019-10-05 15:59:59','2019-10-05 23:59:59','XRPUSDT','4h','0.255220000000000','0.253250000000000','15.528617543773070','15.408754772198611','60.844046484496005','60.844046484496005','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:58:40
