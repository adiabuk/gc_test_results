-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 11:59:59','2018-07-01 15:59:59','NAVBTC','4h','0.000076900000000','0.000073800000000','0.001467500000000','0.001408342002601','19.08322496749025','19.083224967490249','test'),('2018-07-04 15:59:59','2018-07-04 19:59:59','NAVBTC','4h','0.000078200000000','0.000076300000000','0.001467500000000','0.001431844629156','18.765984654731458','18.765984654731458','test'),('2018-07-05 03:59:59','2018-07-05 07:59:59','NAVBTC','4h','0.000076700000000','0.000075800000000','0.001467500000000','0.001450280312907','19.13298565840939','19.132985658409389','test'),('2018-07-18 15:59:59','2018-07-18 19:59:59','NAVBTC','4h','0.000066800000000','0.000066400000000','0.001467500000000','0.001458712574850','21.9685628742515','21.968562874251500','test'),('2018-07-29 19:59:59','2018-07-30 11:59:59','NAVBTC','4h','0.000061200000000','0.000057800000000','0.001467500000000','0.001385972222222','23.978758169934643','23.978758169934643','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','NAVBTC','4h','0.000041600000000','0.000042100000000','0.001467500000000','0.001485138221154','35.27644230769231','35.276442307692307','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','NAVBTC','4h','0.000042700000000','0.000040100000000','0.001467500000000','0.001378144028103','34.36768149882904','34.367681498829043','test'),('2018-08-22 11:59:59','2018-08-22 15:59:59','NAVBTC','4h','0.000041000000000','0.000039400000000','0.001467500000000','0.001410231707317','35.79268292682927','35.792682926829272','test'),('2018-08-25 23:59:59','2018-08-26 03:59:59','NAVBTC','4h','0.000040100000000','0.000039700000000','0.001467500000000','0.001452861596010','36.596009975062344','36.596009975062344','test'),('2018-08-26 07:59:59','2018-08-26 11:59:59','NAVBTC','4h','0.000040000000000','0.000041400000000','0.001467500000000','0.001518862500000','36.6875','36.687500000000000','test'),('2018-09-01 11:59:59','2018-09-02 11:59:59','NAVBTC','4h','0.000040400000000','0.000039300000000','0.001467500000000','0.001427543316832','36.32425742574257','36.324257425742573','test'),('2018-09-04 03:59:59','2018-09-04 07:59:59','NAVBTC','4h','0.000040600000000','0.000041300000000','0.001467500000000','0.001492801724138','36.14532019704434','36.145320197044342','test'),('2018-09-05 03:59:59','2018-09-05 07:59:59','NAVBTC','4h','0.000040400000000','0.000039900000000','0.001467500000000','0.001449337871287','36.32425742574257','36.324257425742573','test'),('2018-09-15 07:59:59','2018-09-15 15:59:59','NAVBTC','4h','0.000036600000000','0.000035700000000','0.001467500000000','0.001431413934426','40.095628415300546','40.095628415300546','test'),('2018-09-16 19:59:59','2018-09-22 19:59:59','NAVBTC','4h','0.000036800000000','0.000067400000000','0.001467500000000','0.002687758152174','39.87771739130435','39.877717391304351','test'),('2018-10-03 11:59:59','2018-10-03 15:59:59','NAVBTC','4h','0.000050700000000','0.000049800000000','0.001681686198294','0.001651833780573','33.169353023555225','33.169353023555225','test'),('2018-10-03 19:59:59','2018-10-06 11:59:59','NAVBTC','4h','0.000053100000000','0.000052900000000','0.001681686198294','0.001675352163649','31.670173225875708','31.670173225875708','test'),('2018-10-08 07:59:59','2018-10-08 15:59:59','NAVBTC','4h','0.000053200000000','0.000052800000000','0.001681686198294','0.001669041941164','31.61064282507519','31.610642825075189','test'),('2018-10-09 03:59:59','2018-10-09 11:59:59','NAVBTC','4h','0.000052700000000','0.000051100000000','0.001681686198294','0.001630629311818','31.910554047324478','31.910554047324478','test'),('2018-10-09 23:59:59','2018-10-10 03:59:59','NAVBTC','4h','0.000052500000000','0.000052000000000','0.001681686198294','0.001665670139263','32.03211806274286','32.032118062742860','test'),('2018-10-13 07:59:59','2018-10-13 11:59:59','NAVBTC','4h','0.000052400000000','0.000050900000000','0.001681686198294','0.001633546326205','32.093248059045806','32.093248059045806','test'),('2018-10-15 19:59:59','2018-10-18 19:59:59','NAVBTC','4h','0.000053100000000','0.000053300000000','0.001681686198294','0.001688020232939','31.670173225875708','31.670173225875708','test'),('2018-10-19 23:59:59','2018-10-20 03:59:59','NAVBTC','4h','0.000053000000000','0.000053200000000','0.001681686198294','0.001688032183948','31.729928269698114','31.729928269698114','test'),('2018-10-30 19:59:59','2018-10-31 03:59:59','NAVBTC','4h','0.000057000000000','0.000055600000000','0.001681686198294','0.001640381625003','29.503266636736843','29.503266636736843','test'),('2018-10-31 19:59:59','2018-10-31 23:59:59','NAVBTC','4h','0.000056200000000','0.000056000000000','0.001681686198294','0.001675701549901','29.923241962526692','29.923241962526692','test'),('2018-11-06 11:59:59','2018-11-06 15:59:59','NAVBTC','4h','0.000057300000000','0.000056800000000','0.001681686198294','0.001667011798658','29.3487992721466','29.348799272146600','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','NAVBTC','4h','0.000058300000000','0.000056700000000','0.001681686198294','0.001635533575356','28.845389336089195','28.845389336089195','test'),('2018-11-08 11:59:59','2018-11-09 03:59:59','NAVBTC','4h','0.000058300000000','0.000057800000000','0.001681686198294','0.001667263503626','28.845389336089195','28.845389336089195','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','NAVBTC','4h','0.000043000000000','0.000043700000000','0.001681686198294','0.001709062485243','39.108981355674416','39.108981355674416','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','NAVBTC','4h','0.000042800000000','0.000043000000000','0.001681686198294','0.001689544545015','39.291733605000005','39.291733605000005','test'),('2018-12-03 19:59:59','2018-12-04 11:59:59','NAVBTC','4h','0.000043100000000','0.000042500000000','0.001681686198294','0.001658275253538','39.018241259721584','39.018241259721584','test'),('2018-12-14 19:59:59','2018-12-18 07:59:59','NAVBTC','4h','0.000040700000000','0.000041700000000','0.001681686198294','0.001723005269505','41.31907121115479','41.319071211154792','test'),('2018-12-18 23:59:59','2018-12-19 03:59:59','NAVBTC','4h','0.000041600000000','0.000042000000000','0.001681686198294','0.001697856257893','40.42514899745192','40.425148997451920','test'),('2018-12-28 19:59:59','2018-12-29 03:59:59','NAVBTC','4h','0.000044900000000','0.000044300000000','0.001681686198294','0.001659213776936','37.454035596748334','37.454035596748334','test'),('2018-12-30 15:59:59','2018-12-31 03:59:59','NAVBTC','4h','0.000044600000000','0.000043600000000','0.001681686198294','0.001643980229722','37.70596857161435','37.705968571614349','test'),('2019-01-04 19:59:59','2019-01-06 07:59:59','NAVBTC','4h','0.000043500000000','0.000043900000000','0.001681686198294','0.001697149979428','38.659452834344826','38.659452834344826','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','NAVBTC','4h','0.000043600000000','0.000043300000000','0.001681686198294','0.001670114962985','38.57078436454128','38.570784364541282','test'),('2019-01-07 07:59:59','2019-01-08 11:59:59','NAVBTC','4h','0.000044300000000','0.000043300000000','0.001681686198294','0.001643724884563','37.96131373124154','37.961313731241539','test'),('2019-01-09 07:59:59','2019-01-09 15:59:59','NAVBTC','4h','0.000044000000000','0.000043900000000','0.001681686198294','0.001677864184207','38.22014087031818','38.220140870318183','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','NAVBTC','4h','0.000044200000000','0.000043400000000','0.001681686198294','0.001651248439049','38.04719905642534','38.047199056425342','test'),('2019-01-13 07:59:59','2019-01-13 11:59:59','NAVBTC','4h','0.000044200000000','0.000043300000000','0.001681686198294','0.001647443719143','38.04719905642534','38.047199056425342','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','NAVBTC','4h','0.000043300000000','0.000042800000000','0.001681686198294','0.001662267189076','38.83801843635104','38.838018436351042','test'),('2019-01-15 15:59:59','2019-01-20 11:59:59','NAVBTC','4h','0.000045600000000','0.000044400000000','0.001681686198294','0.001637431298339','36.879083295921056','36.879083295921056','test'),('2019-01-21 23:59:59','2019-01-23 23:59:59','NAVBTC','4h','0.000045300000000','0.000047000000000','0.001681686198294','0.001744795834875','37.12331563562914','37.123315635629140','test'),('2019-02-04 03:59:59','2019-02-04 07:59:59','NAVBTC','4h','0.000044500000000','0.000043500000000','0.001681686198294','0.001643895497209','37.79070108525843','37.790701085258434','test'),('2019-02-12 11:59:59','2019-02-12 19:59:59','NAVBTC','4h','0.000042100000000','0.000041700000000','0.001681686198294','0.001665708182158','39.945040339524944','39.945040339524944','test'),('2019-02-13 03:59:59','2019-02-14 11:59:59','NAVBTC','4h','0.000043400000000','0.000042000000000','0.001681686198294','0.001627438256414','38.7485299146083','38.748529914608298','test'),('2019-02-14 23:59:59','2019-02-15 03:59:59','NAVBTC','4h','0.000042400000000','0.000042000000000','0.001681686198294','0.001665821234159','39.662410337122644','39.662410337122644','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','NAVBTC','4h','0.000042400000000','0.000041800000000','0.001681686198294','0.001657888752092','39.662410337122644','39.662410337122644','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','NAVBTC','4h','0.000043400000000','0.000042000000000','0.001681686198294','0.001627438256414','38.7485299146083','38.748529914608298','test'),('2019-02-24 03:59:59','2019-02-24 07:59:59','NAVBTC','4h','0.000041900000000','0.000041200000000','0.001681686198294','0.001653591202141','40.13570878983293','40.135708789832933','test'),('2019-02-27 07:59:59','2019-02-27 15:59:59','NAVBTC','4h','0.000041900000000','0.000041200000000','0.001681686198294','0.001653591202141','40.13570878983293','40.135708789832933','test'),('2019-03-01 03:59:59','2019-03-03 19:59:59','NAVBTC','4h','0.000041100000000','0.000041300000000','0.001681686198294','0.001689869586120','40.91693913124087','40.916939131240873','test'),('2019-03-04 07:59:59','2019-03-04 11:59:59','NAVBTC','4h','0.000041200000000','0.000041300000000','0.001681686198294','0.001685767960911','40.81762617218447','40.817626172184468','test'),('2019-03-04 19:59:59','2019-03-08 23:59:59','NAVBTC','4h','0.000041700000000','0.000042000000000','0.001681686198294','0.001693784660152','40.32820619410072','40.328206194100723','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','NAVBTC','4h','0.000053000000000','0.000051200000000','0.001681686198294','0.001624572327409','31.729928269698114','31.729928269698114','test'),('2019-04-18 23:59:59','2019-04-19 03:59:59','NAVBTC','4h','0.000046100000000','0.000045500000000','0.001681686198294','0.001659798742351','36.47909323848156','36.479093238481560','test'),('2019-05-16 19:59:59','2019-05-16 23:59:59','NAVBTC','4h','0.000029400000000','0.000027800000000','0.001681686198294','0.001590165860972','57.20021082632653','57.200210826326533','test'),('2019-05-17 07:59:59','2019-05-17 11:59:59','NAVBTC','4h','0.000029200000000','0.000027800000000','0.001681686198294','0.001601057407965','57.591993092260275','57.591993092260275','test'),('2019-05-19 15:59:59','2019-05-19 23:59:59','NAVBTC','4h','0.000029400000000','0.000028000000000','0.001681686198294','0.001601605903137','57.20021082632653','57.200210826326533','test'),('2019-05-21 15:59:59','2019-05-21 19:59:59','NAVBTC','4h','0.000029100000000','0.000028600000000','0.001681686198294','0.001652791246433','57.7899037214433','57.789903721443302','test'),('2019-05-24 07:59:59','2019-05-24 11:59:59','NAVBTC','4h','0.000028800000000','0.000028500000000','0.001681686198294','0.001664168633728','58.39188188520834','58.391881885208342','test'),('2019-05-31 23:59:59','2019-06-01 03:59:59','NAVBTC','4h','0.000027000000000','0.000026100000000','0.001681686198294','0.001625629991684','62.28467401088889','62.284674010888892','test'),('2019-06-01 11:59:59','2019-06-03 19:59:59','NAVBTC','4h','0.000026900000000','0.000027300000000','0.001681686198294','0.001706692684514','62.51621554996283','62.516215549962830','test'),('2019-06-05 11:59:59','2019-06-06 19:59:59','NAVBTC','4h','0.000027700000000','0.000027200000000','0.001681686198294','0.001651330851754','60.71069307920578','60.710693079205782','test'),('2019-06-10 07:59:59','2019-06-14 03:59:59','NAVBTC','4h','0.000028100000000','0.000031100000000','0.001681686198294','0.001861225650069','59.846483925053384','59.846483925053384','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:24:07
