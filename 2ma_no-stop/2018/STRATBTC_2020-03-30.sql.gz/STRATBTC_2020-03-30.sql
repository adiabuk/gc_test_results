-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-03 03:59:59','2018-03-03 07:59:59','STRATBTC','4h','0.000769000000000','0.000750000000000','0.001467500000000','0.001431241872562','1.9083224967490247','1.908322496749025','test'),('2018-03-03 11:59:59','2018-03-03 15:59:59','STRATBTC','4h','0.000757000000000','0.000717000000000','0.001467500000000','0.001389957067371','1.9385733157199474','1.938573315719947','test'),('2018-03-21 03:59:59','2018-03-21 19:59:59','STRATBTC','4h','0.000584200000000','0.000593200000000','0.001467500000000','0.001490107839781','2.5119821978774395','2.511982197877439','test'),('2018-03-22 19:59:59','2018-03-22 23:59:59','STRATBTC','4h','0.000582800000000','0.000588200000000','0.001467500000000','0.001481097288950','2.5180164722031573','2.518016472203157','test'),('2018-03-23 15:59:59','2018-03-23 19:59:59','STRATBTC','4h','0.000585100000000','0.000572900000000','0.001467500000000','0.001436900957101','2.5081182703811318','2.508118270381132','test'),('2018-03-24 03:59:59','2018-03-24 07:59:59','STRATBTC','4h','0.000587700000000','0.000588200000000','0.001467500000000','0.001468748511145','2.4970222902841583','2.497022290284158','test'),('2018-04-07 15:59:59','2018-04-07 19:59:59','STRATBTC','4h','0.000539000000000','0.000543300000000','0.001467500000000','0.001479207328386','2.7226345083487944','2.722634508348794','test'),('2018-04-09 07:59:59','2018-04-09 11:59:59','STRATBTC','4h','0.000539400000000','0.000530200000000','0.001467500000000','0.001442470337412','2.7206154987022617','2.720615498702262','test'),('2018-04-10 19:59:59','2018-04-12 11:59:59','STRATBTC','4h','0.000548300000000','0.000538100000000','0.001467500000000','0.001440200164144','2.676454495714025','2.676454495714025','test'),('2018-05-13 23:59:59','2018-05-14 03:59:59','STRATBTC','4h','0.000746500000000','0.000722500000000','0.001467500000000','0.001420319825854','1.9658405894172808','1.965840589417281','test'),('2018-05-16 19:59:59','2018-05-16 23:59:59','STRATBTC','4h','0.000742500000000','0.000751100000000','0.001467500000000','0.001484497306397','1.9764309764309764','1.976430976430976','test'),('2018-05-22 07:59:59','2018-05-22 11:59:59','STRATBTC','4h','0.000729400000000','0.000720400000000','0.001467500000000','0.001449392651494','2.0119276117356732','2.011927611735673','test'),('2018-05-24 03:59:59','2018-05-24 07:59:59','STRATBTC','4h','0.000769200000000','0.000726400000000','0.001467500000000','0.001385845033801','1.9078263130525221','1.907826313052522','test'),('2018-07-01 11:59:59','2018-07-01 15:59:59','STRATBTC','4h','0.000418500000000','0.000405600000000','0.001467500000000','0.001422265232975','3.506571087216249','3.506571087216249','test'),('2018-07-04 11:59:59','2018-07-04 23:59:59','STRATBTC','4h','0.000418500000000','0.000408300000000','0.001467500000000','0.001431732974910','3.506571087216249','3.506571087216249','test'),('2018-07-05 03:59:59','2018-07-05 07:59:59','STRATBTC','4h','0.000412400000000','0.000413800000000','0.001467500000000','0.001472481813773','3.5584384093113486','3.558438409311349','test'),('2018-07-15 19:59:59','2018-07-15 23:59:59','STRATBTC','4h','0.000387500000000','0.000384500000000','0.001467500000000','0.001456138709677','3.787096774193549','3.787096774193549','test'),('2018-07-29 03:59:59','2018-07-29 07:59:59','STRATBTC','4h','0.000367500000000','0.000357500000000','0.001467500000000','0.001427568027211','3.993197278911565','3.993197278911565','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','STRATBTC','4h','0.000229300000000','0.000228400000000','0.001467500000000','0.001461740078500','6.399912778020061','6.399912778020061','test'),('2018-08-29 19:59:59','2018-08-29 23:59:59','STRATBTC','4h','0.000232200000000','0.000226700000000','0.001467500000000','0.001432740094746','6.319982773471145','6.319982773471145','test'),('2018-09-01 07:59:59','2018-09-02 15:59:59','STRATBTC','4h','0.000235000000000','0.000231100000000','0.001467500000000','0.001443145744681','6.24468085106383','6.244680851063830','test'),('2018-09-06 11:59:59','2018-09-06 15:59:59','STRATBTC','4h','0.000241700000000','0.000247500000000','0.001467500000000','0.001502715142739','6.071576334298718','6.071576334298718','test'),('2018-09-15 15:59:59','2018-09-15 19:59:59','STRATBTC','4h','0.000223400000000','0.000221100000000','0.001467500000000','0.001452391450313','6.568934646374217','6.568934646374217','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','STRATBTC','4h','0.000216500000000','0.000213700000000','0.001467500000000','0.001448520785219','6.778290993071594','6.778290993071594','test'),('2018-09-21 15:59:59','2018-09-22 11:59:59','STRATBTC','4h','0.000221400000000','0.000219000000000','0.001467500000000','0.001451592140921','6.628274616079494','6.628274616079494','test'),('2018-10-06 03:59:59','2018-10-06 07:59:59','STRATBTC','4h','0.000233900000000','0.000234000000000','0.001467500000000','0.001468127404874','6.274048738777256','6.274048738777256','test'),('2018-10-09 07:59:59','2018-10-09 11:59:59','STRATBTC','4h','0.000231900000000','0.000229900000000','0.001467500000000','0.001454843682622','6.328158689090126','6.328158689090126','test'),('2018-10-17 23:59:59','2018-10-18 03:59:59','STRATBTC','4h','0.000221500000000','0.000220300000000','0.001467500000000','0.001459549661400','6.62528216704289','6.625282167042890','test'),('2018-10-18 11:59:59','2018-10-18 15:59:59','STRATBTC','4h','0.000221100000000','0.000218400000000','0.001467500000000','0.001449579375848','6.637268204432384','6.637268204432384','test'),('2018-10-20 19:59:59','2018-10-21 11:59:59','STRATBTC','4h','0.000220100000000','0.000222100000000','0.001467500000000','0.001480834847796','6.667423898228078','6.667423898228078','test'),('2018-10-22 07:59:59','2018-10-22 15:59:59','STRATBTC','4h','0.000222700000000','0.000225800000000','0.001467500000000','0.001487927705433','6.589582397844635','6.589582397844635','test'),('2018-11-01 11:59:59','2018-11-01 15:59:59','STRATBTC','4h','0.000246000000000','0.000245800000000','0.001467500000000','0.001466306910569','5.965447154471544','5.965447154471544','test'),('2018-11-28 19:59:59','2018-11-30 03:59:59','STRATBTC','4h','0.000194900000000','0.000185300000000','0.001467500000000','0.001395216777835','7.5295023088763475','7.529502308876348','test'),('2018-12-12 15:59:59','2018-12-12 23:59:59','STRATBTC','4h','0.000193600000000','0.000189400000000','0.001467500000000','0.001435663739669','7.580061983471075','7.580061983471075','test'),('2018-12-13 15:59:59','2018-12-13 19:59:59','STRATBTC','4h','0.000190900000000','0.000186400000000','0.001467500000000','0.001432907281299','7.687270822420115','7.687270822420115','test'),('2018-12-15 23:59:59','2018-12-16 19:59:59','STRATBTC','4h','0.000190800000000','0.000194900000000','0.001467500000000','0.001499034329140','7.691299790356394','7.691299790356394','test'),('2019-01-15 19:59:59','2019-01-18 11:59:59','STRATBTC','4h','0.000279400000000','0.000274300000000','0.001467500000000','0.001440713135290','5.252326413743736','5.252326413743736','test'),('2019-01-19 11:59:59','2019-01-20 11:59:59','STRATBTC','4h','0.000291400000000','0.000273300000000','0.001467500000000','0.001376347803706','5.0360329444063145','5.036032944406315','test'),('2019-01-22 23:59:59','2019-01-23 23:59:59','STRATBTC','4h','0.000278400000000','0.000281100000000','0.001467500000000','0.001481732219828','5.271192528735632','5.271192528735632','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','STRATBTC','4h','0.000279000000000','0.000277900000000','0.001467500000000','0.001461714157706','5.259856630824373','5.259856630824373','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','STRATBTC','4h','0.000228900000000','0.000230500000000','0.001467500000000','0.001477757754478','6.411096548711227','6.411096548711227','test'),('2019-02-13 15:59:59','2019-02-13 19:59:59','STRATBTC','4h','0.000228000000000','0.000232800000000','0.001467500000000','0.001498394736842','6.43640350877193','6.436403508771930','test'),('2019-02-17 03:59:59','2019-02-17 15:59:59','STRATBTC','4h','0.000236100000000','0.000236800000000','0.001467500000000','0.001471850910631','6.215586615840746','6.215586615840746','test'),('2019-02-19 15:59:59','2019-02-19 23:59:59','STRATBTC','4h','0.000233700000000','0.000231500000000','0.001467500000000','0.001453685280274','6.279418057338469','6.279418057338469','test'),('2019-02-20 23:59:59','2019-02-21 15:59:59','STRATBTC','4h','0.000233800000000','0.000234200000000','0.001467500000000','0.001470010692900','6.276732249786143','6.276732249786143','test'),('2019-02-22 19:59:59','2019-02-23 03:59:59','STRATBTC','4h','0.000236400000000','0.000231800000000','0.001467500000000','0.001438944585448','6.207698815566836','6.207698815566836','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','STRATBTC','4h','0.000234300000000','0.000230900000000','0.001467500000000','0.001446204652155','6.2633376013657704','6.263337601365770','test'),('2019-02-26 19:59:59','2019-02-27 03:59:59','STRATBTC','4h','0.000234600000000','0.000229300000000','0.001467500000000','0.001434346760443','6.255328218243819','6.255328218243819','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  6:39:15
