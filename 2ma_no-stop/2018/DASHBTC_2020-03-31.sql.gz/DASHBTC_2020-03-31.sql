-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-09 03:59:59','2018-04-09 15:59:59','DASHBTC','4h','0.045013000000000','0.044265000000000','0.001467500000000','0.001443113933752','0.03260169284428943','0.032601692844289','test'),('2018-04-12 03:59:59','2018-04-12 11:59:59','DASHBTC','4h','0.045100000000000','0.043565000000000','0.001467500000000','0.001417552937916','0.03253880266075388','0.032538802660754','test'),('2018-04-12 23:59:59','2018-04-13 03:59:59','DASHBTC','4h','0.045085000000000','0.044953000000000','0.001467500000000','0.001463203449041','0.03254962847953865','0.032549628479539','test'),('2018-04-15 03:59:59','2018-04-15 07:59:59','DASHBTC','4h','0.044765000000000','0.045262000000000','0.001467500000000','0.001483792806880','0.03278230760638892','0.032782307606389','test'),('2018-05-01 15:59:59','2018-05-02 03:59:59','DASHBTC','4h','0.052668000000000','0.052043000000000','0.001467500000000','0.001450085488342','0.02786321865269234','0.027863218652692','test'),('2018-05-02 15:59:59','2018-05-03 19:59:59','DASHBTC','4h','0.052145000000000','0.051780000000000','0.001467500000000','0.001457227922140','0.02814267906798351','0.028142679067984','test'),('2018-05-06 03:59:59','2018-05-06 07:59:59','DASHBTC','4h','0.052350000000000','0.050913000000000','0.001467500000000','0.001427217335244','0.028032473734479466','0.028032473734479','test'),('2018-05-14 19:59:59','2018-05-16 03:59:59','DASHBTC','4h','0.050350000000000','0.048801000000000','0.001467500000000','0.001422352879841','0.029145978152929495','0.029145978152929','test'),('2018-06-03 11:59:59','2018-06-03 19:59:59','DASHBTC','4h','0.043337000000000','0.043039000000000','0.001467500000000','0.001457408969241','0.03386251932528786','0.033862519325288','test'),('2018-06-16 19:59:59','2018-06-17 15:59:59','DASHBTC','4h','0.040855000000000','0.041568000000000','0.001467500000000','0.001493110757557','0.035919716069024596','0.035919716069025','test'),('2018-06-23 03:59:59','2018-06-23 15:59:59','DASHBTC','4h','0.040405000000000','0.039560000000000','0.001467500000000','0.001436809800767','0.036319762405642865','0.036319762405643','test'),('2018-07-03 03:59:59','2018-07-03 19:59:59','DASHBTC','4h','0.038682000000000','0.038000000000000','0.001467500000000','0.001441626596350','0.03793754200920325','0.037937542009203','test'),('2018-07-13 03:59:59','2018-07-13 11:59:59','DASHBTC','4h','0.038594000000000','0.036242000000000','0.001467500000000','0.001378067445717','0.03802404518837125','0.038024045188371','test'),('2018-07-15 15:59:59','2018-07-16 03:59:59','DASHBTC','4h','0.036189000000000','0.036077000000000','0.001467500000000','0.001462958288430','0.04055099615905386','0.040550996159054','test'),('2018-07-18 23:59:59','2018-07-19 03:59:59','DASHBTC','4h','0.036096000000000','0.035862000000000','0.001467500000000','0.001457986619016','0.04065547429078014','0.040655474290780','test'),('2018-07-19 11:59:59','2018-07-19 15:59:59','DASHBTC','4h','0.036332000000000','0.035707000000000','0.001467500000000','0.001442255380931','0.040391390509743476','0.040391390509743','test'),('2018-07-20 07:59:59','2018-07-20 15:59:59','DASHBTC','4h','0.036796000000000','0.035526000000000','0.001467500000000','0.001416849793456','0.03988205239699967','0.039882052397000','test'),('2018-08-06 03:59:59','2018-08-06 07:59:59','DASHBTC','4h','0.029725000000000','0.029470000000000','0.001467500000000','0.001454910849453','0.049369217830109335','0.049369217830109','test'),('2018-08-27 19:59:59','2018-09-05 19:59:59','DASHBTC','4h','0.023287000000000','0.026749000000000','0.001467500000000','0.001685668291321','0.06301799287155925','0.063017992871559','test'),('2018-09-06 23:59:59','2018-09-07 07:59:59','DASHBTC','4h','0.027780000000000','0.027548000000000','0.001467500000000','0.001455244420446','0.052825773938084956','0.052825773938085','test'),('2018-09-13 11:59:59','2018-09-14 11:59:59','DASHBTC','4h','0.029751000000000','0.029126000000000','0.001467500000000','0.001436671204329','0.049326073073174014','0.049326073073174','test'),('2018-09-15 11:59:59','2018-09-15 15:59:59','DASHBTC','4h','0.029222000000000','0.029064000000000','0.001467500000000','0.001459565395935','0.05021901307234276','0.050219013072343','test'),('2018-09-15 19:59:59','2018-09-16 03:59:59','DASHBTC','4h','0.029504000000000','0.028924000000000','0.001467500000000','0.001438651369306','0.04973901843817788','0.049739018438178','test'),('2018-09-16 23:59:59','2018-09-17 23:59:59','DASHBTC','4h','0.029478000000000','0.029280000000000','0.001467500000000','0.001457642987991','0.04978288893412036','0.049782888934120','test'),('2018-09-18 15:59:59','2018-09-18 23:59:59','DASHBTC','4h','0.029556000000000','0.030284000000000','0.001467500000000','0.001503646298552','0.04965150899986467','0.049651508999865','test'),('2018-10-30 15:59:59','2018-10-30 19:59:59','DASHBTC','4h','0.024190000000000','0.024219000000000','0.001467500000000','0.001469259301364','0.06066556428276147','0.060665564282761','test'),('2018-11-02 15:59:59','2018-11-02 19:59:59','DASHBTC','4h','0.024255000000000','0.024221000000000','0.001467500000000','0.001465442898371','0.06050298907441765','0.060502989074418','test'),('2018-11-10 11:59:59','2018-11-10 19:59:59','DASHBTC','4h','0.025500000000000','0.025319000000000','0.001467500000000','0.001457083627451','0.057549019607843144','0.057549019607843','test'),('2018-11-12 07:59:59','2018-11-13 19:59:59','DASHBTC','4h','0.025281000000000','0.025178000000000','0.001467500000000','0.001461521102804','0.05804754558759543','0.058047545587595','test'),('2018-11-14 19:59:59','2018-11-14 23:59:59','DASHBTC','4h','0.025440000000000','0.025090000000000','0.001467500000000','0.001447310338050','0.057684748427672954','0.057684748427673','test'),('2018-11-21 15:59:59','2018-11-22 07:59:59','DASHBTC','4h','0.024253000000000','0.024487000000000','0.001467500000000','0.001481658866944','0.060507978394425434','0.060507978394425','test'),('2018-11-22 19:59:59','2018-11-22 23:59:59','DASHBTC','4h','0.024326000000000','0.023413000000000','0.001467500000000','0.001412421997040','0.06032639973690702','0.060326399736907','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','DASHBTC','4h','0.019856000000000','0.019558000000000','0.001467500000000','0.001445475674859','0.07390713134568896','0.073907131345689','test'),('2018-12-17 11:59:59','2018-12-18 11:59:59','DASHBTC','4h','0.019828000000000','0.019592000000000','0.001467500000000','0.001450033286262','0.07401149889045795','0.074011498890458','test'),('2018-12-20 19:59:59','2018-12-25 15:59:59','DASHBTC','4h','0.021262000000000','0.021251000000000','0.001467500000000','0.001466740781676','0.06901984761546422','0.069019847615464','test'),('2018-12-28 23:59:59','2018-12-29 07:59:59','DASHBTC','4h','0.021479000000000','0.021380000000000','0.001467500000000','0.001460736067787','0.06832254760463709','0.068322547604637','test'),('2018-12-30 03:59:59','2018-12-30 07:59:59','DASHBTC','4h','0.021501000000000','0.021359000000000','0.001467500000000','0.001457808125203','0.06825263941212037','0.068252639412120','test'),('2018-12-31 07:59:59','2018-12-31 15:59:59','DASHBTC','4h','0.021796000000000','0.021203000000000','0.001467500000000','0.001427573981464','0.06732886768214352','0.067328867682144','test'),('2019-01-02 11:59:59','2019-01-03 11:59:59','DASHBTC','4h','0.021439000000000','0.021156000000000','0.001467500000000','0.001448128644060','0.06845002098978498','0.068450020989785','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','DASHBTC','4h','0.021280000000000','0.020942000000000','0.001467500000000','0.001444191024436','0.06896146616541353','0.068961466165414','test'),('2019-01-09 19:59:59','2019-01-10 07:59:59','DASHBTC','4h','0.021501000000000','0.020148000000000','0.001467500000000','0.001375154178875','0.06825263941212037','0.068252639412120','test'),('2019-01-22 19:59:59','2019-01-22 23:59:59','DASHBTC','4h','0.019778000000000','0.019822000000000','0.001467500000000','0.001470764738598','0.07419860451006169','0.074198604510062','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','DASHBTC','4h','0.019753000000000','0.019540000000000','0.001467500000000','0.001451675694831','0.07429251252974232','0.074292512529742','test'),('2019-02-07 15:59:59','2019-02-08 19:59:59','DASHBTC','4h','0.019546000000000','0.020011000000000','0.001467500000000','0.001502411874552','0.075079300112555','0.075079300112555','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','DASHBTC','4h','0.021582000000000','0.021403000000000','0.001467500000000','0.001455328630340','0.06799647854693726','0.067996478546937','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','DASHBTC','4h','0.021608000000000','0.021530000000000','0.001467500000000','0.001462202656424','0.06791466123657905','0.067914661236579','test'),('2019-02-22 23:59:59','2019-02-23 03:59:59','DASHBTC','4h','0.021591000000000','0.021556000000000','0.001467500000000','0.001465121115280','0.06796813487101107','0.067968134871011','test'),('2019-02-23 19:59:59','2019-02-23 23:59:59','DASHBTC','4h','0.021700000000000','0.021609000000000','0.001467500000000','0.001461345967742','0.06762672811059908','0.067626728110599','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','DASHBTC','4h','0.021721000000000','0.021578000000000','0.001467500000000','0.001457838727499','0.0675613461626997','0.067561346162700','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','DASHBTC','4h','0.021570000000000','0.021442000000000','0.001467500000000','0.001458791608716','0.06803430690774225','0.068034306907742','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','DASHBTC','4h','0.021384000000000','0.021007000000000','0.001467500000000','0.001441627969510','0.06862607557052001','0.068626075570520','test'),('2019-03-06 19:59:59','2019-03-07 07:59:59','DASHBTC','4h','0.021475000000000','0.021240000000000','0.001467500000000','0.001451441210710','0.06833527357392316','0.068335273573923','test'),('2019-03-11 23:59:59','2019-03-20 07:59:59','DASHBTC','4h','0.021448000000000','0.022860000000000','0.001467500000000','0.001564110872809','0.0684212980231257','0.068421298023126','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','DASHBTC','4h','0.022649000000000','0.022543000000000','0.001467500000000','0.001460631926354','0.06479314760033555','0.064793147600336','test'),('2019-03-27 11:59:59','2019-04-02 07:59:59','DASHBTC','4h','0.023291000000000','0.025451000000000','0.001467500000000','0.001603595487527','0.0630071701515607','0.063007170151561','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  7:39:31
