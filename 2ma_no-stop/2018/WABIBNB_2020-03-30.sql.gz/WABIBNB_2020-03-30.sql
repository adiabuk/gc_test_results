-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 03:59:59','2018-07-10 07:59:59','WABIBNB','4h','0.026420000000000','0.029100000000000','0.711908500000000','0.784123291067373','26.94581756245269','26.945817562452689','test'),('2018-07-14 03:59:59','2018-07-14 07:59:59','WABIBNB','4h','0.028540000000000','0.028050000000000','0.729962197766843','0.717429560173789','25.57681141439535','25.576811414395351','test'),('2018-07-15 15:59:59','2018-07-16 07:59:59','WABIBNB','4h','0.028730000000000','0.027920000000000','0.729962197766843','0.709381989615394','25.4076643845055','25.407664384505502','test'),('2018-07-20 15:59:59','2018-07-20 19:59:59','WABIBNB','4h','0.032000000000000','0.029260000000000','0.729962197766843','0.667459184583057','22.811318680213844','22.811318680213844','test'),('2018-07-23 03:59:59','2018-07-23 07:59:59','WABIBNB','4h','0.031960000000000','0.030280000000000','0.729962197766843','0.691591218660200','22.839868515858665','22.839868515858665','test'),('2018-08-17 07:59:59','2018-08-17 23:59:59','WABIBNB','4h','0.015390000000000','0.015240000000000','0.729962197766843','0.722847556463073','47.430942025136','47.430942025135998','test'),('2018-08-19 23:59:59','2018-08-20 11:59:59','WABIBNB','4h','0.015150000000000','0.015080000000000','0.729962197766843','0.726589435136897','48.18232328494013','48.182323284940132','test'),('2018-09-07 11:59:59','2018-09-07 15:59:59','WABIBNB','4h','0.019950000000000','0.018400000000000','0.729962197766843','0.673248342802502','36.58958384796206','36.589583847962061','test'),('2018-09-08 11:59:59','2018-09-08 15:59:59','WABIBNB','4h','0.019500000000000','0.018900000000000','0.729962197766843','0.707501822450940','37.4339588598381','37.433958859838100','test'),('2018-09-13 03:59:59','2018-09-13 19:59:59','WABIBNB','4h','0.019360000000000','0.018120000000000','0.729962197766843','0.683208420637149','37.70465897556007','37.704658975560072','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','WABIBNB','4h','0.019050000000000','0.018170000000000','0.729962197766843','0.696242159234831','38.318225604558684','38.318225604558684','test'),('2018-09-15 15:59:59','2018-09-20 03:59:59','WABIBNB','4h','0.021250000000000','0.019560000000000','0.729962197766843','0.671908733567974','34.351162247851434','34.351162247851434','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','WABIBNB','4h','0.020250000000000','0.019710000000000','0.729962197766843','0.710496539159727','36.047515939103356','36.047515939103356','test'),('2018-09-25 03:59:59','2018-09-29 07:59:59','WABIBNB','4h','0.021610000000000','0.021280000000000','0.729962197766843','0.718815158189654','33.77890780966418','33.778907809664183','test'),('2018-09-30 11:59:59','2018-09-30 15:59:59','WABIBNB','4h','0.021400000000000','0.021140000000000','0.729962197766843','0.721093498167807','34.110383073216965','34.110383073216965','test'),('2018-10-01 19:59:59','2018-10-01 23:59:59','WABIBNB','4h','0.021480000000000','0.021710000000000','0.729962197766843','0.737778366551125','33.98334254035582','33.983342540355821','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','WABIBNB','4h','0.021490000000000','0.020120000000000','0.729962197766843','0.683426683065095','33.96752897937846','33.967528979378457','test'),('2018-10-13 15:59:59','2018-10-22 07:59:59','WABIBNB','4h','0.025940000000000','0.025390000000000','0.729962197766843','0.714484973064770','28.140408549222936','28.140408549222936','test'),('2018-10-22 23:59:59','2018-10-23 23:59:59','WABIBNB','4h','0.026500000000000','0.026260000000000','0.729962197766843','0.723351219371973','27.54574331195634','27.545743311956340','test'),('2018-10-28 03:59:59','2018-10-29 15:59:59','WABIBNB','4h','0.026400000000000','0.026870000000000','0.729962197766843','0.742957736893753','27.650083248744053','27.650083248744053','test'),('2018-11-06 15:59:59','2018-11-08 23:59:59','WABIBNB','4h','0.030260000000000','0.029300000000000','0.729962197766843','0.706804110858179','24.123007196524885','24.123007196524885','test'),('2018-11-09 07:59:59','2018-11-09 19:59:59','WABIBNB','4h','0.029880000000000','0.029300000000000','0.729962197766843','0.715792918158250','24.429792428609204','24.429792428609204','test'),('2018-11-10 23:59:59','2018-11-11 03:59:59','WABIBNB','4h','0.029960000000000','0.029400000000000','0.729962197766843','0.716318044537556','24.364559338012118','24.364559338012118','test'),('2018-11-23 23:59:59','2018-11-24 07:59:59','WABIBNB','4h','0.027450000000000','0.026430000000000','0.729962197766843','0.702837919379878','26.59242979114182','26.592429791141821','test'),('2018-11-25 03:59:59','2018-11-27 11:59:59','WABIBNB','4h','0.027210000000000','0.027610000000000','0.729962197766843','0.740692990824790','26.82698264486744','26.826982644867439','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','WABIBNB','4h','0.029950000000000','0.028910000000000','0.729962197766843','0.704614595573938','24.372694416255193','24.372694416255193','test'),('2018-12-16 19:59:59','2018-12-18 03:59:59','WABIBNB','4h','0.025780000000000','0.024030000000000','0.729962197766843','0.680410846095316','28.315058098015633','28.315058098015633','test'),('2018-12-22 07:59:59','2018-12-22 15:59:59','WABIBNB','4h','0.025000000000000','0.023410000000000','0.729962197766843','0.683536601988872','29.19848791067372','29.198487910673720','test'),('2018-12-22 19:59:59','2018-12-22 23:59:59','WABIBNB','4h','0.024300000000000','0.024030000000000','0.729962197766843','0.721851506680545','30.039596615919468','30.039596615919468','test'),('2019-01-03 19:59:59','2019-01-03 23:59:59','WABIBNB','4h','0.022250000000000','0.021490000000000','0.729962197766843','0.705028657528515','32.807289787273845','32.807289787273845','test'),('2019-01-17 15:59:59','2019-01-17 19:59:59','WABIBNB','4h','0.019890000000000','0.019500000000000','0.729962197766843','0.715649213496905','36.699959666507944','36.699959666507944','test'),('2019-01-18 15:59:59','2019-01-20 15:59:59','WABIBNB','4h','0.024420000000000','0.020110000000000','0.729962197766843','0.601127755818641','29.89198189053411','29.891981890534112','test'),('2019-01-21 15:59:59','2019-01-21 19:59:59','WABIBNB','4h','0.020530000000000','0.020170000000000','0.486641465177895','0.478108054195721','23.703919394929144','23.703919394929144','test'),('2019-01-22 23:59:59','2019-01-24 07:59:59','WABIBNB','4h','0.021080000000000','0.020250000000000','0.524241252011040','0.503599874441345','24.869129602041752','24.869129602041752','test'),('2019-01-24 23:59:59','2019-01-25 03:59:59','WABIBNB','4h','0.020610000000000','0.021050000000000','0.524241252011040','0.535433204989442','25.436256769094616','25.436256769094616','test'),('2019-01-30 11:59:59','2019-01-30 19:59:59','WABIBNB','4h','0.019420000000000','0.019880000000000','0.524241252011040','0.536658912975256','26.994915139600412','26.994915139600412','test'),('2019-02-17 15:59:59','2019-02-17 19:59:59','WABIBNB','4h','0.014950000000000','0.014620000000000','0.524983311104271','0.513395050725381','35.11594054209171','35.115940542091707','test'),('2019-02-25 19:59:59','2019-02-28 15:59:59','WABIBNB','4h','0.014080000000000','0.015280000000000','0.524983311104271','0.569726206937021','37.28574652729197','37.285746527291970','test'),('2019-03-02 07:59:59','2019-03-02 11:59:59','WABIBNB','4h','0.014700000000000','0.014110000000000','0.533271969967736','0.511868537159507','36.27700475970993','36.277004759709932','test'),('2019-03-02 15:59:59','2019-03-02 19:59:59','WABIBNB','4h','0.014900000000000','0.014370000000000','0.533271969967736','0.514303235465528','35.79006509850577','35.790065098505771','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','WABIBNB','4h','0.015500000000000','0.015000000000000','0.533271969967736','0.516069648355874','34.404643223724904','34.404643223724904','test'),('2019-03-08 07:59:59','2019-03-08 23:59:59','WABIBNB','4h','0.014520000000000','0.014400000000000','0.533271969967736','0.528864763604366','36.72671969474766','36.726719694747658','test'),('2019-03-13 03:59:59','2019-03-13 07:59:59','WABIBNB','4h','0.014550000000000','0.014340000000000','0.533271969967736','0.525575261122841','36.650994499500754','36.650994499500754','test'),('2019-03-15 03:59:59','2019-03-15 11:59:59','WABIBNB','4h','0.014580000000000','0.014470000000000','0.533271969967736','0.529248656065373','36.57558093057174','36.575580930571739','test'),('2019-03-19 11:59:59','2019-03-21 15:59:59','WABIBNB','4h','0.014440000000000','0.015370000000000','0.533271969967736','0.567617048365935','36.9301918260205','36.930191826020497','test'),('2019-03-27 19:59:59','2019-03-28 07:59:59','WABIBNB','4h','0.014490000000000','0.014130000000000','0.533271969967736','0.520022976925059','36.80275845187964','36.802758451879640','test'),('2019-04-03 07:59:59','2019-04-03 15:59:59','WABIBNB','4h','0.018110000000000','0.017910000000000','0.533271969967736','0.527382715743907','29.446271119146104','29.446271119146104','test'),('2019-04-04 23:59:59','2019-04-05 03:59:59','WABIBNB','4h','0.017750000000000','0.017740000000000','0.533271969967736','0.532971535055078','30.043491265787946','30.043491265787946','test'),('2019-04-06 23:59:59','2019-04-07 07:59:59','WABIBNB','4h','0.017590000000000','0.017500000000000','0.533271969967736','0.530543460741068','30.31676918520386','30.316769185203860','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','WABIBNB','4h','0.017490000000000','0.017430000000000','0.533271969967736','0.531442563552752','30.490106916394282','30.490106916394282','test'),('2019-04-08 23:59:59','2019-04-09 03:59:59','WABIBNB','4h','0.017570000000000','0.017010000000000','0.533271969967736','0.516275253793466','30.351278882625838','30.351278882625838','test'),('2019-04-12 15:59:59','2019-04-12 19:59:59','WABIBNB','4h','0.017700000000000','0.019420000000000','0.533271969967736','0.585092748970250','30.12835988518282','30.128359885182821','test'),('2019-04-24 19:59:59','2019-04-24 23:59:59','WABIBNB','4h','0.016960000000000','0.016150000000000','0.533271969967736','0.507803202534135','31.4429227575316','31.442922757531601','test'),('2019-04-25 07:59:59','2019-04-25 11:59:59','WABIBNB','4h','0.016880000000000','0.017500000000000','0.533271969967736','0.552858973603992','31.591941348799526','31.591941348799526','test'),('2019-04-30 15:59:59','2019-04-30 19:59:59','WABIBNB','4h','0.016010000000000','0.015730000000000','0.533271969967736','0.523945539512335','33.308680197859836','33.308680197859836','test'),('2019-04-30 23:59:59','2019-05-01 03:59:59','WABIBNB','4h','0.016010000000000','0.016010000000000','0.533271969967736','0.533271969967736','33.308680197859836','33.308680197859836','test'),('2019-05-05 11:59:59','2019-05-05 19:59:59','WABIBNB','4h','0.016090000000000','0.015110000000000','0.533271969967736','0.500791762971566','33.14306836343915','33.143068363439149','test'),('2019-05-08 07:59:59','2019-05-08 19:59:59','WABIBNB','4h','0.015540000000000','0.015300000000000','0.533271969967736','0.525036109427694','34.31608558350939','34.316085583509391','test'),('2019-05-10 11:59:59','2019-05-11 11:59:59','WABIBNB','4h','0.016250000000000','0.015530000000000','0.533271969967736','0.509643919606089','32.81673661339914','32.816736613399137','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 17:03:31
