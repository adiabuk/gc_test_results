-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-29 15:59:59','2018-07-29 19:59:59','AEBNB','4h','0.156230000000000','0.144380000000000','0.711908500000000','0.657910447609294','4.556797670101773','4.556797670101773','test'),('2018-07-30 03:59:59','2018-07-31 07:59:59','AEBNB','4h','0.151240000000000','0.148000000000000','0.711908500000000','0.696657352552235','4.707144274001587','4.707144274001587','test'),('2018-08-17 19:59:59','2018-08-18 07:59:59','AEBNB','4h','0.113530000000000','0.104930000000000','0.711908500000000','0.657980788381926','6.270664141636572','6.270664141636572','test'),('2018-08-25 15:59:59','2018-08-25 19:59:59','AEBNB','4h','0.104870000000000','0.101810000000000','0.711908500000000','0.691135733622580','6.788485744254792','6.788485744254792','test'),('2018-08-28 11:59:59','2018-08-28 15:59:59','AEBNB','4h','0.103440000000000','0.104390000000000','0.711908500000000','0.718446716115623','6.88233275328693','6.882332753286930','test'),('2018-08-30 19:59:59','2018-08-30 23:59:59','AEBNB','4h','0.104650000000000','0.101470000000000','0.711908500000000','0.690275733349260','6.802756808408982','6.802756808408982','test'),('2018-08-31 07:59:59','2018-08-31 15:59:59','AEBNB','4h','0.104830000000000','0.105190000000000','0.711908500000000','0.714353287370028','6.791076027854622','6.791076027854622','test'),('2018-09-01 15:59:59','2018-09-02 11:59:59','AEBNB','4h','0.105700000000000','0.104300000000000','0.711908500000000','0.702479248344371','6.735179754020814','6.735179754020814','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','AEBNB','4h','0.106730000000000','0.106220000000000','0.711908500000000','0.708506707298791','6.670181767075799','6.670181767075799','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','AEBNB','4h','0.099250000000000','0.101270000000000','0.711908500000000','0.726397720856423','7.172881612090681','7.172881612090681','test'),('2018-09-15 15:59:59','2018-09-16 07:59:59','AEBNB','4h','0.102010000000000','0.100900000000000','0.711908500000000','0.704162019900010','6.97881090089207','6.978810900892070','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','AEBNB','4h','0.101350000000000','0.100660000000000','0.711908500000000','0.707061762308831','7.024257523433647','7.024257523433647','test'),('2018-09-20 23:59:59','2018-09-21 03:59:59','AEBNB','4h','0.099270000000000','0.096790000000000','0.711908500000000','0.694123337513851','7.171436486350358','7.171436486350358','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','AEBNB','4h','0.099750000000000','0.096800000000000','0.711908500000000','0.690854564411028','7.136927318295739','7.136927318295739','test'),('2018-09-21 19:59:59','2018-09-22 11:59:59','AEBNB','4h','0.100530000000000','0.100410000000000','0.711908500000000','0.711058713667562','7.08155277031732','7.081552770317320','test'),('2018-09-23 07:59:59','2018-09-23 19:59:59','AEBNB','4h','0.098270000000000','0.097810000000000','0.711908500000000','0.708576069858553','7.244413350971813','7.244413350971813','test'),('2018-09-25 15:59:59','2018-09-25 19:59:59','AEBNB','4h','0.098820000000000','0.097980000000000','0.711908500000000','0.705857061627201','7.204093300951224','7.204093300951224','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','AEBNB','4h','0.099390000000000','0.098740000000000','0.711908500000000','0.707252694335446','7.162777945467351','7.162777945467351','test'),('2018-10-04 03:59:59','2018-10-04 15:59:59','AEBNB','4h','0.105150000000000','0.102650000000000','0.711908500000000','0.694982477650975','6.770408939610082','6.770408939610082','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','AEBNB','4h','0.103230000000000','0.101330000000000','0.711908500000000','0.698805466482612','6.896333430204399','6.896333430204399','test'),('2018-10-08 15:59:59','2018-10-08 19:59:59','AEBNB','4h','0.103220000000000','0.102060000000000','0.711908500000000','0.703907978201899','6.897001550087192','6.897001550087192','test'),('2018-10-09 03:59:59','2018-10-09 07:59:59','AEBNB','4h','0.103120000000000','0.103720000000000','0.711908500000000','0.716050713925524','6.90368987587277','6.903689875872770','test'),('2018-10-26 03:59:59','2018-10-26 07:59:59','AEBNB','4h','0.129960000000000','0.127860000000000','0.711908500000000','0.700404900046168','5.4779047399199765','5.477904739919977','test'),('2018-10-26 15:59:59','2018-10-27 07:59:59','AEBNB','4h','0.132760000000000','0.132030000000000','0.711908500000000','0.707993968476951','5.362371949382345','5.362371949382345','test'),('2018-10-28 07:59:59','2018-10-28 15:59:59','AEBNB','4h','0.130300000000000','0.130710000000000','0.711908500000000','0.714148580468150','5.463610897927859','5.463610897927859','test'),('2018-11-12 11:59:59','2018-11-12 15:59:59','AEBNB','4h','0.123420000000000','0.124300000000000','0.711908500000000','0.716984496434938','5.768177766974559','5.768177766974559','test'),('2018-11-12 23:59:59','2018-11-13 03:59:59','AEBNB','4h','0.123340000000000','0.120030000000000','0.711908500000000','0.692803447827144','5.77191908545484','5.771919085454840','test'),('2018-11-24 15:59:59','2018-11-24 23:59:59','AEBNB','4h','0.120700000000000','0.114100000000000','0.711908500000000','0.672980611847556','5.898164871582436','5.898164871582436','test'),('2018-11-28 03:59:59','2018-11-29 03:59:59','AEBNB','4h','0.119500000000000','0.113330000000000','0.711908500000000','0.675151383305439','5.957393305439331','5.957393305439331','test'),('2018-11-29 19:59:59','2018-11-29 23:59:59','AEBNB','4h','0.113740000000000','0.111910000000000','0.711908500000000','0.700454371681027','6.259086513100054','6.259086513100054','test'),('2018-12-21 03:59:59','2018-12-22 07:59:59','AEBNB','4h','0.083380000000000','0.079630000000000','0.711908500000000','0.679890547553370','8.538120652434637','8.538120652434637','test'),('2018-12-23 03:59:59','2018-12-23 07:59:59','AEBNB','4h','0.080490000000000','0.077940000000000','0.711908500000000','0.689354559448379','8.844682569263263','8.844682569263263','test'),('2018-12-24 03:59:59','2018-12-24 07:59:59','AEBNB','4h','0.079290000000000','0.078920000000000','0.711908500000000','0.708586439904149','8.978540799596418','8.978540799596418','test'),('2018-12-24 15:59:59','2018-12-24 19:59:59','AEBNB','4h','0.078480000000000','0.078920000000000','0.711908500000000','0.715899832059123','9.071209225280327','9.071209225280327','test'),('2019-01-10 07:59:59','2019-01-10 11:59:59','AEBNB','4h','0.067570000000000','0.064800000000000','0.711908500000000','0.682724149770608','10.535866508805682','10.535866508805682','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','AEBNB','4h','0.064360000000000','0.065080000000000','0.711908500000000','0.719872672156619','11.061350217526416','11.061350217526416','test'),('2019-01-19 11:59:59','2019-01-19 15:59:59','AEBNB','4h','0.070000000000000','0.068220000000000','0.711908500000000','0.693805683857143','10.170121428571429','10.170121428571429','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','AEBNB','4h','0.046230000000000','0.044730000000000','0.711908500000000','0.688809586956522','15.399275362318841','15.399275362318841','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','AEBNB','4h','0.045570000000000','0.045360000000000','0.711908500000000','0.708627815668203','15.622306341891596','15.622306341891596','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','AEBNB','4h','0.046370000000000','0.045910000000000','0.711908500000000','0.704846220293293','15.352781971102006','15.352781971102006','test'),('2019-02-23 23:59:59','2019-02-24 15:59:59','AEBNB','4h','0.043850000000000','0.042550000000000','0.711908500000000','0.690802888825542','16.23508551881414','16.235085518814142','test'),('2019-02-25 19:59:59','2019-02-27 15:59:59','AEBNB','4h','0.044300000000000','0.043560000000000','0.711908500000000','0.700016574717833','16.070169300225736','16.070169300225736','test'),('2019-03-20 15:59:59','2019-03-24 11:59:59','AEBNB','4h','0.030950000000000','0.028090000000000','0.711908500000000','0.646123094184168','23.0018901453958','23.001890145395802','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','AEBNB','4h','0.030200000000000','0.029530000000000','0.711908500000000','0.696114503476821','23.573129139072847','23.573129139072847','test'),('2019-04-01 23:59:59','2019-04-02 03:59:59','AEBNB','4h','0.030180000000000','0.029340000000000','0.711908500000000','0.692093949304175','23.588750828363157','23.588750828363157','test'),('2019-04-03 03:59:59','2019-04-11 07:59:59','AEBNB','4h','0.031340000000000','0.032820000000000','0.711908500000000','0.745527663369496','22.715650925335037','22.715650925335037','test'),('2019-05-06 07:59:59','2019-05-09 15:59:59','AEBNB','4h','0.022400000000000','0.022810000000000','0.711908500000000','0.724938968080357','31.781629464285718','31.781629464285718','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','AEBNB','4h','0.021820000000000','0.021930000000000','0.711908500000000','0.715497406278644','32.62642071494042','32.626420714940423','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','AEBNB','4h','0.018560000000000','0.018050000000000','0.711908500000000','0.692346359105603','38.35713900862069','38.357139008620692','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','AEBNB','4h','0.016680000000000','0.016270000000000','0.711908500000000','0.694409550059952','42.680365707434056','42.680365707434056','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','AEBNB','4h','0.016500000000000','0.016500000000000','0.711908500000000','0.711908500000000','43.1459696969697','43.145969696969701','test'),('2019-06-24 03:59:59','2019-06-25 11:59:59','AEBNB','4h','0.016800000000000','0.014930000000000','0.711908500000000','0.632666303869048','42.375505952380955','42.375505952380955','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 21:24:00
