-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-27 07:59:59','2018-07-27 15:59:59','AEETH','4h','0.004249000000000','0.004200000000000','0.072144500000000','0.071312520593081','16.979171569781123','16.979171569781123','test'),('2018-08-07 19:59:59','2018-08-08 03:59:59','AEETH','4h','0.004240000000000','0.004129000000000','0.072144500000000','0.070255811438679','17.015212264150943','17.015212264150943','test'),('2018-08-17 19:59:59','2018-08-18 07:59:59','AEETH','4h','0.003702000000000','0.003472000000000','0.072144500000000','0.067662264721772','19.487979470556457','19.487979470556457','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','AEETH','4h','0.003643000000000','0.003550000000000','0.072144500000000','0.070302765577820','19.80359593741422','19.803595937414219','test'),('2018-08-18 19:59:59','2018-08-19 03:59:59','AEETH','4h','0.003684000000000','0.003577000000000','0.072144500000000','0.070049097855592','19.58319761129207','19.583197611292071','test'),('2018-08-21 07:59:59','2018-08-21 11:59:59','AEETH','4h','0.003626000000000','0.003598000000000','0.072144500000000','0.071587399613900','19.896442360728077','19.896442360728077','test'),('2018-08-23 23:59:59','2018-08-24 03:59:59','AEETH','4h','0.003605000000000','0.003575000000000','0.072144500000000','0.071544129680999','20.012343966712898','20.012343966712898','test'),('2018-08-24 11:59:59','2018-08-24 15:59:59','AEETH','4h','0.003637000000000','0.003626000000000','0.072144500000000','0.071926301072312','19.83626615342315','19.836266153423150','test'),('2018-09-14 07:59:59','2018-09-16 19:59:59','AEETH','4h','0.004557000000000','0.004462000000000','0.072144500000000','0.070640500109721','15.831577792407284','15.831577792407284','test'),('2018-09-16 23:59:59','2018-09-17 03:59:59','AEETH','4h','0.004543000000000','0.004472000000000','0.072144500000000','0.071016994056791','15.880365397314549','15.880365397314549','test'),('2018-09-17 19:59:59','2018-09-18 15:59:59','AEETH','4h','0.004567000000000','0.004463000000000','0.072144500000000','0.070501621086052','15.7969126341143','15.796912634114300','test'),('2018-09-25 07:59:59','2018-09-27 19:59:59','AEETH','4h','0.004586000000000','0.004391000000000','0.072144500000000','0.069076864260794','15.731465329262974','15.731465329262974','test'),('2018-09-28 11:59:59','2018-09-28 15:59:59','AEETH','4h','0.004481000000000','0.004463000000000','0.072144500000000','0.071854698393216','16.10008926578889','16.100089265788888','test'),('2018-09-29 23:59:59','2018-09-30 19:59:59','AEETH','4h','0.004747000000000','0.004542000000000','0.072144500000000','0.069028927533179','15.197914472298292','15.197914472298292','test'),('2018-10-26 15:59:59','2018-10-27 07:59:59','AEETH','4h','0.006366000000000','0.006308000000000','0.072144500000000','0.071487198554822','11.332783537543198','11.332783537543198','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','AEETH','4h','0.006229000000000','0.006168000000000','0.072144500000000','0.071437995825975','11.582035639749558','11.582035639749558','test'),('2018-10-28 15:59:59','2018-10-28 19:59:59','AEETH','4h','0.006216000000000','0.006296000000000','0.072144500000000','0.073073000643501','11.606258043758043','11.606258043758043','test'),('2018-10-29 07:59:59','2018-10-29 11:59:59','AEETH','4h','0.006243000000000','0.006089000000000','0.072144500000000','0.070364866330290','11.556062790325164','11.556062790325164','test'),('2018-11-24 15:59:59','2018-11-24 23:59:59','AEETH','4h','0.005264000000000','0.005128000000000','0.072144500000000','0.070280584346505','13.705262158054712','13.705262158054712','test'),('2018-11-26 07:59:59','2018-11-26 11:59:59','AEETH','4h','0.005062000000000','0.004983000000000','0.072144500000000','0.071018578328724','14.252173054128804','14.252173054128804','test'),('2018-11-27 03:59:59','2018-11-27 07:59:59','AEETH','4h','0.005057000000000','0.005080000000000','0.072144500000000','0.072472624085426','14.266264583745304','14.266264583745304','test'),('2018-11-28 03:59:59','2018-11-28 19:59:59','AEETH','4h','0.005402000000000','0.005018000000000','0.072144500000000','0.067016123843021','13.355146242132545','13.355146242132545','test'),('2018-11-29 15:59:59','2018-11-29 19:59:59','AEETH','4h','0.005070000000000','0.005071000000000','0.072144500000000','0.072158729684418','14.229684418145958','14.229684418145958','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','AEETH','4h','0.004114000000000','0.004136000000000','0.072144500000000','0.072530299465241','17.53633932912008','17.536339329120079','test'),('2019-01-10 03:59:59','2019-01-11 07:59:59','AEETH','4h','0.002845000000000','0.002840000000000','0.072144500000000','0.072017708260105','25.35834797891037','25.358347978910370','test'),('2019-01-15 03:59:59','2019-01-27 07:59:59','AEETH','4h','0.002940000000000','0.003500000000000','0.072144500000000','0.085886309523810','24.538945578231292','24.538945578231292','test'),('2019-01-28 15:59:59','2019-01-28 19:59:59','AEETH','4h','0.003486000000000','0.003491000000000','0.072144500000000','0.072247977481354','20.695496270797477','20.695496270797477','test'),('2019-01-29 07:59:59','2019-01-29 11:59:59','AEETH','4h','0.003490000000000','0.003515000000000','0.072144500000000','0.072661294412607','20.671776504297995','20.671776504297995','test'),('2019-02-01 07:59:59','2019-02-01 11:59:59','AEETH','4h','0.003503000000000','0.003453000000000','0.072144500000000','0.071114746931202','20.59506137596346','20.595061375963461','test'),('2019-02-02 07:59:59','2019-02-02 11:59:59','AEETH','4h','0.003482000000000','0.003470000000000','0.072144500000000','0.071895868753590','20.719270534175763','20.719270534175763','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','AEETH','4h','0.003483000000000','0.003447000000000','0.072144500000000','0.071398820413437','20.713321848980765','20.713321848980765','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','AEETH','4h','0.003473000000000','0.003464000000000','0.072144500000000','0.071957543334293','20.772962856320184','20.772962856320184','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','AEETH','4h','0.003474000000000','0.003485000000000','0.072144500000000','0.072372936816350','20.76698330454807','20.766983304548070','test'),('2019-02-16 03:59:59','2019-02-16 11:59:59','AEETH','4h','0.003340000000000','0.003339000000000','0.072144500000000','0.072122899850299','21.600149700598802','21.600149700598802','test'),('2019-02-23 07:59:59','2019-02-23 11:59:59','AEETH','4h','0.003116000000000','0.003034000000000','0.072144500000000','0.070245960526316','23.152920410783057','23.152920410783057','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','AEETH','4h','0.003174000000000','0.003090000000000','0.072144500000000','0.070235193761815','22.729836168872083','22.729836168872083','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','AEETH','4h','0.003091000000000','0.003122000000000','0.072144500000000','0.072868045616305','23.340181171142024','23.340181171142024','test'),('2019-02-26 11:59:59','2019-03-05 15:59:59','AEETH','4h','0.003083000000000','0.003274000000000','0.072144500000000','0.076614042491080','23.40074602659747','23.400746026597471','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','AEETH','4h','0.003240000000000','0.003207000000000','0.072144500000000','0.071409694907407','22.266820987654324','22.266820987654324','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','AEETH','4h','0.003213000000000','0.003191000000000','0.072144500000000','0.071650513383131','22.453937130407716','22.453937130407716','test'),('2019-03-09 23:59:59','2019-03-10 11:59:59','AEETH','4h','0.003217000000000','0.003226000000000','0.072144500000000','0.072346334162263','22.426018029219772','22.426018029219772','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','AEETH','4h','0.003226000000000','0.003187000000000','0.072144500000000','0.071272325325480','22.363453192808432','22.363453192808432','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','AEETH','4h','0.003260000000000','0.003309000000000','0.072144500000000','0.073228880521472','22.130214723926382','22.130214723926382','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','AEETH','4h','0.003323000000000','0.003299000000000','0.072144500000000','0.071623444327415','21.710653024375564','21.710653024375564','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','AEETH','4h','0.003338000000000','0.003303000000000','0.072144500000000','0.071388041791492','21.613091671659678','21.613091671659678','test'),('2019-03-27 11:59:59','2019-03-27 19:59:59','AEETH','4h','0.003443000000000','0.003452000000000','0.072144500000000','0.072333085681092','20.953964565785654','20.953964565785654','test'),('2019-03-28 15:59:59','2019-03-29 03:59:59','AEETH','4h','0.003429000000000','0.003405000000000','0.072144500000000','0.071639551618548','21.039515893846602','21.039515893846602','test'),('2019-03-30 11:59:59','2019-04-02 19:59:59','AEETH','4h','0.003454000000000','0.003524000000000','0.072144500000000','0.073606606253619','20.887232194557036','20.887232194557036','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','AEETH','4h','0.003411000000000','0.003287000000000','0.072144500000000','0.069521832746995','21.15054236294342','21.150542362943419','test'),('2019-05-02 23:59:59','2019-05-03 03:59:59','AEETH','4h','0.003018000000000','0.002963000000000','0.072144500000000','0.070829739396952','23.90473823724321','23.904738237243208','test'),('2019-05-06 07:59:59','2019-05-06 15:59:59','AEETH','4h','0.002991000000000','0.002922000000000','0.072144500000000','0.070480183550652','24.12052825142093','24.120528251420929','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','AEETH','4h','0.002305000000000','0.002303000000000','0.072144500000000','0.072081901735358','31.299132321041213','31.299132321041213','test'),('2019-05-24 07:59:59','2019-05-24 11:59:59','AEETH','4h','0.002285000000000','0.002246000000000','0.072144500000000','0.070913149671772','31.57308533916849','31.573085339168490','test'),('2019-05-25 03:59:59','2019-05-25 11:59:59','AEETH','4h','0.002252000000000','0.002388000000000','0.072144500000000','0.076501361456483','32.0357460035524','32.035746003552397','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','AEETH','4h','0.002290000000000','0.002186000000000','0.072144500000000','0.068868068558952','31.50414847161572','31.504148471615721','test'),('2019-06-09 19:59:59','2019-06-11 11:59:59','AEETH','4h','0.002084000000000','0.002082000000000','0.072144500000000','0.072075263435701','34.618282149712094','34.618282149712094','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','AEETH','4h','0.002064000000000','0.002049000000000','0.072144500000000','0.071620194040698','34.95373062015504','34.953730620155042','test'),('2019-06-24 03:59:59','2019-06-24 11:59:59','AEETH','4h','0.002014000000000','0.001909000000000','0.072144500000000','0.068383242552135','35.821499503475664','35.821499503475664','test'),('2019-07-22 15:59:59','2019-07-23 07:59:59','AEETH','4h','0.001418000000000','0.001421000000000','0.072144500000000','0.072297132933709','50.877644569816646','50.877644569816646','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','AEETH','4h','0.001424000000000','0.001427000000000','0.072144500000000','0.072296489817416','50.66327247191011','50.663272471910112','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:30:29
