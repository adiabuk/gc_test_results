-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-13 11:59:59','2018-07-13 15:59:59','PIVXBNB','4h','0.143230000000000','0.144910000000000','0.711908500000000','0.720258749808001','4.970386790476856','4.970386790476856','test'),('2018-07-13 23:59:59','2018-07-14 07:59:59','PIVXBNB','4h','0.146120000000000','0.141120000000000','0.713996062452000','0.689564223468562','4.886367796687656','4.886367796687656','test'),('2018-07-14 11:59:59','2018-07-14 15:59:59','PIVXBNB','4h','0.145770000000000','0.141800000000000','0.713996062452000','0.694550604758823','4.898100174603828','4.898100174603828','test'),('2018-07-14 19:59:59','2018-07-15 03:59:59','PIVXBNB','4h','0.144000000000000','0.144260000000000','0.713996062452000','0.715285222009205','4.95830598925','4.958305989250000','test'),('2018-07-16 03:59:59','2018-07-16 07:59:59','PIVXBNB','4h','0.144960000000000','0.132260000000000','0.713996062452000','0.651442599475038','4.925469525745033','4.925469525745033','test'),('2018-07-16 19:59:59','2018-07-17 15:59:59','PIVXBNB','4h','0.144400000000000','0.148480000000000','0.713996062452000','0.734169912416018','4.944571069612188','4.944571069612188','test'),('2018-07-24 11:59:59','2018-07-24 15:59:59','PIVXBNB','4h','0.154680000000000','0.154740000000000','0.713996062452000','0.714273019807489','4.615955924825446','4.615955924825446','test'),('2018-07-26 11:59:59','2018-07-26 15:59:59','PIVXBNB','4h','0.153700000000000','0.144200000000000','0.713996062452000','0.669864880973184','4.645387524085882','4.645387524085882','test'),('2018-07-27 03:59:59','2018-07-27 07:59:59','PIVXBNB','4h','0.155540000000000','0.143540000000000','0.713996062452000','0.658910857685226','4.5904337305644844','4.590433730564484','test'),('2018-07-27 15:59:59','2018-07-28 15:59:59','PIVXBNB','4h','0.154250000000000','0.151470000000000','0.713996062452000','0.701127932444761','4.628823743611021','4.628823743611021','test'),('2018-07-30 19:59:59','2018-07-30 23:59:59','PIVXBNB','4h','0.153560000000000','0.153990000000000','0.713996062452000','0.715995400214792','4.649622704167752','4.649622704167752','test'),('2018-08-15 11:59:59','2018-08-15 15:59:59','PIVXBNB','4h','0.107350000000000','0.105110000000000','0.713996062452000','0.699097588489331','6.651104447619934','6.651104447619934','test'),('2018-08-21 07:59:59','2018-08-22 23:59:59','PIVXBNB','4h','0.111240000000000','0.109200000000000','0.713996062452000','0.700902283528932','6.418519079935274','6.418519079935274','test'),('2018-08-23 11:59:59','2018-08-24 15:59:59','PIVXBNB','4h','0.114840000000000','0.111020000000000','0.713996062452000','0.690245932196282','6.217311585266458','6.217311585266458','test'),('2018-08-25 03:59:59','2018-08-25 15:59:59','PIVXBNB','4h','0.114830000000000','0.112220000000000','0.713996062452000','0.697767466066041','6.21785302144039','6.217853021440390','test'),('2018-08-26 03:59:59','2018-08-26 07:59:59','PIVXBNB','4h','0.113380000000000','0.111710000000000','0.713996062452000','0.703479450842414','6.297372221308873','6.297372221308873','test'),('2018-08-27 03:59:59','2018-08-27 07:59:59','PIVXBNB','4h','0.114320000000000','0.114640000000000','0.713996062452000','0.715994651850046','6.245591868894331','6.245591868894331','test'),('2018-09-02 23:59:59','2018-09-03 03:59:59','PIVXBNB','4h','0.109040000000000','0.104850000000000','0.713996062452000','0.686559860125570','6.548019648312546','6.548019648312546','test'),('2018-09-03 19:59:59','2018-09-03 23:59:59','PIVXBNB','4h','0.109800000000000','0.108520000000000','0.713996062452000','0.705672611086439','6.502696379344262','6.502696379344262','test'),('2018-09-04 07:59:59','2018-09-04 11:59:59','PIVXBNB','4h','0.109240000000000','0.109240000000000','0.713996062452000','0.713996062452000','6.536031329659465','6.536031329659465','test'),('2018-09-19 15:59:59','2018-09-19 19:59:59','PIVXBNB','4h','0.096180000000000','0.096160000000000','0.713996062452000','0.713847591655067','7.423539846662507','7.423539846662507','test'),('2018-09-20 03:59:59','2018-09-20 11:59:59','PIVXBNB','4h','0.095710000000000','0.094270000000000','0.713996062452000','0.703253670539651','7.459994383575384','7.459994383575384','test'),('2018-09-20 15:59:59','2018-09-20 19:59:59','PIVXBNB','4h','0.096760000000000','0.095990000000000','0.713996062452000','0.708314200441995','7.379041571434477','7.379041571434477','test'),('2018-09-21 19:59:59','2018-09-23 23:59:59','PIVXBNB','4h','0.096600000000000','0.094900000000000','0.713996062452000','0.701430914355018','7.391263586459627','7.391263586459627','test'),('2018-09-26 15:59:59','2018-09-26 19:59:59','PIVXBNB','4h','0.097240000000000','0.095300000000000','0.713996062452000','0.699751385763838','7.3426168495680795','7.342616849568079','test'),('2018-09-27 07:59:59','2018-09-28 11:59:59','PIVXBNB','4h','0.101130000000000','0.094560000000000','0.713996062452000','0.667610676015635','7.060180583921685','7.060180583921685','test'),('2018-10-03 15:59:59','2018-10-03 23:59:59','PIVXBNB','4h','0.103430000000000','0.103300000000000','0.713996062452000','0.713098648857117','6.903181499100842','6.903181499100842','test'),('2018-10-05 15:59:59','2018-10-06 03:59:59','PIVXBNB','4h','0.107680000000000','0.103630000000000','0.713996062452000','0.687141641455245','6.6307212337667165','6.630721233766717','test'),('2018-10-06 15:59:59','2018-10-06 23:59:59','PIVXBNB','4h','0.108370000000000','0.104190000000000','0.713996062452000','0.686456120207381','6.588502929334687','6.588502929334687','test'),('2018-10-07 07:59:59','2018-10-07 15:59:59','PIVXBNB','4h','0.104840000000000','0.102120000000000','0.713996062452000','0.695471937214787','6.810340160740175','6.810340160740175','test'),('2018-10-08 07:59:59','2018-10-08 15:59:59','PIVXBNB','4h','0.107690000000000','0.103120000000000','0.713996062452000','0.683696480267901','6.630105510743801','6.630105510743801','test'),('2018-10-09 03:59:59','2018-10-09 07:59:59','PIVXBNB','4h','0.106380000000000','0.103390000000000','0.713996062452000','0.693927927212937','6.7117509160744495','6.711750916074450','test'),('2018-10-09 15:59:59','2018-10-09 23:59:59','PIVXBNB','4h','0.106560000000000','0.106850000000000','0.713996062452000','0.715939182366706','6.700413498986486','6.700413498986486','test'),('2018-11-04 15:59:59','2018-11-04 19:59:59','PIVXBNB','4h','0.143530000000000','0.141610000000000','0.713996062452000','0.704444941153959','4.974542342729743','4.974542342729743','test'),('2018-11-11 15:59:59','2018-11-14 11:59:59','PIVXBNB','4h','0.141690000000000','0.141120000000000','0.713996062452000','0.711123751381369','5.03914222917637','5.039142229176370','test'),('2018-11-21 23:59:59','2018-11-22 03:59:59','PIVXBNB','4h','0.135830000000000','0.134670000000000','0.713996062452000','0.707898474051468','5.256541724596922','5.256541724596922','test'),('2018-11-27 03:59:59','2018-11-27 11:59:59','PIVXBNB','4h','0.138000000000000','0.134370000000000','0.713996062452000','0.695214861678806','5.173884510521739','5.173884510521739','test'),('2018-11-28 03:59:59','2018-11-30 11:59:59','PIVXBNB','4h','0.141460000000000','0.139990000000000','0.713996062452000','0.706576479447586','5.047335377152551','5.047335377152551','test'),('2018-12-02 23:59:59','2018-12-03 07:59:59','PIVXBNB','4h','0.144630000000000','0.143080000000000','0.713996062452000','0.706344165219057','4.936707892221531','4.936707892221531','test'),('2018-12-20 11:59:59','2018-12-20 15:59:59','PIVXBNB','4h','0.115820000000000','0.124930000000000','0.713996062452000','0.770156519445073','6.164704390018994','6.164704390018994','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','PIVXBNB','4h','0.114140000000000','0.106000000000000','0.713996062452000','0.663076770807009','6.255441234028385','6.255441234028385','test'),('2018-12-23 15:59:59','2018-12-23 23:59:59','PIVXBNB','4h','0.125950000000000','0.153190000000000','0.713996062452000','0.868416489138721','5.668884973815006','5.668884973815006','test'),('2018-12-29 11:59:59','2019-01-03 15:59:59','PIVXBNB','4h','0.142330000000000','0.140420000000000','0.713996062452000','0.704414579424646','5.016483260394857','5.016483260394857','test'),('2019-01-24 07:59:59','2019-01-25 03:59:59','PIVXBNB','4h','0.127140000000000','0.120000000000000','0.713996062452000','0.673899067911279','5.615825565927324','5.615825565927324','test'),('2019-01-30 03:59:59','2019-01-30 07:59:59','PIVXBNB','4h','0.118870000000000','0.114020000000000','0.713996062452000','0.684864398424977','6.006528665365525','6.006528665365525','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','PIVXBNB','4h','0.084190000000000','0.080170000000000','0.713996062452000','0.679903365325773','8.480770429409668','8.480770429409668','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','PIVXBNB','4h','0.085980000000000','0.081380000000000','0.713996062452000','0.675796691816047','8.304211007815772','8.304211007815772','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','PIVXBNB','4h','0.083540000000000','0.082780000000000','0.713996062452000','0.707500527289640','8.546756792578405','8.546756792578405','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','PIVXBNB','4h','0.078030000000000','0.076790000000000','0.713996062452000','0.702649719796092','9.150276335409457','9.150276335409457','test'),('2019-03-14 03:59:59','2019-03-14 15:59:59','PIVXBNB','4h','0.060560000000000','0.057010000000000','0.713996062452000','0.672141933956217','11.789895350924702','11.789895350924702','test'),('2019-03-20 23:59:59','2019-03-21 15:59:59','PIVXBNB','4h','0.056120000000000','0.054480000000000','0.713996062452000','0.693130888852191','12.722666829151816','12.722666829151816','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','PIVXBNB','4h','0.056020000000000','0.055440000000000','0.713996062452000','0.706603743347713','12.745377766012139','12.745377766012139','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','PIVXBNB','4h','0.056120000000000','0.053780000000000','0.713996062452000','0.684225022071785','12.722666829151816','12.722666829151816','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','PIVXBNB','4h','0.056190000000000','0.050140000000000','0.713996062452000','0.637119817963041','12.706817270902295','12.706817270902295','test'),('2019-03-28 19:59:59','2019-03-30 11:59:59','PIVXBNB','4h','0.057040000000000','0.053910000000000','0.475997374968000','0.449877603164882','8.344975016970547','8.344975016970547','test'),('2019-03-31 03:59:59','2019-03-31 07:59:59','PIVXBNB','4h','0.055480000000000','0.052610000000000','0.518104078198691','0.491302371197425','9.338573868036967','9.338573868036967','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','PIVXBNB','4h','0.056180000000000','0.054770000000000','0.518104078198691','0.505100754057357','9.222215703073887','9.222215703073887','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','PIVXBNB','4h','0.054980000000000','0.055010000000000','0.518104078198691','0.518386783224991','9.42350087665862','9.423500876658620','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','PIVXBNB','4h','0.058200000000000','0.053640000000000','0.518104078198691','0.477510356607866','8.90213192781256','8.902131927812560','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','PIVXBNB','4h','0.054860000000000','0.055790000000000','0.518104078198691','0.526887103950145','9.444113711241178','9.444113711241178','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','PIVXBNB','4h','0.054680000000000','0.051760000000000','0.518104078198691','0.490436486605052','9.475202600561284','9.475202600561284','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','PIVXBNB','4h','0.054310000000000','0.054530000000000','0.518104078198691','0.520202824234480','9.539754708132774','9.539754708132774','test'),('2019-05-08 03:59:59','2019-05-08 07:59:59','PIVXBNB','4h','0.029110000000000','0.028290000000000','0.518104078198691','0.503509597122672','17.798147653682275','17.798147653682275','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','PIVXBNB','4h','0.029110000000000','0.029850000000000','0.518104078198691','0.531274707462416','17.798147653682275','17.798147653682275','test'),('2019-05-11 23:59:59','2019-05-12 03:59:59','PIVXBNB','4h','0.029730000000000','0.029330000000000','0.518104078198691','0.511133286699213','17.42697874869462','17.426978748694619','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','PIVXBNB','4h','0.022640000000000','0.021720000000000','0.518104078198691','0.497050378907931','22.884455750825573','22.884455750825573','test'),('2019-05-30 11:59:59','2019-05-30 19:59:59','PIVXBNB','4h','0.022490000000000','0.023020000000000','0.518104078198691','0.530313734109998','23.037086625108536','23.037086625108536','test'),('2019-06-02 15:59:59','2019-06-03 19:59:59','PIVXBNB','4h','0.022510000000000','0.022230000000000','0.518104078198691','0.511659425071386','23.016618311803242','23.016618311803242','test'),('2019-06-04 03:59:59','2019-06-04 07:59:59','PIVXBNB','4h','0.022190000000000','0.022470000000000','0.518104078198691','0.524641669090788','23.348538900346593','23.348538900346593','test'),('2019-06-04 23:59:59','2019-06-05 11:59:59','PIVXBNB','4h','0.022600000000000','0.021640000000000','0.518104078198691','0.496096117354853','22.924959212331462','22.924959212331462','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','PIVXBNB','4h','0.021970000000000','0.021550000000000','0.518104078198691','0.508199494091115','23.582343113276785','23.582343113276785','test'),('2019-06-09 03:59:59','2019-06-10 11:59:59','PIVXBNB','4h','0.022370000000000','0.021780000000000','0.518104078198691','0.504439285792020','23.160665096052345','23.160665096052345','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','PIVXBNB','4h','0.022460000000000','0.022150000000000','0.518104078198691','0.510953042390962','23.06785744428722','23.067857444287220','test'),('2019-06-14 23:59:59','2019-06-15 07:59:59','PIVXBNB','4h','0.022160000000000','0.021610000000000','0.518104078198691','0.505244996835456','23.380147933153925','23.380147933153925','test'),('2019-06-15 19:59:59','2019-06-16 03:59:59','PIVXBNB','4h','0.022320000000000','0.021880000000000','0.518104078198691','0.507890556943878','23.212548306392964','23.212548306392964','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','PIVXBNB','4h','0.020410000000000','0.019340000000000','0.518104078198691','0.490942325936437','25.384815198368003','25.384815198368003','test'),('2019-07-05 23:59:59','2019-07-06 03:59:59','PIVXBNB','4h','0.019340000000000','0.019950000000000','0.518104078198691','0.534445520168763','26.789249131266338','26.789249131266338','test'),('2019-07-10 03:59:59','2019-07-10 15:59:59','PIVXBNB','4h','0.019810000000000','0.019370000000000','0.518104078198691','0.506596466163990','26.153663715229225','26.153663715229225','test'),('2019-07-10 19:59:59','2019-07-10 19:59:59','PIVXBNB','4h','0.019690000000000','0.019690000000000','0.518104078198691','0.518104078198691','26.31305628231036','26.313056282310360','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:16:39
