-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-13 15:59:59','2018-04-13 19:59:59','EVXETH','4h','0.002558600000000','0.002475900000000','0.072144500000000','0.069812619225358','28.196865473305717','28.196865473305717','test'),('2018-04-14 15:59:59','2018-04-14 19:59:59','EVXETH','4h','0.002538000000000','0.002489700000000','0.072144500000000','0.070771537293144','28.425728920409775','28.425728920409775','test'),('2018-04-15 15:59:59','2018-04-15 19:59:59','EVXETH','4h','0.002503100000000','0.002494400000000','0.072144500000000','0.071893748072390','28.822060644800448','28.822060644800448','test'),('2018-04-18 11:59:59','2018-04-18 15:59:59','EVXETH','4h','0.002464600000000','0.002548500000000','0.072144500000000','0.074600445609835','29.272295707214152','29.272295707214152','test'),('2018-04-20 15:59:59','2018-04-20 19:59:59','EVXETH','4h','0.002521000000000','0.002519200000000','0.072144500000000','0.072092988655296','28.617413724712417','28.617413724712417','test'),('2018-04-21 19:59:59','2018-04-24 11:59:59','EVXETH','4h','0.002727200000000','0.002574500000000','0.072144500000000','0.068105021725579','26.453688765033736','26.453688765033736','test'),('2018-04-30 07:59:59','2018-04-30 11:59:59','EVXETH','4h','0.002551000000000','0.002511700000000','0.072144500000000','0.071033061799294','28.280870246961978','28.280870246961978','test'),('2018-04-30 15:59:59','2018-05-01 03:59:59','EVXETH','4h','0.002557000000000','0.002531400000000','0.072144500000000','0.071422208564724','28.21450919045757','28.214509190457569','test'),('2018-05-01 15:59:59','2018-05-01 19:59:59','EVXETH','4h','0.002550000000000','0.002555300000000','0.072144500000000','0.072294447392157','28.291960784313723','28.291960784313723','test'),('2018-05-05 19:59:59','2018-05-05 23:59:59','EVXETH','4h','0.002598700000000','0.002245100000000','0.072144500000000','0.062327939719860','27.761765498133684','27.761765498133684','test'),('2018-05-28 19:59:59','2018-05-28 23:59:59','EVXETH','4h','0.001916000000000','0.001908300000000','0.072144500000000','0.071854566466597','37.65370563674322','37.653705636743219','test'),('2018-05-30 07:59:59','2018-05-30 15:59:59','EVXETH','4h','0.001907500000000','0.001904700000000','0.072144500000000','0.072038599816514','37.82149410222805','37.821494102228051','test'),('2018-06-02 15:59:59','2018-06-02 19:59:59','EVXETH','4h','0.001896000000000','0.001886600000000','0.072144500000000','0.071786821571730','38.05089662447258','38.050896624472578','test'),('2018-06-02 23:59:59','2018-06-03 03:59:59','EVXETH','4h','0.001893500000000','0.001889900000000','0.072144500000000','0.072007335912332','38.10113546342752','38.101135463427518','test'),('2018-06-22 15:59:59','2018-06-22 19:59:59','EVXETH','4h','0.001618100000000','0.001427900000000','0.072144500000000','0.063664255330326','44.58593412026451','44.585934120264511','test'),('2018-07-01 19:59:59','2018-07-01 23:59:59','EVXETH','4h','0.001433700000000','0.001334700000000','0.072144500000000','0.067162770558694','50.32049940712841','50.320499407128409','test'),('2018-07-02 03:59:59','2018-07-02 07:59:59','EVXETH','4h','0.001358900000000','0.001345800000000','0.072144500000000','0.071449016189565','53.0903672087718','53.090367208771802','test'),('2018-07-02 11:59:59','2018-07-06 03:59:59','EVXETH','4h','0.001372300000000','0.001470000000000','0.072144500000000','0.077280780441594','52.57195948407783','52.571959484077830','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','EVXETH','4h','0.001511300000000','0.001499600000000','0.072144500000000','0.071585980414213','47.73671673393767','47.736716733937669','test'),('2018-07-10 03:59:59','2018-07-10 07:59:59','EVXETH','4h','0.001512000000000','0.001504100000000','0.072144500000000','0.071767554530423','47.7146164021164','47.714616402116398','test'),('2018-07-11 19:59:59','2018-07-11 23:59:59','EVXETH','4h','0.001543000000000','0.001452700000000','0.072144500000000','0.067922433668179','46.755994815294876','46.755994815294876','test'),('2018-07-16 15:59:59','2018-07-17 03:59:59','EVXETH','4h','0.001496200000000','0.001468400000000','0.072144500000000','0.070804026066034','48.218486833311054','48.218486833311054','test'),('2018-07-22 03:59:59','2018-07-22 07:59:59','EVXETH','4h','0.001486200000000','0.001468400000000','0.072144500000000','0.071280435876733','48.542928273449064','48.542928273449064','test'),('2018-07-22 19:59:59','2018-07-22 23:59:59','EVXETH','4h','0.001486000000000','0.001460500000000','0.072144500000000','0.070906488728129','48.549461641991925','48.549461641991925','test'),('2018-07-23 07:59:59','2018-07-23 11:59:59','EVXETH','4h','0.001508100000000','0.001441100000000','0.072144500000000','0.068939353457993','47.83800808964923','47.838008089649229','test'),('2018-07-23 15:59:59','2018-07-24 07:59:59','EVXETH','4h','0.001496500000000','0.001436000000000','0.072144500000000','0.069227866354828','48.2088205813565','48.208820581356498','test'),('2018-07-26 15:59:59','2018-07-26 19:59:59','EVXETH','4h','0.001640900000000','0.001443300000000','0.072144500000000','0.063456735236760','43.966420866597595','43.966420866597595','test'),('2018-08-07 19:59:59','2018-08-08 03:59:59','EVXETH','4h','0.001439200000000','0.001372900000000','0.072144500000000','0.068821000590606','50.12819622012229','50.128196220122291','test'),('2018-08-08 15:59:59','2018-08-08 19:59:59','EVXETH','4h','0.001399100000000','0.001375000000000','0.072144500000000','0.070901785076120','51.564934600814816','51.564934600814816','test'),('2018-08-10 23:59:59','2018-08-11 03:59:59','EVXETH','4h','0.001420000000000','0.001427000000000','0.072144500000000','0.072500141901408','50.805985915492954','50.805985915492954','test'),('2018-08-12 19:59:59','2018-08-13 11:59:59','EVXETH','4h','0.001432600000000','0.001397400000000','0.072144500000000','0.070371858369398','50.35913723300293','50.359137233002933','test'),('2018-08-15 07:59:59','2018-08-15 15:59:59','EVXETH','4h','0.001472500000000','0.001433700000000','0.072144500000000','0.070243510797963','48.994567062818334','48.994567062818334','test'),('2018-08-16 11:59:59','2018-08-16 19:59:59','EVXETH','4h','0.001448400000000','0.001410000000000','0.072144500000000','0.070231804059652','49.80979011322839','49.809790113228388','test'),('2018-08-17 07:59:59','2018-08-18 07:59:59','EVXETH','4h','0.001414600000000','0.001460900000000','0.072144500000000','0.074505796726990','50.999929308638485','50.999929308638485','test'),('2018-08-19 11:59:59','2018-08-19 15:59:59','EVXETH','4h','0.001429700000000','0.001434100000000','0.072144500000000','0.072366529656571','50.461285584388335','50.461285584388335','test'),('2018-08-30 15:59:59','2018-08-30 19:59:59','EVXETH','4h','0.001553300000000','0.001537700000000','0.072144500000000','0.071419943121097','46.445953775832095','46.445953775832095','test'),('2018-08-30 23:59:59','2018-09-13 23:59:59','EVXETH','4h','0.001582700000000','0.001837800000000','0.072144500000000','0.083772769381437','45.58318064067732','45.583180640677320','test'),('2018-09-17 03:59:59','2018-09-17 15:59:59','EVXETH','4h','0.001800000000000','0.001799600000000','0.072144500000000','0.072128467888889','40.08027777777778','40.080277777777781','test'),('2018-09-22 07:59:59','2018-09-22 15:59:59','EVXETH','4h','0.001882100000000','0.001819300000000','0.072144500000000','0.069737255645290','38.3319164762765','38.331916476276497','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','EVXETH','4h','0.001864000000000','0.001846900000000','0.072144500000000','0.071482659361588','38.704130901287556','38.704130901287556','test'),('2018-10-22 19:59:59','2018-10-22 23:59:59','EVXETH','4h','0.002601700000000','0.002586800000000','0.072144500000000','0.071731326671023','27.729753622631353','27.729753622631353','test'),('2018-10-29 03:59:59','2018-10-29 07:59:59','EVXETH','4h','0.002689800000000','0.002691900000000','0.072144500000000','0.072200825172875','26.821510893003197','26.821510893003197','test'),('2018-10-31 03:59:59','2018-10-31 07:59:59','EVXETH','4h','0.002675000000000','0.002661400000000','0.072144500000000','0.071777709271028','26.969906542056076','26.969906542056076','test'),('2018-11-23 03:59:59','2018-11-23 07:59:59','EVXETH','4h','0.002243700000000','0.002187000000000','0.072144500000000','0.070321353790614','32.154254133796854','32.154254133796854','test'),('2018-11-27 11:59:59','2018-11-27 15:59:59','EVXETH','4h','0.002213600000000','0.002213600000000','0.072144500000000','0.072144500000000','32.59147994217564','32.591479942175638','test'),('2018-12-07 11:59:59','2018-12-07 15:59:59','EVXETH','4h','0.002386000000000','0.002330900000000','0.072144500000000','0.070478463977368','30.23658843252305','30.236588432523050','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','EVXETH','4h','0.002369700000000','0.002306100000000','0.072144500000000','0.070208225281681','30.444571042748024','30.444571042748024','test'),('2018-12-10 11:59:59','2018-12-10 19:59:59','EVXETH','4h','0.002358700000000','0.002283700000000','0.072144500000000','0.069850508606436','30.586551914190018','30.586551914190018','test'),('2018-12-10 23:59:59','2018-12-11 03:59:59','EVXETH','4h','0.002325100000000','0.002314400000000','0.072144500000000','0.071812494430347','31.028557911487678','31.028557911487678','test'),('2018-12-11 11:59:59','2018-12-11 15:59:59','EVXETH','4h','0.002318300000000','0.002324400000000','0.072144500000000','0.072334329379287','31.119570374843633','31.119570374843633','test'),('2018-12-13 03:59:59','2018-12-13 07:59:59','EVXETH','4h','0.002318500000000','0.002306200000000','0.072144500000000','0.071761762303213','31.116885917619154','31.116885917619154','test'),('2018-12-13 19:59:59','2018-12-13 23:59:59','EVXETH','4h','0.002323700000000','0.002277200000000','0.072144500000000','0.070700802771442','31.047252227051683','31.047252227051683','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','EVXETH','4h','0.001655700000000','0.001651500000000','0.072144500000000','0.071961491665157','43.57341305792112','43.573413057921123','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','EVXETH','4h','0.001925100000000','0.001894900000000','0.072144500000000','0.071012733390473','37.4757155472443','37.475715547244299','test'),('2019-02-28 23:59:59','2019-03-06 11:59:59','EVXETH','4h','0.001898300000000','0.001986800000000','0.072144500000000','0.075507924248011','38.004793762840436','38.004793762840436','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','EVXETH','4h','0.002178000000000','0.002200800000000','0.072144500000000','0.072899731680441','33.12419651056015','33.124196510560147','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','EVXETH','4h','0.002192600000000','0.002191400000000','0.072144500000000','0.072105015643528','32.90363039314057','32.903630393140567','test'),('2019-03-25 03:59:59','2019-03-25 07:59:59','EVXETH','4h','0.002203000000000','0.002197400000000','0.072144500000000','0.071961109532456','32.74829777576033','32.748297775760328','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:27:32
