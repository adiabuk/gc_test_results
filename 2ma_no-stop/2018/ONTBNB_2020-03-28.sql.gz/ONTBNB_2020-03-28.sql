-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-21 11:59:59','2018-09-21 15:59:59','ONTBNB','4h','0.190500000000000','0.184880000000000','0.711908500000000','0.690906264986877','3.7370524934383202','3.737052493438320','test'),('2018-09-21 19:59:59','2018-09-21 23:59:59','ONTBNB','4h','0.189350000000000','0.205920000000000','0.711908500000000','0.774207543279641','3.7597491418008984','3.759749141800898','test'),('2018-09-26 19:59:59','2018-09-26 23:59:59','ONTBNB','4h','0.192110000000000','0.188000000000000','0.722232702066629','0.706781260676312','3.759474790831448','3.759474790831448','test'),('2018-09-27 23:59:59','2018-09-28 03:59:59','ONTBNB','4h','0.190600000000000','0.195240000000000','0.722232702066629','0.739814862284830','3.7892586677157873','3.789258667715787','test'),('2018-10-08 11:59:59','2018-10-11 03:59:59','ONTBNB','4h','0.195710000000000','0.192340000000000','0.722765381773601','0.710319827961445','3.693042674230241','3.693042674230241','test'),('2018-10-18 11:59:59','2018-10-18 15:59:59','ONTBNB','4h','0.187750000000000','0.187140000000000','0.722765381773601','0.720417116085815','3.849615881617049','3.849615881617049','test'),('2018-10-18 23:59:59','2018-10-19 03:59:59','ONTBNB','4h','0.188550000000000','0.186500000000000','0.722765381773601','0.714907153013930','3.8332823217905116','3.833282321790512','test'),('2018-10-20 15:59:59','2018-10-20 19:59:59','ONTBNB','4h','0.187470000000000','0.186660000000000','0.722765381773601','0.719642535668962','3.8553655612823436','3.855365561282344','test'),('2018-10-20 23:59:59','2018-10-21 15:59:59','ONTBNB','4h','0.188520000000000','0.188500000000000','0.722765381773601','0.722688703927030','3.8338923285253608','3.833892328525361','test'),('2018-10-28 19:59:59','2018-10-28 23:59:59','ONTBNB','4h','0.183490000000000','0.182740000000000','0.722765381773601','0.719811138837582','3.9389905813592074','3.938990581359207','test'),('2018-11-04 11:59:59','2018-11-04 15:59:59','ONTBNB','4h','0.179440000000000','0.176680000000000','0.722765381773601','0.711648393065982','4.027894459282217','4.027894459282217','test'),('2018-11-12 23:59:59','2018-11-13 03:59:59','ONTBNB','4h','0.174390000000000','0.169510000000000','0.722765381773601','0.702540053124853','4.144534559169683','4.144534559169683','test'),('2018-11-14 19:59:59','2018-11-14 23:59:59','ONTBNB','4h','0.181000000000000','0.169680000000000','0.722765381773601','0.677562596570965','3.9931789048265247','3.993178904826525','test'),('2018-11-15 19:59:59','2018-11-16 11:59:59','ONTBNB','4h','0.175340000000000','0.170550000000000','0.722765381773601','0.703020622000044','4.1220792846675085','4.122079284667509','test'),('2018-11-16 23:59:59','2018-11-17 03:59:59','ONTBNB','4h','0.173130000000000','0.171600000000000','0.722765381773601','0.716378094566799','4.174697520785542','4.174697520785542','test'),('2018-11-17 07:59:59','2018-11-17 11:59:59','ONTBNB','4h','0.174410000000000','0.173600000000000','0.722765381773601','0.719408693744035','4.144059295760569','4.144059295760569','test'),('2018-11-17 19:59:59','2018-11-17 23:59:59','ONTBNB','4h','0.172650000000000','0.173360000000000','0.722765381773601','0.725737657597865','4.186303977837248','4.186303977837248','test'),('2018-11-19 23:59:59','2018-11-20 03:59:59','ONTBNB','4h','0.174020000000000','0.167920000000000','0.722765381773601','0.697429967287801','4.1533466370164405','4.153346637016440','test'),('2018-11-21 03:59:59','2018-11-21 15:59:59','ONTBNB','4h','0.176120000000000','0.169360000000000','0.722765381773601','0.695023535414360','4.103823425923239','4.103823425923239','test'),('2018-11-23 11:59:59','2018-11-25 11:59:59','ONTBNB','4h','0.170140000000000','0.171070000000000','0.722765381773601','0.726716080051780','4.248062664709068','4.248062664709068','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','ONTBNB','4h','0.116940000000000','0.114520000000000','0.722765381773601','0.707808205239548','6.180651460352325','6.180651460352325','test'),('2018-12-20 11:59:59','2018-12-20 15:59:59','ONTBNB','4h','0.115630000000000','0.114590000000000','0.722765381773601','0.716264681288912','6.2506735429698255','6.250673542969825','test'),('2019-01-09 15:59:59','2019-01-09 19:59:59','ONTBNB','4h','0.104250000000000','0.109190000000000','0.722765381773601','0.757014408017837','6.933001264015357','6.933001264015357','test'),('2019-01-11 19:59:59','2019-01-11 23:59:59','ONTBNB','4h','0.103200000000000','0.105100000000000','0.722765381773601','0.736072108763619','7.003540521062025','7.003540521062025','test'),('2019-01-16 11:59:59','2019-01-16 15:59:59','ONTBNB','4h','0.104230000000000','0.101870000000000','0.722765381773601','0.706400359217852','6.934331591418986','6.934331591418986','test'),('2019-02-15 15:59:59','2019-02-17 03:59:59','ONTBNB','4h','0.070600000000000','0.072910000000000','0.722765381773601','0.746413937466193','10.237469996793216','10.237469996793216','test'),('2019-02-18 11:59:59','2019-02-19 15:59:59','ONTBNB','4h','0.069270000000000','0.066440000000000','0.722765381773601','0.693237071820962','10.43403178538474','10.434031785384740','test'),('2019-02-21 03:59:59','2019-02-21 19:59:59','ONTBNB','4h','0.068980000000000','0.069720000000000','0.722765381773601','0.730519026054733','10.477897677205','10.477897677205000','test'),('2019-03-16 03:59:59','2019-03-16 11:59:59','ONTBNB','4h','0.068970000000000','0.066770000000000','0.722765381773601','0.699710664651636','10.479416873620428','10.479416873620428','test'),('2019-03-17 19:59:59','2019-03-18 11:59:59','ONTBNB','4h','0.069910000000000','0.069590000000000','0.722765381773601','0.719457057897652','10.338512112338735','10.338512112338735','test'),('2019-03-27 19:59:59','2019-03-27 23:59:59','ONTBNB','4h','0.075110000000000','0.075530000000000','0.722765381773601','0.726806940292372','9.622758378026907','9.622758378026907','test'),('2019-03-29 19:59:59','2019-03-31 03:59:59','ONTBNB','4h','0.075780000000000','0.074010000000000','0.722765381773601','0.705883688375089','9.537679886165227','9.537679886165227','test'),('2019-04-01 03:59:59','2019-04-01 11:59:59','ONTBNB','4h','0.078370000000000','0.072950000000000','0.722765381773601','0.672779566165423','9.222475204460903','9.222475204460903','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','ONTBNB','4h','0.077620000000000','0.076430000000000','0.722765381773601','0.711684593261483','9.311586984972958','9.311586984972958','test'),('2019-04-09 19:59:59','2019-04-09 23:59:59','ONTBNB','4h','0.080000000000000','0.078950000000000','0.722765381773601','0.713279086137822','9.034567272170012','9.034567272170012','test'),('2019-04-10 03:59:59','2019-04-11 03:59:59','ONTBNB','4h','0.082300000000000','0.078860000000000','0.722765381773601','0.692555018307001','8.782082403081422','8.782082403081422','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','ONTBNB','4h','0.050460000000000','0.050160000000000','0.722765381773601','0.718468322428930','14.32353114890212','14.323531148902120','test'),('2019-05-28 19:59:59','2019-05-28 23:59:59','ONTBNB','4h','0.044670000000000','0.044680000000000','0.722765381773601','0.722927182844067','16.180107046644302','16.180107046644302','test'),('2019-05-29 15:59:59','2019-05-30 03:59:59','ONTBNB','4h','0.046830000000000','0.045200000000000','0.722765381773601','0.697608269403518','15.433811269989345','15.433811269989345','test'),('2019-06-02 07:59:59','2019-06-02 15:59:59','ONTBNB','4h','0.046210000000000','0.045390000000000','0.722765381773601','0.709939854548880','15.640886859415732','15.640886859415732','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','ONTBNB','4h','0.045440000000000','0.045880000000000','0.722765381773601','0.729763990223874','15.905928296073965','15.905928296073965','test'),('2019-06-09 23:59:59','2019-06-11 07:59:59','ONTBNB','4h','0.044130000000000','0.044010000000000','0.722765381773601','0.720800010239206','16.3780961199547','16.378096119954701','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','ONTBNB','4h','0.044100000000000','0.044670000000000','0.722765381773601','0.732107247252307','16.389237681941065','16.389237681941065','test'),('2019-06-22 23:59:59','2019-06-23 11:59:59','ONTBNB','4h','0.041950000000000','0.041450000000000','0.722765381773601','0.714150776508123','17.22921053095592','17.229210530955921','test'),('2019-06-24 11:59:59','2019-06-27 15:59:59','ONTBNB','4h','0.042590000000000','0.042660000000000','0.722765381773601','0.723953303274520','16.97030715598969','16.970307155989691','test'),('2019-06-28 11:59:59','2019-06-28 15:59:59','ONTBNB','4h','0.043960000000000','0.043320000000000','0.722765381773601','0.712242864841501','16.441432706405845','16.441432706405845','test'),('2019-07-02 23:59:59','2019-07-03 03:59:59','ONTBNB','4h','0.043890000000000','0.043430000000000','0.722765381773601','0.715190260433527','16.467655087117816','16.467655087117816','test'),('2019-07-24 15:59:59','2019-08-01 07:59:59','ONTBNB','4h','0.034550000000000','0.035240000000000','0.722765381773601','0.737199770005838','20.919403235125934','20.919403235125934','test'),('2019-08-03 07:59:59','2019-08-04 07:59:59','ONTBNB','4h','0.035200000000000','0.035360000000000','0.722765381773601','0.726050678963481','20.533107436750026','20.533107436750026','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:05:53
