-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 03:59:59','2019-01-08 07:59:59','BTSBNB','4h','0.007240000000000','0.006710000000000','0.711908500000000','0.659793651243094','98.32990331491713','98.329903314917132','test'),('2019-01-13 03:59:59','2019-01-13 07:59:59','BTSBNB','4h','0.006610000000000','0.006520000000000','0.711908500000000','0.702215343419062','107.7017397881997','107.701739788199703','test'),('2019-01-13 23:59:59','2019-01-14 07:59:59','BTSBNB','4h','0.006760000000000','0.006600000000000','0.711908500000000','0.695058594674556','105.31190828402367','105.311908284023673','test'),('2019-01-19 07:59:59','2019-01-19 15:59:59','BTSBNB','4h','0.006680000000000','0.006520000000000','0.711908500000000','0.694856799401198','106.57312874251498','106.573128742514982','test'),('2019-01-29 19:59:59','2019-01-31 15:59:59','BTSBNB','4h','0.006050000000000','0.005800000000000','0.711908500000000','0.682490793388430','117.670826446281','117.670826446280998','test'),('2019-02-17 07:59:59','2019-02-17 15:59:59','BTSBNB','4h','0.004650000000000','0.004580000000000','0.711908500000000','0.701191597849463','153.09860215053766','153.098602150537658','test'),('2019-02-19 07:59:59','2019-02-19 15:59:59','BTSBNB','4h','0.004720000000000','0.004470000000000','0.711908500000000','0.674201481991525','150.8280720338983','150.828072033898309','test'),('2019-02-23 11:59:59','2019-02-24 23:59:59','BTSBNB','4h','0.004590000000000','0.004500000000000','0.711908500000000','0.697949509803922','155.09989106753812','155.099891067538124','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','BTSBNB','4h','0.003380000000000','0.003370000000000','0.711908500000000','0.709802261834320','210.62381656804735','210.623816568047346','test'),('2019-03-23 03:59:59','2019-03-24 11:59:59','BTSBNB','4h','0.003510000000000','0.003030000000000','0.711908500000000','0.614553491452992','202.8229344729345','202.822934472934492','test'),('2019-03-25 11:59:59','2019-03-31 03:59:59','BTSBNB','4h','0.003690000000000','0.003660000000000','0.711908500000000','0.706120626016260','192.92913279132793','192.929132791327930','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','BTSBNB','4h','0.003500000000000','0.003450000000000','0.711908500000000','0.701738378571429','203.40242857142857','203.402428571428572','test'),('2019-04-03 03:59:59','2019-04-09 23:59:59','BTSBNB','4h','0.003690000000000','0.003720000000000','0.711908500000000','0.717696373983740','192.92913279132793','192.929132791327930','test'),('2019-05-07 03:59:59','2019-05-07 15:59:59','BTSBNB','4h','0.002480000000000','0.002430000000000','0.711908500000000','0.697555506048387','287.0598790322581','287.059879032258095','test'),('2019-05-14 15:59:59','2019-05-14 19:59:59','BTSBNB','4h','0.002540000000000','0.002540000000000','0.711908500000000','0.711908500000000','280.278937007874','280.278937007873992','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','BTSBNB','4h','0.002570000000000','0.002600000000000','0.711908500000000','0.720218715953307','277.0071984435798','277.007198443579796','test'),('2019-05-30 15:59:59','2019-05-30 19:59:59','BTSBNB','4h','0.002140000000000','0.002110000000000','0.711908500000000','0.701928474299065','332.667523364486','332.667523364485987','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','BTSBNB','4h','0.002120000000000','0.002110000000000','0.711908500000000','0.708550441037736','335.80589622641514','335.805896226415143','test'),('2019-06-01 03:59:59','2019-06-01 07:59:59','BTSBNB','4h','0.002150000000000','0.002070000000000','0.711908500000000','0.685418881395349','331.12023255813955','331.120232558139548','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','BTSBNB','4h','0.002140000000000','0.002060000000000','0.711908500000000','0.685295098130841','332.667523364486','332.667523364485987','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','BTSBNB','4h','0.001950000000000','0.001890000000000','0.711908500000000','0.690003623076923','365.0812820512821','365.081282051282074','test'),('2019-06-15 23:59:59','2019-06-16 03:59:59','BTSBNB','4h','0.001940000000000','0.001950000000000','0.711908500000000','0.715578131443299','366.9631443298969','366.963144329896920','test'),('2019-06-24 07:59:59','2019-06-24 11:59:59','BTSBNB','4h','0.001840000000000','0.001930000000000','0.711908500000000','0.746730111413044','386.9067934782609','386.906793478260909','test'),('2019-06-27 19:59:59','2019-06-27 23:59:59','BTSBNB','4h','0.001890000000000','0.001870000000000','0.711908500000000','0.704375076719577','376.67116402116403','376.671164021164032','test'),('2019-07-02 15:59:59','2019-07-02 19:59:59','BTSBNB','4h','0.001920000000000','0.001840000000000','0.711908500000000','0.682245645833333','370.7856770833333','370.785677083333326','test'),('2019-07-03 03:59:59','2019-07-03 07:59:59','BTSBNB','4h','0.001920000000000','0.001850000000000','0.711908500000000','0.685953502604167','370.7856770833333','370.785677083333326','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','BTSBNB','4h','0.001890000000000','0.001840000000000','0.711908500000000','0.693074941798942','376.67116402116403','376.671164021164032','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','BTSBNB','4h','0.001850000000000','0.001850000000000','0.711908500000000','0.711908500000000','384.81540540540544','384.815405405405443','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','BTSBNB','4h','0.001556000000000','0.001534000000000','0.711908500000000','0.701842955655527','457.5247429305913','457.524742930591287','test'),('2019-07-26 03:59:59','2019-07-26 07:59:59','BTSBNB','4h','0.001560000000000','0.001553000000000','0.711908500000000','0.708714038782051','456.3516025641026','456.351602564102620','test'),('2019-08-02 11:59:59','2019-08-03 03:59:59','BTSBNB','4h','0.001607000000000','0.001598000000000','0.711908500000000','0.707921457996266','443.0046670815184','443.004667081518392','test'),('2019-08-18 15:59:59','2019-08-18 23:59:59','BTSBNB','4h','0.001489000000000','0.001451000000000','0.711908500000000','0.693740250839490','478.11182001343184','478.111820013431839','test'),('2019-08-19 11:59:59','2019-08-19 15:59:59','BTSBNB','4h','0.001504000000000','0.001441000000000','0.711908500000000','0.682087864694149','473.34341755319156','473.343417553191557','test'),('2019-08-19 19:59:59','2019-08-20 11:59:59','BTSBNB','4h','0.001467000000000','0.001469000000000','0.711908500000000','0.712879063735515','485.2818677573279','485.281867757327916','test'),('2019-08-20 23:59:59','2019-08-22 03:59:59','BTSBNB','4h','0.001471000000000','0.001484000000000','0.711908500000000','0.718200009517335','483.96227056424203','483.962270564242033','test'),('2019-08-22 19:59:59','2019-08-26 07:59:59','BTSBNB','4h','0.001471000000000','0.001473000000000','0.711908500000000','0.712876424541129','483.96227056424203','483.962270564242033','test'),('2019-08-29 03:59:59','2019-08-29 23:59:59','BTSBNB','4h','0.001550000000000','0.001506000000000','0.711908500000000','0.691699484516129','459.295806451613','459.295806451612975','test'),('2019-08-30 15:59:59','2019-08-30 23:59:59','BTSBNB','4h','0.001537000000000','0.001535000000000','0.711908500000000','0.710982138906962','463.1805465191933','463.180546519193285','test'),('2019-09-01 19:59:59','2019-09-02 15:59:59','BTSBNB','4h','0.001527000000000','0.001497000000000','0.711908500000000','0.697922085461690','466.21381794368045','466.213817943680453','test'),('2019-09-09 03:59:59','2019-09-09 07:59:59','BTSBNB','4h','0.001496000000000','0.001486000000000','0.711908500000000','0.707149753342246','475.8746657754011','475.874665775401127','test'),('2019-09-18 19:59:59','2019-09-19 03:59:59','BTSBNB','4h','0.001612000000000','0.001623000000000','0.711908500000000','0.716766436414392','441.6305831265509','441.630583126550903','test'),('2019-09-21 15:59:59','2019-09-24 19:59:59','BTSBNB','4h','0.001632000000000','0.001517000000000','0.711908500000000','0.661743378982843','436.218443627451','436.218443627450995','test'),('2019-09-25 11:59:59','2019-09-25 19:59:59','BTSBNB','4h','0.001664000000000','0.001621000000000','0.711908500000000','0.693511826021635','427.8296274038462','427.829627403846189','test'),('2019-10-04 03:59:59','2019-10-04 07:59:59','BTSBNB','4h','0.001801000000000','0.001756000000000','0.711908500000000','0.694120669627984','395.2851193781233','395.285119378123284','test'),('2019-10-04 11:59:59','2019-10-04 19:59:59','BTSBNB','4h','0.001800000000000','0.001798000000000','0.711908500000000','0.711117490555556','395.50472222222226','395.504722222222256','test'),('2019-10-26 07:59:59','2019-10-27 07:59:59','BTSBNB','4h','0.001475000000000','0.001451000000000','0.711908500000000','0.700324904067797','482.6498305084746','482.649830508474622','test'),('2019-10-27 11:59:59','2019-10-27 15:59:59','BTSBNB','4h','0.001505000000000','0.001531000000000','0.711908500000000','0.724207251495017','473.0289036544851','473.028903654485077','test'),('2019-10-29 07:59:59','2019-10-29 11:59:59','BTSBNB','4h','0.001519000000000','0.001439000000000','0.711908500000000','0.674414964779460','468.6691902567479','468.669190256747925','test'),('2019-10-30 03:59:59','2019-10-30 07:59:59','BTSBNB','4h','0.001536000000000','0.001409000000000','0.711908500000000','0.653046273763021','463.4820963541667','463.482096354166686','test'),('2019-10-31 19:59:59','2019-10-31 23:59:59','BTSBNB','4h','0.001475000000000','0.001461000000000','0.711908500000000','0.705151402372881','482.6498305084746','482.649830508474622','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  8:12:39
