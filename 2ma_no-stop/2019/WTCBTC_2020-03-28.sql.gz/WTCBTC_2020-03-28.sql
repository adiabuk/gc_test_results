-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 07:59:59','2019-01-03 11:59:59','WTCBTC','4h','0.000298100000000','0.000297900000000','0.001467500000000','0.001466515431063','4.922844682992285','4.922844682992285','test'),('2019-01-04 23:59:59','2019-01-05 03:59:59','WTCBTC','4h','0.000297400000000','0.000297200000000','0.001467500000000','0.001466513113652','4.934431741761936','4.934431741761936','test'),('2019-01-05 11:59:59','2019-01-05 23:59:59','WTCBTC','4h','0.000296800000000','0.000295700000000','0.001467500000000','0.001462061152291','4.944407008086253','4.944407008086253','test'),('2019-01-12 15:59:59','2019-01-13 03:59:59','WTCBTC','4h','0.000310100000000','0.000300300000000','0.001467500000000','0.001421123024831','4.732344405030635','4.732344405030635','test'),('2019-01-14 03:59:59','2019-01-14 15:59:59','WTCBTC','4h','0.000303400000000','0.000303500000000','0.001467500000000','0.001467983684904','4.836849044166118','4.836849044166118','test'),('2019-01-19 07:59:59','2019-01-20 11:59:59','WTCBTC','4h','0.000316300000000','0.000313500000000','0.001467500000000','0.001454509168511','4.639582674675941','4.639582674675941','test'),('2019-01-20 19:59:59','2019-01-20 23:59:59','WTCBTC','4h','0.000316500000000','0.000315600000000','0.001467500000000','0.001463327014218','4.636650868878357','4.636650868878357','test'),('2019-01-22 23:59:59','2019-01-23 03:59:59','WTCBTC','4h','0.000317400000000','0.000315400000000','0.001467500000000','0.001458252993069','4.623503465658475','4.623503465658475','test'),('2019-01-25 11:59:59','2019-01-25 15:59:59','WTCBTC','4h','0.000313700000000','0.000311800000000','0.001467500000000','0.001458611730953','4.678036340452662','4.678036340452662','test'),('2019-01-25 23:59:59','2019-01-26 03:59:59','WTCBTC','4h','0.000313200000000','0.000309600000000','0.001467500000000','0.001450632183908','4.685504469987229','4.685504469987229','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','WTCBTC','4h','0.000281300000000','0.000277600000000','0.001467500000000','0.001448197653750','5.216850337717739','5.216850337717739','test'),('2019-02-10 23:59:59','2019-02-11 03:59:59','WTCBTC','4h','0.000279900000000','0.000278500000000','0.001467500000000','0.001460159878528','5.242943908538765','5.242943908538765','test'),('2019-02-11 07:59:59','2019-02-11 11:59:59','WTCBTC','4h','0.000280800000000','0.000279400000000','0.001467500000000','0.001460183404558','5.226139601139601','5.226139601139601','test'),('2019-02-12 07:59:59','2019-02-12 11:59:59','WTCBTC','4h','0.000280100000000','0.000276800000000','0.001467500000000','0.001450210639057','5.239200285612282','5.239200285612282','test'),('2019-02-13 03:59:59','2019-02-13 07:59:59','WTCBTC','4h','0.000278800000000','0.000279700000000','0.001467500000000','0.001472237266858','5.263629842180775','5.263629842180775','test'),('2019-02-14 03:59:59','2019-02-14 07:59:59','WTCBTC','4h','0.000278900000000','0.000277700000000','0.001467500000000','0.001461185908928','5.261742560057368','5.261742560057368','test'),('2019-02-18 03:59:59','2019-02-19 11:59:59','WTCBTC','4h','0.000282900000000','0.000284000000000','0.001467500000000','0.001473206079887','5.187345351714387','5.187345351714387','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','WTCBTC','4h','0.000278800000000','0.000274100000000','0.001467500000000','0.001442760939742','5.263629842180775','5.263629842180775','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','WTCBTC','4h','0.000278500000000','0.000276700000000','0.001467500000000','0.001458015260323','5.269299820466786','5.269299820466786','test'),('2019-03-06 03:59:59','2019-03-06 07:59:59','WTCBTC','4h','0.000286800000000','0.000287100000000','0.001467500000000','0.001469035041841','5.116806136680614','5.116806136680614','test'),('2019-03-26 19:59:59','2019-04-03 23:59:59','WTCBTC','4h','0.000320500000000','0.000391400000000','0.001467500000000','0.001792135725429','4.5787831513260535','4.578783151326054','test'),('2019-04-10 03:59:59','2019-04-10 19:59:59','WTCBTC','4h','0.000421900000000','0.000400200000000','0.001502339324075','0.001425068019661','3.560889604349964','3.560889604349964','test'),('2019-04-12 11:59:59','2019-04-12 15:59:59','WTCBTC','4h','0.000408300000000','0.000409700000000','0.001502339324075','0.001507490622272','3.6794987119152585','3.679498711915258','test'),('2019-04-16 07:59:59','2019-04-16 15:59:59','WTCBTC','4h','0.000424900000000','0.000414300000000','0.001502339324075','0.001464860395303','3.5357479973523183','3.535747997352318','test'),('2019-04-17 03:59:59','2019-04-23 07:59:59','WTCBTC','4h','0.000421100000000','0.000476600000000','0.001502339324075','0.001700344150687','3.5676545335431014','3.567654533543101','test'),('2019-04-24 03:59:59','2019-04-24 07:59:59','WTCBTC','4h','0.000466400000000','0.000449300000000','0.001524440796981','0.001468548992460','3.2685265801479413','3.268526580147941','test'),('2019-04-24 11:59:59','2019-04-24 15:59:59','WTCBTC','4h','0.000463800000000','0.000456300000000','0.001524440796981','0.001499789425749','3.286849497587322','3.286849497587322','test'),('2019-05-17 23:59:59','2019-05-18 03:59:59','WTCBTC','4h','0.000312300000000','0.000304100000000','0.001524440796981','0.001484413853224','4.881334604486071','4.881334604486071','test'),('2019-05-29 23:59:59','2019-05-31 07:59:59','WTCBTC','4h','0.000281500000000','0.000281900000000','0.001524440796981','0.001526606965076','5.415420237943161','5.415420237943161','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','WTCBTC','4h','0.000269900000000','0.000264600000000','0.001524440796981','0.001494505501598','5.6481689402778805','5.648168940277881','test'),('2019-06-08 07:59:59','2019-06-08 15:59:59','WTCBTC','4h','0.000268200000000','0.000265700000000','0.001524440796981','0.001510230871580','5.68397016025727','5.683970160257270','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','WTCBTC','4h','0.000267400000000','0.000266400000000','0.001524440796981','0.001518739821674','5.70097530658564','5.700975306585640','test'),('2019-07-02 07:59:59','2019-07-03 23:59:59','WTCBTC','4h','0.000153900000000','0.000152900000000','0.001524440796981','0.001514535398690','9.90539829097466','9.905398290974659','test'),('2019-07-09 15:59:59','2019-07-10 03:59:59','WTCBTC','4h','0.000214800000000','0.000204200000000','0.001524440796981','0.001449212340519','7.097024194511174','7.097024194511174','test'),('2019-07-15 11:59:59','2019-07-15 15:59:59','WTCBTC','4h','0.000203500000000','0.000193300000000','0.001524440796981','0.001448031479393','7.491109567474201','7.491109567474201','test'),('2019-07-24 11:59:59','2019-07-27 11:59:59','WTCBTC','4h','0.000182300000000','0.000187300000000','0.001524440796981','0.001566252118895','8.36226438278113','8.362264382781129','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','WTCBTC','4h','0.000139800000000','0.000139900000000','0.001524440796981','0.001525531241042','10.904440607875536','10.904440607875536','test'),('2019-08-24 11:59:59','2019-08-24 15:59:59','WTCBTC','4h','0.000142600000000','0.000142700000000','0.001524440796981','0.001525509829798','10.690328169572231','10.690328169572231','test'),('2019-09-18 07:59:59','2019-09-18 11:59:59','WTCBTC','4h','0.000099100000000','0.000098400000000','0.001524440796981','0.001513672799424','15.382853652684158','15.382853652684158','test'),('2019-09-21 11:59:59','2019-09-22 11:59:59','WTCBTC','4h','0.000100200000000','0.000097800000000','0.001524440796981','0.001487927244958','15.21398000979042','15.213980009790420','test'),('2019-09-23 15:59:59','2019-09-23 19:59:59','WTCBTC','4h','0.000098000000000','0.000097600000000','0.001524440796981','0.001518218589646','15.555518336540818','15.555518336540818','test'),('2019-10-04 23:59:59','2019-10-05 03:59:59','WTCBTC','4h','0.000088900000000','0.000088600000000','0.001524440796981','0.001519296452334','17.14781548910011','17.147815489100111','test'),('2019-10-05 07:59:59','2019-10-05 15:59:59','WTCBTC','4h','0.000089500000000','0.000088300000000','0.001524440796981','0.001504001367301','17.03285806682682','17.032858066826819','test'),('2019-10-05 19:59:59','2019-10-05 23:59:59','WTCBTC','4h','0.000089200000000','0.000088200000000','0.001524440796981','0.001507350653517','17.090143463912558','17.090143463912558','test'),('2019-10-06 03:59:59','2019-10-06 07:59:59','WTCBTC','4h','0.000089500000000','0.000087700000000','0.001524440796981','0.001493781652461','17.03285806682682','17.032858066826819','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','WTCBTC','4h','0.000089400000000','0.000085800000000','0.001524440796981','0.001463053919250','17.051910480771813','17.051910480771813','test'),('2019-10-11 11:59:59','2019-10-11 15:59:59','WTCBTC','4h','0.000091000000000','0.000086900000000','0.001524440796981','0.001455757200634','16.752096670120878','16.752096670120878','test'),('2019-10-11 19:59:59','2019-10-13 15:59:59','WTCBTC','4h','0.000090800000000','0.000088200000000','0.001524440796981','0.001480789408521','16.78899556146476','16.788995561464759','test'),('2019-10-13 23:59:59','2019-10-14 19:59:59','WTCBTC','4h','0.000090100000000','0.000089200000000','0.001524440796981','0.001509213308443','16.91943170900111','16.919431709001110','test'),('2019-10-22 07:59:59','2019-10-22 11:59:59','WTCBTC','4h','0.000088100000000','0.000086400000000','0.001524440796981','0.001495024799763','17.30352777503973','17.303527775039729','test'),('2019-10-28 11:59:59','2019-10-28 23:59:59','WTCBTC','4h','0.000084900000000','0.000080800000000','0.001524440796981','0.001450822336821','17.955721990353357','17.955721990353357','test'),('2019-10-31 07:59:59','2019-10-31 11:59:59','WTCBTC','4h','0.000083000000000','0.000079500000000','0.001524440796981','0.001460157148916','18.366756590132532','18.366756590132532','test'),('2019-11-02 07:59:59','2019-11-02 11:59:59','WTCBTC','4h','0.000081000000000','0.000080500000000','0.001524440796981','0.001515030668605','18.82025675285185','18.820256752851851','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','WTCBTC','4h','0.000080600000000','0.000080200000000','0.001524440796981','0.001516875333969','18.913657530781638','18.913657530781638','test'),('2019-11-03 15:59:59','2019-11-03 23:59:59','WTCBTC','4h','0.000081800000000','0.000080700000000','0.001524440796981','0.001503940981863','18.636195562114917','18.636195562114917','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','WTCBTC','4h','0.000082200000000','0.000081500000000','0.001524440796981','0.001511458941046','18.54550847908759','18.545508479087591','test'),('2019-11-12 23:59:59','2019-11-13 01:59:59','WTCBTC','4h','0.000081600000000','0.000081100000000','0.001524440796981','0.001515099860725','18.681872512022057','18.681872512022057','test'),('2019-11-13 11:59:59','2019-11-14 07:59:59','WTCBTC','4h','0.000083600000000','0.000081300000000','0.001524440796981','0.001482500440126','18.234937762930624','18.234937762930624','test'),('2019-11-14 23:59:59','2019-11-15 07:59:59','WTCBTC','4h','0.000082100000000','0.000082300000000','0.001524440796981','0.001528154416462','18.568097405371496','18.568097405371496','test'),('2019-11-16 07:59:59','2019-11-17 07:59:59','WTCBTC','4h','0.000081900000000','0.000082700000000','0.001524440796981','0.001539331549577','18.613440744578757','18.613440744578757','test'),('2019-11-28 23:59:59','2019-11-29 03:59:59','WTCBTC','4h','0.000075600000000','0.000073200000000','0.001524440796981','0.001476045851045','20.164560806626987','20.164560806626987','test'),('2019-11-29 07:59:59','2019-11-29 11:59:59','WTCBTC','4h','0.000074000000000','0.000073500000000','0.001524440796981','0.001514140521326','20.600551310554057','20.600551310554057','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','WTCBTC','4h','0.000068300000000','0.000064400000000','0.001524440796981','0.001437393665089','22.31977740821376','22.319777408213760','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:44:30
