-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-02 23:59:59','BRDBNB','4h','0.036690000000000','0.035820000000000','0.711908500000000','0.695027595257563','19.40333878440992','19.403338784409922','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','BRDBNB','4h','0.033360000000000','0.034100000000000','0.711908500000000','0.727700235311751','21.340182853717028','21.340182853717028','test'),('2019-01-19 03:59:59','2019-01-19 19:59:59','BRDBNB','4h','0.033620000000000','0.032400000000000','0.711908500000000','0.686074818560381','21.17514872099941','21.175148720999410','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','BRDBNB','4h','0.034040000000000','0.032050000000000','0.711908500000000','0.670289877350176','20.91388072855464','20.913880728554641','test'),('2019-01-24 15:59:59','2019-01-25 11:59:59','BRDBNB','4h','0.033240000000000','0.032340000000000','0.711908500000000','0.692632999097473','21.417223225030085','21.417223225030085','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','BRDBNB','4h','0.032470000000000','0.030140000000000','0.711908500000000','0.660822980905451','21.92511549122267','21.925115491222670','test'),('2019-01-28 23:59:59','2019-01-29 03:59:59','BRDBNB','4h','0.031440000000000','0.031130000000000','0.711908500000000','0.704889045960560','22.643400127226464','22.643400127226464','test'),('2019-01-29 07:59:59','2019-01-31 15:59:59','BRDBNB','4h','0.031700000000000','0.032470000000000','0.711908500000000','0.729200914668770','22.45768138801262','22.457681388012620','test'),('2019-02-25 19:59:59','2019-02-26 07:59:59','BRDBNB','4h','0.022260000000000','0.022010000000000','0.711908500000000','0.703913121518419','31.981513926325253','31.981513926325253','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','BRDBNB','4h','0.022420000000000','0.015660000000000','0.711908500000000','0.497256338537021','31.75327832292596','31.753278322925961','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','BRDBNB','4h','0.017310000000000','0.017020000000000','0.711908500000000','0.699981667822068','41.12700751010977','41.127007510109770','test'),('2019-03-15 15:59:59','2019-03-16 11:59:59','BRDBNB','4h','0.017790000000000','0.016670000000000','0.711908500000000','0.667089077852726','40.01734120292299','40.017341202922992','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','BRDBNB','4h','0.016840000000000','0.016590000000000','0.711908500000000','0.701339787114014','42.274851543942994','42.274851543942994','test'),('2019-03-23 15:59:59','2019-03-24 11:59:59','BRDBNB','4h','0.017010000000000','0.014870000000000','0.711908500000000','0.622344467666079','41.85235155790711','41.852351557907113','test'),('2019-03-27 03:59:59','2019-03-27 11:59:59','BRDBNB','4h','0.016800000000000','0.016480000000000','0.711908500000000','0.698348338095238','42.375505952380955','42.375505952380955','test'),('2019-03-31 19:59:59','2019-03-31 23:59:59','BRDBNB','4h','0.017100000000000','0.016830000000000','0.711908500000000','0.700667839473684','41.63207602339182','41.632076023391818','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','BRDBNB','4h','0.016850000000000','0.016970000000000','0.711908500000000','0.716978471513353','42.24976261127597','42.249762611275969','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','BRDBNB','4h','0.017280000000000','0.016310000000000','0.711908500000000','0.671946043692130','41.19840856481482','41.198408564814819','test'),('2019-04-05 03:59:59','2019-04-11 11:59:59','BRDBNB','4h','0.016780000000000','0.016860000000000','0.711908500000000','0.715302581048868','42.42601311084625','42.426013110846249','test'),('2019-04-12 23:59:59','2019-04-13 03:59:59','BRDBNB','4h','0.018740000000000','0.017420000000000','0.711908500000000','0.661763397545358','37.98871398078976','37.988713980789761','test'),('2019-04-29 15:59:59','2019-05-13 23:59:59','BRDBNB','4h','0.014190000000000','0.019940000000000','0.711908500000000','1.000384460183228','50.16973220577872','50.169732205778722','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','BRDBNB','4h','0.019740000000000','0.019200000000000','0.711908500000000','0.692433799392097','36.06426038500507','36.064260385005070','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','BRDBNB','4h','0.014630000000000','0.013340000000000','0.711908500000000','0.649135980177717','48.66086807928913','48.660868079289131','test'),('2019-06-14 15:59:59','2019-06-14 19:59:59','BRDBNB','4h','0.014100000000000','0.013790000000000','0.711908500000000','0.696256610992908','50.4899645390071','50.489964539007097','test'),('2019-06-15 19:59:59','2019-06-16 07:59:59','BRDBNB','4h','0.014210000000000','0.013810000000000','0.711908500000000','0.691868851864884','50.09912033779029','50.099120337790289','test'),('2019-06-25 23:59:59','2019-06-26 07:59:59','BRDBNB','4h','0.012050000000000','0.011210000000000','0.711908500000000','0.662281683402490','59.079543568464736','59.079543568464736','test'),('2019-07-01 23:59:59','2019-07-02 07:59:59','BRDBNB','4h','0.011150000000000','0.011430000000000','0.711908500000000','0.729786022869955','63.84829596412556','63.848295964125562','test'),('2019-07-04 07:59:59','2019-07-04 23:59:59','BRDBNB','4h','0.011690000000000','0.011040000000000','0.711908500000000','0.672324195038494','60.89893071000856','60.898930710008557','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','BRDBNB','4h','0.011190000000000','0.011130000000000','0.711908500000000','0.708091296246649','63.620062555853444','63.620062555853444','test'),('2019-07-08 15:59:59','2019-07-09 07:59:59','BRDBNB','4h','0.011660000000000','0.011570000000000','0.711908500000000','0.706413494425386','61.055617495711836','61.055617495711836','test'),('2019-07-11 11:59:59','2019-07-12 03:59:59','BRDBNB','4h','0.011240000000000','0.010880000000000','0.711908500000000','0.689107160142349','63.337055160142356','63.337055160142356','test'),('2019-07-16 03:59:59','2019-07-16 07:59:59','BRDBNB','4h','0.011040000000000','0.011030000000000','0.711908500000000','0.711263655344203','64.48446557971015','64.484465579710147','test'),('2019-07-29 03:59:59','2019-07-31 15:59:59','BRDBNB','4h','0.009400000000000','0.009450000000000','0.711908500000000','0.715695247340426','75.73494680851064','75.734946808510642','test'),('2019-08-01 19:59:59','2019-08-01 23:59:59','BRDBNB','4h','0.009480000000000','0.009430000000000','0.711908500000000','0.708153708333333','75.09583333333333','75.095833333333331','test'),('2019-08-02 03:59:59','2019-08-02 23:59:59','BRDBNB','4h','0.009650000000000','0.009300000000000','0.711908500000000','0.686087984455959','73.77290155440414','73.772901554404143','test'),('2019-08-03 19:59:59','2019-08-03 23:59:59','BRDBNB','4h','0.009480000000000','0.009410000000000','0.711908500000000','0.706651791666667','75.09583333333333','75.095833333333331','test'),('2019-08-04 03:59:59','2019-08-04 07:59:59','BRDBNB','4h','0.009480000000000','0.009560000000000','0.711908500000000','0.717916166666667','75.09583333333333','75.095833333333331','test'),('2019-08-12 11:59:59','2019-08-28 11:59:59','BRDBNB','4h','0.008830000000000','0.011040000000000','0.711908500000000','0.890087184597962','80.62383918459797','80.623839184597969','test'),('2019-08-30 03:59:59','2019-08-30 11:59:59','BRDBNB','4h','0.011130000000000','0.011000000000000','0.711908500000000','0.703593306379156','63.963027852650505','63.963027852650505','test'),('2019-08-31 07:59:59','2019-09-05 19:59:59','BRDBNB','4h','0.011120000000000','0.011620000000000','0.711908500000000','0.743918774280576','64.02054856115109','64.020548561151088','test'),('2019-09-20 03:59:59','2019-09-22 11:59:59','BRDBNB','4h','0.010900000000000','0.010880000000000','0.711908500000000','0.710602245871560','65.31270642201835','65.312706422018351','test'),('2019-11-02 03:59:59','2019-11-05 03:59:59','BRDBNB','4h','0.017010000000000','0.017430000000000','0.711908500000000','0.729486487654321','41.85235155790711','41.852351557907113','test'),('2019-11-17 15:59:59','2019-11-17 19:59:59','BRDBNB','4h','0.016400000000000','0.016810000000000','0.711908500000000','0.729706212500000','43.40905487804878','43.409054878048778','test'),('2019-11-19 23:59:59','2019-11-20 03:59:59','BRDBNB','4h','0.016660000000000','0.016520000000000','0.711908500000000','0.705926075630252','42.731602641056426','42.731602641056426','test'),('2019-11-21 23:59:59','2019-11-22 07:59:59','BRDBNB','4h','0.016710000000000','0.016400000000000','0.711908500000000','0.698701340514662','42.60374027528427','42.603740275284267','test'),('2019-11-22 11:59:59','2019-11-23 15:59:59','BRDBNB','4h','0.016640000000000','0.016430000000000','0.711908500000000','0.702924077824519','42.782962740384626','42.782962740384626','test'),('2019-11-26 07:59:59','2019-11-29 03:59:59','BRDBNB','4h','0.016550000000000','0.016510000000000','0.711908500000000','0.710187875226586','43.01561933534744','43.015619335347438','test'),('2019-12-09 11:59:59','2019-12-10 03:59:59','BRDBNB','4h','0.017130000000000','0.016090000000000','0.711908500000000','0.668686968184472','41.55916520723877','41.559165207238770','test'),('2019-12-11 03:59:59','2019-12-16 07:59:59','BRDBNB','4h','0.016660000000000','0.017170000000000','0.711908500000000','0.733701617346939','42.731602641056426','42.731602641056426','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','BRDBNB','4h','0.018540000000000','0.018230000000000','0.711908500000000','0.700004959816613','38.3985167206041','38.398516720604100','test'),('2019-12-27 07:59:59','2019-12-29 15:59:59','BRDBNB','4h','0.018780000000000','0.018380000000000','0.711908500000000','0.696745379659212','37.90780085197018','37.907800851970180','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','BRDBNB','4h','0.018950000000000','0.017830000000000','0.711908500000000','0.669832641424802','37.5677308707124','37.567730870712403','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  9:17:39
