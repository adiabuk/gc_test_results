-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 23:59:59','2019-01-11 03:59:59','GRSETH','4h','0.001674190000000','0.001620570000000','0.072144500000000','0.069833897207008','43.092181890944275','43.092181890944275','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','GRSETH','4h','0.001686660000000','0.001680000000000','0.072144500000000','0.071859627903668','42.77358803789738','42.773588037897383','test'),('2019-01-12 11:59:59','2019-01-12 15:59:59','GRSETH','4h','0.001666260000000','0.001642950000000','0.072144500000000','0.071135240763746','43.297264532545945','43.297264532545945','test'),('2019-01-12 19:59:59','2019-01-13 15:59:59','GRSETH','4h','0.001689250000000','0.001681040000000','0.072144500000000','0.071793867266538','42.708006511765575','42.708006511765575','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','GRSETH','4h','0.001712160000000','0.001644310000000','0.072144500000000','0.069285535694678','42.136540977478745','42.136540977478745','test'),('2019-01-15 19:59:59','2019-01-20 15:59:59','GRSETH','4h','0.001705450000000','0.001759450000000','0.072144500000000','0.074428825544578','42.302324899586615','42.302324899586615','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','GRSETH','4h','0.001845510000000','0.001800000000000','0.072144500000000','0.070365427442821','39.091904134900375','39.091904134900375','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','GRSETH','4h','0.001867590000000','0.001832990000000','0.072144500000000','0.070807911294770','38.629731365021236','38.629731365021236','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','GRSETH','4h','0.001857110000000','0.001886060000000','0.072144500000000','0.073269141660968','38.847725767455884','38.847725767455884','test'),('2019-01-30 23:59:59','2019-01-31 03:59:59','GRSETH','4h','0.001854380000000','0.001840890000000','0.072144500000000','0.071619672669571','38.90491700730163','38.904917007301627','test'),('2019-02-02 07:59:59','2019-02-02 15:59:59','GRSETH','4h','0.001856400000000','0.001834530000000','0.072144500000000','0.071294575298966','38.86258349493644','38.862583494936437','test'),('2019-02-06 15:59:59','2019-02-06 19:59:59','GRSETH','4h','0.001819000000000','0.001803360000000','0.072144500000000','0.071524192149533','39.66162726772952','39.661627267729521','test'),('2019-02-06 23:59:59','2019-02-07 03:59:59','GRSETH','4h','0.001814060000000','0.001800060000000','0.072144500000000','0.071587725141396','39.76963275746117','39.769632757461167','test'),('2019-02-07 07:59:59','2019-02-07 11:59:59','GRSETH','4h','0.001836910000000','0.002700000000000','0.072144500000000','0.106042293852176','39.27492364895395','39.274923648953951','test'),('2019-02-16 11:59:59','2019-02-17 03:59:59','GRSETH','4h','0.001900970000000','0.001917190000000','0.078350733472604','0.079019260012700','41.21618619578649','41.216186195786491','test'),('2019-02-26 11:59:59','2019-02-27 07:59:59','GRSETH','4h','0.001722790000000','0.001686770000000','0.078517865107628','0.076876217837109','45.575993073809485','45.575993073809485','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','GRSETH','4h','0.001690730000000','0.001680570000000','0.078517865107628','0.078046032520820','46.4402152369852','46.440215236985203','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','GRSETH','4h','0.001730000000000','0.001681190000000','0.078517865107628','0.076302572046412','45.386049195160695','45.386049195160695','test'),('2019-03-07 07:59:59','2019-03-07 11:59:59','GRSETH','4h','0.001731840000000','0.001779440000000','0.078517865107628','0.080675945749675','45.337828614437825','45.337828614437825','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','GRSETH','4h','0.003152170000000','0.002924770000000','0.078517865107628','0.072853525136917','24.909146748946913','24.909146748946913','test'),('2019-04-15 07:59:59','2019-04-15 15:59:59','GRSETH','4h','0.002806380000000','0.002681240000000','0.078517865107628','0.075016655136217','27.978344025979375','27.978344025979375','test'),('2019-04-17 03:59:59','2019-04-17 07:59:59','GRSETH','4h','0.002738880000000','0.002709840000000','0.078517865107628','0.077685350063988','28.667873403591248','28.667873403591248','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','GRSETH','4h','0.001739340000000','0.001726800000000','0.078517865107628','0.077951780254494','45.14233278578541','45.142332785785413','test'),('2019-06-06 07:59:59','2019-06-06 11:59:59','GRSETH','4h','0.001676780000000','0.001623760000000','0.078517865107628','0.076035120079654','46.82657540501914','46.826575405019142','test'),('2019-06-07 07:59:59','2019-06-07 19:59:59','GRSETH','4h','0.001680050000000','0.001663380000000','0.078517865107628','0.077738785430628','46.73543353330437','46.735433533304366','test'),('2019-07-16 15:59:59','2019-07-16 19:59:59','GRSETH','4h','0.001188580000000','0.001141740000000','0.078517865107628','0.075423604055245','66.06022742064312','66.060227420643116','test'),('2019-07-18 07:59:59','2019-07-18 11:59:59','GRSETH','4h','0.001147150000000','0.001188580000000','0.078517865107628','0.081353584195288','68.44603156311554','68.446031563115540','test'),('2019-07-19 03:59:59','2019-07-19 07:59:59','GRSETH','4h','0.001169840000000','0.001136290000000','0.078517865107628','0.076266040606533','67.11846501028175','67.118465010281753','test'),('2019-07-29 11:59:59','2019-07-31 11:59:59','GRSETH','4h','0.001735060000000','0.001376880000000','0.078517865107628','0.062308898890754','45.25368869527739','45.253688695277390','test'),('2019-08-02 19:59:59','2019-08-02 23:59:59','GRSETH','4h','0.001320720000000','0.001325090000000','0.078517865107628','0.078777665118622','59.450803431179956','59.450803431179956','test'),('2019-08-04 07:59:59','2019-08-04 11:59:59','GRSETH','4h','0.001326020000000','0.001335510000000','0.078517865107628','0.079079798215629','59.21318314024524','59.213183140245242','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','GRSETH','4h','0.001219720000000','0.001164280000000','0.078517865107628','0.074948988282154','64.37368011316367','64.373680113163672','test'),('2019-08-17 23:59:59','2019-08-18 03:59:59','GRSETH','4h','0.001192490000000','0.001191400000000','0.078517865107628','0.078446095555709','65.84362561332003','65.843625613320029','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','GRSETH','4h','0.001201270000000','0.001152270000000','0.078517865107628','0.075315108533108','65.36237907183897','65.362379071838973','test'),('2019-08-22 07:59:59','2019-08-22 19:59:59','GRSETH','4h','0.001176040000000','0.001184800000000','0.078517865107628','0.079102723189277','66.76462119284038','66.764621192840380','test'),('2019-08-29 19:59:59','2019-08-29 23:59:59','GRSETH','4h','0.001226160000000','0.001210000000000','0.078517865107628','0.077483050156774','64.03557864196189','64.035578641961891','test'),('2019-08-30 03:59:59','2019-08-31 23:59:59','GRSETH','4h','0.001294890000000','0.001216390000000','0.078517865107628','0.073757883633565','60.63670667595549','60.636706675955487','test'),('2019-09-02 03:59:59','2019-09-02 19:59:59','GRSETH','4h','0.001242000000000','0.001213780000000','0.078517865107628','0.076733827947131','63.21889300131078','63.218893001310782','test'),('2019-09-04 07:59:59','2019-09-04 15:59:59','GRSETH','4h','0.001239130000000','0.001239300000000','0.078517865107628','0.078528637211498','63.36531688170571','63.365316881705709','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','GRSETH','4h','0.001270410000000','0.001238220000000','0.078517865107628','0.076528357721969','61.80513779616659','61.805137796166591','test'),('2019-09-10 11:59:59','2019-09-10 23:59:59','GRSETH','4h','0.001269840000000','0.001250640000000','0.078517865107628','0.077330673800009','61.83288060513765','61.832880605137653','test'),('2019-09-11 11:59:59','2019-09-11 15:59:59','GRSETH','4h','0.001249040000000','0.001241630000000','0.078517865107628','0.078052053459925','62.862570540277325','62.862570540277325','test'),('2019-09-28 11:59:59','2019-09-28 15:59:59','GRSETH','4h','0.001085500000000','0.001079400000000','0.078517865107628','0.078076631595738','72.33336260490833','72.333362604908331','test'),('2019-10-02 03:59:59','2019-10-06 07:59:59','GRSETH','4h','0.001066710000000','0.001117450000000','0.078517865107628','0.082252710075390','73.60750823337926','73.607508233379264','test'),('2019-10-11 15:59:59','2019-10-15 11:59:59','GRSETH','4h','0.001113970000000','0.001147590000000','0.078517865107628','0.080887561441388','70.48472140868067','70.484721408680670','test'),('2019-10-23 07:59:59','2019-10-23 11:59:59','GRSETH','4h','0.001177980000000','0.001164110000000','0.078517865107628','0.077593364870746','66.6546674032055','66.654667403205494','test'),('2019-10-27 19:59:59','2019-10-27 23:59:59','GRSETH','4h','0.001149330000000','0.001144520000000','0.078517865107628','0.078189264156493','68.31620605711849','68.316206057118492','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','GRSETH','4h','0.001239600000000','0.001222180000000','0.078517865107628','0.077414459807390','63.34129163248467','63.341291632484669','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','GRSETH','4h','0.001236020000000','0.001209900000000','0.078517865107628','0.076858598561285','63.52475292279089','63.524752922790888','test'),('2019-11-07 19:59:59','2019-11-08 03:59:59','GRSETH','4h','0.001230000000000','0.001209900000000','0.078517865107628','0.077234768287577','63.835662689128455','63.835662689128455','test'),('2019-11-13 11:59:59','2019-11-13 15:59:59','GRSETH','4h','0.001221640000000','0.001210030000000','0.078517865107628','0.077771661304626','64.27250671853247','64.272506718532469','test'),('2019-11-14 03:59:59','2019-11-14 07:59:59','GRSETH','4h','0.001214990000000','0.001192160000000','0.078517865107628','0.077042492585708','64.62428917738252','64.624289177382522','test'),('2019-11-14 19:59:59','2019-11-15 03:59:59','GRSETH','4h','0.001230850000000','0.001218110000000','0.078517865107628','0.077705160390180','63.79157907757079','63.791579077570788','test'),('2019-11-16 11:59:59','2019-11-16 15:59:59','GRSETH','4h','0.001221750000000','0.001213490000000','0.078517865107628','0.077987022000782','64.26671995713362','64.266719957133617','test'),('2019-11-17 03:59:59','2019-11-17 07:59:59','GRSETH','4h','0.001221320000000','0.001203060000000','0.078517865107628','0.077343941633956','64.289346860469','64.289346860468996','test'),('2019-11-18 07:59:59','2019-11-18 11:59:59','GRSETH','4h','0.001209950000000','0.001190830000000','0.078517865107628','0.077277101786121','64.89347915833547','64.893479158335467','test'),('2019-11-25 03:59:59','2019-12-01 03:59:59','GRSETH','4h','0.001187200000000','0.001274920000000','0.078517865107628','0.084319404129900','66.1370157577729','66.137015757772900','test'),('2019-12-03 15:59:59','2019-12-03 19:59:59','GRSETH','4h','0.001285860000000','0.001278740000000','0.078517865107628','0.078083099892467','61.06253021917471','61.062530219174711','test'),('2019-12-07 11:59:59','2019-12-08 03:59:59','GRSETH','4h','0.001322390000000','0.001256850000000','0.078517865107628','0.074626380084939','59.37572509443356','59.375725094433562','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','GRSETH','4h','0.001265300000000','0.001235300000000','0.078517865107628','0.076656222846323','62.05474204349008','62.054742043490080','test'),('2019-12-09 07:59:59','2019-12-10 07:59:59','GRSETH','4h','0.001409690000000','0.001264210000000','0.078517865107628','0.070414821874110','55.69867496231654','55.698674962316538','test'),('2019-12-11 11:59:59','2019-12-11 19:59:59','GRSETH','4h','0.001281000000000','0.001264210000000','0.078517865107628','0.077488735556373','61.29419602469008','61.294196024690081','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','GRSETH','4h','0.001280310000000','0.001225210000000','0.078517865107628','0.075138734766203','61.32722942695753','61.327229426957530','test'),('2019-12-19 23:59:59','2019-12-21 03:59:59','GRSETH','4h','0.001228940000000','0.001227170000000','0.078517865107628','0.078404778527941','63.89072298698716','63.890722986987157','test'),('2019-12-25 07:59:59','2019-12-25 15:59:59','GRSETH','4h','0.001228760000000','0.001200000000000','0.078517865107628','0.076680098741132','63.90008228427683','63.900082284276827','test'),('2019-12-27 07:59:59','2019-12-27 19:59:59','GRSETH','4h','0.001258270000000','0.001224670000000','0.078517865107628','0.076421176584802','62.4014441317269','62.401444131726898','test'),('2019-12-31 23:59:59','2020-01-01 03:59:59','GRSETH','4h','0.001212610000000','0.001213680000000','0.078517865107628','0.078587148814397','64.75112782149908','64.751127821499082','test'),('2020-01-01 15:59:59','2020-01-01 15:59:59','GRSETH','4h','0.001198760000000','0.001198760000000','0.078517865107628','0.078517865107628','65.49923680105108','65.499236801051083','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 13:58:55
