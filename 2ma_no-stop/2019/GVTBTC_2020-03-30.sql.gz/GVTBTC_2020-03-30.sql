-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-02 11:59:59','GVTBTC','4h','0.001093700000000','0.001120100000000','0.001467500000000','0.001502922876474','1.341775624028527','1.341775624028527','test'),('2019-01-05 03:59:59','2019-01-05 07:59:59','GVTBTC','4h','0.001098100000000','0.001082800000000','0.001476355719118','0.001455785422695','1.344463818521537','1.344463818521537','test'),('2019-01-17 07:59:59','2019-01-18 15:59:59','GVTBTC','4h','0.001019800000000','0.001001000000000','0.001476355719118','0.001449139120256','1.447691428827221','1.447691428827221','test'),('2019-01-23 11:59:59','2019-01-27 03:59:59','GVTBTC','4h','0.001045200000000','0.001032000000000','0.001476355719118','0.001457710583745','1.4125102555663986','1.412510255566399','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','GVTBTC','4h','0.001026100000000','0.001021100000000','0.001476355719118','0.001469161704309','1.4388029618146378','1.438802961814638','test'),('2019-01-30 11:59:59','2019-01-30 19:59:59','GVTBTC','4h','0.001043900000000','0.001045700000000','0.001476355719118','0.001478901403853','1.4142692969805537','1.414269296980554','test'),('2019-02-07 15:59:59','2019-02-07 19:59:59','GVTBTC','4h','0.001011000000000','0.000995100000000','0.001476355719118','0.001453137068343','1.4602925016003956','1.460292501600396','test'),('2019-02-08 07:59:59','2019-02-08 19:59:59','GVTBTC','4h','0.001038900000000','0.001042500000000','0.001476355719118','0.001481471592242','1.4210758678583117','1.421075867858312','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','GVTBTC','4h','0.001025500000000','0.001027700000000','0.001476355719118','0.001479522937628','1.4396447772969283','1.439644777296928','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','GVTBTC','4h','0.001040000000000','0.001025000000000','0.001476355719118','0.001455062127015','1.4195728068442308','1.419572806844231','test'),('2019-02-20 07:59:59','2019-02-21 03:59:59','GVTBTC','4h','0.001038200000000','0.001045500000000','0.001476355719118','0.001486736567461','1.4220340195704102','1.422034019570410','test'),('2019-02-23 03:59:59','2019-02-23 07:59:59','GVTBTC','4h','0.001037600000000','0.001027100000000','0.001476355719118','0.001461415727743','1.422856321432151','1.422856321432151','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','GVTBTC','4h','0.001055700000000','0.001039500000000','0.001476355719118','0.001453700644144','1.3984614181282562','1.398461418128256','test'),('2019-02-24 11:59:59','2019-02-24 15:59:59','GVTBTC','4h','0.001046200000000','0.001018900000000','0.001476355719118','0.001437831047801','1.4111601215044924','1.411160121504492','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','GVTBTC','4h','0.001082300000000','0.001055700000000','0.001476355719118','0.001440070897785','1.3640910275505866','1.364091027550587','test'),('2019-03-01 15:59:59','2019-03-01 19:59:59','GVTBTC','4h','0.001069000000000','0.001081200000000','0.001476355719118','0.001493204680552','1.381062412645463','1.381062412645463','test'),('2019-03-12 15:59:59','2019-03-12 19:59:59','GVTBTC','4h','0.001025000000000','0.001046300000000','0.001476355719118','0.001507035111135','1.440347043041951','1.440347043041951','test'),('2019-03-14 15:59:59','2019-03-16 03:59:59','GVTBTC','4h','0.001045900000000','0.001019500000000','0.001476355719118','0.001439090406005','1.4115648906377283','1.411564890637728','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','GVTBTC','4h','0.001025300000000','0.001024300000000','0.001476355719118','0.001474915793517','1.4399256014025161','1.439925601402516','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','GVTBTC','4h','0.001013400000000','0.001005500000000','0.001476355719118','0.001464846729399','1.456834141620288','1.456834141620288','test'),('2019-03-26 23:59:59','2019-04-02 07:59:59','GVTBTC','4h','0.001013300000000','0.000967500000000','0.001476355719118','0.001409626130708','1.4569779128767393','1.456977912876739','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','GVTBTC','4h','0.000808000000000','0.000808900000000','0.001476355719118','0.001478000174746','1.827172919700495','1.827172919700495','test'),('2019-05-22 07:59:59','2019-05-23 11:59:59','GVTBTC','4h','0.000431200000000','0.000460800000000','0.001476355719118','0.001577701102434','3.4238305174350647','3.423830517435065','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','GVTBTC','4h','0.000424000000000','0.000412500000000','0.001476355719118','0.001436313052208','3.48197103565566','3.481971035655660','test'),('2019-05-31 11:59:59','2019-06-01 07:59:59','GVTBTC','4h','0.000433200000000','0.000418100000000','0.001476355719118','0.001424894566397','3.408023358998153','3.408023358998153','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','GVTBTC','4h','0.000421600000000','0.000421700000000','0.001476355719118','0.001476705898368','3.5017925026518024','3.501792502651802','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','GVTBTC','4h','0.000422000000000','0.000408400000000','0.001476355719118','0.001428776482672','3.498473268052132','3.498473268052132','test'),('2019-06-05 07:59:59','2019-06-05 11:59:59','GVTBTC','4h','0.000418000000000','0.000413600000000','0.001476355719118','0.001460815132601','3.5319514811435404','3.531951481143540','test'),('2019-06-05 19:59:59','2019-06-06 15:59:59','GVTBTC','4h','0.000422400000000','0.000419900000000','0.001476355719118','0.001467617818318','3.4951603198816286','3.495160319881629','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','GVTBTC','4h','0.000413600000000','0.000380300000000','0.001476355719118','0.001357490522197','3.569525433070599','3.569525433070599','test'),('2019-06-23 11:59:59','2019-06-23 15:59:59','GVTBTC','4h','0.000423700000000','0.000379000000000','0.001476355719118','0.001320601410304','3.484436438796318','3.484436438796318','test'),('2019-07-21 23:59:59','2019-07-22 03:59:59','GVTBTC','4h','0.000209000000000','0.000208700000000','0.001476355719118','0.001474236548229','7.063902962287081','7.063902962287081','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','GVTBTC','4h','0.000207600000000','0.000207100000000','0.001476355719118','0.001472799949082','7.111540072822735','7.111540072822735','test'),('2019-07-26 03:59:59','2019-07-26 23:59:59','GVTBTC','4h','0.000206500000000','0.000206300000000','0.001476355719118','0.001474925834644','7.1494223686101686','7.149422368610169','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','GVTBTC','4h','0.000208300000000','0.000209700000000','0.001476355719118','0.001486278417182','7.087641474402304','7.087641474402304','test'),('2019-07-30 19:59:59','2019-07-30 23:59:59','GVTBTC','4h','0.000206900000000','0.000206800000000','0.001476355719118','0.001475642159080','7.1356003823972936','7.135600382397294','test'),('2019-07-31 07:59:59','2019-07-31 11:59:59','GVTBTC','4h','0.000206500000000','0.000205100000000','0.001476355719118','0.001466346527802','7.1494223686101686','7.149422368610169','test'),('2019-08-14 15:59:59','2019-08-14 19:59:59','GVTBTC','4h','0.000147100000000','0.000122700000000','0.001476355719118','0.001231467346946','10.03640869556764','10.036408695567641','test'),('2019-08-22 11:59:59','2019-08-26 03:59:59','GVTBTC','4h','0.000125400000000','0.000127500000000','0.001476355719118','0.001501079379486','11.7731716038118','11.773171603811800','test'),('2019-08-26 07:59:59','2019-08-26 19:59:59','GVTBTC','4h','0.000131500000000','0.000130000000000','0.001476355719118','0.001459515159584','11.227039689110265','11.227039689110265','test'),('2019-08-29 19:59:59','2019-08-29 23:59:59','GVTBTC','4h','0.000130800000000','0.000130400000000','0.001476355719118','0.001471840869824','11.287123234847094','11.287123234847094','test'),('2019-09-01 03:59:59','2019-09-01 11:59:59','GVTBTC','4h','0.000131400000000','0.000129600000000','0.001476355719118','0.001456131668171','11.235583859345509','11.235583859345509','test'),('2019-09-10 03:59:59','2019-09-10 07:59:59','GVTBTC','4h','0.000115400000000','0.000114600000000','0.001476355719118','0.001466121017426','12.793377115407278','12.793377115407278','test'),('2019-09-11 07:59:59','2019-09-11 11:59:59','GVTBTC','4h','0.000115800000000','0.000114000000000','0.001476355719118','0.001453407184624','12.749185830034541','12.749185830034541','test'),('2019-09-18 03:59:59','2019-09-24 15:59:59','GVTBTC','4h','0.000108500000000','0.000119300000000','0.001476355719118','0.001623310942772','13.60696515316129','13.606965153161291','test'),('2019-09-25 19:59:59','2019-09-26 15:59:59','GVTBTC','4h','0.000116400000000','0.000118800000000','0.001476355719118','0.001506796043224','12.683468377302406','12.683468377302406','test'),('2019-10-10 15:59:59','2019-10-11 07:59:59','GVTBTC','4h','0.000144900000000','0.000139900000000','0.001476355719118','0.001425411767458','10.188790332077295','10.188790332077295','test'),('2019-10-12 23:59:59','2019-10-13 03:59:59','GVTBTC','4h','0.000141800000000','0.000140500000000','0.001476355719118','0.001462820723104','10.411535395754584','10.411535395754584','test'),('2019-10-13 07:59:59','2019-10-13 11:59:59','GVTBTC','4h','0.000141000000000','0.000142400000000','0.001476355719118','0.001491014570230','10.47060793700709','10.470607937007090','test'),('2019-10-15 03:59:59','2019-10-15 07:59:59','GVTBTC','4h','0.000141700000000','0.000141000000000','0.001476355719118','0.001469062501028','10.418882986012703','10.418882986012703','test'),('2019-10-20 23:59:59','2019-10-21 03:59:59','GVTBTC','4h','0.000137300000000','0.000135800000000','0.001476355719118','0.001460226559769','10.752772899621267','10.752772899621267','test'),('2019-11-09 07:59:59','2019-11-21 11:59:59','GVTBTC','4h','0.000122600000000','0.000130100000000','0.001476355719118','0.001566671117922','12.042053173882545','12.042053173882545','test'),('2019-11-22 19:59:59','2019-11-25 07:59:59','GVTBTC','4h','0.000137000000000','0.000141900000000','0.001476355719118','0.001529159682794','10.776319117649635','10.776319117649635','test'),('2019-12-01 19:59:59','2019-12-01 23:59:59','GVTBTC','4h','0.000142300000000','0.000141300000000','0.001476355719118','0.001465980766770','10.374952347983134','10.374952347983134','test'),('2019-12-02 03:59:59','2019-12-02 07:59:59','GVTBTC','4h','0.000142000000000','0.000141900000000','0.001476355719118','0.001475316031992','10.396871261394365','10.396871261394365','test'),('2019-12-02 15:59:59','2019-12-04 15:59:59','GVTBTC','4h','0.000161500000000','0.000141700000000','0.001476355719118','0.001295353593802','9.14152148060681','9.141521480606810','test'),('2019-12-04 23:59:59','2019-12-05 03:59:59','GVTBTC','4h','0.000143800000000','0.000141500000000','0.001476355719118','0.001452742240996','10.266729618344923','10.266729618344923','test'),('2019-12-06 07:59:59','2019-12-06 11:59:59','GVTBTC','4h','0.000143700000000','0.000146300000000','0.001476355719118','0.001503067791976','10.2738741761865','10.273874176186499','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','GVTBTC','4h','0.000149200000000','0.000143200000000','0.001476355719118','0.001416984845695','9.895145570495979','9.895145570495979','test'),('2019-12-17 03:59:59','2019-12-17 19:59:59','GVTBTC','4h','0.000146000000000','0.000140400000000','0.001476355719118','0.001419728376467','10.112025473410958','10.112025473410958','test'),('2019-12-25 19:59:59','2019-12-26 07:59:59','GVTBTC','4h','0.000139700000000','0.000138100000000','0.001476355719118','0.001459446849035','10.568043801846814','10.568043801846814','test'),('2019-12-27 19:59:59','2019-12-27 23:59:59','GVTBTC','4h','0.000138100000000','0.000138300000000','0.001476355719118','0.001478493815742','10.690483121781318','10.690483121781318','test'),('2019-12-28 23:59:59','2019-12-29 03:59:59','GVTBTC','4h','0.000138300000000','0.000137300000000','0.001476355719118','0.001465680695842','10.675023276341287','10.675023276341287','test'),('2019-12-29 07:59:59','2019-12-29 11:59:59','GVTBTC','4h','0.000138600000000','0.000137000000000','0.001476355719118','0.001459312651653','10.651917165353535','10.651917165353535','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  9:31:37
