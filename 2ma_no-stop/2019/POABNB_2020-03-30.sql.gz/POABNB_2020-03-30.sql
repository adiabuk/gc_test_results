-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-10 07:59:59','POABNB','4h','0.004780000000000','0.004620000000000','0.711908500000000','0.688078926778243','148.93483263598327','148.934832635983270','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','POABNB','4h','0.004540000000000','0.004490000000000','0.711908500000000','0.704068098017621','156.80803964757712','156.808039647577118','test'),('2019-01-17 03:59:59','2019-01-17 19:59:59','POABNB','4h','0.004640000000000','0.004560000000000','0.711908500000000','0.699634215517241','153.42855603448277','153.428556034482767','test'),('2019-01-19 03:59:59','2019-01-20 15:59:59','POABNB','4h','0.004660000000000','0.004460000000000','0.711908500000000','0.681354487124464','152.77006437768242','152.770064377682417','test'),('2019-01-20 23:59:59','2019-01-21 03:59:59','POABNB','4h','0.004590000000000','0.004580000000000','0.711908500000000','0.710357501089325','155.09989106753812','155.099891067538124','test'),('2019-01-21 15:59:59','2019-01-21 23:59:59','POABNB','4h','0.004620000000000','0.004500000000000','0.711908500000000','0.693417370129870','154.09274891774893','154.092748917748935','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','POABNB','4h','0.004680000000000','0.004550000000000','0.711908500000000','0.692133263888889','152.11720085470085','152.117200854700855','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','POABNB','4h','0.004680000000000','0.004550000000000','0.711908500000000','0.692133263888889','152.11720085470085','152.117200854700855','test'),('2019-01-30 11:59:59','2019-01-31 11:59:59','POABNB','4h','0.004660000000000','0.004360000000000','0.711908500000000','0.666077480686695','152.77006437768242','152.770064377682417','test'),('2019-02-26 03:59:59','2019-02-27 15:59:59','POABNB','4h','0.002920000000000','0.002780000000000','0.711908500000000','0.677775900684932','243.80428082191784','243.804280821917843','test'),('2019-03-15 03:59:59','2019-03-15 11:59:59','POABNB','4h','0.002310000000000','0.002260000000000','0.711908500000000','0.696499225108225','308.18549783549787','308.185497835497870','test'),('2019-03-20 19:59:59','2019-03-20 23:59:59','POABNB','4h','0.002160000000000','0.002140000000000','0.711908500000000','0.705316754629630','329.58726851851856','329.587268518518556','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','POABNB','4h','0.002200000000000','0.002150000000000','0.711908500000000','0.695728761363636','323.59477272727275','323.594772727272755','test'),('2019-03-22 15:59:59','2019-03-23 03:59:59','POABNB','4h','0.002200000000000','0.002150000000000','0.711908500000000','0.695728761363636','323.59477272727275','323.594772727272755','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','POABNB','4h','0.002170000000000','0.002170000000000','0.711908500000000','0.711908500000000','328.0684331797235','328.068433179723513','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','POABNB','4h','0.002130000000000','0.002140000000000','0.711908500000000','0.715250793427230','334.2293427230047','334.229342723004720','test'),('2019-04-07 15:59:59','2019-04-07 19:59:59','POABNB','4h','0.002160000000000','0.002150000000000','0.711908500000000','0.708612627314815','329.58726851851856','329.587268518518556','test'),('2019-04-08 23:59:59','2019-04-09 03:59:59','POABNB','4h','0.002180000000000','0.002180000000000','0.711908500000000','0.711908500000000','326.5635321100917','326.563532110091728','test'),('2019-04-09 23:59:59','2019-04-10 03:59:59','POABNB','4h','0.002170000000000','0.002200000000000','0.711908500000000','0.721750552995392','328.0684331797235','328.068433179723513','test'),('2019-04-15 07:59:59','2019-04-15 11:59:59','POABNB','4h','0.002230000000000','0.002200000000000','0.711908500000000','0.702331255605381','319.2414798206278','319.241479820627774','test'),('2019-04-17 11:59:59','2019-04-17 19:59:59','POABNB','4h','0.002210000000000','0.002160000000000','0.711908500000000','0.695801972850679','322.1305429864253','322.130542986425326','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','POABNB','4h','0.001400000000000','0.001340000000000','0.711908500000000','0.681398135714286','508.5060714285715','508.506071428571488','test'),('2019-05-10 23:59:59','2019-05-11 03:59:59','POABNB','4h','0.001350000000000','0.001340000000000','0.711908500000000','0.706635103703704','527.3396296296296','527.339629629629599','test'),('2019-05-11 07:59:59','2019-05-11 15:59:59','POABNB','4h','0.001410000000000','0.001330000000000','0.711908500000000','0.671516528368794','504.89964539007093','504.899645390070930','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','POABNB','4h','0.001170000000000','0.001060000000000','0.711908500000000','0.644976931623932','608.4688034188034','608.468803418803418','test'),('2019-05-26 23:59:59','2019-05-30 03:59:59','POABNB','4h','0.001240000000000','0.001180000000000','0.711908500000000','0.677461314516129','574.1197580645162','574.119758064516191','test'),('2019-06-12 19:59:59','2019-06-13 03:59:59','POABNB','4h','0.001160000000000','0.001080000000000','0.711908500000000','0.662811362068966','613.7142241379311','613.714224137931069','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','POABNB','4h','0.001130000000000','0.001130000000000','0.711908500000000','0.711908500000000','630.0075221238939','630.007522123893864','test'),('2019-06-15 19:59:59','2019-06-15 23:59:59','POABNB','4h','0.001090000000000','0.001110000000000','0.711908500000000','0.724971041284404','653.1270642201835','653.127064220183456','test'),('2019-06-20 07:59:59','2019-06-20 11:59:59','POABNB','4h','0.001090000000000','0.001000000000000','0.711908500000000','0.653127064220184','653.1270642201835','653.127064220183456','test'),('2019-06-23 11:59:59','2019-06-23 15:59:59','POABNB','4h','0.001050000000000','0.001040000000000','0.711908500000000','0.705128419047619','678.0080952380953','678.008095238095279','test'),('2019-06-23 23:59:59','2019-06-24 03:59:59','POABNB','4h','0.001050000000000','0.001030000000000','0.711908500000000','0.698348338095238','678.0080952380953','678.008095238095279','test'),('2019-06-27 11:59:59','2019-06-27 15:59:59','POABNB','4h','0.001050000000000','0.000990000000000','0.711908500000000','0.671228014285714','678.0080952380953','678.008095238095279','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','POABNB','4h','0.001020000000000','0.001020000000000','0.711908500000000','0.711908500000000','697.9495098039216','697.949509803921615','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','POABNB','4h','0.000980000000000','0.000960000000000','0.711908500000000','0.697379755102041','726.4372448979593','726.437244897959317','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','POABNB','4h','0.000749000000000','0.000735000000000','0.711908500000000','0.698601799065421','950.4786381842457','950.478638184245710','test'),('2019-07-26 07:59:59','2019-07-26 15:59:59','POABNB','4h','0.000739000000000','0.000739000000000','0.711908500000000','0.711908500000000','963.3403247631936','963.340324763193621','test'),('2019-07-29 03:59:59','2019-07-31 07:59:59','POABNB','4h','0.000740000000000','0.000736000000000','0.711908500000000','0.708060345945946','962.0385135135136','962.038513513513635','test'),('2019-08-18 23:59:59','2019-08-19 07:59:59','POABNB','4h','0.000572000000000','0.000504000000000','0.711908500000000','0.627276020979021','1244.5952797202797','1244.595279720279677','test'),('2019-08-20 03:59:59','2019-08-20 07:59:59','POABNB','4h','0.000541000000000','0.000509000000000','0.474605666666667','0.446532873074554','877.2747997535429','877.274799753542879','test'),('2019-08-21 23:59:59','2019-08-22 03:59:59','POABNB','4h','0.000527000000000','0.000515000000000','0.521410898223519','0.509538164298126','989.3944937827692','989.394493782769246','test'),('2019-08-22 11:59:59','2019-09-02 23:59:59','POABNB','4h','0.000519000000000','0.000592000000000','0.521410898223519','0.594750003368638','1004.6452759605376','1004.645275960537560','test'),('2019-09-04 11:59:59','2019-09-04 19:59:59','POABNB','4h','0.000620000000000','0.000662000000000','0.536777491028451','0.573139837194894','865.770146820082','865.770146820082005','test'),('2019-09-09 15:59:59','2019-09-09 19:59:59','POABNB','4h','0.000600000000000','0.000648000000000','0.545868077570062','0.589537523775667','909.780129283436','909.780129283436054','test'),('2019-09-25 11:59:59','2019-10-09 15:59:59','POABNB','4h','0.000781000000000','0.001064000000000','0.556785439121463','0.758539958034874','712.9134943936785','712.913494393678548','test'),('2019-10-20 07:59:59','2019-10-20 19:59:59','POABNB','4h','0.000989000000000','0.000978000000000','0.607224068849816','0.600470312775652','613.9778249239794','613.977824923979369','test'),('2019-10-21 11:59:59','2019-10-21 19:59:59','POABNB','4h','0.001000000000000','0.000988000000000','0.607224068849816','0.599937380023618','607.2240688498159','607.224068849815922','test'),('2019-11-17 07:59:59','2019-11-18 19:59:59','POABNB','4h','0.000806000000000','0.000829000000000','0.607224068849816','0.624551802824438','753.379738027067','753.379738027066992','test'),('2019-11-22 19:59:59','2019-11-24 03:59:59','POABNB','4h','0.000835000000000','0.000816000000000','0.608045891118381','0.594210116350418','728.1986719980607','728.198671998060718','test'),('2019-11-24 11:59:59','2019-12-04 03:59:59','POABNB','4h','0.000829000000000','0.000920000000000','0.608045891118381','0.674791580010749','733.4691087073354','733.469108707335408','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 23:54:20
