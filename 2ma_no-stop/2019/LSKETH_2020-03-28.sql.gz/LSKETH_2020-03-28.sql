-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 19:59:59','LSKETH','4h','0.009517000000000','0.009498000000000','0.072144500000000','0.072000468740149','7.580592623725964','7.580592623725964','test'),('2019-01-11 11:59:59','2019-01-12 03:59:59','LSKETH','4h','0.009763000000000','0.009512000000000','0.072144500000000','0.070289714636894','7.38958311994264','7.389583119942640','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','LSKETH','4h','0.009811000000000','0.009887000000000','0.072144500000000','0.072703360666599','7.353429823667312','7.353429823667312','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','LSKETH','4h','0.010470000000000','0.010446000000000','0.072144500000000','0.071979125787966','6.890592168099332','6.890592168099332','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','LSKETH','4h','0.010512000000000','0.010225000000000','0.072144500000000','0.070174801417428','6.863061263318112','6.863061263318112','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','LSKETH','4h','0.010389000000000','0.010325000000000','0.072144500000000','0.071700063769371','6.944316103571085','6.944316103571085','test'),('2019-02-04 07:59:59','2019-02-04 11:59:59','LSKETH','4h','0.010350000000000','0.010385000000000','0.072144500000000','0.072388466908213','6.97048309178744','6.970483091787440','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','LSKETH','4h','0.010400000000000','0.010381000000000','0.072144500000000','0.072012697548077','6.936971153846154','6.936971153846154','test'),('2019-02-26 15:59:59','2019-02-28 03:59:59','LSKETH','4h','0.008885000000000','0.008898000000000','0.072144500000000','0.072250057512662','8.119808666291503','8.119808666291503','test'),('2019-04-13 03:59:59','2019-04-13 11:59:59','LSKETH','4h','0.012150000000000','0.011822000000000','0.072144500000000','0.070196895390947','5.937818930041153','5.937818930041153','test'),('2019-05-09 23:59:59','2019-05-10 07:59:59','LSKETH','4h','0.010489000000000','0.010762000000000','0.072144500000000','0.074022224139575','6.878110401372867','6.878110401372867','test'),('2019-05-11 07:59:59','2019-05-11 11:59:59','LSKETH','4h','0.010808000000000','0.010263000000000','0.072144500000000','0.068506569531828','6.67510177646188','6.675101776461880','test'),('2019-06-02 03:59:59','2019-06-02 11:59:59','LSKETH','4h','0.008146000000000','0.007925000000000','0.072144500000000','0.070187228394304','8.856432604959489','8.856432604959489','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','LSKETH','4h','0.007965000000000','0.007890000000000','0.072144500000000','0.071465173258004','9.057689893283113','9.057689893283113','test'),('2019-06-03 11:59:59','2019-06-03 23:59:59','LSKETH','4h','0.007968000000000','0.007949000000000','0.072144500000000','0.071972468687249','9.054279618473897','9.054279618473897','test'),('2019-06-06 19:59:59','2019-06-06 23:59:59','LSKETH','4h','0.008036000000000','0.007868000000000','0.072144500000000','0.070636252613240','8.977663016426083','8.977663016426083','test'),('2019-06-07 03:59:59','2019-06-10 15:59:59','LSKETH','4h','0.008098000000000','0.008369000000000','0.072144500000000','0.074558819523339','8.90892813040257','8.908928130402570','test'),('2019-07-15 07:59:59','2019-07-15 11:59:59','LSKETH','4h','0.005601000000000','0.005600000000000','0.072144500000000','0.072131619353687','12.880646313158364','12.880646313158364','test'),('2019-07-17 07:59:59','2019-07-28 23:59:59','LSKETH','4h','0.006245000000000','0.006575000000000','0.072144500000000','0.075956779423539','11.55236188951161','11.552361889511610','test'),('2019-08-09 11:59:59','2019-08-09 15:59:59','LSKETH','4h','0.006092000000000','0.005878000000000','0.072144500000000','0.069610205351280','11.842498358502954','11.842498358502954','test'),('2019-08-09 23:59:59','2019-08-10 03:59:59','LSKETH','4h','0.006068000000000','0.005961000000000','0.072144500000000','0.070872340886618','11.889337508239947','11.889337508239947','test'),('2019-08-11 07:59:59','2019-08-11 11:59:59','LSKETH','4h','0.006057000000000','0.006034000000000','0.072144500000000','0.071870548621430','11.910929503054318','11.910929503054318','test'),('2019-08-12 07:59:59','2019-08-12 11:59:59','LSKETH','4h','0.006006000000000','0.005949000000000','0.072144500000000','0.071459811938062','12.012071262071261','12.012071262071261','test'),('2019-08-14 19:59:59','2019-08-15 15:59:59','LSKETH','4h','0.006108000000000','0.006151000000000','0.072144500000000','0.072652393500327','11.811476751800917','11.811476751800917','test'),('2019-08-20 07:59:59','2019-08-20 11:59:59','LSKETH','4h','0.006244000000000','0.006205000000000','0.072144500000000','0.071693885730301','11.554212043561819','11.554212043561819','test'),('2019-08-21 07:59:59','2019-08-21 11:59:59','LSKETH','4h','0.006260000000000','0.006323000000000','0.072144500000000','0.072870554872204','11.524680511182108','11.524680511182108','test'),('2019-08-24 19:59:59','2019-08-24 23:59:59','LSKETH','4h','0.006303000000000','0.006230000000000','0.072144500000000','0.071308937807393','11.446057432968429','11.446057432968429','test'),('2019-08-25 03:59:59','2019-08-25 07:59:59','LSKETH','4h','0.006373000000000','0.006243000000000','0.072144500000000','0.070672856347089','11.3203357916209','11.320335791620900','test'),('2019-08-25 11:59:59','2019-08-25 15:59:59','LSKETH','4h','0.006331000000000','0.006254000000000','0.072144500000000','0.071267051492655','11.395435160322224','11.395435160322224','test'),('2019-08-25 19:59:59','2019-08-26 03:59:59','LSKETH','4h','0.006411000000000','0.006238000000000','0.072144500000000','0.070197690063953','11.253236624551551','11.253236624551551','test'),('2019-08-26 15:59:59','2019-08-27 15:59:59','LSKETH','4h','0.006395000000000','0.006290000000000','0.072144500000000','0.070959953870211','11.281391712275216','11.281391712275216','test'),('2019-09-24 23:59:59','2019-09-26 19:59:59','LSKETH','4h','0.005140000000000','0.005135000000000','0.072144500000000','0.072074320525292','14.035894941634242','14.035894941634242','test'),('2019-09-28 19:59:59','2019-09-28 23:59:59','LSKETH','4h','0.004975000000000','0.004930000000000','0.072144500000000','0.071491936683417','14.501407035175879','14.501407035175879','test'),('2019-09-29 03:59:59','2019-09-29 07:59:59','LSKETH','4h','0.005001000000000','0.004882000000000','0.072144500000000','0.070427804239152','14.426014797040592','14.426014797040592','test'),('2019-10-02 19:59:59','2019-10-02 23:59:59','LSKETH','4h','0.004906000000000','0.004831000000000','0.072144500000000','0.071041597941296','14.705360782715044','14.705360782715044','test'),('2019-10-03 11:59:59','2019-10-03 15:59:59','LSKETH','4h','0.004924000000000','0.004927000000000','0.072144500000000','0.072188454813160','14.651604386677496','14.651604386677496','test'),('2019-10-06 23:59:59','2019-10-07 07:59:59','LSKETH','4h','0.004996000000000','0.004979000000000','0.072144500000000','0.071899012309848','14.440452361889513','14.440452361889513','test'),('2019-10-18 03:59:59','2019-10-18 07:59:59','LSKETH','4h','0.004691000000000','0.004615000000000','0.072144500000000','0.070975669899808','15.379343423577064','15.379343423577064','test'),('2019-10-28 11:59:59','2019-10-29 03:59:59','LSKETH','4h','0.004384000000000','0.004384000000000','0.072144500000000','0.072144500000000','16.456318430656935','16.456318430656935','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','LSKETH','4h','0.004400000000000','0.004355000000000','0.072144500000000','0.071406658522727','16.39647727272727','16.396477272727271','test'),('2019-10-31 11:59:59','2019-10-31 15:59:59','LSKETH','4h','0.004455000000000','0.004384000000000','0.072144500000000','0.070994722334456','16.19405162738496','16.194051627384962','test'),('2019-11-03 15:59:59','2019-11-03 23:59:59','LSKETH','4h','0.004418000000000','0.004400000000000','0.072144500000000','0.071850565866908','16.32967406066093','16.329674060660931','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','LSKETH','4h','0.004205000000000','0.004192000000000','0.072144500000000','0.071921461117717','17.15683709869203','17.156837098692030','test'),('2019-11-21 15:59:59','2019-11-22 11:59:59','LSKETH','4h','0.004308000000000','0.004399000000000','0.072144500000000','0.073668443709378','16.746634168987928','16.746634168987928','test'),('2019-12-02 15:59:59','2019-12-02 23:59:59','LSKETH','4h','0.004568000000000','0.004477000000000','0.072144500000000','0.070707295643608','15.793454465849386','15.793454465849386','test'),('2019-12-09 11:59:59','2019-12-09 15:59:59','LSKETH','4h','0.004586000000000','0.004551000000000','0.072144500000000','0.071593898713476','15.731465329262974','15.731465329262974','test'),('2019-12-12 03:59:59','2019-12-12 07:59:59','LSKETH','4h','0.004568000000000','0.004515000000000','0.072144500000000','0.071307446913310','15.793454465849386','15.793454465849386','test'),('2019-12-12 15:59:59','2019-12-12 19:59:59','LSKETH','4h','0.004562000000000','0.004541000000000','0.072144500000000','0.071812401249452','15.81422621657168','15.814226216571679','test'),('2019-12-19 11:59:59','2019-12-19 15:59:59','LSKETH','4h','0.004281000000000','0.004142000000000','0.072144500000000','0.069802036673674','16.852254146227516','16.852254146227516','test'),('2019-12-23 11:59:59','2019-12-23 19:59:59','LSKETH','4h','0.004243000000000','0.004448000000000','0.072144500000000','0.075630152250766','17.0031817110535','17.003181711053500','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','LSKETH','4h','0.004411000000000','0.004279000000000','0.072144500000000','0.069985562344140','16.355588301972343','16.355588301972343','test'),('2019-12-30 11:59:59','2019-12-30 23:59:59','LSKETH','4h','0.004454000000000','0.004370000000000','0.072144500000000','0.070783894252357','16.19768747193534','16.197687471935339','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:18:38
