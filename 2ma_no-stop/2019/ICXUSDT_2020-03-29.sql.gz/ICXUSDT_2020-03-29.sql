-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-10 07:59:59','ICXUSDT','4h','0.241800000000000','0.259700000000000','15.000000000000000','16.110421836228291','62.03473945409429','62.034739454094293','test'),('2019-01-17 23:59:59','2019-01-18 07:59:59','ICXUSDT','4h','0.242200000000000','0.243000000000000','15.277605459057073','15.328068235139835','63.07847010345612','63.078470103456119','test'),('2019-01-19 11:59:59','2019-01-20 07:59:59','ICXUSDT','4h','0.242300000000000','0.239600000000000','15.290221153077763','15.119838994128900','63.1045033143944','63.104503314394400','test'),('2019-02-07 07:59:59','2019-02-14 11:59:59','ICXUSDT','4h','0.203500000000000','0.214700000000000','15.290221153077763','16.131746838161160','75.13622188244601','75.136221882446009','test'),('2019-02-25 19:59:59','2019-03-04 07:59:59','ICXUSDT','4h','0.248800000000000','0.266100000000000','15.458007034611397','16.532860417645065','62.13025335454741','62.130253354547413','test'),('2019-03-05 11:59:59','2019-03-14 15:59:59','ICXUSDT','4h','0.274700000000000','0.324800000000000','15.726720380369814','18.594971894954917','57.25052923323558','57.250529233235582','test'),('2019-03-18 23:59:59','2019-03-21 15:59:59','ICXUSDT','4h','0.327100000000000','0.318600000000000','16.443783259016090','16.016476142838663','50.271425432638615','50.271425432638615','test'),('2019-03-24 15:59:59','2019-03-25 07:59:59','ICXUSDT','4h','0.342100000000000','0.338100000000000','16.443783259016090','16.251514527545574','48.06718286762961','48.067182867629612','test'),('2019-03-27 07:59:59','2019-03-27 11:59:59','ICXUSDT','4h','0.327000000000000','0.330600000000000','16.443783259016090','16.624815735262136','50.286798957235746','50.286798957235746','test'),('2019-03-28 15:59:59','2019-03-28 19:59:59','ICXUSDT','4h','0.325500000000000','0.322900000000000','16.443783259016090','16.312435067085396','50.51853535796034','50.518535357960339','test'),('2019-03-29 03:59:59','2019-03-29 07:59:59','ICXUSDT','4h','0.325700000000000','0.326100000000000','16.443783259016090','16.463978264553720','50.48751384407765','50.487513844077647','test'),('2019-04-20 03:59:59','2019-04-20 15:59:59','ICXUSDT','4h','0.381200000000000','0.378500000000000','16.443783259016090','16.327313650413405','43.136892075068445','43.136892075068445','test'),('2019-04-22 11:59:59','2019-04-23 23:59:59','ICXUSDT','4h','0.391700000000000','0.376600000000000','16.443783259016090','15.809876883700433','41.980554656666044','41.980554656666044','test'),('2019-04-24 23:59:59','2019-04-25 07:59:59','ICXUSDT','4h','0.386700000000000','0.381900000000000','16.443783259016090','16.239671131673767','42.52335986298446','42.523359862984456','test'),('2019-05-11 11:59:59','2019-05-12 03:59:59','ICXUSDT','4h','0.340600000000000','0.345400000000000','16.443783259016090','16.675521836947027','48.27887040227859','48.278870402278592','test'),('2019-05-13 07:59:59','2019-05-13 11:59:59','ICXUSDT','4h','0.334500000000000','0.339900000000000','16.443783259016090','16.709243437188544','49.159292254158714','49.159292254158714','test'),('2019-05-17 19:59:59','2019-05-17 23:59:59','ICXUSDT','4h','0.351600000000000','0.373500000000000','16.443783259016090','17.468012079756850','46.7684393032312','46.768439303231197','test'),('2019-05-23 15:59:59','2019-05-25 19:59:59','ICXUSDT','4h','0.377800000000000','0.371200000000000','16.448093985963219','16.160753011089323','43.53651134452943','43.536511344529430','test'),('2019-05-26 23:59:59','2019-05-28 15:59:59','ICXUSDT','4h','0.378600000000000','0.390900000000000','16.448093985963219','16.982461540182314','43.44451660317807','43.444516603178073','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','ICXUSDT','4h','0.390800000000000','0.398700000000000','16.509850630799519','16.843596331882726','42.24629127635497','42.246291276354967','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','ICXUSDT','4h','0.390900000000000','0.387200000000000','16.593287056070320','16.436226012050209','42.44893081624538','42.448930816245380','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','ICXUSDT','4h','0.385900000000000','0.377300000000000','16.593287056070320','16.223496258759607','42.99892991985053','42.998929919850532','test'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ICXUSDT','4h','0.378800000000000','0.372400000000000','16.593287056070320','16.312935849209573','43.80487607199134','43.804876071991337','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ICXUSDT','4h','0.380200000000000','0.366800000000000','16.593287056070320','16.008463156671734','43.64357458198401','43.643574581984012','test'),('2019-06-12 03:59:59','2019-06-14 03:59:59','ICXUSDT','4h','0.384700000000000','0.382500000000000','16.593287056070320','16.498394330509225','43.13305707322672','43.133057073226723','test'),('2019-06-26 07:59:59','2019-06-26 11:59:59','ICXUSDT','4h','0.376400000000000','0.358600000000000','16.593287056070320','15.808588571484632','44.08418452728565','44.084184527285650','test'),('2019-07-07 07:59:59','2019-07-09 03:59:59','ICXUSDT','4h','0.328000000000000','0.325300000000000','16.593287056070320','16.456695973596570','50.589289805092434','50.589289805092434','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','ICXUSDT','4h','0.330700000000000','0.330100000000000','16.593287056070320','16.563181303927465','50.17625357142522','50.176253571425221','test'),('2019-07-25 15:59:59','2019-07-25 19:59:59','ICXUSDT','4h','0.278300000000000','0.272000000000000','16.593287056070320','16.217657489224315','59.623740769207046','59.623740769207046','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','ICXUSDT','4h','0.277800000000000','0.269400000000000','16.593287056070320','16.091546194763659','59.73105491745976','59.731054917459758','test'),('2019-07-26 11:59:59','2019-07-27 11:59:59','ICXUSDT','4h','0.280000000000000','0.263100000000000','16.593287056070320','15.591763658757502','59.26173948596542','59.261739485965421','test'),('2019-08-22 15:59:59','2019-08-28 03:59:59','ICXUSDT','4h','0.241000000000000','0.217500000000000','16.593287056070320','14.975269438569688','68.85181351066522','68.851813510665224','test'),('2019-09-02 07:59:59','2019-09-02 15:59:59','ICXUSDT','4h','0.215800000000000','0.215100000000000','16.593287056070320','16.539462677297156','76.89196967595144','76.891969675951444','test'),('2019-09-03 07:59:59','2019-09-03 11:59:59','ICXUSDT','4h','0.215900000000000','0.211700000000000','16.593287056070320','16.270490364845237','76.8563550535911','76.856355053591102','test'),('2019-09-09 23:59:59','2019-09-10 11:59:59','ICXUSDT','4h','0.208500000000000','0.204200000000000','16.593287056070320','16.251075380573425','79.584110580673','79.584110580672998','test'),('2019-09-12 15:59:59','2019-09-12 19:59:59','ICXUSDT','4h','0.210500000000000','0.206000000000000','16.593287056070320','16.238561204515371','78.82796701221055','78.827967012210550','test'),('2019-09-17 15:59:59','2019-09-19 03:59:59','ICXUSDT','4h','0.203300000000000','0.204800000000000','16.593287056070320','16.715716621166756','81.6197100642908','81.619710064290800','test'),('2019-10-05 07:59:59','2019-10-05 11:59:59','ICXUSDT','4h','0.173600000000000','0.172000000000000','16.593287056070320','16.440353534816214','95.58345078381521','95.583450783815209','test'),('2019-10-07 23:59:59','2019-10-08 11:59:59','ICXUSDT','4h','0.172000000000000','0.172500000000000','16.593287056070320','16.641523355651920','96.47259916319955','96.472599163199547','test'),('2019-10-26 03:59:59','2019-10-26 11:59:59','ICXUSDT','4h','0.158300000000000','0.149000000000000','16.593287056070320','15.618444544248121','104.82177546475249','104.821775464752491','test'),('2019-10-27 15:59:59','2019-10-31 11:59:59','ICXUSDT','4h','0.161100000000000','0.161700000000000','16.593287056070320','16.655087007862019','102.99991965282632','102.999919652826321','test'),('2019-11-17 19:59:59','2019-11-18 15:59:59','ICXUSDT','4h','0.166500000000000','0.161700000000000','16.593287056070320','16.114922023823247','99.65938171814005','99.659381718140054','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','ICXUSDT','4h','0.162300000000000','0.160000000000000','16.593287056070320','16.358138810666983','102.23836756666864','102.238367566668643','test'),('2019-11-29 15:59:59','2019-11-29 19:59:59','ICXUSDT','4h','0.141300000000000','0.138600000000000','16.593287056070320','16.276217876654961','117.43302941309497','117.433029413094971','test'),('2019-12-07 11:59:59','2019-12-07 15:59:59','ICXUSDT','4h','0.135300000000000','0.135200000000000','16.593287056070320','16.581022985814538','122.64070255779986','122.640702557799855','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','ICXUSDT','4h','0.135600000000000','0.136200000000000','16.593287056070320','16.666708680212224','122.36937356984012','122.369373569840121','test'),('2019-12-12 11:59:59','2019-12-12 15:59:59','ICXUSDT','4h','0.133400000000000','0.131600000000000','16.593287056070320','16.369389629526644','124.38745919093195','124.387459190931949','test'),('2019-12-12 19:59:59','2019-12-12 23:59:59','ICXUSDT','4h','0.132900000000000','0.132400000000000','16.593287056070320','16.530859339531304','124.85543307803101','124.855433078031012','test'),('2019-12-13 03:59:59','2019-12-13 07:59:59','ICXUSDT','4h','0.132800000000000','0.134400000000000','16.593287056070320','16.793206177227791','124.94945072342108','124.949450723421080','test'),('2019-12-14 03:59:59','2019-12-14 07:59:59','ICXUSDT','4h','0.133000000000000','0.133100000000000','16.593287056070320','16.605763211751576','124.7615568125588','124.761556812558794','test'),('2019-12-22 23:59:59','2019-12-23 07:59:59','ICXUSDT','4h','0.124700000000000','0.122200000000000','16.593287056070320','16.260622921024805','133.06565401820626','133.065654018206260','test'),('2019-12-26 19:59:59','2019-12-26 23:59:59','ICXUSDT','4h','0.122000000000000','0.119500000000000','16.593287056070320','16.253260681970520','136.01054963992067','136.010549639920669','test'),('2019-12-28 19:59:59','2019-12-28 23:59:59','ICXUSDT','4h','0.120800000000000','0.118000000000000','16.593287056070320','16.208674442187892','137.36164781515166','137.361647815151656','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 11:13:56
