-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-02 03:59:59','AMBETH','4h','0.000535880000000','0.000518000000000','0.072144500000000','0.069737349779801','134.62808837799508','134.628088377995084','test'),('2019-01-07 19:59:59','2019-01-08 03:59:59','AMBETH','4h','0.000503280000000','0.000497410000000','0.072144500000000','0.071303043524479','143.34863296773167','143.348632967731675','test'),('2019-01-08 15:59:59','2019-01-08 19:59:59','AMBETH','4h','0.000501410000000','0.000494110000000','0.072144500000000','0.071094152280569','143.88324923715123','143.883249237151233','test'),('2019-01-09 07:59:59','2019-01-10 19:59:59','AMBETH','4h','0.000507680000000','0.000506700000000','0.072144500000000','0.072005235876930','142.10624803025527','142.106248030255273','test'),('2019-01-14 23:59:59','2019-01-20 15:59:59','AMBETH','4h','0.000522990000000','0.000551260000000','0.072144500000000','0.076044239985468','137.94623224153426','137.946232241534261','test'),('2019-03-01 11:59:59','2019-03-02 03:59:59','AMBETH','4h','0.000385690000000','0.000390360000000','0.072144500000000','0.073018037854235','187.05307371204853','187.053073712048530','test'),('2019-03-08 15:59:59','2019-03-09 03:59:59','AMBETH','4h','0.000395600000000','0.000415440000000','0.072228264825371','0.075850632808524','182.57903140892444','182.579031408924436','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','AMBETH','4h','0.000427200000000','0.000425230000000','0.073133856821159','0.072796605655575','171.1934850682555','171.193485068255512','test'),('2019-03-18 19:59:59','2019-03-18 23:59:59','AMBETH','4h','0.000429650000000','0.000425560000000','0.073133856821159','0.072437668122454','170.21728574690795','170.217285746907947','test'),('2019-03-19 11:59:59','2019-03-19 15:59:59','AMBETH','4h','0.000428070000000','0.000425620000000','0.073133856821159','0.072715285210881','170.84555521563996','170.845555215639962','test'),('2019-03-19 23:59:59','2019-03-20 03:59:59','AMBETH','4h','0.000426000000000','0.000421420000000','0.073133856821159','0.072347582022471','171.67572023746243','171.675720237462428','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','AMBETH','4h','0.000434140000000','0.000407180000000','0.073133856821159','0.068592260147509','168.45684991283687','168.456849912836873','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','AMBETH','4h','0.000424410000000','0.000439580000000','0.073133856821159','0.075747934265086','172.31888226280955','172.318882262809552','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','AMBETH','4h','0.000477540000000','0.000422120000000','0.073133856821159','0.064646445619943','153.1470804983017','153.147080498301705','test'),('2019-05-18 11:59:59','2019-05-19 03:59:59','AMBETH','4h','0.000190120000000','0.000191890000000','0.073133856821159','0.073814726411804','384.6720851102409','384.672085110240914','test'),('2019-05-20 11:59:59','2019-05-20 15:59:59','AMBETH','4h','0.000194630000000','0.000186950000000','0.073133856821159','0.070248032331684','375.75839706704517','375.758397067045166','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','AMBETH','4h','0.000195190000000','0.000187070000000','0.073133856821159','0.070091452408086','374.68034643761973','374.680346437619733','test'),('2019-05-21 23:59:59','2019-05-22 03:59:59','AMBETH','4h','0.000191450000000','0.000189260000000','0.073133856821159','0.072297277315083','381.99977446413686','381.999774464136863','test'),('2019-05-22 19:59:59','2019-05-25 11:59:59','AMBETH','4h','0.000200990000000','0.000189690000000','0.073133856821159','0.069022146874997','363.8681368284939','363.868136828493903','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','AMBETH','4h','0.000202770000000','0.000194880000000','0.073133856821159','0.070288139356450','360.6739498996844','360.673949899684374','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','AMBETH','4h','0.000199430000000','0.000186260000000','0.073133856821159','0.068304227907081','366.7144202033746','366.714420203374573','test'),('2019-06-02 19:59:59','2019-06-03 07:59:59','AMBETH','4h','0.000184440000000','0.000180420000000','0.073133856821159','0.071539852785044','396.51841694404146','396.518416944041462','test'),('2019-06-07 07:59:59','2019-06-09 15:59:59','AMBETH','4h','0.000183200000000','0.000186840000000','0.073133856821159','0.074586953102977','399.202275224667','399.202275224667005','test'),('2019-06-10 07:59:59','2019-06-12 07:59:59','AMBETH','4h','0.000190790000000','0.000185750000000','0.073133856821159','0.071201917839144','383.32122659027726','383.321226590277263','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','AMBETH','4h','0.000188060000000','0.000181660000000','0.073133856821159','0.070644987930085','388.8857642303467','388.885764230346695','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','AMBETH','4h','0.000190650000000','0.000180240000000','0.073133856821159','0.069140552601341','383.60271083744556','383.602710837445557','test'),('2019-07-07 07:59:59','2019-07-07 19:59:59','AMBETH','4h','0.000139750000000','0.000132030000000','0.073133856821159','0.069093832673328','523.3191901335169','523.319190133516940','test'),('2019-07-11 23:59:59','2019-07-12 07:59:59','AMBETH','4h','0.000132800000000','0.000120780000000','0.073133856821159','0.066514361648039','550.706753171378','550.706753171377954','test'),('2019-07-13 03:59:59','2019-07-13 07:59:59','AMBETH','4h','0.000127170000000','0.000126200000000','0.073133856821159','0.072576022102935','575.0873383750807','575.087338375080662','test'),('2019-07-13 23:59:59','2019-07-14 03:59:59','AMBETH','4h','0.000129770000000','0.000126470000000','0.073133856821159','0.071274091640379','563.5652062969792','563.565206296979227','test'),('2019-07-19 03:59:59','2019-07-20 03:59:59','AMBETH','4h','0.000134160000000','0.000131980000000','0.073133856821159','0.071945486160231','545.1241563890802','545.124156389080213','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','AMBETH','4h','0.000132770000000','0.000132850000000','0.073133856821159','0.073177923316193','550.831187927687','550.831187927686983','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','AMBETH','4h','0.000133290000000','0.000132270000000','0.073133856821159','0.072574200928312','548.6822478892566','548.682247889256587','test'),('2019-07-26 03:59:59','2019-07-27 07:59:59','AMBETH','4h','0.000133300000000','0.000135010000000','0.073133856821159','0.074072033078955','548.6410864303001','548.641086430300106','test'),('2019-08-06 03:59:59','2019-08-06 07:59:59','AMBETH','4h','0.000128310000000','0.000127000000000','0.073133856821159','0.072387185849016','569.9778413308316','569.977841330831552','test'),('2019-08-06 19:59:59','2019-08-06 23:59:59','AMBETH','4h','0.000129180000000','0.000126080000000','0.073133856821159','0.071378825421983','566.139161024609','566.139161024609052','test'),('2019-08-07 03:59:59','2019-08-07 07:59:59','AMBETH','4h','0.000130900000000','0.000125000000000','0.073133856821159','0.069837525612260','558.7002048980825','558.700204898082461','test'),('2019-08-12 11:59:59','2019-08-13 19:59:59','AMBETH','4h','0.000131500000000','0.000129180000000','0.073133856821159','0.071843586495493','556.1510024422738','556.151002442273807','test'),('2019-08-14 19:59:59','2019-08-15 15:59:59','AMBETH','4h','0.000131120000000','0.000127490000000','0.073133856821159','0.071109177899097','557.7627884469111','557.762788446911145','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','AMBETH','4h','0.000128090000000','0.000123840000000','0.073133856821159','0.070707290410901','570.9568024136076','570.956802413607647','test'),('2019-08-22 23:59:59','2019-08-23 11:59:59','AMBETH','4h','0.000124860000000','0.000126250000000','0.073133856821159','0.073948017168599','585.7268686621736','585.726868662173615','test'),('2019-08-24 07:59:59','2019-08-25 15:59:59','AMBETH','4h','0.000127620000000','0.000128770000000','0.073133856821159','0.073792875277078','573.0595268857468','573.059526885746777','test'),('2019-08-26 07:59:59','2019-08-26 15:59:59','AMBETH','4h','0.000128930000000','0.000128270000000','0.073133856821159','0.072759480450245','567.2369256275421','567.236925627542064','test'),('2019-08-30 03:59:59','2019-08-30 07:59:59','AMBETH','4h','0.000126730000000','0.000124800000000','0.073133856821159','0.072020084678297','577.0840118453326','577.084011845332611','test'),('2019-09-18 15:59:59','2019-09-18 23:59:59','AMBETH','4h','0.000096320000000','0.000094780000000','0.073133856821159','0.071964565505704','759.2800749705045','759.280074970504529','test'),('2019-09-21 19:59:59','2019-09-23 23:59:59','AMBETH','4h','0.000097030000000','0.000097650000000','0.073133856821159','0.073601165810432','753.7241762460992','753.724176246099205','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','AMBETH','4h','0.000097460000000','0.000089040000000','0.073133856821159','0.066815499808701','750.3986950662733','750.398695066273262','test'),('2019-09-27 07:59:59','2019-09-27 15:59:59','AMBETH','4h','0.000099990000000','0.000096720000000','0.073133856821159','0.070742140531478','731.4117093825282','731.411709382528215','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','AMBETH','4h','0.000097610000000','0.000096150000000','0.048755904547439','0.048026638891878','499.49702435651403','499.497024356514032','test'),('2019-10-28 19:59:59','2019-10-30 03:59:59','AMBETH','4h','0.000204090000000','0.000173690000000','0.054479363084227','0.046364449870642','266.9379346573889','266.937934657388894','test'),('2019-11-03 11:59:59','2019-11-03 19:59:59','AMBETH','4h','0.000182590000000','0.000178390000000','0.054479363084227','0.053226209434226','298.36991666699714','298.369916666997142','test'),('2019-11-14 03:59:59','2019-11-14 11:59:59','AMBETH','4h','0.000166220000000','0.000165910000000','0.054479363084227','0.054377759170401','327.7545607281134','327.754560728113404','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','AMBETH','4h','0.000161270000000','0.000160300000000','0.054479363084227','0.054151682906936','337.81461576379365','337.814615763793654','test'),('2019-11-16 23:59:59','2019-11-17 03:59:59','AMBETH','4h','0.000161050000000','0.000164080000000','0.054479363084227','0.055504339614157','338.27608248511024','338.276082485110237','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','AMBETH','4h','0.000152880000000','0.000148150000000','0.054479363084227','0.052793809791524','356.35376167076794','356.353761670767938','test'),('2019-11-25 11:59:59','2019-11-25 23:59:59','AMBETH','4h','0.000155650000000','0.000158770000000','0.054479363084227','0.055571400429699','350.01196970271127','350.011969702711269','test'),('2019-11-28 03:59:59','2019-11-28 15:59:59','AMBETH','4h','0.000155100000000','0.000154090000000','0.054479363084227','0.054124597405858','351.25314690023856','351.253146900238562','test'),('2019-11-29 07:59:59','2019-11-29 15:59:59','AMBETH','4h','0.000157690000000','0.000153100000000','0.054479363084227','0.052893591782581','345.4839437137866','345.483943713786573','test'),('2019-11-29 19:59:59','2019-11-30 03:59:59','AMBETH','4h','0.000156580000000','0.000155470000000','0.054479363084227','0.054093157355376','347.9330890549687','347.933089054968718','test'),('2019-12-02 15:59:59','2019-12-03 03:59:59','AMBETH','4h','0.000159210000000','0.000154310000000','0.054479363084227','0.052802653837869','342.18556048129517','342.185560481295170','test'),('2019-12-08 11:59:59','2019-12-08 19:59:59','AMBETH','4h','0.000153130000000','0.000147360000000','0.054479363084227','0.052426558767659','355.7719786078953','355.771978607895278','test'),('2019-12-27 19:59:59','2019-12-27 23:59:59','AMBETH','4h','0.000119640000000','0.000117390000000','0.054479363084227','0.053454801341169','455.36077469263626','455.360774692636255','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','AMBETH','4h','0.000119420000000','0.000116080000000','0.054479363084227','0.052955656228580','456.1996573792246','456.199657379224618','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:30:16
