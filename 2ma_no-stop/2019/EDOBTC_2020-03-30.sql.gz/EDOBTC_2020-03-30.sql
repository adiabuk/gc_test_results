-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 23:59:59','2019-01-05 03:59:59','EDOBTC','4h','0.000210300000000','0.000202900000000','0.001467500000000','0.001415861864004','6.978126485972421','6.978126485972421','test'),('2019-01-05 15:59:59','2019-01-13 19:59:59','EDOBTC','4h','0.000216600000000','0.000218700000000','0.001467500000000','0.001481727839335','6.775161588180979','6.775161588180979','test'),('2019-01-16 03:59:59','2019-01-16 07:59:59','EDOBTC','4h','0.000221800000000','0.000219400000000','0.001467500000000','0.001451620829576','6.616321009918846','6.616321009918846','test'),('2019-01-16 11:59:59','2019-01-16 15:59:59','EDOBTC','4h','0.000221600000000','0.000221400000000','0.001467500000000','0.001466175541516','6.622292418772564','6.622292418772564','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','EDOBTC','4h','0.000195900000000','0.000194700000000','0.001467500000000','0.001458510719755','7.491066870852476','7.491066870852476','test'),('2019-02-08 11:59:59','2019-02-08 19:59:59','EDOBTC','4h','0.000196600000000','0.000194900000000','0.001467500000000','0.001454810528993','7.46439471007121','7.464394710071210','test'),('2019-02-10 15:59:59','2019-02-10 19:59:59','EDOBTC','4h','0.000196400000000','0.000191200000000','0.001467500000000','0.001428645621181','7.471995926680244','7.471995926680244','test'),('2019-02-11 15:59:59','2019-02-11 23:59:59','EDOBTC','4h','0.000196500000000','0.000194700000000','0.001467500000000','0.001454057251908','7.468193384223919','7.468193384223919','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','EDOBTC','4h','0.000196000000000','0.000194000000000','0.001467500000000','0.001452525510204','7.487244897959184','7.487244897959184','test'),('2019-02-15 15:59:59','2019-02-15 23:59:59','EDOBTC','4h','0.000197400000000','0.000197400000000','0.001467500000000','0.001467500000000','7.434143870314084','7.434143870314084','test'),('2019-02-20 15:59:59','2019-02-20 19:59:59','EDOBTC','4h','0.000199900000000','0.000199600000000','0.001467500000000','0.001465297648824','7.341170585292646','7.341170585292646','test'),('2019-02-22 11:59:59','2019-02-23 19:59:59','EDOBTC','4h','0.000201900000000','0.000198800000000','0.001467500000000','0.001444967805844','7.268449727587915','7.268449727587915','test'),('2019-02-26 07:59:59','2019-02-26 11:59:59','EDOBTC','4h','0.000200000000000','0.000200000000000','0.001467500000000','0.001467500000000','7.3375','7.337500000000000','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','EDOBTC','4h','0.000200900000000','0.000201000000000','0.001467500000000','0.001468230462917','7.304629168740667','7.304629168740667','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','EDOBTC','4h','0.000200200000000','0.000201100000000','0.001467500000000','0.001474097152847','7.330169830169831','7.330169830169831','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','EDOBTC','4h','0.000201400000000','0.000200500000000','0.001467500000000','0.001460942154916','7.2864945382323745','7.286494538232374','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','EDOBTC','4h','0.000202200000000','0.000202000000000','0.001467500000000','0.001466048466864','7.257665677546983','7.257665677546983','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','EDOBTC','4h','0.000202000000000','0.000200700000000','0.001467500000000','0.001458055693069','7.264851485148515','7.264851485148515','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','EDOBTC','4h','0.000202400000000','0.000200600000000','0.001467500000000','0.001454449110672','7.250494071146246','7.250494071146246','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','EDOBTC','4h','0.000202400000000','0.000203000000000','0.001467500000000','0.001471850296443','7.250494071146246','7.250494071146246','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','EDOBTC','4h','0.000130500000000','0.000127700000000','0.001467500000000','0.001436013409962','11.245210727969349','11.245210727969349','test'),('2019-04-19 23:59:59','2019-04-20 07:59:59','EDOBTC','4h','0.000132800000000','0.000130400000000','0.001467500000000','0.001440978915663','11.050451807228916','11.050451807228916','test'),('2019-05-06 07:59:59','2019-05-06 15:59:59','EDOBTC','4h','0.000105500000000','0.000104100000000','0.001467500000000','0.001448026066351','13.909952606635072','13.909952606635072','test'),('2019-05-17 15:59:59','2019-05-18 03:59:59','EDOBTC','4h','0.000089000000000','0.000088200000000','0.001467500000000','0.001454308988764','16.48876404494382','16.488764044943821','test'),('2019-05-20 03:59:59','2019-05-20 23:59:59','EDOBTC','4h','0.000090800000000','0.000087400000000','0.001467500000000','0.001412549559471','16.161894273127754','16.161894273127754','test'),('2019-06-03 11:59:59','2019-06-03 19:59:59','EDOBTC','4h','0.000106800000000','0.000102000000000','0.001467500000000','0.001401544943820','13.74063670411985','13.740636704119851','test'),('2019-06-07 23:59:59','2019-06-13 11:59:59','EDOBTC','4h','0.000101000000000','0.000106200000000','0.001467500000000','0.001543054455446','14.52970297029703','14.529702970297031','test'),('2019-06-18 15:59:59','2019-06-19 23:59:59','EDOBTC','4h','0.000114900000000','0.000109300000000','0.001467500000000','0.001395976936466','12.771975630983464','12.771975630983464','test'),('2019-06-23 15:59:59','2019-06-23 19:59:59','EDOBTC','4h','0.000108300000000','0.000099900000000','0.001467500000000','0.001353677285319','13.550323176361958','13.550323176361958','test'),('2019-07-16 15:59:59','2019-07-18 15:59:59','EDOBTC','4h','0.000079400000000','0.000074800000000','0.001467500000000','0.001382481108312','18.4823677581864','18.482367758186399','test'),('2019-07-21 15:59:59','2019-07-22 11:59:59','EDOBTC','4h','0.000075000000000','0.000072900000000','0.001467500000000','0.001426410000000','19.56666666666667','19.566666666666670','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','EDOBTC','4h','0.000072600000000','0.000072100000000','0.001467500000000','0.001457393250689','20.213498622589533','20.213498622589533','test'),('2019-07-25 15:59:59','2019-07-25 19:59:59','EDOBTC','4h','0.000072600000000','0.000072500000000','0.001467500000000','0.001465478650138','20.213498622589533','20.213498622589533','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','EDOBTC','4h','0.000072300000000','0.000072400000000','0.001467500000000','0.001469529737206','20.29737206085754','20.297372060857541','test'),('2019-08-18 15:59:59','2019-08-19 07:59:59','EDOBTC','4h','0.000045300000000','0.000042100000000','0.001467500000000','0.001363835540839','32.39514348785872','32.395143487858718','test'),('2019-08-25 03:59:59','2019-08-25 07:59:59','EDOBTC','4h','0.000042600000000','0.000042500000000','0.001467500000000','0.001464055164319','34.448356807511736','34.448356807511736','test'),('2019-09-10 19:59:59','2019-09-11 23:59:59','EDOBTC','4h','0.000032100000000','0.000030600000000','0.001467500000000','0.001398925233645','45.716510903426794','45.716510903426794','test'),('2019-09-17 03:59:59','2019-09-24 19:59:59','EDOBTC','4h','0.000030300000000','0.000035560000000','0.001467500000000','0.001722254125413','48.43234323432343','48.432343234323433','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','EDOBTC','4h','0.000035760000000','0.000035940000000','0.001467500000000','0.001474886744966','41.03747203579418','41.037472035794181','test'),('2019-09-27 07:59:59','2019-10-08 03:59:59','EDOBTC','4h','0.000037330000000','0.000047110000000','0.001467500000000','0.001851966916689','39.31154567372087','39.311545673720872','test'),('2019-10-18 19:59:59','2019-10-19 03:59:59','EDOBTC','4h','0.000041230000000','0.000038630000000','0.001467500000000','0.001374958161533','35.59301479505214','35.593014795052142','test'),('2019-11-01 15:59:59','2019-11-01 19:59:59','EDOBTC','4h','0.000033600000000','0.000034500000000','0.001467500000000','0.001506808035714','43.67559523809524','43.675595238095241','test'),('2019-11-05 15:59:59','2019-11-05 19:59:59','EDOBTC','4h','0.000034280000000','0.000033900000000','0.001467500000000','0.001451232497083','42.80921820303384','42.809218203033844','test'),('2019-11-09 15:59:59','2019-11-09 19:59:59','EDOBTC','4h','0.000033470000000','0.000033280000000','0.001467500000000','0.001459169405438','43.84523453839259','43.845234538392589','test'),('2019-11-10 11:59:59','2019-11-10 19:59:59','EDOBTC','4h','0.000034120000000','0.000033660000000','0.001467500000000','0.001447715416178','43.009964830011725','43.009964830011725','test'),('2019-11-26 15:59:59','2019-11-27 07:59:59','EDOBTC','4h','0.000033460000000','0.000033440000000','0.001467500000000','0.001466622833234','43.85833831440526','43.858338314405259','test'),('2019-11-29 07:59:59','2019-11-29 19:59:59','EDOBTC','4h','0.000033690000000','0.000033140000000','0.001467500000000','0.001443542594242','43.55891956070051','43.558919560700510','test'),('2019-12-03 19:59:59','2019-12-03 23:59:59','EDOBTC','4h','0.000032880000000','0.000033020000000','0.001467500000000','0.001473748479319','44.631995133819956','44.631995133819956','test'),('2019-12-07 11:59:59','2019-12-08 07:59:59','EDOBTC','4h','0.000033070000000','0.000032250000000','0.001467500000000','0.001431112035077','44.37556697913517','44.375566979135172','test'),('2019-12-09 11:59:59','2019-12-09 19:59:59','EDOBTC','4h','0.000032700000000','0.000032410000000','0.001467500000000','0.001454485474006','44.87767584097859','44.877675840978590','test'),('2019-12-11 07:59:59','2019-12-11 15:59:59','EDOBTC','4h','0.000032310000000','0.000031890000000','0.001467500000000','0.001448423862581','45.419374806561436','45.419374806561436','test'),('2019-12-16 11:59:59','2019-12-17 11:59:59','EDOBTC','4h','0.000032500000000','0.000031510000000','0.001467500000000','0.001422797692308','45.15384615384616','45.153846153846160','test'),('2019-12-28 03:59:59','2019-12-28 07:59:59','EDOBTC','4h','0.000030790000000','0.000027600000000','0.001467500000000','0.001315459564794','47.661578434556674','47.661578434556674','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 14:24:05
