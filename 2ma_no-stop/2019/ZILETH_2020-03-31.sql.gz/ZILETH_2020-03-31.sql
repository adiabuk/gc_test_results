-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 03:59:59','2019-01-14 19:59:59','ZILETH','4h','0.000141260000000','0.000159480000000','0.072144500000000','0.081449843267733','510.72136485912495','510.721364859124947','test'),('2019-02-26 23:59:59','2019-02-27 03:59:59','ZILETH','4h','0.000130930000000','0.000129410000000','0.074470835816933','0.073606284755742','568.7835928888204','568.783592888820408','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','ZILETH','4h','0.000128910000000','0.000127050000000','0.074470835816933','0.073396320615479','577.6963448679932','577.696344867993162','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ZILETH','4h','0.000129220000000','0.000127930000000','0.074470835816933','0.073727395341745','576.3104458824718','576.310445882471754','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','ZILETH','4h','0.000128820000000','0.000126930000000','0.074470835816933','0.073378226907649','578.0999520022746','578.099952002274563','test'),('2019-03-08 15:59:59','2019-03-16 03:59:59','ZILETH','4h','0.000130100000000','0.000131000000000','0.074470835816933','0.074986006856404','572.4122660794236','572.412266079423603','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','ZILETH','4h','0.000131550000000','0.000131180000000','0.074470835816933','0.074261377745840','566.1028948455569','566.102894845556875','test'),('2019-03-19 23:59:59','2019-03-21 15:59:59','ZILETH','4h','0.000132210000000','0.000134110000000','0.074470835816933','0.075541061881922','563.2768763099085','563.276876309908516','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','ZILETH','4h','0.000138440000000','0.000137110000000','0.074470835816933','0.073755390774774','537.9286031272248','537.928603127224847','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ZILETH','4h','0.000139560000000','0.000138220000000','0.074470835816933','0.073755796264091','533.611606598832','533.611606598832054','test'),('2019-03-28 03:59:59','2019-03-28 07:59:59','ZILETH','4h','0.000139120000000','0.000137900000000','0.074470835816933','0.073817770695479','535.299279880197','535.299279880196991','test'),('2019-03-31 03:59:59','2019-04-01 23:59:59','ZILETH','4h','0.000138020000000','0.000145820000000','0.074470835816933','0.078679447028149','539.5655398995291','539.565539899529085','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','ZILETH','4h','0.000142310000000','0.000139040000000','0.074470835816933','0.072759644522425','523.3000900634742','523.300090063474158','test'),('2019-04-04 03:59:59','2019-04-07 23:59:59','ZILETH','4h','0.000140900000000','0.000141670000000','0.074470835816933','0.074877809156742','528.5368049462952','528.536804946295206','test'),('2019-04-18 03:59:59','2019-04-18 07:59:59','ZILETH','4h','0.000131220000000','0.000128780000000','0.074470835816933','0.073086070999121','567.5265646771301','567.526564677130068','test'),('2019-05-21 15:59:59','2019-05-21 23:59:59','ZILETH','4h','0.000083780000000','0.000082320000000','0.074470835816933','0.073173062836595','888.88560297127','888.885602971270032','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','ZILETH','4h','0.000080010000000','0.000076760000000','0.074470835816933','0.071445836236818','930.7691015739658','930.769101573965827','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','ZILETH','4h','0.000080010000000','0.000079550000000','0.074470835816933','0.074042682030209','930.7691015739658','930.769101573965827','test'),('2019-06-02 15:59:59','2019-06-03 07:59:59','ZILETH','4h','0.000078710000000','0.000077220000000','0.074470835816933','0.073061084255921','946.1419872561684','946.141987256168363','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','ZILETH','4h','0.000093060000000','0.000090840000000','0.074470835816933','0.072694291055343','800.2453881037289','800.245388103728942','test'),('2019-06-16 23:59:59','2019-06-18 11:59:59','ZILETH','4h','0.000093620000000','0.000086980000000','0.074470835816933','0.069188990593429','795.4586179975754','795.458617997575402','test'),('2019-07-30 23:59:59','2019-07-31 15:59:59','ZILETH','4h','0.000051330000000','0.000049900000000','0.074470835816933','0.072396156385446','1450.8247772634525','1450.824777263452461','test'),('2019-08-11 15:59:59','2019-08-11 19:59:59','ZILETH','4h','0.000043510000000','0.000042320000000','0.074470835816933','0.072434055889970','1711.5797705569526','1711.579770556952553','test'),('2019-08-13 07:59:59','2019-08-13 15:59:59','ZILETH','4h','0.000043980000000','0.000042390000000','0.074470835816933','0.071778506827644','1693.2886725087085','1693.288672508708487','test'),('2019-08-24 07:59:59','2019-08-27 15:59:59','ZILETH','4h','0.000042230000000','0.000041660000000','0.074470835816933','0.073465664696506','1763.4581060130952','1763.458106013095176','test'),('2019-08-29 19:59:59','2019-08-29 23:59:59','ZILETH','4h','0.000041930000000','0.000041560000000','0.074470835816933','0.073813687969276','1776.075263938302','1776.075263938301987','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','ZILETH','4h','0.000041780000000','0.000041210000000','0.074470835816933','0.073454838296214','1782.4517907355912','1782.451790735591203','test'),('2019-08-30 23:59:59','2019-08-31 23:59:59','ZILETH','4h','0.000041670000000','0.000040320000000','0.074470835816933','0.072058173749430','1787.1570870394291','1787.157087039429143','test'),('2019-10-04 03:59:59','2019-10-04 07:59:59','ZILETH','4h','0.000029990000000','0.000029740000000','0.074470835816933','0.073850038586048','2483.1889235389467','2483.188923538946710','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','ZILETH','4h','0.000030490000000','0.000030000000000','0.074470835816933','0.073274026713939','2442.467557131289','2442.467557131289141','test'),('2019-10-11 19:59:59','2019-10-12 11:59:59','ZILETH','4h','0.000032390000000','0.000031220000000','0.074470835816933','0.071780780926355','2299.192214168972','2299.192214168971987','test'),('2019-10-21 23:59:59','2019-10-22 11:59:59','ZILETH','4h','0.000030710000000','0.000030500000000','0.074470835816933','0.073961592068266','2424.9702317464344','2424.970231746434365','test'),('2019-10-23 03:59:59','2019-10-23 15:59:59','ZILETH','4h','0.000030660000000','0.000029640000000','0.074470835816933','0.071993332472730','2428.924847258089','2428.924847258088903','test'),('2019-10-27 15:59:59','2019-10-29 11:59:59','ZILETH','4h','0.000031190000000','0.000030270000000','0.074470835816933','0.072274196863692','2387.6510361312285','2387.651036131228466','test'),('2019-10-30 19:59:59','2019-10-31 03:59:59','ZILETH','4h','0.000030540000000','0.000030190000000','0.074470835816933','0.073617371752233','2438.468756284643','2438.468756284642950','test'),('2019-11-14 19:59:59','2019-11-18 19:59:59','ZILETH','4h','0.000032200000000','0.000034010000000','0.074470835816933','0.078656929383040','2312.7588763022677','2312.758876302267709','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','ZILETH','4h','0.000033840000000','0.000033280000000','0.074470835816933','0.073238457919253','2200.6748172852544','2200.674817285254449','test'),('2019-11-25 11:59:59','2019-11-25 15:59:59','ZILETH','4h','0.000033160000000','0.000033010000000','0.074470835816933','0.074133965329221','2245.80325141535','2245.803251415350132','test'),('2019-12-02 19:59:59','2019-12-10 03:59:59','ZILETH','4h','0.000034080000000','0.000039080000000','0.074470835816933','0.085396721353455','2185.1771073043724','2185.177107304372385','test'),('2019-12-11 11:59:59','2019-12-11 15:59:59','ZILETH','4h','0.000039450000000','0.000038510000000','0.074470835816933','0.072696372301903','1887.727143648492','1887.727143648492074','test'),('2019-12-11 23:59:59','2019-12-12 03:59:59','ZILETH','4h','0.000039430000000','0.000038720000000','0.074470835816933','0.073129869714219','1888.6846517101953','1888.684651710195340','test'),('2019-12-18 15:59:59','2019-12-18 19:59:59','ZILETH','4h','0.000037680000000','0.000038390000000','0.074470835816933','0.075874081396286','1976.4022244408973','1976.402224440897271','test'),('2019-12-28 03:59:59','2019-12-28 07:59:59','ZILETH','4h','0.000037690000000','0.000037650000000','0.074470835816933','0.074391800703304','1975.8778407252057','1975.877840725205715','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  6:31:13
