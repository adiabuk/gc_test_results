-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-02 23:59:59','QLCBNB','4h','0.004330000000000','0.004291000000000','0.711908500000000','0.705496391108545','164.41304849884528','164.413048498845285','test'),('2019-01-03 07:59:59','2019-01-03 19:59:59','QLCBNB','4h','0.004356000000000','0.004357000000000','0.711908500000000','0.712071931703398','163.43170339761252','163.431703397612523','test'),('2019-01-05 15:59:59','2019-01-05 19:59:59','QLCBNB','4h','0.004359000000000','0.004337000000000','0.711908500000000','0.708315477058958','163.31922459279653','163.319224592796530','test'),('2019-01-09 15:59:59','2019-01-10 07:59:59','QLCBNB','4h','0.004537000000000','0.004533000000000','0.711908500000000','0.711280853096760','156.91172581000663','156.911725810006629','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','QLCBNB','4h','0.004767000000000','0.005425000000000','0.711908500000000','0.810174871512482','149.34099014054962','149.340990140549621','test'),('2019-01-30 07:59:59','2019-01-30 15:59:59','QLCBNB','4h','0.003889000000000','0.003718000000000','0.733857756120036','0.701589904153843','188.70088869118945','188.700888691189448','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','QLCBNB','4h','0.002625000000000','0.002565000000000','0.733857756120036','0.717083864551578','279.5648594742994','279.564859474299396','test'),('2019-02-24 03:59:59','2019-02-24 15:59:59','QLCBNB','4h','0.002578000000000','0.002486000000000','0.733857756120036','0.707668883519942','284.66165869667805','284.661658696678046','test'),('2019-02-26 03:59:59','2019-02-27 23:59:59','QLCBNB','4h','0.002578000000000','0.002531000000000','0.733857756120036','0.720478658161292','284.66165869667805','284.661658696678046','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','QLCBNB','4h','0.002591000000000','0.002510000000000','0.733857756120036','0.710915850197333','283.23340645312084','283.233406453120836','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','QLCBNB','4h','0.002594000000000','0.002447000000000','0.733857756120036','0.692270597234282','282.90584276022975','282.905842760229746','test'),('2019-03-02 07:59:59','2019-03-03 03:59:59','QLCBNB','4h','0.002672000000000','0.002565000000000','0.733857756120036','0.704470488191576','274.64736381737873','274.647363817378732','test'),('2019-03-03 11:59:59','2019-03-04 23:59:59','QLCBNB','4h','0.002694000000000','0.002543000000000','0.733857756120036','0.692724674763642','272.40451229399997','272.404512293999971','test'),('2019-03-10 19:59:59','2019-03-10 23:59:59','QLCBNB','4h','0.002469000000000','0.002433000000000','0.733857756120036','0.723157521522903','297.22873880924914','297.228738809249137','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','QLCBNB','4h','0.002379000000000','0.002266000000000','0.733857756120036','0.699000283887348','308.4732055990063','308.473205599006292','test'),('2019-03-15 11:59:59','2019-03-16 11:59:59','QLCBNB','4h','0.002388000000000','0.002238000000000','0.733857756120036','0.687761163398928','307.3106181407186','307.310618140718589','test'),('2019-03-20 07:59:59','2019-03-24 11:59:59','QLCBNB','4h','0.002335000000000','0.002117000000000','0.733857756120036','0.665343413150371','314.28597692506895','314.285976925068951','test'),('2019-03-26 03:59:59','2019-03-28 11:59:59','QLCBNB','4h','0.002500000000000','0.002371000000000','0.733857756120036','0.695990695904242','293.5431024480144','293.543102448014395','test'),('2019-05-06 07:59:59','2019-05-10 03:59:59','QLCBNB','4h','0.001496000000000','0.001548000000000','0.733857756120036','0.759366180798005','490.546628422484','490.546628422483991','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','QLCBNB','4h','0.001420000000000','0.001308000000000','0.733857756120036','0.675976017609160','516.8012367042506','516.801236704250641','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','QLCBNB','4h','0.001451000000000','0.001383000000000','0.733857756120036','0.699466076301867','505.7599973260069','505.759997326006896','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','QLCBNB','4h','0.001298000000000','0.001283000000000','0.733857756120036','0.725377119493071','565.3757751309985','565.375775130998477','test'),('2019-06-06 15:59:59','2019-06-06 19:59:59','QLCBNB','4h','0.001309000000000','0.001303000000000','0.733857756120036','0.730494007810853','560.6247181971245','560.624718197124480','test'),('2019-06-10 15:59:59','2019-06-11 03:59:59','QLCBNB','4h','0.001311000000000','0.001318000000000','0.733857756120036','0.737776142308320','559.769455469135','559.769455469134982','test'),('2019-06-26 03:59:59','2019-06-26 07:59:59','QLCBNB','4h','0.001097000000000','0.001078000000000','0.733857756120036','0.721147366542752','668.967872488638','668.967872488638022','test'),('2019-07-01 11:59:59','2019-07-01 15:59:59','QLCBNB','4h','0.001024000000000','0.000995000000000','0.733857756120036','0.713074675136168','716.6579649609727','716.657964960972663','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','QLCBNB','4h','0.001024000000000','0.001019000000000','0.733857756120036','0.730274466295231','716.6579649609727','716.657964960972663','test'),('2019-07-07 03:59:59','2019-07-07 07:59:59','QLCBNB','4h','0.000974000000000','0.000963000000000','0.733857756120036','0.725569834849687','753.4473882135893','753.447388213589306','test'),('2019-07-07 11:59:59','2019-07-07 23:59:59','QLCBNB','4h','0.000972000000000','0.000965000000000','0.733857756120036','0.728572772279665','754.9976914815186','754.997691481518586','test'),('2019-07-26 23:59:59','2019-07-29 03:59:59','QLCBNB','4h','0.000806000000000','0.000792000000000','0.733857756120036','0.721110847204800','910.4934939454541','910.493493945454134','test'),('2019-07-30 23:59:59','2019-07-31 11:59:59','QLCBNB','4h','0.000792000000000','0.000785000000000','0.733857756120036','0.727371639588672','926.5880759091365','926.588075909136478','test'),('2019-08-20 15:59:59','2019-08-20 19:59:59','QLCBNB','4h','0.000520000000000','0.000506000000000','0.733857756120036','0.714100047301420','1411.264915615454','1411.264915615453901','test'),('2019-08-21 19:59:59','2019-08-28 19:59:59','QLCBNB','4h','0.000520000000000','0.000592000000000','0.733857756120036','0.835468830044349','1411.264915615454','1411.264915615453901','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','QLCBNB','4h','0.000643000000000','0.000622000000000','0.733857756120036','0.709890395500253','1141.3028866563545','1141.302886656354531','test'),('2019-09-03 23:59:59','2019-09-05 19:59:59','QLCBNB','4h','0.000659000000000','0.000605000000000','0.733857756120036','0.673723736650412','1113.5929531411775','1113.592953141177532','test'),('2019-09-07 23:59:59','2019-09-09 03:59:59','QLCBNB','4h','0.000657000000000','0.000624000000000','0.733857756120036','0.696997320881130','1116.982886027452','1116.982886027451968','test'),('2019-09-09 11:59:59','2019-09-12 11:59:59','QLCBNB','4h','0.000655000000000','0.000663000000000','0.733857756120036','0.742820904286387','1120.393520793948','1120.393520793948028','test'),('2019-09-25 11:59:59','2019-09-26 03:59:59','QLCBNB','4h','0.000851000000000','0.000819000000000','0.733857756120036','0.706262634855828','862.3475395065053','862.347539506505314','test'),('2019-10-09 23:59:59','2019-10-10 07:59:59','QLCBNB','4h','0.001075000000000','0.001013000000000','0.733857756120036','0.691532936697299','682.65837778608','682.658377786079996','test'),('2019-10-10 15:59:59','2019-10-11 03:59:59','QLCBNB','4h','0.001119000000000','0.001061000000000','0.733857756120036','0.695820446151348','655.8156891153137','655.815689115313717','test'),('2019-10-19 11:59:59','2019-10-20 15:59:59','QLCBNB','4h','0.001024000000000','0.000958000000000','0.733857756120036','0.686558330432612','716.6579649609727','716.657964960972663','test'),('2019-10-21 03:59:59','2019-10-21 15:59:59','QLCBNB','4h','0.000979000000000','0.000967000000000','0.489238504080024','0.483241709341556','499.7328948723432','499.732894872343195','test'),('2019-10-24 11:59:59','2019-10-24 15:59:59','QLCBNB','4h','0.000991000000000','0.000972000000000','0.544440934269237','0.534002611614226','549.3854028952946','549.385402895294646','test'),('2019-10-27 23:59:59','2019-10-28 03:59:59','QLCBNB','4h','0.000993000000000','0.000943000000000','0.544440934269237','0.517026989945509','548.2788864745589','548.278886474558931','test'),('2019-10-28 11:59:59','2019-10-28 19:59:59','QLCBNB','4h','0.000999000000000','0.000935000000000','0.544440934269237','0.509561835377114','544.9859201894263','544.985920189426338','test'),('2019-11-16 19:59:59','2019-11-17 03:59:59','QLCBNB','4h','0.000835000000000','0.000840000000000','0.544440934269237','0.547701059624143','652.0250709811221','652.025070981122099','test'),('2019-11-22 19:59:59','2019-11-23 15:59:59','QLCBNB','4h','0.000846000000000','0.000838000000000','0.544440934269237','0.539292556640213','643.5472036279398','643.547203627939780','test'),('2019-11-25 07:59:59','2019-11-27 19:59:59','QLCBNB','4h','0.000865000000000','0.000876000000000','0.544440934269237','0.551364460600985','629.4114847043203','629.411484704320287','test'),('2019-12-06 11:59:59','2019-12-10 03:59:59','QLCBNB','4h','0.000907000000000','0.000958000000000','0.544440934269237','0.575054481841157','600.2656386650904','600.265638665090364','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','QLCBNB','4h','0.000950000000000','0.000930000000000','0.544440934269237','0.532979019863569','573.0957202834073','573.095720283407331','test'),('2019-12-14 03:59:59','2019-12-14 07:59:59','QLCBNB','4h','0.000947000000000','0.000928000000000','0.544440934269237','0.533517620910086','574.9112294289725','574.911229428972547','test'),('2019-12-14 11:59:59','2019-12-14 15:59:59','QLCBNB','4h','0.000970000000000','0.000974000000000','0.544440934269237','0.546686051523956','561.2793136796257','561.279313679625716','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:20:52
