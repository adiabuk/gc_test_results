-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 19:59:59','2019-01-07 15:59:59','NEOETH','4h','0.055293000000000','0.054735000000000','0.072144500000000','0.071416439829635','1.3047673304034868','1.304767330403487','test'),('2019-02-01 03:59:59','2019-02-01 07:59:59','NEOETH','4h','0.064577000000000','0.065029000000000','0.072144500000000','0.072649467929758','1.117185685305914','1.117185685305914','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','NEOETH','4h','0.065563000000000','0.063672000000000','0.072144500000000','0.070063673169318','1.1003843631316443','1.100384363131644','test'),('2019-02-11 15:59:59','2019-02-11 19:59:59','NEOETH','4h','0.065539000000000','0.067092000000000','0.072144500000000','0.073854022704039','1.100787317475091','1.100787317475091','test'),('2019-02-15 11:59:59','2019-02-16 11:59:59','NEOETH','4h','0.066602000000000','0.065380000000000','0.072144500000000','0.070820807333113','1.0832182216750248','1.083218221675025','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','NEOETH','4h','0.069361000000000','0.065851000000000','0.072144500000000','0.068493641520451','1.0401306209541383','1.040130620954138','test'),('2019-02-23 23:59:59','2019-02-24 03:59:59','NEOETH','4h','0.064347000000000','0.061320000000000','0.072144500000000','0.068750691407525','1.121178920540196','1.121178920540196','test'),('2019-02-24 07:59:59','2019-03-04 07:59:59','NEOETH','4h','0.064102000000000','0.065534000000000','0.072144500000000','0.073756164597048','1.1254641040841158','1.125464104084116','test'),('2019-03-05 11:59:59','2019-03-05 15:59:59','NEOETH','4h','0.065350000000000','0.064878000000000','0.072144500000000','0.071623425723030','1.1039709257842387','1.103970925784239','test'),('2019-03-07 19:59:59','2019-03-10 07:59:59','NEOETH','4h','0.066514000000000','0.064946000000000','0.072144500000000','0.070443766680699','1.0846513515951528','1.084651351595153','test'),('2019-03-10 19:59:59','2019-03-10 23:59:59','NEOETH','4h','0.065221000000000','0.064817000000000','0.072144500000000','0.071697613598381','1.1061544594532435','1.106154459453244','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','NEOETH','4h','0.065011000000000','0.065299000000000','0.072144500000000','0.072464101544354','1.1097275845626124','1.109727584562612','test'),('2019-03-20 19:59:59','2019-03-21 07:59:59','NEOETH','4h','0.067352000000000','0.066700000000000','0.072144500000000','0.071446106277468','1.0711560161539375','1.071156016153938','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','NEOETH','4h','0.066642000000000','0.066408000000000','0.072144500000000','0.071891179076258','1.082568050178566','1.082568050178566','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOETH','4h','0.068287000000000','0.066649000000000','0.072144500000000','0.070413970162696','1.0564895221638086','1.056489522163809','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','NEOETH','4h','0.066790000000000','0.066220000000000','0.072144500000000','0.071528803563408','1.0801691870040424','1.080169187004042','test'),('2019-03-28 11:59:59','2019-03-28 15:59:59','NEOETH','4h','0.066849000000000','0.067160000000000','0.072144500000000','0.072480136127691','1.0792158446648417','1.079215844664842','test'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOETH','4h','0.062013000000000','0.061265000000000','0.072144500000000','0.071274293978682','1.1633770338477416','1.163377033847742','test'),('2019-05-29 15:59:59','2019-06-04 03:59:59','NEOETH','4h','0.049458000000000','0.049452000000000','0.072144500000000','0.072135747786000','1.458702333292895','1.458702333292895','test'),('2019-06-07 11:59:59','2019-06-08 15:59:59','NEOETH','4h','0.049239000000000','0.048535000000000','0.072144500000000','0.071113006102886','1.465190194764313','1.465190194764313','test'),('2019-06-14 23:59:59','2019-06-18 07:59:59','NEOETH','4h','0.051143000000000','0.050402000000000','0.072144500000000','0.071099213753593','1.4106427077019337','1.410642707701934','test'),('2019-06-18 11:59:59','2019-06-18 19:59:59','NEOETH','4h','0.050997000000000','0.050845000000000','0.072144500000000','0.071929468449124','1.4146812557601427','1.414681255760143','test'),('2019-06-22 15:59:59','2019-06-26 19:59:59','NEOETH','4h','0.055613000000000','0.054367000000000','0.072144500000000','0.070528114496610','1.2972596335389206','1.297259633538921','test'),('2019-07-01 19:59:59','2019-07-07 03:59:59','NEOETH','4h','0.056975000000000','0.058101000000000','0.072144500000000','0.073570295647214','1.2662483545414656','1.266248354541466','test'),('2019-07-18 15:59:59','2019-07-22 15:59:59','NEOETH','4h','0.056872000000000','0.055721000000000','0.072144500000000','0.070684408575397','1.2685416373610916','1.268541637361092','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','NEOETH','4h','0.055329000000000','0.054422000000000','0.072144500000000','0.070961846030111','1.3039183791501743','1.303918379150174','test'),('2019-08-04 03:59:59','2019-08-04 07:59:59','NEOETH','4h','0.054529000000000','0.054208000000000','0.072144500000000','0.071719801500119','1.3230482862330135','1.323048286233014','test'),('2019-08-04 15:59:59','2019-08-04 19:59:59','NEOETH','4h','0.054280000000000','0.053991000000000','0.072144500000000','0.071760385031319','1.329117538688283','1.329117538688283','test'),('2019-08-15 11:59:59','2019-08-18 15:59:59','NEOETH','4h','0.053035000000000','0.051410000000000','0.072144500000000','0.069933982181578','1.3603186574903365','1.360318657490337','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','NEOETH','4h','0.051397000000000','0.051195000000000','0.072144500000000','0.071860958373057','1.4036714205109249','1.403671420510925','test'),('2019-08-24 03:59:59','2019-08-24 11:59:59','NEOETH','4h','0.051344000000000','0.051819000000000','0.072144500000000','0.072811932173185','1.4051203645995638','1.405120364599564','test'),('2019-08-26 07:59:59','2019-08-27 03:59:59','NEOETH','4h','0.051734000000000','0.051339000000000','0.072144500000000','0.071593661528202','1.3945277767039084','1.394527776703908','test'),('2019-08-28 19:59:59','2019-08-29 07:59:59','NEOETH','4h','0.052827000000000','0.051203000000000','0.072144500000000','0.069926644206561','1.3656747496545327','1.365674749654533','test'),('2019-08-29 15:59:59','2019-08-29 19:59:59','NEOETH','4h','0.051705000000000','0.051592000000000','0.072144500000000','0.071986829977758','1.395309931341263','1.395309931341263','test'),('2019-09-03 23:59:59','2019-09-04 03:59:59','NEOETH','4h','0.051759000000000','0.051538000000000','0.072144500000000','0.071836458219827','1.393854208929848','1.393854208929848','test'),('2019-09-04 19:59:59','2019-09-04 23:59:59','NEOETH','4h','0.051775000000000','0.051908000000000','0.072144500000000','0.072329825321101','1.3934234669241912','1.393423466924191','test'),('2019-09-05 23:59:59','2019-09-06 07:59:59','NEOETH','4h','0.051794000000000','0.051856000000000','0.072144500000000','0.072230860563000','1.392912306444762','1.392912306444762','test'),('2019-09-07 03:59:59','2019-09-07 19:59:59','NEOETH','4h','0.051985000000000','0.051050000000000','0.072144500000000','0.070846912090026','1.3877945561219582','1.387794556121958','test'),('2019-10-16 03:59:59','2019-10-16 07:59:59','NEOETH','4h','0.040960000000000','0.040651000000000','0.072144500000000','0.071600245837402','1.76134033203125','1.761340332031250','test'),('2019-10-17 23:59:59','2019-10-18 19:59:59','NEOETH','4h','0.040991000000000','0.040720000000000','0.072144500000000','0.071667537752190','1.7600082945036715','1.760008294503671','test'),('2019-11-19 15:59:59','2019-11-21 07:59:59','NEOETH','4h','0.065387000000000','0.065796000000000','0.072144500000000','0.072595768608439','1.103346230902167','1.103346230902167','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','NEOETH','4h','0.065740000000000','0.065995000000000','0.072144500000000','0.072424342523578','1.097421661089139','1.097421661089139','test'),('2019-12-07 11:59:59','2019-12-07 19:59:59','NEOETH','4h','0.061760000000000','0.061219000000000','0.072144500000000','0.071512534739313','1.168142810880829','1.168142810880829','test'),('2019-12-13 07:59:59','2019-12-13 15:59:59','NEOETH','4h','0.060589000000000','0.062500000000000','0.072144500000000','0.074419964845104','1.1907194375216623','1.190719437521662','test'),('2020-01-01 15:59:59','2020-01-01 15:59:59','NEOETH','4h','0.067871000000000','0.067871000000000','0.072144500000000','0.072144500000000','1.0629650366135757','1.062965036613576','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:59:24
