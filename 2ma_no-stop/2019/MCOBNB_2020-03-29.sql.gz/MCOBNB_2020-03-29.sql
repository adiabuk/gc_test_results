-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 03:59:59','2019-01-03 11:59:59','MCOBNB','4h','0.389970000000000','0.388550000000000','0.711908500000000','0.709316223491551','1.8255468369361747','1.825546836936175','test'),('2019-01-04 23:59:59','2019-01-08 11:59:59','MCOBNB','4h','0.399080000000000','0.403850000000000','0.711908500000000','0.720417579745916','1.7838741605693096','1.783874160569310','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','MCOBNB','4h','0.404880000000000','0.400000000000000','0.713387700809367','0.704789271694692','1.7619731792367288','1.761973179236729','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','MCOBNB','4h','0.404130000000000','0.387880000000000','0.713387700809367','0.684702500160684','1.7652431168420235','1.765243116842024','test'),('2019-02-15 03:59:59','2019-02-15 23:59:59','MCOBNB','4h','0.269210000000000','0.283050000000000','0.713387700809367','0.750062734348989','2.6499301690478325','2.649930169047833','test'),('2019-02-20 15:59:59','2019-02-22 15:59:59','MCOBNB','4h','0.293740000000000','0.287190000000000','0.713387700809367','0.697480131393212','2.4286365520847246','2.428636552084725','test'),('2019-02-23 19:59:59','2019-02-24 07:59:59','MCOBNB','4h','0.281000000000000','0.276530000000000','0.713387700809367','0.702039504999339','2.538746266225505','2.538746266225505','test'),('2019-02-25 19:59:59','2019-02-27 19:59:59','MCOBNB','4h','0.278640000000000','0.282320000000000','0.713387700809367','0.722809416065534','2.5602487109150407','2.560248710915041','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','MCOBNB','4h','0.226460000000000','0.196810000000000','0.713387700809367','0.619985133782087','3.1501708946805924','3.150170894680592','test'),('2019-03-15 07:59:59','2019-03-16 11:59:59','MCOBNB','4h','0.236730000000000','0.206980000000000','0.713387700809367','0.623735843845405','3.0135077971079585','3.013507797107958','test'),('2019-03-17 11:59:59','2019-03-18 11:59:59','MCOBNB','4h','0.210090000000000','0.210900000000000','0.713387700809367','0.716138160315558','3.395629019988419','3.395629019988419','test'),('2019-03-23 11:59:59','2019-03-23 23:59:59','MCOBNB','4h','0.215920000000000','0.215060000000000','0.713387700809367','0.710546308521964','3.303944520236046','3.303944520236046','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','MCOBNB','4h','0.207500000000000','0.203150000000000','0.713387700809367','0.698432344189990','3.4380130159487567','3.438013015948757','test'),('2019-03-27 23:59:59','2019-03-30 19:59:59','MCOBNB','4h','0.211600000000000','0.206590000000000','0.713387700809367','0.696496999575648','3.3713974518401084','3.371397451840108','test'),('2019-04-06 19:59:59','2019-04-06 23:59:59','MCOBNB','4h','0.199830000000000','0.195570000000000','0.713387700809367','0.698179615909963','3.5699729810807534','3.569972981080753','test'),('2019-04-07 03:59:59','2019-04-07 07:59:59','MCOBNB','4h','0.200510000000000','0.196990000000000','0.713387700809367','0.700864012679852','3.5578659458848287','3.557865945884829','test'),('2019-04-07 15:59:59','2019-04-13 23:59:59','MCOBNB','4h','0.199910000000000','0.211540000000000','0.713387700809367','0.754889871588282','3.5685443490038864','3.568544349003886','test'),('2019-04-15 03:59:59','2019-04-15 11:59:59','MCOBNB','4h','0.215060000000000','0.208190000000000','0.713387700809367','0.690598834890273','3.317156611221831','3.317156611221831','test'),('2019-04-16 07:59:59','2019-04-16 11:59:59','MCOBNB','4h','0.215310000000000','0.213570000000000','0.713387700809367','0.707622550099190','3.313305005849087','3.313305005849087','test'),('2019-04-19 03:59:59','2019-04-19 11:59:59','MCOBNB','4h','0.219350000000000','0.213080000000000','0.713387700809367','0.692995902842306','3.2522803775216182','3.252280377521618','test'),('2019-04-21 11:59:59','2019-04-21 15:59:59','MCOBNB','4h','0.210730000000000','0.206960000000000','0.713387700809367','0.700625058413641','3.385316285338428','3.385316285338428','test'),('2019-04-21 23:59:59','2019-04-22 07:59:59','MCOBNB','4h','0.216050000000000','0.213450000000000','0.713387700809367','0.704802613921589','3.3019564952990836','3.301956495299084','test'),('2019-04-22 19:59:59','2019-04-22 23:59:59','MCOBNB','4h','0.211570000000000','0.209780000000000','0.713387700809367','0.707352043653585','3.371875506023382','3.371875506023382','test'),('2019-04-24 03:59:59','2019-04-24 07:59:59','MCOBNB','4h','0.211360000000000','0.209560000000000','0.713387700809367','0.707312294576131','3.375225685131373','3.375225685131373','test'),('2019-04-25 15:59:59','2019-04-25 23:59:59','MCOBNB','4h','0.217260000000000','0.196910000000000','0.713387700809367','0.646567118504890','3.283566698008685','3.283566698008685','test'),('2019-04-27 07:59:59','2019-04-27 15:59:59','MCOBNB','4h','0.210430000000000','0.208280000000000','0.713387700809367','0.706098894285867','3.3901425690698423','3.390142569069842','test'),('2019-04-29 19:59:59','2019-04-29 23:59:59','MCOBNB','4h','0.212280000000000','0.207080000000000','0.713387700809367','0.695912592253645','3.360597799177346','3.360597799177346','test'),('2019-05-04 07:59:59','2019-05-11 15:59:59','MCOBNB','4h','0.221500000000000','0.228180000000000','0.713387700809367','0.734902056752512','3.2207119675366456','3.220711967536646','test'),('2019-05-26 23:59:59','2019-05-27 03:59:59','MCOBNB','4h','0.176750000000000','0.199840000000000','0.713387700809367','0.806582167636458','4.036139749982275','4.036139749982275','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','MCOBNB','4h','0.194910000000000','0.191470000000000','0.713387700809367','0.700796998994251','3.66008773695227','3.660087736952270','test'),('2019-06-09 23:59:59','2019-06-10 03:59:59','MCOBNB','4h','0.194950000000000','0.192900000000000','0.713387700809367','0.705886060457178','3.6593367571652573','3.659336757165257','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','MCOBNB','4h','0.194080000000000','0.193640000000000','0.713387700809367','0.711770375024350','3.6757404204934407','3.675740420493441','test'),('2019-06-10 19:59:59','2019-06-10 23:59:59','MCOBNB','4h','0.193860000000000','0.193060000000000','0.713387700809367','0.710443771372415','3.6799117961898635','3.679911796189864','test'),('2019-06-11 03:59:59','2019-06-12 03:59:59','MCOBNB','4h','0.199810000000000','0.193140000000000','0.713387700809367','0.689573597589316','3.5703303178487915','3.570330317848792','test'),('2019-06-14 11:59:59','2019-06-14 19:59:59','MCOBNB','4h','0.202030000000000','0.195970000000000','0.713387700809367','0.691989247773161','3.53109786076012','3.531097860760120','test'),('2019-06-16 23:59:59','2019-06-17 07:59:59','MCOBNB','4h','0.194650000000000','0.189440000000000','0.713387700809367','0.694293172572959','3.664976628869083','3.664976628869083','test'),('2019-06-25 11:59:59','2019-06-26 23:59:59','MCOBNB','4h','0.200290000000000','0.177580000000000','0.713387700809367','0.632499814817152','3.561773931845659','3.561773931845659','test'),('2019-06-27 11:59:59','2019-06-27 15:59:59','MCOBNB','4h','0.181030000000000','0.170880000000000','0.713387700809367','0.673389439950862','3.9407153555176877','3.940715355517688','test'),('2019-06-28 19:59:59','2019-06-29 11:59:59','MCOBNB','4h','0.180180000000000','0.179850000000000','0.713387700809367','0.712081129928764','3.9593056987976856','3.959305698797686','test'),('2019-06-30 03:59:59','2019-06-30 07:59:59','MCOBNB','4h','0.179940000000000','0.179310000000000','0.713387700809367','0.710890011293362','3.9645865333409303','3.964586533340930','test'),('2019-07-05 19:59:59','2019-07-05 23:59:59','MCOBNB','4h','0.184480000000000','0.182420000000000','0.713387700809367','0.705421641270841','3.8670191934592744','3.867019193459274','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','MCOBNB','4h','0.184480000000000','0.183610000000000','0.713387700809367','0.710023394111057','3.8670191934592744','3.867019193459274','test'),('2019-07-14 07:59:59','2019-07-14 11:59:59','MCOBNB','4h','0.190250000000000','0.181300000000000','0.713387700809367','0.679827543530819','3.74973824341323','3.749738243413230','test'),('2019-07-17 03:59:59','2019-07-17 11:59:59','MCOBNB','4h','0.193600000000000','0.176830000000000','0.713387700809367','0.651592702139052','3.684853826494664','3.684853826494664','test'),('2019-07-24 03:59:59','2019-07-24 15:59:59','MCOBNB','4h','0.176710000000000','0.163450000000000','0.713387700809367','0.659856373138425','4.037053368849341','4.037053368849341','test'),('2019-07-28 15:59:59','2019-07-28 19:59:59','MCOBNB','4h','0.163590000000000','0.160000000000000','0.713387700809367','0.697732331618673','4.360827072616706','4.360827072616706','test'),('2019-07-29 11:59:59','2019-07-31 03:59:59','MCOBNB','4h','0.162210000000000','0.159370000000000','0.713387700809367','0.700897588792237','4.397926766594951','4.397926766594951','test'),('2019-07-31 07:59:59','2019-07-31 11:59:59','MCOBNB','4h','0.163040000000000','0.160000000000000','0.713387700809367','0.700086065563658','4.375537909772859','4.375537909772859','test'),('2019-08-22 19:59:59','2019-08-26 11:59:59','MCOBNB','4h','0.126700000000000','0.131120000000000','0.713387700809367','0.738274627704216','5.630526446798476','5.630526446798476','test'),('2019-09-06 23:59:59','2019-09-07 03:59:59','MCOBNB','4h','0.145150000000000','0.145160000000000','0.713387700809367','0.713436849118069','4.914830870198877','4.914830870198877','test'),('2019-09-07 23:59:59','2019-09-09 07:59:59','MCOBNB','4h','0.145250000000000','0.144340000000000','0.713387700809367','0.708918283888634','4.911447165641081','4.911447165641081','test'),('2019-09-09 15:59:59','2019-09-10 03:59:59','MCOBNB','4h','0.145630000000000','0.145710000000000','0.713387700809367','0.713779591326875','4.898631468855092','4.898631468855092','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','MCOBNB','4h','0.157440000000000','0.153040000000000','0.713387700809367','0.693450544536748','4.531171880140796','4.531171880140796','test'),('2019-09-19 03:59:59','2019-09-19 07:59:59','MCOBNB','4h','0.157220000000000','0.155260000000000','0.713387700809367','0.704494176489393','4.537512408150152','4.537512408150152','test'),('2019-10-16 03:59:59','2019-10-16 11:59:59','MCOBNB','4h','0.196630000000000','0.192410000000000','0.713387700809367','0.698077239041501','3.6280715089730307','3.628071508973031','test'),('2019-10-16 15:59:59','2019-10-17 03:59:59','MCOBNB','4h','0.198480000000000','0.196720000000000','0.475591800539578','0.471374541526329','2.3961698938914653','2.396169893891465','test'),('2019-10-21 07:59:59','2019-10-25 15:59:59','MCOBNB','4h','0.193590000000000','0.205640000000000','0.532947987568256','0.566121308763553','2.752972713302627','2.752972713302627','test'),('2019-10-29 11:59:59','2019-11-03 07:59:59','MCOBNB','4h','0.206100000000000','0.206850000000000','0.541241317867080','0.543210900537630','2.626110227399708','2.626110227399708','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','MCOBNB','4h','0.208570000000000','0.206890000000000','0.541733713534717','0.537370129899782','2.5973712112706395','2.597371211270640','test'),('2019-11-05 11:59:59','2019-11-05 15:59:59','MCOBNB','4h','0.209050000000000','0.206420000000000','0.541733713534717','0.534918312115935','2.5914073835671703','2.591407383567170','test'),('2019-11-05 19:59:59','2019-11-10 11:59:59','MCOBNB','4h','0.208690000000000','0.209480000000000','0.541733713534717','0.543784456903793','2.5958776823744167','2.595877682374417','test'),('2019-11-14 03:59:59','2019-11-14 07:59:59','MCOBNB','4h','0.211530000000000','0.201280000000000','0.541733713534717','0.515483202667555','2.561025450454862','2.561025450454862','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','MCOBNB','4h','0.210510000000000','0.208460000000000','0.541733713534717','0.536458172644754','2.573434580469892','2.573434580469892','test'),('2019-11-16 11:59:59','2019-11-16 15:59:59','MCOBNB','4h','0.210090000000000','0.209730000000000','0.541733713534717','0.540805425006598','2.5785792447747014','2.578579244774701','test'),('2019-12-21 11:59:59','2019-12-27 07:59:59','MCOBNB','4h','0.291050000000000','0.296320000000000','0.541733713534717','0.551542807059293','1.861308069179581','1.861308069179581','test'),('2019-12-28 07:59:59','2019-12-28 11:59:59','MCOBNB','4h','0.298420000000000','0.296270000000000','0.541733713534717','0.537830732889654','1.8153398349129313','1.815339834912931','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 13:06:13
