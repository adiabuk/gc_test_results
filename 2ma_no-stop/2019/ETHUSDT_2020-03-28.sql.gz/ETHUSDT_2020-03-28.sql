-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-08 15:59:59','2019-02-24 15:59:59','ETHUSDT','4h','112.560000000000002','139.990000000000009','15.000000000000000','18.655383795309170','0.13326226012793177','0.133262260127932','test'),('2019-03-05 19:59:59','2019-03-06 03:59:59','ETHUSDT','4h','136.650000000000006','135.129999999999995','15.913845948827293','15.736831343322590','0.11645697730572478','0.116456977305725','test'),('2019-03-09 07:59:59','2019-03-09 19:59:59','ETHUSDT','4h','137.090000000000003','136.969999999999999','15.913845948827293','15.899915964774047','0.11608320044370335','0.116083200443703','test'),('2019-03-11 03:59:59','2019-03-11 07:59:59','ETHUSDT','4h','135.819999999999993','133.550000000000011','15.913845948827293','15.647873114901230','0.11716864930663594','0.117168649306636','test'),('2019-03-15 11:59:59','2019-03-20 11:59:59','ETHUSDT','4h','134.909999999999997','138.199999999999989','15.913845948827293','16.301930991979329','0.1179589796814713','0.117958979681471','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','ETHUSDT','4h','136.889999999999986','135.979999999999990','15.913845948827293','15.808055899784756','0.11625280114564464','0.116252801145645','test'),('2019-03-23 03:59:59','2019-03-23 07:59:59','ETHUSDT','4h','136.830000000000013','137.659999999999997','15.913845948827293','16.010378084598148','0.11630377803717964','0.116303778037180','test'),('2019-03-27 07:59:59','2019-04-11 11:59:59','ETHUSDT','4h','137.250000000000000','162.550000000000011','15.913845948827293','18.847327205696736','0.11594787576559047','0.115947875765590','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ETHUSDT','4h','164.939999999999998','164.069999999999993','16.627693689643742','16.539988502848605','0.10081055953464134','0.100810559534641','test'),('2019-04-13 03:59:59','2019-04-13 07:59:59','ETHUSDT','4h','164.949999999999989','164.199999999999989','16.627693689643742','16.552090353679915','0.10080444795176564','0.100804447951766','test'),('2019-04-14 23:59:59','2019-04-15 15:59:59','ETHUSDT','4h','167.229999999999990','165.590000000000003','16.627693689643742','16.464628344603884','0.09943008843893884','0.099430088438939','test'),('2019-04-16 19:59:59','2019-04-16 23:59:59','ETHUSDT','4h','164.379999999999995','165.370000000000005','16.627693689643742','16.727836144642811','0.10115399494855665','0.101153994948557','test'),('2019-04-21 23:59:59','2019-04-22 03:59:59','ETHUSDT','4h','168.590000000000003','167.039999999999992','16.627693689643742','16.474820297277954','0.09862799507470041','0.098627995074700','test'),('2019-04-22 07:59:59','2019-04-22 19:59:59','ETHUSDT','4h','168.889999999999986','171.530000000000001','16.627693689643742','16.887609086296354','0.09845280176235267','0.098452801762353','test'),('2019-05-02 15:59:59','2019-05-02 19:59:59','ETHUSDT','4h','162.069999999999993','160.759999999999991','16.627693689643742','16.493293253206193','0.10259575300576135','0.102595753005761','test'),('2019-05-02 23:59:59','2019-05-03 03:59:59','ETHUSDT','4h','161.810000000000002','162.419999999999987','16.627693689643742','16.690377659427330','0.1027606062026064','0.102760606202606','test'),('2019-05-06 11:59:59','2019-05-08 03:59:59','ETHUSDT','4h','165.080000000000013','169.639999999999986','16.627693689643742','17.086999984923455','0.1007250647543236','0.100725064754324','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','ETHUSDT','4h','257.500000000000000','261.139999999999986','16.694793794671945','16.930790103070411','0.06483415065892018','0.064834150658920','test'),('2019-06-12 11:59:59','2019-06-12 15:59:59','ETHUSDT','4h','247.879999999999995','253.500000000000000','16.753792871771562','17.133639232669402','0.06758832044445523','0.067588320444455','test'),('2019-06-28 03:59:59','2019-06-28 07:59:59','ETHUSDT','4h','301.699999999999989','301.879999999999995','16.848754461996023','16.858806751698243','0.05584605390121321','0.055846053901213','test'),('2019-06-30 19:59:59','2019-06-30 23:59:59','ETHUSDT','4h','303.209999999999980','292.699999999999989','16.851267534421577','16.267161397464449','0.055576226161477456','0.055576226161477','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','ETHUSDT','4h','301.139999999999986','296.709999999999980','16.851267534421577','16.603372485017687','0.05595825042977213','0.055958250429772','test'),('2019-07-07 19:59:59','2019-07-10 15:59:59','ETHUSDT','4h','306.319999999999993','288.230000000000018','16.851267534421577','15.856100944914898','0.055011972885941424','0.055011972885941','test'),('2019-08-02 07:59:59','2019-08-02 19:59:59','ETHUSDT','4h','221.090000000000003','216.620000000000005','16.851267534421577','16.510568426009328','0.07621903991325513','0.076219039913255','test'),('2019-08-19 15:59:59','2019-08-19 19:59:59','ETHUSDT','4h','201.280000000000001','198.069999999999993','16.851267534421577','16.582524644986496','0.0837205263037638','0.083720526303764','test'),('2019-08-19 23:59:59','2019-08-20 03:59:59','ETHUSDT','4h','202.280000000000001','198.669999999999987','16.851267534421577','16.550530556968237','0.08330664195383418','0.083306641953834','test'),('2019-09-03 15:59:59','2019-09-03 23:59:59','ETHUSDT','4h','181.259999999999991','178.750000000000000','16.851267534421577','16.617919407358805','0.0929673812999094','0.092967381299909','test'),('2019-09-07 23:59:59','2019-09-08 11:59:59','ETHUSDT','4h','177.620000000000005','179.900000000000006','16.851267534421577','17.067577015214738','0.0948725792952459','0.094872579295246','test'),('2019-09-12 15:59:59','2019-09-13 11:59:59','ETHUSDT','4h','179.759999999999991','179.169999999999987','16.851267534421577','16.795959079563385','0.09374314382744536','0.093743143827445','test'),('2019-10-01 03:59:59','2019-10-01 07:59:59','ETHUSDT','4h','182.219999999999999','180.789999999999992','16.851267534421577','16.719024572209840','0.09247759595226417','0.092477595952264','test'),('2019-10-07 19:59:59','2019-10-08 19:59:59','ETHUSDT','4h','180.199999999999989','178.689999999999998','16.851267534421577','16.710061019565995','0.0935142482487324','0.093514248248732','test'),('2019-10-12 03:59:59','2019-10-12 19:59:59','ETHUSDT','4h','182.629999999999995','179.689999999999998','16.851267534421577','16.579993775722571','0.0922699859520428','0.092269985952043','test'),('2019-10-13 11:59:59','2019-10-13 23:59:59','ETHUSDT','4h','182.460000000000008','180.990000000000009','16.851267534421577','16.715504280691448','0.09235595491845652','0.092355954918457','test'),('2019-10-14 03:59:59','2019-10-14 15:59:59','ETHUSDT','4h','182.409999999999997','181.750000000000000','16.851267534421577','16.790295895954838','0.09238127040415316','0.092381270404153','test'),('2019-10-25 15:59:59','2019-10-31 11:59:59','ETHUSDT','4h','175.520000000000010','180.300000000000011','16.851267534421577','17.310184232316605','0.09600767738389686','0.096007677383897','test'),('2019-11-09 03:59:59','2019-11-09 07:59:59','ETHUSDT','4h','184.560000000000002','185.090000000000003','16.851267534421577','16.899659232477731','0.09130509067198514','0.091305090671985','test'),('2019-11-09 23:59:59','2019-11-10 03:59:59','ETHUSDT','4h','184.889999999999986','184.060000000000002','16.851267534421577','16.775619570477776','0.09114212523349872','0.091142125233499','test'),('2019-11-17 19:59:59','2019-11-17 23:59:59','ETHUSDT','4h','185.069999999999993','183.819999999999993','16.851267534421577','16.737450684483569','0.09105347995040568','0.091053479950406','test'),('2019-12-08 19:59:59','2019-12-09 03:59:59','ETHUSDT','4h','150.419999999999987','150.310000000000002','16.851267534421577','16.838944442885968','0.11202810486917683','0.112028104869177','test'),('2019-12-29 15:59:59','2019-12-31 15:59:59','ETHUSDT','4h','131.990000000000009','129.729999999999990','16.851267534421577','16.562731549666722','0.12767078971453577','0.127670789714536','test'),('2020-01-01 11:59:59','2020-01-01 15:59:59','ETHUSDT','4h','130.740000000000009','132.080000000000013','16.851267534421577','17.023982070876563','0.12889144511566145','0.128891445115661','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:29:25
