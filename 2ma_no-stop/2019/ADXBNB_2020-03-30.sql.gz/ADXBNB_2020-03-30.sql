-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 03:59:59','2019-01-03 03:59:59','ADXBNB','4h','0.017760000000000','0.017530000000000','0.711908500000000','0.702688964245496','40.08493806306306','40.084938063063063','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','ADXBNB','4h','0.017890000000000','0.017430000000000','0.711908500000000','0.693603418390162','39.79365567356065','39.793655673560650','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','ADXBNB','4h','0.017930000000000','0.017450000000000','0.711908500000000','0.692850157557167','39.704880089235914','39.704880089235914','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','ADXBNB','4h','0.016450000000000','0.016000000000000','0.711908500000000','0.692433799392097','43.27711246200609','43.277112462006087','test'),('2019-01-17 19:59:59','2019-01-17 23:59:59','ADXBNB','4h','0.016180000000000','0.016030000000000','0.711908500000000','0.705308606613103','43.999289245982695','43.999289245982695','test'),('2019-01-19 15:59:59','2019-01-20 07:59:59','ADXBNB','4h','0.017900000000000','0.016120000000000','0.711908500000000','0.641115364245810','39.77142458100559','39.771424581005590','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','ADXBNB','4h','0.016470000000000','0.016390000000000','0.711908500000000','0.708450535215543','43.22455980570735','43.224559805707351','test'),('2019-01-30 19:59:59','2019-01-31 07:59:59','ADXBNB','4h','0.015390000000000','0.015100000000000','0.711908500000000','0.698493719948018','46.25786224821313','46.257862248213129','test'),('2019-02-08 03:59:59','2019-02-08 15:59:59','ADXBNB','4h','0.019080000000000','0.013590000000000','0.711908500000000','0.507066903301887','37.31176624737946','37.311766247379460','test'),('2019-02-16 23:59:59','2019-02-18 03:59:59','ADXBNB','4h','0.012800000000000','0.012620000000000','0.711908500000000','0.701897286718750','55.6178515625','55.617851562500000','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','ADXBNB','4h','0.012050000000000','0.011860000000000','0.711908500000000','0.700683386721992','59.079543568464736','59.079543568464736','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','ADXBNB','4h','0.012040000000000','0.012170000000000','0.711908500000000','0.719595219684385','59.128612956810635','59.128612956810635','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','ADXBNB','4h','0.009900000000000','0.009770000000000','0.711908500000000','0.702560206565656','71.9099494949495','71.909949494949501','test'),('2019-03-16 03:59:59','2019-03-16 07:59:59','ADXBNB','4h','0.009850000000000','0.009450000000000','0.711908500000000','0.682998510152284','72.27497461928935','72.274974619289353','test'),('2019-03-20 15:59:59','2019-03-21 03:59:59','ADXBNB','4h','0.009570000000000','0.009450000000000','0.711908500000000','0.702981747648903','74.38960292580983','74.389602925809825','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ADXBNB','4h','0.009630000000000','0.009290000000000','0.711908500000000','0.686773620456906','73.92611630321912','73.926116303219118','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','ADXBNB','4h','0.009590000000000','0.009670000000000','0.711908500000000','0.717847257038582','74.23446298227321','74.234462982273214','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','ADXBNB','4h','0.009740000000000','0.009450000000000','0.711908500000000','0.690712045687885','73.09122176591376','73.091221765913758','test'),('2019-03-26 15:59:59','2019-03-30 07:59:59','ADXBNB','4h','0.011990000000000','0.009570000000000','0.711908500000000','0.568220545871560','59.37518765638032','59.375187656380319','test'),('2019-03-30 19:59:59','2019-03-30 23:59:59','ADXBNB','4h','0.009690000000000','0.009310000000000','0.711908500000000','0.683990519607843','73.46836945304437','73.468369453044374','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','ADXBNB','4h','0.009760000000000','0.009450000000000','0.711908500000000','0.689296652151639','72.94144467213115','72.941444672131155','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','ADXBNB','4h','0.009620000000000','0.009490000000000','0.711908500000000','0.702288114864865','74.00296257796258','74.002962577962577','test'),('2019-04-07 03:59:59','2019-04-07 07:59:59','ADXBNB','4h','0.009400000000000','0.009250000000000','0.711908500000000','0.700548257978723','75.73494680851064','75.734946808510642','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','ADXBNB','4h','0.009330000000000','0.009300000000000','0.711908500000000','0.709619405144695','76.30316184351555','76.303161843515554','test'),('2019-04-07 19:59:59','2019-04-09 07:59:59','ADXBNB','4h','0.009530000000000','0.009310000000000','0.711908500000000','0.695474096012592','74.70183630640085','74.701836306400850','test'),('2019-04-10 15:59:59','2019-04-11 11:59:59','ADXBNB','4h','0.009680000000000','0.009470000000000','0.711908500000000','0.696464204028926','73.54426652892563','73.544266528925633','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','ADXBNB','4h','0.006480000000000','0.006220000000000','0.474605666666667','0.455562846707819','73.24161522633746','73.241615226337458','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','ADXBNB','4h','0.006390000000000','0.006300000000000','0.528233181321655','0.520793277359378','82.66559958085368','82.665599580853680','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','ADXBNB','4h','0.006460000000000','0.006350000000000','0.528233181321655','0.519238498667571','81.76984230985371','81.769842309853715','test'),('2019-05-11 11:59:59','2019-05-11 15:59:59','ADXBNB','4h','0.006510000000000','0.006070000000000','0.528233181321655','0.492530785041850','81.14180972682873','81.141809726828726','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','ADXBNB','4h','0.005160000000000','0.005180000000000','0.528233181321655','0.530280596753134','102.37077157396415','102.370771573964149','test'),('2019-05-27 19:59:59','2019-05-27 23:59:59','ADXBNB','4h','0.005140000000000','0.005090000000000','0.528233181321655','0.523094726250433','102.7691014244465','102.769101424446504','test'),('2019-05-28 11:59:59','2019-05-30 03:59:59','ADXBNB','4h','0.005120000000000','0.005060000000000','0.528233181321655','0.522042948728042','103.17054322688573','103.170543226885727','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','ADXBNB','4h','0.005290000000000','0.005210000000000','0.528233181321655','0.520244777823407','99.85504372810112','99.855043728101123','test'),('2019-06-08 07:59:59','2019-06-08 19:59:59','ADXBNB','4h','0.005430000000000','0.005060000000000','0.528233181321655','0.492239391802500','97.28051221393278','97.280512213932781','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ADXBNB','4h','0.005130000000000','0.005000000000000','0.528233181321655','0.514847155284264','102.96943105685283','102.969431056852827','test'),('2019-06-10 15:59:59','2019-06-11 11:59:59','ADXBNB','4h','0.005130000000000','0.005090000000000','0.528233181321655','0.524114404079381','102.96943105685283','102.969431056852827','test'),('2019-06-14 07:59:59','2019-06-14 15:59:59','ADXBNB','4h','0.005140000000000','0.005150000000000','0.528233181321655','0.529260872335899','102.7691014244465','102.769101424446504','test'),('2019-06-28 07:59:59','2019-06-28 11:59:59','ADXBNB','4h','0.004340000000000','0.004090000000000','0.528233181321655','0.497805002674094','121.71271459024308','121.712714590243081','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','ADXBNB','4h','0.004140000000000','0.004090000000000','0.528233181321655','0.521853553527915','127.5925558747959','127.592555874795906','test'),('2019-07-05 11:59:59','2019-07-05 15:59:59','ADXBNB','4h','0.004030000000000','0.004150000000000','0.528233181321655','0.543962209053317','131.07523109718485','131.075231097184854','test'),('2019-07-08 19:59:59','2019-07-09 03:59:59','ADXBNB','4h','0.004070000000000','0.004080000000000','0.528233181321655','0.529531051546033','129.78702243775308','129.787022437753080','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','ADXBNB','4h','0.004130000000000','0.004040000000000','0.528233181321655','0.516722046619730','127.90149668805205','127.901496688052049','test'),('2019-07-15 03:59:59','2019-07-15 11:59:59','ADXBNB','4h','0.004003000000000','0.003812000000000','0.528233181321655','0.503028950086972','131.95932583603673','131.959325836036726','test'),('2019-07-23 03:59:59','2019-07-24 15:59:59','ADXBNB','4h','0.003799000000000','0.003580000000000','0.528233181321655','0.497782255628198','139.0453228011727','139.045322801172688','test'),('2019-07-31 23:59:59','2019-08-01 03:59:59','ADXBNB','4h','0.003834000000000','0.003773000000000','0.528233181321655','0.519828845364268','137.7759993014228','137.775999301422786','test'),('2019-08-04 23:59:59','2019-08-05 03:59:59','ADXBNB','4h','0.003791000000000','0.003688000000000','0.528233181321655','0.513881290613100','139.33874474324847','139.338744743248469','test'),('2019-08-22 15:59:59','2019-09-02 15:59:59','ADXBNB','4h','0.003075000000000','0.003421000000000','0.528233181321655','0.587670150667116','171.78314839728617','171.783148397286169','test'),('2019-09-04 03:59:59','2019-09-04 07:59:59','ADXBNB','4h','0.003506000000000','0.003434000000000','0.528233181321655','0.517385266588295','150.66548240777382','150.665482407773823','test'),('2019-09-04 11:59:59','2019-09-05 23:59:59','ADXBNB','4h','0.003502000000000','0.003576000000000','0.528233181321655','0.539395161737932','150.83757319293403','150.837573192934030','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','ADXBNB','4h','0.003558000000000','0.003456000000000','0.528233181321655','0.513089902936380','148.46351358112844','148.463513581128439','test'),('2019-09-09 15:59:59','2019-09-11 07:59:59','ADXBNB','4h','0.003526000000000','0.003617000000000','0.528233181321655','0.541865971877602','149.81088523019142','149.810885230191417','test'),('2019-09-19 03:59:59','2019-09-19 19:59:59','ADXBNB','4h','0.003806000000000','0.003786000000000','0.528233181321655','0.525457389512293','138.78959046811744','138.789590468117439','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','ADXBNB','4h','0.003965000000000','0.003800000000000','0.528233181321655','0.506251220434373','133.2240053774666','133.224005377466597','test'),('2019-09-26 23:59:59','2019-09-27 03:59:59','ADXBNB','4h','0.003862000000000','0.003878000000000','0.528233181321655','0.530421615009161','136.77710546909762','136.777105469097620','test'),('2019-10-12 03:59:59','2019-10-12 07:59:59','ADXBNB','4h','0.004835000000000','0.004708000000000','0.528233181321655','0.514358183590972','109.25195063529576','109.251950635295756','test'),('2019-10-12 11:59:59','2019-10-12 15:59:59','ADXBNB','4h','0.004845000000000','0.004840000000000','0.528233181321655','0.527688049039589','109.02645641313828','109.026456413138277','test'),('2019-10-22 03:59:59','2019-10-22 23:59:59','ADXBNB','4h','0.004353000000000','0.004309000000000','0.528233181321655','0.522893815372160','121.34922612489203','121.349226124892027','test'),('2019-10-31 23:59:59','2019-11-03 03:59:59','ADXBNB','4h','0.004059000000000','0.004044000000000','0.528233181321655','0.526281100089868','130.13874878582286','130.138748785822855','test'),('2019-11-03 11:59:59','2019-11-03 15:59:59','ADXBNB','4h','0.004141000000000','0.004165000000000','0.528233181321655','0.531294663174280','127.56174385937092','127.561743859370921','test'),('2019-11-08 03:59:59','2019-11-10 03:59:59','ADXBNB','4h','0.004354000000000','0.004123000000000','0.528233181321655','0.500207948229027','121.32135537934197','121.321355379341966','test'),('2019-11-15 19:59:59','2019-11-16 03:59:59','ADXBNB','4h','0.004048000000000','0.003930000000000','0.528233181321655','0.512835079692219','130.49238669013215','130.492386690132150','test'),('2019-11-16 11:59:59','2019-11-20 07:59:59','ADXBNB','4h','0.004041000000000','0.004149000000000','0.528233181321655','0.542350771913770','130.71843140847685','130.718431408476846','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 16:25:33
