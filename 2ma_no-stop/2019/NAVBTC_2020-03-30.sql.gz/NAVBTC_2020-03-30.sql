-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 19:59:59','2019-01-06 07:59:59','NAVBTC','4h','0.000043500000000','0.000043900000000','0.001467500000000','0.001480994252874','33.735632183908045','33.735632183908045','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','NAVBTC','4h','0.000043600000000','0.000043300000000','0.001470873563218','0.001460752873563','33.735632183910546','33.735632183910546','test'),('2019-01-07 07:59:59','2019-01-08 11:59:59','NAVBTC','4h','0.000044300000000','0.000043300000000','0.001470873563218','0.001437670999714','33.20256350379233','33.202563503792327','test'),('2019-01-09 07:59:59','2019-01-09 15:59:59','NAVBTC','4h','0.000044000000000','0.000043900000000','0.001470873563218','0.001467530668756','33.42894461859091','33.428944618590911','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','NAVBTC','4h','0.000044200000000','0.000043400000000','0.001470873563218','0.001444251417277','33.277682425746605','33.277682425746605','test'),('2019-01-13 07:59:59','2019-01-13 11:59:59','NAVBTC','4h','0.000044200000000','0.000043300000000','0.001470873563218','0.001440923649035','33.277682425746605','33.277682425746605','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','NAVBTC','4h','0.000043300000000','0.000042800000000','0.001470873563218','0.001453888880040','33.9693663560739','33.969366356073898','test'),('2019-01-15 15:59:59','2019-01-20 11:59:59','NAVBTC','4h','0.000045600000000','0.000044400000000','0.001470873563218','0.001432166364186','32.25599919337719','32.255999193377193','test'),('2019-01-21 23:59:59','2019-01-23 23:59:59','NAVBTC','4h','0.000045300000000','0.000047000000000','0.001470873563218','0.001526071908858','32.46961508207505','32.469615082075052','test'),('2019-02-04 03:59:59','2019-02-04 07:59:59','NAVBTC','4h','0.000044500000000','0.000043500000000','0.001470873563218','0.001437820224719','33.0533384992809','33.053338499280898','test'),('2019-02-12 11:59:59','2019-02-12 19:59:59','NAVBTC','4h','0.000042100000000','0.000041700000000','0.001470873563218','0.001456898517487','34.93761432821852','34.937614328218523','test'),('2019-02-13 03:59:59','2019-02-14 11:59:59','NAVBTC','4h','0.000043400000000','0.000042000000000','0.001470873563218','0.001423426028921','33.89109592668203','33.891095926682027','test'),('2019-02-14 23:59:59','2019-02-15 03:59:59','NAVBTC','4h','0.000042400000000','0.000042000000000','0.001470873563218','0.001456997397527','34.69041422683962','34.690414226839621','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','NAVBTC','4h','0.000042400000000','0.000041800000000','0.001470873563218','0.001450059314682','34.69041422683962','34.690414226839621','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','NAVBTC','4h','0.000043400000000','0.000042000000000','0.001470873563218','0.001423426028921','33.89109592668203','33.891095926682027','test'),('2019-02-24 03:59:59','2019-02-24 07:59:59','NAVBTC','4h','0.000041900000000','0.000041200000000','0.001470873563218','0.001446300496529','35.104380983723146','35.104380983723146','test'),('2019-02-27 07:59:59','2019-02-27 15:59:59','NAVBTC','4h','0.000041900000000','0.000041200000000','0.001470873563218','0.001446300496529','35.104380983723146','35.104380983723146','test'),('2019-03-01 03:59:59','2019-03-03 19:59:59','NAVBTC','4h','0.000041100000000','0.000041300000000','0.001470873563218','0.001478031098805','35.78767793717761','35.787677937177612','test'),('2019-03-04 07:59:59','2019-03-04 11:59:59','NAVBTC','4h','0.000041200000000','0.000041300000000','0.001470873563218','0.001474443644682','35.70081464121359','35.700814641213590','test'),('2019-03-04 19:59:59','2019-03-08 23:59:59','NAVBTC','4h','0.000041700000000','0.000042000000000','0.001470873563218','0.001481455387414','35.2727473193765','35.272747319376499','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','NAVBTC','4h','0.000053000000000','0.000051200000000','0.001470873563218','0.001420919366731','27.752331381471695','27.752331381471695','test'),('2019-04-18 23:59:59','2019-04-19 03:59:59','NAVBTC','4h','0.000046100000000','0.000045500000000','0.001470873563218','0.001451729872590','31.9061510459436','31.906151045943599','test'),('2019-05-16 19:59:59','2019-05-16 23:59:59','NAVBTC','4h','0.000029400000000','0.000027800000000','0.001470873563218','0.001390826022363','50.02971303462585','50.029713034625850','test'),('2019-05-17 07:59:59','2019-05-17 11:59:59','NAVBTC','4h','0.000029200000000','0.000027800000000','0.001470873563218','0.001400352227995','50.3723823019863','50.372382301986299','test'),('2019-05-19 15:59:59','2019-05-19 23:59:59','NAVBTC','4h','0.000029400000000','0.000028000000000','0.001470873563218','0.001400831964970','50.02971303462585','50.029713034625850','test'),('2019-05-21 15:59:59','2019-05-21 19:59:59','NAVBTC','4h','0.000029100000000','0.000028600000000','0.001470873563218','0.001445600821582','50.54548327209622','50.545483272096220','test'),('2019-05-24 07:59:59','2019-05-24 11:59:59','NAVBTC','4h','0.000028800000000','0.000028500000000','0.001470873563218','0.001455551963601','51.07199872284722','51.071998722847219','test'),('2019-05-31 23:59:59','2019-06-01 03:59:59','NAVBTC','4h','0.000027000000000','0.000026100000000','0.001470873563218','0.001421844444444','54.4767986377037','54.476798637703702','test'),('2019-06-01 11:59:59','2019-06-03 19:59:59','NAVBTC','4h','0.000026900000000','0.000027300000000','0.001470873563218','0.001492745289065','54.67931461776951','54.679314617769514','test'),('2019-06-05 11:59:59','2019-06-06 19:59:59','NAVBTC','4h','0.000027700000000','0.000027200000000','0.001470873563218','0.001444323498900','53.10012863602888','53.100128636028877','test'),('2019-06-10 07:59:59','2019-06-14 11:59:59','NAVBTC','4h','0.000028100000000','0.000028300000000','0.001470873563218','0.001481342414202','52.344254918790035','52.344254918790035','test'),('2019-06-18 19:59:59','2019-06-18 23:59:59','NAVBTC','4h','0.000028100000000','0.000026400000000','0.001470873563218','0.001381888329856','52.344254918790035','52.344254918790035','test'),('2019-07-23 23:59:59','2019-07-25 15:59:59','NAVBTC','4h','0.000013600000000','0.000014000000000','0.001470873563218','0.001514134550371','108.15246788367647','108.152467883676465','test'),('2019-07-30 23:59:59','2019-07-31 03:59:59','NAVBTC','4h','0.000013900000000','0.000013900000000','0.001470873563218','0.001470873563218','105.81824195812949','105.818241958129491','test'),('2019-08-01 19:59:59','2019-08-02 03:59:59','NAVBTC','4h','0.000015600000000','0.000013500000000','0.001470873563218','0.001272871352785','94.28676687294872','94.286766872948718','test'),('2019-08-13 15:59:59','2019-08-13 19:59:59','NAVBTC','4h','0.000011000000000','0.000010300000000','0.001470873563218','0.001377272518286','133.71577847436365','133.715778474363646','test'),('2019-08-13 23:59:59','2019-08-14 07:59:59','NAVBTC','4h','0.000011100000000','0.000011200000000','0.001470873563218','0.001484124676400','132.51113182144144','132.511131821441438','test'),('2019-08-22 15:59:59','2019-08-25 15:59:59','NAVBTC','4h','0.000010700000000','0.000010700000000','0.001470873563218','0.001470873563218','137.46481899233646','137.464818992336461','test'),('2019-08-26 11:59:59','2019-08-26 15:59:59','NAVBTC','4h','0.000010900000000','0.000010900000000','0.001470873563218','0.001470873563218','134.9425287355963','134.942528735596312','test'),('2019-08-29 07:59:59','2019-08-29 11:59:59','NAVBTC','4h','0.000010900000000','0.000011000000000','0.001470873563218','0.001484367816092','134.9425287355963','134.942528735596312','test'),('2019-08-31 07:59:59','2019-09-01 19:59:59','NAVBTC','4h','0.000011200000000','0.000010800000000','0.001470873563218','0.001418342364532','131.32799671589285','131.327996715892851','test'),('2019-09-08 19:59:59','2019-09-09 07:59:59','NAVBTC','4h','0.000010600000000','0.000010500000000','0.001470873563218','0.001456997397527','138.76165690735849','138.761656907358486','test'),('2019-09-09 15:59:59','2019-09-11 19:59:59','NAVBTC','4h','0.000010500000000','0.000010800000000','0.001470873563218','0.001512898522167','140.08319649695238','140.083196496952382','test'),('2019-09-16 19:59:59','2019-09-16 23:59:59','NAVBTC','4h','0.000010700000000','0.000010600000000','0.001470873563218','0.001457127081319','137.46481899233646','137.464818992336461','test'),('2019-09-17 19:59:59','2019-09-18 03:59:59','NAVBTC','4h','0.000010500000000','0.000010590000000','0.001470873563218','0.001483481050903','140.08319649695238','140.083196496952382','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','NAVBTC','4h','0.000011140000000','0.000010510000000','0.001470873563218','0.001387691306052','132.0353288346499','132.035328834649903','test'),('2019-09-25 11:59:59','2019-09-25 15:59:59','NAVBTC','4h','0.000011220000000','0.000010780000000','0.001470873563218','0.001413192247013','131.0939004650624','131.093900465062404','test'),('2019-10-01 15:59:59','2019-10-06 11:59:59','NAVBTC','4h','0.000011100000000','0.000011600000000','0.001470873563218','0.001537129129129','132.51113182144144','132.511131821441438','test'),('2019-10-24 15:59:59','2019-10-24 19:59:59','NAVBTC','4h','0.000011070000000','0.000010590000000','0.001470873563218','0.001407095847740','132.87024057976512','132.870240579765124','test'),('2019-10-27 03:59:59','2019-10-27 11:59:59','NAVBTC','4h','0.000011200000000','0.000010030000000','0.001470873563218','0.001317219807060','131.32799671589285','131.327996715892851','test'),('2019-10-28 19:59:59','2019-10-28 23:59:59','NAVBTC','4h','0.000010390000000','0.000010520000000','0.001470873563218','0.001489277178542','141.56627172454282','141.566271724542815','test'),('2019-10-29 19:59:59','2019-10-29 23:59:59','NAVBTC','4h','0.000010420000000','0.000010270000000','0.001470873563218','0.001449699759525','141.15869128771593','141.158691287715925','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','NAVBTC','4h','0.000011210000000','0.000010410000000','0.001470873563218','0.001365904887877','131.2108441764496','131.210844176449598','test'),('2019-11-02 11:59:59','2019-11-02 15:59:59','NAVBTC','4h','0.000010500000000','0.000010380000000','0.001470873563218','0.001454063579638','140.08319649695238','140.083196496952382','test'),('2019-11-07 23:59:59','2019-11-08 03:59:59','NAVBTC','4h','0.000010470000000','0.000010360000000','0.001470873563218','0.001455420259306','140.4845810141356','140.484581014135614','test'),('2019-11-09 07:59:59','2019-11-09 15:59:59','NAVBTC','4h','0.000010380000000','0.000010260000000','0.001470873563218','0.001453869244568','141.70265541599227','141.702655415992268','test'),('2019-11-10 15:59:59','2019-11-10 19:59:59','NAVBTC','4h','0.000010400000000','0.000010170000000','0.001470873563218','0.001438344628647','141.43015030942306','141.430150309423055','test'),('2019-11-13 15:59:59','2019-11-15 15:59:59','NAVBTC','4h','0.000010410000000','0.000010350000000','0.000980582375479','0.000974930603862','94.1961936098623','94.196193609862306','test'),('2019-11-16 11:59:59','2019-11-16 15:59:59','NAVBTC','4h','0.000010340000000','0.000010400000000','0.001094610112532','0.001100961815313','105.86171301078345','105.861713010783447','test'),('2019-11-23 19:59:59','2019-12-02 03:59:59','NAVBTC','4h','0.000010710000000','0.000016220000000','0.001096198038227','0.001660161734831','102.35275800436514','102.352758004365143','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','NAVBTC','4h','0.000013740000000','0.000012890000000','0.001237188962378','0.001160652527296','90.04286480187415','90.042864801874146','test'),('2019-12-14 03:59:59','2019-12-14 07:59:59','NAVBTC','4h','0.000013460000000','0.000012830000000','0.001237188962378','0.001179281900989','91.91597045898959','91.915970458989591','test'),('2019-12-19 19:59:59','2019-12-21 23:59:59','NAVBTC','4h','0.000013420000000','0.000012580000000','0.001237188962378','0.001159749414807','92.18993758405365','92.189937584053652','test'),('2019-12-23 07:59:59','2019-12-24 15:59:59','NAVBTC','4h','0.000013240000000','0.000012980000000','0.001237188962378','0.001212893710851','93.44327510407854','93.443275104078538','test'),('2019-12-25 07:59:59','2019-12-25 23:59:59','NAVBTC','4h','0.000013020000000','0.000013190000000','0.001237188962378','0.001253342735312','95.02219373102918','95.022193731029176','test'),('2019-12-26 19:59:59','2019-12-28 03:59:59','NAVBTC','4h','0.000013040000000','0.000013180000000','0.001237188962378','0.001250471665962','94.87645417009202','94.876454170092018','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  9:22:36
