-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 03:59:59','2019-01-08 11:59:59','REPBNB','4h','1.381000000000000','1.465000000000000','0.711908500000000','0.755210682476466','0.515502172338885','0.515502172338885','test'),('2019-01-14 19:59:59','2019-01-23 15:59:59','REPBNB','4h','1.728000000000000','2.325000000000000','0.722734045619117','0.972428620407666','0.4182488689925443','0.418248868992544','test'),('2019-01-24 23:59:59','2019-01-25 03:59:59','REPBNB','4h','2.302000000000000','2.190000000000000','0.785157689316254','0.746957141443352','0.3410763202937679','0.341076320293768','test'),('2019-02-02 03:59:59','2019-02-04 07:59:59','REPBNB','4h','2.036000000000000','2.043000000000000','0.785157689316254','0.787857150919994','0.3856373719627966','0.385637371962797','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','REPBNB','4h','0.996000000000000','0.976000000000000','0.785157689316254','0.769391470655285','0.7883109330484478','0.788310933048448','test'),('2019-03-18 11:59:59','2019-03-18 15:59:59','REPBNB','4h','0.975000000000000','0.954000000000000','0.785157689316254','0.768246600623289','0.8052899377602605','0.805289937760260','test'),('2019-03-18 19:59:59','2019-03-19 03:59:59','REPBNB','4h','0.979000000000000','0.960000000000000','0.785157689316254','0.769919695345867','0.8019996826519448','0.801999682651945','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','REPBNB','4h','0.983000000000000','0.971000000000000','0.785157689316254','0.775572854858680','0.7987362047978168','0.798736204797817','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','REPBNB','4h','0.980000000000000','0.962000000000000','0.785157689316254','0.770736425634935','0.8011813156288305','0.801181315628831','test'),('2019-03-30 03:59:59','2019-03-31 03:59:59','REPBNB','4h','1.013000000000000','0.894000000000000','0.785157689316254','0.692922975566368','0.7750816281503001','0.775081628150300','test'),('2019-04-03 03:59:59','2019-04-11 03:59:59','REPBNB','4h','1.166000000000000','1.037000000000000','0.785157689316254','0.698292044443358','0.6733770920379537','0.673377092037954','test'),('2019-04-12 03:59:59','2019-04-12 19:59:59','REPBNB','4h','1.073000000000000','1.083000000000000','0.785157689316254','0.792475095554057','0.7317406237802926','0.731740623780293','test'),('2019-04-18 03:59:59','2019-04-18 07:59:59','REPBNB','4h','1.139000000000000','1.060000000000000','0.785157689316254','0.730699868898358','0.6893394989607147','0.689339498960715','test'),('2019-04-25 11:59:59','2019-04-25 23:59:59','REPBNB','4h','0.973000000000000','0.964000000000000','0.785157689316254','0.777895182426381','0.8069452099858725','0.806945209985872','test'),('2019-04-26 15:59:59','2019-04-26 19:59:59','REPBNB','4h','0.996000000000000','0.961000000000000','0.785157689316254','0.757566806659558','0.7883109330484478','0.788310933048448','test'),('2019-04-30 11:59:59','2019-04-30 15:59:59','REPBNB','4h','0.970000000000000','0.953000000000000','0.785157689316254','0.771397193730299','0.8094409168208804','0.809440916820880','test'),('2019-04-30 23:59:59','2019-05-01 03:59:59','REPBNB','4h','0.962000000000000','0.940000000000000','0.785157689316254','0.767201900163491','0.8161722342164802','0.816172234216480','test'),('2019-05-06 23:59:59','2019-05-07 23:59:59','REPBNB','4h','0.940000000000000','0.975000000000000','0.785157689316254','0.814392284131221','0.835274137570483','0.835274137570483','test'),('2019-06-08 19:59:59','2019-06-08 23:59:59','REPBNB','4h','0.601000000000000','0.606000000000000','0.785157689316254','0.791689783237354','1.3064187842200565','1.306418784220057','test'),('2019-06-16 19:59:59','2019-06-17 07:59:59','REPBNB','4h','0.582000000000000','0.558000000000000','0.785157689316254','0.752780052643419','1.3490681947014673','1.349068194701467','test'),('2019-06-27 11:59:59','2019-06-27 19:59:59','REPBNB','4h','0.549000000000000','0.501000000000000','0.785157689316254','0.716510022490789','1.4301597255305172','1.430159725530517','test'),('2019-07-09 15:59:59','2019-07-12 03:59:59','REPBNB','4h','0.494000000000000','0.459600000000000','0.785157689316254','0.730482740910426','1.5893880350531457','1.589388035053146','test'),('2019-07-12 23:59:59','2019-07-13 23:59:59','REPBNB','4h','0.483500000000000','0.467400000000000','0.785157689316254','0.759012831409343','1.6239042178205874','1.623904217820587','test'),('2019-07-14 03:59:59','2019-07-14 11:59:59','REPBNB','4h','0.472100000000000','0.475100000000000','0.785157689316254','0.790147041292422','1.6631173253892266','1.663117325389227','test'),('2019-07-29 19:59:59','2019-07-31 11:59:59','REPBNB','4h','0.414100000000000','0.411500000000000','0.785157689316254','0.780227938067226','1.896058172702859','1.896058172702859','test'),('2019-07-31 19:59:59','2019-08-01 07:59:59','REPBNB','4h','0.419000000000000','0.417000000000000','0.785157689316254','0.781409919916176','1.8738847000387924','1.873884700038792','test'),('2019-08-05 07:59:59','2019-08-06 03:59:59','REPBNB','4h','0.446600000000000','0.400000000000000','0.785157689316254','0.703231248827814','1.7580781220695343','1.758078122069534','test'),('2019-08-06 15:59:59','2019-08-06 19:59:59','REPBNB','4h','0.417000000000000','0.396400000000000','0.785157689316254','0.746370522889600','1.8828721566337026','1.882872156633703','test'),('2019-08-07 11:59:59','2019-08-07 15:59:59','REPBNB','4h','0.421100000000000','0.383500000000000','0.785157689316254','0.715050994663461','1.8645397514040702','1.864539751404070','test'),('2019-08-20 03:59:59','2019-08-20 19:59:59','REPBNB','4h','0.370100000000000','0.361500000000000','0.785157689316254','0.766913009153812','2.121474437493256','2.121474437493256','test'),('2019-08-21 19:59:59','2019-08-23 15:59:59','REPBNB','4h','0.368400000000000','0.359400000000000','0.785157689316254','0.765976312541427','2.1312640860918943','2.131264086091894','test'),('2019-08-24 03:59:59','2019-08-26 03:59:59','REPBNB','4h','0.364100000000000','0.366100000000000','0.785157689316254','0.789470557700304','2.1564341920248666','2.156434192024867','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','REPBNB','4h','0.372000000000000','0.369000000000000','0.785157689316254','0.778825772466929','2.1106389497748763','2.110638949774876','test'),('2019-08-29 07:59:59','2019-08-29 11:59:59','REPBNB','4h','0.369900000000000','0.363900000000000','0.785157689316254','0.772421960373573','2.122621490446753','2.122621490446753','test'),('2019-08-29 15:59:59','2019-08-29 19:59:59','REPBNB','4h','0.366700000000000','0.367900000000000','0.523438459544169','0.525151375146713','1.4274296687869357','1.427429668786936','test'),('2019-08-31 11:59:59','2019-08-31 15:59:59','REPBNB','4h','0.369300000000000','0.366100000000000','0.587335753596500','0.582246464640343','1.5904027987990794','1.590402798799079','test'),('2019-08-31 19:59:59','2019-09-02 15:59:59','REPBNB','4h','0.368800000000000','0.360600000000000','0.587335753596500','0.574276769921090','1.592558984806128','1.592558984806128','test'),('2019-09-02 19:59:59','2019-09-02 23:59:59','REPBNB','4h','0.371600000000000','0.358600000000000','0.587335753596500','0.566788485575094','1.5805590785696988','1.580559078569699','test'),('2019-09-03 15:59:59','2019-09-03 23:59:59','REPBNB','4h','0.376100000000000','0.366100000000000','0.587335753596500','0.571719275170643','1.5616478425857485','1.561647842585749','test'),('2019-09-04 03:59:59','2019-09-05 19:59:59','REPBNB','4h','0.391400000000000','0.391400000000000','0.587335753596500','0.587335753596500','1.5006023341760348','1.500602334176035','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','REPBNB','4h','0.504900000000000','0.483200000000000','0.587335753596500','0.562092763196334','1.1632714470122796','1.163271447012280','test'),('2019-10-01 19:59:59','2019-10-01 23:59:59','REPBNB','4h','0.526000000000000','0.522000000000000','0.587335753596500','0.582869322010215','1.116607896571293','1.116607896571293','test'),('2019-10-03 03:59:59','2019-10-03 07:59:59','REPBNB','4h','0.536300000000000','0.522000000000000','0.587335753596500','0.571674927050854','1.0951626954997205','1.095162695499720','test'),('2019-10-03 15:59:59','2019-10-04 03:59:59','REPBNB','4h','0.527400000000000','0.526000000000000','0.587335753596500','0.585776652240726','1.1136438255527115','1.113643825552711','test'),('2019-10-06 11:59:59','2019-10-07 11:59:59','REPBNB','4h','0.528200000000000','0.522000000000000','0.587335753596500','0.580441619419487','1.1119571253246876','1.111957125324688','test'),('2019-10-08 07:59:59','2019-10-08 11:59:59','REPBNB','4h','0.526900000000000','0.526000000000000','0.587335753596500','0.586332523043763','1.1147006141516416','1.114700614151642','test'),('2019-10-08 23:59:59','2019-10-09 03:59:59','REPBNB','4h','0.528000000000000','0.532000000000000','0.587335753596500','0.591785266881322','1.1123783212054925','1.112378321205493','test'),('2019-10-28 23:59:59','2019-10-29 11:59:59','REPBNB','4h','0.448300000000000','0.441600000000000','0.587335753596500','0.578557815722093','1.3101399812547403','1.310139981254740','test'),('2019-10-30 03:59:59','2019-10-30 07:59:59','REPBNB','4h','0.456400000000000','0.446700000000000','0.587335753596500','0.574852938500343','1.2868881542429889','1.286888154242989','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:37:34
