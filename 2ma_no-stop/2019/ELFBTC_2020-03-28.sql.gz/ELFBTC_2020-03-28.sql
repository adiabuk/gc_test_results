-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-02 23:59:59','ELFBTC','4h','0.000030450000000','0.000029910000000','0.001467500000000','0.001441475369458','48.19376026272578','48.193760262725782','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','ELFBTC','4h','0.000030090000000','0.000030080000000','0.001467500000000','0.001467012296444','48.77035559986707','48.770355599867067','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','ELFBTC','4h','0.000029500000000','0.000029900000000','0.001467500000000','0.001487398305085','49.74576271186441','49.745762711864408','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','ELFBTC','4h','0.000030470000000','0.000030220000000','0.001467500000000','0.001455459468330','48.16212668198228','48.162126681982279','test'),('2019-02-07 03:59:59','2019-02-09 11:59:59','ELFBTC','4h','0.000030040000000','0.000030160000000','0.001467500000000','0.001473362183755','48.85153129161119','48.851531291611188','test'),('2019-02-10 11:59:59','2019-02-11 15:59:59','ELFBTC','4h','0.000030490000000','0.000030030000000','0.001467500000000','0.001445359954083','48.13053460150869','48.130534601508693','test'),('2019-02-13 03:59:59','2019-02-13 07:59:59','ELFBTC','4h','0.000030280000000','0.000030040000000','0.001467500000000','0.001455868560106','48.46433289299868','48.464332892998677','test'),('2019-02-13 15:59:59','2019-02-13 23:59:59','ELFBTC','4h','0.000030030000000','0.000030100000000','0.001467500000000','0.001470920745921','48.867798867798875','48.867798867798875','test'),('2019-02-14 19:59:59','2019-02-15 03:59:59','ELFBTC','4h','0.000030110000000','0.000030510000000','0.001467500000000','0.001486995184324','48.737960810362004','48.737960810362004','test'),('2019-03-06 03:59:59','2019-03-07 07:59:59','ELFBTC','4h','0.000038450000000','0.000038620000000','0.001467500000000','0.001473988296489','38.1664499349805','38.166449934980498','test'),('2019-03-17 15:59:59','2019-03-18 03:59:59','ELFBTC','4h','0.000042670000000','0.000042150000000','0.001467500000000','0.001449616240919','34.39184438715725','34.391844387157249','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','ELFBTC','4h','0.000042250000000','0.000042030000000','0.001467500000000','0.001459858579882','34.73372781065089','34.733727810650890','test'),('2019-03-20 23:59:59','2019-03-21 15:59:59','ELFBTC','4h','0.000042660000000','0.000042180000000','0.001467500000000','0.001450988045007','34.39990623534927','34.399906235349270','test'),('2019-04-04 11:59:59','2019-04-06 15:59:59','ELFBTC','4h','0.000044650000000','0.000044130000000','0.001467500000000','0.001450409294513','32.86674132138858','32.866741321388581','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','ELFBTC','4h','0.000037950000000','0.000035880000000','0.001467500000000','0.001387454545455','38.669301712779976','38.669301712779976','test'),('2019-05-15 19:59:59','2019-05-16 11:59:59','ELFBTC','4h','0.000026660000000','0.000026330000000','0.001467500000000','0.001449335146287','55.04501125281321','55.045011252813211','test'),('2019-05-28 03:59:59','2019-05-28 11:59:59','ELFBTC','4h','0.000029980000000','0.000028540000000','0.001467500000000','0.001397013008672','48.949299533022014','48.949299533022014','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','ELFBTC','4h','0.000025930000000','0.000024870000000','0.001467500000000','0.001407509641342','56.594677979174705','56.594677979174705','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','ELFBTC','4h','0.000025480000000','0.000025310000000','0.001467500000000','0.001457708987441','57.594191522762955','57.594191522762955','test'),('2019-06-09 11:59:59','2019-06-09 15:59:59','ELFBTC','4h','0.000025480000000','0.000024710000000','0.001467500000000','0.001423152472527','57.594191522762955','57.594191522762955','test'),('2019-06-10 07:59:59','2019-06-10 15:59:59','ELFBTC','4h','0.000026730000000','0.000026260000000','0.001467500000000','0.001441696595585','54.90086045641601','54.900860456416012','test'),('2019-07-01 15:59:59','2019-07-03 03:59:59','ELFBTC','4h','0.000019170000000','0.000018390000000','0.001467500000000','0.001407789514867','76.55190401669275','76.551904016692745','test'),('2019-07-04 11:59:59','2019-07-04 19:59:59','ELFBTC','4h','0.000019320000000','0.000018760000000','0.001467500000000','0.001424963768116','75.9575569358178','75.957556935817806','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','ELFBTC','4h','0.000013560000000','0.000013070000000','0.001467500000000','0.001414470870206','108.22271386430678','108.222713864306783','test'),('2019-07-26 19:59:59','2019-07-26 23:59:59','ELFBTC','4h','0.000013140000000','0.000013140000000','0.001467500000000','0.001467500000000','111.68188736681888','111.681887366818884','test'),('2019-07-29 07:59:59','2019-07-29 11:59:59','ELFBTC','4h','0.000013240000000','0.000013190000000','0.001467500000000','0.001461958081571','110.83836858006042','110.838368580060418','test'),('2019-08-17 15:59:59','2019-08-18 03:59:59','ELFBTC','4h','0.000008800000000','0.000008640000000','0.001467500000000','0.001440818181818','166.76136363636363','166.761363636363626','test'),('2019-08-24 15:59:59','2019-08-25 15:59:59','ELFBTC','4h','0.000008620000000','0.000008290000000','0.001467500000000','0.001411319605568','170.24361948955917','170.243619489559165','test'),('2019-09-01 07:59:59','2019-09-01 11:59:59','ELFBTC','4h','0.000008230000000','0.000008240000000','0.001467500000000','0.001469283110571','178.31105710814094','178.311057108140943','test'),('2019-09-02 11:59:59','2019-09-02 15:59:59','ELFBTC','4h','0.000008170000000','0.000008020000000','0.001467500000000','0.001440556915545','179.62056303549573','179.620563035495735','test'),('2019-09-08 15:59:59','2019-09-08 23:59:59','ELFBTC','4h','0.000008070000000','0.000007970000000','0.001467500000000','0.001449315365551','181.84634448574968','181.846344485749682','test'),('2019-09-11 19:59:59','2019-09-11 23:59:59','ELFBTC','4h','0.000008070000000','0.000007930000000','0.001467500000000','0.001442041511772','181.84634448574968','181.846344485749682','test'),('2019-09-12 15:59:59','2019-09-12 19:59:59','ELFBTC','4h','0.000007980000000','0.000007940000000','0.001467500000000','0.001460144110276','183.89724310776944','183.897243107769441','test'),('2019-09-13 15:59:59','2019-09-13 19:59:59','ELFBTC','4h','0.000008000000000','0.000007910000000','0.001467500000000','0.001450990625000','183.43750000000003','183.437500000000028','test'),('2019-09-16 11:59:59','2019-09-16 15:59:59','ELFBTC','4h','0.000007970000000','0.000008030000000','0.001467500000000','0.001478547678795','184.1279799247177','184.127979924717692','test'),('2019-09-20 07:59:59','2019-09-20 11:59:59','ELFBTC','4h','0.000008170000000','0.000008230000000','0.001467500000000','0.001478277233782','179.62056303549573','179.620563035495735','test'),('2019-09-25 19:59:59','2019-10-01 19:59:59','ELFBTC','4h','0.000008250000000','0.000008880000000','0.001467500000000','0.001579563636364','177.87878787878788','177.878787878787875','test'),('2019-10-11 23:59:59','2019-10-12 07:59:59','ELFBTC','4h','0.000009510000000','0.000009340000000','0.001467500000000','0.001441267087277','154.3112513144059','154.311251314405894','test'),('2019-10-13 15:59:59','2019-10-16 15:59:59','ELFBTC','4h','0.000009660000000','0.000009680000000','0.001467500000000','0.001470538302277','151.9151138716356','151.915113871635612','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','ELFBTC','4h','0.000009970000000','0.000009940000000','0.001467500000000','0.001463084252758','147.19157472417254','147.191574724172540','test'),('2019-10-27 19:59:59','2019-10-27 23:59:59','ELFBTC','4h','0.000009790000000','0.000010040000000','0.001467500000000','0.001504974463739','149.89785495403476','149.897854954034756','test'),('2019-10-30 23:59:59','2019-10-31 03:59:59','ELFBTC','4h','0.000009810000000','0.000009670000000','0.001467500000000','0.001446557084608','149.592252803262','149.592252803261999','test'),('2019-10-31 19:59:59','2019-11-01 03:59:59','ELFBTC','4h','0.000009830000000','0.000009780000000','0.001467500000000','0.001460035605290','149.2878942014242','149.287894201424194','test'),('2019-11-04 11:59:59','2019-11-04 15:59:59','ELFBTC','4h','0.000009840000000','0.000009810000000','0.001467500000000','0.001463025914634','149.1361788617886','149.136178861788608','test'),('2019-11-14 15:59:59','2019-11-14 23:59:59','ELFBTC','4h','0.000009490000000','0.000009440000000','0.001467500000000','0.001459768177028','154.63645943097998','154.636459430979983','test'),('2019-11-18 19:59:59','2019-11-18 23:59:59','ELFBTC','4h','0.000009650000000','0.000009850000000','0.001467500000000','0.001497914507772','152.07253886010363','152.072538860103634','test'),('2019-12-01 11:59:59','2019-12-02 07:59:59','ELFBTC','4h','0.000009450000000','0.000008910000000','0.001467500000000','0.001383642857143','155.29100529100532','155.291005291005320','test'),('2019-12-30 23:59:59','2019-12-31 03:59:59','ELFBTC','4h','0.000007050000000','0.000007150000000','0.001467500000000','0.001488315602837','208.15602836879432','208.156028368794324','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:43:00
