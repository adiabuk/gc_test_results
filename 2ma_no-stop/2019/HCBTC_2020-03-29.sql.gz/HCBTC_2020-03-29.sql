-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-07 15:59:59','2019-02-07 19:59:59','HCBTC','4h','0.000271400000000','0.000266900000000','0.001467500000000','0.001443167833456','5.407148120854828','5.407148120854828','test'),('2019-02-08 11:59:59','2019-02-14 11:59:59','HCBTC','4h','0.000312900000000','0.000300500000000','0.001467500000000','0.001409344039629','4.689996804090764','4.689996804090764','test'),('2019-02-19 11:59:59','2019-02-19 15:59:59','HCBTC','4h','0.000307200000000','0.000304300000000','0.001467500000000','0.001453646647135','4.777018229166667','4.777018229166667','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','HCBTC','4h','0.000306700000000','0.000302900000000','0.001467500000000','0.001449317737202','4.784805999347897','4.784805999347897','test'),('2019-02-24 11:59:59','2019-02-24 15:59:59','HCBTC','4h','0.000301700000000','0.000294300000000','0.001467500000000','0.001431505634736','4.864103413987404','4.864103413987404','test'),('2019-02-26 15:59:59','2019-02-27 03:59:59','HCBTC','4h','0.000304200000000','0.000303000000000','0.001467500000000','0.001461711045365','4.824128862590401','4.824128862590401','test'),('2019-02-28 03:59:59','2019-02-28 07:59:59','HCBTC','4h','0.000299900000000','0.000299200000000','0.001467500000000','0.001464074691564','4.893297765921973','4.893297765921973','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','HCBTC','4h','0.000299500000000','0.000299500000000','0.001467500000000','0.001467500000000','4.899833055091819','4.899833055091819','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','HCBTC','4h','0.000300700000000','0.000298300000000','0.001467500000000','0.001455787329564','4.880279348187563','4.880279348187563','test'),('2019-03-07 07:59:59','2019-03-07 15:59:59','HCBTC','4h','0.000298500000000','0.000295200000000','0.001467500000000','0.001451276381910','4.916247906197655','4.916247906197655','test'),('2019-03-08 11:59:59','2019-03-20 07:59:59','HCBTC','4h','0.000304500000000','0.000326600000000','0.001467500000000','0.001574008210181','4.819376026272579','4.819376026272579','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','HCBTC','4h','0.000331900000000','0.000322900000000','0.001467500000000','0.001427706387466','4.421512503766195','4.421512503766195','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','HCBTC','4h','0.000328000000000','0.000328100000000','0.001467500000000','0.001467947408537','4.474085365853659','4.474085365853659','test'),('2019-03-26 19:59:59','2019-03-28 15:59:59','HCBTC','4h','0.000338000000000','0.000338200000000','0.001467500000000','0.001468368343195','4.341715976331361','4.341715976331361','test'),('2019-03-29 23:59:59','2019-03-30 07:59:59','HCBTC','4h','0.000340600000000','0.000338100000000','0.001467500000000','0.001456728567234','4.30857310628303','4.308573106283030','test'),('2019-03-30 23:59:59','2019-03-31 03:59:59','HCBTC','4h','0.000338800000000','0.000336300000000','0.001467500000000','0.001456671340024','4.3314639905549','4.331463990554900','test'),('2019-03-31 07:59:59','2019-03-31 11:59:59','HCBTC','4h','0.000338000000000','0.000338900000000','0.001467500000000','0.001471407544379','4.341715976331361','4.341715976331361','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','HCBTC','4h','0.000176500000000','0.000173900000000','0.001467500000000','0.001445882436261','8.314447592067989','8.314447592067989','test'),('2019-05-16 19:59:59','2019-05-16 23:59:59','HCBTC','4h','0.000177300000000','0.000171100000000','0.001467500000000','0.001416183023125','8.276931754089114','8.276931754089114','test'),('2019-05-17 03:59:59','2019-05-17 07:59:59','HCBTC','4h','0.000173900000000','0.000173000000000','0.001467500000000','0.001459905117884','8.438757906843014','8.438757906843014','test'),('2019-05-18 11:59:59','2019-05-18 15:59:59','HCBTC','4h','0.000174100000000','0.000172300000000','0.001467500000000','0.001452327685238','8.429063756461805','8.429063756461805','test'),('2019-05-30 03:59:59','2019-06-22 03:59:59','HCBTC','4h','0.000164800000000','0.000310900000000','0.001467500000000','0.002768481492718','8.904733009708739','8.904733009708739','test'),('2019-07-03 19:59:59','2019-07-08 07:59:59','HCBTC','4h','0.000409100000000','0.000417900000000','0.001734487224201','0.001771797142492','4.2397634421920065','4.239763442192007','test'),('2019-07-24 15:59:59','2019-07-25 11:59:59','HCBTC','4h','0.000318900000000','0.000307900000000','0.001743814703773','0.001683664306340','5.468217948490121','5.468217948490121','test'),('2019-07-26 11:59:59','2019-07-26 19:59:59','HCBTC','4h','0.000313200000000','0.000309500000000','0.001743814703773','0.001723214083071','5.567735324945721','5.567735324945721','test'),('2019-08-17 15:59:59','2019-08-24 03:59:59','HCBTC','4h','0.000234000000000','0.000245400000000','0.001743814703773','0.001828769779085','7.452199588773504','7.452199588773504','test'),('2019-08-24 15:59:59','2019-08-24 19:59:59','HCBTC','4h','0.000246500000000','0.000245800000000','0.001744865718068','0.001739910724142','7.078562750781947','7.078562750781947','test'),('2019-08-25 03:59:59','2019-08-25 07:59:59','HCBTC','4h','0.000247800000000','0.000243000000000','0.001744865718068','0.001711066866386','7.041427433688458','7.041427433688458','test'),('2019-08-25 11:59:59','2019-08-25 15:59:59','HCBTC','4h','0.000251200000000','0.000245600000000','0.001744865718068','0.001705967437729','6.946121489124204','6.946121489124204','test'),('2019-08-28 19:59:59','2019-08-28 23:59:59','HCBTC','4h','0.000238700000000','0.000233400000000','0.001744865718068','0.001706123412640','7.30986894875576','7.309868948755760','test'),('2019-09-08 07:59:59','2019-09-08 15:59:59','HCBTC','4h','0.000220700000000','0.000214600000000','0.001744865718068','0.001696638799716','7.906052188799275','7.906052188799275','test'),('2019-09-14 19:59:59','2019-09-14 23:59:59','HCBTC','4h','0.000208200000000','0.000208000000000','0.001744865718068','0.001743189574247','8.380719106954851','8.380719106954851','test'),('2019-09-17 15:59:59','2019-09-19 23:59:59','HCBTC','4h','0.000212600000000','0.000212200000000','0.001744865718068','0.001741582809850','8.207270545945438','8.207270545945438','test'),('2019-09-21 03:59:59','2019-09-21 07:59:59','HCBTC','4h','0.000211400000000','0.000211000000000','0.001744865718068','0.001741564174609','8.25385864743614','8.253858647436140','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','HCBTC','4h','0.000201400000000','0.000199600000000','0.001744865718068','0.001729271089009','8.663682810665343','8.663682810665343','test'),('2019-10-01 03:59:59','2019-10-01 07:59:59','HCBTC','4h','0.000201400000000','0.000197100000000','0.001744865718068','0.001707611881982','8.663682810665343','8.663682810665343','test'),('2019-10-03 11:59:59','2019-10-03 15:59:59','HCBTC','4h','0.000200100000000','0.000199600000000','0.001744865718068','0.001740505733765','8.71996860603698','8.719968606036980','test'),('2019-10-03 19:59:59','2019-10-03 23:59:59','HCBTC','4h','0.000202500000000','0.000200100000000','0.001744865718068','0.001724185828076','8.616620829965433','8.616620829965433','test'),('2019-10-07 03:59:59','2019-10-07 07:59:59','HCBTC','4h','0.000202400000000','0.000197900000000','0.001744865718068','0.001706071766826','8.620878053695654','8.620878053695654','test'),('2019-10-27 15:59:59','2019-10-30 07:59:59','HCBTC','4h','0.000188700000000','0.000187200000000','0.001744865718068','0.001730995561327','9.246771160932697','9.246771160932697','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','HCBTC','4h','0.000165000000000','0.000169700000000','0.001744865718068','0.001794567953674','10.574943745866667','10.574943745866667','test'),('2019-12-14 23:59:59','2019-12-15 03:59:59','HCBTC','4h','0.000164400000000','0.000165700000000','0.001744865718068','0.001758663318028','10.613538431070559','10.613538431070559','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','HCBTC','4h','0.000165900000000','0.000162000000000','0.001744865718068','0.001703847174967','10.517575154116939','10.517575154116939','test'),('2019-12-31 11:59:59','2019-12-31 15:59:59','HCBTC','4h','0.000153700000000','0.000152600000000','0.001744865718068','0.001732378064913','11.352411958802863','11.352411958802863','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','HCBTC','4h','0.000154200000000','0.000152800000000','0.001744865718068','0.001729023876270','11.315601284487677','11.315601284487677','test'),('2020-01-01 15:59:59','2020-01-01 19:59:59','HCBTC','4h','0.000153700000000','0.000153700000000','0.001744865718068','0.001744865718068','11.352411958802863','11.352411958802863','test'),('2020-01-06 15:59:59','2020-01-06 19:59:59','HCBTC','4h','0.000150900000000','0.000149800000000','0.001744865718068','0.001732146352330','11.563059761882041','11.563059761882041','test'),('2020-01-07 03:59:59','2020-01-07 07:59:59','HCBTC','4h','0.000150600000000','0.000150300000000','0.001744865718068','0.001741389889944','11.586093745471448','11.586093745471448','test'),('2020-01-10 23:59:59','2020-01-11 03:59:59','HCBTC','4h','0.000148900000000','0.000147300000000','0.001744865718068','0.001726116321500','11.71837285472129','11.718372854721290','test'),('2020-01-11 07:59:59','2020-01-11 11:59:59','HCBTC','4h','0.000149200000000','0.000148100000000','0.001744865718068','0.001732001426581','11.694810442815013','11.694810442815013','test'),('2020-01-14 15:59:59','2020-01-14 19:59:59','HCBTC','4h','0.000150400000000','0.000154700000000','0.001744865718068','0.001794752171444','11.601500785026596','11.601500785026596','test'),('2020-01-23 19:59:59','2020-01-23 23:59:59','HCBTC','4h','0.000164100000000','0.000164500000000','0.001744865718068','0.001749118894712','10.632941609189519','10.632941609189519','test'),('2020-01-24 15:59:59','2020-01-24 19:59:59','HCBTC','4h','0.000163700000000','0.000162400000000','0.001744865718068','0.001731009117986','10.658923140305436','10.658923140305436','test'),('2020-01-29 07:59:59','2020-01-29 11:59:59','HCBTC','4h','0.000167100000000','0.000164700000000','0.001744865718068','0.001719804810089','10.442044991430281','10.442044991430281','test'),('2020-01-29 19:59:59','2020-01-30 03:59:59','HCBTC','4h','0.000167200000000','0.000165100000000','0.001744865718068','0.001722950538595','10.435799749210526','10.435799749210526','test'),('2020-01-30 11:59:59','2020-02-04 15:59:59','HCBTC','4h','0.000166400000000','0.000184000000000','0.001744865718068','0.001929418822864','10.485971863389423','10.485971863389423','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:54:28
