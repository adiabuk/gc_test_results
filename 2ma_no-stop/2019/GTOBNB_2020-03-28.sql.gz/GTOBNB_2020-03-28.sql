-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 11:59:59','2019-01-03 23:59:59','GTOBNB','4h','0.004470000000000','0.004400000000000','0.711908500000000','0.700760044742729','159.2636465324385','159.263646532438486','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','GTOBNB','4h','0.004340000000000','0.004350000000000','0.711908500000000','0.713548842165899','164.03421658986176','164.034216589861757','test'),('2019-01-07 23:59:59','2019-01-08 03:59:59','GTOBNB','4h','0.004390000000000','0.004320000000000','0.711908500000000','0.700556883826879','162.16594533029615','162.165945330296154','test'),('2019-01-15 03:59:59','2019-01-18 11:59:59','GTOBNB','4h','0.004380000000000','0.004390000000000','0.711908500000000','0.713533861872146','162.53618721461189','162.536187214611886','test'),('2019-01-19 11:59:59','2019-01-19 15:59:59','GTOBNB','4h','0.004570000000000','0.004450000000000','0.711908500000000','0.693215060175055','155.77866520787745','155.778665207877452','test'),('2019-01-22 11:59:59','2019-01-22 15:59:59','GTOBNB','4h','0.004430000000000','0.004410000000000','0.711908500000000','0.708694466139955','160.70169300225734','160.701693002257343','test'),('2019-01-25 03:59:59','2019-01-25 11:59:59','GTOBNB','4h','0.004570000000000','0.004410000000000','0.711908500000000','0.686983913566740','155.77866520787745','155.778665207877452','test'),('2019-02-17 07:59:59','2019-02-17 15:59:59','GTOBNB','4h','0.003210000000000','0.003110000000000','0.711908500000000','0.689730665109034','221.77834890965732','221.778348909657325','test'),('2019-02-26 03:59:59','2019-02-27 23:59:59','GTOBNB','4h','0.003040000000000','0.003020000000000','0.711908500000000','0.707224891447369','234.18042763157897','234.180427631578965','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','GTOBNB','4h','0.003000000000000','0.003010000000000','0.711908500000000','0.714281528333333','237.30283333333335','237.302833333333353','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','GTOBNB','4h','0.002430000000000','0.002380000000000','0.711908500000000','0.697260176954733','292.96646090534983','292.966460905349834','test'),('2019-03-13 23:59:59','2019-03-14 15:59:59','GTOBNB','4h','0.002430000000000','0.002420000000000','0.711908500000000','0.708978835390947','292.96646090534983','292.966460905349834','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','GTOBNB','4h','0.002360000000000','0.002370000000000','0.711908500000000','0.714925061440678','301.6561440677966','301.656144067796617','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','GTOBNB','4h','0.002370000000000','0.002330000000000','0.711908500000000','0.699893166666667','300.3833333333333','300.383333333333326','test'),('2019-03-29 19:59:59','2019-03-29 23:59:59','GTOBNB','4h','0.002190000000000','0.002220000000000','0.711908500000000','0.721660671232877','325.07237442922377','325.072374429223771','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','GTOBNB','4h','0.002210000000000','0.002140000000000','0.711908500000000','0.689359361990950','322.1305429864253','322.130542986425326','test'),('2019-04-08 03:59:59','2019-04-08 07:59:59','GTOBNB','4h','0.002090000000000','0.002050000000000','0.711908500000000','0.698283456937799','340.626076555024','340.626076555023985','test'),('2019-04-08 23:59:59','2019-04-09 03:59:59','GTOBNB','4h','0.002080000000000','0.002070000000000','0.711908500000000','0.708485862980769','342.263701923077','342.263701923077008','test'),('2019-04-10 07:59:59','2019-04-10 23:59:59','GTOBNB','4h','0.002080000000000','0.002030000000000','0.711908500000000','0.694795314903846','342.263701923077','342.263701923077008','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','GTOBNB','4h','0.001910000000000','0.001780000000000','0.711908500000000','0.663453994764398','372.72696335078535','372.726963350785354','test'),('2019-04-24 07:59:59','2019-04-24 11:59:59','GTOBNB','4h','0.001770000000000','0.001620000000000','0.711908500000000','0.651577271186441','402.20819209039547','402.208192090395471','test'),('2019-05-21 03:59:59','2019-05-21 23:59:59','GTOBNB','4h','0.001230000000000','0.001040000000000','0.711908500000000','0.601938894308943','578.7873983739838','578.787398373983820','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','GTOBNB','4h','0.001110000000000','0.001040000000000','0.711908500000000','0.667013369369369','641.359009009009','641.359009009009014','test'),('2019-05-26 03:59:59','2019-05-26 07:59:59','GTOBNB','4h','0.001090000000000','0.001050000000000','0.711908500000000','0.685783417431193','653.1270642201835','653.127064220183456','test'),('2019-07-01 03:59:59','2019-07-02 07:59:59','GTOBNB','4h','0.000850000000000','0.000790000000000','0.711908500000000','0.661656135294118','837.539411764706','837.539411764705960','test'),('2019-07-08 03:59:59','2019-07-08 07:59:59','GTOBNB','4h','0.000790000000000','0.000810000000000','0.711908500000000','0.729931500000000','901.1500000000001','901.150000000000091','test'),('2019-07-09 15:59:59','2019-07-09 19:59:59','GTOBNB','4h','0.000790000000000','0.000800000000000','0.711908500000000','0.720920000000000','901.1500000000001','901.150000000000091','test'),('2019-07-23 11:59:59','2019-07-25 19:59:59','GTOBNB','4h','0.000670000000000','0.000661000000000','0.711908500000000','0.702345550000000','1062.55','1062.549999999999955','test'),('2019-07-25 23:59:59','2019-07-26 19:59:59','GTOBNB','4h','0.000668000000000','0.000664000000000','0.711908500000000','0.707645574850300','1065.7312874251497','1065.731287425149731','test'),('2019-08-22 11:59:59','2019-08-22 19:59:59','GTOBNB','4h','0.000495000000000','0.000477000000000','0.711908500000000','0.686020918181818','1438.19898989899','1438.198989898990021','test'),('2019-08-23 23:59:59','2019-08-28 19:59:59','GTOBNB','4h','0.000499000000000','0.000509000000000','0.711908500000000','0.726175203406814','1426.6703406813629','1426.670340681362859','test'),('2019-09-06 03:59:59','2019-09-06 07:59:59','GTOBNB','4h','0.000560000000000','0.000554000000000','0.711908500000000','0.704280908928572','1271.2651785714288','1271.265178571428805','test'),('2019-09-09 19:59:59','2019-09-24 03:59:59','GTOBNB','4h','0.000551000000000','0.000644000000000','0.711908500000000','0.832067284936479','1292.0299455535392','1292.029945553539164','test'),('2019-10-31 23:59:59','2019-11-01 03:59:59','GTOBNB','4h','0.000665000000000','0.000673000000000','0.711908500000000','0.720472812781955','1070.539097744361','1070.539097744361015','test'),('2019-11-03 11:59:59','2019-11-04 03:59:59','GTOBNB','4h','0.000660000000000','0.000660000000000','0.711908500000000','0.711908500000000','1078.6492424242424','1078.649242424242402','test'),('2019-11-07 15:59:59','2019-11-07 23:59:59','GTOBNB','4h','0.000677000000000','0.000666000000000','0.711908500000000','0.700341301329395','1051.5635155096013','1051.563515509601302','test'),('2019-11-11 11:59:59','2019-11-12 03:59:59','GTOBNB','4h','0.000681000000000','0.000666000000000','0.711908500000000','0.696227696035242','1045.3869309838474','1045.386930983847378','test'),('2019-11-17 07:59:59','2019-11-21 15:59:59','GTOBNB','4h','0.000659000000000','0.000659000000000','0.711908500000000','0.711908500000000','1080.2860394537179','1080.286039453717876','test'),('2019-11-24 15:59:59','2019-11-24 19:59:59','GTOBNB','4h','0.000655000000000','0.000638000000000','0.711908500000000','0.693431485496183','1086.8832061068704','1086.883206106870375','test'),('2019-11-25 15:59:59','2019-11-27 11:59:59','GTOBNB','4h','0.000659000000000','0.000660000000000','0.711908500000000','0.712988786039454','1080.2860394537179','1080.286039453717876','test'),('2019-12-09 19:59:59','2019-12-09 23:59:59','GTOBNB','4h','0.000695000000000','0.000678000000000','0.711908500000000','0.694494910791367','1024.3287769784174','1024.328776978417409','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','GTOBNB','4h','0.000679000000000','0.000674000000000','0.711908500000000','0.706666169366716','1048.4661266568482','1048.466126656848246','test'),('2019-12-16 11:59:59','2019-12-16 15:59:59','GTOBNB','4h','0.000679000000000','0.000677000000000','0.711908500000000','0.709811567746686','1048.4661266568482','1048.466126656848246','test'),('2019-12-19 11:59:59','2019-12-19 15:59:59','GTOBNB','4h','0.000689000000000','0.000674000000000','0.711908500000000','0.696409766328012','1033.2489114658927','1033.248911465892661','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:54:53
