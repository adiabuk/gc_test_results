-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-10 11:59:59','NASETH','4h','0.004253000000000','0.004250000000000','0.072144500000000','0.072093610392664','16.96320244533271','16.963202445332708','test'),('2019-01-11 11:59:59','2019-01-12 07:59:59','NASETH','4h','0.004247000000000','0.004249000000000','0.072144500000000','0.072178474334825','16.98716741229103','16.987167412291029','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','NASETH','4h','0.004290000000000','0.004245000000000','0.072144500000000','0.071387739510490','16.816899766899766','16.816899766899766','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','NASETH','4h','0.004278000000000','0.004248000000000','0.072144500000000','0.071638577840112','16.864071996259934','16.864071996259934','test'),('2019-01-15 23:59:59','2019-01-30 15:59:59','NASETH','4h','0.004342000000000','0.004872000000000','0.072144500000000','0.080950714877936','16.615499769691386','16.615499769691386','test'),('2019-02-01 15:59:59','2019-02-02 15:59:59','NASETH','4h','0.004854000000000','0.004838000000000','0.074026154239007','0.073782145489970','15.250546814793314','15.250546814793314','test'),('2019-02-03 11:59:59','2019-02-04 07:59:59','NASETH','4h','0.004865000000000','0.004852000000000','0.074026154239007','0.073828345399314','15.216064591779444','15.216064591779444','test'),('2019-02-06 03:59:59','2019-02-06 19:59:59','NASETH','4h','0.004893000000000','0.004862000000000','0.074026154239007','0.073557155509923','15.12899126078214','15.128991260782140','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','NASETH','4h','0.004853000000000','0.004838000000000','0.074026154239007','0.073797348899303','15.253689313621885','15.253689313621885','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','NASETH','4h','0.004851000000000','0.004776000000000','0.074026154239007','0.072881655874149','15.259978198104927','15.259978198104927','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','NASETH','4h','0.004600000000000','0.004562000000000','0.074026154239007','0.073414633834424','16.09264222587109','16.092642225871089','test'),('2019-02-23 03:59:59','2019-02-23 19:59:59','NASETH','4h','0.004502000000000','0.004184000000000','0.074026154239007','0.068797296609508','16.442948520436918','16.442948520436918','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','NASETH','4h','0.004421000000000','0.004278000000000','0.074026154239007','0.071631732149847','16.744210413708892','16.744210413708892','test'),('2019-02-24 19:59:59','2019-02-25 15:59:59','NASETH','4h','0.004372000000000','0.004365000000000','0.074026154239007','0.073907631119228','16.93187425411871','16.931874254118711','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','NASETH','4h','0.004599000000000','0.004585000000000','0.074026154239007','0.073800808259588','16.096141387042184','16.096141387042184','test'),('2019-04-10 19:59:59','2019-04-11 03:59:59','NASETH','4h','0.006911000000000','0.006855000000000','0.074026154239007','0.073426318522413','10.711352082044135','10.711352082044135','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','NASETH','4h','0.004498000000000','0.004467000000000','0.074026154239007','0.073515969538827','16.457570973545355','16.457570973545355','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','NASETH','4h','0.004442000000000','0.004391000000000','0.074026154239007','0.073176236664448','16.665050481541424','16.665050481541424','test'),('2019-06-07 03:59:59','2019-06-08 15:59:59','NASETH','4h','0.004419000000000','0.004444000000000','0.074026154239007','0.074444948956358','16.751788694050013','16.751788694050013','test'),('2019-06-18 23:59:59','2019-06-19 11:59:59','NASETH','4h','0.005826000000000','0.005878000000000','0.074026154239007','0.074686875148796','12.706171342088398','12.706171342088398','test'),('2019-06-23 15:59:59','2019-06-23 23:59:59','NASETH','4h','0.005814000000000','0.005788000000000','0.074026154239007','0.073695111925589','12.732396669935847','12.732396669935847','test'),('2019-07-01 11:59:59','2019-07-01 15:59:59','NASETH','4h','0.005413000000000','0.005241000000000','0.074026154239007','0.071673946862486','13.675624282099944','13.675624282099944','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','NASETH','4h','0.005267000000000','0.005479000000000','0.074026154239007','0.077005752624932','14.054709367573002','14.054709367573002','test'),('2019-07-04 07:59:59','2019-07-06 19:59:59','NASETH','4h','0.005416000000000','0.005325000000000','0.074026154239007','0.072782361765641','13.668049157866877','13.668049157866877','test'),('2019-07-06 23:59:59','2019-07-07 03:59:59','NASETH','4h','0.005436000000000','0.005292000000000','0.074026154239007','0.072065196510821','13.617762001289','13.617762001289000','test'),('2019-07-22 03:59:59','2019-07-22 07:59:59','NASETH','4h','0.004300000000000','0.004232000000000','0.074026154239007','0.072855508078948','17.215384706745816','17.215384706745816','test'),('2019-07-22 11:59:59','2019-07-22 15:59:59','NASETH','4h','0.004277000000000','0.004310000000000','0.074026154239007','0.074597316990910','17.307962178865324','17.307962178865324','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','NASETH','4h','0.004317000000000','0.004294000000000','0.074026154239007','0.073631759625271','17.14759190155363','17.147591901553628','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','NASETH','4h','0.004273000000000','0.004192000000000','0.074026154239007','0.072622896927198','17.324164343320152','17.324164343320152','test'),('2019-07-26 11:59:59','2019-07-27 03:59:59','NASETH','4h','0.004272000000000','0.004280000000000','0.074026154239007','0.074164779996009','17.32821962523572','17.328219625235722','test'),('2019-07-28 15:59:59','2019-07-28 19:59:59','NASETH','4h','0.004270000000000','0.004299000000000','0.074026154239007','0.074528907979740','17.33633588735527','17.336335887355268','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','NASETH','4h','0.004291000000000','0.004218000000000','0.074026154239007','0.072766795287842','17.25149248170753','17.251492481707530','test'),('2019-07-31 19:59:59','2019-07-31 23:59:59','NASETH','4h','0.004264000000000','0.004205000000000','0.074026154239007','0.073001871147989','17.360730356239916','17.360730356239916','test'),('2019-08-01 03:59:59','2019-08-01 19:59:59','NASETH','4h','0.004355000000000','0.004243000000000','0.074026154239007','0.072122381730449','16.997968826408037','16.997968826408037','test'),('2019-08-02 07:59:59','2019-08-02 11:59:59','NASETH','4h','0.004275000000000','0.004253000000000','0.074026154239007','0.073645200930643','17.316059471112748','17.316059471112748','test'),('2019-08-02 23:59:59','2019-08-03 03:59:59','NASETH','4h','0.004292000000000','0.004234000000000','0.074026154239007','0.073025800803345','17.247473028659602','17.247473028659602','test'),('2019-08-03 11:59:59','2019-08-05 03:59:59','NASETH','4h','0.004613000000000','0.004329000000000','0.074026154239007','0.069468723542307','16.04729118556406','16.047291185564060','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','NASETH','4h','0.003631000000000','0.003615000000000','0.074026154239007','0.073699958020934','20.387263629580556','20.387263629580556','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','NASETH','4h','0.003696000000000','0.003584000000000','0.074026154239007','0.071782937443886','20.028721385012716','20.028721385012716','test'),('2019-08-23 19:59:59','2019-08-27 03:59:59','NASETH','4h','0.003666000000000','0.003741000000000','0.074026154239007','0.075540600929658','20.19262254200955','20.192622542009548','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','NASETH','4h','0.003883000000000','0.003849000000000','0.074026154239007','0.073377972615487','19.0641653976325','19.064165397632500','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','NASETH','4h','0.003877000000000','0.003853000000000','0.074026154239007','0.073567906185941','19.093668877742328','19.093668877742328','test'),('2019-09-30 07:59:59','2019-09-30 11:59:59','NASETH','4h','0.002956000000000','0.002893000000000','0.074026154239007','0.072448465566119','25.04267734743133','25.042677347431329','test'),('2019-10-06 11:59:59','2019-10-09 15:59:59','NASETH','4h','0.002877000000000','0.002850000000000','0.074026154239007','0.073331435377536','25.730328202644078','25.730328202644078','test'),('2019-10-09 23:59:59','2019-10-10 03:59:59','NASETH','4h','0.002936000000000','0.002912000000000','0.074026154239007','0.073421035811985','25.21326779257732','25.213267792577319','test'),('2019-10-21 15:59:59','2019-10-22 03:59:59','NASETH','4h','0.002700000000000','0.002732000000000','0.074026154239007','0.074903501252210','27.417094162595184','27.417094162595184','test'),('2019-10-23 03:59:59','2019-10-23 07:59:59','NASETH','4h','0.002711000000000','0.002707000000000','0.074026154239007','0.073916930846548','27.3058481147204','27.305848114720401','test'),('2019-10-27 03:59:59','2019-11-04 23:59:59','NASETH','4h','0.002737000000000','0.003299000000000','0.074026154239007','0.089226263366637','27.04645752247242','27.046457522472419','test'),('2019-11-07 11:59:59','2019-11-08 11:59:59','NASETH','4h','0.003240000000000','0.003276000000000','0.074026154239007','0.074848667063885','22.847578468829322','22.847578468829322','test'),('2019-11-10 07:59:59','2019-11-10 11:59:59','NASETH','4h','0.003255000000000','0.003247000000000','0.074026154239007','0.073844215918297','22.742290088788636','22.742290088788636','test'),('2019-11-12 11:59:59','2019-11-15 15:59:59','NASETH','4h','0.003279000000000','0.003258000000000','0.074026154239007','0.073552061759892','22.57583233882495','22.575832338824949','test'),('2019-11-16 15:59:59','2019-11-16 19:59:59','NASETH','4h','0.003289000000000','0.003265000000000','0.074026154239007','0.073485981632824','22.507191924295228','22.507191924295228','test'),('2019-11-28 07:59:59','2019-11-28 15:59:59','NASETH','4h','0.002935000000000','0.002953000000000','0.074026154239007','0.074480147689195','25.221858343784326','25.221858343784326','test'),('2019-12-07 07:59:59','2019-12-07 11:59:59','NASETH','4h','0.002882000000000','0.002874000000000','0.074026154239007','0.073820668731057','25.685688493756768','25.685688493756768','test'),('2019-12-11 15:59:59','2019-12-11 23:59:59','NASETH','4h','0.002876000000000','0.002885000000000','0.074026154239007','0.074257807711939','25.739274770169335','25.739274770169335','test'),('2019-12-13 07:59:59','2019-12-13 11:59:59','NASETH','4h','0.002880000000000','0.002896000000000','0.074026154239007','0.074437410651446','25.703525777432986','25.703525777432986','test'),('2019-12-17 03:59:59','2019-12-17 07:59:59','NASETH','4h','0.002873000000000','0.002891000000000','0.074026154239007','0.074489944972144','25.76615184093526','25.766151840935262','test'),('2019-12-17 23:59:59','2019-12-18 03:59:59','NASETH','4h','0.002870000000000','0.002908000000000','0.074026154239007','0.075006291472834','25.793085100699304','25.793085100699304','test'),('2019-12-19 03:59:59','2019-12-22 11:59:59','NASETH','4h','0.002871000000000','0.002881000000000','0.074026154239007','0.074283995249941','25.784101093349708','25.784101093349708','test'),('2019-12-25 03:59:59','2019-12-25 15:59:59','NASETH','4h','0.002937000000000','0.002909000000000','0.074026154239007','0.073320423112452','25.20468309125196','25.204683091251962','test'),('2019-12-26 23:59:59','2019-12-27 03:59:59','NASETH','4h','0.002908000000000','0.002903000000000','0.074026154239007','0.073898874056340','25.456036533358667','25.456036533358667','test'),('2019-12-28 03:59:59','2019-12-28 07:59:59','NASETH','4h','0.002895000000000','0.002879000000000','0.074026154239007','0.073617028688809','25.570346887394475','25.570346887394475','test'),('2019-12-28 15:59:59','2019-12-28 19:59:59','NASETH','4h','0.002901000000000','0.002924000000000','0.074026154239007','0.074613055841040','25.51746095794795','25.517460957947950','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:08:15
