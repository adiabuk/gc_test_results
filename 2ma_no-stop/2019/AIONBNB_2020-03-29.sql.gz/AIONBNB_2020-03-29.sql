-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 07:59:59','2019-01-06 19:59:59','AIONBNB','4h','0.026430000000000','0.026460000000000','0.711908500000000','0.712716568671964','26.93562239878926','26.935622398789260','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','AIONBNB','4h','0.026660000000000','0.025770000000000','0.712110517167991','0.688337885499592','26.710822099324496','26.710822099324496','test'),('2019-01-19 07:59:59','2019-01-19 11:59:59','AIONBNB','4h','0.022630000000000','0.022000000000000','0.712110517167991','0.692285964546876','31.467543843039813','31.467543843039813','test'),('2019-02-26 23:59:59','2019-02-27 07:59:59','AIONBNB','4h','0.012200000000000','0.011990000000000','0.712110517167991','0.699852877118378','58.36971452196647','58.369714521966472','test'),('2019-03-13 03:59:59','2019-03-13 11:59:59','AIONBNB','4h','0.010000000000000','0.009580000000000','0.712110517167991','0.682201875446935','71.2110517167991','71.211051716799105','test'),('2019-03-13 23:59:59','2019-03-14 03:59:59','AIONBNB','4h','0.009610000000000','0.009530000000000','0.712110517167991','0.706182437940786','74.1009903400615','74.100990340061500','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','AIONBNB','4h','0.009670000000000','0.009260000000000','0.712110517167991','0.681917620369762','73.64121170299804','73.641211702998035','test'),('2019-03-19 23:59:59','2019-03-20 07:59:59','AIONBNB','4h','0.009350000000000','0.009490000000000','0.712110517167991','0.722773134537351','76.1615526382878','76.161552638287802','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','AIONBNB','4h','0.009480000000000','0.008420000000000','0.712110517167991','0.632486345417140','75.11714316118048','75.117143161180479','test'),('2019-03-27 19:59:59','2019-04-02 07:59:59','AIONBNB','4h','0.009070000000000','0.009490000000000','0.712110517167991','0.745085866364304','78.51273618169691','78.512736181696908','test'),('2019-04-18 03:59:59','2019-04-18 07:59:59','AIONBNB','4h','0.010130000000000','0.009490000000000','0.712110517167991','0.667120316675640','70.29718826929822','70.297188269298218','test'),('2019-05-01 07:59:59','2019-05-01 19:59:59','AIONBNB','4h','0.008180000000000','0.008040000000000','0.712110517167991','0.699922806605214','87.05507544840967','87.055075448409667','test'),('2019-05-03 15:59:59','2019-05-05 19:59:59','AIONBNB','4h','0.008200000000000','0.008250000000000','0.712110517167991','0.716452654467796','86.84274599609645','86.842745996096454','test'),('2019-05-14 15:59:59','2019-05-14 19:59:59','AIONBNB','4h','0.008890000000000','0.009210000000000','0.712110517167991','0.737743291689223','80.10242037885163','80.102420378851633','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','AIONBNB','4h','0.008990000000000','0.009200000000000','0.712110517167991','0.728744911896053','79.2114034669623','79.211403466962295','test'),('2019-05-31 19:59:59','2019-06-01 07:59:59','AIONBNB','4h','0.007020000000000','0.006600000000000','0.712110517167991','0.669505614431445','101.44024461082493','101.440244610824934','test'),('2019-07-07 19:59:59','2019-07-08 07:59:59','AIONBNB','4h','0.003990000000000','0.003880000000000','0.712110517167991','0.692478397647069','178.47381382656417','178.473813826564168','test'),('2019-07-24 07:59:59','2019-08-01 11:59:59','AIONBNB','4h','0.003119000000000','0.003813000000000','0.712110517167991','0.870560244296746','228.3137278512315','228.313727851231505','test'),('2019-08-18 19:59:59','2019-08-18 23:59:59','AIONBNB','4h','0.003045000000000','0.002800000000000','0.712110517167991','0.654814268660222','233.862238807222','233.862238807222013','test'),('2019-08-22 19:59:59','2019-08-23 15:59:59','AIONBNB','4h','0.002937000000000','0.003496000000000','0.712110517167991','0.847646703445453','242.46187169492373','242.461871694923730','test'),('2019-08-29 03:59:59','2019-08-29 15:59:59','AIONBNB','4h','0.003226000000000','0.003180000000000','0.713613864884030','0.703438341702175','221.20702569250773','221.207025692507727','test'),('2019-08-29 23:59:59','2019-08-30 03:59:59','AIONBNB','4h','0.003230000000000','0.003235000000000','0.713613864884030','0.714718530309547','220.93308510341487','220.933085103414868','test'),('2019-09-03 23:59:59','2019-09-04 03:59:59','AIONBNB','4h','0.003318000000000','0.003418000000000','0.713613864884030','0.735121214639426','215.0734975539572','215.073497553957196','test'),('2019-09-07 19:59:59','2019-09-08 03:59:59','AIONBNB','4h','0.003283000000000','0.003263000000000','0.716722987883794','0.712356719300889','218.3134291452313','218.313429145231311','test'),('2019-09-09 19:59:59','2019-09-14 23:59:59','AIONBNB','4h','0.003353000000000','0.003349000000000','0.716722987883794','0.715867964933739','213.75573751380674','213.755737513806736','test'),('2019-09-15 07:59:59','2019-09-18 11:59:59','AIONBNB','4h','0.003455000000000','0.003430000000000','0.716722987883794','0.711536859172623','207.4451484468289','207.445148446828910','test'),('2019-09-24 19:59:59','2019-09-30 23:59:59','AIONBNB','4h','0.003799000000000','0.004018000000000','0.716722987883794','0.758039738172436','188.6609602221095','188.660960222109509','test'),('2019-10-21 15:59:59','2019-10-21 19:59:59','AIONBNB','4h','0.003808000000000','0.003818000000000','0.724450320394922','0.726352763463186','190.24430682639763','190.244306826397633','test'),('2019-10-22 11:59:59','2019-10-22 15:59:59','AIONBNB','4h','0.003879000000000','0.003830000000000','0.724925931161988','0.715768578589949','186.88474636813308','186.884746368133079','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','AIONBNB','4h','0.003818000000000','0.003829000000000','0.724925931161988','0.727014507705409','189.8705948564662','189.870594856466198','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','AIONBNB','4h','0.003815000000000','0.003726000000000','0.724925931161988','0.708014159766597','190.0199033190008','190.019903319000804','test'),('2019-10-26 07:59:59','2019-10-26 11:59:59','AIONBNB','4h','0.003857000000000','0.003851000000000','0.724925931161988','0.723798226835576','187.95072106870313','187.950721068703132','test'),('2019-10-27 19:59:59','2019-10-27 23:59:59','AIONBNB','4h','0.003880000000000','0.003804000000000','0.724925931161988','0.710726351067062','186.83658019638864','186.836580196388638','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','AIONBNB','4h','0.003810000000000','0.003831000000000','0.724925931161988','0.728921585900676','190.26927327086298','190.269273270862982','test'),('2019-11-17 11:59:59','2019-11-20 23:59:59','AIONBNB','4h','0.004101000000000','0.004136000000000','0.724925931161988','0.731112814261396','176.768088554496','176.768088554495989','test'),('2019-11-25 23:59:59','2019-11-26 03:59:59','AIONBNB','4h','0.004082000000000','0.003957000000000','0.724925931161988','0.702727072417439','177.590869956391','177.590869956391003','test'),('2019-11-26 07:59:59','2019-11-26 11:59:59','AIONBNB','4h','0.004012000000000','0.004027000000000','0.724925931161988','0.727636272380191','180.68941454685643','180.689414546856426','test'),('2019-11-28 15:59:59','2019-11-28 23:59:59','AIONBNB','4h','0.004061000000000','0.004041000000000','0.724925931161988','0.721355746817433','178.50921722777343','178.509217227773433','test'),('2019-12-05 15:59:59','2019-12-06 07:59:59','AIONBNB','4h','0.004179000000000','0.004030000000000','0.724925931161988','0.699079086523764','173.46875596123186','173.468755961231864','test'),('2019-12-11 19:59:59','2019-12-12 03:59:59','AIONBNB','4h','0.004095000000000','0.004011000000000','0.724925931161988','0.710055655650973','177.0270894168469','177.027089416846906','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','AIONBNB','4h','0.003994000000000','0.003856000000000','0.724925931161988','0.699878415263051','181.50373839809413','181.503738398094129','test'),('2019-12-19 23:59:59','2019-12-23 03:59:59','AIONBNB','4h','0.003959000000000','0.004013000000000','0.724925931161988','0.734813781700697','183.10834330941856','183.108343309418558','test'),('2019-12-24 07:59:59','2019-12-24 11:59:59','AIONBNB','4h','0.004043000000000','0.004067000000000','0.724925931161988','0.729229226325947','179.30396516497353','179.303965164973533','test'),('2019-12-28 15:59:59','2019-12-28 19:59:59','AIONBNB','4h','0.004063000000000','0.004020000000000','0.724925931161988','0.717253813258969','178.42134658183315','178.421346581833149','test'),('2019-12-29 03:59:59','2019-12-29 15:59:59','AIONBNB','4h','0.004075000000000','0.003977000000000','0.724925931161988','0.707492129627295','177.89593402748173','177.895934027481729','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  2:19:19
