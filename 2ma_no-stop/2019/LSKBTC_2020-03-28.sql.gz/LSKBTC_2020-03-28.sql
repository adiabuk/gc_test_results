-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-17 07:59:59','2019-01-17 15:59:59','LSKBTC','4h','0.000341200000000','0.000339700000000','0.001467500000000','0.001461048505275','4.300996483001173','4.300996483001173','test'),('2019-01-22 19:59:59','2019-01-25 15:59:59','LSKBTC','4h','0.000350200000000','0.000345500000000','0.001467500000000','0.001447804825814','4.190462592804112','4.190462592804112','test'),('2019-02-10 19:59:59','2019-02-11 03:59:59','LSKBTC','4h','0.000319600000000','0.000317600000000','0.001467500000000','0.001458316645807','4.591677096370463','4.591677096370463','test'),('2019-02-11 11:59:59','2019-02-12 03:59:59','LSKBTC','4h','0.000321500000000','0.000317700000000','0.001467500000000','0.001450154743390','4.564541213063763','4.564541213063763','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','LSKBTC','4h','0.000320300000000','0.000319300000000','0.001467500000000','0.001462918357790','4.581642210427725','4.581642210427725','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','LSKBTC','4h','0.000319200000000','0.000318000000000','0.001467500000000','0.001461983082707','4.597431077694235','4.597431077694235','test'),('2019-02-16 15:59:59','2019-02-19 03:59:59','LSKBTC','4h','0.000322000000000','0.000321500000000','0.001467500000000','0.001465221273292','4.557453416149068','4.557453416149068','test'),('2019-02-23 03:59:59','2019-02-23 11:59:59','LSKBTC','4h','0.000320000000000','0.000317700000000','0.001467500000000','0.001456952343750','4.5859375','4.585937500000000','test'),('2019-02-23 19:59:59','2019-02-23 23:59:59','LSKBTC','4h','0.000320400000000','0.000314000000000','0.001467500000000','0.001438186641698','4.580212234706617','4.580212234706617','test'),('2019-02-26 19:59:59','2019-02-27 23:59:59','LSKBTC','4h','0.000320500000000','0.000317800000000','0.001467500000000','0.001455137285491','4.5787831513260535','4.578783151326054','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LSKBTC','4h','0.000318400000000','0.000316900000000','0.001467500000000','0.001460586526382','4.608982412060302','4.608982412060302','test'),('2019-02-28 19:59:59','2019-02-28 23:59:59','LSKBTC','4h','0.000318400000000','0.000318900000000','0.001467500000000','0.001469804491206','4.608982412060302','4.608982412060302','test'),('2019-03-02 23:59:59','2019-03-03 07:59:59','LSKBTC','4h','0.000320000000000','0.000319300000000','0.001467500000000','0.001464289843750','4.5859375','4.585937500000000','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','LSKBTC','4h','0.000317900000000','0.000318000000000','0.001467500000000','0.001467961623152','4.616231519345707','4.616231519345707','test'),('2019-03-10 23:59:59','2019-03-11 03:59:59','LSKBTC','4h','0.000326000000000','0.000324200000000','0.001467500000000','0.001459397239264','4.501533742331288','4.501533742331288','test'),('2019-03-11 23:59:59','2019-03-21 15:59:59','LSKBTC','4h','0.000333000000000','0.000369300000000','0.001467500000000','0.001627470720721','4.406906906906907','4.406906906906907','test'),('2019-04-03 07:59:59','2019-04-06 19:59:59','LSKBTC','4h','0.000404800000000','0.000419000000000','0.001474308537372','0.001526025882309','3.642066544891922','3.642066544891922','test'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LSKBTC','4h','0.000397800000000','0.000384700000000','0.001487237873606','0.001438261462987','3.7386572991616385','3.738657299161638','test'),('2019-04-16 07:59:59','2019-04-16 15:59:59','LSKBTC','4h','0.000398000000000','0.000391000000000','0.001487237873606','0.001461080423568','3.736778576899497','3.736778576899497','test'),('2019-04-17 07:59:59','2019-04-17 11:59:59','LSKBTC','4h','0.000394400000000','0.000390500000000','0.001487237873606','0.001472531413902','3.770887103463489','3.770887103463489','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','LSKBTC','4h','0.000282100000000','0.000269100000000','0.001487237873606','0.001418701566067','5.272023656880538','5.272023656880538','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','LSKBTC','4h','0.000290100000000','0.000273800000000','0.001487237873606','0.001403673663541','5.126638654277835','5.126638654277835','test'),('2019-05-30 03:59:59','2019-05-30 07:59:59','LSKBTC','4h','0.000250200000000','0.000254400000000','0.001487237873606','0.001512203497384','5.9441961375139885','5.944196137513988','test'),('2019-06-02 03:59:59','2019-06-02 11:59:59','LSKBTC','4h','0.000253000000000','0.000245300000000','0.001487237873606','0.001441974112235','5.878410567612648','5.878410567612648','test'),('2019-06-04 03:59:59','2019-06-04 07:59:59','LSKBTC','4h','0.000247200000000','0.000250500000000','0.001487237873606','0.001507091777259','6.016334440153722','6.016334440153722','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','LSKBTC','4h','0.000255500000000','0.000250400000000','0.001487237873606','0.001457551325053','5.8208918732133075','5.820891873213307','test'),('2019-06-10 15:59:59','2019-06-12 15:59:59','LSKBTC','4h','0.000256000000000','0.000252700000000','0.001487237873606','0.001468066447892','5.8095229437734375','5.809522943773437','test'),('2019-07-20 11:59:59','2019-07-28 23:59:59','LSKBTC','4h','0.000137200000000','0.000144900000000','0.001487237873606','0.001570705305288','10.839926192463556','10.839926192463556','test'),('2019-08-14 07:59:59','2019-08-14 11:59:59','LSKBTC','4h','0.000116500000000','0.000114700000000','0.001487237873606','0.001464259091010','12.765990331381975','12.765990331381975','test'),('2019-08-15 01:59:59','2019-08-15 11:59:59','LSKBTC','4h','0.000115300000000','0.000112400000000','0.001487237873606','0.001449831196820','12.898854064232438','12.898854064232438','test'),('2019-08-16 07:59:59','2019-08-16 11:59:59','LSKBTC','4h','0.000115000000000','0.000114400000000','0.001487237873606','0.001479478371657','12.932503248747826','12.932503248747826','test'),('2019-08-17 11:59:59','2019-08-19 11:59:59','LSKBTC','4h','0.000119300000000','0.000116600000000','0.001487237873606','0.001453578676131','12.466369435088014','12.466369435088014','test'),('2019-08-21 11:59:59','2019-08-21 15:59:59','LSKBTC','4h','0.000117300000000','0.000116800000000','0.001487237873606','0.001480898411229','12.67892475367434','12.678924753674339','test'),('2019-08-27 07:59:59','2019-08-27 11:59:59','LSKBTC','4h','0.000117500000000','0.000117100000000','0.001487237873606','0.001482174936164','12.657343605157447','12.657343605157447','test'),('2019-08-29 11:59:59','2019-08-29 19:59:59','LSKBTC','4h','0.000117100000000','0.000116900000000','0.001487237873606','0.001484697757682','12.70057962088813','12.700579620888130','test'),('2019-09-18 03:59:59','2019-09-18 07:59:59','LSKBTC','4h','0.000096300000000','0.000096100000000','0.001487237873606','0.001484149113744','15.443799310550364','15.443799310550364','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','LSKBTC','4h','0.000100300000000','0.000095800000000','0.001487237873606','0.001420512345877','14.827895050907278','14.827895050907278','test'),('2019-09-24 23:59:59','2019-09-25 03:59:59','LSKBTC','4h','0.000100200000000','0.000099000000000','0.001487237873606','0.001469426641587','14.842693349361278','14.842693349361278','test'),('2019-09-30 03:59:59','2019-09-30 07:59:59','LSKBTC','4h','0.000101500000000','0.000102800000000','0.001487237873606','0.001506286240460','14.652589887743842','14.652589887743842','test'),('2019-10-02 07:59:59','2019-10-05 19:59:59','LSKBTC','4h','0.000103300000000','0.000105100000000','0.001487237873606','0.001513152957560','14.39726886356244','14.397268863562440','test'),('2019-10-18 03:59:59','2019-10-18 07:59:59','LSKBTC','4h','0.000102000000000','0.000100200000000','0.001487237873606','0.001460992499366','14.580763466725491','14.580763466725491','test'),('2019-10-18 11:59:59','2019-10-18 15:59:59','LSKBTC','4h','0.000101100000000','0.000098600000000','0.001487237873606','0.001450461467236','14.710562548031652','14.710562548031652','test'),('2019-11-06 19:59:59','2019-11-07 03:59:59','LSKBTC','4h','0.000087600000000','0.000086500000000','0.001487237873606','0.001468562512179','16.977601296872145','16.977601296872145','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','LSKBTC','4h','0.000087400000000','0.000086600000000','0.001487237873606','0.001473624712292','17.016451643089244','17.016451643089244','test'),('2019-11-09 11:59:59','2019-11-09 15:59:59','LSKBTC','4h','0.000086800000000','0.000086900000000','0.001487237873606','0.001488951281294','17.134076884861752','17.134076884861752','test'),('2019-11-09 23:59:59','2019-11-10 07:59:59','LSKBTC','4h','0.000087000000000','0.000087700000000','0.001487237873606','0.001499204155348','17.094688202367816','17.094688202367816','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','LSKBTC','4h','0.000086900000000','0.000086800000000','0.001487237873606','0.001485526437618','17.114359880391255','17.114359880391255','test'),('2019-11-14 15:59:59','2019-11-21 11:59:59','LSKBTC','4h','0.000087400000000','0.000089400000000','0.001487237873606','0.001521270776892','17.016451643089244','17.016451643089244','test'),('2019-11-21 15:59:59','2019-11-21 19:59:59','LSKBTC','4h','0.000091100000000','0.000092000000000','0.001487237873606','0.001501930673675','16.325333409506037','16.325333409506037','test'),('2019-11-27 03:59:59','2019-11-27 07:59:59','LSKBTC','4h','0.000092600000000','0.000092700000000','0.001487237873606','0.001488843962022','16.060884164211664','16.060884164211664','test'),('2019-11-30 23:59:59','2019-12-01 03:59:59','LSKBTC','4h','0.000092200000000','0.000092000000000','0.001487237873606','0.001484011761082','16.13056262045553','16.130562620455532','test'),('2019-12-01 19:59:59','2019-12-01 23:59:59','LSKBTC','4h','0.000092200000000','0.000092000000000','0.001487237873606','0.001484011761082','16.13056262045553','16.130562620455532','test'),('2019-12-02 11:59:59','2019-12-02 15:59:59','LSKBTC','4h','0.000092000000000','0.000092800000000','0.001487237873606','0.001500170376855','16.165629060934783','16.165629060934783','test'),('2019-12-03 03:59:59','2019-12-03 07:59:59','LSKBTC','4h','0.000092400000000','0.000091900000000','0.001487237873606','0.001479190049615','16.09564798274892','16.095647982748918','test'),('2019-12-05 11:59:59','2019-12-05 15:59:59','LSKBTC','4h','0.000093000000000','0.000092400000000','0.001487237873606','0.001477642790550','15.991805092537636','15.991805092537636','test'),('2019-12-24 03:59:59','2019-12-24 07:59:59','LSKBTC','4h','0.000079000000000','0.000077700000000','0.001487237873606','0.001462764338977','18.82579586843038','18.825795868430379','test'),('2019-12-25 07:59:59','2019-12-25 11:59:59','LSKBTC','4h','0.000078400000000','0.000078200000000','0.001487237873606','0.001483443899439','18.969870836811225','18.969870836811225','test'),('2019-12-26 07:59:59','2019-12-26 19:59:59','LSKBTC','4h','0.000080300000000','0.000079200000000','0.001487237873606','0.001466864752050','18.521019596587795','18.521019596587795','test'),('2019-12-30 03:59:59','2019-12-31 03:59:59','LSKBTC','4h','0.000079200000000','0.000077200000000','0.001487237873606','0.001449681361646','18.778255979873737','18.778255979873737','test'),('2019-12-31 07:59:59','2019-12-31 11:59:59','LSKBTC','4h','0.000079000000000','0.000078400000000','0.001487237873606','0.001475942396085','18.82579586843038','18.825795868430379','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:30:07
