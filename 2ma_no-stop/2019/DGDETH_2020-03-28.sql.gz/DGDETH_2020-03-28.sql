-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 11:59:59','2019-01-03 15:59:59','DGDETH','4h','0.140860000000000','0.132310000000000','0.072144500000000','0.067765432308675','0.5121716598040608','0.512171659804061','test'),('2019-01-06 03:59:59','2019-01-06 07:59:59','DGDETH','4h','0.136240000000000','0.135920000000000','0.072144500000000','0.071975047269524','0.5295397827363476','0.529539782736348','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','DGDETH','4h','0.137360000000000','0.139220000000000','0.072144500000000','0.073121413002330','0.5252220442632498','0.525222044263250','test'),('2019-01-10 07:59:59','2019-01-10 19:59:59','DGDETH','4h','0.138310000000000','0.137900000000000','0.072144500000000','0.071930638059432','0.5216144891909479','0.521614489190948','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','DGDETH','4h','0.139810000000000','0.140230000000000','0.072144500000000','0.072361227630355','0.5160181675130535','0.516018167513054','test'),('2019-02-08 03:59:59','2019-02-08 07:59:59','DGDETH','4h','0.147700000000000','0.147720000000000','0.072144500000000','0.072154269058903','0.4884529451591063','0.488452945159106','test'),('2019-02-26 15:59:59','2019-02-27 11:59:59','DGDETH','4h','0.118020000000000','0.114030000000000','0.072144500000000','0.069705451067616','0.6112904592441959','0.611290459244196','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','DGDETH','4h','0.116520000000000','0.114650000000000','0.072144500000000','0.070986671172331','0.6191598008925506','0.619159800892551','test'),('2019-03-01 19:59:59','2019-03-04 11:59:59','DGDETH','4h','0.120890000000000','0.120400000000000','0.072144500000000','0.071852078749276','0.5967780627016296','0.596778062701630','test'),('2019-03-08 11:59:59','2019-03-08 15:59:59','DGDETH','4h','0.116390000000000','0.113630000000000','0.072144500000000','0.070433710241430','0.619851361800842','0.619851361800842','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','DGDETH','4h','0.115890000000000','0.115960000000000','0.072144500000000','0.072188076796963','0.622525670894814','0.622525670894814','test'),('2019-03-10 15:59:59','2019-03-16 07:59:59','DGDETH','4h','0.115930000000000','0.121530000000000','0.072144500000000','0.075629440912620','0.622310877253515','0.622310877253515','test'),('2019-03-17 03:59:59','2019-03-17 07:59:59','DGDETH','4h','0.121400000000000','0.121650000000000','0.072144500000000','0.072293067751236','0.5942710049423394','0.594271004942339','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','DGDETH','4h','0.121960000000000','0.123240000000000','0.072144500000000','0.072901674155461','0.5915423089537554','0.591542308953755','test'),('2019-04-06 03:59:59','2019-04-06 07:59:59','DGDETH','4h','0.135200000000000','0.134050000000000','0.072144500000000','0.071530844859467','0.5336131656804735','0.533613165680473','test'),('2019-04-07 15:59:59','2019-04-07 19:59:59','DGDETH','4h','0.133730000000000','0.132550000000000','0.072144500000000','0.071507915015329','0.5394788005683093','0.539478800568309','test'),('2019-04-18 19:59:59','2019-05-01 23:59:59','DGDETH','4h','0.136990000000000','0.174370000000000','0.072144500000000','0.091830326775677','0.5266406307029711','0.526640630702971','test'),('2019-05-03 15:59:59','2019-05-06 03:59:59','DGDETH','4h','0.184950000000000','0.183360000000000','0.075572196206656','0.074922508226291','0.40860879268265077','0.408608792682651','test'),('2019-05-08 07:59:59','2019-05-11 11:59:59','DGDETH','4h','0.196660000000000','0.188990000000000','0.075572196206656','0.072624780642204','0.3842784308281095','0.384278430828109','test'),('2019-05-12 03:59:59','2019-05-12 07:59:59','DGDETH','4h','0.198320000000000','0.187120000000000','0.075572196206656','0.071304302915437','0.3810619010016943','0.381061901001694','test'),('2019-05-30 23:59:59','2019-05-31 03:59:59','DGDETH','4h','0.141400000000000','0.139750000000000','0.075572196206656','0.074690342431967','0.5344568331446676','0.534456833144668','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','DGDETH','4h','0.139480000000000','0.136270000000000','0.075572196206656','0.073832973738751','0.5418138529298538','0.541813852929854','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','DGDETH','4h','0.134580000000000','0.133830000000000','0.075572196206656','0.075151040409695','0.5615410626144747','0.561541062614475','test'),('2019-06-08 23:59:59','2019-06-09 03:59:59','DGDETH','4h','0.135090000000000','0.133910000000000','0.075572196206656','0.074912079310336','0.5594210985761789','0.559421098576179','test'),('2019-06-10 19:59:59','2019-06-10 23:59:59','DGDETH','4h','0.134230000000000','0.132870000000000','0.075572196206656','0.074806509051467','0.5630052611685615','0.563005261168562','test'),('2019-06-11 03:59:59','2019-06-11 07:59:59','DGDETH','4h','0.134140000000000','0.130210000000000','0.075572196206656','0.073358100999468','0.5633830043734606','0.563383004373461','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','DGDETH','4h','0.127640000000000','0.115960000000000','0.075572196206656','0.068656783705138','0.592072988143654','0.592072988143654','test'),('2019-06-20 11:59:59','2019-06-20 15:59:59','DGDETH','4h','0.122740000000000','0.117280000000000','0.075572196206656','0.072210421794986','0.6157095992069089','0.615709599206909','test'),('2019-06-20 19:59:59','2019-06-20 23:59:59','DGDETH','4h','0.123560000000000','0.113420000000000','0.075572196206656','0.069370334200056','0.6116234720512788','0.611623472051279','test'),('2019-07-06 23:59:59','2019-07-07 15:59:59','DGDETH','4h','0.098900000000000','0.089230000000000','0.075572196206656','0.068183084605864','0.7641273630602224','0.764127363060222','test'),('2019-07-11 07:59:59','2019-07-11 11:59:59','DGDETH','4h','0.088620000000000','0.085930000000000','0.075572196206656','0.073278253442089','0.8527668269764839','0.852766826976484','test'),('2019-07-12 03:59:59','2019-07-12 07:59:59','DGDETH','4h','0.086240000000000','0.084060000000000','0.075572196206656','0.073661860078055','0.8763009764222636','0.876300976422264','test'),('2019-07-12 15:59:59','2019-07-14 11:59:59','DGDETH','4h','0.087740000000000','0.088210000000000','0.075572196206656','0.075977016496343','0.8613197652912697','0.861319765291270','test'),('2019-07-19 19:59:59','2019-07-20 03:59:59','DGDETH','4h','0.088530000000000','0.084060000000000','0.075572196206656','0.071756453328041','0.8536337536050606','0.853633753605061','test'),('2019-07-21 11:59:59','2019-07-23 19:59:59','DGDETH','4h','0.085790000000000','0.084470000000000','0.075572196206656','0.074409411511554','0.8808974962892645','0.880897496289265','test'),('2019-08-03 07:59:59','2019-08-03 11:59:59','DGDETH','4h','0.091660000000000','0.090280000000000','0.075572196206656','0.074434408395559','0.8244839210850535','0.824483921085054','test'),('2019-08-05 07:59:59','2019-08-06 11:59:59','DGDETH','4h','0.094500000000000','0.089820000000000','0.075572196206656','0.071829573156422','0.7997057799646138','0.799705779964614','test'),('2019-08-14 19:59:59','2019-08-16 07:59:59','DGDETH','4h','0.103060000000000','0.100790000000000','0.075572196206656','0.073907642690363','0.7332834873535417','0.733283487353542','test'),('2019-08-17 15:59:59','2019-08-17 19:59:59','DGDETH','4h','0.102130000000000','0.101200000000000','0.075572196206656','0.074884032665364','0.7399607970885734','0.739960797088573','test'),('2019-08-17 23:59:59','2019-08-18 11:59:59','DGDETH','4h','0.102580000000000','0.101230000000000','0.075572196206656','0.074577631331642','0.7367147222329499','0.736714722232950','test'),('2019-08-21 11:59:59','2019-08-21 23:59:59','DGDETH','4h','0.102010000000000','0.099900000000000','0.075572196206656','0.074009042261003','0.7408312538638957','0.740831253863896','test'),('2019-08-24 15:59:59','2019-08-24 23:59:59','DGDETH','4h','0.100710000000000','0.099230000000000','0.075572196206656','0.074461612844668','0.7503941635056699','0.750394163505670','test'),('2019-08-25 03:59:59','2019-08-25 23:59:59','DGDETH','4h','0.103530000000000','0.101020000000000','0.075572196206656','0.073740010246271','0.7299545658906211','0.729954565890621','test'),('2019-09-26 15:59:59','2019-09-26 19:59:59','DGDETH','4h','0.071900000000000','0.069840000000000','0.075572196206656','0.073406984465547','1.0510736607323505','1.051073660732351','test'),('2019-09-27 07:59:59','2019-09-27 11:59:59','DGDETH','4h','0.070970000000000','0.071240000000000','0.075572196206656','0.075859704914220','1.0648470650508102','1.064847065050810','test'),('2019-09-27 23:59:59','2019-09-28 07:59:59','DGDETH','4h','0.071940000000000','0.071130000000000','0.075572196206656','0.074721299919091','1.0504892439068112','1.050489243906811','test'),('2019-10-03 07:59:59','2019-10-03 11:59:59','DGDETH','4h','0.072760000000000','0.072860000000000','0.075572196206656','0.075676061237176','1.0386503052041782','1.038650305204178','test'),('2019-10-04 11:59:59','2019-10-04 15:59:59','DGDETH','4h','0.072860000000000','0.072860000000000','0.075572196206656','0.075572196206656','1.0372247626496844','1.037224762649684','test'),('2019-10-07 23:59:59','2019-10-08 03:59:59','DGDETH','4h','0.072480000000000','0.072860000000000','0.075572196206656','0.075968408052110','1.042662751195585','1.042662751195585','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','DGDETH','4h','0.074000000000000','0.069540000000000','0.075572196206656','0.071017439516363','1.0212458946845406','1.021245894684541','test'),('2019-10-10 07:59:59','2019-10-11 07:59:59','DGDETH','4h','0.076330000000000','0.075870000000000','0.075572196206656','0.075116763083964','0.9900720058516443','0.990072005851644','test'),('2019-10-13 19:59:59','2019-10-15 11:59:59','DGDETH','4h','0.088680000000000','0.077010000000000','0.075572196206656','0.065627140616538','0.8521898534805594','0.852189853480559','test'),('2019-10-17 15:59:59','2019-10-18 03:59:59','DGDETH','4h','0.075150000000000','0.075140000000000','0.050381464137771','0.050374760017460','0.6704120311080596','0.670412031108060','test'),('2019-11-02 15:59:59','2019-11-04 07:59:59','DGDETH','4h','0.070920000000000','0.069700000000000','0.056292855491013','0.055324478676306','0.7937514874649353','0.793751487464935','test'),('2019-11-04 15:59:59','2019-11-04 19:59:59','DGDETH','4h','0.069820000000000','0.072160000000000','0.056292855491013','0.058179496594550','0.8062568818535234','0.806256881853523','test'),('2019-11-05 19:59:59','2019-11-05 23:59:59','DGDETH','4h','0.069950000000000','0.070000000000000','0.056522421563221','0.056562823580064','0.8080403368580517','0.808040336858052','test'),('2019-11-06 11:59:59','2019-11-06 23:59:59','DGDETH','4h','0.070900000000000','0.069820000000000','0.056532522067431','0.055671377866686','0.797355741430627','0.797355741430627','test'),('2019-11-20 15:59:59','2019-11-20 19:59:59','DGDETH','4h','0.068210000000000','0.066800000000000','0.056532522067431','0.055363912536349','0.8288010858734935','0.828801085873494','test'),('2019-12-22 19:59:59','2019-12-23 03:59:59','DGDETH','4h','0.136150000000000','0.129640000000000','0.056532522067431','0.053829424611251','0.4152223434993096','0.415222343499310','test'),('2019-12-24 03:59:59','2019-12-24 15:59:59','DGDETH','4h','0.130620000000000','0.129260000000000','0.056532522067431','0.055943912130119','0.4328014244941892','0.432801424494189','test'),('2019-12-24 23:59:59','2019-12-25 03:59:59','DGDETH','4h','0.130800000000000','0.129130000000000','0.056532522067431','0.055810738337671','0.43220582620360093','0.432205826203601','test'),('2019-12-25 07:59:59','2019-12-25 11:59:59','DGDETH','4h','0.130850000000000','0.130120000000000','0.056532522067431','0.056217132376111','0.4320406730411234','0.432040673041123','test'),('2019-12-26 07:59:59','2019-12-26 11:59:59','DGDETH','4h','0.129820000000000','0.129910000000000','0.056532522067431','0.056571714233400','0.43546851076437376','0.435468510764374','test'),('2019-12-26 23:59:59','2019-12-28 15:59:59','DGDETH','4h','0.131090000000000','0.132020000000000','0.056532522067431','0.056933584280588','0.4312496915663361','0.431249691566336','test'),('2019-12-30 07:59:59','2019-12-30 23:59:59','DGDETH','4h','0.137670000000000','0.137500000000000','0.056532522067431','0.056462713621499','0.4106379172472652','0.410637917247265','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:30:43
