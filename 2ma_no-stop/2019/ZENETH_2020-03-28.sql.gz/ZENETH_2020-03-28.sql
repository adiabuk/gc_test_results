-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 15:59:59','2019-01-11 19:59:59','ZENETH','4h','0.036830000000000','0.036390000000000','0.072144500000000','0.071282605348900','1.958851479771925','1.958851479771925','test'),('2019-01-12 23:59:59','2019-01-13 03:59:59','ZENETH','4h','0.037770000000000','0.036190000000000','0.072144500000000','0.069126541037861','1.9101006089489014','1.910100608948901','test'),('2019-01-13 19:59:59','2019-01-13 23:59:59','ZENETH','4h','0.037020000000000','0.036310000000000','0.072144500000000','0.070760853457591','1.9487979470556458','1.948797947055646','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','ZENETH','4h','0.037000000000000','0.036140000000000','0.072144500000000','0.070467627837838','1.9498513513513513','1.949851351351351','test'),('2019-01-17 07:59:59','2019-01-17 15:59:59','ZENETH','4h','0.036160000000000','0.037500000000000','0.072144500000000','0.074817996404867','1.9951465707964604','1.995146570796460','test'),('2019-01-28 03:59:59','2019-01-28 07:59:59','ZENETH','4h','0.038680000000000','0.038470000000000','0.072144500000000','0.071752815796277','1.8651628748707343','1.865162874870734','test'),('2019-02-01 19:59:59','2019-02-01 23:59:59','ZENETH','4h','0.038910000000000','0.037970000000000','0.072144500000000','0.070401610511437','1.8541377537907993','1.854137753790799','test'),('2019-02-07 03:59:59','2019-02-07 07:59:59','ZENETH','4h','0.037910000000000','0.037680000000000','0.072144500000000','0.071706799261409','1.903046689527829','1.903046689527829','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','ZENETH','4h','0.037710000000000','0.038840000000000','0.072144500000000','0.074306347918324','1.9131397507292496','1.913139750729250','test'),('2019-02-11 11:59:59','2019-02-11 15:59:59','ZENETH','4h','0.037780000000000','0.037180000000000','0.072144500000000','0.070998742985707','1.909595023822128','1.909595023822128','test'),('2019-02-12 03:59:59','2019-02-12 23:59:59','ZENETH','4h','0.038070000000000','0.037810000000000','0.072144500000000','0.071651787365380','1.8950485946939848','1.895048594693985','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','ZENETH','4h','0.036390000000000','0.035450000000000','0.072144500000000','0.070280915773564','1.9825364111019512','1.982536411101951','test'),('2019-02-24 19:59:59','2019-03-06 03:59:59','ZENETH','4h','0.035970000000000','0.040350000000000','0.072144500000000','0.080929401584654','2.005685293299972','2.005685293299972','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','ZENETH','4h','0.039580000000000','0.039400000000000','0.072295886320952','0.071967102603474','1.8265762082100117','1.826576208210012','test'),('2019-03-08 11:59:59','2019-03-08 15:59:59','ZENETH','4h','0.039720000000000','0.039850000000000','0.072295886320952','0.072532504277189','1.8201381248980868','1.820138124898087','test'),('2019-03-30 19:59:59','2019-03-30 23:59:59','ZENETH','4h','0.048250000000000','0.048000000000000','0.072295886320952','0.071921296236387','1.4983603382580726','1.498360338258073','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','ZENETH','4h','0.048380000000000','0.049040000000000','0.072295886320952','0.073282146861916','1.4943341529754446','1.494334152975445','test'),('2019-04-11 07:59:59','2019-04-11 15:59:59','ZENETH','4h','0.048760000000000','0.047850000000000','0.072425762494742','0.071074092193876','1.485351978973375','1.485351978973375','test'),('2019-04-23 15:59:59','2019-04-23 19:59:59','ZENETH','4h','0.042890000000000','0.042170000000000','0.072425762494742','0.071209941814019','1.6886398343376545','1.688639834337655','test'),('2019-04-23 23:59:59','2019-04-29 19:59:59','ZENETH','4h','0.042920000000000','0.046830000000000','0.072425762494742','0.079023729208499','1.6874595175848557','1.687459517584856','test'),('2019-04-30 15:59:59','2019-05-14 07:59:59','ZENETH','4h','0.045990000000000','0.059310000000000','0.073433381427784','0.094701758044833','1.5967249712499183','1.596724971249918','test'),('2019-05-14 15:59:59','2019-05-14 19:59:59','ZENETH','4h','0.059970000000000','0.059340000000000','0.078750475582046','0.077923181941614','1.313164508621744','1.313164508621744','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','ZENETH','4h','0.041900000000000','0.041070000000000','0.078750475582046','0.077190501960731','1.8794862907409546','1.879486290740955','test'),('2019-06-09 15:59:59','2019-06-10 03:59:59','ZENETH','4h','0.041670000000000','0.041460000000000','0.078750475582046','0.078353604934764','1.8898602251510919','1.889860225151092','test'),('2019-06-12 07:59:59','2019-06-12 15:59:59','ZENETH','4h','0.041890000000000','0.042260000000000','0.078750475582046','0.079446051518197','1.8799349625697304','1.879934962569730','test'),('2019-06-13 03:59:59','2019-06-13 07:59:59','ZENETH','4h','0.042670000000000','0.041660000000000','0.078750475582046','0.076886449794892','1.8455700862912114','1.845570086291211','test'),('2019-06-19 03:59:59','2019-06-20 07:59:59','ZENETH','4h','0.041290000000000','0.040760000000000','0.078750475582046','0.077739631502160','1.90725298091659','1.907252980916590','test'),('2019-06-30 03:59:59','2019-06-30 07:59:59','ZENETH','4h','0.036290000000000','0.032170000000000','0.078750475582046','0.069809942118336','2.170032394104326','2.170032394104326','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','ZENETH','4h','0.033780000000000','0.031290000000000','0.078750475582046','0.072945600383725','2.3312751800487272','2.331275180048727','test'),('2019-07-15 03:59:59','2019-07-15 07:59:59','ZENETH','4h','0.031310000000000','0.030460000000000','0.078750475582046','0.076612567429867','2.515186061387608','2.515186061387608','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','ZENETH','4h','0.031830000000000','0.030280000000000','0.078750475582046','0.074915626786816','2.4740959969225886','2.474095996922589','test'),('2019-07-16 11:59:59','2019-07-16 15:59:59','ZENETH','4h','0.031300000000000','0.030720000000000','0.078750475582046','0.077291201593625','2.515989635209137','2.515989635209137','test'),('2019-07-23 07:59:59','2019-07-31 15:59:59','ZENETH','4h','0.029510000000000','0.032000000000000','0.078750475582046','0.085395297140816','2.668603035650491','2.668603035650491','test'),('2019-08-03 11:59:59','2019-08-05 11:59:59','ZENETH','4h','0.033040000000000','0.032550000000000','0.078750475582046','0.077582565986550','2.383488970400908','2.383488970400908','test'),('2019-08-08 19:59:59','2019-08-08 23:59:59','ZENETH','4h','0.033450000000000','0.031940000000000','0.078750475582046','0.075195521377894','2.3542743073855306','2.354274307385531','test'),('2019-08-16 19:59:59','2019-08-16 23:59:59','ZENETH','4h','0.029210000000000','0.028090000000000','0.078750475582046','0.075730943481673','2.6960108039043478','2.696010803904348','test'),('2019-08-17 15:59:59','2019-08-17 19:59:59','ZENETH','4h','0.029120000000000','0.028980000000000','0.078750475582046','0.078371867526363','2.704343254877953','2.704343254877953','test'),('2019-08-25 03:59:59','2019-08-25 11:59:59','ZENETH','4h','0.027960000000000','0.027450000000000','0.078750475582046','0.077314039868640','2.8165406145223892','2.816540614522389','test'),('2019-08-28 23:59:59','2019-08-31 19:59:59','ZENETH','4h','0.028440000000000','0.027950000000000','0.078750475582046','0.077393663590653','2.7690040640663147','2.769004064066315','test'),('2019-09-24 03:59:59','2019-09-24 07:59:59','ZENETH','4h','0.020450000000000','0.020620000000000','0.078750475582046','0.079405125012312','3.8508790015670415','3.850879001567042','test'),('2019-10-04 11:59:59','2019-10-04 19:59:59','ZENETH','4h','0.019990000000000','0.019670000000000','0.078750475582046','0.077489837653769','3.9394935258652324','3.939493525865232','test'),('2019-10-05 19:59:59','2019-10-06 07:59:59','ZENETH','4h','0.020100000000000','0.019810000000000','0.078750475582046','0.077614274690564','3.917934108559502','3.917934108559502','test'),('2019-10-06 19:59:59','2019-10-06 23:59:59','ZENETH','4h','0.019970000000000','0.020040000000000','0.078750475582046','0.079026516307672','3.9434389375085623','3.943438937508562','test'),('2019-10-15 07:59:59','2019-10-15 11:59:59','ZENETH','4h','0.019100000000000','0.019040000000000','0.078750475582046','0.078503091889118','4.12306154879822','4.123061548798220','test'),('2019-10-17 19:59:59','2019-10-18 07:59:59','ZENETH','4h','0.019100000000000','0.019040000000000','0.078750475582046','0.078503091889118','4.12306154879822','4.123061548798220','test'),('2019-10-18 23:59:59','2019-11-04 19:59:59','ZENETH','4h','0.019050000000000','0.025810000000000','0.078750475582046','0.106695526234783','4.133883232653333','4.133883232653333','test'),('2019-11-07 19:59:59','2019-11-08 15:59:59','ZENETH','4h','0.027850000000000','0.025980000000000','0.078750475582046','0.073462741674024','2.8276651914558704','2.827665191455870','test'),('2019-11-09 11:59:59','2019-11-09 15:59:59','ZENETH','4h','0.025990000000000','0.026490000000000','0.078750475582046','0.080265490502824','3.030029841556214','3.030029841556214','test'),('2019-11-11 03:59:59','2019-11-11 07:59:59','ZENETH','4h','0.026080000000000','0.025690000000000','0.078750475582046','0.077572841936456','3.019573450231825','3.019573450231825','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','ZENETH','4h','0.026040000000000','0.026120000000000','0.078750475582046','0.078992412526999','3.024211811906528','3.024211811906528','test'),('2019-11-19 15:59:59','2019-12-04 03:59:59','ZENETH','4h','0.029370000000000','0.034500000000000','0.078750475582046','0.092505665903323','2.6813236493716714','2.681323649371671','test'),('2019-12-06 03:59:59','2019-12-09 03:59:59','ZENETH','4h','0.036790000000000','0.036150000000000','0.079655627506271','0.078269935698606','2.165143449477318','2.165143449477318','test'),('2019-12-29 03:59:59','2019-12-29 15:59:59','ZENETH','4h','0.052470000000000','0.052370000000000','0.079655627506271','0.079503815751923','1.5181175434776253','1.518117543477625','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:55:36
