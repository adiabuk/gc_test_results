-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 03:59:59','2019-01-13 07:59:59','ADXETH','4h','0.000734000000000','0.000733300000000','0.072144500000000','0.072075697343324','98.28950953678475','98.289509536784749','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','ADXETH','4h','0.000744100000000','0.000738500000000','0.072144500000000','0.071601549858890','96.95538234108318','96.955382341083180','test'),('2019-01-29 15:59:59','2019-01-30 03:59:59','ADXETH','4h','0.000877500000000','0.000873300000000','0.072144500000000','0.071799192991453','82.21595441595441','82.215954415954414','test'),('2019-02-02 23:59:59','2019-02-03 03:59:59','ADXETH','4h','0.000859900000000','0.000862100000000','0.072144500000000','0.072329077160135','83.898709152227','83.898709152226999','test'),('2019-02-05 07:59:59','2019-02-05 11:59:59','ADXETH','4h','0.000862000000000','0.000853800000000','0.072144500000000','0.071458206612529','83.69431554524361','83.694315545243612','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','ADXETH','4h','0.000943600000000','0.000917700000000','0.072144500000000','0.070164272626113','76.45665536244172','76.456655362441722','test'),('2019-02-11 07:59:59','2019-02-11 15:59:59','ADXETH','4h','0.000938700000000','0.000928000000000','0.072144500000000','0.071322143389794','76.85575796314052','76.855757963140519','test'),('2019-02-12 23:59:59','2019-02-13 03:59:59','ADXETH','4h','0.000921900000000','0.000902800000000','0.072144500000000','0.070649804317171','78.25631847271939','78.256318472719386','test'),('2019-02-16 15:59:59','2019-02-17 11:59:59','ADXETH','4h','0.000917300000000','0.000913300000000','0.072144500000000','0.071829904992914','78.64875177150333','78.648751771503328','test'),('2019-02-25 23:59:59','2019-02-27 15:59:59','ADXETH','4h','0.000842000000000','0.000853000000000','0.072144500000000','0.073087005344418','85.68230403800476','85.682304038004759','test'),('2019-03-07 07:59:59','2019-03-16 11:59:59','ADXETH','4h','0.000906300000000','0.001016900000000','0.072144500000000','0.080948628544632','79.60333222994593','79.603332229945934','test'),('2019-03-19 19:59:59','2019-03-21 15:59:59','ADXETH','4h','0.001034400000000','0.000999800000000','0.073063495795343','0.070619569891902','70.63369663122897','70.633696631228972','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','ADXETH','4h','0.001039300000000','0.001028700000000','0.073063495795343','0.072318308596815','70.30067910645917','70.300679106459171','test'),('2019-03-22 15:59:59','2019-03-23 07:59:59','ADXETH','4h','0.001056500000000','0.001026900000000','0.073063495795343','0.071016473101976','69.15617207320682','69.156172073206818','test'),('2019-03-24 11:59:59','2019-03-25 15:59:59','ADXETH','4h','0.001052300000000','0.001043200000000','0.073063495795343','0.072431662846813','69.43219214610188','69.432192146101883','test'),('2019-03-30 23:59:59','2019-03-31 03:59:59','ADXETH','4h','0.001115700000000','0.001103600000000','0.073063495795343','0.072271106892301','65.48668620179528','65.486686201795280','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','ADXETH','4h','0.001134100000000','0.001146200000000','0.073063495795343','0.073843028728174','64.424209324877','64.424209324876998','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','ADXETH','4h','0.001111400000000','0.001113000000000','0.073063495795343','0.073168679881426','65.74005380182022','65.740053801820224','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADXETH','4h','0.001115000000000','0.001004600000000','0.073063495795343','0.065829226794620','65.52779891959014','65.527798919590140','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','ADXETH','4h','0.001044400000000','0.001035800000000','0.073063495795343','0.072461862260452','69.95738777799981','69.957387777999813','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','ADXETH','4h','0.001023700000000','0.001015200000000','0.073063495795343','0.072456833966428','71.37197987236789','71.371979872367888','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','ADXETH','4h','0.001062600000000','0.000996300000000','0.073063495795343','0.068504762714945','68.7591716500499','68.759171650049893','test'),('2019-04-21 23:59:59','2019-04-22 07:59:59','ADXETH','4h','0.001042500000000','0.001023200000000','0.073063495795343','0.071710857455918','70.08488805308681','70.084888053086814','test'),('2019-04-23 11:59:59','2019-04-23 15:59:59','ADXETH','4h','0.001041000000000','0.001034800000000','0.073063495795343','0.072628343370817','70.18587492348031','70.185874923480313','test'),('2019-05-22 19:59:59','2019-05-23 07:59:59','ADXETH','4h','0.000632600000000','0.000617500000000','0.073063495795343','0.071319488861246','115.49714795343505','115.497147953435046','test'),('2019-05-27 19:59:59','2019-05-27 23:59:59','ADXETH','4h','0.000641200000000','0.000626000000000','0.073063495795343','0.071331485289901','113.94805956853246','113.948059568532457','test'),('2019-05-28 15:59:59','2019-05-28 19:59:59','ADXETH','4h','0.000655100000000','0.000637200000000','0.073063495795343','0.071067103527389','111.53029429910396','111.530294299103957','test'),('2019-05-30 19:59:59','2019-06-01 03:59:59','ADXETH','4h','0.000652000000000','0.000649200000000','0.073063495795343','0.072749726181498','112.06057637322547','112.060576373225473','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','ADXETH','4h','0.000654700000000','0.000644600000000','0.073063495795343','0.071936351595659','111.59843561225448','111.598435612254477','test'),('2019-06-07 11:59:59','2019-06-07 15:59:59','ADXETH','4h','0.000641500000000','0.000624800000000','0.073063495795343','0.071161453114467','113.8947713099657','113.894771309965705','test'),('2019-06-07 19:59:59','2019-06-08 03:59:59','ADXETH','4h','0.000628400000000','0.000638900000000','0.073063495795343','0.074284321234317','116.26908942607099','116.269089426070991','test'),('2019-07-05 15:59:59','2019-07-06 03:59:59','ADXETH','4h','0.000473300000000','0.000463500000000','0.073063495795343','0.071550666176086','154.37036931194382','154.370369311943819','test'),('2019-07-14 07:59:59','2019-07-14 11:59:59','ADXETH','4h','0.000453800000000','0.000440300000000','0.073063495795343','0.070889945347487','161.00373687823492','161.003736878234918','test'),('2019-07-19 15:59:59','2019-07-19 19:59:59','ADXETH','4h','0.000450000000000','0.000446200000000','0.073063495795343','0.072446515164182','162.36332398965112','162.363323989651121','test'),('2019-07-21 19:59:59','2019-07-21 23:59:59','ADXETH','4h','0.000452900000000','0.000445400000000','0.073063495795343','0.071853568176741','161.32368248033342','161.323682480333417','test'),('2019-07-22 03:59:59','2019-07-25 03:59:59','ADXETH','4h','0.000458700000000','0.000483200000000','0.073063495795343','0.076965949789208','159.28383648428823','159.283836484288230','test'),('2019-08-14 15:59:59','2019-08-14 19:59:59','ADXETH','4h','0.000447200000000','0.000450300000000','0.073063495795343','0.073569973516643','163.37991009692087','163.379910096920867','test'),('2019-08-16 07:59:59','2019-08-16 11:59:59','ADXETH','4h','0.000438200000000','0.000435900000000','0.073063495795343','0.072680004146942','166.73549930475355','166.735499304753546','test'),('2019-08-17 03:59:59','2019-08-17 23:59:59','ADXETH','4h','0.000448100000000','0.000439200000000','0.073063495795343','0.071612335088852','163.05176477425354','163.051764774253542','test'),('2019-08-21 15:59:59','2019-08-21 19:59:59','ADXETH','4h','0.000436900000000','0.000435200000000','0.073063495795343','0.072779202037384','167.2316223285489','167.231622328548895','test'),('2019-08-22 11:59:59','2019-08-22 15:59:59','ADXETH','4h','0.000438000000000','0.000435800000000','0.073063495795343','0.072696510200024','166.81163423594293','166.811634235942932','test'),('2019-09-04 19:59:59','2019-09-06 11:59:59','ADXETH','4h','0.000472500000000','0.000459500000000','0.073063495795343','0.071053283212614','154.63173713300108','154.631737133001081','test'),('2019-09-10 03:59:59','2019-09-11 03:59:59','ADXETH','4h','0.000460200000000','0.000436500000000','0.073063495795343','0.069300773391280','158.76465839926772','158.764658399267717','test'),('2019-09-29 07:59:59','2019-09-29 23:59:59','ADXETH','4h','0.000382900000000','0.000380500000000','0.073063495795343','0.072605537085735','190.8161290032463','190.816129003246289','test'),('2019-10-01 23:59:59','2019-10-02 03:59:59','ADXETH','4h','0.000379000000000','0.000376800000000','0.073063495795343','0.072639380516320','192.77967228322694','192.779672283226944','test'),('2019-10-11 15:59:59','2019-10-11 19:59:59','ADXETH','4h','0.000433200000000','0.000432800000000','0.073063495795343','0.072996031810306','168.6599625931279','168.659962593127887','test'),('2019-10-15 15:59:59','2019-10-15 19:59:59','ADXETH','4h','0.000438100000000','0.000435600000000','0.073063495795343','0.072646561900140','166.7735580811299','166.773558081129892','test'),('2019-10-21 19:59:59','2019-10-23 15:59:59','ADXETH','4h','0.000437000000000','0.000433600000000','0.073063495795343','0.072495038390986','167.19335422275287','167.193354222752873','test'),('2019-10-26 23:59:59','2019-10-27 03:59:59','ADXETH','4h','0.000427400000000','0.000428000000000','0.073063495795343','0.073166065045407','170.94875010609033','170.948750106090330','test'),('2019-10-27 23:59:59','2019-10-28 03:59:59','ADXETH','4h','0.000429700000000','0.000424900000000','0.073063495795343','0.072247333868842','170.03373468778918','170.033734687789178','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','ADXETH','4h','0.000433700000000','0.000427000000000','0.073063495795343','0.071934776814875','168.46551947277612','168.465519472776123','test'),('2019-10-31 11:59:59','2019-10-31 15:59:59','ADXETH','4h','0.000436400000000','0.000449300000000','0.073063495795343','0.075223255409825','167.42322592883366','167.423225928833659','test'),('2019-11-08 03:59:59','2019-11-10 03:59:59','ADXETH','4h','0.000475100000000','0.000446100000000','0.073063495795343','0.068603716005688','153.78550998809305','153.785509988093054','test'),('2019-11-12 07:59:59','2019-11-12 11:59:59','ADXETH','4h','0.000446000000000','0.000442200000000','0.073063495795343','0.072440981705607','163.81949729897536','163.819497298975364','test'),('2019-11-12 15:59:59','2019-11-12 19:59:59','ADXETH','4h','0.000444200000000','0.000438000000000','0.073063495795343','0.072043699140838','164.48333137177625','164.483331371776245','test'),('2019-11-14 11:59:59','2019-11-14 15:59:59','ADXETH','4h','0.000442900000000','0.000443700000000','0.073063495795343','0.073195468693596','164.96612281630846','164.966122816308456','test'),('2019-11-21 19:59:59','2019-11-21 23:59:59','ADXETH','4h','0.000453500000000','0.000451900000000','0.073063495795343','0.072805719404444','161.11024431167144','161.110244311671437','test'),('2019-11-23 11:59:59','2019-11-23 19:59:59','ADXETH','4h','0.000448600000000','0.000455600000000','0.073063495795343','0.074203586010607','162.87003075199064','162.870030751990640','test'),('2019-11-25 19:59:59','2019-11-30 15:59:59','ADXETH','4h','0.000469400000000','0.000480100000000','0.073063495795343','0.074728982384628','155.65295226958457','155.652952269584574','test'),('2019-12-05 19:59:59','2019-12-05 23:59:59','ADXETH','4h','0.000510400000000','0.000508400000000','0.073063495795343','0.072777196830628','143.14948235764695','143.149482357646946','test'),('2019-12-11 15:59:59','2019-12-12 07:59:59','ADXETH','4h','0.000537300000000','0.000531400000000','0.073063495795343','0.072261197963233','135.98268340841804','135.982683408418040','test'),('2019-12-13 07:59:59','2019-12-14 19:59:59','ADXETH','4h','0.000525400000000','0.000528300000000','0.073063495795343','0.073466777367110','139.06261095421203','139.062610954212033','test'),('2019-12-24 03:59:59','2019-12-24 07:59:59','ADXETH','4h','0.000581300000000','0.000579300000000','0.073063495795343','0.072812116143544','125.68982589943748','125.689825899437480','test'),('2019-12-25 03:59:59','2019-12-25 19:59:59','ADXETH','4h','0.000588600000000','0.000585500000000','0.073063495795343','0.072678689752248','124.13098164346417','124.130981643464168','test'),('2020-01-01 07:59:59','2020-01-01 11:59:59','ADXETH','4h','0.000598500000000','0.000598500000000','0.073063495795343','0.073063495795343','122.07768721026402','122.077687210264017','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:53:43
