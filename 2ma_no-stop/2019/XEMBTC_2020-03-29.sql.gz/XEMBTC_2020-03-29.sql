-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-22 03:59:59','2019-01-22 07:59:59','XEMBTC','4h','0.000015840000000','0.000015650000000','0.001467500000000','0.001449897411616','92.64520202020202','92.645202020202021','test'),('2019-02-14 15:59:59','2019-02-17 15:59:59','XEMBTC','4h','0.000011240000000','0.000011220000000','0.001467500000000','0.001464888790036','130.56049822064057','130.560498220640568','test'),('2019-02-23 03:59:59','2019-02-24 15:59:59','XEMBTC','4h','0.000011240000000','0.000011180000000','0.001467500000000','0.001459666370107','130.56049822064057','130.560498220640568','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','XEMBTC','4h','0.000011240000000','0.000011140000000','0.001467500000000','0.001454443950178','130.56049822064057','130.560498220640568','test'),('2019-02-26 19:59:59','2019-02-27 23:59:59','XEMBTC','4h','0.000011290000000','0.000011210000000','0.001467500000000','0.001457101417183','129.9822852081488','129.982285208148795','test'),('2019-03-09 11:59:59','2019-03-09 15:59:59','XEMBTC','4h','0.000010980000000','0.000011930000000','0.001467500000000','0.001594469489982','133.6520947176685','133.652094717668490','test'),('2019-05-15 15:59:59','2019-05-22 11:59:59','XEMBTC','4h','0.000008840000000','0.000010520000000','0.001486366857275','0.001768843816576','168.14104720311084','168.141047203110844','test'),('2019-05-24 03:59:59','2019-05-24 15:59:59','XEMBTC','4h','0.000010850000000','0.000010530000000','0.001556986097101','0.001511065769813','143.50102277426268','143.501022774262680','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','XEMBTC','4h','0.000010520000000','0.000010290000000','0.001556986097101','0.001522945526537','148.00248071302283','148.002480713022834','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','XEMBTC','4h','0.000010650000000','0.000010420000000','0.001556986097101','0.001523361045239','146.19587766206573','146.195877662065726','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','XEMBTC','4h','0.000010830000000','0.000010780000000','0.001556986097101','0.001549797795637','143.76602927987074','143.766029279870736','test'),('2019-06-10 03:59:59','2019-06-10 07:59:59','XEMBTC','4h','0.000010780000000','0.000010780000000','0.001556986097101','0.001556986097101','144.43284759749537','144.432847597495368','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','XEMBTC','4h','0.000008490000000','0.000008450000000','0.001556986097101','0.001549650473558','183.39058858669023','183.390588586690228','test'),('2019-07-01 15:59:59','2019-07-02 15:59:59','XEMBTC','4h','0.000008580000000','0.000008350000000','0.001556986097101','0.001515248707552','181.46691108403266','181.466911084032660','test'),('2019-07-24 19:59:59','2019-07-26 03:59:59','XEMBTC','4h','0.000006830000000','0.000006630000000','0.001556986097101','0.001511393532032','227.9628253442167','227.962825344216697','test'),('2019-07-27 11:59:59','2019-07-28 03:59:59','XEMBTC','4h','0.000006690000000','0.000006690000000','0.001556986097101','0.001556986097101','232.7333478476831','232.733347847683092','test'),('2019-07-28 23:59:59','2019-07-29 03:59:59','XEMBTC','4h','0.000006700000000','0.000006620000000','0.001556986097101','0.001538395218330','232.3859846419403','232.385984641940297','test'),('2019-07-29 15:59:59','2019-07-30 03:59:59','XEMBTC','4h','0.000006660000000','0.000006660000000','0.001556986097101','0.001556986097101','233.7816962614114','233.781696261411412','test'),('2019-08-18 23:59:59','2019-08-19 03:59:59','XEMBTC','4h','0.000005350000000','0.000005340000000','0.001556986097101','0.001554075842714','291.0254387104673','291.025438710467313','test'),('2019-08-19 11:59:59','2019-08-19 15:59:59','XEMBTC','4h','0.000005360000000','0.000005380000000','0.001556986097101','0.001562795746717','290.48248080242536','290.482480802425357','test'),('2019-08-21 07:59:59','2019-08-21 11:59:59','XEMBTC','4h','0.000005350000000','0.000005380000000','0.001556986097101','0.001565716860262','291.0254387104673','291.025438710467313','test'),('2019-09-14 11:59:59','2019-09-14 15:59:59','XEMBTC','4h','0.000004640000000','0.000004580000000','0.001556986097101','0.001536852656190','335.55734851314656','335.557348513146565','test'),('2019-09-15 15:59:59','2019-09-15 19:59:59','XEMBTC','4h','0.000004530000000','0.000004460000000','0.001556986097101','0.001532926709287','343.70554019889624','343.705540198896244','test'),('2019-09-18 03:59:59','2019-09-22 03:59:59','XEMBTC','4h','0.000004550000000','0.000004480000000','0.001556986097101','0.001533032464838','342.1947466156044','342.194746615604402','test'),('2019-09-23 15:59:59','2019-09-24 03:59:59','XEMBTC','4h','0.000004600000000','0.000004600000000','0.001556986097101','0.001556986097101','338.4752385002174','338.475238500217415','test'),('2019-09-24 15:59:59','2019-09-24 19:59:59','XEMBTC','4h','0.000004540000000','0.000004470000000','0.001556986097101','0.001532979703533','342.9484795376652','342.948479537665207','test'),('2019-09-24 23:59:59','2019-09-25 03:59:59','XEMBTC','4h','0.000004570000000','0.000004700000000','0.001556986097101','0.001601276730060','340.6971766085339','340.697176608533880','test'),('2019-10-02 19:59:59','2019-10-02 23:59:59','XEMBTC','4h','0.000004860000000','0.000004820000000','0.001556986097101','0.001544171396713','320.3675096915638','320.367509691563782','test'),('2019-10-03 11:59:59','2019-10-03 15:59:59','XEMBTC','4h','0.000004840000000','0.000004830000000','0.001556986097101','0.001553769183677','321.6913423762397','321.691342376239675','test'),('2019-10-04 15:59:59','2019-10-07 15:59:59','XEMBTC','4h','0.000004860000000','0.000004880000000','0.001556986097101','0.001563393447295','320.3675096915638','320.367509691563782','test'),('2019-10-17 07:59:59','2019-10-20 23:59:59','XEMBTC','4h','0.000005240000000','0.000004940000000','0.001556986097101','0.001467845671694','297.1347513551527','297.134751355152673','test'),('2019-10-22 19:59:59','2019-10-22 23:59:59','XEMBTC','4h','0.000004950000000','0.000004810000000','0.001556986097101','0.001512950126678','314.5426458789899','314.542645878989902','test'),('2019-10-23 15:59:59','2019-10-23 19:59:59','XEMBTC','4h','0.000004990000000','0.000004910000000','0.001556986097101','0.001532024396145','312.0212619440882','312.021261944088224','test'),('2019-11-02 11:59:59','2019-11-02 15:59:59','XEMBTC','4h','0.000004610000000','0.000004530000000','0.001556986097101','0.001529966815589','337.74101889392625','337.741018893926253','test'),('2019-11-03 07:59:59','2019-11-03 11:59:59','XEMBTC','4h','0.000004640000000','0.000004510000000','0.001556986097101','0.001513363641794','335.55734851314656','335.557348513146565','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','XEMBTC','4h','0.000004620000000','0.000004550000000','0.001556986097101','0.001533395398660','337.0099777274892','337.009977727489172','test'),('2019-11-05 11:59:59','2019-11-05 19:59:59','XEMBTC','4h','0.000004610000000','0.000004570000000','0.001556986097101','0.001543476456345','337.74101889392625','337.741018893926253','test'),('2019-11-12 03:59:59','2019-11-12 07:59:59','XEMBTC','4h','0.000004540000000','0.000004520000000','0.001556986097101','0.001550127127510','342.9484795376652','342.948479537665207','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','XEMBTC','4h','0.000004530000000','0.000004570000000','0.001556986097101','0.001570734318709','343.70554019889624','343.705540198896244','test'),('2019-11-12 23:59:59','2019-11-13 01:59:59','XEMBTC','4h','0.000004540000000','0.000004520000000','0.001556986097101','0.001550127127510','342.9484795376652','342.948479537665207','test'),('2019-11-13 07:59:59','2019-11-13 11:59:59','XEMBTC','4h','0.000004550000000','0.000004560000000','0.001556986097101','0.001560408044567','342.1947466156044','342.194746615604402','test'),('2019-11-13 23:59:59','2019-11-14 07:59:59','XEMBTC','4h','0.000004580000000','0.000004550000000','0.001556986097101','0.001546787498212','339.953296310262','339.953296310261976','test'),('2019-11-28 03:59:59','2019-11-28 07:59:59','XEMBTC','4h','0.000004910000000','0.000004830000000','0.001556986097101','0.001531617688187','317.10511142586563','317.105111425865630','test'),('2019-12-01 15:59:59','2019-12-01 19:59:59','XEMBTC','4h','0.000004880000000','0.000004860000000','0.001556986097101','0.001550605006539','319.05452809446723','319.054528094467230','test'),('2019-12-01 23:59:59','2019-12-02 03:59:59','XEMBTC','4h','0.000004900000000','0.000004880000000','0.001556986097101','0.001550631051807','317.7522647144898','317.752264714489797','test'),('2019-12-04 11:59:59','2019-12-04 15:59:59','XEMBTC','4h','0.000004890000000','0.000004850000000','0.001556986097101','0.001544250014507','318.4020648468303','318.402064846830285','test'),('2019-12-04 23:59:59','2019-12-05 03:59:59','XEMBTC','4h','0.000004880000000','0.000004910000000','0.001556986097101','0.001566557732944','319.05452809446723','319.054528094467230','test'),('2019-12-05 15:59:59','2019-12-05 23:59:59','XEMBTC','4h','0.000004910000000','0.000004870000000','0.001556986097101','0.001544301892644','317.10511142586563','317.105111425865630','test'),('2019-12-11 07:59:59','2019-12-12 03:59:59','XEMBTC','4h','0.000004860000000','0.000004910000000','0.001556986097101','0.001573004472586','320.3675096915638','320.367509691563782','test'),('2020-01-01 11:59:59','2020-01-01 15:59:59','XEMBTC','4h','0.000004480000000','0.000004510000000','0.001556986097101','0.001567412343287','347.5415395314732','347.541539531473177','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 11:00:25
