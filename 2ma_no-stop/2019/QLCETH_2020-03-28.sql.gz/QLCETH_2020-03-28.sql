-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 19:59:59','2019-01-06 23:59:59','QLCETH','4h','0.000194620000000','0.000218420000000','0.072144500000000','0.080967021323605','370.69417326071317','370.694173260713171','test'),('2019-01-17 15:59:59','2019-01-17 23:59:59','QLCETH','4h','0.000211120000000','0.000205780000000','0.074350130330901','0.072469542532649','352.1699996727039','352.169999672703909','test'),('2019-01-24 11:59:59','2019-01-25 15:59:59','QLCETH','4h','0.000215500000000','0.000217700000000','0.074350130330901','0.075109157183467','345.01220571183757','345.012205711837566','test'),('2019-01-29 19:59:59','2019-01-30 15:59:59','QLCETH','4h','0.000217110000000','0.000210920000000','0.074350130330901','0.072230341713388','342.45373465478787','342.453734654787866','test'),('2019-02-02 15:59:59','2019-02-03 15:59:59','QLCETH','4h','0.000218560000000','0.000210000000000','0.074350130330901','0.071438174274749','340.18178226071103','340.181782260711032','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','QLCETH','4h','0.000186740000000','0.000175980000000','0.074350130330901','0.070066059417543','398.14785440131203','398.147854401312031','test'),('2019-02-26 11:59:59','2019-03-18 07:59:59','QLCETH','4h','0.000189460000000','0.000250580000000','0.074350130330901','0.098335562431738','392.43180793255044','392.431807932550441','test'),('2019-03-19 15:59:59','2019-03-19 19:59:59','QLCETH','4h','0.000248110000000','0.000249000000000','0.077737144222933','0.078015996580187','313.31725534211944','313.317255342119438','test'),('2019-04-27 15:59:59','2019-04-27 19:59:59','QLCETH','4h','0.000229590000000','0.000214560000000','0.077806857312247','0.072713268456447','338.89480078508103','338.894800785081031','test'),('2019-05-06 11:59:59','2019-05-06 15:59:59','QLCETH','4h','0.000208240000000','0.000196730000000','0.077806857312247','0.073506257390695','373.6403059558538','373.640305955853819','test'),('2019-05-21 11:59:59','2019-05-21 19:59:59','QLCETH','4h','0.000164580000000','0.000168390000000','0.077806857312247','0.079608073294503','472.7601003296087','472.760100329608690','test'),('2019-06-03 19:59:59','2019-06-04 03:59:59','QLCETH','4h','0.000161690000000','0.000158910000000','0.077806857312247','0.076469093298838','481.21007676570594','481.210076765705935','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','QLCETH','4h','0.000164210000000','0.000159250000000','0.077806857312247','0.075456683679285','473.8253292262773','473.825329226277290','test'),('2019-06-10 15:59:59','2019-06-12 15:59:59','QLCETH','4h','0.000171310000000','0.000161330000000','0.077806857312247','0.073274066255238','454.1874806622322','454.187480662232190','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','QLCETH','4h','0.000119200000000','0.000111010000000','0.077806857312247','0.072460899582488','652.7420915456963','652.742091545696326','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','QLCETH','4h','0.000113920000000','0.000105430000000','0.077806857312247','0.072008224775546','682.9955873617188','682.995587361718776','test'),('2019-07-13 07:59:59','2019-07-13 11:59:59','QLCETH','4h','0.000105660000000','0.000102490000000','0.077806857312247','0.075472504315088','736.3889580943309','736.388958094330860','test'),('2019-07-14 19:59:59','2019-07-15 03:59:59','QLCETH','4h','0.000103340000000','0.000103340000000','0.077806857312247','0.077806857312247','752.9210113435939','752.921011343593932','test'),('2019-07-15 23:59:59','2019-07-16 07:59:59','QLCETH','4h','0.000105860000000','0.000102500000000','0.077806857312247','0.075337265015165','734.9977074650197','734.997707465019744','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','QLCETH','4h','0.000101330000000','0.000099790000000','0.077806857312247','0.076624358938016','767.8560871631995','767.856087163199504','test'),('2019-07-23 11:59:59','2019-07-23 23:59:59','QLCETH','4h','0.000102500000000','0.000100000000000','0.077806857312247','0.075909129085119','759.0912908511903','759.091290851190251','test'),('2019-07-24 03:59:59','2019-07-24 07:59:59','QLCETH','4h','0.000101840000000','0.000100310000000','0.077806857312247','0.076637920826704','764.0107748649548','764.010774864954783','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','QLCETH','4h','0.000102400000000','0.000100310000000','0.077806857312247','0.076218807197183','759.8325909399122','759.832590939912166','test'),('2019-07-26 07:59:59','2019-07-26 15:59:59','QLCETH','4h','0.000101610000000','0.000102090000000','0.077806857312247','0.078174412587416','765.7401566011908','765.740156601190847','test'),('2019-08-19 23:59:59','2019-08-20 03:59:59','QLCETH','4h','0.000073960000000','0.000071910000000','0.077806857312247','0.075650231332121','1052.0126732321119','1052.012673232111865','test'),('2019-08-20 15:59:59','2019-08-20 19:59:59','QLCETH','4h','0.000074460000000','0.000072150000000','0.077806857312247','0.075393026525364','1044.9483925899408','1044.948392589940795','test'),('2019-08-21 03:59:59','2019-08-21 07:59:59','QLCETH','4h','0.000072860000000','0.000073940000000','0.077806857312247','0.078960184321542','1067.8953789767636','1067.895378976763595','test'),('2019-08-21 15:59:59','2019-08-28 11:59:59','QLCETH','4h','0.000073170000000','0.000084250000000','0.077806857312247','0.089589008180358','1063.3710169775454','1063.371016977545423','test'),('2019-08-29 19:59:59','2019-09-01 03:59:59','QLCETH','4h','0.000083990000000','0.000084440000000','0.077806857312247','0.078223729389762','926.3823944784737','926.382394478473657','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','QLCETH','4h','0.000085860000000','0.000084550000000','0.077806857312247','0.076619727297350','906.2061182418705','906.206118241870513','test'),('2019-09-04 15:59:59','2019-09-04 19:59:59','QLCETH','4h','0.000087180000000','0.000081730000000','0.077806857312247','0.072942813123766','892.4851721982909','892.485172198290911','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','QLCETH','4h','0.000083840000000','0.000082910000000','0.077806857312247','0.076943780292920','928.0398057281369','928.039805728136912','test'),('2019-09-05 11:59:59','2019-09-05 15:59:59','QLCETH','4h','0.000084100000000','0.000082950000000','0.077806857312247','0.076742910987525','925.1707171491914','925.170717149191432','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','QLCETH','4h','0.000084720000000','0.000082410000000','0.077806857312247','0.075685353058337','918.4001099179296','918.400109917929626','test'),('2019-09-14 11:59:59','2019-09-14 15:59:59','QLCETH','4h','0.000082220000000','0.000079830000000','0.077806857312247','0.075545140102611','946.32519231631','946.325192316309995','test'),('2019-09-15 19:59:59','2019-09-17 15:59:59','QLCETH','4h','0.000102710000000','0.000085940000000','0.077806857312247','0.065102923935493','757.5392591981988','757.539259198198806','test'),('2019-09-18 23:59:59','2019-09-20 03:59:59','QLCETH','4h','0.000089770000000','0.000085890000000','0.077806857312247','0.074443923076182','866.7356278516987','866.735627851698723','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','QLCETH','4h','0.000087080000000','0.000082850000000','0.077806857312247','0.074027309695908','893.5100747846463','893.510074784646349','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','QLCETH','4h','0.000086760000000','0.000083910000000','0.077806857312247','0.075250961238712','896.8056398368718','896.805639836871819','test'),('2019-09-27 11:59:59','2019-09-27 23:59:59','QLCETH','4h','0.000086050000000','0.000084790000000','0.077806857312247','0.076667558762411','904.20519828294','904.205198282940046','test'),('2019-10-01 15:59:59','2019-10-01 19:59:59','QLCETH','4h','0.000086030000000','0.000084950000000','0.077806857312247','0.076830088674595','904.4154052336046','904.415405233604588','test'),('2019-10-10 15:59:59','2019-10-11 03:59:59','QLCETH','4h','0.000100870000000','0.000096870000000','0.077806857312247','0.074721426269826','771.3577606052047','771.357760605204703','test'),('2019-10-18 23:59:59','2019-10-19 07:59:59','QLCETH','4h','0.000096170000000','0.000096410000000','0.077806857312247','0.078001030606985','809.0553947410523','809.055394741052282','test'),('2019-10-24 11:59:59','2019-10-24 15:59:59','QLCETH','4h','0.000102980000000','0.000101930000000','0.077806857312247','0.077013526566686','755.5530910103612','755.553091010361186','test'),('2019-10-27 23:59:59','2019-10-29 07:59:59','QLCETH','4h','0.000106030000000','0.000098890000000','0.077806857312247','0.072567387716760','733.8192710765538','733.819271076553832','test'),('2019-10-29 15:59:59','2019-10-29 19:59:59','QLCETH','4h','0.000100720000000','0.000097870000000','0.077806857312247','0.075605213712764','772.506526134303','772.506526134303044','test'),('2019-10-30 19:59:59','2019-10-31 11:59:59','QLCETH','4h','0.000100150000000','0.000098750000000','0.077806857312247','0.076719192806634','776.9032182950275','776.903218295027500','test'),('2019-11-03 19:59:59','2019-11-03 23:59:59','QLCETH','4h','0.000099620000000','0.000098500000000','0.077806857312247','0.076932096418955','781.0365118675668','781.036511867566787','test'),('2019-11-16 03:59:59','2019-11-16 07:59:59','QLCETH','4h','0.000092670000000','0.000092670000000','0.051871238208165','0.051871238208165','559.7414288136902','559.741428813690163','test'),('2019-11-18 03:59:59','2019-11-18 19:59:59','QLCETH','4h','0.000093090000000','0.000091540000000','0.058202375715663','0.057233273960810','625.2269386149212','625.226938614921210','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','QLCETH','4h','0.000090470000000','0.000088430000000','0.058202375715663','0.056889975511618','643.3334333553995','643.333433355399507','test'),('2019-11-25 07:59:59','2019-11-27 11:59:59','QLCETH','4h','0.000094430000000','0.000093240000000','0.058202375715663','0.057468913605088','616.3547147692789','616.354714769278871','test'),('2019-11-28 03:59:59','2019-11-28 07:59:59','QLCETH','4h','0.000092100000000','0.000092670000000','0.058202375715663','0.058562585858529','631.9476190625733','631.947619062573267','test'),('2019-12-03 07:59:59','2019-12-03 11:59:59','QLCETH','4h','0.000093210000000','0.000093950000000','0.058202375715663','0.058664448004362','624.4220117547795','624.422011754779533','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','QLCETH','4h','0.000093560000000','0.000093170000000','0.058202375715663','0.057959762135831','622.0861021340637','622.086102134063708','test'),('2019-12-05 23:59:59','2019-12-06 07:59:59','QLCETH','4h','0.000094620000000','0.000093810000000','0.058202375715663','0.057704130901356','615.117054699461','615.117054699461050','test'),('2019-12-14 11:59:59','2019-12-14 15:59:59','QLCETH','4h','0.000098750000000','0.000098340000000','0.058202375715663','0.057960725345603','589.3911464877266','589.391146487726587','test'),('2019-12-16 19:59:59','2019-12-16 23:59:59','QLCETH','4h','0.000098260000000','0.000098040000000','0.058202375715663','0.058072063048683','592.3303044541319','592.330304454131920','test'),('2019-12-20 07:59:59','2019-12-20 11:59:59','QLCETH','4h','0.000096650000000','0.000096710000000','0.058202375715663','0.058238507557804','602.1973690187584','602.197369018758422','test'),('2019-12-31 23:59:59','2020-01-01 03:59:59','QLCETH','4h','0.000092390000000','0.000090950000000','0.058202375715663','0.057295227528299','629.9640190027384','629.964019002738382','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:58:38
