-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-08 23:59:59','NEBLBTC','4h','0.000345000000000','0.000342400000000','0.001467500000000','0.001456440579710','4.253623188405798','4.253623188405798','test'),('2019-01-10 03:59:59','2019-01-10 11:59:59','NEBLBTC','4h','0.000338600000000','0.000328400000000','0.001467500000000','0.001423292971057','4.334022445363261','4.334022445363261','test'),('2019-01-19 03:59:59','2019-01-19 07:59:59','NEBLBTC','4h','0.000317900000000','0.000316000000000','0.001467500000000','0.001458729160113','4.616231519345707','4.616231519345707','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','NEBLBTC','4h','0.000321600000000','0.000310600000000','0.001467500000000','0.001417305659204','4.563121890547264','4.563121890547264','test'),('2019-01-24 19:59:59','2019-01-24 23:59:59','NEBLBTC','4h','0.000316400000000','0.000321400000000','0.001467500000000','0.001490690581542','4.638116308470291','4.638116308470291','test'),('2019-02-09 07:59:59','2019-02-09 19:59:59','NEBLBTC','4h','0.000294300000000','0.000300000000000','0.001467500000000','0.001495922528033','4.9864084267754','4.986408426775400','test'),('2019-02-12 19:59:59','2019-02-16 03:59:59','NEBLBTC','4h','0.000295500000000','0.000290500000000','0.001467500000000','0.001442669204738','4.9661590524534684','4.966159052453468','test'),('2019-02-17 15:59:59','2019-02-17 19:59:59','NEBLBTC','4h','0.000297900000000','0.000294600000000','0.001467500000000','0.001451243705942','4.926149714669353','4.926149714669353','test'),('2019-02-20 19:59:59','2019-02-21 19:59:59','NEBLBTC','4h','0.000301400000000','0.000293900000000','0.001467500000000','0.001430982913072','4.868944923689449','4.868944923689449','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','NEBLBTC','4h','0.000297400000000','0.000305000000000','0.001467500000000','0.001505001681237','4.934431741761936','4.934431741761936','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','NEBLBTC','4h','0.000296000000000','0.000291300000000','0.001467500000000','0.001444198479730','4.957770270270271','4.957770270270271','test'),('2019-02-27 19:59:59','2019-03-01 23:59:59','NEBLBTC','4h','0.000307000000000','0.000300000000000','0.001467500000000','0.001434039087948','4.780130293159609','4.780130293159609','test'),('2019-03-05 11:59:59','2019-03-21 15:59:59','NEBLBTC','4h','0.000301100000000','0.000351100000000','0.001467500000000','0.001711189804052','4.8737960810362','4.873796081036200','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','NEBLBTC','4h','0.000360700000000','0.000358400000000','0.001488551589094','0.001479059854536','4.1268411119891875','4.126841111989187','test'),('2019-03-22 15:59:59','2019-03-23 03:59:59','NEBLBTC','4h','0.000364200000000','0.000361200000000','0.001488551589094','0.001476290043879','4.087181738314113','4.087181738314113','test'),('2019-03-27 07:59:59','2019-03-27 11:59:59','NEBLBTC','4h','0.000356400000000','0.000360100000000','0.001488551589094','0.001504005126916','4.176631843698092','4.176631843698092','test'),('2019-04-18 15:59:59','2019-04-18 19:59:59','NEBLBTC','4h','0.000326400000000','0.000323400000000','0.001488551589094','0.001474870048753','4.560513446979166','4.560513446979166','test'),('2019-04-21 23:59:59','2019-04-22 07:59:59','NEBLBTC','4h','0.000319400000000','0.000319700000000','0.001488551589094','0.001489949727719','4.6604620823231055','4.660462082323106','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','NEBLBTC','4h','0.000174700000000','0.000169000000000','0.001488551589094','0.001439984078746','8.520615850566687','8.520615850566687','test'),('2019-05-24 07:59:59','2019-05-24 11:59:59','NEBLBTC','4h','0.000174700000000','0.000172700000000','0.001488551589094','0.001471510357393','8.520615850566687','8.520615850566687','test'),('2019-06-01 07:59:59','2019-06-01 23:59:59','NEBLBTC','4h','0.000164400000000','0.000160900000000','0.001488551589094','0.001456861013900','9.054450055316302','9.054450055316302','test'),('2019-06-05 23:59:59','2019-06-06 15:59:59','NEBLBTC','4h','0.000160900000000','0.000158500000000','0.001488551589094','0.001466348209269','9.251408260372902','9.251408260372902','test'),('2019-06-07 11:59:59','2019-06-07 19:59:59','NEBLBTC','4h','0.000161500000000','0.000159000000000','0.001488551589094','0.001465508994836','9.21703770336842','9.217037703368421','test'),('2019-07-01 15:59:59','2019-07-01 23:59:59','NEBLBTC','4h','0.000106000000000','0.000106100000000','0.001488551589094','0.001489955883046','14.042939519754716','14.042939519754716','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','NEBLBTC','4h','0.000089000000000','0.000084300000000','0.001488551589094','0.001409942684951','16.725298753865168','16.725298753865168','test'),('2019-07-20 03:59:59','2019-07-20 11:59:59','NEBLBTC','4h','0.000087900000000','0.000086300000000','0.001488551589094','0.001461456224560','16.934602833833903','16.934602833833903','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','NEBLBTC','4h','0.000085600000000','0.000086000000000','0.001488551589094','0.001495507437641','17.38962136792056','17.389621367920562','test'),('2019-07-27 23:59:59','2019-07-30 07:59:59','NEBLBTC','4h','0.000085800000000','0.000087800000000','0.001488551589094','0.001523249761334','17.34908611997669','17.349086119976690','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','NEBLBTC','4h','0.000054300000000','0.000054800000000','0.001488551589094','0.001502258325642','27.413473095653774','27.413473095653774','test'),('2019-08-22 19:59:59','2019-08-23 15:59:59','NEBLBTC','4h','0.000055700000000','0.000054000000000','0.001488551589094','0.001443120032515','26.724445046570917','26.724445046570917','test'),('2019-08-24 03:59:59','2019-08-24 07:59:59','NEBLBTC','4h','0.000054600000000','0.000055200000000','0.001488551589094','0.001504909298864','27.262849617106227','27.262849617106227','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','NEBLBTC','4h','0.000055800000000','0.000054900000000','0.001488551589094','0.001464542692496','26.676551775878135','26.676551775878135','test'),('2019-08-27 23:59:59','2019-09-01 19:59:59','NEBLBTC','4h','0.000055400000000','0.000059400000000','0.001488551589094','0.001596028238126','26.86916225801444','26.869162258014441','test'),('2019-09-18 03:59:59','2019-09-18 15:59:59','NEBLBTC','4h','0.000047500000000','0.000047290000000','0.001488551589094','0.001481970624174','31.33792819145263','31.337928191452630','test'),('2019-09-19 15:59:59','2019-09-19 23:59:59','NEBLBTC','4h','0.000048260000000','0.000045950000000','0.001488551589094','0.001417300984643','30.844417511272272','30.844417511272272','test'),('2019-09-21 07:59:59','2019-09-21 11:59:59','NEBLBTC','4h','0.000046800000000','0.000046770000000','0.001488551589094','0.001487597389357','31.80665788662393','31.806657886623931','test'),('2019-09-23 11:59:59','2019-09-23 15:59:59','NEBLBTC','4h','0.000047140000000','0.000047300000000','0.001488551589094','0.001493603949176','31.577250511115825','31.577250511115825','test'),('2019-09-27 19:59:59','2019-09-28 03:59:59','NEBLBTC','4h','0.000045620000000','0.000045540000000','0.001488551589094','0.001485941239968','32.6293640748356','32.629364074835600','test'),('2019-09-30 19:59:59','2019-10-01 07:59:59','NEBLBTC','4h','0.000046020000000','0.000046610000000','0.001488551589094','0.001507635583826','32.34575378300739','32.345753783007389','test'),('2019-10-02 11:59:59','2019-10-13 23:59:59','NEBLBTC','4h','0.000046300000000','0.000054330000000','0.001488551589094','0.001746717231868','32.15014231304536','32.150142313045357','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','NEBLBTC','4h','0.000054550000000','0.000053650000000','0.001499859622243','0.001475114000611','27.495135146535286','27.495135146535286','test'),('2019-10-15 07:59:59','2019-10-15 11:59:59','NEBLBTC','4h','0.000054420000000','0.000054610000000','0.001499859622243','0.001505096177337','27.560816285244396','27.560816285244396','test'),('2019-10-17 15:59:59','2019-10-17 19:59:59','NEBLBTC','4h','0.000054250000000','0.000053990000000','0.001499859622243','0.001492671354929','27.647181976829497','27.647181976829497','test'),('2019-10-21 11:59:59','2019-10-23 11:59:59','NEBLBTC','4h','0.000054430000000','0.000056160000000','0.001499859622243','0.001547531074502','27.55575275111152','27.555752751111520','test'),('2019-10-26 19:59:59','2019-10-26 23:59:59','NEBLBTC','4h','0.000054910000000','0.000055890000000','0.001505103151845','0.001531965309718','27.410365176566195','27.410365176566195','test'),('2019-11-02 23:59:59','2019-11-04 11:59:59','NEBLBTC','4h','0.000054780000000','0.000053140000000','0.001511818691313','0.001466557963789','27.598004587687107','27.598004587687107','test'),('2019-11-05 07:59:59','2019-11-05 11:59:59','NEBLBTC','4h','0.000053680000000','0.000053620000000','0.001511818691313','0.001510128879065','28.163537468573026','28.163537468573026','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','NEBLBTC','4h','0.000053340000000','0.000053800000000','0.001511818691313','0.001524856497800','28.343057579921258','28.343057579921258','test'),('2019-11-25 11:59:59','2019-11-25 15:59:59','NEBLBTC','4h','0.000055050000000','0.000055190000000','0.001511818691313','0.001515663461827','27.46264652702997','27.462646527029971','test'),('2019-12-16 15:59:59','2019-12-17 11:59:59','NEBLBTC','4h','0.000065700000000','0.000063850000000','0.001511818691313','0.001469248454191','23.01093898497717','23.010938984977169','test'),('2019-12-30 11:59:59','2019-12-30 15:59:59','NEBLBTC','4h','0.000059010000000','0.000057200000000','0.001511818691313','0.001465447028353','25.619703292882562','25.619703292882562','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 17:14:22
