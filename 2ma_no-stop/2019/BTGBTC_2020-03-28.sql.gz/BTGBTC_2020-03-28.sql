-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-08 23:59:59','2019-02-09 03:59:59','BTGBTC','4h','0.002838000000000','0.002822000000000','0.001467500000000','0.001459226568006','0.5170894996476393','0.517089499647639','test'),('2019-02-13 07:59:59','2019-02-13 15:59:59','BTGBTC','4h','0.002829000000000','0.002816000000000','0.001467500000000','0.001460756451043','0.5187345351714387','0.518734535171439','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BTGBTC','4h','0.002813000000000','0.002811000000000','0.001467500000000','0.001466456629932','0.5216850337717739','0.521685033771774','test'),('2019-02-16 23:59:59','2019-02-17 03:59:59','BTGBTC','4h','0.002820000000000','0.002792000000000','0.001467500000000','0.001452929078014','0.5203900709219859','0.520390070921986','test'),('2019-02-17 23:59:59','2019-02-18 03:59:59','BTGBTC','4h','0.002824000000000','0.003114000000000','0.001467500000000','0.001618199362606','0.5196529745042493','0.519652974504249','test'),('2019-03-05 15:59:59','2019-03-06 19:59:59','BTGBTC','4h','0.003199000000000','0.003233000000000','0.001497517022400','0.001513433114542','0.4681203571116755','0.468120357111675','test'),('2019-03-08 07:59:59','2019-03-08 23:59:59','BTGBTC','4h','0.003342000000000','0.003216000000000','0.001501496045436','0.001444886679271','0.449280683852708','0.449280683852708','test'),('2019-03-12 19:59:59','2019-03-13 11:59:59','BTGBTC','4h','0.003235000000000','0.003257000000000','0.001501496045436','0.001511707146827','0.4641409723140649','0.464140972314065','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','BTGBTC','4h','0.003302000000000','0.003285000000000','0.001501496045436','0.001493765750835','0.4547232118219261','0.454723211821926','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','BTGBTC','4h','0.003296000000000','0.003270000000000','0.001501496045436','0.001489651719835','0.4555509846589806','0.455550984658981','test'),('2019-04-01 07:59:59','2019-04-01 23:59:59','BTGBTC','4h','0.003219000000000','0.003207000000000','0.001501496045436','0.001495898669684','0.4664479793215284','0.466447979321528','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','BTGBTC','4h','0.003271000000000','0.003211000000000','0.001501496045436','0.001473954081900','0.45903272559951086','0.459032725599511','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','BTGBTC','4h','0.003246000000000','0.003137000000000','0.001501496045436','0.001451076122777','0.4625680977929759','0.462568097792976','test'),('2019-04-05 07:59:59','2019-04-08 19:59:59','BTGBTC','4h','0.003496000000000','0.003395000000000','0.001501496045436','0.001458117584169','0.42948971551373','0.429489715513730','test'),('2019-04-09 03:59:59','2019-04-09 07:59:59','BTGBTC','4h','0.003373000000000','0.003344000000000','0.001501496045436','0.001488586651627','0.44515151065401715','0.445151510654017','test'),('2019-04-09 15:59:59','2019-04-10 11:59:59','BTGBTC','4h','0.003419000000000','0.003464000000000','0.001501496045436','0.001521258350801','0.4391623414553963','0.439162341455396','test'),('2019-04-15 15:59:59','2019-04-15 19:59:59','BTGBTC','4h','0.003334000000000','0.003244000000000','0.001501496045436','0.001460963758667','0.4503587418824235','0.450358741882423','test'),('2019-04-17 07:59:59','2019-04-17 11:59:59','BTGBTC','4h','0.003303000000000','0.003275000000000','0.001501496045436','0.001488767650258','0.45458554206357854','0.454585542063579','test'),('2019-04-18 03:59:59','2019-04-18 07:59:59','BTGBTC','4h','0.003279000000000','0.003285000000000','0.001501496045436','0.001504243522189','0.45791279214272645','0.457912792142726','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','BTGBTC','4h','0.003281000000000','0.003269000000000','0.001501496045436','0.001496004441490','0.457633662126181','0.457633662126181','test'),('2019-05-01 07:59:59','2019-05-02 15:59:59','BTGBTC','4h','0.003149000000000','0.003077000000000','0.001501496045436','0.001467165237157','0.47681678165639885','0.476816781656399','test'),('2019-05-03 11:59:59','2019-05-06 11:59:59','BTGBTC','4h','0.003290000000000','0.003176000000000','0.001501496045436','0.001449468522889','0.45638177672826746','0.456381776728267','test'),('2019-05-12 03:59:59','2019-05-12 11:59:59','BTGBTC','4h','0.003311000000000','0.003112000000000','0.001501496045436','0.001411252097069','0.45348717772153424','0.453487177721534','test'),('2019-05-12 15:59:59','2019-05-12 19:59:59','BTGBTC','4h','0.003174000000000','0.003126000000000','0.001501496045436','0.001478789110911','0.4730611359281663','0.473061135928166','test'),('2019-05-21 23:59:59','2019-05-22 23:59:59','BTGBTC','4h','0.002935000000000','0.002961000000000','0.001501496045436','0.001514797202908','0.5115829797056217','0.511582979705622','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','BTGBTC','4h','0.002943000000000','0.002937000000000','0.001501496045436','0.001498434891419','0.5101923361997961','0.510192336199796','test'),('2019-05-29 15:59:59','2019-06-09 15:59:59','BTGBTC','4h','0.003133000000000','0.003195000000000','0.001501496045436','0.001531209660124','0.4792518498040217','0.479251849804022','test'),('2019-06-10 07:59:59','2019-06-10 19:59:59','BTGBTC','4h','0.003302000000000','0.003221000000000','0.001501496045436','0.001464663465278','0.4547232118219261','0.454723211821926','test'),('2019-06-12 07:59:59','2019-06-12 11:59:59','BTGBTC','4h','0.003285000000000','0.003231000000000','0.001501496045436','0.001476813918662','0.4570764217461187','0.457076421746119','test'),('2019-06-13 07:59:59','2019-06-13 15:59:59','BTGBTC','4h','0.003240000000000','0.003262000000000','0.001501496045436','0.001511691388954','0.4634247053814815','0.463424705381482','test'),('2019-07-11 07:59:59','2019-07-11 11:59:59','BTGBTC','4h','0.002393000000000','0.002377000000000','0.001501496045436','0.001491456790640','0.6274534247538653','0.627453424753865','test'),('2019-07-11 15:59:59','2019-07-18 15:59:59','BTGBTC','4h','0.002417000000000','0.002582000000000','0.001501496045436','0.001603997844152','0.6212230225221349','0.621223022522135','test'),('2019-07-19 03:59:59','2019-07-19 11:59:59','BTGBTC','4h','0.002647000000000','0.002594000000000','0.001501496045436','0.001471432089861','0.5672444448190403','0.567244444819040','test'),('2019-07-20 11:59:59','2019-07-20 19:59:59','BTGBTC','4h','0.002636000000000','0.002581000000000','0.001501496045436','0.001470167410194','0.569611549861912','0.569611549861912','test'),('2019-08-14 03:59:59','2019-08-14 15:59:59','BTGBTC','4h','0.001643000000000','0.001494000000000','0.001501496045436','0.001365328722995','0.9138746472525867','0.913874647252587','test'),('2019-08-23 07:59:59','2019-08-23 15:59:59','BTGBTC','4h','0.001392000000000','0.001351000000000','0.001501496045436','0.001457270946397','1.0786609521810344','1.078660952181034','test'),('2019-08-24 11:59:59','2019-08-24 23:59:59','BTGBTC','4h','0.001370000000000','0.001364000000000','0.001501496045436','0.001494920150346','1.0959825149167883','1.095982514916788','test'),('2019-09-18 07:59:59','2019-09-19 03:59:59','BTGBTC','4h','0.001022000000000','0.001018000000000','0.001501496045436','0.001495619348585','1.4691742127553817','1.469174212755382','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','BTGBTC','4h','0.000957000000000','0.000966000000000','0.001501496045436','0.001515616697901','1.5689613849905957','1.568961384990596','test'),('2019-10-14 07:59:59','2019-10-14 11:59:59','BTGBTC','4h','0.000949000000000','0.000952000000000','0.001501496045436','0.001506242608277','1.582187613736565','1.582187613736565','test'),('2019-10-24 23:59:59','2019-10-25 03:59:59','BTGBTC','4h','0.000948000000000','0.000941000000000','0.001501496045436','0.001490409049320','1.5838565880126583','1.583856588012658','test'),('2019-10-30 03:59:59','2019-10-30 07:59:59','BTGBTC','4h','0.000909000000000','0.000876000000000','0.001501496045436','0.001446986288011','1.6518108310627062','1.651810831062706','test'),('2019-11-03 19:59:59','2019-11-04 07:59:59','BTGBTC','4h','0.000896000000000','0.000890000000000','0.001501496045436','0.001491441384417','1.675776836424107','1.675776836424107','test'),('2019-12-29 23:59:59','2019-12-31 19:59:59','BTGBTC','4h','0.000737000000000','0.000736000000000','0.001501496045436','0.001499458737369','2.0373080670773405','2.037308067077340','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:45:42
