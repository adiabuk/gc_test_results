-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 19:59:59','2019-01-06 03:59:59','FUNBTC','4h','0.000001160000000','0.000001160000000','0.001467500000000','0.001467500000000','1265.0862068965519','1265.086206896551857','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','FUNBTC','4h','0.000001150000000','0.000001160000000','0.001467500000000','0.001480260869565','1276.0869565217392','1276.086956521739239','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','FUNBTC','4h','0.000001150000000','0.000001160000000','0.001470690217391','0.001483478827977','1278.861058601087','1278.861058601087052','test'),('2019-01-12 19:59:59','2019-01-13 03:59:59','FUNBTC','4h','0.000001160000000','0.000001150000000','0.001473887370038','0.001461181444434','1270.592560377371','1270.592560377371001','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','FUNBTC','4h','0.000001150000000','0.000001150000000','0.001473887370038','0.001473887370038','1281.6411913373913','1281.641191337391319','test'),('2019-01-16 07:59:59','2019-01-23 23:59:59','FUNBTC','4h','0.000001160000000','0.000001290000000','0.001473887370038','0.001639064402887','1270.5925603775863','1270.592560377586324','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','FUNBTC','4h','0.000001160000000','0.000001140000000','0.001512005146849','0.001485936092593','1303.4527128008622','1303.452712800862173','test'),('2019-02-04 07:59:59','2019-02-04 11:59:59','FUNBTC','4h','0.000001160000000','0.000001110000000','0.001512005146849','0.001446832511209','1303.4527128008622','1303.452712800862173','test'),('2019-02-27 03:59:59','2019-02-27 07:59:59','FUNBTC','4h','0.000001010000000','0.000001010000000','0.001512005146849','0.001512005146849','1497.034798860396','1497.034798860395995','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','FUNBTC','4h','0.000001010000000','0.000000990000000','0.001512005146849','0.001482064450872','1497.034798860396','1497.034798860395995','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','FUNBTC','4h','0.000001000000000','0.000000990000000','0.001512005146849','0.001496885095381','1512.005146849','1512.005146849000084','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','FUNBTC','4h','0.000001000000000','0.000001000000000','0.001512005146849','0.001512005146849','1512.005146849','1512.005146849000084','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','FUNBTC','4h','0.000001010000000','0.000001020000000','0.001512005146849','0.001526975494838','1497.034798860396','1497.034798860395995','test'),('2019-03-09 23:59:59','2019-03-10 03:59:59','FUNBTC','4h','0.000001030000000','0.000001040000000','0.001512005146849','0.001526684808469','1467.9661619893202','1467.966161989320199','test'),('2019-03-11 15:59:59','2019-03-18 15:59:59','FUNBTC','4h','0.000001030000000','0.000001140000000','0.001512005146849','0.001673481424668','1467.9661619893202','1467.966161989320199','test'),('2019-03-25 07:59:59','2019-03-25 11:59:59','FUNBTC','4h','0.000001130000000','0.000001130000000','0.001525711109371','0.001525711109371','1350.1868224519912','1350.186822451991247','test'),('2019-04-06 03:59:59','2019-04-06 07:59:59','FUNBTC','4h','0.000001170000000','0.000001180000000','0.001525711109371','0.001538751375263','1304.0265892059829','1304.026589205982873','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','FUNBTC','4h','0.000001100000000','0.000001060000000','0.001528971175844','0.001473372223995','1389.973796221591','1389.973796221591101','test'),('2019-04-23 03:59:59','2019-04-24 03:59:59','FUNBTC','4h','0.000001090000000','0.000001050000000','0.001528971175844','0.001472862141868','1402.7258493981653','1402.725849398165337','test'),('2019-05-01 03:59:59','2019-05-01 19:59:59','FUNBTC','4h','0.000001030000000','0.000001000000000','0.001528971175844','0.001484438034800','1484.4380348','1484.438034799999969','test'),('2019-05-16 19:59:59','2019-05-17 03:59:59','FUNBTC','4h','0.000000860000000','0.000000840000000','0.001528971175844','0.001493413706638','1777.873460283721','1777.873460283720988','test'),('2019-05-18 15:59:59','2019-05-18 19:59:59','FUNBTC','4h','0.000000840000000','0.000000820000000','0.001528971175844','0.001492567100229','1820.2037807666666','1820.203780766666569','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','FUNBTC','4h','0.000000860000000','0.000000810000000','0.001528971175844','0.001440077502830','1777.873460283721','1777.873460283720988','test'),('2019-05-23 15:59:59','2019-05-24 07:59:59','FUNBTC','4h','0.000000830000000','0.000000820000000','0.001528971175844','0.001510549836376','1842.1339468','1842.133946800000103','test'),('2019-05-30 07:59:59','2019-05-30 11:59:59','FUNBTC','4h','0.000000810000000','0.000000770000000','0.001528971175844','0.001453466426420','1887.6187356098767','1887.618735609876694','test'),('2019-06-01 03:59:59','2019-06-01 07:59:59','FUNBTC','4h','0.000000780000000','0.000000770000000','0.001528971175844','0.001509368981282','1960.2194562102563','1960.219456210256340','test'),('2019-06-05 23:59:59','2019-06-11 19:59:59','FUNBTC','4h','0.000000770000000','0.000000800000000','0.001528971175844','0.001588541481396','1985.6768517454545','1985.676851745454542','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','FUNBTC','4h','0.000000350000000','0.000000330000000','0.001528971175844','0.001441601394367','4368.48907384','4368.489073839999946','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','FUNBTC','4h','0.000000330000000','0.000000320000000','0.001528971175844','0.001482638715970','4633.2459874060605','4633.245987406060522','test'),('2019-07-21 19:59:59','2019-07-21 23:59:59','FUNBTC','4h','0.000000330000000','0.000000320000000','0.001528971175844','0.001482638715970','4633.2459874060605','4633.245987406060522','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','FUNBTC','4h','0.000000320000000','0.000000320000000','0.001528971175844','0.001528971175844','4778.0349245125','4778.034924512499856','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','FUNBTC','4h','0.000000320000000','0.000000320000000','0.001528971175844','0.001528971175844','4778.0349245125','4778.034924512499856','test'),('2019-07-26 23:59:59','2019-07-27 03:59:59','FUNBTC','4h','0.000000320000000','0.000000320000000','0.001528971175844','0.001528971175844','4778.0349245125','4778.034924512499856','test'),('2019-07-27 11:59:59','2019-07-27 15:59:59','FUNBTC','4h','0.000000320000000','0.000000320000000','0.001528971175844','0.001528971175844','4778.0349245125','4778.034924512499856','test'),('2019-08-14 15:59:59','2019-08-14 19:59:59','FUNBTC','4h','0.000000230000000','0.000000220000000','0.001528971175844','0.001462494168199','6647.70076453913','6647.700764539130432','test'),('2019-08-15 23:59:59','2019-08-16 03:59:59','FUNBTC','4h','0.000000230000000','0.000000220000000','0.001528971175844','0.001462494168199','6647.70076453913','6647.700764539130432','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','FUNBTC','4h','0.000000230000000','0.000000220000000','0.001528971175844','0.001462494168199','6647.70076453913','6647.700764539130432','test'),('2019-08-19 11:59:59','2019-08-19 15:59:59','FUNBTC','4h','0.000000230000000','0.000000230000000','0.001528971175844','0.001528971175844','6647.70076453913','6647.700764539130432','test'),('2019-08-21 07:59:59','2019-08-21 11:59:59','FUNBTC','4h','0.000000230000000','0.000000220000000','0.001528971175844','0.001462494168199','6647.70076453913','6647.700764539130432','test'),('2019-08-21 23:59:59','2019-08-22 03:59:59','FUNBTC','4h','0.000000230000000','0.000000230000000','0.001528971175844','0.001528971175844','6647.70076453913','6647.700764539130432','test'),('2019-08-31 07:59:59','2019-08-31 23:59:59','FUNBTC','4h','0.000000280000000','0.000000280000000','0.001528971175844','0.001528971175844','5460.6113423','5460.611342299999706','test'),('2019-09-09 19:59:59','2019-09-11 19:59:59','FUNBTC','4h','0.000000300000000','0.000000270000000','0.001528971175844','0.001376074058260','5096.570586146667','5096.570586146666756','test'),('2019-09-12 19:59:59','2019-09-13 07:59:59','FUNBTC','4h','0.000000280000000','0.000000280000000','0.001528971175844','0.001528971175844','5460.6113423','5460.611342299999706','test'),('2019-09-25 11:59:59','2019-10-13 23:59:59','FUNBTC','4h','0.000000340000000','0.000000470000000','0.001528971175844','0.002113577801902','4496.9740466','4496.974046600000293','test'),('2019-10-14 07:59:59','2019-10-14 11:59:59','FUNBTC','4h','0.000000480000000','0.000000490000000','0.001528971175844','0.001560824742007','3185.356616341667','3185.356616341667177','test'),('2019-10-15 19:59:59','2019-10-15 23:59:59','FUNBTC','4h','0.000000480000000','0.000000470000000','0.001528971175844','0.001497117609681','3185.356616341667','3185.356616341667177','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','FUNBTC','4h','0.000000370000000','0.000000370000000','0.001528971175844','0.001528971175844','4132.354529308108','4132.354529308107885','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','FUNBTC','4h','0.000000420000000','0.000000420000000','0.001528971175844','0.001528971175844','3640.407561533333','3640.407561533333137','test'),('2019-11-18 15:59:59','2019-11-18 19:59:59','FUNBTC','4h','0.000000450000000','0.000000440000000','0.001528971175844','0.001494994038603','3397.713724097778','3397.713724097778140','test'),('2019-11-21 11:59:59','2019-11-21 15:59:59','FUNBTC','4h','0.000000440000000','0.000000430000000','0.001528971175844','0.001494221830938','3474.9344905545454','3474.934490554545391','test'),('2019-11-22 11:59:59','2019-11-22 15:59:59','FUNBTC','4h','0.000000430000000','0.000000430000000','0.001528971175844','0.001528971175844','3555.746920567442','3555.746920567441975','test'),('2019-12-04 07:59:59','2019-12-10 03:59:59','FUNBTC','4h','0.000000420000000','0.000000440000000','0.001528971175844','0.001601779327075','3640.407561533333','3640.407561533333137','test'),('2019-12-15 11:59:59','2019-12-15 15:59:59','FUNBTC','4h','0.000000500000000','0.000000480000000','0.001528971175844','0.001467812328810','3057.942351688','3057.942351688000144','test'),('2019-12-15 19:59:59','2019-12-15 23:59:59','FUNBTC','4h','0.000000500000000','0.000000490000000','0.001528971175844','0.001498391752327','3057.942351688','3057.942351688000144','test'),('2019-12-16 07:59:59','2019-12-16 11:59:59','FUNBTC','4h','0.000000500000000','0.000000480000000','0.001528971175844','0.001467812328810','3057.942351688','3057.942351688000144','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','FUNBTC','4h','0.000000450000000','0.000000450000000','0.001528971175844','0.001528971175844','3397.713724097778','3397.713724097778140','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:29:33
