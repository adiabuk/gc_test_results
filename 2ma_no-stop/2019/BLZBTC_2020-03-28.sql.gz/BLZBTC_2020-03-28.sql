-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-02 19:59:59','BLZBTC','4h','0.000011470000000','0.000011620000000','0.001467500000000','0.001486691368788','127.94245858761988','127.942458587619882','test'),('2019-01-03 11:59:59','2019-01-03 23:59:59','BLZBTC','4h','0.000011570000000','0.000011430000000','0.001472297842197','0.001454482656552','127.25132603258429','127.251326032584288','test'),('2019-01-15 15:59:59','2019-01-15 23:59:59','BLZBTC','4h','0.000011330000000','0.000011270000000','0.001472297842197','0.001464501031029','129.94685279761694','129.946852797616941','test'),('2019-01-25 19:59:59','2019-01-25 23:59:59','BLZBTC','4h','0.000011780000000','0.000011820000000','0.001472297842197','0.001477297155753','124.98283889617997','124.982838896179970','test'),('2019-01-26 19:59:59','2019-01-26 23:59:59','BLZBTC','4h','0.000011770000000','0.000011750000000','0.001472297842197','0.001469796061667','125.08902652480883','125.089026524808830','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','BLZBTC','4h','0.000011450000000','0.000010900000000','0.001472297842197','0.001401576111786','128.58496438401747','128.584964384017468','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','BLZBTC','4h','0.000011020000000','0.000011040000000','0.001472297842197','0.001474969889098','133.602345026951','133.602345026951014','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','BLZBTC','4h','0.000011000000000','0.000010740000000','0.001472297842197','0.001437498075018','133.84525838154548','133.845258381545477','test'),('2019-02-14 19:59:59','2019-02-14 23:59:59','BLZBTC','4h','0.000010910000000','0.000010760000000','0.001472297842197','0.001452055433734','134.94938975224565','134.949389752245651','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','BLZBTC','4h','0.000010950000000','0.000010970000000','0.001472297842197','0.001474986970676','134.45642394493152','134.456423944931515','test'),('2019-02-19 15:59:59','2019-02-19 19:59:59','BLZBTC','4h','0.000011260000000','0.000011050000000','0.001472297842197','0.001444839356685','130.75469291269982','130.754692912699824','test'),('2019-02-20 15:59:59','2019-02-20 23:59:59','BLZBTC','4h','0.000011200000000','0.000010870000000','0.001472297842197','0.001428917637918','131.45516448187502','131.455164481875016','test'),('2019-02-21 07:59:59','2019-02-21 11:59:59','BLZBTC','4h','0.000011260000000','0.000011110000000','0.001472297842197','0.001452684638260','130.75469291269982','130.754692912699824','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','BLZBTC','4h','0.000011420000000','0.000011280000000','0.001472297842197','0.001454248656741','128.92275325718037','128.922753257180375','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','BLZBTC','4h','0.000011250000000','0.000011210000000','0.001472297842197','0.001467063005425','130.8709193064','130.870919306399998','test'),('2019-03-01 07:59:59','2019-03-18 23:59:59','BLZBTC','4h','0.000011370000000','0.000013950000000','0.001472297842197','0.001806381257577','129.48969588364116','129.489695883641161','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','BLZBTC','4h','0.000014130000000','0.000013490000000','0.001491505418438','0.001423949617461','105.55593902604386','105.555939026043859','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','BLZBTC','4h','0.000014000000000','0.000014000000000','0.001491505418438','0.001491505418438','106.53610131699999','106.536101316999989','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','BLZBTC','4h','0.000014010000000','0.000014950000000','0.001491505418438','0.001591577873351','106.4600584181299','106.460058418129904','test'),('2019-04-04 11:59:59','2019-04-04 15:59:59','BLZBTC','4h','0.000015360000000','0.000015250000000','0.001499634581922','0.001488895011348','97.63245976054688','97.632459760546880','test'),('2019-04-04 23:59:59','2019-04-08 11:59:59','BLZBTC','4h','0.000015220000000','0.000015840000000','0.001499634581922','0.001560723507073','98.53052443639947','98.530524436399475','test'),('2019-04-10 07:59:59','2019-04-10 11:59:59','BLZBTC','4h','0.000016000000000','0.000015810000000','0.001512221920566','0.001494264285259','94.51387003539061','94.513870035390610','test'),('2019-05-15 19:59:59','2019-05-16 11:59:59','BLZBTC','4h','0.000008210000000','0.000007480000000','0.001512221920566','0.001377761262586','184.19268216394642','184.192682163946415','test'),('2019-05-17 15:59:59','2019-05-17 19:59:59','BLZBTC','4h','0.000007730000000','0.000007660000000','0.001512221920566','0.001498527802269','195.63026139275547','195.630261392755472','test'),('2019-05-19 07:59:59','2019-05-19 23:59:59','BLZBTC','4h','0.000008550000000','0.000007610000000','0.001512221920566','0.001345965943334','176.8680608849123','176.868060884912296','test'),('2019-05-20 19:59:59','2019-05-20 23:59:59','BLZBTC','4h','0.000007800000000','0.000007750000000','0.001512221920566','0.001502528190306','193.87460520076922','193.874605200769224','test'),('2019-06-03 11:59:59','2019-06-03 19:59:59','BLZBTC','4h','0.000007620000000','0.000007740000000','0.001512221920566','0.001536036439000','198.45432028425196','198.454320284251963','test'),('2019-06-06 11:59:59','2019-06-06 19:59:59','BLZBTC','4h','0.000007610000000','0.000007470000000','0.001512221920566','0.001484401806390','198.71510125703023','198.715101257030227','test'),('2019-06-24 15:59:59','2019-06-24 19:59:59','BLZBTC','4h','0.000007100000000','0.000006750000000','0.001512221920566','0.001437675769552','212.98900289661972','212.989002896619724','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','BLZBTC','4h','0.000003700000000','0.000003690000000','0.001512221920566','0.001508134834294','408.70862717999995','408.708627179999951','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','BLZBTC','4h','0.000003730000000','0.000002970000000','0.001512221920566','0.001204101636483','405.42142642520105','405.421426425201048','test'),('2019-08-17 23:59:59','2019-08-18 11:59:59','BLZBTC','4h','0.000003100000000','0.000003050000000','0.001512221920566','0.001487831244428','487.8135227632258','487.813522763225819','test'),('2019-08-21 03:59:59','2019-08-28 07:59:59','BLZBTC','4h','0.000003100000000','0.000003340000000','0.001512221920566','0.001629297166029','487.8135227632258','487.813522763225819','test'),('2019-08-30 11:59:59','2019-08-31 15:59:59','BLZBTC','4h','0.000003430000000','0.000003260000000','0.001512221920566','0.001437272146077','440.8810264040816','440.881026404081581','test'),('2019-09-01 03:59:59','2019-09-01 07:59:59','BLZBTC','4h','0.000003340000000','0.000003290000000','0.001512221920566','0.001489583867863','452.7610540616766','452.761054061676589','test'),('2019-09-10 03:59:59','2019-09-10 15:59:59','BLZBTC','4h','0.000003050000000','0.000003040000000','0.001512221920566','0.001507263815908','495.81046575934425','495.810465759344254','test'),('2019-09-10 23:59:59','2019-09-12 15:59:59','BLZBTC','4h','0.000003110000000','0.000003060000000','0.001512221920566','0.001487909671039','486.24499053569133','486.244990535691329','test'),('2019-09-13 15:59:59','2019-09-24 03:59:59','BLZBTC','4h','0.000003120000000','0.000003440000000','0.001512221920566','0.001667321604727','484.686513001923','484.686513001923004','test'),('2019-09-28 03:59:59','2019-09-28 15:59:59','BLZBTC','4h','0.000003340000000','0.000003340000000','0.001512221920566','0.001512221920566','452.7610540616766','452.761054061676589','test'),('2019-10-04 15:59:59','2019-10-05 15:59:59','BLZBTC','4h','0.000003240000000','0.000003240000000','0.001512221920566','0.001512221920566','466.7351606685185','466.735160668518517','test'),('2019-10-06 11:59:59','2019-10-06 15:59:59','BLZBTC','4h','0.000003240000000','0.000003240000000','0.001512221920566','0.001512221920566','466.7351606685185','466.735160668518517','test'),('2019-10-07 07:59:59','2019-10-07 19:59:59','BLZBTC','4h','0.000003250000000','0.000003210000000','0.001512221920566','0.001493609958467','465.29905248184616','465.299052481846161','test'),('2019-10-13 23:59:59','2019-10-16 07:59:59','BLZBTC','4h','0.000003270000000','0.000003250000000','0.001512221920566','0.001502972856832','462.45318671743115','462.453186717431151','test'),('2019-10-19 15:59:59','2019-10-19 19:59:59','BLZBTC','4h','0.000003240000000','0.000003230000000','0.001512221920566','0.001507554568959','466.7351606685185','466.735160668518517','test'),('2019-10-19 23:59:59','2019-10-20 19:59:59','BLZBTC','4h','0.000003250000000','0.000003230000000','0.001512221920566','0.001502915939516','465.29905248184616','465.299052481846161','test'),('2019-10-21 15:59:59','2019-10-22 07:59:59','BLZBTC','4h','0.000003290000000','0.000003290000000','0.001512221920566','0.001512221920566','459.64192114468085','459.641921144680850','test'),('2019-10-24 19:59:59','2019-10-24 23:59:59','BLZBTC','4h','0.000003250000000','0.000003280000000','0.001512221920566','0.001526180892140','465.29905248184616','465.299052481846161','test'),('2019-11-08 23:59:59','2019-11-09 03:59:59','BLZBTC','4h','0.000002880000000','0.000002790000000','0.001512221920566','0.001464964985548','525.0770557520833','525.077055752083311','test'),('2019-11-17 03:59:59','2019-11-17 07:59:59','BLZBTC','4h','0.000003260000000','0.000003260000000','0.001512221920566','0.001512221920566','463.8717547748466','463.871754774846579','test'),('2019-11-26 11:59:59','2019-11-26 15:59:59','BLZBTC','4h','0.000003020000000','0.000003000000000','0.001512221920566','0.001502207205860','500.73573528675496','500.735735286754959','test'),('2019-12-02 11:59:59','2019-12-02 19:59:59','BLZBTC','4h','0.000003060000000','0.000002950000000','0.001512221920566','0.001457861001853','494.19017011960784','494.190170119607842','test'),('2019-12-03 11:59:59','2019-12-03 15:59:59','BLZBTC','4h','0.000002940000000','0.000002930000000','0.001512221920566','0.001507078308591','514.3611974714286','514.361197471428568','test'),('2019-12-03 19:59:59','2019-12-03 23:59:59','BLZBTC','4h','0.000002940000000','0.000002930000000','0.001512221920566','0.001507078308591','514.3611974714286','514.361197471428568','test'),('2019-12-07 15:59:59','2019-12-07 19:59:59','BLZBTC','4h','0.000002910000000','0.000002910000000','0.001512221920566','0.001512221920566','519.663890228866','519.663890228865966','test'),('2019-12-28 07:59:59','2019-12-28 19:59:59','BLZBTC','4h','0.000002340000000','0.000002410000000','0.001512221920566','0.001557459328446','646.2486840025641','646.248684002564119','test'),('2019-12-29 23:59:59','2019-12-30 07:59:59','BLZBTC','4h','0.000002390000000','0.000002250000000','0.001512221920566','0.001423639883378','632.7288370569038','632.728837056903785','test'),('2019-12-30 19:59:59','2019-12-30 23:59:59','BLZBTC','4h','0.000002340000000','0.000002260000000','0.001512221920566','0.001460522025846','646.2486840025641','646.248684002564119','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:15:37
