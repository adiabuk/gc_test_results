-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 23:59:59','2019-01-08 03:59:59','ICXETH','4h','0.001827000000000','0.001805000000000','0.072144500000000','0.071275764915161','39.487958401751506','39.487958401751506','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','ICXETH','4h','0.001847000000000','0.001878000000000','0.072144500000000','0.073355371413102','39.06036816459123','39.060368164591232','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','ICXETH','4h','0.001958000000000','0.001915000000000','0.072230034082066','0.070643776949518','36.88970075692836','36.889700756928363','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','ICXETH','4h','0.001960000000000','0.001943000000000','0.072230034082066','0.071603549092579','36.85205820513572','36.852058205135720','test'),('2019-02-07 03:59:59','2019-02-08 19:59:59','ICXETH','4h','0.001885000000000','0.001884000000000','0.072230034082066','0.072191715761598','38.31832046793953','38.318320467939529','test'),('2019-02-10 03:59:59','2019-02-10 07:59:59','ICXETH','4h','0.001916000000000','0.001844000000000','0.072230034082066','0.069515753051842','37.698347641996875','37.698347641996875','test'),('2019-02-11 23:59:59','2019-02-12 11:59:59','ICXETH','4h','0.001902000000000','0.001900000000000','0.072230034082066','0.072154082416365','37.97583285071819','37.975832850718191','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','ICXETH','4h','0.001861000000000','0.001838000000000','0.072230034082066','0.071337346933282','38.81248472975067','38.812484729750672','test'),('2019-02-17 03:59:59','2019-02-17 11:59:59','ICXETH','4h','0.001844000000000','0.001797000000000','0.072230034082066','0.070389029959584','39.17030047834382','39.170300478343819','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','ICXETH','4h','0.001786000000000','0.001730000000000','0.072230034082066','0.069965262576693','40.442348310227324','40.442348310227324','test'),('2019-02-24 19:59:59','2019-02-24 23:59:59','ICXETH','4h','0.001746000000000','0.001757000000000','0.072230034082066','0.072685091570556','41.36886258995762','41.368862589957622','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','ICXETH','4h','0.001739000000000','0.001763000000000','0.072230034082066','0.073226883316091','41.535384751044276','41.535384751044276','test'),('2019-03-19 03:59:59','2019-03-20 15:59:59','ICXETH','4h','0.002467000000000','0.002425000000000','0.072230034082066','0.071000337514799','29.278489696824487','29.278489696824487','test'),('2019-03-24 15:59:59','2019-03-25 15:59:59','ICXETH','4h','0.002509000000000','0.002389000000000','0.072230034082066','0.068775429024335','28.788375481094462','28.788375481094462','test'),('2019-03-30 15:59:59','2019-03-30 19:59:59','ICXETH','4h','0.002372000000000','0.002370000000000','0.072230034082066','0.072169131861086','30.451110489909784','30.451110489909784','test'),('2019-03-31 07:59:59','2019-04-02 07:59:59','ICXETH','4h','0.002379000000000','0.002514000000000','0.072230034082066','0.076328838033760','30.361510753285415','30.361510753285415','test'),('2019-04-03 07:59:59','2019-04-03 23:59:59','ICXETH','4h','0.002461000000000','0.002510000000000','0.072230034082066','0.073668177791949','29.349871630258434','29.349871630258434','test'),('2019-04-22 11:59:59','2019-04-23 19:59:59','ICXETH','4h','0.002299000000000','0.002278000000000','0.072230034082066','0.071570255606327','31.41802265422619','31.418022654226188','test'),('2019-04-24 23:59:59','2019-04-25 23:59:59','ICXETH','4h','0.002353000000000','0.002307000000000','0.072230034082066','0.070817972217308','30.696997059951553','30.696997059951553','test'),('2019-04-27 23:59:59','2019-04-28 03:59:59','ICXETH','4h','0.002279000000000','0.002275000000000','0.072230034082066','0.072103259120974','31.693740272955683','31.693740272955683','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','ICXETH','4h','0.001539000000000','0.001501000000000','0.072230034082066','0.070446576450410','46.93309556989344','46.933095569893439','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','ICXETH','4h','0.001533000000000','0.001528000000000','0.072230034082066','0.071994450148335','47.11678674629224','47.116786746292242','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','ICXETH','4h','0.001531000000000','0.001658000000000','0.072230034082066','0.078221682892270','47.17833708822077','47.178337088220772','test'),('2019-06-07 11:59:59','2019-06-07 19:59:59','ICXETH','4h','0.001525000000000','0.001515000000000','0.072230034082066','0.071756394514315','47.363956775125246','47.363956775125246','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','ICXETH','4h','0.001106000000000','0.001075000000000','0.072230034082066','0.070205503289531','65.30744492049368','65.307444920493680','test'),('2019-07-06 23:59:59','2019-07-07 03:59:59','ICXETH','4h','0.001089000000000','0.001077000000000','0.072230034082066','0.071434110841492','66.32693671447751','66.326936714477512','test'),('2019-07-10 19:59:59','2019-07-11 15:59:59','ICXETH','4h','0.001151000000000','0.001086000000000','0.072230034082066','0.068151013912358','62.75415645705127','62.754156457051273','test'),('2019-07-12 11:59:59','2019-07-13 23:59:59','ICXETH','4h','0.001103000000000','0.001102000000000','0.072230034082066','0.072164549010369','65.48507169724932','65.485071697249325','test'),('2019-07-31 03:59:59','2019-07-31 07:59:59','ICXETH','4h','0.001236000000000','0.001233000000000','0.072230034082066','0.072054718465362','58.438538901347904','58.438538901347904','test'),('2019-08-15 11:59:59','2019-08-18 19:59:59','ICXETH','4h','0.001027000000000','0.001036000000000','0.072230034082066','0.072863013932834','70.33109452976242','70.331094529762424','test'),('2019-08-22 11:59:59','2019-08-31 23:59:59','ICXETH','4h','0.001076000000000','0.001195000000000','0.072230034082066','0.080218299933150','67.12828446288663','67.128284462886626','test'),('2019-09-03 07:59:59','2019-09-03 11:59:59','ICXETH','4h','0.001209000000000','0.001196000000000','0.072230034082066','0.071453367048926','59.7436179338842','59.743617933884202','test'),('2019-09-12 15:59:59','2019-09-12 19:59:59','ICXETH','4h','0.001167000000000','0.001149000000000','0.072230034082066','0.071115946152780','61.8937738492425','61.893773849242500','test'),('2019-10-04 19:59:59','2019-10-04 23:59:59','ICXETH','4h','0.000979000000000','0.000966000000000','0.072230034082066','0.071270901862386','73.779401513857','73.779401513856996','test'),('2019-10-06 15:59:59','2019-10-06 23:59:59','ICXETH','4h','0.000975000000000','0.000971000000000','0.072230034082066','0.071933705737114','74.08208623801642','74.082086238016416','test'),('2019-10-07 07:59:59','2019-10-07 11:59:59','ICXETH','4h','0.000965000000000','0.000964000000000','0.072230034082066','0.072155184305815','74.8497762508456','74.849776250845593','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','ICXETH','4h','0.000970000000000','0.000922000000000','0.072230034082066','0.068655764354294','74.46395266192371','74.463952661923713','test'),('2019-10-22 07:59:59','2019-10-22 11:59:59','ICXETH','4h','0.000911000000000','0.000907000000000','0.072230034082066','0.071912887939005','79.28653576516575','79.286535765165752','test'),('2019-10-23 03:59:59','2019-10-23 07:59:59','ICXETH','4h','0.000907000000000','0.000911000000000','0.072230034082066','0.072548578885074','79.63620075200221','79.636200752002210','test'),('2019-10-27 19:59:59','2019-10-27 23:59:59','ICXETH','4h','0.000904000000000','0.000902000000000','0.072230034082066','0.072070233121707','79.90048017927656','79.900480179276556','test'),('2019-10-30 07:59:59','2019-10-31 11:59:59','ICXETH','4h','0.000915000000000','0.000897000000000','0.072230034082066','0.070809115378812','78.93992795854209','78.939927958542086','test'),('2019-11-02 15:59:59','2019-11-02 19:59:59','ICXETH','4h','0.000896000000000','0.000898000000000','0.072230034082066','0.072391261836713','80.61387732373439','80.613877323734386','test'),('2019-11-17 03:59:59','2019-11-17 07:59:59','ICXETH','4h','0.000887000000000','0.000877000000000','0.072230034082066','0.071415715772234','81.43183098316348','81.431830983163479','test'),('2019-11-17 19:59:59','2019-11-18 15:59:59','ICXETH','4h','0.000903000000000','0.000893000000000','0.072230034082066','0.071430144446606','79.98896354603102','79.988963546031016','test'),('2019-11-19 07:59:59','2019-11-20 11:59:59','ICXETH','4h','0.000922000000000','0.000895000000000','0.072230034082066','0.070114837856235','78.34060095668764','78.340600956687638','test'),('2019-11-21 19:59:59','2019-11-21 23:59:59','ICXETH','4h','0.000898000000000','0.000891000000000','0.072230034082066','0.071666993727306','80.43433639428285','80.434336394282852','test'),('2019-11-23 11:59:59','2019-11-23 15:59:59','ICXETH','4h','0.000892000000000','0.000889000000000','0.072230034082066','0.071987107958472','80.97537453146413','80.975374531464126','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','ICXETH','4h','0.000899000000000','0.000900000000000','0.072230034082066','0.072310378947563','80.34486549729256','80.344865497292560','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','ICXETH','4h','0.000895000000000','0.000866000000000','0.072230034082066','0.069889619569910','80.70394869504582','80.703948695045824','test'),('2019-11-27 07:59:59','2019-11-27 11:59:59','ICXETH','4h','0.000889000000000','0.000907000000000','0.072230034082066','0.073692509462805','81.24863226329134','81.248632263291341','test'),('2019-11-30 19:59:59','2019-11-30 23:59:59','ICXETH','4h','0.000894000000000','0.000900000000000','0.072230034082066','0.072714799411476','80.79422156830648','80.794221568306483','test'),('2019-12-01 07:59:59','2019-12-01 11:59:59','ICXETH','4h','0.000894000000000','0.000884000000000','0.072230034082066','0.071422091866383','80.79422156830648','80.794221568306483','test'),('2019-12-02 11:59:59','2019-12-02 15:59:59','ICXETH','4h','0.000892000000000','0.000883000000000','0.072230034082066','0.071501255711283','80.97537453146413','80.975374531464126','test'),('2019-12-03 07:59:59','2019-12-03 11:59:59','ICXETH','4h','0.000906000000000','0.000902000000000','0.072230034082066','0.071911137684353','79.72409942832893','79.724099428328927','test'),('2019-12-05 11:59:59','2019-12-05 15:59:59','ICXETH','4h','0.000892000000000','0.000892000000000','0.072230034082066','0.072230034082066','80.97537453146413','80.975374531464126','test'),('2019-12-12 03:59:59','2019-12-14 15:59:59','ICXETH','4h','0.000941000000000','0.000908000000000','0.072230034082066','0.069696993566967','76.75880348784911','76.758803487849107','test'),('2019-12-16 19:59:59','2019-12-16 23:59:59','ICXETH','4h','0.000906000000000','0.000897000000000','0.072230034082066','0.071512517187211','79.72409942832893','79.724099428328927','test'),('2019-12-18 03:59:59','2019-12-18 07:59:59','ICXETH','4h','0.000904000000000','0.000903000000000','0.072230034082066','0.072150133601887','79.90048017927656','79.900480179276556','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:02:59
