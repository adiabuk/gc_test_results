-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-04 19:59:59','INSETH','4h','0.002134000000000','0.002084000000000','0.072144500000000','0.070454141518276','33.80716963448922','33.807169634489220','test'),('2019-01-07 15:59:59','2019-01-22 11:59:59','INSETH','4h','0.002124000000000','0.002582000000000','0.072144500000000','0.087701082391714','33.966337099811675','33.966337099811675','test'),('2019-01-30 07:59:59','2019-01-30 15:59:59','INSETH','4h','0.002611000000000','0.002480000000000','0.075611055977497','0.071817471782533','28.95865797682784','28.958657976827840','test'),('2019-01-31 15:59:59','2019-01-31 23:59:59','INSETH','4h','0.002558000000000','0.002540000000000','0.075611055977497','0.075079000071479','29.558661445464033','29.558661445464033','test'),('2019-02-04 07:59:59','2019-02-04 11:59:59','INSETH','4h','0.002540000000000','0.002535000000000','0.075611055977497','0.075462215316124','29.768132274605115','29.768132274605115','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','INSETH','4h','0.001976000000000','0.001974000000000','0.075611055977497','0.075534526568613','38.26470444205314','38.264704442053137','test'),('2019-03-11 03:59:59','2019-03-11 07:59:59','INSETH','4h','0.002044000000000','0.002054000000000','0.075611055977497','0.075980973081105','36.991710360810664','36.991710360810664','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','INSETH','4h','0.002095000000000','0.002064000000000','0.075611055977497','0.074492228896207','36.09119617064296','36.091196170642959','test'),('2019-03-19 11:59:59','2019-03-19 15:59:59','INSETH','4h','0.002088000000000','0.002109000000000','0.075611055977497','0.076371512000259','36.212191560103925','36.212191560103925','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','INSETH','4h','0.002099000000000','0.002071000000000','0.075611055977497','0.074602428265553','36.02241828370509','36.022418283705093','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','INSETH','4h','0.002101000000000','0.002078000000000','0.075611055977497','0.074783329043902','35.98812754759496','35.988127547594956','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','INSETH','4h','0.002093000000000','0.002097000000000','0.075611055977497','0.075755558712284','36.1256836968452','36.125683696845201','test'),('2019-03-25 15:59:59','2019-03-26 11:59:59','INSETH','4h','0.002111000000000','0.002104000000000','0.075611055977497','0.075360332438017','35.81764849715632','35.817648497156320','test'),('2019-04-06 19:59:59','2019-04-07 23:59:59','INSETH','4h','0.002246000000000','0.002132000000000','0.075611055977497','0.071773273082824','33.664762233970166','33.664762233970166','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','INSETH','4h','0.002027000000000','0.002017000000000','0.075611055977497','0.075238036461081','37.30195164158707','37.301951641587067','test'),('2019-04-20 15:59:59','2019-04-21 03:59:59','INSETH','4h','0.002068000000000','0.002021000000000','0.075611055977497','0.073892622887099','36.5624061786736','36.562406178673598','test'),('2019-04-21 19:59:59','2019-04-21 23:59:59','INSETH','4h','0.002029000000000','0.002021000000000','0.075611055977497','0.075312934514796','37.26518283760325','37.265182837603248','test'),('2019-05-01 23:59:59','2019-05-02 03:59:59','INSETH','4h','0.001904000000000','0.001893000000000','0.075611055977497','0.075174227397795','39.71168906381145','39.711689063811448','test'),('2019-05-23 15:59:59','2019-05-24 15:59:59','INSETH','4h','0.001400000000000','0.001371000000000','0.075611055977497','0.074044826960820','54.00789712678357','54.007897126783568','test'),('2019-05-27 07:59:59','2019-05-27 11:59:59','INSETH','4h','0.001395000000000','0.001429000000000','0.075611055977497','0.077453906087343','54.201473818994266','54.201473818994266','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','INSETH','4h','0.001401000000000','0.001393000000000','0.075611055977497','0.075179301196755','53.96934759278872','53.969347592788722','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','INSETH','4h','0.001377000000000','0.001421000000000','0.075611055977497','0.078027095529429','54.909989816628176','54.909989816628176','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','INSETH','4h','0.001379000000000','0.001384000000000','0.075611055977497','0.075885207739562','54.83035241297824','54.830352412978243','test'),('2019-06-04 23:59:59','2019-06-14 11:59:59','INSETH','4h','0.001375000000000','0.001470000000000','0.075611055977497','0.080835092572306','54.98985889272509','54.989858892725088','test'),('2019-06-19 03:59:59','2019-06-20 03:59:59','INSETH','4h','0.001454000000000','0.001450000000000','0.075611055977497','0.075403047570406','52.00210177269395','52.002101772693948','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','INSETH','4h','0.001215000000000','0.001173000000000','0.075611055977497','0.072997340462226','62.231321792178605','62.231321792178605','test'),('2019-07-06 03:59:59','2019-07-06 07:59:59','INSETH','4h','0.001193000000000','0.001175000000000','0.075611055977497','0.074470235350846','63.37892370284744','63.378923702847437','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','INSETH','4h','0.001199000000000','0.001156000000000','0.075611055977497','0.072899400091732','63.06176478523519','63.061764785235191','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','INSETH','4h','0.001223000000000','0.001192000000000','0.075611055977497','0.073694504272426','61.82424855069256','61.824248550692559','test'),('2019-07-12 15:59:59','2019-07-12 19:59:59','INSETH','4h','0.001131000000000','0.001121000000000','0.075611055977497','0.074942523210234','66.85327672634571','66.853276726345712','test'),('2019-07-14 15:59:59','2019-07-15 03:59:59','INSETH','4h','0.001141000000000','0.001180000000000','0.075611055977497','0.078195482956570','66.26735843777125','66.267358437771250','test'),('2019-07-24 07:59:59','2019-07-24 11:59:59','INSETH','4h','0.001243000000000','0.001235000000000','0.075611055977497','0.075124420058092','60.82948992558085','60.829489925580852','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','INSETH','4h','0.001247000000000','0.001228000000000','0.075611055977497','0.074459002999492','60.63436726342982','60.634367263429823','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','INSETH','4h','0.001244000000000','0.001235000000000','0.075611055977497','0.075064030652901','60.78059162178214','60.780591621782143','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','INSETH','4h','0.001238000000000','0.001223000000000','0.075611055977497','0.074694928481808','61.07516637923829','61.075166379238290','test'),('2019-08-03 11:59:59','2019-08-03 23:59:59','INSETH','4h','0.001241000000000','0.001221000000000','0.075611055977497','0.074392505518553','60.92752294721757','60.927522947217568','test'),('2019-08-21 07:59:59','2019-08-21 11:59:59','INSETH','4h','0.001161000000000','0.001122000000000','0.075611055977497','0.073071149704351','65.12580187553574','65.125801875535743','test'),('2019-08-27 03:59:59','2019-08-27 07:59:59','INSETH','4h','0.001125000000000','0.001084000000000','0.075611055977497','0.072855453048539','67.20982753555289','67.209827535552890','test'),('2019-08-27 11:59:59','2019-08-27 15:59:59','INSETH','4h','0.001107000000000','0.001107000000000','0.075611055977497','0.075611055977497','68.30267025970822','68.302670259708222','test'),('2019-09-11 11:59:59','2019-09-12 15:59:59','INSETH','4h','0.001495000000000','0.001486000000000','0.075611055977497','0.075155872362917','50.57595717558328','50.575957175583277','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','INSETH','4h','0.001096000000000','0.001079000000000','0.075611055977497','0.074438256751569','68.98818976048996','68.988189760489959','test'),('2019-10-06 23:59:59','2019-10-07 03:59:59','INSETH','4h','0.001087000000000','0.001080000000000','0.075611055977497','0.075124140253631','69.55938912373229','69.559389123732288','test'),('2019-10-11 19:59:59','2019-10-11 23:59:59','INSETH','4h','0.001107000000000','0.001114000000000','0.075611055977497','0.076089174669315','68.30267025970822','68.302670259708222','test'),('2019-10-13 15:59:59','2019-10-13 19:59:59','INSETH','4h','0.001094000000000','0.001076000000000','0.075611055977497','0.074366998383717','69.11431076553656','69.114310765536558','test'),('2019-10-15 07:59:59','2019-10-15 11:59:59','INSETH','4h','0.001110000000000','0.001090000000000','0.075611055977497','0.074248694608533','68.11806844819549','68.118068448195487','test'),('2019-10-19 15:59:59','2019-10-23 15:59:59','INSETH','4h','0.001148000000000','0.001120000000000','0.075611055977497','0.073766883880485','65.86328917900435','65.863289179004354','test'),('2019-10-24 11:59:59','2019-10-25 19:59:59','INSETH','4h','0.001133000000000','0.001141000000000','0.075611055977497','0.076144938102669','66.73526564651104','66.735265646511039','test'),('2019-10-26 19:59:59','2019-10-26 23:59:59','INSETH','4h','0.001137000000000','0.001110000000000','0.075611055977497','0.073815542774865','66.500488986365','66.500488986364999','test'),('2019-10-27 03:59:59','2019-10-27 11:59:59','INSETH','4h','0.001147000000000','0.001120000000000','0.075611055977497','0.073831196769657','65.92071140147951','65.920711401479508','test'),('2019-10-28 03:59:59','2019-10-29 07:59:59','INSETH','4h','0.001154000000000','0.001183000000000','0.075611055977497','0.077511160503795','65.52084573439947','65.520845734399472','test'),('2019-11-10 03:59:59','2019-11-10 07:59:59','INSETH','4h','0.001066000000000','0.001058000000000','0.075611055977497','0.075043618409186','70.92969603892776','70.929696038927759','test'),('2019-11-15 19:59:59','2019-11-16 11:59:59','INSETH','4h','0.001037000000000','0.001029000000000','0.075611055977497','0.075027749856166','72.91326516634233','72.913265166342327','test'),('2019-11-17 03:59:59','2019-11-17 07:59:59','INSETH','4h','0.001034000000000','0.001029000000000','0.075611055977497','0.075245431915710','73.1248123573472','73.124812357347196','test'),('2019-11-18 07:59:59','2019-11-18 11:59:59','INSETH','4h','0.001027000000000','0.001037000000000','0.075611055977497','0.076347288265496','73.6232287998997','73.623228799899707','test'),('2019-11-19 19:59:59','2019-11-20 07:59:59','INSETH','4h','0.001037000000000','0.001044000000000','0.075611055977497','0.076121448833661','72.91326516634233','72.913265166342327','test'),('2019-11-21 19:59:59','2019-11-22 15:59:59','INSETH','4h','0.001037000000000','0.001032000000000','0.075611055977497','0.075246489651665','72.91326516634233','72.913265166342327','test'),('2019-11-25 19:59:59','2019-11-25 23:59:59','INSETH','4h','0.001044000000000','0.001064000000000','0.075611055977497','0.077059543639901','72.42438312020785','72.424383120207850','test'),('2019-12-10 23:59:59','2019-12-11 03:59:59','INSETH','4h','0.001188000000000','0.001191000000000','0.075611055977497','0.075801992987541','63.64567001472811','63.645670014728111','test'),('2019-12-23 11:59:59','2019-12-23 15:59:59','INSETH','4h','0.001553000000000','0.001521000000000','0.075611055977497','0.074053068990195','48.687093353185446','48.687093353185446','test'),('2019-12-26 23:59:59','2019-12-29 15:59:59','INSETH','4h','0.001535000000000','0.001578000000000','0.075611055977497','0.077729150705205','49.25801692345082','49.258016923450818','test'),('2019-12-30 11:59:59','2020-01-01 15:59:59','INSETH','4h','0.001598000000000','0.001666000000000','0.075611055977497','0.078828547721220','47.31605505475407','47.316055054754067','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 10:16:28
