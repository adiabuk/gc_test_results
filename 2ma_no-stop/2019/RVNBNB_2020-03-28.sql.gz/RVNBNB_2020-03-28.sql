-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-04-06 07:59:59','2019-04-11 07:59:59','RVNBNB','4h','0.003423000000000','0.003604000000000','0.711908500000000','0.749552507741747','207.9779433245691','207.977943324569111','test'),('2019-04-12 07:59:59','2019-04-12 15:59:59','RVNBNB','4h','0.003664000000000','0.003469000000000','0.721319501935437','0.682930500058414','196.8666762924227','196.866676292422710','test'),('2019-04-12 23:59:59','2019-04-13 03:59:59','RVNBNB','4h','0.003515000000000','0.003572000000000','0.721319501935437','0.733016574939796','205.2118070940077','205.211807094007696','test'),('2019-05-10 03:59:59','2019-05-10 07:59:59','RVNBNB','4h','0.002301000000000','0.002325000000000','0.721319501935437','0.728843043024724','313.4808787203116','313.480878720311580','test'),('2019-05-15 19:59:59','2019-05-16 07:59:59','RVNBNB','4h','0.002325000000000','0.002298000000000','0.721319501935437','0.712942888364574','310.2449470690052','310.244947069005207','test'),('2019-05-17 23:59:59','2019-05-18 03:59:59','RVNBNB','4h','0.002230000000000','0.002118000000000','0.721319501935437','0.685091796008635','323.46166006073406','323.461660060734062','test'),('2019-05-30 15:59:59','2019-05-30 23:59:59','RVNBNB','4h','0.001824000000000','0.001704000000000','0.721319501935437','0.673864271544948','395.4602532540773','395.460253254077315','test'),('2019-06-06 23:59:59','2019-06-07 19:59:59','RVNBNB','4h','0.002031000000000','0.002018000000000','0.721319501935437','0.716702488875289','355.154850780619','355.154850780618972','test'),('2019-06-08 15:59:59','2019-06-10 07:59:59','RVNBNB','4h','0.002099000000000','0.002036000000000','0.721319501935437','0.699669607403787','343.64911954999377','343.649119549993770','test'),('2019-06-24 07:59:59','2019-06-24 11:59:59','RVNBNB','4h','0.001801000000000','0.001747000000000','0.721319501935437','0.699691932193897','400.51055076925985','400.510550769259851','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','RVNBNB','4h','0.001697000000000','0.001650000000000','0.721319501935437','0.701341884616070','425.05568764610314','425.055687646103138','test'),('2019-07-04 03:59:59','2019-07-04 11:59:59','RVNBNB','4h','0.001731000000000','0.001655000000000','0.721319501935437','0.689649783768428','416.7068179869654','416.706817986965405','test'),('2019-07-13 03:59:59','2019-07-14 03:59:59','RVNBNB','4h','0.001668000000000','0.001525000000000','0.721319501935437','0.659479760462555','432.44574456560974','432.445744565609743','test'),('2019-07-16 07:59:59','2019-07-16 11:59:59','RVNBNB','4h','0.001542000000000','0.001505000000000','0.721319501935437','0.704011576143212','467.7817781682471','467.781778168247115','test'),('2019-07-16 23:59:59','2019-07-17 03:59:59','RVNBNB','4h','0.001548000000000','0.001603000000000','0.721319501935437','0.746947778812988','465.96867050092834','465.968670500928340','test'),('2019-07-20 15:59:59','2019-07-21 03:59:59','RVNBNB','4h','0.001551000000000','0.001503000000000','0.721319501935437','0.698996267832986','465.0673771343888','465.067377134388778','test'),('2019-07-24 15:59:59','2019-07-26 19:59:59','RVNBNB','4h','0.001616000000000','0.001585000000000','0.721319501935437','0.707482308519596','446.36107793034466','446.361077930344663','test'),('2019-08-22 19:59:59','2019-08-22 23:59:59','RVNBNB','4h','0.001260000000000','0.001272000000000','0.721319501935437','0.728189211477679','572.4757951868547','572.475795186854725','test'),('2019-08-28 23:59:59','2019-09-02 15:59:59','RVNBNB','4h','0.001372000000000','0.001419000000000','0.721319501935437','0.746029426564421','525.7430772124177','525.743077212417688','test'),('2019-09-03 19:59:59','2019-09-04 03:59:59','RVNBNB','4h','0.001417000000000','0.001443000000000','0.721319501935437','0.734554722154436','509.0469314999555','509.046931499955519','test'),('2019-09-06 23:59:59','2019-09-07 03:59:59','RVNBNB','4h','0.001431000000000','0.001426000000000','0.721319501935437','0.718799168245935','504.0667379003753','504.066737900375301','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','RVNBNB','4h','0.001432000000000','0.001419000000000','0.721319501935437','0.714771210367587','503.71473598843374','503.714735988433745','test'),('2019-09-10 19:59:59','2019-09-11 03:59:59','RVNBNB','4h','0.001436000000000','0.001427000000000','0.721319501935437','0.716798697257569','502.3116308742598','502.311630874259777','test'),('2019-09-11 11:59:59','2019-09-23 07:59:59','RVNBNB','4h','0.001421000000000','0.001602000000000','0.721319501935437','0.813197636946214','507.6140055844033','507.614005584403287','test'),('2019-09-24 23:59:59','2019-10-09 07:59:59','RVNBNB','4h','0.001624000000000','0.001882000000000','0.721319501935437','0.835913363696116','444.16225488635286','444.162254886352855','test'),('2019-10-10 07:59:59','2019-10-13 19:59:59','RVNBNB','4h','0.001968000000000','0.001968000000000','0.721319501935437','0.721319501935437','366.5241371623155','366.524137162315526','test'),('2019-11-20 19:59:59','2019-11-20 23:59:59','RVNBNB','4h','0.001364000000000','0.001359000000000','0.721319501935437','0.718675368863826','528.8266143221679','528.826614322167870','test'),('2019-11-21 03:59:59','2019-11-21 11:59:59','RVNBNB','4h','0.001377000000000','0.001362000000000','0.721319501935437','0.713461991021108','523.834060955292','523.834060955291989','test'),('2019-11-21 23:59:59','2019-11-22 03:59:59','RVNBNB','4h','0.001377000000000','0.001355000000000','0.721319501935437','0.709795152594421','523.834060955292','523.834060955291989','test'),('2019-11-22 15:59:59','2019-11-24 07:59:59','RVNBNB','4h','0.001390000000000','0.001393000000000','0.721319501935437','0.722876306615873','518.9348934787317','518.934893478731738','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','RVNBNB','4h','0.001399000000000','0.001394000000000','0.721319501935437','0.718741519441029','515.5964988816562','515.596498881656203','test'),('2019-12-19 03:59:59','2019-12-19 07:59:59','RVNBNB','4h','0.001679000000000','0.001690000000000','0.721319501935437','0.726045240185163','429.61256815690115','429.612568156901148','test'),('2019-12-24 15:59:59','2019-12-25 11:59:59','RVNBNB','4h','0.001695000000000','0.001720000000000','0.721319501935437','0.731958432642449','425.55722828049386','425.557228280493860','test'),('2019-12-26 03:59:59','2019-12-26 07:59:59','RVNBNB','4h','0.001716000000000','0.001698000000000','0.721319501935437','0.713753213453597','420.349360102236','420.349360102236005','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','RVNBNB','4h','0.001689000000000','0.001671000000000','0.721319501935437','0.713632260351756','427.0689768711883','427.068976871188283','test'),('2020-01-01 19:59:59','2020-01-01 23:59:59','RVNBNB','4h','0.001678000000000','0.001669000000000','0.721319501935437','0.717450684582982','429.8685947171854','429.868594717185374','test'),('2020-01-02 11:59:59','2020-01-03 03:59:59','RVNBNB','4h','0.001680000000000','0.001670000000000','0.721319501935437','0.717025933471536','429.3568463901411','429.356846390141072','test'),('2020-01-08 23:59:59','2020-01-09 03:59:59','RVNBNB','4h','0.001662000000000','0.001648000000000','0.721319501935437','0.715243405047894','434.00692053877077','434.006920538770771','test'),('2020-01-18 11:59:59','2020-01-18 15:59:59','RVNBNB','4h','0.001584000000000','0.001530000000000','0.721319501935437','0.696729064369456','455.3784734440891','455.378473444089082','test'),('2020-01-25 15:59:59','2020-01-25 23:59:59','RVNBNB','4h','0.001537000000000','0.001525000000000','0.721319501935437','0.715687859760274','469.30351459690115','469.303514596901152','test'),('2020-01-26 15:59:59','2020-01-26 19:59:59','RVNBNB','4h','0.001537000000000','0.001521000000000','0.721319501935437','0.713810645701887','469.30351459690115','469.303514596901152','test'),('2020-01-30 11:59:59','2020-01-30 15:59:59','RVNBNB','4h','0.001533000000000','0.001514000000000','0.721319501935437','0.712379468969505','470.52805083851075','470.528050838510751','test'),('2020-02-01 15:59:59','2020-02-02 11:59:59','RVNBNB','4h','0.001530000000000','0.001517000000000','0.721319501935437','0.715190643422260','471.4506548597628','471.450654859762778','test'),('2020-02-08 11:59:59','2020-02-08 15:59:59','RVNBNB','4h','0.001607000000000','0.001563000000000','0.721319501935437','0.701569621359731','448.860922175132','448.860922175131975','test'),('2020-02-14 03:59:59','2020-02-15 15:59:59','RVNBNB','4h','0.001513000000000','0.001522000000000','0.721319501935437','0.725610232614498','476.74785322897355','476.747853228973554','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:51:08
