-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-02 11:59:59','XMRBTC','4h','0.012761000000000','0.012768000000000','0.001467500000000','0.001468304991772','0.11499882454353108','0.114998824543531','test'),('2019-01-09 23:59:59','2019-01-10 03:59:59','XMRBTC','4h','0.013039000000000','0.013073000000000','0.001467701247943','0.001471528369841','0.11256240876930745','0.112562408769307','test'),('2019-01-16 23:59:59','2019-01-17 11:59:59','XMRBTC','4h','0.012697000000000','0.012416000000000','0.001468658028417','0.001436154846092','0.11566968799066708','0.115669687990667','test'),('2019-01-21 23:59:59','2019-01-22 03:59:59','XMRBTC','4h','0.012487000000000','0.012578000000000','0.001468658028417','0.001479360989944','0.11761496183366701','0.117614961833667','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','XMRBTC','4h','0.012682000000000','0.012591000000000','0.001468658028417','0.001458119636950','0.11580649963862166','0.115806499638622','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','XMRBTC','4h','0.012728000000000','0.012757000000000','0.001468658028417','0.001472004279425','0.115387965777577','0.115387965777577','test'),('2019-02-01 03:59:59','2019-02-01 07:59:59','XMRBTC','4h','0.012743000000000','0.012612000000000','0.001468658028417','0.001453559997991','0.11525214065895','0.115252140658950','test'),('2019-02-06 19:59:59','2019-02-11 07:59:59','XMRBTC','4h','0.012592000000000','0.013032000000000','0.001468658028417','0.001519977082777','0.1166342144549714','0.116634214454971','test'),('2019-02-15 11:59:59','2019-02-15 15:59:59','XMRBTC','4h','0.013197000000000','0.013078000000000','0.001470465194087','0.001457205714046','0.11142420202218307','0.111424202022183','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','XMRBTC','4h','0.013169000000000','0.013184000000000','0.001470465194087','0.001472140110779','0.11166111277143291','0.111661112771433','test'),('2019-02-18 19:59:59','2019-02-18 23:59:59','XMRBTC','4h','0.013206000000000','0.013092000000000','0.001470465194087','0.001457771491821','0.11134826549197334','0.111348265491973','test'),('2019-02-23 23:59:59','2019-02-24 15:59:59','XMRBTC','4h','0.013038000000000','0.012858000000000','0.001470465194087','0.001450164248011','0.1127830337541801','0.112783033754180','test'),('2019-03-03 19:59:59','2019-03-03 23:59:59','XMRBTC','4h','0.012780000000000','0.012834000000000','0.001470465194087','0.001476678427301','0.1150598743417058','0.115059874341706','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','XMRBTC','4h','0.012780000000000','0.012741000000000','0.001470465194087','0.001465977858988','0.1150598743417058','0.115059874341706','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','XMRBTC','4h','0.012764000000000','0.012712000000000','0.001470465194087','0.001464474580636','0.11520410483288938','0.115204104832889','test'),('2019-03-09 11:59:59','2019-03-09 15:59:59','XMRBTC','4h','0.012776000000000','0.012643000000000','0.001470465194087','0.001455157439640','0.11509589809697872','0.115095898096979','test'),('2019-03-12 11:59:59','2019-03-12 19:59:59','XMRBTC','4h','0.012788000000000','0.012771000000000','0.001470465194087','0.001468510399882','0.1149878944390835','0.114987894439083','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','XMRBTC','4h','0.012993000000000','0.013015000000000','0.001470465194087','0.001472955014319','0.11317364689348111','0.113173646893481','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','XMRBTC','4h','0.013103000000000','0.013231000000000','0.001470465194087','0.001484829808667','0.11222355140708234','0.112223551407082','test'),('2019-03-27 03:59:59','2019-03-27 07:59:59','XMRBTC','4h','0.013131000000000','0.013109000000000','0.001470465194087','0.001468001540575','0.11198425055875409','0.111984250558754','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','XMRBTC','4h','0.013206000000000','0.013066000000000','0.001470465194087','0.001454876436918','0.11134826549197334','0.111348265491973','test'),('2019-03-30 15:59:59','2019-03-30 19:59:59','XMRBTC','4h','0.013180000000000','0.013123000000000','0.001470465194087','0.001464105822610','0.11156792064393019','0.111567920643930','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','XMRBTC','4h','0.013119000000000','0.013630000000000','0.001470465194087','0.001527741489093','0.11208668298551717','0.112086682985517','test'),('2019-04-05 11:59:59','2019-04-06 19:59:59','XMRBTC','4h','0.013577000000000','0.013378000000000','0.001470465194087','0.001448912378765','0.10830560463187744','0.108305604631877','test'),('2019-04-07 07:59:59','2019-04-07 15:59:59','XMRBTC','4h','0.013500000000000','0.013390000000000','0.001470465194087','0.001458483625839','0.10892334771014815','0.108923347710148','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','XMRBTC','4h','0.013472000000000','0.013442000000000','0.001470465194087','0.001467190702117','0.10914973234018706','0.109149732340187','test'),('2019-04-12 15:59:59','2019-04-12 19:59:59','XMRBTC','4h','0.013378000000000','0.013199000000000','0.001470465194087','0.001450790110387','0.10991666871632531','0.109916668716325','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','XMRBTC','4h','0.013146000000000','0.013052000000000','0.001470465194087','0.001459950685625','0.111856473002206','0.111856473002206','test'),('2019-04-19 07:59:59','2019-04-19 15:59:59','XMRBTC','4h','0.013196000000000','0.013077000000000','0.001470465194087','0.001457204709236','0.11143264580835102','0.111432645808351','test'),('2019-04-20 03:59:59','2019-04-20 07:59:59','XMRBTC','4h','0.013164000000000','0.013150000000000','0.001470465194087','0.001468901344747','0.11170352431532968','0.111703524315330','test'),('2019-04-20 23:59:59','2019-04-21 03:59:59','XMRBTC','4h','0.013084000000000','0.013145000000000','0.001470465194087','0.001477320771650','0.11238651743251299','0.112386517432513','test'),('2019-05-02 03:59:59','2019-05-02 07:59:59','XMRBTC','4h','0.012176000000000','0.012181000000000','0.001470465194087','0.001471069031634','0.12076750936982589','0.120767509369826','test'),('2019-05-15 15:59:59','2019-05-16 11:59:59','XMRBTC','4h','0.011437000000000','0.011040000000000','0.001470465194087','0.001419422553355','0.12857088345606366','0.128570883456064','test'),('2019-05-17 15:59:59','2019-05-17 19:59:59','XMRBTC','4h','0.011175000000000','0.011120000000000','0.001470465194087','0.001463228005212','0.13158525226729306','0.131585252267293','test'),('2019-05-20 07:59:59','2019-05-20 15:59:59','XMRBTC','4h','0.011160000000000','0.011135000000000','0.001470465194087','0.001467171141233','0.1317621141655018','0.131762114165502','test'),('2019-05-21 03:59:59','2019-05-22 23:59:59','XMRBTC','4h','0.011626000000000','0.010894000000000','0.001470465194087','0.001377881285428','0.12648074953440563','0.126480749534406','test'),('2019-05-27 19:59:59','2019-05-29 03:59:59','XMRBTC','4h','0.011108000000000','0.010829000000000','0.001470465194087','0.001433531471621','0.1323789335692294','0.132378933569229','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','XMRBTC','4h','0.011008000000000','0.010852000000000','0.001470465194087','0.001449626479491','0.1335815038233103','0.133581503823310','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','XMRBTC','4h','0.011110000000000','0.010952000000000','0.001470465194087','0.001449553087816','0.1323551029781278','0.132355102978128','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','XMRBTC','4h','0.011056000000000','0.010893000000000','0.001470465194087','0.001448785940592','0.1330015551815304','0.133001555181530','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','XMRBTC','4h','0.010992000000000','0.010944000000000','0.001470465194087','0.001464043948698','0.1337759456047125','0.133775945604713','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','XMRBTC','4h','0.010970000000000','0.010787000000000','0.001470465194087','0.001445935100147','0.13404422917839562','0.134044229178396','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','XMRBTC','4h','0.010986000000000','0.010991000000000','0.001470465194087','0.001471134439123','0.13384900728991445','0.133849007289914','test'),('2019-06-06 11:59:59','2019-06-06 23:59:59','XMRBTC','4h','0.011003000000000','0.011125000000000','0.001470465194087','0.001486769543235','0.13364220613350902','0.133642206133509','test'),('2019-06-09 19:59:59','2019-06-09 23:59:59','XMRBTC','4h','0.010988000000000','0.010935000000000','0.001470465194087','0.001463372487927','0.1338246445292137','0.133824644529214','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','XMRBTC','4h','0.011003000000000','0.011020000000000','0.001470465194087','0.001472737111591','0.13364220613350902','0.133642206133509','test'),('2019-06-19 07:59:59','2019-06-19 15:59:59','XMRBTC','4h','0.010861000000000','0.010877000000000','0.001470465194087','0.001472631425843','0.13538948477000276','0.135389484770003','test'),('2019-06-23 03:59:59','2019-06-23 07:59:59','XMRBTC','4h','0.010888000000000','0.010914000000000','0.001470465194087','0.001473976591501','0.1350537467015981','0.135053746701598','test'),('2019-07-06 19:59:59','2019-07-06 23:59:59','XMRBTC','4h','0.008595000000000','0.008400000000000','0.001470465194087','0.001437103854605','0.17108379221489237','0.171083792214892','test'),('2019-07-07 03:59:59','2019-07-08 11:59:59','XMRBTC','4h','0.008791000000000','0.008480000000000','0.001470465194087','0.001418444414271','0.16726938847537254','0.167269388475373','test'),('2019-07-14 03:59:59','2019-07-14 07:59:59','XMRBTC','4h','0.008275000000000','0.008283000000000','0.001470465194087','0.001471886791858','0.17769972133981873','0.177699721339819','test'),('2019-07-14 15:59:59','2019-07-14 19:59:59','XMRBTC','4h','0.008296000000000','0.008290000000000','0.001470465194087','0.001469401694670','0.17724990285523143','0.177249902855231','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','XMRBTC','4h','0.008279000000000','0.008087000000000','0.001470465194087','0.001436363331874','0.1776138656947699','0.177613865694770','test'),('2019-07-22 19:59:59','2019-07-23 07:59:59','XMRBTC','4h','0.008107000000000','0.008170000000000','0.001470465194087','0.001481892270345','0.18138216283298383','0.181382162832984','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','XMRBTC','4h','0.008247000000000','0.008185000000000','0.001470465194087','0.001459410405433','0.17830304281399295','0.178303042813993','test'),('2019-08-07 19:59:59','2019-08-08 03:59:59','XMRBTC','4h','0.008089000000000','0.007977000000000','0.001470465194087','0.001450105186455','0.18178578243132648','0.181785782431326','test'),('2019-08-10 15:59:59','2019-08-11 11:59:59','XMRBTC','4h','0.008016000000000','0.008012000000000','0.001470465194087','0.001469731429020','0.18344126672742014','0.183441266727420','test'),('2019-08-12 19:59:59','2019-08-12 23:59:59','XMRBTC','4h','0.008007000000000','0.008006000000000','0.001470465194087','0.001470281546629','0.18364745773535654','0.183647457735357','test'),('2019-08-15 23:59:59','2019-08-16 03:59:59','XMRBTC','4h','0.008009000000000','0.007925000000000','0.001470465194087','0.001455042659900','0.18360159746372828','0.183601597463728','test'),('2019-08-17 03:59:59','2019-08-17 11:59:59','XMRBTC','4h','0.007981000000000','0.008056000000000','0.001470465194087','0.001484283624053','0.18424573287645657','0.184245732876457','test'),('2019-08-22 15:59:59','2019-08-22 19:59:59','XMRBTC','4h','0.008153000000000','0.008089000000000','0.001470465194087','0.001458922231690','0.18035878745087697','0.180358787450877','test'),('2019-08-25 15:59:59','2019-08-25 19:59:59','XMRBTC','4h','0.008034000000000','0.007936000000000','0.001470465194087','0.001452528227567','0.1830302706107792','0.183030270610779','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','XMRBTC','4h','0.007365000000000','0.007281000000000','0.001470465194087','0.001453694104297','0.19965583083326544','0.199655830833265','test'),('2019-09-07 15:59:59','2019-09-09 19:59:59','XMRBTC','4h','0.007413000000000','0.007281000000000','0.001470465194087','0.001444281273189','0.1983630371087279','0.198363037108728','test'),('2019-09-11 15:59:59','2019-09-11 19:59:59','XMRBTC','4h','0.007400000000000','0.007261000000000','0.001470465194087','0.001442844293820','0.19871151271445944','0.198711512714459','test'),('2019-09-11 23:59:59','2019-09-12 03:59:59','XMRBTC','4h','0.007294000000000','0.007100000000000','0.001470465194087','0.001431354932550','0.20159928627460927','0.201599286274609','test'),('2019-09-13 23:59:59','2019-09-14 07:59:59','XMRBTC','4h','0.007414000000000','0.007310000000000','0.001470465194087','0.001449838220768','0.19833628191084435','0.198336281910844','test'),('2019-09-14 19:59:59','2019-09-14 23:59:59','XMRBTC','4h','0.007282000000000','0.007352000000000','0.001470465194087','0.001484600399194','0.20193150152252126','0.201931501522521','test'),('2019-09-15 07:59:59','2019-09-15 11:59:59','XMRBTC','4h','0.007294000000000','0.007272000000000','0.001470465194087','0.001466030009789','0.20159928627460927','0.201599286274609','test'),('2019-09-16 23:59:59','2019-09-17 07:59:59','XMRBTC','4h','0.007336000000000','0.007279000000000','0.001470465194087','0.001459039823849','0.2004450918875409','0.200445091887541','test'),('2019-09-17 19:59:59','2019-09-17 23:59:59','XMRBTC','4h','0.007285000000000','0.007239000000000','0.001470465194087','0.001461180170212','0.20184834510459848','0.201848345104598','test'),('2019-09-18 03:59:59','2019-09-19 23:59:59','XMRBTC','4h','0.007310000000000','0.007385000000000','0.001470465194087','0.001485552046284','0.2011580292868673','0.201158029286867','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','XMRBTC','4h','0.007044000000000','0.007013000000000','0.001470465194087','0.001463993811206','0.20875428649730265','0.208754286497303','test'),('2019-10-05 15:59:59','2019-10-05 19:59:59','XMRBTC','4h','0.006995000000000','0.006944000000000','0.001470465194087','0.001459744146925','0.2102166110203002','0.210216611020300','test'),('2019-10-06 03:59:59','2019-10-06 07:59:59','XMRBTC','4h','0.006960000000000','0.006962000000000','0.001470465194087','0.001470887741557','0.21127373478261494','0.211273734782615','test'),('2019-10-06 23:59:59','2019-10-07 03:59:59','XMRBTC','4h','0.006955000000000','0.006988000000000','0.001470465194087','0.001477442239580','0.211425621004601','0.211425621004601','test'),('2019-10-16 15:59:59','2019-10-19 03:59:59','XMRBTC','4h','0.006728000000000','0.006924000000000','0.001470465194087','0.001513302765139','0.21855903598201545','0.218559035982015','test'),('2019-10-19 23:59:59','2019-10-21 03:59:59','XMRBTC','4h','0.006841000000000','0.006803000000000','0.001470465194087','0.001462297137169','0.21494886626034204','0.214948866260342','test'),('2019-11-01 19:59:59','2019-11-01 23:59:59','XMRBTC','4h','0.006605000000000','0.006565000000000','0.001470465194087','0.001461560030156','0.22262909827206662','0.222629098272067','test'),('2019-11-19 11:59:59','2019-11-20 03:59:59','XMRBTC','4h','0.007278000000000','0.007201000000000','0.001470465194087','0.001454907922866','0.2020424833865073','0.202042483386507','test'),('2019-11-25 15:59:59','2019-11-25 19:59:59','XMRBTC','4h','0.007183000000000','0.007003000000000','0.001470465194087','0.001433616560517','0.204714630946262','0.204714630946262','test'),('2019-11-26 07:59:59','2019-11-29 15:59:59','XMRBTC','4h','0.007178000000000','0.007169000000000','0.001470465194087','0.001468621479021','0.2048572296025355','0.204857229602535','test'),('2019-11-30 15:59:59','2019-11-30 19:59:59','XMRBTC','4h','0.007207000000000','0.007169000000000','0.001470465194087','0.001462711943445','0.2040329116257805','0.204032911625780','test'),('2019-11-30 23:59:59','2019-12-01 15:59:59','XMRBTC','4h','0.007267000000000','0.007228000000000','0.001470465194087','0.001462573609861','0.202348313483831','0.202348313483831','test'),('2019-12-06 03:59:59','2019-12-06 15:59:59','XMRBTC','4h','0.007287000000000','0.007285000000000','0.001470465194087','0.001470061608196','0.2017929455313572','0.201792945531357','test'),('2019-12-08 07:59:59','2019-12-08 11:59:59','XMRBTC','4h','0.007279000000000','0.007218000000000','0.001470465194087','0.001458142295771','0.20201472648536886','0.202014726485369','test'),('2019-12-09 23:59:59','2019-12-13 03:59:59','XMRBTC','4h','0.007414000000000','0.007293000000000','0.001470465194087','0.001446466503976','0.19833628191084435','0.198336281910844','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 10:26:09
