-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-02 19:59:59','LOOMBNB','4h','0.007930000000000','0.008180000000000','0.711908500000000','0.734352021437579','89.77408575031527','89.774085750315265','test'),('2019-01-04 23:59:59','2019-01-05 15:59:59','LOOMBNB','4h','0.008050000000000','0.007980000000000','0.717519380359395','0.711280081399748','89.13284228067016','89.132842280670161','test'),('2019-01-07 15:59:59','2019-01-08 03:59:59','LOOMBNB','4h','0.008390000000000','0.007850000000000','0.717519380359395','0.671338156832092','85.52078430982063','85.520784309820627','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','LOOMBNB','4h','0.007630000000000','0.007890000000000','0.717519380359395','0.741969582049230','94.03923726859699','94.039237268596992','test'),('2019-01-23 15:59:59','2019-01-23 19:59:59','LOOMBNB','4h','0.007140000000000','0.007090000000000','0.717519380359395','0.712494734838671','100.4929104144811','100.492910414481102','test'),('2019-01-23 23:59:59','2019-01-24 03:59:59','LOOMBNB','4h','0.007110000000000','0.007100000000000','0.717519380359395','0.716510211048060','100.91693113352953','100.916931133529530','test'),('2019-01-24 07:59:59','2019-01-24 11:59:59','LOOMBNB','4h','0.007260000000000','0.007250000000000','0.717519380359395','0.716531061653666','98.83187057291943','98.831870572919428','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','LOOMBNB','4h','0.006930000000000','0.006810000000000','0.717519380359395','0.705094802344514','103.53815012401081','103.538150124010812','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','LOOMBNB','4h','0.004870000000000','0.004570000000000','0.717519380359395','0.673319007852656','147.33457502246304','147.334575022463042','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','LOOMBNB','4h','0.004820000000000','0.004760000000000','0.717519380359395','0.708587603840399','148.86294198327698','148.862941983276983','test'),('2019-02-23 19:59:59','2019-02-24 15:59:59','LOOMBNB','4h','0.004680000000000','0.004640000000000','0.717519380359395','0.711386736082819','153.31610691440065','153.316106914400649','test'),('2019-02-25 07:59:59','2019-02-25 11:59:59','LOOMBNB','4h','0.004710000000000','0.004620000000000','0.717519380359395','0.703808818951254','152.33957120157007','152.339571201570067','test'),('2019-02-25 15:59:59','2019-02-28 11:59:59','LOOMBNB','4h','0.004730000000000','0.004810000000000','0.717519380359395','0.729655014699512','151.6954292514577','151.695429251457711','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','LOOMBNB','4h','0.005010000000000','0.004720000000000','0.717519380359395','0.675986322414440','143.21744118950002','143.217441189500022','test'),('2019-03-03 07:59:59','2019-03-03 11:59:59','LOOMBNB','4h','0.004940000000000','0.004870000000000','0.717519380359395','0.707352101690335','145.24683812943218','145.246838129432177','test'),('2019-03-03 23:59:59','2019-03-04 07:59:59','LOOMBNB','4h','0.005020000000000','0.005160000000000','0.717519380359395','0.737529881006868','142.93214748195118','142.932147481951176','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','LOOMBNB','4h','0.004600000000000','0.004900000000000','0.717519380359395','0.764314122556747','155.98247399117284','155.982473991172839','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','LOOMBNB','4h','0.004460000000000','0.004370000000000','0.717519380359395','0.703040289724340','160.87878483394505','160.878784833945048','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','LOOMBNB','4h','0.004480000000000','0.004350000000000','0.717519380359395','0.696698505482895','160.16057597307926','160.160575973079261','test'),('2019-03-15 03:59:59','2019-03-15 07:59:59','LOOMBNB','4h','0.004470000000000','0.004330000000000','0.717519380359395','0.695046737574090','160.51887703789598','160.518877037895976','test'),('2019-03-15 15:59:59','2019-03-16 07:59:59','LOOMBNB','4h','0.004490000000000','0.004350000000000','0.717519380359395','0.695146838432821','159.80387090409687','159.803870904096868','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','LOOMBNB','4h','0.004400000000000','0.004220000000000','0.717519380359395','0.688166314799238','163.07258644531703','163.072586445317029','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','LOOMBNB','4h','0.004390000000000','0.004360000000000','0.717519380359395','0.712616058853522','163.44405019576197','163.444050195761974','test'),('2019-03-28 19:59:59','2019-03-29 03:59:59','LOOMBNB','4h','0.004450000000000','0.004260000000000','0.717519380359395','0.686883721422702','161.24031019312247','161.240310193122468','test'),('2019-03-29 19:59:59','2019-03-29 23:59:59','LOOMBNB','4h','0.004410000000000','0.004370000000000','0.717519380359395','0.711011268065886','162.7028073377313','162.702807337731286','test'),('2019-04-01 03:59:59','2019-04-01 11:59:59','LOOMBNB','4h','0.004670000000000','0.004140000000000','0.717519380359395','0.636087844686915','153.64440692920664','153.644406929206639','test'),('2019-04-07 15:59:59','2019-04-08 07:59:59','LOOMBNB','4h','0.004350000000000','0.004200000000000','0.717519380359395','0.692777332760795','164.94698399066553','164.946983990665530','test'),('2019-04-08 15:59:59','2019-04-09 03:59:59','LOOMBNB','4h','0.004250000000000','0.004200000000000','0.717519380359395','0.709077975884578','168.82808949632823','168.828089496328232','test'),('2019-05-01 03:59:59','2019-05-01 07:59:59','LOOMBNB','4h','0.002870000000000','0.002900000000000','0.717519380359395','0.725019582941549','250.00675273846514','250.006752738465138','test'),('2019-05-06 07:59:59','2019-05-08 03:59:59','LOOMBNB','4h','0.002820000000000','0.002840000000000','0.717519380359395','0.722608170291022','254.43949658134574','254.439496581345736','test'),('2019-05-09 15:59:59','2019-05-09 19:59:59','LOOMBNB','4h','0.002830000000000','0.002780000000000','0.717519380359395','0.704842359504989','253.54041708812542','253.540417088125423','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','LOOMBNB','4h','0.002840000000000','0.002860000000000','0.717519380359395','0.722572333742208','252.64766914063205','252.647669140632047','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','LOOMBNB','4h','0.002960000000000','0.002880000000000','0.717519380359395','0.698126964674006','242.4051960673632','242.405196067363192','test'),('2019-05-17 15:59:59','2019-05-17 23:59:59','LOOMBNB','4h','0.002820000000000','0.002770000000000','0.717519380359395','0.704797405530328','254.43949658134574','254.439496581345736','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','LOOMBNB','4h','0.002390000000000','0.002370000000000','0.717519380359395','0.711515034080237','300.21731395790584','300.217313957905844','test'),('2019-05-28 23:59:59','2019-05-29 15:59:59','LOOMBNB','4h','0.002360000000000','0.002420000000000','0.717519380359395','0.735761398504125','304.03363574550633','304.033635745506331','test'),('2019-05-30 11:59:59','2019-05-30 23:59:59','LOOMBNB','4h','0.002380000000000','0.002370000000000','0.717519380359395','0.714504593046961','301.47873124344324','301.478731243443235','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','LOOMBNB','4h','0.002420000000000','0.002390000000000','0.717519380359395','0.708624512007832','296.49561171875825','296.495611718758255','test'),('2019-06-07 07:59:59','2019-06-10 15:59:59','LOOMBNB','4h','0.002450000000000','0.002520000000000','0.717519380359395','0.738019934083949','292.86505320791633','292.865053207916333','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','LOOMBNB','4h','0.002590000000000','0.002560000000000','0.717519380359395','0.709208345065657','277.0345097912722','277.034509791272228','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','LOOMBNB','4h','0.002520000000000','0.002420000000000','0.717519380359395','0.689046389075292','284.7299128410298','284.729912841029773','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','LOOMBNB','4h','0.002050000000000','0.002020000000000','0.717519380359395','0.707019096744379','350.0094538338512','350.009453833851182','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','LOOMBNB','4h','0.002070000000000','0.002030000000000','0.717519380359395','0.703654271560180','346.6277199803841','346.627719980384086','test'),('2019-07-04 15:59:59','2019-07-04 23:59:59','LOOMBNB','4h','0.002030000000000','0.001960000000000','0.717519380359395','0.692777332760795','353.4578228371404','353.457822837140384','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','LOOMBNB','4h','0.001558000000000','0.001583000000000','0.717519380359395','0.729032849235509','460.5387550445411','460.538755044541119','test'),('2019-07-29 19:59:59','2019-07-30 07:59:59','LOOMBNB','4h','0.001561000000000','0.001514000000000','0.717519380359395','0.695915657824551','459.65367095412876','459.653670954128756','test'),('2019-08-21 23:59:59','2019-08-26 11:59:59','LOOMBNB','4h','0.001154000000000','0.001222000000000','0.717519380359395','0.759799551819047','621.7672273478292','621.767227347829248','test'),('2019-08-29 07:59:59','2019-08-29 15:59:59','LOOMBNB','4h','0.001254000000000','0.001215000000000','0.717519380359395','0.695204184319509','572.1845138432177','572.184513843217701','test'),('2019-08-29 19:59:59','2019-09-02 23:59:59','LOOMBNB','4h','0.001275000000000','0.001246000000000','0.717519380359395','0.701199331708083','562.7602983210941','562.760298321094069','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','LOOMBNB','4h','0.001264000000000','0.001256000000000','0.717519380359395','0.712978118458386','567.6577376261037','567.657737626103653','test'),('2019-09-03 19:59:59','2019-09-05 19:59:59','LOOMBNB','4h','0.001280000000000','0.001241000000000','0.717519380359395','0.695657461739070','560.5620159057773','560.562015905777344','test'),('2019-09-07 19:59:59','2019-09-09 07:59:59','LOOMBNB','4h','0.001309000000000','0.001273000000000','0.717519380359395','0.697786227041642','548.1431477153513','548.143147715351347','test'),('2019-09-09 19:59:59','2019-09-10 07:59:59','LOOMBNB','4h','0.001300000000000','0.001291000000000','0.717519380359395','0.712551938495368','551.9379848918423','551.937984891842348','test'),('2019-09-20 19:59:59','2019-09-21 07:59:59','LOOMBNB','4h','0.001173000000000','0.001143000000000','0.717519380359395','0.699168501066316','611.6959764359718','611.695976435971829','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','LOOMBNB','4h','0.001163000000000','0.001145000000000','0.717519380359395','0.706414179287625','616.955615098362','616.955615098362046','test'),('2019-10-02 15:59:59','2019-10-02 23:59:59','LOOMBNB','4h','0.001735000000000','0.001713000000000','0.717519380359395','0.708421151905270','413.5558388238588','413.555838823858778','test'),('2019-11-01 07:59:59','2019-11-01 11:59:59','LOOMBNB','4h','0.001190000000000','0.001171000000000','0.717519380359395','0.706063188572144','602.9574624868865','602.957462486886470','test'),('2019-11-01 15:59:59','2019-11-01 19:59:59','LOOMBNB','4h','0.001189000000000','0.001177000000000','0.717519380359395','0.710277805452488','603.4645755756055','603.464575575605522','test'),('2019-11-02 11:59:59','2019-11-02 15:59:59','LOOMBNB','4h','0.001180000000000','0.001169000000000','0.717519380359395','0.710830640372994','608.0672714910127','608.067271491012661','test'),('2019-11-03 03:59:59','2019-11-03 07:59:59','LOOMBNB','4h','0.001185000000000','0.001163000000000','0.717519380359395','0.704198345449769','605.5015868011772','605.501586801177154','test'),('2019-11-03 15:59:59','2019-11-03 19:59:59','LOOMBNB','4h','0.001179000000000','0.001170000000000','0.717519380359395','0.712042133181079','608.5830198128881','608.583019812888097','test'),('2019-11-15 15:59:59','2019-11-15 23:59:59','LOOMBNB','4h','0.001119000000000','0.001098000000000','0.717519380359395','0.704053869199835','641.2148171218901','641.214817121890064','test'),('2019-11-17 19:59:59','2019-11-17 23:59:59','LOOMBNB','4h','0.001105000000000','0.001106000000000','0.717519380359395','0.718168719165150','649.3388057551085','649.338805755108524','test'),('2019-11-18 19:59:59','2019-11-18 23:59:59','LOOMBNB','4h','0.001106000000000','0.001093000000000','0.717519380359395','0.709085608257522','648.7517001441184','648.751700144118445','test'),('2019-11-20 19:59:59','2019-11-20 23:59:59','LOOMBNB','4h','0.001114000000000','0.001093000000000','0.717519380359395','0.703993431537539','644.0928010407496','644.092801040749578','test'),('2019-11-23 03:59:59','2019-11-23 07:59:59','LOOMBNB','4h','0.001094000000000','0.001082000000000','0.717519380359395','0.709648966680864','655.8678065442368','655.867806544236828','test'),('2019-11-26 15:59:59','2019-11-27 19:59:59','LOOMBNB','4h','0.001100000000000','0.001082000000000','0.717519380359395','0.705778154135332','652.2903457812681','652.290345781268115','test'),('2019-12-14 15:59:59','2019-12-15 23:59:59','LOOMBNB','4h','0.001287000000000','0.001257000000000','0.717519380359395','0.700793986877824','557.513116052366','557.513116052365945','test'),('2019-12-19 23:59:59','2019-12-22 11:59:59','LOOMBNB','4h','0.001248000000000','0.001253000000000','0.717519380359395','0.720394057364040','574.9354009290024','574.935400929002412','test'),('2019-12-23 15:59:59','2019-12-23 19:59:59','LOOMBNB','4h','0.001277000000000','0.001252000000000','0.717519380359395','0.703472407368804','561.8789196236453','561.878919623645288','test'),('2019-12-26 23:59:59','2019-12-28 11:59:59','LOOMBNB','4h','0.001270000000000','0.001262000000000','0.717519380359395','0.712999573239021','564.9758900467676','564.975890046767631','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:33:18
