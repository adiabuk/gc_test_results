-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 19:59:59','2019-01-10 07:59:59','DASHETH','4h','0.574350000000000','0.561890000000000','0.072144500000000','0.070579390798294','0.12561069034560807','0.125610690345608','test'),('2019-01-10 19:59:59','2019-01-11 07:59:59','DASHETH','4h','0.567730000000000','0.565900000000000','0.072144500000000','0.071911952072288','0.12707537033448998','0.127075370334490','test'),('2019-01-16 03:59:59','2019-01-16 15:59:59','DASHETH','4h','0.581100000000000','0.576630000000000','0.072144500000000','0.071589542307692','0.12415160901738084','0.124151609017381','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','DASHETH','4h','0.622280000000000','0.620050000000000','0.072144500000000','0.071885963272160','0.11593575239442051','0.115935752394421','test'),('2019-02-04 23:59:59','2019-02-05 03:59:59','DASHETH','4h','0.621090000000000','0.619240000000000','0.072144500000000','0.071929607915117','0.11615788372055579','0.116157883720556','test'),('2019-02-05 07:59:59','2019-02-05 11:59:59','DASHETH','4h','0.620830000000000','0.630910000000000','0.072144500000000','0.073315861822077','0.11620652996794614','0.116206529967946','test'),('2019-02-09 03:59:59','2019-02-09 07:59:59','DASHETH','4h','0.630780000000000','0.626110000000000','0.072144500000000','0.071610375875900','0.11437347411141761','0.114373474111418','test'),('2019-02-09 11:59:59','2019-02-09 15:59:59','DASHETH','4h','0.627950000000000','0.622470000000000','0.072144500000000','0.071514908694960','0.11488892427741063','0.114888924277411','test'),('2019-02-11 07:59:59','2019-02-14 15:59:59','DASHETH','4h','0.634610000000000','0.637280000000000','0.072144500000000','0.072448034162714','0.11368320700902916','0.113683207009029','test'),('2019-02-14 23:59:59','2019-02-15 03:59:59','DASHETH','4h','0.642490000000000','0.635850000000000','0.072144500000000','0.071398901656057','0.11228890722034585','0.112288907220346','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','DASHETH','4h','0.644000000000000','0.651460000000000','0.072144500000000','0.072980211133540','0.11202562111801243','0.112025621118012','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','DASHETH','4h','0.602700000000000','0.596160000000000','0.072144500000000','0.071361647784968','0.11970217355234776','0.119702173552348','test'),('2019-02-26 15:59:59','2019-02-27 03:59:59','DASHETH','4h','0.599130000000000','0.596750000000000','0.072144500000000','0.071857911262998','0.12041543571512024','0.120415435715120','test'),('2019-02-28 15:59:59','2019-03-05 19:59:59','DASHETH','4h','0.606000000000000','0.602800000000000','0.072144500000000','0.071763538943894','0.1190503300330033','0.119050330033003','test'),('2019-03-09 23:59:59','2019-03-10 03:59:59','DASHETH','4h','0.606520000000000','0.601160000000000','0.072144500000000','0.071506937314516','0.11894826221723934','0.118948262217239','test'),('2019-03-10 15:59:59','2019-03-10 19:59:59','DASHETH','4h','0.605120000000000','0.604010000000000','0.072144500000000','0.072012161959611','0.11922345980962454','0.119223459809625','test'),('2019-03-26 19:59:59','2019-03-26 23:59:59','DASHETH','4h','0.661570000000000','0.660460000000000','0.072144500000000','0.072023454010913','0.10905044061852866','0.109050440618529','test'),('2019-03-27 11:59:59','2019-04-08 03:59:59','DASHETH','4h','0.679700000000000','0.750910000000000','0.072144500000000','0.079702849043696','0.10614168015300869','0.106141680153009','test'),('2019-04-25 11:59:59','2019-04-25 15:59:59','DASHETH','4h','0.718860000000000','0.718510000000000','0.072842562507849','0.072807096774775','0.1013306659263956','0.101330665926396','test'),('2019-04-29 11:59:59','2019-04-29 15:59:59','DASHETH','4h','0.713050000000000','0.699620000000000','0.072842562507849','0.071470603157901','0.10215631794102657','0.102156317941027','test'),('2019-05-01 15:59:59','2019-05-03 11:59:59','DASHETH','4h','0.727610000000000','0.711290000000000','0.072842562507849','0.071208733093564','0.1001120964635574','0.100112096463557','test'),('2019-05-13 07:59:59','2019-05-13 15:59:59','DASHETH','4h','0.684800000000000','0.659370000000000','0.072842562507849','0.070137559054907','0.10637056440982623','0.106370564409826','test'),('2019-05-14 15:59:59','2019-05-14 19:59:59','DASHETH','4h','0.685610000000000','0.667730000000000','0.072842562507849','0.070942903784026','0.10624489506840477','0.106244895068405','test'),('2019-05-19 23:59:59','2019-05-21 03:59:59','DASHETH','4h','0.665350000000000','0.645270000000000','0.072842562507849','0.070644202764620','0.10948006689388892','0.109480066893889','test'),('2019-05-29 15:59:59','2019-05-29 23:59:59','DASHETH','4h','0.630360000000000','0.626230000000000','0.072842562507849','0.072365311757234','0.11555708247326765','0.115557082473268','test'),('2019-05-30 23:59:59','2019-05-31 07:59:59','DASHETH','4h','0.640610000000000','0.628880000000000','0.072842562507849','0.071508766191499','0.11370812586105274','0.113708125861053','test'),('2019-06-09 19:59:59','2019-06-10 11:59:59','DASHETH','4h','0.611400000000000','0.602140000000000','0.072842562507849','0.071739320556880','0.11914059945673698','0.119140599456737','test'),('2019-06-10 19:59:59','2019-06-11 07:59:59','DASHETH','4h','0.612000000000000','0.604390000000000','0.072842562507849','0.071936791428299','0.11902379494746569','0.119023794947466','test'),('2019-06-13 03:59:59','2019-06-13 07:59:59','DASHETH','4h','0.610450000000000','0.601050000000000','0.072842562507849','0.071720898018417','0.11932600951404536','0.119326009514045','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','DASHETH','4h','0.608270000000000','0.598690000000000','0.072842562507849','0.071695322386151','0.1197536661480083','0.119753666148008','test'),('2019-06-18 15:59:59','2019-06-19 03:59:59','DASHETH','4h','0.602640000000000','0.595540000000000','0.072842562507849','0.071984368239620','0.1208724321449771','0.120872432144977','test'),('2019-06-19 15:59:59','2019-06-19 19:59:59','DASHETH','4h','0.596560000000000','0.602500000000000','0.072842562507849','0.073567862261933','0.12210433570445386','0.122104335704454','test'),('2019-07-04 15:59:59','2019-07-04 19:59:59','DASHETH','4h','0.546170000000000','0.550180000000000','0.072842562507849','0.073377375250505','0.1333697612608693','0.133369761260869','test'),('2019-07-11 23:59:59','2019-07-12 03:59:59','DASHETH','4h','0.532580000000000','0.541540000000000','0.072842562507849','0.074068048557025','0.13677299655985767','0.136772996559858','test'),('2019-07-14 11:59:59','2019-07-15 15:59:59','DASHETH','4h','0.531080000000000','0.531560000000000','0.072842562507849','0.072908398973172','0.1371593027563625','0.137159302756363','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','DASHETH','4h','0.530210000000000','0.530370000000000','0.072842562507849','0.072864544005748','0.1373843618714264','0.137384361871426','test'),('2019-07-20 07:59:59','2019-07-20 19:59:59','DASHETH','4h','0.518670000000000','0.516930000000000','0.072842562507849','0.072598195070435','0.14044105598521026','0.140441055985210','test'),('2019-07-21 03:59:59','2019-07-23 11:59:59','DASHETH','4h','0.522730000000000','0.519910000000000','0.072842562507849','0.072449594768725','0.1393502621006045','0.139350262100604','test'),('2019-07-24 03:59:59','2019-07-24 15:59:59','DASHETH','4h','0.523960000000000','0.514270000000000','0.072842562507849','0.071495428316878','0.13902313632309526','0.139023136323095','test'),('2019-07-25 15:59:59','2019-07-28 23:59:59','DASHETH','4h','0.520250000000000','0.513300000000000','0.072842562507849','0.071869461480594','0.14001453629572128','0.140014536295721','test'),('2019-08-09 11:59:59','2019-08-10 03:59:59','DASHETH','4h','0.490270000000000','0.488500000000000','0.072842562507849','0.072579582240570','0.1485764221915455','0.148576422191545','test'),('2019-08-11 07:59:59','2019-08-12 07:59:59','DASHETH','4h','0.497910000000000','0.484590000000000','0.072842562507849','0.070893891196559','0.14629664499176356','0.146296644991764','test'),('2019-08-14 19:59:59','2019-08-17 23:59:59','DASHETH','4h','0.514590000000000','0.493770000000000','0.072842562507849','0.069895396508872','0.14155456287111876','0.141554562871119','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','DASHETH','4h','0.490000000000000','0.483490000000000','0.072842562507849','0.071874797034530','0.14865829083234489','0.148658290832345','test'),('2019-08-24 19:59:59','2019-08-24 23:59:59','DASHETH','4h','0.487410000000000','0.483670000000000','0.072842562507849','0.072283626122097','0.14944823148447714','0.149448231484477','test'),('2019-08-25 07:59:59','2019-08-25 11:59:59','DASHETH','4h','0.487740000000000','0.487550000000000','0.072842562507849','0.072814186555751','0.14934711630755934','0.149347116307559','test'),('2019-08-26 19:59:59','2019-08-26 23:59:59','DASHETH','4h','0.489280000000000','0.488900000000000','0.072842562507849','0.072785989229250','0.14887704894508053','0.148877048945081','test'),('2019-08-28 19:59:59','2019-08-29 03:59:59','DASHETH','4h','0.496350000000000','0.481670000000000','0.072842562507849','0.070688177864724','0.14675644707937746','0.146756447079377','test'),('2019-09-06 23:59:59','2019-09-07 19:59:59','DASHETH','4h','0.474460000000000','0.471920000000000','0.072842562507849','0.072452603167188','0.15352729947276694','0.153527299472767','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','DASHETH','4h','0.476360000000000','0.470890000000000','0.072842562507849','0.072006117766649','0.1529149435465803','0.152914943546580','test'),('2019-10-15 11:59:59','2019-10-15 19:59:59','DASHETH','4h','0.395540000000000','0.395950000000000','0.072842562507849','0.072918068020890','0.18415978790476056','0.184159787904761','test'),('2019-10-18 11:59:59','2019-10-18 15:59:59','DASHETH','4h','0.393330000000000','0.391580000000000','0.072842562507849','0.072518472089145','0.18519452497355654','0.185194524973557','test'),('2019-10-18 19:59:59','2019-10-18 23:59:59','DASHETH','4h','0.393080000000000','0.393300000000000','0.072842562507849','0.072883331215877','0.18531230921911315','0.185312309219113','test'),('2019-10-19 19:59:59','2019-10-19 23:59:59','DASHETH','4h','0.394450000000000','0.391830000000000','0.072842562507849','0.072358730555078','0.18466868426378247','0.184668684263782','test'),('2019-10-23 03:59:59','2019-10-23 15:59:59','DASHETH','4h','0.398670000000000','0.393700000000000','0.072842562507849','0.071934474275316','0.1827139300871623','0.182713930087162','test'),('2019-10-26 23:59:59','2019-10-27 03:59:59','DASHETH','4h','0.393790000000000','0.390340000000000','0.072842562507849','0.072204387742994','0.18497819271146804','0.184978192711468','test'),('2019-10-27 15:59:59','2019-10-27 19:59:59','DASHETH','4h','0.395740000000000','0.389220000000000','0.072842562507849','0.071642447514290','0.18406671680358064','0.184066716803581','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','DASHETH','4h','0.394300000000000','0.393980000000000','0.072842562507849','0.072783446048294','0.1847389361091783','0.184738936109178','test'),('2019-11-01 03:59:59','2019-11-01 07:59:59','DASHETH','4h','0.396400000000000','0.392780000000000','0.072842562507849','0.072177350408257','0.18376024850617811','0.183760248506178','test'),('2019-11-01 15:59:59','2019-11-01 23:59:59','DASHETH','4h','0.393500000000000','0.392840000000000','0.072842562507849','0.072720386926514','0.18511451717369504','0.185114517173695','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','DASHETH','4h','0.394710000000000','0.392420000000000','0.072842562507849','0.072419949784222','0.184547040885331','0.184547040885331','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','DASHETH','4h','0.392500000000000','0.393080000000000','0.072842562507849','0.072950202472829','0.18558614651681274','0.185586146516813','test'),('2019-11-05 11:59:59','2019-11-05 15:59:59','DASHETH','4h','0.393000000000000','0.387570000000000','0.072842562507849','0.071836111835031','0.18535003182658777','0.185350031826588','test'),('2019-11-05 23:59:59','2019-11-06 03:59:59','DASHETH','4h','0.394670000000000','0.391050000000000','0.072842562507849','0.072174434511603','0.18456574481934018','0.184565744819340','test'),('2019-11-21 15:59:59','2019-11-22 19:59:59','DASHETH','4h','0.377820000000000','0.363920000000000','0.072842562507849','0.070162684209032','0.19279699991490393','0.192796999914904','test'),('2019-11-29 15:59:59','2019-12-01 03:59:59','DASHETH','4h','0.370400000000000','0.357650000000000','0.072842562507849','0.070335157885886','0.19665918603630939','0.196659186036309','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','DASHETH','4h','0.358660000000000','0.356780000000000','0.072842562507849','0.072460741235572','0.20309642142376905','0.203096421423769','test'),('2019-12-06 19:59:59','2019-12-06 23:59:59','DASHETH','4h','0.355920000000000','0.353730000000000','0.072842562507849','0.072394357259781','0.20465993062443524','0.204659930624435','test'),('2019-12-07 23:59:59','2019-12-08 03:59:59','DASHETH','4h','0.356570000000000','0.353230000000000','0.072842562507849','0.072160244425071','0.20428685113119163','0.204286851131192','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','DASHETH','4h','0.349090000000000','0.347650000000000','0.072842562507849','0.072542086155014','0.20866413391345784','0.208664133913458','test'),('2019-12-13 19:59:59','2019-12-13 23:59:59','DASHETH','4h','0.349280000000000','0.349430000000000','0.072842562507849','0.072873845101688','0.20855062559507845','0.208550625595078','test'),('2019-12-29 07:59:59','2019-12-29 19:59:59','DASHETH','4h','0.339500000000000','0.328000000000000','0.072842562507849','0.070375141391972','0.21455835790235345','0.214558357902353','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 19:13:32
