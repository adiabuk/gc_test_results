-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 15:59:59','2019-01-09 19:59:59','VETBNB','4h','0.000700000000000','0.000710000000000','0.711908500000000','0.722078621428571','1017.012142857143','1017.012142857142976','test'),('2019-01-17 15:59:59','2019-01-17 19:59:59','VETBNB','4h','0.000690000000000','0.000680000000000','0.714451030357143','0.704096667598344','1035.436275879917','1035.436275879917048','test'),('2019-01-22 11:59:59','2019-01-23 15:59:59','VETBNB','4h','0.000670000000000','0.000670000000000','0.714451030357143','0.714451030357143','1066.3448214285715','1066.344821428571549','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','VETBNB','4h','0.000640000000000','0.000640000000000','0.714451030357143','0.714451030357143','1116.3297349330358','1116.329734933035752','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','VETBNB','4h','0.000470000000000','0.000450000000000','0.714451030357143','0.684048858852584','1520.108575227964','1520.108575227963911','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','VETBNB','4h','0.000460000000000','0.000460000000000','0.714451030357143','0.714451030357143','1553.154413819876','1553.154413819876027','test'),('2019-02-23 19:59:59','2019-02-24 11:59:59','VETBNB','4h','0.000460000000000','0.000440000000000','0.714451030357143','0.683387942080745','1553.154413819876','1553.154413819876027','test'),('2019-02-25 03:59:59','2019-02-25 07:59:59','VETBNB','4h','0.000450000000000','0.000440000000000','0.714451030357143','0.698574340793651','1587.6689563492066','1587.668956349206610','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','VETBNB','4h','0.000450000000000','0.000460000000000','0.714451030357143','0.730327719920635','1587.6689563492066','1587.668956349206610','test'),('2019-03-13 03:59:59','2019-03-13 07:59:59','VETBNB','4h','0.000360000000000','0.000350000000000','0.714451030357143','0.694605168402778','1984.5861954365082','1984.586195436508206','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','VETBNB','4h','0.000350000000000','0.000340000000000','0.714451030357143','0.694038143775510','2041.2886581632656','2041.288658163265609','test'),('2019-03-14 23:59:59','2019-03-15 03:59:59','VETBNB','4h','0.000350000000000','0.000350000000000','0.714451030357143','0.714451030357143','2041.2886581632656','2041.288658163265609','test'),('2019-03-15 15:59:59','2019-03-16 11:59:59','VETBNB','4h','0.000350000000000','0.000340000000000','0.714451030357143','0.694038143775510','2041.2886581632656','2041.288658163265609','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','VETBNB','4h','0.000350000000000','0.000330000000000','0.714451030357143','0.673625257193878','2041.2886581632656','2041.288658163265609','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','VETBNB','4h','0.000350000000000','0.000350000000000','0.714451030357143','0.714451030357143','2041.2886581632656','2041.288658163265609','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','VETBNB','4h','0.000360000000000','0.000360000000000','0.714451030357143','0.714451030357143','1984.5861954365082','1984.586195436508206','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','VETBNB','4h','0.000360000000000','0.000360000000000','0.714451030357143','0.714451030357143','1984.5861954365082','1984.586195436508206','test'),('2019-04-01 07:59:59','2019-04-01 11:59:59','VETBNB','4h','0.000360000000000','0.000350000000000','0.714451030357143','0.694605168402778','1984.5861954365082','1984.586195436508206','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','VETBNB','4h','0.000370000000000','0.000360000000000','0.714451030357143','0.695141543050193','1930.9487306949811','1930.948730694981123','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','VETBNB','4h','0.000390000000000','0.000370000000000','0.714451030357143','0.677812515979854','1831.9257188644692','1831.925718864469218','test'),('2019-04-12 11:59:59','2019-04-12 15:59:59','VETBNB','4h','0.000390000000000','0.000370000000000','0.714451030357143','0.677812515979854','1831.9257188644692','1831.925718864469218','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','VETBNB','4h','0.000390000000000','0.000370000000000','0.714451030357143','0.677812515979854','1831.9257188644692','1831.925718864469218','test'),('2019-05-01 03:59:59','2019-05-01 23:59:59','VETBNB','4h','0.000290000000000','0.000300000000000','0.714451030357143','0.739087272783251','2463.624242610838','2463.624242610837882','test'),('2019-05-04 03:59:59','2019-05-04 07:59:59','VETBNB','4h','0.000290000000000','0.000290000000000','0.714451030357143','0.714451030357143','2463.624242610838','2463.624242610837882','test'),('2019-05-06 23:59:59','2019-05-07 03:59:59','VETBNB','4h','0.000290000000000','0.000290000000000','0.714451030357143','0.714451030357143','2463.624242610838','2463.624242610837882','test'),('2019-05-07 19:59:59','2019-05-07 23:59:59','VETBNB','4h','0.000290000000000','0.000300000000000','0.714451030357143','0.739087272783251','2463.624242610838','2463.624242610837882','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','VETBNB','4h','0.000310000000000','0.000300000000000','0.714451030357143','0.691404222926267','2304.680743087558','2304.680743087557858','test'),('2019-05-14 19:59:59','2019-05-14 23:59:59','VETBNB','4h','0.000301200000000','0.000297200000000','0.714451030357143','0.704962968865016','2372.0153730316833','2372.015373031683339','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','VETBNB','4h','0.000297400000000','0.000295500000000','0.714451030357143','0.709886615570060','2402.323572149102','2402.323572149101892','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','VETBNB','4h','0.000238300000000','0.000233800000000','0.714451030357143','0.700959508592111','2998.1159477849055','2998.115947784905529','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','VETBNB','4h','0.000237800000000','0.000235000000000','0.714451030357143','0.706038654894569','3004.419808061997','3004.419808061997173','test'),('2019-06-04 15:59:59','2019-06-07 11:59:59','VETBNB','4h','0.000244600000000','0.000243800000000','0.714451030357143','0.712114313986392','2920.8954634388515','2920.895463438851493','test'),('2019-06-10 07:59:59','2019-06-10 19:59:59','VETBNB','4h','0.000245100000000','0.000242600000000','0.714451030357143','0.707163688146238','2914.9368843620687','2914.936884362068668','test'),('2019-06-25 03:59:59','2019-06-26 23:59:59','VETBNB','4h','0.000289400000000','0.000224700000000','0.714451030357143','0.554724072291811','2468.7319639154907','2468.731963915490724','test'),('2019-07-22 15:59:59','2019-07-22 19:59:59','VETBNB','4h','0.000207800000000','0.000204500000000','0.714451030357143','0.703105080404407','3438.1666523442873','3438.166652344287286','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','VETBNB','4h','0.000203300000000','0.000200300000000','0.714451030357143','0.703908221252020','3514.26970170754','3514.269701707540207','test'),('2019-07-24 23:59:59','2019-07-25 07:59:59','VETBNB','4h','0.000204200000000','0.000202200000000','0.714451030357143','0.707453468845320','3498.7807559115718','3498.780755911571759','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','VETBNB','4h','0.000203100000000','0.000203100000000','0.714451030357143','0.714451030357143','3517.730331645214','3517.730331645213937','test'),('2019-08-07 07:59:59','2019-08-07 11:59:59','VETBNB','4h','0.000205100000000','0.000189000000000','0.714451030357143','0.658367843673818','3483.427744305914','3483.427744305914075','test'),('2019-08-22 19:59:59','2019-08-22 23:59:59','VETBNB','4h','0.000168100000000','0.000165300000000','0.714451030357143','0.702550596775941','4250.154850429167','4250.154850429166800','test'),('2019-08-26 15:59:59','2019-09-05 19:59:59','VETBNB','4h','0.000172700000000','0.000168900000000','0.714451030357143','0.698730625520101','4136.948641326827','4136.948641326826873','test'),('2019-09-10 15:59:59','2019-09-10 19:59:59','VETBNB','4h','0.000181500000000','0.000179300000000','0.714451030357143','0.705791017867965','3936.369313262496','3936.369313262495780','test'),('2019-09-11 07:59:59','2019-09-11 11:59:59','VETBNB','4h','0.000180500000000','0.000179800000000','0.714451030357143','0.711680306139691','3958.1774535021773','3958.177453502177286','test'),('2019-09-15 15:59:59','2019-09-15 19:59:59','VETBNB','4h','0.000180300000000','0.000180400000000','0.714451030357143','0.714847287168212','3962.568110688536','3962.568110688535853','test'),('2019-10-10 11:59:59','2019-10-10 15:59:59','VETBNB','4h','0.000218900000000','0.000216000000000','0.714451030357143','0.704985941330027','3263.823802453828','3263.823802453828193','test'),('2019-10-11 11:59:59','2019-10-11 15:59:59','VETBNB','4h','0.000219900000000','0.000217800000000','0.714451030357143','0.707628169221399','3248.9814932112004','3248.981493211200359','test'),('2019-10-27 11:59:59','2019-10-27 15:59:59','VETBNB','4h','0.000188100000000','0.000214000000000','0.714451030357143','0.812825733633326','3798.2510917445134','3798.251091744513360','test'),('2019-11-22 19:59:59','2019-11-22 23:59:59','VETBNB','4h','0.000342300000000','0.000334000000000','0.714451030357143','0.697127210456575','2087.2072169358544','2087.207216935854376','test'),('2019-11-23 15:59:59','2019-12-06 11:59:59','VETBNB','4h','0.000346000000000','0.000430000000000','0.714451030357143','0.887901569518993','2064.8873709744016','2064.887370974401620','test'),('2019-12-13 03:59:59','2019-12-13 15:59:59','VETBNB','4h','0.000436900000000','0.000414900000000','0.714451030357143','0.678475011433231','1635.2735874505447','1635.273587450544710','test'),('2019-12-20 11:59:59','2019-12-20 15:59:59','VETBNB','4h','0.000400100000000','0.000391900000000','0.714451030357143','0.699808444881190','1785.6811556039563','1785.681155603956313','test'),('2019-12-20 19:59:59','2019-12-20 23:59:59','VETBNB','4h','0.000401500000000','0.000399000000000','0.714451030357143','0.710002393804483','1779.454621063868','1779.454621063867990','test'),('2019-12-23 07:59:59','2019-12-26 23:59:59','VETBNB','4h','0.000400900000000','0.000416600000000','0.714451030357143','0.742430279986994','1782.1178108185159','1782.117810818515864','test'),('2019-12-27 19:59:59','2019-12-28 03:59:59','VETBNB','4h','0.000432500000000','0.000414600000000','0.714451030357143','0.684881843204790','1651.9098967795214','1651.909896779521432','test'),('2019-12-28 15:59:59','2019-12-28 19:59:59','VETBNB','4h','0.000419200000000','0.000414800000000','0.714451030357143','0.706952021450723','1704.3202060046349','1704.320206004634883','test'),('2019-12-29 03:59:59','2019-12-29 11:59:59','VETBNB','4h','0.000423900000000','0.000413000000000','0.714451030357143','0.696079913983251','1685.423520540559','1685.423520540558911','test'),('2020-01-04 23:59:59','2020-01-05 03:59:59','VETBNB','4h','0.000407400000000','0.000400100000000','0.714451030357143','0.701649134133267','1753.6844142296097','1753.684414229609729','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:48:26
