-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-02 03:59:59','BCPTBNB','4h','0.005810000000000','0.005590000000000','0.711908500000000','0.684951551635112','122.53158347676421','122.531583476764212','test'),('2019-01-02 07:59:59','2019-01-02 11:59:59','BCPTBNB','4h','0.005800000000000','0.005720000000000','0.711908500000000','0.702089072413793','122.74284482758623','122.742844827586225','test'),('2019-01-03 11:59:59','2019-01-03 15:59:59','BCPTBNB','4h','0.005740000000000','0.005570000000000','0.711908500000000','0.690824101916376','124.02587108013938','124.025871080139382','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','BCPTBNB','4h','0.005660000000000','0.005540000000000','0.711908500000000','0.696815033568905','125.77888692579506','125.778886925795064','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','BCPTBNB','4h','0.005200000000000','0.004900000000000','0.711908500000000','0.670836855769231','136.9054807692308','136.905480769230792','test'),('2019-01-17 15:59:59','2019-01-17 19:59:59','BCPTBNB','4h','0.005350000000000','0.005150000000000','0.711908500000000','0.685295098130841','133.06700934579442','133.067009345794418','test'),('2019-01-18 23:59:59','2019-01-20 07:59:59','BCPTBNB','4h','0.006000000000000','0.005200000000000','0.711908500000000','0.616987366666667','118.65141666666668','118.651416666666677','test'),('2019-01-22 19:59:59','2019-01-23 15:59:59','BCPTBNB','4h','0.005370000000000','0.005110000000000','0.711908500000000','0.677439932029795','132.57141527001863','132.571415270018633','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','BCPTBNB','4h','0.004910000000000','0.004930000000000','0.711908500000000','0.714808330957230','144.99154786150714','144.991547861507144','test'),('2019-02-21 07:59:59','2019-02-21 23:59:59','BCPTBNB','4h','0.003670000000000','0.003520000000000','0.711908500000000','0.682811422343324','193.98051771117167','193.980517711171672','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','BCPTBNB','4h','0.003390000000000','0.003370000000000','0.711908500000000','0.707708449852508','210.0025073746313','210.002507374631307','test'),('2019-03-02 19:59:59','2019-03-03 19:59:59','BCPTBNB','4h','0.003330000000000','0.003310000000000','0.711908500000000','0.707632773273273','213.78633633633635','213.786336336336348','test'),('2019-03-06 07:59:59','2019-03-06 15:59:59','BCPTBNB','4h','0.003410000000000','0.003210000000000','0.711908500000000','0.670154335777126','208.77082111436954','208.770821114369539','test'),('2019-03-09 15:59:59','2019-03-10 03:59:59','BCPTBNB','4h','0.003450000000000','0.003360000000000','0.711908500000000','0.693336973913044','206.35028985507248','206.350289855072475','test'),('2019-03-10 11:59:59','2019-03-10 15:59:59','BCPTBNB','4h','0.003350000000000','0.003320000000000','0.711908500000000','0.705533200000000','212.51000000000002','212.510000000000019','test'),('2019-03-20 19:59:59','2019-03-21 11:59:59','BCPTBNB','4h','0.003070000000000','0.003050000000000','0.711908500000000','0.707270659609121','231.892019543974','231.892019543973987','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','BCPTBNB','4h','0.002880000000000','0.002940000000000','0.711908500000000','0.726739927083333','247.1904513888889','247.190451388888903','test'),('2019-03-28 11:59:59','2019-03-28 23:59:59','BCPTBNB','4h','0.002880000000000','0.002860000000000','0.711908500000000','0.706964690972222','247.1904513888889','247.190451388888903','test'),('2019-03-31 11:59:59','2019-04-01 07:59:59','BCPTBNB','4h','0.002940000000000','0.002960000000000','0.711908500000000','0.716751414965986','242.14574829931976','242.145748299319763','test'),('2019-04-01 19:59:59','2019-04-02 03:59:59','BCPTBNB','4h','0.002950000000000','0.002860000000000','0.711908500000000','0.690189257627119','241.3249152542373','241.324915254237311','test'),('2019-04-03 03:59:59','2019-04-03 19:59:59','BCPTBNB','4h','0.003090000000000','0.003170000000000','0.711908500000000','0.730339788025890','230.3911003236246','230.391100323624613','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','BCPTBNB','4h','0.002990000000000','0.002930000000000','0.711908500000000','0.697622710702341','238.09648829431438','238.096488294314383','test'),('2019-04-12 07:59:59','2019-04-12 11:59:59','BCPTBNB','4h','0.003190000000000','0.003070000000000','0.711908500000000','0.685128242946708','223.16880877742946','223.168808777429462','test'),('2019-04-23 07:59:59','2019-04-23 11:59:59','BCPTBNB','4h','0.002860000000000','0.002790000000000','0.711908500000000','0.694484166083916','248.91905594405594','248.919055944055941','test'),('2019-05-10 19:59:59','2019-05-10 23:59:59','BCPTBNB','4h','0.002120000000000','0.002120000000000','0.711908500000000','0.711908500000000','335.80589622641514','335.805896226415143','test'),('2019-05-23 07:59:59','2019-05-24 07:59:59','BCPTBNB','4h','0.001800000000000','0.001730000000000','0.711908500000000','0.684223169444445','395.50472222222226','395.504722222222256','test'),('2019-05-25 11:59:59','2019-05-25 15:59:59','BCPTBNB','4h','0.001800000000000','0.001810000000000','0.711908500000000','0.715863547222222','395.50472222222226','395.504722222222256','test'),('2019-06-18 15:59:59','2019-06-18 19:59:59','BCPTBNB','4h','0.001850000000000','0.001890000000000','0.711908500000000','0.727301116216216','384.81540540540544','384.815405405405443','test'),('2019-06-25 23:59:59','2019-06-26 23:59:59','BCPTBNB','4h','0.001650000000000','0.001660000000000','0.711908500000000','0.716223096969697','431.459696969697','431.459696969697006','test'),('2019-06-29 07:59:59','2019-06-29 11:59:59','BCPTBNB','4h','0.001650000000000','0.001640000000000','0.711908500000000','0.707593903030303','431.459696969697','431.459696969697006','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','BCPTBNB','4h','0.001710000000000','0.001670000000000','0.711908500000000','0.695255669590643','416.3207602339182','416.320760233918179','test'),('2019-07-09 15:59:59','2019-07-09 19:59:59','BCPTBNB','4h','0.001690000000000','0.001650000000000','0.711908500000000','0.695058594674556','421.2476331360947','421.247633136094692','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','BCPTBNB','4h','0.001670000000000','0.001620000000000','0.711908500000000','0.690593874251497','426.2925149700599','426.292514970059926','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','BCPTBNB','4h','0.001488000000000','0.001498000000000','0.711908500000000','0.716692831317204','478.43313172043014','478.433131720430140','test'),('2019-07-28 07:59:59','2019-07-31 07:59:59','BCPTBNB','4h','0.001479000000000','0.001500000000000','0.711908500000000','0.722016734279919','481.3444895199459','481.344489519945910','test'),('2019-08-12 11:59:59','2019-08-12 23:59:59','BCPTBNB','4h','0.001365000000000','0.001268000000000','0.711908500000000','0.661318665201465','521.5446886446887','521.544688644688677','test'),('2019-08-13 19:59:59','2019-08-13 23:59:59','BCPTBNB','4h','0.001282000000000','0.001225000000000','0.711908500000000','0.680255781981279','555.3108424336974','555.310842433697417','test'),('2019-08-21 15:59:59','2019-08-26 03:59:59','BCPTBNB','4h','0.001170000000000','0.001240000000000','0.711908500000000','0.754501316239316','608.4688034188034','608.468803418803418','test'),('2019-09-04 03:59:59','2019-09-04 19:59:59','BCPTBNB','4h','0.001397000000000','0.001322000000000','0.711908500000000','0.673688644953472','509.5980672870437','509.598067287043705','test'),('2019-09-08 15:59:59','2019-09-08 19:59:59','BCPTBNB','4h','0.001308000000000','0.001315000000000','0.711908500000000','0.715718407874618','544.2725535168197','544.272553516819698','test'),('2019-09-09 19:59:59','2019-09-14 19:59:59','BCPTBNB','4h','0.001310000000000','0.001614000000000','0.711908500000000','0.877114747328244','543.4416030534352','543.441603053435188','test'),('2019-09-16 15:59:59','2019-09-17 19:59:59','BCPTBNB','4h','0.001628000000000','0.001592000000000','0.711908500000000','0.696166051597052','437.29023341523344','437.290233415233445','test'),('2019-09-17 23:59:59','2019-09-18 03:59:59','BCPTBNB','4h','0.001635000000000','0.001651000000000','0.711908500000000','0.718875188685015','435.4180428134557','435.418042813455713','test'),('2019-09-18 23:59:59','2019-09-19 03:59:59','BCPTBNB','4h','0.001612000000000','0.001553000000000','0.711908500000000','0.685852295595534','441.6305831265509','441.630583126550903','test'),('2019-09-19 15:59:59','2019-09-19 19:59:59','BCPTBNB','4h','0.001630000000000','0.001636000000000','0.711908500000000','0.714529022085890','436.75368098159515','436.753680981595153','test'),('2019-09-20 07:59:59','2019-09-20 11:59:59','BCPTBNB','4h','0.001614000000000','0.001643000000000','0.711908500000000','0.724699916666667','441.08333333333337','441.083333333333371','test'),('2019-09-25 11:59:59','2019-09-26 19:59:59','BCPTBNB','4h','0.001679000000000','0.001740000000000','0.711908500000000','0.737772954139369','424.0074449076832','424.007444907683180','test'),('2019-10-21 19:59:59','2019-10-21 23:59:59','BCPTBNB','4h','0.001674000000000','0.001666000000000','0.711908500000000','0.708506308841099','425.2738948626046','425.273894862604607','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','BCPTBNB','4h','0.001688000000000','0.001712000000000','0.711908500000000','0.722030421800948','421.7467417061612','421.746741706161174','test'),('2019-10-24 11:59:59','2019-10-24 19:59:59','BCPTBNB','4h','0.001704000000000','0.001704000000000','0.711908500000000','0.711908500000000','417.7866784037559','417.786678403755900','test'),('2019-10-30 15:59:59','2019-10-30 19:59:59','BCPTBNB','4h','0.001627000000000','0.001629000000000','0.711908500000000','0.712783618008605','437.5590043023971','437.559004302397113','test'),('2019-11-01 15:59:59','2019-11-01 19:59:59','BCPTBNB','4h','0.001608000000000','0.001573000000000','0.711908500000000','0.696412979166667','442.7291666666667','442.729166666666686','test'),('2019-11-16 19:59:59','2019-11-16 23:59:59','BCPTBNB','4h','0.001448000000000','0.001449000000000','0.711908500000000','0.712400149516575','491.6495165745857','491.649516574585675','test'),('2019-11-22 19:59:59','2019-11-22 23:59:59','BCPTBNB','4h','0.001491000000000','0.001500000000000','0.711908500000000','0.716205734406439','477.4704896042925','477.470489604292482','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','BCPTBNB','4h','0.001487000000000','0.001452000000000','0.711908500000000','0.695152079354405','478.7548755884331','478.754875588433094','test'),('2019-11-25 07:59:59','2019-12-04 11:59:59','BCPTBNB','4h','0.001597000000000','0.001624000000000','0.711908500000000','0.723944523481528','445.77864746399507','445.778647463995071','test'),('2019-12-06 15:59:59','2019-12-10 07:59:59','BCPTBNB','4h','0.001638000000000','0.001638000000000','0.711908500000000','0.711908500000000','434.62057387057393','434.620573870573935','test'),('2019-12-16 19:59:59','2019-12-16 23:59:59','BCPTBNB','4h','0.001628000000000','0.001584000000000','0.711908500000000','0.692667729729730','437.29023341523344','437.290233415233445','test'),('2019-12-19 23:59:59','2019-12-21 03:59:59','BCPTBNB','4h','0.001616000000000','0.001609000000000','0.711908500000000','0.708824737933168','440.5374381188119','440.537438118811906','test'),('2019-12-21 23:59:59','2019-12-22 19:59:59','BCPTBNB','4h','0.001718000000000','0.001584000000000','0.711908500000000','0.656381294528522','414.3821303841677','414.382130384167681','test'),('2019-12-28 07:59:59','2019-12-28 11:59:59','BCPTBNB','4h','0.001666000000000','0.001576000000000','0.711908500000000','0.673450057623049','427.3160264105643','427.316026410564291','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:13:00
