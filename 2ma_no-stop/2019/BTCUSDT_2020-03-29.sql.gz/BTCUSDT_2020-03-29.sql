-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3797.139999999999873','3756.000000000000000','15.000000000000000','14.837482947692211','0.003950341572868001','0.003950341572868','test'),('2019-01-04 23:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3792.010000000000218','3770.960000000000036','15.000000000000000','14.916732814523167','0.003955685770870857','0.003955685770871','test'),('2019-01-19 11:59:59','2019-01-20 11:59:59','BTCUSDT','4h','3695.380000000000109','3580.000000000000000','15.000000000000000','14.531658449198728','0.00405912247184322','0.004059122471843','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','BTCUSDT','4h','3620.579999999999927','3589.929999999999836','15.000000000000000','14.873017582818221','0.004142982616044943','0.004142982616045','test'),('2019-02-08 15:59:59','2019-02-24 15:59:59','BTCUSDT','4h','3507.340000000000146','3778.650000000000091','15.000000000000000','16.160323778133858','0.004276745339773161','0.004276745339773','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','BTCUSDT','4h','3855.389999999999873','3827.920000000000073','15.079803893091546','14.972358936046158','0.003911356281230056','0.003911356281230','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','BTCUSDT','4h','3852.880000000000109','3821.110000000000127','15.079803893091546','14.955459151058699','0.003913904376230649','0.003913904376231','test'),('2019-03-01 07:59:59','2019-03-01 11:59:59','BTCUSDT','4h','3839.019999999999982','3828.590000000000146','15.079803893091546','15.038834490846977','0.003928034731022903','0.003928034731023','test'),('2019-03-01 19:59:59','2019-03-01 23:59:59','BTCUSDT','4h','3845.010000000000218','3823.000000000000000','15.079803893091546','14.993482535361149','0.00392191538984074','0.003921915389841','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','BTCUSDT','4h','3835.849999999999909','3802.460000000000036','15.079803893091546','14.948538423380706','0.003931280913771797','0.003931280913772','test'),('2019-03-05 19:59:59','2019-03-08 23:59:59','BTCUSDT','4h','3855.710000000000036','3864.889999999999873','15.079803893091546','15.115707163757280','0.003911031662934076','0.003911031662934','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','BTCUSDT','4h','3871.610000000000127','3834.690000000000055','15.079803893091546','14.936001609356113','0.003894969765315087','0.003894969765315','test'),('2019-03-12 11:59:59','2019-03-13 11:59:59','BTCUSDT','4h','3885.179999999999836','3856.119999999999891','15.079803893091546','14.967011409568713','0.003881365572017653','0.003881365572018','test'),('2019-03-14 15:59:59','2019-03-21 15:59:59','BTCUSDT','4h','3882.099999999999909','3968.659999999999854','15.079803893091546','15.416041451368253','0.0038844449893334913','0.003884444989333','test'),('2019-03-27 03:59:59','2019-04-12 03:59:59','BTCUSDT','4h','3991.590000000000146','4984.880000000000109','15.079803893091546','18.832348219780634','0.003777893995398211','0.003777893995398','test'),('2019-04-26 23:59:59','2019-04-27 07:59:59','BTCUSDT','4h','5314.100000000000364','5323.000000000000000','15.924240007993852','15.950909761305070','0.0029966014956425077','0.002996601495643','test'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BTCUSDT','4h','5312.189999999999600','5292.529999999999745','15.930907446321656','15.871948402990247','0.002998934045341311','0.002998934045341','test'),('2019-06-12 15:59:59','2019-06-27 23:59:59','BTCUSDT','4h','8140.569999999999709','11329.989999999999782','15.930907446321656','22.172528712086489','0.001956976900428552','0.001956976900429','test'),('2019-07-03 03:59:59','2019-07-03 11:59:59','BTCUSDT','4h','11289.479999999999563','11162.350000000000364','17.476573001930014','17.279770604854566','0.0015480405653697084','0.001548040565370','test'),('2019-07-05 11:59:59','2019-07-05 15:59:59','BTCUSDT','4h','11175.000000000000000','11233.739999999999782','17.476573001930014','17.568436438004586','0.0015638991500608514','0.001563899150061','test'),('2019-07-06 03:59:59','2019-07-06 23:59:59','BTCUSDT','4h','11444.450000000000728','11256.489999999999782','17.476573001930014','17.189543335896015','0.0015270784530431792','0.001527078453043','test'),('2019-07-12 23:59:59','2019-07-13 03:59:59','BTCUSDT','4h','11757.219999999999345','11586.709999999999127','17.476573001930014','17.223117638965036','0.001486454536185426','0.001486454536185','test'),('2019-07-20 19:59:59','2019-07-20 23:59:59','BTCUSDT','4h','10898.659999999999854','10740.229999999999563','17.476573001930014','17.222522186444827','0.0016035524552495458','0.001603552455250','test'),('2019-07-31 15:59:59','2019-08-01 07:59:59','BTCUSDT','4h','10049.639999999999418','9960.190000000000509','17.476573001930014','17.321017235253535','0.0017390247811792277','0.001739024781179','test'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BTCUSDT','4h','10707.799999999999272','10685.879999999999200','17.476573001930014','17.440796607133482','0.0016321347991118638','0.001632134799112','test'),('2019-08-19 23:59:59','2019-08-20 11:59:59','BTCUSDT','4h','10915.540000000000873','10708.819999999999709','17.476573001930014','17.145599255238693','0.0016010726910377327','0.001601072691038','test'),('2019-09-02 19:59:59','2019-09-06 23:59:59','BTCUSDT','4h','10163.680000000000291','10298.729999999999563','17.476573001930014','17.708793141083415','0.0017195123224983484','0.001719512322498','test'),('2019-09-09 11:59:59','2019-09-09 15:59:59','BTCUSDT','4h','10413.260000000000218','10321.100000000000364','17.476573001930014','17.321900885046553','0.001678299879377833','0.001678299879378','test'),('2019-09-12 15:59:59','2019-09-12 19:59:59','BTCUSDT','4h','10326.520000000000437','10300.629999999999200','17.476573001930014','17.432756839755342','0.0016923971485001735','0.001692397148500','test'),('2019-09-13 23:59:59','2019-09-14 15:59:59','BTCUSDT','4h','10342.059999999999491','10356.319999999999709','17.476573001930014','17.500670322097129','0.0016898541491666085','0.001689854149167','test'),('2019-10-09 15:59:59','2019-10-11 11:59:59','BTCUSDT','4h','8550.000000000000000','8297.500000000000000','17.476573001930014','16.960451986375940','0.0020440436259567267','0.002044043625957','test'),('2019-10-12 15:59:59','2019-10-12 19:59:59','BTCUSDT','4h','8372.420000000000073','8309.860000000000582','17.476573001930014','17.345985381265887','0.002087398028518638','0.002087398028519','test'),('2019-10-13 15:59:59','2019-10-13 23:59:59','BTCUSDT','4h','8403.799999999999272','8275.010000000000218','17.476573001930014','17.208740850175026','0.0020796036319200854','0.002079603631920','test'),('2019-10-20 19:59:59','2019-10-21 15:59:59','BTCUSDT','4h','8235.000000000000000','8191.250000000000000','17.476573001930014','17.383725391871184','0.0021222310870588966','0.002122231087059','test'),('2019-10-25 15:59:59','2019-11-07 15:59:59','BTCUSDT','4h','8263.159999999999854','9191.930000000000291','17.476573001930014','19.440920383198502','0.002114998741635163','0.002114998741635','test'),('2019-11-29 15:59:59','2019-11-30 15:59:59','BTCUSDT','4h','7807.989999999999782','7539.399999999999636','17.476573001930014','16.875389759816692','0.002238293466299267','0.002238293466299','test'),('2019-12-06 23:59:59','2019-12-08 03:59:59','BTCUSDT','4h','7527.470000000000255','7403.909999999999854','17.476573001930014','17.189702996454272','0.0023217060980555235','0.002321706098056','test'),('2019-12-08 11:59:59','2019-12-09 11:59:59','BTCUSDT','4h','7520.029999999999745','7471.250000000000000','17.476573001930014','17.363208130907672','0.0023240030959889805','0.002324003095989','test'),('2019-12-18 23:59:59','2019-12-19 07:59:59','BTCUSDT','4h','7277.829999999999927','7092.539999999999964','17.476573001930014','17.031627982394298','0.0024013439448200926','0.002401343944820','test'),('2019-12-25 19:59:59','2019-12-25 23:59:59','BTCUSDT','4h','7239.020000000000437','7204.630000000000109','17.476573001930014','17.393548041985660','0.0024142180850349926','0.002414218085035','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','BTCUSDT','4h','7231.449999999999818','7301.380000000000109','17.476573001930014','17.645576002714776','0.002416745327967422','0.002416745327967','test'),('2019-12-27 23:59:59','2019-12-30 15:59:59','BTCUSDT','4h','7254.739999999999782','7262.079999999999927','17.476573001930014','17.494254965147739','0.002408986814404102','0.002408986814404','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  8:15:09
