-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-16 11:59:59','2019-01-18 15:59:59','MANAETH','4h','0.000316630000000','0.000323210000000','0.072144500000000','0.073643760366990','227.8511196033225','227.851119603322502','test'),('2019-01-28 15:59:59','2019-01-28 23:59:59','MANAETH','4h','0.000336440000000','0.000333830000000','0.072519315091747','0.071956732127803','215.54902833119573','215.549028331195728','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','MANAETH','4h','0.000336660000000','0.000324080000000','0.072519315091747','0.069809480291491','215.4081717214608','215.408171721460803','test'),('2019-02-05 23:59:59','2019-02-06 11:59:59','MANAETH','4h','0.000322800000000','0.000316470000000','0.072519315091747','0.071097235585766','224.65710994964994','224.657109949649936','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','MANAETH','4h','0.000302290000000','0.000298420000000','0.072519315091747','0.071590902807500','239.89981505093454','239.899815050934535','test'),('2019-02-26 11:59:59','2019-03-04 07:59:59','MANAETH','4h','0.000274280000000','0.000303560000000','0.072519315091747','0.080260913261086','264.39884458125636','264.398844581256355','test'),('2019-03-08 03:59:59','2019-03-08 07:59:59','MANAETH','4h','0.000306140000000','0.000341100000000','0.073048987245475','0.081390898116651','238.6130111892443','238.613011189244304','test'),('2019-04-14 03:59:59','2019-04-14 07:59:59','MANAETH','4h','0.000347000000000','0.000332800000000','0.075134464963269','0.072059798097337','216.52583562901805','216.525835629018047','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','MANAETH','4h','0.000339800000000','0.000338740000000','0.075134464963269','0.074900084348610','221.11378741397587','221.113787413975871','test'),('2019-04-19 19:59:59','2019-04-20 07:59:59','MANAETH','4h','0.000338440000000','0.000338810000000','0.075134464963269','0.075216605821431','222.00231935725387','222.002319357253867','test'),('2019-05-01 19:59:59','2019-05-02 03:59:59','MANAETH','4h','0.000320350000000','0.000317850000000','0.075134464963269','0.074548118272437','234.53867633297645','234.538676332976451','test'),('2019-05-03 03:59:59','2019-05-03 07:59:59','MANAETH','4h','0.000320250000000','0.000316140000000','0.075134464963269','0.074170210003085','234.61191245361124','234.611912453611239','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','MANAETH','4h','0.000238440000000','0.000227460000000','0.075134464963269','0.071674573899284','315.1084757728108','315.108475772810777','test'),('2019-05-23 15:59:59','2019-05-23 23:59:59','MANAETH','4h','0.000240250000000','0.000255590000000','0.075134464963269','0.079931812278718','312.73450557031845','312.734505570318447','test'),('2019-05-25 15:59:59','2019-05-25 23:59:59','MANAETH','4h','0.000239190000000','0.000238240000000','0.075134464963269','0.074836050557503','314.1204271218237','314.120427121823695','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','MANAETH','4h','0.000239980000000','0.000225930000000','0.075134464963269','0.070735601588263','313.0863612103884','313.086361210388418','test'),('2019-06-06 07:59:59','2019-06-06 15:59:59','MANAETH','4h','0.000229190000000','0.000230010000000','0.075134464963269','0.075403282369220','327.8261048181378','327.826104818137821','test'),('2019-07-03 19:59:59','2019-07-04 03:59:59','MANAETH','4h','0.000201840000000','0.000207690000000','0.075134464963269','0.077312113695112','372.24764646883176','372.247646468831761','test'),('2019-07-06 23:59:59','2019-07-07 03:59:59','MANAETH','4h','0.000180550000000','0.000185710000000','0.075134464963269','0.077281758451004','416.1421487857602','416.142148785760185','test'),('2019-07-12 15:59:59','2019-07-12 19:59:59','MANAETH','4h','0.000177340000000','0.000173200000000','0.075134464963269','0.073380451853153','423.6746642791756','423.674664279175602','test'),('2019-07-13 03:59:59','2019-07-13 11:59:59','MANAETH','4h','0.000178300000000','0.000172440000000','0.075134464963269','0.072665098924656','421.3935219476669','421.393521947666898','test'),('2019-07-13 15:59:59','2019-07-13 19:59:59','MANAETH','4h','0.000174150000000','0.000171150000000','0.075134464963269','0.073840158934617','431.4353428841172','431.435342884117176','test'),('2019-07-14 11:59:59','2019-07-23 11:59:59','MANAETH','4h','0.000176060000000','0.000198240000000','0.075134464963269','0.084599888301252','426.7548844897706','426.754884489770575','test'),('2019-07-24 03:59:59','2019-07-24 07:59:59','MANAETH','4h','0.000198460000000','0.000197200000000','0.075235506959114','0.074757845270267','379.0965784496309','379.096578449630897','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','MANAETH','4h','0.000195990000000','0.000192990000000','0.075235506959114','0.074083884320830','383.8742127614368','383.874212761436809','test'),('2019-07-27 19:59:59','2019-07-28 23:59:59','MANAETH','4h','0.000197360000000','0.000196640000000','0.075235506959114','0.074961036118971','381.2095001981861','381.209500198186106','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','MANAETH','4h','0.000196690000000','0.000195210000000','0.075235506959114','0.074669395055614','382.50804290565867','382.508042905658669','test'),('2019-07-29 23:59:59','2019-07-30 03:59:59','MANAETH','4h','0.000195960000000','0.000195890000000','0.075235506959114','0.075208631650443','383.9329810120127','383.932981012012704','test'),('2019-08-08 03:59:59','2019-08-08 07:59:59','MANAETH','4h','0.000185790000000','0.000183890000000','0.075235506959114','0.074466103529315','404.9491735783089','404.949173578308887','test'),('2019-08-17 07:59:59','2019-08-18 15:59:59','MANAETH','4h','0.000191670000000','0.000190840000000','0.075235506959114','0.074909710168922','392.5262532431471','392.526253243147096','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','MANAETH','4h','0.000189950000000','0.000184580000000','0.075235506959114','0.073108554222234','396.08058414906026','396.080584149060257','test'),('2019-08-24 03:59:59','2019-08-24 11:59:59','MANAETH','4h','0.000190080000000','0.000196330000000','0.075235506959114','0.077709317557254','395.80969570240956','395.809695702409556','test'),('2019-08-26 19:59:59','2019-08-26 23:59:59','MANAETH','4h','0.000190820000000','0.000187770000000','0.075235506959114','0.074032968984975','394.2747456195053','394.274745619505325','test'),('2019-08-27 07:59:59','2019-08-27 15:59:59','MANAETH','4h','0.000188670000000','0.000186490000000','0.075235506959114','0.074366193315340','398.7677265019028','398.767726501902814','test'),('2019-08-27 19:59:59','2019-08-27 23:59:59','MANAETH','4h','0.000191150000000','0.000187150000000','0.075235506959114','0.073661130669099','393.5940725038661','393.594072503866073','test'),('2019-08-28 07:59:59','2019-08-28 11:59:59','MANAETH','4h','0.000188920000000','0.000189700000000','0.075235506959114','0.075546134184543','398.24003260170446','398.240032601704456','test'),('2019-08-30 19:59:59','2019-08-30 23:59:59','MANAETH','4h','0.000189000000000','0.000189000000000','0.075235506959114','0.075235506959114','398.07146539213755','398.071465392137554','test'),('2019-09-04 07:59:59','2019-09-06 03:59:59','MANAETH','4h','0.000197630000000','0.000183700000000','0.075235506959114','0.069932513426045','380.6886958412893','380.688695841289302','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','MANAETH','4h','0.000169830000000','0.000160160000000','0.075235506959114','0.070951650442040','443.0048104522994','443.004810452299409','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','MANAETH','4h','0.000164240000000','0.000160610000000','0.075235506959114','0.073572666662831','458.0827262488675','458.082726248867516','test'),('2019-10-03 11:59:59','2019-10-06 23:59:59','MANAETH','4h','0.000163020000000','0.000164930000000','0.075235506959114','0.076116992778596','461.51090025220225','461.510900252202248','test'),('2019-10-07 11:59:59','2019-10-07 15:59:59','MANAETH','4h','0.000164690000000','0.000165400000000','0.075235506959114','0.075559857010368','456.83105810379504','456.831058103795044','test'),('2019-10-11 23:59:59','2019-10-18 07:59:59','MANAETH','4h','0.000170360000000','0.000172310000000','0.075235506959114','0.076096678822053','441.62659637892705','441.626596378927047','test'),('2019-10-18 19:59:59','2019-10-18 23:59:59','MANAETH','4h','0.000174950000000','0.000172310000000','0.075235506959114','0.074100201223921','430.0400512095685','430.040051209568503','test'),('2019-10-21 19:59:59','2019-10-21 23:59:59','MANAETH','4h','0.000174070000000','0.000173920000000','0.075235506959114','0.075170674845344','432.2140917970587','432.214091797058700','test'),('2019-10-26 03:59:59','2019-10-26 11:59:59','MANAETH','4h','0.000176480000000','0.000171940000000','0.075235506959114','0.073300051374377','426.3118028054964','426.311802805496427','test'),('2019-10-31 15:59:59','2019-10-31 19:59:59','MANAETH','4h','0.000171170000000','0.000174100000000','0.075235506959114','0.076523349661633','439.5367585389613','439.536758538961294','test'),('2019-11-02 23:59:59','2019-11-03 07:59:59','MANAETH','4h','0.000171860000000','0.000171740000000','0.075235506959114','0.075182974311406','437.7720642331782','437.772064233178185','test'),('2019-11-03 19:59:59','2019-11-03 23:59:59','MANAETH','4h','0.000172710000000','0.000172600000000','0.075235506959114','0.075187589028679','435.61754941296977','435.617549412969765','test'),('2019-11-18 15:59:59','2019-11-18 19:59:59','MANAETH','4h','0.000165880000000','0.000162580000000','0.075235506959114','0.073738779367089','453.55381576509524','453.553815765095237','test'),('2019-11-27 07:59:59','2019-12-01 19:59:59','MANAETH','4h','0.000178740000000','0.000166340000000','0.075235506959114','0.070016080494456','420.9214890853418','420.921489085341818','test'),('2019-12-05 15:59:59','2019-12-10 11:59:59','MANAETH','4h','0.000164050000000','0.000184680000000','0.075235506959114','0.084696698721178','458.61327009517834','458.613270095178336','test'),('2019-12-15 11:59:59','2019-12-15 19:59:59','MANAETH','4h','0.000176990000000','0.000185760000000','0.075235506959114','0.078963488178570','425.083377360947','425.083377360946997','test'),('2019-12-31 15:59:59','2019-12-31 19:59:59','MANAETH','4h','0.000246180000000','0.000244280000000','0.075235506959114','0.074654844585151','305.6117757702251','305.611775770225108','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  1:20:33
