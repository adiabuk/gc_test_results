-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-02 15:59:59','BTSBTC','4h','0.000010480000000','0.000010420000000','0.001467500000000','0.001459098282443','140.02862595419847','140.028625954198475','test'),('2019-01-04 07:59:59','2019-01-04 11:59:59','BTSBTC','4h','0.000010430000000','0.000010300000000','0.001467500000000','0.001449209012464','140.69990412272293','140.699904122722927','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','BTSBTC','4h','0.000010440000000','0.000010280000000','0.001467500000000','0.001445009578544','140.56513409961687','140.565134099616870','test'),('2019-01-07 03:59:59','2019-01-08 15:59:59','BTSBTC','4h','0.000011300000000','0.000010890000000','0.001467500000000','0.001414254424779','129.86725663716814','129.867256637168140','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','BTSBTC','4h','0.000010680000000','0.000010470000000','0.001467500000000','0.001438644662921','137.4063670411985','137.406367041198507','test'),('2019-01-12 03:59:59','2019-01-12 07:59:59','BTSBTC','4h','0.000010590000000','0.000010500000000','0.001467500000000','0.001455028328612','138.57412653446647','138.574126534466473','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','BTSBTC','4h','0.000010550000000','0.000010900000000','0.001467500000000','0.001516184834123','139.0995260663507','139.099526066350705','test'),('2019-01-13 23:59:59','2019-01-14 03:59:59','BTSBTC','4h','0.000010560000000','0.000010660000000','0.001467500000000','0.001481396780303','138.96780303030303','138.967803030303031','test'),('2019-01-16 11:59:59','2019-01-17 15:59:59','BTSBTC','4h','0.000010800000000','0.000010790000000','0.001467500000000','0.001466141203704','135.87962962962965','135.879629629629648','test'),('2019-01-24 03:59:59','2019-01-24 07:59:59','BTSBTC','4h','0.000010910000000','0.000010820000000','0.001467500000000','0.001455394133822','134.5096241979835','134.509624197983499','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','BTSBTC','4h','0.000010830000000','0.000010700000000','0.001467500000000','0.001449884579871','135.5032317636196','135.503231763619596','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','BTSBTC','4h','0.000010750000000','0.000010790000000','0.001467500000000','0.001472960465116','136.51162790697674','136.511627906976742','test'),('2019-01-31 23:59:59','2019-02-03 23:59:59','BTSBTC','4h','0.000010760000000','0.000010870000000','0.001467500000000','0.001482502323420','136.38475836431226','136.384758364312262','test'),('2019-02-07 11:59:59','2019-02-09 19:59:59','BTSBTC','4h','0.000010920000000','0.000010830000000','0.001467500000000','0.001455405219780','134.3864468864469','134.386446886446890','test'),('2019-02-10 23:59:59','2019-02-11 03:59:59','BTSBTC','4h','0.000010900000000','0.000010810000000','0.001467500000000','0.001455383027523','134.63302752293578','134.633027522935777','test'),('2019-02-12 07:59:59','2019-02-14 15:59:59','BTSBTC','4h','0.000010860000000','0.000011110000000','0.001467500000000','0.001501282228361','135.12891344383058','135.128913443830584','test'),('2019-02-21 15:59:59','2019-02-21 23:59:59','BTSBTC','4h','0.000011300000000','0.000011430000000','0.001467500000000','0.001484382743363','129.86725663716814','129.867256637168140','test'),('2019-03-05 23:59:59','2019-03-08 15:59:59','BTSBTC','4h','0.000012030000000','0.000011990000000','0.001467500000000','0.001462620532003','121.98669991687449','121.986699916874485','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','BTSBTC','4h','0.000011940000000','0.000012010000000','0.001467500000000','0.001476103433836','122.90619765494138','122.906197654941380','test'),('2019-03-10 23:59:59','2019-03-11 03:59:59','BTSBTC','4h','0.000011950000000','0.000012030000000','0.001467500000000','0.001477324267782','122.80334728033472','122.803347280334719','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','BTSBTC','4h','0.000012090000000','0.000011970000000','0.001467500000000','0.001452934243176','121.38130686517785','121.381306865177848','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','BTSBTC','4h','0.000012490000000','0.000012410000000','0.001467500000000','0.001458100480384','117.49399519615692','117.493995196156916','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','BTSBTC','4h','0.000012560000000','0.000012340000000','0.001467500000000','0.001441795382166','116.8391719745223','116.839171974522301','test'),('2019-03-22 15:59:59','2019-04-02 07:59:59','BTSBTC','4h','0.000012600000000','0.000013760000000','0.001467500000000','0.001602603174603','116.46825396825398','116.468253968253975','test'),('2019-04-03 03:59:59','2019-04-03 23:59:59','BTSBTC','4h','0.000014420000000','0.000014510000000','0.001475910835775','0.001485122484542','102.35165296634881','102.351652966348809','test'),('2019-05-15 23:59:59','2019-05-17 03:59:59','BTSBTC','4h','0.000008440000000','0.000008770000000','0.001478213747966','0.001536011204936','175.14380900077012','175.143809000770119','test'),('2019-05-25 11:59:59','2019-05-25 15:59:59','BTSBTC','4h','0.000008350000000','0.000008230000000','0.001492663112209','0.001471211666285','178.7620493663473','178.762049366347298','test'),('2019-05-30 07:59:59','2019-05-30 11:59:59','BTSBTC','4h','0.000008200000000','0.000008210000000','0.001492663112209','0.001494483433078','182.03208685475613','182.032086854756130','test'),('2019-06-07 15:59:59','2019-06-08 15:59:59','BTSBTC','4h','0.000007910000000','0.000007910000000','0.001492663112209','0.001492663112209','188.70582960922883','188.705829609228829','test'),('2019-06-09 07:59:59','2019-06-09 15:59:59','BTSBTC','4h','0.000007930000000','0.000007830000000','0.001492663112209','0.001473840122143','188.22990065687264','188.229900656872644','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','BTSBTC','4h','0.000008010000000','0.000007830000000','0.001492663112209','0.001459120120923','186.3499515866417','186.349951586641708','test'),('2019-07-20 07:59:59','2019-07-20 11:59:59','BTSBTC','4h','0.000004530000000','0.000004450000000','0.001492663112209','0.001466302615746','329.5062057856513','329.506205785651275','test'),('2019-07-24 07:59:59','2019-07-25 15:59:59','BTSBTC','4h','0.000004440000000','0.000004470000000','0.001492663112209','0.001502748673778','336.1853856326577','336.185385632657699','test'),('2019-08-14 03:59:59','2019-08-14 19:59:59','BTSBTC','4h','0.000004010000000','0.000003880000000','0.001492663112209','0.001444272537499','372.2351900770574','372.235190077057382','test'),('2019-08-18 11:59:59','2019-08-18 15:59:59','BTSBTC','4h','0.000003900000000','0.000003970000000','0.001492663112209','0.001519454501402','382.73413133564105','382.734131335641052','test'),('2019-08-21 03:59:59','2019-08-23 15:59:59','BTSBTC','4h','0.000003960000000','0.000003960000000','0.001492663112209','0.001492663112209','376.9351293457071','376.935129345707082','test'),('2019-09-09 23:59:59','2019-09-10 03:59:59','BTSBTC','4h','0.000003320000000','0.000003400000000','0.001492663112209','0.001528630898045','449.5973229545181','449.597322954518120','test'),('2019-09-12 11:59:59','2019-09-12 15:59:59','BTSBTC','4h','0.000003360000000','0.000003270000000','0.001492663112209','0.001452681064561','444.24497387172624','444.244973871726245','test'),('2019-09-15 11:59:59','2019-09-15 15:59:59','BTSBTC','4h','0.000003310000000','0.000003270000000','0.001492663112209','0.001474624887288','450.9556230238671','450.955623023867076','test'),('2019-09-16 07:59:59','2019-09-16 11:59:59','BTSBTC','4h','0.000003300000000','0.000003270000000','0.001492663112209','0.001479093447553','452.32215521484846','452.322155214848465','test'),('2019-09-17 15:59:59','2019-09-19 23:59:59','BTSBTC','4h','0.000003350000000','0.000003370000000','0.001492663112209','0.001501574533774','445.5710782713433','445.571078271343310','test'),('2019-09-21 03:59:59','2019-09-21 07:59:59','BTSBTC','4h','0.000003370000000','0.000003380000000','0.001492663112209','0.001497092379604','442.92673952789323','442.926739527893233','test'),('2019-09-23 11:59:59','2019-09-24 03:59:59','BTSBTC','4h','0.000003370000000','0.000003360000000','0.001492663112209','0.001488233844814','442.92673952789323','442.926739527893233','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','BTSBTC','4h','0.000003360000000','0.000003230000000','0.001492663112209','0.001434911265606','444.24497387172624','444.244973871726245','test'),('2019-09-27 03:59:59','2019-10-01 15:59:59','BTSBTC','4h','0.000003390000000','0.000003380000000','0.001492663112209','0.001488259976185','440.3136024215339','440.313602421533915','test'),('2019-10-02 15:59:59','2019-10-02 19:59:59','BTSBTC','4h','0.000003420000000','0.000003420000000','0.001492663112209','0.001492663112209','436.45120240029246','436.451202400292459','test'),('2019-10-03 07:59:59','2019-10-03 11:59:59','BTSBTC','4h','0.000003410000000','0.000003420000000','0.001492663112209','0.001497040423388','437.7311179498534','437.731117949853399','test'),('2019-10-04 23:59:59','2019-10-08 07:59:59','BTSBTC','4h','0.000003560000000','0.000003470000000','0.001492663112209','0.001454927247013','419.28739106994385','419.287391069943851','test'),('2019-10-22 23:59:59','2019-10-23 03:59:59','BTSBTC','4h','0.000003260000000','0.000003240000000','0.001492663112209','0.001483505669803','457.8721203095092','457.872120309509228','test'),('2019-10-23 15:59:59','2019-10-23 19:59:59','BTSBTC','4h','0.000003260000000','0.000003250000000','0.001492663112209','0.001488084391006','457.8721203095092','457.872120309509228','test'),('2019-10-28 03:59:59','2019-10-28 15:59:59','BTSBTC','4h','0.000003280000000','0.000003190000000','0.001492663112209','0.001451705892667','455.08021713689027','455.080217136890269','test'),('2019-11-01 15:59:59','2019-11-01 23:59:59','BTSBTC','4h','0.000003240000000','0.000003160000000','0.001492663112209','0.001455807232895','460.69849142253094','460.698491422530935','test'),('2019-11-05 23:59:59','2019-11-06 03:59:59','BTSBTC','4h','0.000003170000000','0.000003170000000','0.001492663112209','0.001492663112209','470.87164422996847','470.871644229968467','test'),('2019-11-06 15:59:59','2019-11-07 07:59:59','BTSBTC','4h','0.000003190000000','0.000003190000000','0.001492663112209','0.001492663112209','467.91947091191224','467.919470911912242','test'),('2019-11-08 19:59:59','2019-11-08 23:59:59','BTSBTC','4h','0.000003180000000','0.000003180000000','0.001492663112209','0.001492663112209','469.3909157889937','469.390915788993709','test'),('2019-11-10 15:59:59','2019-11-10 19:59:59','BTSBTC','4h','0.000003180000000','0.000003150000000','0.001492663112209','0.001478581384735','469.3909157889937','469.390915788993709','test'),('2019-11-16 19:59:59','2019-11-16 23:59:59','BTSBTC','4h','0.000003130000000','0.000003130000000','0.001492663112209','0.001492663112209','476.88917322971247','476.889173229712469','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 23:32:30
