-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 23:59:59','THETAETH','4h','0.000353100000000','0.000349670000000','0.072144500000000','0.071443691064854','204.3174738034551','204.317473803455101','test'),('2019-02-20 19:59:59','2019-02-20 23:59:59','THETAETH','4h','0.000678530000000','0.000659270000000','0.072144500000000','0.070096686240844','106.32470192917042','106.324701929170416','test'),('2019-02-24 23:59:59','2019-03-04 07:59:59','THETAETH','4h','0.000662050000000','0.000976200000000','0.072144500000000','0.106377858016766','108.9713767842308','108.971376784230799','test'),('2019-03-14 19:59:59','2019-03-14 23:59:59','THETAETH','4h','0.001090000000000','0.001005040000000','0.080015683830616','0.073778865024883','73.40888424827155','73.408884248271548','test'),('2019-03-15 03:59:59','2019-03-15 07:59:59','THETAETH','4h','0.001059960000000','0.001041890000000','0.080015683830616','0.078651591405601','75.48934283427299','75.489342834272989','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','THETAETH','4h','0.000789050000000','0.000751450000000','0.080015683830616','0.076202757258116','101.40762160904379','101.407621609043787','test'),('2019-04-13 23:59:59','2019-04-14 03:59:59','THETAETH','4h','0.000716000000000','0.000740530000000','0.080015683830616','0.082757003278053','111.75374836678213','111.753748366782133','test'),('2019-04-15 19:59:59','2019-04-18 07:59:59','THETAETH','4h','0.000740730000000','0.000731410000000','0.080015683830616','0.079008911898466','108.02273950105436','108.022739501054360','test'),('2019-05-18 07:59:59','2019-05-18 11:59:59','THETAETH','4h','0.000490570000000','0.000483100000000','0.080015683830616','0.078797270233750','163.10757655506043','163.107576555060433','test'),('2019-05-18 15:59:59','2019-05-19 03:59:59','THETAETH','4h','0.000493020000000','0.000467220000000','0.080015683830616','0.075828420346721','162.29703425949452','162.297034259494524','test'),('2019-05-24 03:59:59','2019-05-24 11:59:59','THETAETH','4h','0.000559060000000','0.000477090000000','0.080015683830616','0.068283695128875','143.12539589778555','143.125395897785552','test'),('2019-05-27 07:59:59','2019-05-27 11:59:59','THETAETH','4h','0.000485290000000','0.000479720000000','0.080015683830616','0.079097289965223','164.8822020454079','164.882202045407894','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','THETAETH','4h','0.000490040000000','0.000482800000000','0.080015683830616','0.078833507781857','163.28398463516447','163.283984635164472','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','THETAETH','4h','0.000502690000000','0.000497190000000','0.080015683830616','0.079140221296911','159.17500612826194','159.175006128261941','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','THETAETH','4h','0.000417370000000','0.000407050000000','0.080015683830616','0.078037195062540','191.71402791435895','191.714027914358951','test'),('2019-07-04 03:59:59','2019-07-04 07:59:59','THETAETH','4h','0.000418760000000','0.000399980000000','0.080015683830616','0.076427245244459','191.07766699449803','191.077666994498031','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','THETAETH','4h','0.000411150000000','0.000401410000000','0.080015683830616','0.078120140207826','194.61433498872918','194.614334988729183','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','THETAETH','4h','0.000410170000000','0.000399890000000','0.080015683830616','0.078010268442414','195.07931791846306','195.079317918463062','test'),('2019-07-06 23:59:59','2019-07-07 15:59:59','THETAETH','4h','0.000413470000000','0.000411970000000','0.080015683830616','0.079725400313684','193.52234462141388','193.522344621413879','test'),('2019-07-10 15:59:59','2019-07-12 03:59:59','THETAETH','4h','0.000405870000000','0.000393520000000','0.080015683830616','0.077580929610526','197.1460906955823','197.146090695582302','test'),('2019-07-12 15:59:59','2019-07-31 15:59:59','THETAETH','4h','0.000407000000000','0.000584000000000','0.080015683830616','0.114813659354004','196.59873177055528','196.598731770555275','test'),('2019-08-10 19:59:59','2019-08-11 03:59:59','THETAETH','4h','0.000558450000000','0.000558500000000','0.080015683830616','0.080022847917269','143.28173306583577','143.281733065835766','test'),('2019-08-11 15:59:59','2019-08-11 19:59:59','THETAETH','4h','0.000567510000000','0.000560310000000','0.080015683830616','0.079000524761031','140.99431522020052','140.994315220200519','test'),('2019-08-12 03:59:59','2019-08-14 03:59:59','THETAETH','4h','0.000584130000000','0.000563980000000','0.080015683830616','0.077255483140381','136.98266452778662','136.982664527786625','test'),('2019-08-14 19:59:59','2019-08-26 03:59:59','THETAETH','4h','0.000587410000000','0.000649750000000','0.080015683830616','0.088507499989688','136.21777605184792','136.217776051847920','test'),('2019-08-29 11:59:59','2019-08-30 11:59:59','THETAETH','4h','0.000658320000000','0.000646440000000','0.080015683830616','0.078571725992623','121.5452725583546','121.545272558354597','test'),('2019-09-01 07:59:59','2019-09-01 11:59:59','THETAETH','4h','0.000656700000000','0.000664220000000','0.080015683830616','0.080931959058888','121.8451101425552','121.845110142555200','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','THETAETH','4h','0.000663670000000','0.000644730000000','0.080015683830616','0.077732173875741','120.56546752243736','120.565467522437359','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','THETAETH','4h','0.000649300000000','0.000638850000000','0.080015683830616','0.078727890982888','123.2337653328446','123.233765332844598','test'),('2019-09-05 11:59:59','2019-09-06 07:59:59','THETAETH','4h','0.000656210000000','0.000643900000000','0.080015683830616','0.078514650521226','121.93609337043935','121.936093370439352','test'),('2019-09-07 03:59:59','2019-09-07 07:59:59','THETAETH','4h','0.000650230000000','0.000638750000000','0.080015683830616','0.078602983631647','123.0575086209741','123.057508620974104','test'),('2019-10-06 03:59:59','2019-10-06 07:59:59','THETAETH','4h','0.000496230000000','0.000484490000000','0.080015683830616','0.078122642039166','161.24717133308346','161.247171333083458','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','THETAETH','4h','0.000494630000000','0.000460740000000','0.080015683830616','0.074533340412264','161.76876418861775','161.768764188617752','test'),('2019-10-12 19:59:59','2019-10-13 03:59:59','THETAETH','4h','0.000484660000000','0.000473120000000','0.080015683830616','0.078110469883921','165.09652917636282','165.096529176362822','test'),('2019-10-15 03:59:59','2019-10-16 11:59:59','THETAETH','4h','0.000486730000000','0.000477830000000','0.080015683830616','0.078552573715989','164.3943949019292','164.394394901929189','test'),('2019-10-16 19:59:59','2019-10-17 03:59:59','THETAETH','4h','0.000485140000000','0.000480660000000','0.080015683830616','0.079276783176040','164.93318182507318','164.933181825073177','test'),('2019-10-19 19:59:59','2019-10-19 23:59:59','THETAETH','4h','0.000483560000000','0.000478020000000','0.080015683830616','0.079098968452128','165.4720899797667','165.472089979766707','test'),('2019-10-26 19:59:59','2019-10-26 23:59:59','THETAETH','4h','0.000523300000000','0.000518110000000','0.080015683830616','0.079222101948176','152.90595037381235','152.905950373812345','test'),('2019-10-27 03:59:59','2019-10-27 11:59:59','THETAETH','4h','0.000527950000000','0.000521190000000','0.080015683830616','0.078991143584958','151.55920793752438','151.559207937524377','test'),('2019-11-15 15:59:59','2019-11-16 15:59:59','THETAETH','4h','0.000504510000000','0.000489530000000','0.080015683830616','0.077639844018159','158.6007885485243','158.600788548524292','test'),('2019-11-18 07:59:59','2019-11-18 11:59:59','THETAETH','4h','0.000495040000000','0.000514220000000','0.080015683830616','0.083115839001655','161.63478472571106','161.634784725711057','test'),('2019-11-21 19:59:59','2019-11-22 11:59:59','THETAETH','4h','0.000509140000000','0.000502860000000','0.080015683830616','0.079028728387209','157.15851009666494','157.158510096664941','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','THETAETH','4h','0.000508260000000','0.000484080000000','0.080015683830616','0.076209011586048','157.4306139192854','157.430613919285406','test'),('2019-11-26 11:59:59','2019-11-26 15:59:59','THETAETH','4h','0.000497570000000','0.000502000000000','0.080015683830616','0.080728085059327','160.81291844487407','160.812918444874072','test'),('2019-11-28 07:59:59','2019-11-28 11:59:59','THETAETH','4h','0.000499850000000','0.000504650000000','0.080015683830616','0.080784064909714','160.07939147867557','160.079391478675575','test'),('2019-11-29 19:59:59','2019-11-29 23:59:59','THETAETH','4h','0.000500000000000','0.000503220000000','0.080015683830616','0.080530984834485','160.031367661232','160.031367661231997','test'),('2019-12-03 23:59:59','2019-12-04 03:59:59','THETAETH','4h','0.000497180000000','0.000491440000000','0.080015683830616','0.079091893603359','160.939063982091','160.939063982091000','test'),('2019-12-04 15:59:59','2019-12-04 19:59:59','THETAETH','4h','0.000495470000000','0.000489390000000','0.080015683830616','0.079033797222567','161.49450790283163','161.494507902831629','test'),('2019-12-05 03:59:59','2019-12-10 03:59:59','THETAETH','4h','0.000497440000000','0.000550400000000','0.080015683830616','0.088534561716732','160.85494497952718','160.854944979527176','test'),('2019-12-11 03:59:59','2019-12-17 23:59:59','THETAETH','4h','0.000530510000000','0.000778510000000','0.080015683830616','0.117420991157514','150.82785212458955','150.827852124589555','test'),('2019-12-25 03:59:59','2019-12-25 19:59:59','THETAETH','4h','0.000763910000000','0.000730270000000','0.084578382929554','0.080853838412857','110.7177323631757','110.717732363175699','test'),('2019-12-31 11:59:59','2019-12-31 15:59:59','THETAETH','4h','0.000708700000000','0.000696490000000','0.084578382929554','0.083121204919719','119.34299834846055','119.342998348460554','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  9:24:09
