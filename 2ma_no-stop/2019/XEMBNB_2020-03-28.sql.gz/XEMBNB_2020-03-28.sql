-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-23 23:59:59','2019-02-24 11:59:59','XEMBNB','4h','0.004510000000000','0.004390000000000','0.711908500000000','0.692966366962306','157.85110864745013','157.851108647450133','test'),('2019-02-25 23:59:59','2019-02-27 15:59:59','XEMBNB','4h','0.004430000000000','0.004380000000000','0.711908500000000','0.703873415349887','160.70169300225734','160.701693002257343','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','XEMBNB','4h','0.003280000000000','0.003210000000000','0.711908500000000','0.696715330792683','217.04527439024392','217.045274390243918','test'),('2019-03-14 23:59:59','2019-03-15 03:59:59','XEMBNB','4h','0.003260000000000','0.003320000000000','0.711908500000000','0.725011110429448','218.37684049079758','218.376840490797576','test'),('2019-03-20 07:59:59','2019-03-21 19:59:59','XEMBNB','4h','0.003280000000000','0.003300000000000','0.711908500000000','0.716249405487805','217.04527439024392','217.045274390243918','test'),('2019-03-29 03:59:59','2019-03-30 23:59:59','XEMBNB','4h','0.003230000000000','0.003160000000000','0.711908500000000','0.696480142414861','220.40510835913315','220.405108359133152','test'),('2019-03-31 19:59:59','2019-03-31 23:59:59','XEMBNB','4h','0.003210000000000','0.003190000000000','0.711908500000000','0.707472933021807','221.77834890965732','221.778348909657325','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XEMBNB','4h','0.003270000000000','0.003230000000000','0.711908500000000','0.703200139143731','217.70902140672786','217.709021406727857','test'),('2019-04-12 11:59:59','2019-04-12 15:59:59','XEMBNB','4h','0.003740000000000','0.003640000000000','0.711908500000000','0.692873513368984','190.34986631016045','190.349866310160451','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','XEMBNB','4h','0.002500000000000','0.002520000000000','0.711908500000000','0.717603768000000','284.7634','284.763399999999990','test'),('2019-05-13 15:59:59','2019-05-13 19:59:59','XEMBNB','4h','0.002600000000000','0.002460000000000','0.711908500000000','0.673574965384615','273.8109615384616','273.810961538461584','test'),('2019-05-14 07:59:59','2019-05-15 15:59:59','XEMBNB','4h','0.002690000000000','0.002620000000000','0.711908500000000','0.693383000000000','264.65000000000003','264.650000000000034','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','XEMBNB','4h','0.002750000000000','0.002650000000000','0.711908500000000','0.686020918181818','258.8758181818182','258.875818181818204','test'),('2019-05-28 15:59:59','2019-05-29 07:59:59','XEMBNB','4h','0.002710000000000','0.002700000000000','0.711908500000000','0.709281531365314','262.6968634686347','262.696863468634717','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','XEMBNB','4h','0.002750000000000','0.002680000000000','0.711908500000000','0.693787192727273','258.8758181818182','258.875818181818204','test'),('2019-05-30 03:59:59','2019-05-31 07:59:59','XEMBNB','4h','0.002730000000000','0.003210000000000','0.711908500000000','0.837079225274726','260.77234432234434','260.772344322344338','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','XEMBNB','4h','0.002820000000000','0.002760000000000','0.711908500000000','0.696761510638298','252.44982269503546','252.449822695035465','test'),('2019-06-14 15:59:59','2019-06-14 19:59:59','XEMBNB','4h','0.002670000000000','0.002600000000000','0.711908500000000','0.693244232209738','266.6323970037453','266.632397003745325','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','XEMBNB','4h','0.002660000000000','0.002550000000000','0.711908500000000','0.682468674812030','267.63477443609025','267.634774436090254','test'),('2019-06-16 07:59:59','2019-06-17 15:59:59','XEMBNB','4h','0.002710000000000','0.002660000000000','0.711908500000000','0.698773656826568','262.6968634686347','262.696863468634717','test'),('2019-06-25 15:59:59','2019-06-25 23:59:59','XEMBNB','4h','0.002490000000000','0.002550000000000','0.711908500000000','0.729062921686747','285.90702811244984','285.907028112449836','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','XEMBNB','4h','0.002740000000000','0.002700000000000','0.711908500000000','0.701515675182482','259.8206204379562','259.820620437956222','test'),('2019-07-07 19:59:59','2019-07-08 07:59:59','XEMBNB','4h','0.002740000000000','0.002710000000000','0.711908500000000','0.704113881386861','259.8206204379562','259.820620437956222','test'),('2019-07-08 19:59:59','2019-07-09 11:59:59','XEMBNB','4h','0.002730000000000','0.002710000000000','0.711908500000000','0.706693053113553','260.77234432234434','260.772344322344338','test'),('2019-07-28 03:59:59','2019-07-28 07:59:59','XEMBNB','4h','0.002318000000000','0.002311000000000','0.711908500000000','0.709758646893874','307.1218723037101','307.121872303710120','test'),('2019-07-29 03:59:59','2019-08-01 07:59:59','XEMBNB','4h','0.002311000000000','0.002320000000000','0.711908500000000','0.714680969277369','308.0521419299005','308.052141929900472','test'),('2019-08-04 23:59:59','2019-08-05 07:59:59','XEMBNB','4h','0.002321000000000','0.002321000000000','0.711908500000000','0.711908500000000','306.7249030590263','306.724903059026303','test'),('2019-08-06 11:59:59','2019-08-06 15:59:59','XEMBNB','4h','0.002387000000000','0.002311000000000','0.711908500000000','0.689241953707583','298.24403016338505','298.244030163385048','test'),('2019-08-06 23:59:59','2019-08-07 03:59:59','XEMBNB','4h','0.002318000000000','0.002308000000000','0.711908500000000','0.708837281276963','307.1218723037101','307.121872303710120','test'),('2019-08-07 07:59:59','2019-08-07 11:59:59','XEMBNB','4h','0.002322000000000','0.002339000000000','0.711908500000000','0.717120577734711','306.5928079242033','306.592807924203328','test'),('2019-08-21 03:59:59','2019-08-21 07:59:59','XEMBNB','4h','0.002023000000000','0.002012000000000','0.711908500000000','0.708037519525457','351.9073158675235','351.907315867523494','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','XEMBNB','4h','0.002038000000000','0.002054000000000','0.711908500000000','0.717497575564279','349.3172227674191','349.317222767419082','test'),('2019-08-28 23:59:59','2019-09-03 15:59:59','XEMBNB','4h','0.002097000000000','0.002162000000000','0.711908500000000','0.733975287076776','339.4890319504054','339.489031950405376','test'),('2019-09-03 23:59:59','2019-09-04 03:59:59','XEMBNB','4h','0.002200000000000','0.002196000000000','0.711908500000000','0.710614120909091','323.59477272727275','323.594772727272755','test'),('2019-09-12 07:59:59','2019-09-12 11:59:59','XEMBNB','4h','0.002135000000000','0.002047000000000','0.711908500000000','0.682565198829040','333.44660421545666','333.446604215456659','test'),('2019-09-13 23:59:59','2019-09-14 03:59:59','XEMBNB','4h','0.002135000000000','0.002102000000000','0.711908500000000','0.700904762060890','333.44660421545666','333.446604215456659','test'),('2019-09-14 11:59:59','2019-09-16 03:59:59','XEMBNB','4h','0.002293000000000','0.002197000000000','0.711908500000000','0.682103346925425','310.4703445268208','310.470344526820782','test'),('2019-09-16 15:59:59','2019-09-16 19:59:59','XEMBNB','4h','0.002153000000000','0.002129000000000','0.711908500000000','0.703972687645146','330.6588481189039','330.658848118903904','test'),('2019-09-16 23:59:59','2019-09-17 07:59:59','XEMBNB','4h','0.002136000000000','0.002150000000000','0.711908500000000','0.716574566947566','333.29049625468167','333.290496254681671','test'),('2019-09-18 03:59:59','2019-09-18 07:59:59','XEMBNB','4h','0.002169000000000','0.002111000000000','0.711908500000000','0.692871758183495','328.2196864914708','328.219686491470782','test'),('2019-09-18 19:59:59','2019-09-19 03:59:59','XEMBNB','4h','0.002223000000000','0.002207000000000','0.711908500000000','0.706784552181737','320.2467386414755','320.246738641475474','test'),('2019-10-08 15:59:59','2019-10-08 19:59:59','XEMBNB','4h','0.002548000000000','0.002534000000000','0.711908500000000','0.707996914835165','279.39894034536894','279.398940345368942','test'),('2019-10-17 23:59:59','2019-10-18 03:59:59','XEMBNB','4h','0.002328000000000','0.002325000000000','0.711908500000000','0.710991092139175','305.8026202749141','305.802620274914091','test'),('2019-10-19 19:59:59','2019-10-19 23:59:59','XEMBNB','4h','0.002269000000000','0.002216000000000','0.711908500000000','0.695279522256501','313.75429704715737','313.754297047157365','test'),('2019-10-24 03:59:59','2019-10-24 11:59:59','XEMBNB','4h','0.002253000000000','0.002249000000000','0.711908500000000','0.710644570128717','315.9824678206836','315.982467820683610','test'),('2019-11-06 07:59:59','2019-11-06 11:59:59','XEMBNB','4h','0.002110000000000','0.002071000000000','0.711908500000000','0.698750001658768','337.397393364929','337.397393364928973','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','XEMBNB','4h','0.002003000000000','0.001967000000000','0.711908500000000','0.699113339740389','355.42111832251624','355.421118322516236','test'),('2019-11-16 15:59:59','2019-12-03 03:59:59','XEMBNB','4h','0.001978000000000','0.002326000000000','0.711908500000000','0.837158327098079','359.9132962588473','359.913296258847311','test'),('2019-12-04 03:59:59','2019-12-04 07:59:59','XEMBNB','4h','0.002298000000000','0.002290000000000','0.711908500000000','0.709430141427328','309.7948215839861','309.794821583986106','test'),('2019-12-09 19:59:59','2019-12-09 23:59:59','XEMBNB','4h','0.002317000000000','0.002290000000000','0.711908500000000','0.703612630556754','307.25442382391026','307.254423823910258','test'),('2019-12-10 03:59:59','2019-12-10 11:59:59','XEMBNB','4h','0.002317000000000','0.002324000000000','0.711908500000000','0.714059280966768','307.25442382391026','307.254423823910258','test'),('2019-12-19 23:59:59','2019-12-20 11:59:59','XEMBNB','4h','0.002440000000000','0.002414000000000','0.711908500000000','0.704322589754098','291.7657786885246','291.765778688524620','test'),('2019-12-20 15:59:59','2019-12-21 15:59:59','XEMBNB','4h','0.002434000000000','0.002412000000000','0.711908500000000','0.705473829909614','292.48500410846344','292.485004108463443','test'),('2019-12-22 19:59:59','2019-12-22 23:59:59','XEMBNB','4h','0.002437000000000','0.002414000000000','0.711908500000000','0.705189626179729','292.1249487074272','292.124948707427222','test'),('2019-12-24 03:59:59','2019-12-24 07:59:59','XEMBNB','4h','0.002430000000000','0.002423000000000','0.711908500000000','0.709857734773663','292.96646090534983','292.966460905349834','test'),('2019-12-25 07:59:59','2019-12-26 03:59:59','XEMBNB','4h','0.002447000000000','0.002395000000000','0.711908500000000','0.696780080711075','290.9311401716388','290.931140171638788','test'),('2019-12-26 07:59:59','2019-12-26 19:59:59','XEMBNB','4h','0.002434000000000','0.002422000000000','0.711908500000000','0.708398679950699','292.48500410846344','292.485004108463443','test'),('2019-12-27 07:59:59','2019-12-27 11:59:59','XEMBNB','4h','0.002450000000000','0.002459000000000','0.711908500000000','0.714523674081633','290.5748979591837','290.574897959183716','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:07:57
