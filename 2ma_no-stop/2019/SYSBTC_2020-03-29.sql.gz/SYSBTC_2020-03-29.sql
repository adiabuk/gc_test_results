-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-01 23:59:59','SYSBTC','4h','0.000012560000000','0.000012270000000','0.001467500000000','0.001433616640127','116.8391719745223','116.839171974522301','test'),('2019-01-03 19:59:59','2019-01-04 07:59:59','SYSBTC','4h','0.000013160000000','0.000012220000000','0.001467500000000','0.001362678571429','111.51215805471125','111.512158054711250','test'),('2019-01-04 23:59:59','2019-01-05 07:59:59','SYSBTC','4h','0.000012480000000','0.000012070000000','0.001467500000000','0.001419288862179','117.58814102564102','117.588141025641022','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','SYSBTC','4h','0.000012350000000','0.000012810000000','0.001467500000000','0.001522159919028','118.82591093117409','118.825910931174093','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','SYSBTC','4h','0.000012350000000','0.000011560000000','0.001467500000000','0.001373627530364','118.82591093117409','118.825910931174093','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','SYSBTC','4h','0.000013150000000','0.000011790000000','0.001467500000000','0.001315728136882','111.59695817490496','111.596958174904955','test'),('2019-01-17 11:59:59','2019-01-18 11:59:59','SYSBTC','4h','0.000012230000000','0.000011710000000','0.001467500000000','0.001405104251840','119.99182338511856','119.991823385118565','test'),('2019-01-19 03:59:59','2019-01-19 07:59:59','SYSBTC','4h','0.000011740000000','0.000011680000000','0.001467500000000','0.001460000000000','125.00000000000001','125.000000000000014','test'),('2019-01-19 11:59:59','2019-01-20 03:59:59','SYSBTC','4h','0.000011840000000','0.000011720000000','0.001467500000000','0.001452626689189','123.94425675675676','123.944256756756758','test'),('2019-01-24 07:59:59','2019-01-27 15:59:59','SYSBTC','4h','0.000012080000000','0.000011970000000','0.001467500000000','0.001454137003311','121.4817880794702','121.481788079470206','test'),('2019-01-27 19:59:59','2019-01-28 03:59:59','SYSBTC','4h','0.000012600000000','0.000012000000000','0.001467500000000','0.001397619047619','116.46825396825398','116.468253968253975','test'),('2019-01-28 15:59:59','2019-01-28 19:59:59','SYSBTC','4h','0.000012220000000','0.000012120000000','0.001467500000000','0.001455490998363','120.09001636661212','120.090016366612119','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','SYSBTC','4h','0.000012140000000','0.000012120000000','0.001467500000000','0.001465082372323','120.88138385502471','120.881383855024708','test'),('2019-02-01 15:59:59','2019-02-01 19:59:59','SYSBTC','4h','0.000012140000000','0.000012210000000','0.001467500000000','0.001475961696870','120.88138385502471','120.881383855024708','test'),('2019-02-03 15:59:59','2019-02-04 07:59:59','SYSBTC','4h','0.000012120000000','0.000012190000000','0.001467500000000','0.001475975660066','121.0808580858086','121.080858085808600','test'),('2019-02-05 23:59:59','2019-02-06 03:59:59','SYSBTC','4h','0.000012180000000','0.000011890000000','0.001467500000000','0.001432559523810','120.48440065681446','120.484400656814458','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','SYSBTC','4h','0.000011490000000','0.000011640000000','0.001467500000000','0.001486657963446','127.71975630983464','127.719756309834636','test'),('2019-02-19 11:59:59','2019-02-24 07:59:59','SYSBTC','4h','0.000013290000000','0.000013100000000','0.001467500000000','0.001446519939804','110.42136945071483','110.421369450714835','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','SYSBTC','4h','0.000012980000000','0.000012750000000','0.001467500000000','0.001441496533128','113.05855161787366','113.058551617873661','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','SYSBTC','4h','0.000013140000000','0.000013310000000','0.001467500000000','0.001486485920852','111.68188736681888','111.681887366818884','test'),('2019-03-12 11:59:59','2019-03-13 03:59:59','SYSBTC','4h','0.000014260000000','0.000013690000000','0.001467500000000','0.001408841164095','102.91023842917251','102.910238429172509','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','SYSBTC','4h','0.000014700000000','0.000014390000000','0.001467500000000','0.001436552721088','99.82993197278913','99.829931972789126','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','SYSBTC','4h','0.000015260000000','0.000013950000000','0.001467500000000','0.001341521952818','96.16644823066842','96.166448230668422','test'),('2019-05-02 03:59:59','2019-05-02 11:59:59','SYSBTC','4h','0.000010950000000','0.000010460000000','0.001467500000000','0.001401831050228','134.01826484018264','134.018264840182638','test'),('2019-05-04 15:59:59','2019-05-04 19:59:59','SYSBTC','4h','0.000010580000000','0.000010560000000','0.001467500000000','0.001464725897921','138.70510396975425','138.705103969754248','test'),('2019-05-06 07:59:59','2019-05-07 07:59:59','SYSBTC','4h','0.000010570000000','0.000010340000000','0.001467500000000','0.001435567644276','138.83632923368023','138.836329233680232','test'),('2019-05-08 07:59:59','2019-05-08 19:59:59','SYSBTC','4h','0.000010580000000','0.000010370000000','0.001467500000000','0.001438371928166','138.70510396975425','138.705103969754248','test'),('2019-05-18 03:59:59','2019-05-20 07:59:59','SYSBTC','4h','0.000009080000000','0.000008850000000','0.001467500000000','0.001430327643172','161.61894273127754','161.618942731277542','test'),('2019-05-21 07:59:59','2019-05-21 19:59:59','SYSBTC','4h','0.000009020000000','0.000008890000000','0.001467500000000','0.001446349778271','162.6940133037694','162.694013303769395','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','SYSBTC','4h','0.000009020000000','0.000008500000000','0.001467500000000','0.001382899113082','162.6940133037694','162.694013303769395','test'),('2019-05-29 23:59:59','2019-05-30 07:59:59','SYSBTC','4h','0.000009230000000','0.000008600000000','0.001467500000000','0.001367334777898','158.99241603466956','158.992416034669560','test'),('2019-06-01 11:59:59','2019-06-02 03:59:59','SYSBTC','4h','0.000009030000000','0.000008730000000','0.001467500000000','0.001418745847176','162.51384274640088','162.513842746400883','test'),('2019-06-03 11:59:59','2019-06-03 19:59:59','SYSBTC','4h','0.000008830000000','0.000008660000000','0.001467500000000','0.001439246885617','166.19479048697622','166.194790486976217','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','SYSBTC','4h','0.000008730000000','0.000008670000000','0.001467500000000','0.001457414089347','168.09851088201606','168.098510882016058','test'),('2019-06-12 19:59:59','2019-06-13 15:59:59','SYSBTC','4h','0.000008450000000','0.000008290000000','0.001467500000000','0.001439713017751','173.66863905325442','173.668639053254424','test'),('2019-07-18 07:59:59','2019-07-18 11:59:59','SYSBTC','4h','0.000003220000000','0.000003190000000','0.001467500000000','0.001453827639752','455.74534161490686','455.745341614906863','test'),('2019-07-19 07:59:59','2019-07-19 11:59:59','SYSBTC','4h','0.000003210000000','0.000003140000000','0.001467500000000','0.001435498442368','457.1651090342679','457.165109034267914','test'),('2019-07-22 15:59:59','2019-07-22 19:59:59','SYSBTC','4h','0.000003390000000','0.000003130000000','0.001467500000000','0.001354948377581','432.89085545722713','432.890855457227133','test'),('2019-08-16 19:59:59','2019-08-18 07:59:59','SYSBTC','4h','0.000002690000000','0.000002460000000','0.001467500000000','0.001342026022305','545.539033457249','545.539033457249047','test'),('2019-08-18 11:59:59','2019-08-18 23:59:59','SYSBTC','4h','0.000002550000000','0.000002490000000','0.000978333333333','0.000955313725490','383.6601307189543','383.660130718954292','test'),('2019-08-21 07:59:59','2019-08-21 11:59:59','SYSBTC','4h','0.000002500000000','0.000002480000000','0.001068260411425','0.001059714328134','427.30416456989974','427.304164569899740','test'),('2019-08-22 03:59:59','2019-08-22 07:59:59','SYSBTC','4h','0.000002480000000','0.000002490000000','0.001068260411425','0.001072567913084','430.75016589717745','430.750165897177453','test'),('2019-08-24 11:59:59','2019-08-26 03:59:59','SYSBTC','4h','0.000002810000000','0.000002640000000','0.001068260411425','0.001003632557353','380.1638474822064','380.163847482206393','test'),('2019-08-29 03:59:59','2019-08-29 07:59:59','SYSBTC','4h','0.000002760000000','0.000002610000000','0.001068260411425','0.001010202780369','387.0508737047102','387.050873704710227','test'),('2019-09-01 03:59:59','2019-09-01 07:59:59','SYSBTC','4h','0.000002640000000','0.000002750000000','0.001068260411425','0.001112771261901','404.64409523674243','404.644095236742430','test'),('2019-09-10 07:59:59','2019-09-11 15:59:59','SYSBTC','4h','0.000002520000000','0.000002520000000','0.001068260411425','0.001068260411425','423.91286167658734','423.912861676587340','test'),('2019-09-17 19:59:59','2019-09-23 03:59:59','SYSBTC','4h','0.000002440000000','0.000002610000000','0.001068260411425','0.001142688390910','437.8116440266394','437.811644026639385','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','SYSBTC','4h','0.000002630000000','0.000002440000000','0.001068260411425','0.000991085704896','406.1826659410647','406.182665941064727','test'),('2019-09-26 19:59:59','2019-09-26 23:59:59','SYSBTC','4h','0.000002610000000','0.000002550000000','0.001068260411425','0.001043702700818','409.29517679118777','409.295176791187771','test'),('2019-10-10 15:59:59','2019-10-10 19:59:59','SYSBTC','4h','0.000003060000000','0.000002950000000','0.001068260411425','0.001029858893367','349.1047096160131','349.104709616013110','test'),('2019-10-13 11:59:59','2019-10-14 19:59:59','SYSBTC','4h','0.000003160000000','0.000003100000000','0.001068260411425','0.001047976985892','338.05709222310134','338.057092223101336','test'),('2019-10-17 11:59:59','2019-10-17 23:59:59','SYSBTC','4h','0.000003090000000','0.000003060000000','0.001068260411425','0.001057888951120','345.7153435032363','345.715343503236284','test'),('2019-11-01 11:59:59','2019-11-02 15:59:59','SYSBTC','4h','0.000002830000000','0.000002780000000','0.001068260411425','0.001049386552566','377.47717718197885','377.477177181978846','test'),('2019-11-09 15:59:59','2019-11-09 19:59:59','SYSBTC','4h','0.000002800000000','0.000002810000000','0.001068260411425','0.001072075627180','381.5215755089286','381.521575508928606','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','SYSBTC','4h','0.000002810000000','0.000002790000000','0.001068260411425','0.001060657134475','380.1638474822064','380.163847482206393','test'),('2019-11-12 03:59:59','2019-11-12 19:59:59','SYSBTC','4h','0.000002810000000','0.000002820000000','0.001068260411425','0.001072062049900','380.1638474822064','380.163847482206393','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','SYSBTC','4h','0.000002940000000','0.000002880000000','0.001068260411425','0.001046459178539','363.3538814370749','363.353881437074904','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','SYSBTC','4h','0.000002890000000','0.000002870000000','0.001068260411425','0.001060867605810','369.64028076989626','369.640280769896265','test'),('2019-11-26 11:59:59','2019-11-27 11:59:59','SYSBTC','4h','0.000002860000000','0.000002950000000','0.001068260411425','0.001101876997799','373.51762637237766','373.517626372377663','test'),('2019-12-07 15:59:59','2019-12-08 15:59:59','SYSBTC','4h','0.000003150000000','0.000003010000000','0.001068260411425','0.001020782170917','339.1302893412699','339.130289341269872','test'),('2019-12-11 07:59:59','2019-12-12 11:59:59','SYSBTC','4h','0.000003010000000','0.000002970000000','0.001068260411425','0.001054064259778','354.9037911710964','354.903791171096373','test'),('2019-12-14 19:59:59','2019-12-16 19:59:59','SYSBTC','4h','0.000003030000000','0.000003020000000','0.001068260411425','0.001064734799506','352.561191889439','352.561191889438987','test'),('2019-12-17 03:59:59','2019-12-17 11:59:59','SYSBTC','4h','0.000003040000000','0.000002960000000','0.001068260411425','0.001040148295335','351.40145112664476','351.401451126644758','test'),('2019-12-19 23:59:59','2019-12-20 03:59:59','SYSBTC','4h','0.000003000000000','0.000002980000000','0.001068260411425','0.001061138675349','356.08680380833334','356.086803808333343','test'),('2019-12-21 11:59:59','2019-12-21 15:59:59','SYSBTC','4h','0.000002970000000','0.000002950000000','0.001068260411425','0.001061066738621','359.6836402104378','359.683640210437773','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:03:34
