-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-02 11:59:59','MCOBTC','4h','0.000584000000000','0.000604000000000','0.001467500000000','0.001517756849315','2.5128424657534247','2.512842465753425','test'),('2019-01-12 03:59:59','2019-01-12 11:59:59','MCOBTC','4h','0.000641000000000','0.000623000000000','0.001480064212329','0.001438502346772','2.3089925309340873','2.308992530934087','test'),('2019-01-17 23:59:59','2019-01-18 07:59:59','MCOBTC','4h','0.000627000000000','0.000622000000000','0.001480064212329','0.001468261467414','2.3605489829808612','2.360548982980861','test'),('2019-01-18 19:59:59','2019-01-18 23:59:59','MCOBTC','4h','0.000625000000000','0.000631000000000','0.001480064212329','0.001494272828767','2.3681027397264','2.368102739726400','test'),('2019-01-23 19:59:59','2019-01-23 23:59:59','MCOBTC','4h','0.000632000000000','0.000626000000000','0.001480064212329','0.001466012969807','2.341873753685127','2.341873753685127','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','MCOBTC','4h','0.000625000000000','0.000629000000000','0.001480064212329','0.001489536623288','2.3681027397264','2.368102739726400','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','MCOBTC','4h','0.000584000000000','0.000578000000000','0.001480064212329','0.001464858073161','2.5343565279606164','2.534356527960616','test'),('2019-02-09 03:59:59','2019-02-10 07:59:59','MCOBTC','4h','0.000582000000000','0.000572000000000','0.001480064212329','0.001454633555760','2.54306565692268','2.543065656922680','test'),('2019-02-10 11:59:59','2019-02-10 19:59:59','MCOBTC','4h','0.000586000000000','0.000580000000000','0.001480064212329','0.001464909971247','2.5257068469778154','2.525706846977815','test'),('2019-02-11 19:59:59','2019-02-12 11:59:59','MCOBTC','4h','0.000587000000000','0.000579000000000','0.001480064212329','0.001459892979452','2.521404109589438','2.521404109589438','test'),('2019-02-12 19:59:59','2019-02-13 03:59:59','MCOBTC','4h','0.000583000000000','0.000579000000000','0.001480064212329','0.001469909397836','2.538703623205832','2.538703623205832','test'),('2019-02-15 03:59:59','2019-02-24 07:59:59','MCOBTC','4h','0.000684000000000','0.000719000000000','0.001480064212329','0.001555798492200','2.163836567732456','2.163836567732456','test'),('2019-02-24 23:59:59','2019-02-25 07:59:59','MCOBTC','4h','0.000721000000000','0.000717000000000','0.001480064212329','0.001471853037781','2.052793637072122','2.052793637072122','test'),('2019-02-26 23:59:59','2019-02-27 03:59:59','MCOBTC','4h','0.000729000000000','0.000715000000000','0.001480064212329','0.001451640482600','2.0302664092304523','2.030266409230452','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','MCOBTC','4h','0.000693000000000','0.000684000000000','0.001480064212329','0.001460842599182','2.135734794125541','2.135734794125541','test'),('2019-03-09 11:59:59','2019-03-09 15:59:59','MCOBTC','4h','0.000685000000000','0.000708000000000','0.001480064212329','0.001529759799020','2.1606776822321168','2.160677682232117','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','MCOBTC','4h','0.000808000000000','0.000823000000000','0.001480064212329','0.001507540651914','1.8317626390210395','1.831762639021040','test'),('2019-03-26 07:59:59','2019-03-26 15:59:59','MCOBTC','4h','0.000808000000000','0.000812000000000','0.001480064212329','0.001487391262885','1.8317626390210395','1.831762639021040','test'),('2019-04-10 15:59:59','2019-04-10 19:59:59','MCOBTC','4h','0.000778000000000','0.000762000000000','0.001480064212329','0.001449625873772','1.9023961598059125','1.902396159805912','test'),('2019-04-11 07:59:59','2019-04-11 11:59:59','MCOBTC','4h','0.000788000000000','0.000744000000000','0.001480064212329','0.001397421032960','1.8782540765596447','1.878254076559645','test'),('2019-04-11 19:59:59','2019-04-12 03:59:59','MCOBTC','4h','0.000779000000000','0.000772000000000','0.001480064212329','0.001466764533913','1.8999540594724005','1.899954059472400','test'),('2019-04-25 11:59:59','2019-04-25 23:59:59','MCOBTC','4h','0.000878000000000','0.000846000000000','0.001480064212329','0.001426121097529','1.6857223375045558','1.685722337504556','test'),('2019-04-26 03:59:59','2019-04-26 07:59:59','MCOBTC','4h','0.000896000000000','0.000874000000000','0.001480064212329','0.001443723349973','1.6518573798314733','1.651857379831473','test'),('2019-04-27 07:59:59','2019-04-28 11:59:59','MCOBTC','4h','0.000887000000000','0.000877000000000','0.001480064212329','0.001463378031807','1.668618052231116','1.668618052231116','test'),('2019-04-30 03:59:59','2019-05-01 19:59:59','MCOBTC','4h','0.000897000000000','0.000881000000000','0.001480064212329','0.001453663958820','1.6500158442909698','1.650015844290970','test'),('2019-05-05 07:59:59','2019-05-05 19:59:59','MCOBTC','4h','0.000886000000000','0.000863000000000','0.001480064212329','0.001441642680858','1.670501368317156','1.670501368317156','test'),('2019-05-23 11:59:59','2019-05-23 15:59:59','MCOBTC','4h','0.000674000000000','0.000664000000000','0.001480064212329','0.001458104802651','2.195940967847181','2.195940967847181','test'),('2019-05-26 03:59:59','2019-05-26 19:59:59','MCOBTC','4h','0.000705000000000','0.000666000000000','0.001480064212329','0.001398188319732','2.0993818614595745','2.099381861459575','test'),('2019-06-06 23:59:59','2019-06-07 03:59:59','MCOBTC','4h','0.000758000000000','0.000753000000000','0.001480064212329','0.001470301255783','1.9525913091411609','1.952591309141161','test'),('2019-06-08 03:59:59','2019-06-09 19:59:59','MCOBTC','4h','0.000766000000000','0.000770000000000','0.001480064212329','0.001487793007171','1.9321987106122716','1.932198710612272','test'),('2019-07-01 11:59:59','2019-07-02 15:59:59','MCOBTC','4h','0.000580000000000','0.000575000000000','0.001480064212329','0.001467305038085','2.5518348488431033','2.551834848843103','test'),('2019-07-14 07:59:59','2019-07-14 11:59:59','MCOBTC','4h','0.000527000000000','0.000499000000000','0.001480064212329','0.001401427024577','2.8084709911366224','2.808470991136622','test'),('2019-07-14 15:59:59','2019-07-14 19:59:59','MCOBTC','4h','0.000515000000000','0.000511000000000','0.001480064212329','0.001468568567961','2.8739110919009705','2.873911091900970','test'),('2019-07-24 03:59:59','2019-07-25 03:59:59','MCOBTC','4h','0.000519000000000','0.000470000000000','0.001480064212329','0.001340327899412','2.8517614881098265','2.851761488109827','test'),('2019-07-28 11:59:59','2019-07-28 15:59:59','MCOBTC','4h','0.000466000000000','0.000472000000000','0.001480064212329','0.001499120833089','3.1761034599334765','3.176103459933477','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','MCOBTC','4h','0.000468000000000','0.000465000000000','0.001480064212329','0.001470576621224','3.162530368224359','3.162530368224359','test'),('2019-08-22 07:59:59','2019-08-22 11:59:59','MCOBTC','4h','0.000334000000000','0.000333000000000','0.001480064212329','0.001475632882352','4.431329977032934','4.431329977032934','test'),('2019-08-26 15:59:59','2019-08-27 07:59:59','MCOBTC','4h','0.000355000000000','0.000346000000000','0.001480064212329','0.001442541457650','4.169194964307042','4.169194964307042','test'),('2019-08-31 03:59:59','2019-09-01 15:59:59','MCOBTC','4h','0.000342000000000','0.000341000000000','0.001480064212329','0.001475736539194','4.327673135464912','4.327673135464912','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','MCOBTC','4h','0.000320000000000','0.000319000000000','0.001480064212329','0.001475439011665','4.625200663528124','4.625200663528124','test'),('2019-09-14 07:59:59','2019-09-15 03:59:59','MCOBTC','4h','0.000320000000000','0.000319000000000','0.001480064212329','0.001475439011665','4.625200663528124','4.625200663528124','test'),('2019-09-25 11:59:59','2019-10-26 03:59:59','MCOBTC','4h','0.000331500000000','0.000434400000000','0.001480064212329','0.001939486859233','4.464748755140271','4.464748755140271','test'),('2019-10-29 07:59:59','2019-11-04 23:59:59','MCOBTC','4h','0.000438500000000','0.000451800000000','0.001480064212329','0.001524955555599','3.3752889676830105','3.375288967683010','test'),('2019-11-30 11:59:59','2019-11-30 15:59:59','MCOBTC','4h','0.000532400000000','0.000530400000000','0.001480064212329','0.001474504241584','2.779985372518783','2.779985372518783','test'),('2019-11-30 19:59:59','2019-11-30 23:59:59','MCOBTC','4h','0.000532200000000','0.000538700000000','0.001480064212329','0.001498140907895','2.78103008705186','2.781030087051860','test'),('2019-12-03 19:59:59','2019-12-04 03:59:59','MCOBTC','4h','0.000538300000000','0.000541000000000','0.001480064212329','0.001487487904273','2.7495155346999813','2.749515534699981','test'),('2019-12-21 23:59:59','2019-12-22 15:59:59','MCOBTC','4h','0.000570400000000','0.000564700000000','0.001480064212329','0.001465273949338','2.5947829809414444','2.594782980941444','test'),('2019-12-31 15:59:59','2020-01-01 15:59:59','MCOBTC','4h','0.000554300000000','0.000556200000000','0.001480064212329','0.001485137497560','2.670150121466715','2.670150121466715','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  7:27:38
