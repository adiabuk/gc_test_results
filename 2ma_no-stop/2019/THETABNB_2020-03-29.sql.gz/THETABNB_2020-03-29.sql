-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 07:59:59','2019-01-03 11:59:59','THETABNB','4h','0.008590000000000','0.008480000000000','0.711908500000000','0.702792093131548','82.87642607683352','82.876426076833525','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','THETABNB','4h','0.008040000000000','0.008200000000000','0.711908500000000','0.726075833333333','88.54583333333333','88.545833333333334','test'),('2019-01-22 23:59:59','2019-01-28 03:59:59','THETABNB','4h','0.007680000000000','0.007540000000000','0.713171231616220','0.700170714373216','92.86083745002868','92.860837450028683','test'),('2019-01-28 19:59:59','2019-01-31 11:59:59','THETABNB','4h','0.008360000000000','0.008550000000000','0.713171231616220','0.729379668698407','85.30756359045694','85.307563590456937','test'),('2019-02-01 19:59:59','2019-02-02 07:59:59','THETABNB','4h','0.008510000000000','0.008200000000000','0.713973211576016','0.687964786712495','83.89814472103596','83.898144721035962','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','THETABNB','4h','0.008300000000000','0.008150000000000','0.713973211576016','0.701070081246329','86.02086886458024','86.020868864580237','test'),('2019-02-04 07:59:59','2019-02-04 15:59:59','THETABNB','4h','0.008320000000000','0.008370000000000','0.713973211576016','0.718263915972507','85.81408792980963','85.814087929809631','test'),('2019-02-07 11:59:59','2019-02-07 23:59:59','THETABNB','4h','0.008530000000000','0.008850000000000','0.713973211576016','0.740757669689067','83.70143160328442','83.701431603284419','test'),('2019-02-08 19:59:59','2019-02-08 23:59:59','THETABNB','4h','0.008440000000000','0.008420000000000','0.713973211576016','0.712281331927732','84.59398241421991','84.593982414219909','test'),('2019-02-09 15:59:59','2019-02-12 03:59:59','THETABNB','4h','0.008820000000000','0.008710000000000','0.713973211576016','0.705068783767245','80.9493437161016','80.949343716101595','test'),('2019-02-25 03:59:59','2019-03-03 19:59:59','THETABNB','4h','0.009730000000000','0.012010000000000','0.713973211576016','0.881276286847683','73.3785417858187','73.378541785818697','test'),('2019-03-10 03:59:59','2019-03-11 15:59:59','THETABNB','4h','0.012010000000000','0.011280000000000','0.751190805358752','0.705531414192067','62.547111187240006','62.547111187240006','test'),('2019-03-12 01:59:59','2019-03-12 11:59:59','THETABNB','4h','0.011160000000000','0.010770000000000','0.751190805358752','0.724939513773634','67.3110040644043','67.311004064404301','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','THETABNB','4h','0.006620000000000','0.006360000000000','0.751190805358752','0.721687843214753','113.47293132307432','113.472931323074320','test'),('2019-04-08 19:59:59','2019-04-09 03:59:59','THETABNB','4h','0.006480000000000','0.006490000000000','0.751190805358752','0.752350050428750','115.92450699980742','115.924506999807420','test'),('2019-04-16 19:59:59','2019-04-18 07:59:59','THETABNB','4h','0.006630000000000','0.006060000000000','0.751190805358752','0.686608790418407','113.30178059709685','113.301780597096851','test'),('2019-05-10 03:59:59','2019-05-10 07:59:59','THETABNB','4h','0.004330000000000','0.004410000000000','0.751190805358752','0.765069619314572','173.48517444774876','173.485174447748761','test'),('2019-05-11 23:59:59','2019-05-12 03:59:59','THETABNB','4h','0.004250000000000','0.004280000000000','0.751190805358752','0.756493328690696','176.75077773147106','176.750777731471061','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','THETABNB','4h','0.004280000000000','0.004160000000000','0.751190805358752','0.730129380909441','175.51187041092336','175.511870410923365','test'),('2019-05-14 19:59:59','2019-05-15 02:59:59','THETABNB','4h','0.004510000000000','0.004200000000000','0.751190805358752','0.699556847562474','166.56115418154147','166.561154181541468','test'),('2019-05-17 15:59:59','2019-05-18 11:59:59','THETABNB','4h','0.004520000000000','0.004320000000000','0.751190805358752','0.717952274148188','166.19265605282126','166.192656052821263','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','THETABNB','4h','0.004310000000000','0.003850000000000','0.751190805358752','0.671017308731136','174.2902100600353','174.290210060035292','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','THETABNB','4h','0.003950000000000','0.003960000000000','0.751190805358752','0.753092554233078','190.17488743259543','190.174887432595426','test'),('2019-06-02 03:59:59','2019-06-04 11:59:59','THETABNB','4h','0.004240000000000','0.004090000000000','0.751190805358752','0.724615658942758','177.1676427732906','177.167642773290595','test'),('2019-06-25 11:59:59','2019-06-26 07:59:59','THETABNB','4h','0.003690000000000','0.003540000000000','0.751190805358752','0.720654593758803','203.5747439996618','203.574743999661791','test'),('2019-06-30 23:59:59','2019-07-01 15:59:59','THETABNB','4h','0.003620000000000','0.003480000000000','0.751190805358752','0.722139227250955','207.5112721985503','207.511272198550301','test'),('2019-07-01 23:59:59','2019-07-02 07:59:59','THETABNB','4h','0.003640000000000','0.003510000000000','0.751190805358752','0.724362562310225','206.37110037328353','206.371100373283525','test'),('2019-07-03 07:59:59','2019-07-03 11:59:59','THETABNB','4h','0.003590000000000','0.003550000000000','0.751190805358752','0.742820991371468','209.24534968210364','209.245349682103637','test'),('2019-07-06 07:59:59','2019-07-06 19:59:59','THETABNB','4h','0.003600000000000','0.003600000000000','0.751190805358752','0.751190805358752','208.66411259965335','208.664112599653350','test'),('2019-07-09 15:59:59','2019-07-09 19:59:59','THETABNB','4h','0.003590000000000','0.003670000000000','0.751190805358752','0.767930433333320','209.24534968210364','209.245349682103637','test'),('2019-07-13 03:59:59','2019-07-13 23:59:59','THETABNB','4h','0.003719000000000','0.003656000000000','0.751190805358752','0.738465604837751','201.987309857153','201.987309857153008','test'),('2019-07-15 15:59:59','2019-07-15 23:59:59','THETABNB','4h','0.003669000000000','0.003600000000000','0.751190805358752','0.737063750147590','204.73993059655277','204.739930596552767','test'),('2019-07-16 07:59:59','2019-07-16 15:59:59','THETABNB','4h','0.003673000000000','0.003750000000000','0.751190805358752','0.766938611515197','204.5169630707193','204.516963070719299','test'),('2019-08-12 23:59:59','2019-08-13 03:59:59','THETABNB','4h','0.004250000000000','0.004059000000000','0.751190805358752','0.717431406812041','176.75077773147106','176.750777731471061','test'),('2019-08-17 07:59:59','2019-08-17 11:59:59','THETABNB','4h','0.004110000000000','0.004105000000000','0.751190805358752','0.750276947931308','182.77148548874746','182.771485488747459','test'),('2019-08-17 19:59:59','2019-08-17 23:59:59','THETABNB','4h','0.004099000000000','0.004196000000000','0.751190805358752','0.768967216219889','183.26196764058355','183.261967640583549','test'),('2019-09-03 19:59:59','2019-09-05 19:59:59','THETABNB','4h','0.004950000000000','0.004915000000000','0.751190805358752','0.745879355219852','151.75571825429333','151.755718254293328','test'),('2019-09-08 19:59:59','2019-09-08 23:59:59','THETABNB','4h','0.004974000000000','0.004937000000000','0.751190805358752','0.745602936480933','151.02348318430882','151.023483184308816','test'),('2019-09-10 03:59:59','2019-09-10 07:59:59','THETABNB','4h','0.004978000000000','0.004909000000000','0.751190805358752','0.740778558357998','150.90213044571155','150.902130445711549','test'),('2019-09-10 11:59:59','2019-09-12 23:59:59','THETABNB','4h','0.004987000000000','0.005061000000000','0.751190805358752','0.762337410451302','150.62979854797513','150.629798547975128','test'),('2019-09-13 19:59:59','2019-09-14 11:59:59','THETABNB','4h','0.005163000000000','0.004987000000000','0.751190805358752','0.725583681255878','145.49502331178618','145.495023311786184','test'),('2019-09-14 19:59:59','2019-09-14 23:59:59','THETABNB','4h','0.005024000000000','0.005039000000000','0.751190805358752','0.753433612301503','149.5204628500701','149.520462850070089','test'),('2019-09-19 03:59:59','2019-09-19 11:59:59','THETABNB','4h','0.005093000000000','0.005253000000000','0.751190805358752','0.774789966728750','147.49475856248813','147.494758562488130','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','THETABNB','4h','0.005183000000000','0.005028000000000','0.751190805358752','0.728726098657883','144.93359161851285','144.933591618512850','test'),('2019-09-23 03:59:59','2019-09-24 19:59:59','THETABNB','4h','0.005147000000000','0.005059000000000','0.751190805358752','0.738347442065267','145.947310153245','145.947310153245013','test'),('2019-10-02 19:59:59','2019-10-02 23:59:59','THETABNB','4h','0.005253000000000','0.005177000000000','0.751190805358752','0.740322634559730','143.00224735555912','143.002247355559120','test'),('2019-10-03 07:59:59','2019-10-03 15:59:59','THETABNB','4h','0.005306000000000','0.005279000000000','0.751190805358752','0.747368311626244','141.57384194473278','141.573841944732777','test'),('2019-10-07 15:59:59','2019-10-08 03:59:59','THETABNB','4h','0.005414000000000','0.005303000000000','0.751190805358752','0.735789590102967','138.74968698905653','138.749686989056528','test'),('2019-10-22 23:59:59','2019-10-26 03:59:59','THETABNB','4h','0.004911000000000','0.005046000000000','0.751190805358752','0.771840522060734','152.9608644591228','152.960864459122803','test'),('2019-10-26 19:59:59','2019-10-26 23:59:59','THETABNB','4h','0.005118000000000','0.004917000000000','0.751190805358752','0.721689173495307','146.77428787783353','146.774287877833530','test'),('2019-10-27 03:59:59','2019-10-27 11:59:59','THETABNB','4h','0.005091000000000','0.004954000000000','0.751190805358752','0.730976085198833','147.552701897221','147.552701897220999','test'),('2019-10-29 03:59:59','2019-10-29 07:59:59','THETABNB','4h','0.005145000000000','0.005037000000000','0.751190805358752','0.735422368628189','146.0040438015067','146.004043801506697','test'),('2019-11-15 19:59:59','2019-11-16 03:59:59','THETABNB','4h','0.004513000000000','0.004376000000000','0.751190805358752','0.728387096000421','166.45043327249104','166.450433272491040','test'),('2019-11-16 15:59:59','2019-11-16 19:59:59','THETABNB','4h','0.004448000000000','0.004470000000000','0.751190805358752','0.754906227507559','168.88282494576262','168.882824945762621','test'),('2019-11-17 19:59:59','2019-11-17 23:59:59','THETABNB','4h','0.004443000000000','0.004403000000000','0.751190805358752','0.744427890163085','169.072879891684','169.072879891684011','test'),('2019-11-18 03:59:59','2019-11-23 15:59:59','THETABNB','4h','0.004428000000000','0.004675000000000','0.751190805358752','0.793093273498683','169.64561999971818','169.645619999718178','test'),('2019-11-25 19:59:59','2019-11-25 23:59:59','THETABNB','4h','0.004746000000000','0.004717000000000','0.751190805358752','0.746600722477293','158.27872005030594','158.278720050305935','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','THETABNB','4h','0.004738000000000','0.004744000000000','0.751190805358752','0.752142081178117','158.54596989420685','158.545969894206848','test'),('2019-12-03 11:59:59','2019-12-03 15:59:59','THETABNB','4h','0.004793000000000','0.004721000000000','0.751190805358752','0.739906486980736','156.72664413910954','156.726644139109538','test'),('2019-12-03 23:59:59','2019-12-04 03:59:59','THETABNB','4h','0.004799000000000','0.004735000000000','0.751190805358752','0.741172840878035','156.53069501120066','156.530695011200663','test'),('2019-12-04 15:59:59','2019-12-04 19:59:59','THETABNB','4h','0.004761000000000','0.004695000000000','0.751190805358752','0.740777322234686','157.78004733433147','157.780047334331471','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','THETABNB','4h','0.004766000000000','0.004758000000000','0.751190805358752','0.749929889193651','157.6145206375896','157.614520637589607','test'),('2019-12-25 03:59:59','2019-12-25 07:59:59','THETABNB','4h','0.007271000000000','0.007113000000000','0.751190805358752','0.734867308281777','103.3132726390802','103.313272639080196','test'),('2019-12-31 11:59:59','2019-12-31 15:59:59','THETABNB','4h','0.006753000000000','0.006552000000000','0.751190805358752','0.728831949757225','111.2380875697841','111.238087569784099','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:56:50
