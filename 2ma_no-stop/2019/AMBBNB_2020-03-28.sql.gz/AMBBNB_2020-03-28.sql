-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-04 15:59:59','AMBBNB','4h','0.012360000000000','0.011790000000000','0.711908500000000','0.679077768203884','57.59777508090615','57.597775080906153','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','AMBBNB','4h','0.011900000000000','0.012040000000000','0.711908500000000','0.720283894117647','59.82424369747899','59.824243697478991','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','AMBBNB','4h','0.011990000000000','0.011920000000000','0.711908500000000','0.707752236864053','59.37518765638032','59.375187656380319','test'),('2019-01-19 23:59:59','2019-01-20 03:59:59','AMBBNB','4h','0.011410000000000','0.010810000000000','0.711908500000000','0.674472470201578','62.39338299737073','62.393382997370729','test'),('2019-03-15 19:59:59','2019-03-16 03:59:59','AMBBNB','4h','0.004250000000000','0.004120000000000','0.711908500000000','0.690132475294118','167.50788235294118','167.507882352941181','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','AMBBNB','4h','0.003970000000000','0.003820000000000','0.711908500000000','0.685010193954660','179.32204030226703','179.322040302267027','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','AMBBNB','4h','0.003770000000000','0.003600000000000','0.711908500000000','0.679806525198939','188.83514588859418','188.835145888594184','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','AMBBNB','4h','0.003790000000000','0.003710000000000','0.711908500000000','0.696881407651715','187.83865435356202','187.838654353562021','test'),('2019-03-31 15:59:59','2019-03-31 23:59:59','AMBBNB','4h','0.003840000000000','0.003850000000000','0.711908500000000','0.713762428385417','185.39283854166666','185.392838541666663','test'),('2019-04-01 15:59:59','2019-04-01 19:59:59','AMBBNB','4h','0.003870000000000','0.003810000000000','0.711908500000000','0.700871158914729','183.95568475452197','183.955684754521968','test'),('2019-04-01 23:59:59','2019-04-02 03:59:59','AMBBNB','4h','0.003900000000000','0.003850000000000','0.711908500000000','0.702781467948718','182.54064102564104','182.540641025641037','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','AMBBNB','4h','0.004050000000000','0.003780000000000','0.711908500000000','0.664447933333333','175.7798765432099','175.779876543209895','test'),('2019-04-07 15:59:59','2019-04-08 15:59:59','AMBBNB','4h','0.003850000000000','0.003830000000000','0.711908500000000','0.708210274025974','184.9112987012987','184.911298701298705','test'),('2019-05-08 15:59:59','2019-05-08 23:59:59','AMBBNB','4h','0.001830000000000','0.001810000000000','0.711908500000000','0.704128079234973','389.0210382513661','389.021038251366122','test'),('2019-05-09 19:59:59','2019-05-09 23:59:59','AMBBNB','4h','0.001820000000000','0.001770000000000','0.711908500000000','0.692350574175824','391.1585164835165','391.158516483516507','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','AMBBNB','4h','0.001820000000000','0.001810000000000','0.711908500000000','0.707996914835165','391.1585164835165','391.158516483516507','test'),('2019-05-17 23:59:59','2019-05-18 11:59:59','AMBBNB','4h','0.001740000000000','0.001700000000000','0.711908500000000','0.695542787356322','409.14281609195405','409.142816091954046','test'),('2019-05-20 11:59:59','2019-05-20 15:59:59','AMBBNB','4h','0.001700000000000','0.001610000000000','0.711908500000000','0.674219226470588','418.769705882353','418.769705882352980','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','AMBBNB','4h','0.001720000000000','0.001630000000000','0.711908500000000','0.674657473837209','413.90029069767445','413.900290697674450','test'),('2019-05-23 19:59:59','2019-05-24 11:59:59','AMBBNB','4h','0.001680000000000','0.001660000000000','0.711908500000000','0.703433398809524','423.75505952380956','423.755059523809564','test'),('2019-06-02 19:59:59','2019-06-03 15:59:59','AMBBNB','4h','0.001480000000000','0.001460000000000','0.711908500000000','0.702288114864865','481.0192567567568','481.019256756756818','test'),('2019-06-07 11:59:59','2019-06-08 15:59:59','AMBBNB','4h','0.001460000000000','0.001480000000000','0.711908500000000','0.721660671232877','487.6085616438357','487.608561643835685','test'),('2019-06-09 03:59:59','2019-06-09 15:59:59','AMBBNB','4h','0.001460000000000','0.001440000000000','0.711908500000000','0.702156328767123','487.6085616438357','487.608561643835685','test'),('2019-06-10 15:59:59','2019-06-10 23:59:59','AMBBNB','4h','0.001460000000000','0.001460000000000','0.711908500000000','0.711908500000000','487.6085616438357','487.608561643835685','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','AMBBNB','4h','0.001460000000000','0.001460000000000','0.711908500000000','0.711908500000000','487.6085616438357','487.608561643835685','test'),('2019-06-14 07:59:59','2019-06-14 15:59:59','AMBBNB','4h','0.001460000000000','0.001360000000000','0.711908500000000','0.663147643835617','487.6085616438357','487.608561643835685','test'),('2019-06-16 15:59:59','2019-06-17 07:59:59','AMBBNB','4h','0.001510000000000','0.001440000000000','0.711908500000000','0.678906119205298','471.46258278145694','471.462582781456945','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','AMBBNB','4h','0.001400000000000','0.001190000000000','0.711908500000000','0.605122225000000','508.5060714285715','508.506071428571488','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','AMBBNB','4h','0.001220000000000','0.001190000000000','0.711908500000000','0.694402553278689','583.5315573770492','583.531557377049239','test'),('2019-07-07 03:59:59','2019-07-08 07:59:59','AMBBNB','4h','0.001190000000000','0.001180000000000','0.711908500000000','0.705926075630252','598.2424369747899','598.242436974789939','test'),('2019-07-11 23:59:59','2019-07-12 03:59:59','AMBBNB','4h','0.001214000000000','0.001107000000000','0.711908500000000','0.649162034184514','586.415568369028','586.415568369028051','test'),('2019-07-15 15:59:59','2019-07-15 23:59:59','AMBBNB','4h','0.001136000000000','0.001111000000000','0.711908500000000','0.696241499559859','626.6800176056338','626.680017605633793','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','AMBBNB','4h','0.001025000000000','0.001025000000000','0.711908500000000','0.711908500000000','694.5448780487804','694.544878048780447','test'),('2019-07-27 23:59:59','2019-07-28 03:59:59','AMBBNB','4h','0.001019000000000','0.001012000000000','0.711908500000000','0.707018058881256','698.6344455348382','698.634445534838164','test'),('2019-07-28 19:59:59','2019-07-31 15:59:59','AMBBNB','4h','0.001032000000000','0.000991000000000','0.711908500000000','0.683625313468992','689.8338178294574','689.833817829457416','test'),('2019-08-04 23:59:59','2019-08-07 15:59:59','AMBBNB','4h','0.001015000000000','0.000949000000000','0.711908500000000','0.665616912807882','701.3876847290641','701.387684729064063','test'),('2019-08-13 23:59:59','2019-08-14 07:59:59','AMBBNB','4h','0.000939000000000','0.000914000000000','0.474605666666667','0.461969733049344','505.4373446929358','505.437344692935824','test'),('2019-08-22 15:59:59','2019-08-23 07:59:59','AMBBNB','4h','0.000870000000000','0.000897000000000','0.523277451478567','0.539517096524453','601.4683350328361','601.468335032836080','test'),('2019-08-28 23:59:59','2019-09-01 23:59:59','AMBBNB','4h','0.000947000000000','0.000980000000000','0.527337362740039','0.545713427122744','556.8504358395343','556.850435839534271','test'),('2019-09-02 11:59:59','2019-09-02 15:59:59','AMBBNB','4h','0.000978000000000','0.000889000000000','0.531931378835715','0.483524535567434','543.8971153739419','543.897115373941915','test'),('2019-09-10 19:59:59','2019-09-11 07:59:59','AMBBNB','4h','0.000875000000000','0.000801000000000','0.531931378835715','0.486945182225609','607.9215758122457','607.921575812245692','test'),('2019-09-14 19:59:59','2019-09-15 07:59:59','AMBBNB','4h','0.000876000000000','0.000806000000000','0.531931378835715','0.489425446736971','607.2276014106335','607.227601410633497','test'),('2019-10-19 03:59:59','2019-10-19 07:59:59','AMBBNB','4h','0.001832000000000','0.001786000000000','0.531931378835715','0.518575023253596','290.35555613303217','290.355556133032167','test'),('2019-10-20 11:59:59','2019-10-20 15:59:59','AMBBNB','4h','0.001827000000000','0.001812000000000','0.531931378835715','0.527564126135914','291.15017998670766','291.150179986707656','test'),('2019-10-21 03:59:59','2019-10-22 07:59:59','AMBBNB','4h','0.001810000000000','0.001829000000000','0.531931378835715','0.537515188889791','293.8847396882403','293.884739688240302','test'),('2019-10-28 19:59:59','2019-10-28 23:59:59','AMBBNB','4h','0.001818000000000','0.001689000000000','0.531931378835715','0.494187073076745','292.5915175113944','292.591517511394386','test'),('2019-10-29 11:59:59','2019-10-29 23:59:59','AMBBNB','4h','0.001656000000000','0.001598000000000','0.531931378835715','0.513300931992435','321.2146007462047','321.214600746204724','test'),('2019-10-30 19:59:59','2019-10-31 03:59:59','AMBBNB','4h','0.001686000000000','0.001609000000000','0.531931378835715','0.507637952874653','315.4990384553469','315.499038455346920','test'),('2019-10-31 07:59:59','2019-11-02 03:59:59','AMBBNB','4h','0.001648000000000','0.001670000000000','0.531931378835715','0.539032404524056','322.77389492458434','322.773894924584340','test'),('2019-11-14 07:59:59','2019-11-14 11:59:59','AMBBNB','4h','0.001479000000000','0.001448000000000','0.531931378835715','0.520782039590342','359.65610468946244','359.656104689462438','test'),('2019-11-14 19:59:59','2019-11-14 23:59:59','AMBBNB','4h','0.001483000000000','0.001478000000000','0.531931378835715','0.530137948698036','358.68602753588334','358.686027535883341','test'),('2019-11-16 19:59:59','2019-11-16 23:59:59','AMBBNB','4h','0.001457000000000','0.001445000000000','0.531931378835715','0.527550337966787','365.086739077361','365.086739077361017','test'),('2019-11-17 23:59:59','2019-11-18 03:59:59','AMBBNB','4h','0.001460000000000','0.001424000000000','0.531931378835715','0.518815262645245','364.3365608463801','364.336560846380110','test'),('2019-11-19 23:59:59','2019-11-20 03:59:59','AMBBNB','4h','0.001453000000000','0.001432000000000','0.531931378835715','0.524243451130588','366.09179548225393','366.091795482253929','test'),('2019-11-20 11:59:59','2019-11-20 19:59:59','AMBBNB','4h','0.001458000000000','0.001447000000000','0.531931378835715','0.527918179132565','364.83633665001025','364.836336650010253','test'),('2019-11-21 03:59:59','2019-11-21 07:59:59','AMBBNB','4h','0.001442000000000','0.001437000000000','0.531931378835715','0.530086956579003','368.8844513423821','368.884451342382079','test'),('2019-11-23 19:59:59','2019-11-24 03:59:59','AMBBNB','4h','0.001442000000000','0.001402000000000','0.531931378835715','0.517176000782020','368.8844513423821','368.884451342382079','test'),('2019-11-25 11:59:59','2019-11-25 23:59:59','AMBBNB','4h','0.001487000000000','0.001508000000000','0.531931378835715','0.539443523392238','357.7211693582481','357.721169358248119','test'),('2019-12-01 11:59:59','2019-12-02 03:59:59','AMBBNB','4h','0.001482000000000','0.001499000000000','0.531931378835715','0.538033155785922','358.9280558945445','358.928055894544514','test'),('2019-12-08 11:59:59','2019-12-08 19:59:59','AMBBNB','4h','0.001444000000000','0.001410000000000','0.531931378835715','0.519406678780026','368.3735310496641','368.373531049664109','test'),('2019-12-28 11:59:59','2019-12-28 19:59:59','AMBBNB','4h','0.001142000000000','0.001096000000000','0.531931378835715','0.510505071106781','465.7892984550919','465.789298455091910','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','AMBBNB','4h','0.001142000000000','0.001075000000000','0.531931378835715','0.500723495839224','465.7892984550919','465.789298455091910','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:59:31
