-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 03:59:59','2019-01-04 07:59:59','GRSBTC','4h','0.000062940000000','0.000062760000000','0.001467500000000','0.001463303145853','23.315856371147124','23.315856371147124','test'),('2019-01-04 15:59:59','2019-01-04 19:59:59','GRSBTC','4h','0.000062670000000','0.000062590000000','0.001467500000000','0.001465626695389','23.41630764321047','23.416307643210470','test'),('2019-01-16 15:59:59','2019-01-16 23:59:59','GRSBTC','4h','0.000059380000000','0.000061800000000','0.001467500000000','0.001527307174133','24.71370831929943','24.713708319299428','test'),('2019-01-18 23:59:59','2019-01-20 15:59:59','GRSBTC','4h','0.000060370000000','0.000058750000000','0.001480934253844','0.001441194093313','24.53096329043813','24.530963290438130','test'),('2019-01-23 03:59:59','2019-01-23 07:59:59','GRSBTC','4h','0.000059700000000','0.000059630000000','0.001480934253844','0.001479197815020','24.806268908609717','24.806268908609717','test'),('2019-02-07 11:59:59','2019-02-08 07:59:59','GRSBTC','4h','0.000083500000000','0.000066350000000','0.001480934253844','0.001176766320270','17.735739566994013','17.735739566994013','test'),('2019-02-11 07:59:59','2019-02-11 11:59:59','GRSBTC','4h','0.000061040000000','0.000060560000000','0.001480934253844','0.001469288637169','24.26170140635649','24.261701406356490','test'),('2019-02-13 03:59:59','2019-02-13 07:59:59','GRSBTC','4h','0.000060620000000','0.000059530000000','0.001480934253844','0.001454305775839','24.42979633526889','24.429796335268890','test'),('2019-02-15 11:59:59','2019-02-15 15:59:59','GRSBTC','4h','0.000060870000000','0.000059200000000','0.001480934253844','0.001440304054995','24.32946038843437','24.329460388434370','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','GRSBTC','4h','0.000060100000000','0.000059800000000','0.001480934253844','0.001473541903159','24.641168949151417','24.641168949151417','test'),('2019-02-20 07:59:59','2019-02-20 11:59:59','GRSBTC','4h','0.000063000000000','0.000061670000000','0.001480934253844','0.001449670086263','23.50689291815873','23.506892918158730','test'),('2019-02-20 19:59:59','2019-02-20 23:59:59','GRSBTC','4h','0.000061860000000','0.000061990000000','0.001480934253844','0.001484046466146','23.940094630520534','23.940094630520534','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GRSBTC','4h','0.000061400000000','0.000059920000000','0.001480934253844','0.001445237467269','24.119450388338763','24.119450388338763','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','GRSBTC','4h','0.000061770000000','0.000060500000000','0.001480934253844','0.001450486034605','23.974975778598026','23.974975778598026','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','GRSBTC','4h','0.000061490000000','0.000059990000000','0.001480934253844','0.001444808032007','24.084147891429502','24.084147891429502','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','GRSBTC','4h','0.000060610000000','0.000060650000000','0.001480934253844','0.001481911606924','24.433826989671672','24.433826989671672','test'),('2019-03-04 15:59:59','2019-03-04 19:59:59','GRSBTC','4h','0.000060890000000','0.000060860000000','0.001480934253844','0.001480204609771','24.321469105665955','24.321469105665955','test'),('2019-03-05 07:59:59','2019-03-07 07:59:59','GRSBTC','4h','0.000061000000000','0.000061330000000','0.001480934253844','0.001488945865381','24.2776107187541','24.277610718754101','test'),('2019-04-15 07:59:59','2019-04-15 15:59:59','GRSBTC','4h','0.000090730000000','0.000086290000000','0.001480934253844','0.001408462655838','16.322431983291086','16.322431983291086','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','GRSBTC','4h','0.000054260000000','0.000052770000000','0.001480934253844','0.001440267242450','27.29329623744932','27.293296237449319','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','GRSBTC','4h','0.000053780000000','0.000054520000000','0.001480934253844','0.001501311556705','27.53689575760506','27.536895757605059','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','GRSBTC','4h','0.000053910000000','0.000053570000000','0.001480934253844','0.001471594286374','27.47049255878316','27.470492558783160','test'),('2019-06-06 03:59:59','2019-06-06 15:59:59','GRSBTC','4h','0.000051460000000','0.000051420000000','0.001480934253844','0.001479783119562','28.778357050991062','28.778357050991062','test'),('2019-06-13 23:59:59','2019-06-14 03:59:59','GRSBTC','4h','0.000053980000000','0.000053050000000','0.001480934253844','0.001455419825239','27.43486946728418','27.434869467284180','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','GRSBTC','4h','0.000026320000000','0.000025620000000','0.001480934253844','0.001441547704540','56.26649900623101','56.266499006231008','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','GRSBTC','4h','0.000021750000000','0.000021800000000','0.001480934253844','0.001484338700405','68.0889312112184','68.088931211218394','test'),('2019-08-22 11:59:59','2019-08-26 03:59:59','GRSBTC','4h','0.000022030000000','0.000023090000000','0.001480934253844','0.001552191190252','67.22352491348161','67.223524913481612','test'),('2019-08-30 03:59:59','2019-08-30 07:59:59','GRSBTC','4h','0.000022720000000','0.000022800000000','0.001480934253844','0.001486148811076','65.18196539806338','65.181965398063383','test'),('2019-09-07 23:59:59','2019-09-08 07:59:59','GRSBTC','4h','0.000021500000000','0.000021360000000','0.001480934253844','0.001471290961028','68.88066296948837','68.880662969488370','test'),('2019-09-09 03:59:59','2019-09-09 07:59:59','GRSBTC','4h','0.000021440000000','0.000021180000000','0.001480934253844','0.001462975163079','69.07342601884328','69.073426018843278','test'),('2019-09-09 19:59:59','2019-09-12 03:59:59','GRSBTC','4h','0.000022180000000','0.000021080000000','0.001480934253844','0.001407488461273','66.7689023374211','66.768902337421096','test'),('2019-09-17 15:59:59','2019-09-22 07:59:59','GRSBTC','4h','0.000021320000000','0.000022280000000','0.001480934253844','0.001547617972591','69.46220702833021','69.462207028330212','test'),('2019-09-28 03:59:59','2019-09-29 15:59:59','GRSBTC','4h','0.000022100000000','0.000021680000000','0.001480934253844','0.001452789801961','67.01059972144797','67.010599721447974','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','GRSBTC','4h','0.000021820000000','0.000021390000000','0.001480934253844','0.001451749939951','67.87049742639779','67.870497426397790','test'),('2019-09-30 23:59:59','2019-10-01 03:59:59','GRSBTC','4h','0.000021780000000','0.000021740000000','0.001480934253844','0.001478214448052','67.99514480459136','67.995144804591362','test'),('2019-10-01 19:59:59','2019-10-01 23:59:59','GRSBTC','4h','0.000021890000000','0.000022200000000','0.001480934253844','0.001501906826649','67.65346065984468','67.653460659844683','test'),('2019-10-10 03:59:59','2019-10-10 07:59:59','GRSBTC','4h','0.000024030000000','0.000024000000000','0.001480934253844','0.001479085397098','61.62855821240117','61.628558212401167','test'),('2019-10-10 15:59:59','2019-10-10 19:59:59','GRSBTC','4h','0.000023680000000','0.000023640000000','0.001480934253844','0.001478432675713','62.53945328733108','62.539453287331078','test'),('2019-10-19 23:59:59','2019-10-20 03:59:59','GRSBTC','4h','0.000025610000000','0.000025370000000','0.001480934253844','0.001467055916440','57.826405850995705','57.826405850995705','test'),('2019-10-28 23:59:59','2019-10-29 03:59:59','GRSBTC','4h','0.000023880000000','0.000023480000000','0.001480934253844','0.001456127984935','62.015672271524295','62.015672271524295','test'),('2019-10-29 15:59:59','2019-10-29 19:59:59','GRSBTC','4h','0.000023600000000','0.000023610000000','0.001480934253844','0.001481561768358','62.751451434067796','62.751451434067796','test'),('2019-11-08 23:59:59','2019-11-09 03:59:59','GRSBTC','4h','0.000025000000000','0.000024800000000','0.001480934253844','0.001469086779813','59.23737015376','59.237370153759997','test'),('2019-11-25 07:59:59','2019-11-29 19:59:59','GRSBTC','4h','0.000025770000000','0.000025890000000','0.001480934253844','0.001487830338844','57.46737500364765','57.467375003647653','test'),('2019-11-30 11:59:59','2019-12-01 03:59:59','GRSBTC','4h','0.000026400000000','0.000025540000000','0.001480934253844','0.001432691698605','56.095994463787875','56.095994463787875','test'),('2019-12-07 11:59:59','2019-12-07 19:59:59','GRSBTC','4h','0.000025840000000','0.000025070000000','0.001480934253844','0.001436804247054','57.311697130185756','57.311697130185756','test'),('2019-12-09 07:59:59','2019-12-10 03:59:59','GRSBTC','4h','0.000027730000000','0.000026100000000','0.001480934253844','0.001393883304195','53.40549058218536','53.405490582185358','test'),('2019-12-11 07:59:59','2019-12-11 15:59:59','GRSBTC','4h','0.000025590000000','0.000025310000000','0.001480934253844','0.001464730205736','57.871600384681514','57.871600384681514','test'),('2019-12-27 11:59:59','2019-12-27 15:59:59','GRSBTC','4h','0.000022270000000','0.000021850000000','0.001480934253844','0.001453004645105','66.4990684258644','66.499068425864394','test'),('2019-12-31 23:59:59','2020-01-01 03:59:59','GRSBTC','4h','0.000021500000000','0.000021830000000','0.001480934253844','0.001503664872624','68.88066296948837','68.880662969488370','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 18:21:13
