-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 23:59:59','2019-01-08 03:59:59','SYSETH','4h','0.000340000000000','0.000342990000000','0.072144500000000','0.072778947220588','212.18970588235294','212.189705882352939','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','SYSETH','4h','0.000338050000000','0.000331730000000','0.072303111805147','0.070951371924631','213.88289248675346','213.882892486753462','test'),('2019-01-13 03:59:59','2019-01-13 23:59:59','SYSETH','4h','0.000338660000000','0.000328130000000','0.072303111805147','0.070054981623525','213.49764307903794','213.497643079037942','test'),('2019-01-15 07:59:59','2019-01-15 15:59:59','SYSETH','4h','0.000370150000000','0.000339990000000','0.072303111805147','0.066411819485700','195.3346259763528','195.334625976352811','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','SYSETH','4h','0.000354690000000','0.000344390000000','0.072303111805147','0.070203469718838','203.8487462436127','203.848746243612709','test'),('2019-02-17 15:59:59','2019-02-17 19:59:59','SYSETH','4h','0.000357310000000','0.000345300000000','0.072303111805147','0.069872840128508','202.3540113770871','202.354011377087090','test'),('2019-02-19 15:59:59','2019-02-19 23:59:59','SYSETH','4h','0.000356050000000','0.000343520000000','0.072303111805147','0.069758643357124','203.07010758361744','203.070107583617443','test'),('2019-02-20 15:59:59','2019-02-23 19:59:59','SYSETH','4h','0.000370060000000','0.000342870000000','0.072303111805147','0.066990671633332','195.38213210059718','195.382132100597175','test'),('2019-02-26 11:59:59','2019-02-27 07:59:59','SYSETH','4h','0.000365370000000','0.000350300000000','0.072303111805147','0.069320907751986','197.89011633452935','197.890116334529353','test'),('2019-02-27 15:59:59','2019-02-27 19:59:59','SYSETH','4h','0.000352540000000','0.000370730000000','0.072303111805147','0.076033734156471','205.09193795072048','205.091937950720478','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','SYSETH','4h','0.000394960000000','0.000384930000000','0.072303111805147','0.070466975965048','183.06439083741896','183.064390837418955','test'),('2019-03-12 11:59:59','2019-03-16 03:59:59','SYSETH','4h','0.000417460000000','0.000400240000000','0.072303111805147','0.069320647412667','173.1976999117209','173.197699911720889','test'),('2019-03-17 03:59:59','2019-03-25 03:59:59','SYSETH','4h','0.000404690000000','0.000416950000000','0.072303111805147','0.074493519649994','178.66295634966764','178.662956349667638','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','SYSETH','4h','0.000434530000000','0.000423750000000','0.072303111805147','0.070509386296530','166.39383196821163','166.393831968211629','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','SYSETH','4h','0.000443000000000','0.000431960000000','0.072303111805147','0.070501246445488','163.2124419980745','163.212441998074496','test'),('2019-04-24 11:59:59','2019-04-24 23:59:59','SYSETH','4h','0.000359710000000','0.000357540000000','0.072303111805147','0.071866933348565','201.0038970424703','201.003897042470300','test'),('2019-05-01 19:59:59','2019-05-03 07:59:59','SYSETH','4h','0.000351350000000','0.000351160000000','0.072303111805147','0.072264012356611','205.78657123992315','205.786571239923148','test'),('2019-05-04 07:59:59','2019-05-04 11:59:59','SYSETH','4h','0.000349340000000','0.000375620000000','0.072303111805147','0.077742299353779','206.9706068733812','206.970606873381200','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','SYSETH','4h','0.000355260000000','0.000356200000000','0.072303111805147','0.072494422183734','203.5216793479339','203.521679347933912','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','SYSETH','4h','0.000362680000000','0.000336590000000','0.072303111805147','0.067101865011841','199.3578686587267','199.357868658726687','test'),('2019-05-19 03:59:59','2019-05-19 19:59:59','SYSETH','4h','0.000302280000000','0.000287890000000','0.072303111805147','0.068861131591848','239.1925096107814','239.192509610781400','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','SYSETH','4h','0.000288770000000','0.000282280000000','0.072303111805147','0.070678125845333','250.38304465542473','250.383044655424726','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','SYSETH','4h','0.000295190000000','0.000299740000000','0.072303111805147','0.073417577602476','244.93753787440966','244.937537874409657','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','SYSETH','4h','0.000293770000000','0.000280150000000','0.072303111805147','0.068950937033094','246.12149574547092','246.121495745470924','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','SYSETH','4h','0.000297840000000','0.000271190000000','0.072303111805147','0.065833604923576','242.7582319538913','242.758231953891311','test'),('2019-06-01 11:59:59','2019-06-02 07:59:59','SYSETH','4h','0.000286650000000','0.000274090000000','0.072303111805147','0.069135042437372','252.23482227506364','252.234822275063635','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','SYSETH','4h','0.000282350000000','0.000276030000000','0.072303111805147','0.070684710294226','256.0761884368585','256.076188436858502','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','SYSETH','4h','0.000270040000000','0.000266490000000','0.072303111805147','0.071352600596036','267.7496363692305','267.749636369230473','test'),('2019-06-10 11:59:59','2019-06-10 15:59:59','SYSETH','4h','0.000270880000000','0.000266710000000','0.072303111805147','0.071190058142169','266.91934363979254','266.919343639792544','test'),('2019-06-13 07:59:59','2019-06-13 11:59:59','SYSETH','4h','0.000271320000000','0.000267750000000','0.072303111805147','0.071351755070869','266.48648018998597','266.486480189985969','test'),('2019-07-16 07:59:59','2019-07-16 19:59:59','SYSETH','4h','0.000138110000000','0.000137570000000','0.072303111805147','0.072020411925524','523.5182955987764','523.518295598776376','test'),('2019-08-16 19:59:59','2019-08-18 19:59:59','SYSETH','4h','0.000151490000000','0.000134730000000','0.072303111805147','0.064303902921034','477.27976635518513','477.279766355185131','test'),('2019-08-20 19:59:59','2019-08-20 23:59:59','SYSETH','4h','0.000133770000000','0.000133220000000','0.072303111805147','0.072005835050323','540.5031905894222','540.503190589422161','test'),('2019-08-24 07:59:59','2019-08-24 11:59:59','SYSETH','4h','0.000133760000000','0.000150260000000','0.072303111805147','0.081222081189006','540.5435990217329','540.543599021732916','test'),('2019-09-04 07:59:59','2019-09-04 11:59:59','SYSETH','4h','0.000152190000000','0.000147190000000','0.072303111805147','0.069927689247648','475.0845114997503','475.084511499750306','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','SYSETH','4h','0.000147670000000','0.000146720000000','0.072303111805147','0.071837966845339','489.6262734824067','489.626273482406702','test'),('2019-09-07 03:59:59','2019-09-07 07:59:59','SYSETH','4h','0.000147310000000','0.000149150000000','0.072303111805147','0.073206225821313','490.8228348730364','490.822834873036413','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','SYSETH','4h','0.000152080000000','0.000146780000000','0.072303111805147','0.069783342653600','475.4281418013348','475.428141801334789','test'),('2019-09-11 07:59:59','2019-09-11 11:59:59','SYSETH','4h','0.000146770000000','0.000148000000000','0.072303111805147','0.072909045085247','492.6286830084281','492.628683008428084','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','SYSETH','4h','0.000143500000000','0.000126120000000','0.072303111805147','0.063546121678503','503.8544376665296','503.854437666529577','test'),('2019-09-23 23:59:59','2019-09-24 03:59:59','SYSETH','4h','0.000130140000000','0.000124410000000','0.072303111805147','0.069119641460568','555.5794667676886','555.579466767688587','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','SYSETH','4h','0.000129760000000','0.000128850000000','0.072303111805147','0.071796053915638','557.2064719878775','557.206471987877535','test'),('2019-09-27 11:59:59','2019-09-27 15:59:59','SYSETH','4h','0.000130900000000','0.000128000000000','0.072303111805147','0.070701285798769','552.3537953028799','552.353795302879917','test'),('2019-09-28 07:59:59','2019-09-29 15:59:59','SYSETH','4h','0.000128730000000','0.000130540000000','0.072303111805147','0.073319725122690','561.6648163221238','561.664816322123784','test'),('2019-10-01 11:59:59','2019-10-01 19:59:59','SYSETH','4h','0.000136900000000','0.000132860000000','0.072303111805147','0.070169404195996','528.1454478096932','528.145447809693223','test'),('2019-10-13 11:59:59','2019-10-14 15:59:59','SYSETH','4h','0.000146480000000','0.000142030000000','0.072303111805147','0.070106574069395','493.6039855621723','493.603985562172284','test'),('2019-10-15 07:59:59','2019-10-15 11:59:59','SYSETH','4h','0.000142180000000','0.000144350000000','0.072303111805147','0.073406626734231','508.5322253843508','508.532225384350795','test'),('2019-10-16 07:59:59','2019-10-16 11:59:59','SYSETH','4h','0.000141520000000','0.000141520000000','0.072303111805147','0.072303111805147','510.90384260279114','510.903842602791144','test'),('2019-10-16 23:59:59','2019-10-17 03:59:59','SYSETH','4h','0.000141400000000','0.000139820000000','0.072303111805147','0.071495198674651','511.33742436454736','511.337424364547360','test'),('2019-10-20 15:59:59','2019-10-20 19:59:59','SYSETH','4h','0.000141350000000','0.000135940000000','0.072303111805147','0.069535797798314','511.5183007085037','511.518300708503716','test'),('2019-10-21 07:59:59','2019-10-21 11:59:59','SYSETH','4h','0.000142980000000','0.000139740000000','0.048202074536765','0.047109790850242','337.12459460599155','337.124594605991547','test'),('2019-10-22 19:59:59','2019-10-22 23:59:59','SYSETH','4h','0.000140410000000','0.000136800000000','0.053949754604042','0.052562683782017','384.2301446053865','384.230144605386499','test'),('2019-10-29 15:59:59','2019-10-29 19:59:59','SYSETH','4h','0.000138250000000','0.000131610000000','0.053949754604042','0.051358605449823','390.23330635835083','390.233306358350831','test'),('2019-10-31 23:59:59','2019-11-01 03:59:59','SYSETH','4h','0.000133070000000','0.000133080000000','0.053949754604042','0.053953808842759','405.42387167687684','405.423871676876843','test'),('2019-11-07 19:59:59','2019-11-08 03:59:59','SYSETH','4h','0.000140520000000','0.000137720000000','0.053949754604042','0.052874752377375','383.92936666696556','383.929366666965564','test'),('2019-11-13 15:59:59','2019-11-13 19:59:59','SYSETH','4h','0.000137720000000','0.000137270000000','0.053949754604042','0.053773473820047','391.73507554488816','391.735075544888161','test'),('2019-11-15 07:59:59','2019-11-15 23:59:59','SYSETH','4h','0.000141520000000','0.000144430000000','0.053949754604042','0.055059094527005','381.21646837225836','381.216468372258362','test'),('2019-11-23 15:59:59','2019-11-24 07:59:59','SYSETH','4h','0.000138230000000','0.000136000000000','0.053949754604042','0.053079408421831','390.28976780758154','390.289767807581541','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','SYSETH','4h','0.000136550000000','0.000134010000000','0.053949754604042','0.052946222002839','395.091575276763','395.091575276763024','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','SYSETH','4h','0.000136310000000','0.000134380000000','0.053949754604042','0.053185885288615','395.78721006560045','395.787210065600448','test'),('2019-11-25 15:59:59','2019-12-05 07:59:59','SYSETH','4h','0.000139080000000','0.000148520000000','0.053949754604042','0.057611572863045','387.9044765893155','387.904476589315493','test'),('2019-12-06 11:59:59','2019-12-06 15:59:59','SYSETH','4h','0.000146460000000','0.000145290000000','0.053949754604042','0.053518775409131','368.35828624909186','368.358286249091861','test'),('2019-12-06 23:59:59','2019-12-07 03:59:59','SYSETH','4h','0.000150690000000','0.000148800000000','0.053949754604042','0.053273100305803','358.0181472164178','358.018147216417788','test'),('2019-12-11 11:59:59','2019-12-12 11:59:59','SYSETH','4h','0.000151860000000','0.000148760000000','0.053949754604042','0.052848449195952','355.2598090612538','355.259809061253804','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','SYSETH','4h','0.000149420000000','0.000149370000000','0.053949754604042','0.053931701547355','361.0611337440905','361.061133744090512','test'),('2019-12-14 19:59:59','2019-12-14 23:59:59','SYSETH','4h','0.000152130000000','0.000156580000000','0.053949754604042','0.055527854965496','354.6292947087491','354.629294708749114','test'),('2019-12-23 07:59:59','2019-12-23 15:59:59','SYSETH','4h','0.000160580000000','0.000160130000000','0.053949754604042','0.053798568967152','335.9680819780919','335.968081978091902','test'),('2019-12-24 11:59:59','2019-12-24 15:59:59','SYSETH','4h','0.000159200000000','0.000158810000000','0.053949754604042','0.053817591260477','338.8803681158417','338.880368115841691','test'),('2019-12-24 19:59:59','2019-12-25 15:59:59','SYSETH','4h','0.000161920000000','0.000159180000000','0.053949754604042','0.053036820268475','333.1877137107337','333.187713710733703','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','SYSETH','4h','0.000160120000000','0.000156320000000','0.053949754604042','0.052669408192005','336.93326632551833','336.933266325518332','test'),('2019-12-27 07:59:59','2019-12-27 15:59:59','SYSETH','4h','0.000160700000000','0.000160700000000','0.053949754604042','0.053949754604042','335.71720350990665','335.717203509906653','test'),('2019-12-28 11:59:59','2019-12-28 15:59:59','SYSETH','4h','0.000160610000000','0.000158350000000','0.053949754604042','0.053190608564536','335.9053272152544','335.905327215254374','test'),('2019-12-28 19:59:59','2019-12-29 11:59:59','SYSETH','4h','0.000160630000000','0.000161150000000','0.053949754604042','0.054124403625981','335.8635037293282','335.863503729328215','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:03:51
