-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-06 07:59:59','LOOMBTC','4h','0.000012020000000','0.000012440000000','0.001467500000000','0.001518777038270','122.08818635607321','122.088186356073209','test'),('2019-01-07 15:59:59','2019-01-08 03:59:59','LOOMBTC','4h','0.000012990000000','0.000012240000000','0.001480319259567','0.001394850480146','113.95837256100847','113.958372561008474','test'),('2019-01-08 11:59:59','2019-01-08 23:59:59','LOOMBTC','4h','0.000012650000000','0.000012420000000','0.001480319259567','0.001453404363939','117.02128534126483','117.021285341264829','test'),('2019-01-09 23:59:59','2019-01-10 03:59:59','LOOMBTC','4h','0.000012390000000','0.000012360000000','0.001480319259567','0.001476734951432','119.4769378181598','119.476937818159797','test'),('2019-01-14 23:59:59','2019-01-15 03:59:59','LOOMBTC','4h','0.000012020000000','0.000011970000000','0.001480319259567','0.001474161525542','123.15468049642263','123.154680496422628','test'),('2019-01-16 03:59:59','2019-01-20 15:59:59','LOOMBTC','4h','0.000012480000000','0.000012060000000','0.001480319259567','0.001430500822947','118.61532528581729','118.615325285817292','test'),('2019-01-20 19:59:59','2019-01-20 23:59:59','LOOMBTC','4h','0.000012330000000','0.000012260000000','0.001480319259567','0.001471915176179','120.05833410924573','120.058334109245735','test'),('2019-01-21 23:59:59','2019-01-22 03:59:59','LOOMBTC','4h','0.000012430000000','0.000012310000000','0.001480319259567','0.001466028164543','119.09245853314562','119.092458533145617','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','LOOMBTC','4h','0.000012270000000','0.000012040000000','0.001480319259567','0.001452570813789','120.64541642762836','120.645416427628362','test'),('2019-02-04 03:59:59','2019-02-04 23:59:59','LOOMBTC','4h','0.000012640000000','0.000012070000000','0.001480319259567','0.001413564356248','117.11386547207279','117.113865472072789','test'),('2019-02-07 03:59:59','2019-02-07 07:59:59','LOOMBTC','4h','0.000011900000000','0.000011640000000','0.001480319259567','0.001447976149694','124.39657643420168','124.396576434201677','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','LOOMBTC','4h','0.000012000000000','0.000011790000000','0.001480319259567','0.001454413672525','123.35993829725','123.359938297249997','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','LOOMBTC','4h','0.000011450000000','0.000011420000000','0.001480319259567','0.001476440693821','129.2855248530131','129.285524853013101','test'),('2019-02-19 11:59:59','2019-02-19 15:59:59','LOOMBTC','4h','0.000011740000000','0.000011820000000','0.001480319259567','0.001490406613976','126.09193011643953','126.091930116439528','test'),('2019-03-27 07:59:59','2019-03-27 11:59:59','LOOMBTC','4h','0.000017320000000','0.000017260000000','0.001480319259567','0.001475191132802','85.46877942072749','85.468779420727486','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','LOOMBTC','4h','0.000017350000000','0.000017340000000','0.001480319259567','0.001479466049619','85.32099478772334','85.320994787723336','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','LOOMBTC','4h','0.000018560000000','0.000016720000000','0.001480319259567','0.001333563470903','79.75858079563578','79.758580795635780','test'),('2019-04-19 23:59:59','2019-04-20 03:59:59','LOOMBTC','4h','0.000014050000000','0.000013920000000','0.001480319259567','0.001466622355386','105.36080139266905','105.360801392669046','test'),('2019-05-16 03:59:59','2019-05-16 11:59:59','LOOMBTC','4h','0.000009870000000','0.000008960000000','0.001480319259567','0.001343835923579','149.98168789939209','149.981687899392085','test'),('2019-05-17 15:59:59','2019-05-19 03:59:59','LOOMBTC','4h','0.000009650000000','0.000009000000000','0.001480319259567','0.001380608635866','153.40095954062176','153.400959540621756','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','LOOMBTC','4h','0.000009180000000','0.000009210000000','0.001480319259567','0.001485156904206','161.25482130359475','161.254821303594753','test'),('2019-05-26 03:59:59','2019-05-26 11:59:59','LOOMBTC','4h','0.000009480000000','0.000009070000000','0.001480319259567','0.001416297013109','156.15182062943038','156.151820629430375','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','LOOMBTC','4h','0.000009340000000','0.000008520000000','0.001480319259567','0.001350355470183','158.49242607783725','158.492426077837251','test'),('2019-05-29 07:59:59','2019-05-29 15:59:59','LOOMBTC','4h','0.000009400000000','0.000009260000000','0.001480319259567','0.001458271951446','157.4807722943617','157.480772294361714','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','LOOMBTC','4h','0.000009280000000','0.000009100000000','0.001480319259567','0.001451606170481','159.51716159127156','159.517161591271559','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','LOOMBTC','4h','0.000009110000000','0.000009200000000','0.001480319259567','0.001494943708893','162.49388140142702','162.493881401427018','test'),('2019-06-03 11:59:59','2019-06-06 19:59:59','LOOMBTC','4h','0.000009210000000','0.000009410000000','0.001480319259567','0.001512465171827','160.72956129934852','160.729561299348518','test'),('2019-07-02 03:59:59','2019-07-02 11:59:59','LOOMBTC','4h','0.000006660000000','0.000006460000000','0.001480319259567','0.001435865227748','222.27015909414413','222.270159094144134','test'),('2019-07-20 15:59:59','2019-07-20 19:59:59','LOOMBTC','4h','0.000004500000000','0.000004290000000','0.001480319259567','0.001411237694121','328.9598354593333','328.959835459333306','test'),('2019-07-23 03:59:59','2019-07-24 03:59:59','LOOMBTC','4h','0.000004530000000','0.000004420000000','0.001480319259567','0.001444373317282','326.781293502649','326.781293502649021','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','LOOMBTC','4h','0.000004450000000','0.000004490000000','0.001480319259567','0.001493625500102','332.6560133858427','332.656013385842698','test'),('2019-07-25 23:59:59','2019-07-27 11:59:59','LOOMBTC','4h','0.000004470000000','0.000004440000000','0.001480319259567','0.001470384230979','331.1676195899328','331.167619589932826','test'),('2019-08-21 23:59:59','2019-08-26 03:59:59','LOOMBTC','4h','0.000003120000000','0.000003190000000','0.001480319259567','0.001513531550647','474.46130114326917','474.461301143269168','test'),('2019-09-20 23:59:59','2019-09-21 07:59:59','LOOMBTC','4h','0.000002420000000','0.000002410000000','0.001480319259567','0.001474202237833','611.7021733747933','611.702173374793347','test'),('2019-09-23 15:59:59','2019-09-24 19:59:59','LOOMBTC','4h','0.000002510000000','0.000002450000000','0.001480319259567','0.001444933141808','589.7686293095617','589.768629309561675','test'),('2019-10-01 19:59:59','2019-10-02 03:59:59','LOOMBTC','4h','0.000003370000000','0.000003310000000','0.001480319259567','0.001453963427052','439.26387524243324','439.263875242433244','test'),('2019-10-03 03:59:59','2019-10-03 07:59:59','LOOMBTC','4h','0.000003310000000','0.000003320000000','0.001480319259567','0.001484791523191','447.2263624069486','447.226362406948624','test'),('2019-10-03 23:59:59','2019-10-04 07:59:59','LOOMBTC','4h','0.000003390000000','0.000003150000000','0.001480319259567','0.001375517896058','436.67234795486723','436.672347954867234','test'),('2019-10-08 23:59:59','2019-10-09 03:59:59','LOOMBTC','4h','0.000003240000000','0.000003210000000','0.001480319259567','0.001466612599756','456.8886603601852','456.888660360185213','test'),('2019-10-18 03:59:59','2019-10-18 07:59:59','LOOMBTC','4h','0.000003010000000','0.000002950000000','0.001480319259567','0.001450811234459','491.80041846079735','491.800418460797346','test'),('2019-10-19 15:59:59','2019-10-19 23:59:59','LOOMBTC','4h','0.000002940000000','0.000002910000000','0.001480319259567','0.001465213961000','503.5099522336735','503.509952233673516','test'),('2019-11-01 07:59:59','2019-11-01 11:59:59','LOOMBTC','4h','0.000002580000000','0.000002540000000','0.001480319259567','0.001457368573372','573.7671548709302','573.767154870930199','test'),('2019-11-02 03:59:59','2019-11-02 07:59:59','LOOMBTC','4h','0.000002560000000','0.000002560000000','0.001480319259567','0.001480319259567','578.2497107683594','578.249710768359364','test'),('2019-11-03 03:59:59','2019-11-03 07:59:59','LOOMBTC','4h','0.000002600000000','0.000002540000000','0.001480319259567','0.001446158045885','569.3535613719231','569.353561371923092','test'),('2019-11-03 23:59:59','2019-11-04 11:59:59','LOOMBTC','4h','0.000002560000000','0.000002550000000','0.001480319259567','0.001474536762459','578.2497107683594','578.249710768359364','test'),('2019-11-11 15:59:59','2019-11-12 03:59:59','LOOMBTC','4h','0.000002570000000','0.000002530000000','0.001480319259567','0.001457279271091','575.9997118937744','575.999711893774361','test'),('2019-11-13 19:59:59','2019-11-17 23:59:59','LOOMBTC','4h','0.000002510000000','0.000002600000000','0.001480319259567','0.001533398436205','589.7686293095617','589.768629309561675','test'),('2019-11-26 23:59:59','2019-11-27 19:59:59','LOOMBTC','4h','0.000002470000000','0.000002320000000','0.001480319259567','0.001390421328824','599.3195382862348','599.319538286234774','test'),('2019-11-30 19:59:59','2019-11-30 23:59:59','LOOMBTC','4h','0.000002400000000','0.000002410000000','0.001480319259567','0.001486487256482','616.79969148625','616.799691486250026','test'),('2019-12-02 23:59:59','2019-12-03 03:59:59','LOOMBTC','4h','0.000002410000000','0.000002380000000','0.001480319259567','0.001461892048867','614.240356666805','614.240356666805042','test'),('2019-12-03 19:59:59','2019-12-04 15:59:59','LOOMBTC','4h','0.000002500000000','0.000002440000000','0.001480319259567','0.001444791597337','592.1277038267999','592.127703826799916','test'),('2019-12-14 15:59:59','2019-12-14 19:59:59','LOOMBTC','4h','0.000002630000000','0.000002550000000','0.001480319259567','0.001435290536843','562.8590340558935','562.859034055893517','test'),('2019-12-14 23:59:59','2019-12-15 19:59:59','LOOMBTC','4h','0.000002650000000','0.000002580000000','0.000986879506378','0.000960810991115','372.4073608973585','372.407360897358501','test'),('2019-12-20 15:59:59','2019-12-20 19:59:59','LOOMBTC','4h','0.000002520000000','0.000002510000000','0.001100821171785','0.001096452833802','436.83379832728195','436.833798327281954','test'),('2019-12-27 07:59:59','2019-12-27 23:59:59','LOOMBTC','4h','0.000002410000000','0.000002360000000','0.001100821171785','0.001077982558262','456.7722704502075','456.772270450207486','test'),('2019-12-28 19:59:59','2019-12-28 23:59:59','LOOMBTC','4h','0.000002370000000','0.000002340000000','0.001100821171785','0.001086886726573','464.4815070822784','464.481507082278426','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:40:04
