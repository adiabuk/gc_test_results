-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 07:59:59','2019-01-05 23:59:59','VIBEETH','4h','0.000225900000000','0.000210600000000','0.072144500000000','0.067258219123506','319.36476316954406','319.364763169544062','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','VIBEETH','4h','0.000213800000000','0.000213500000000','0.072144500000000','0.072043268241347','337.4391955098223','337.439195509822298','test'),('2019-02-02 23:59:59','2019-02-03 11:59:59','VIBEETH','4h','0.000335300000000','0.000324900000000','0.072144500000000','0.069906794065016','215.16403220996122','215.164032209961221','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','VIBEETH','4h','0.000329900000000','0.000321000000000','0.072144500000000','0.070198194907548','218.68596544407396','218.685965444073958','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','VIBEETH','4h','0.000324700000000','0.000316100000000','0.072144500000000','0.070233681706190','222.18817369879892','222.188173698798920','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','VIBEETH','4h','0.000270600000000','0.000270100000000','0.072144500000000','0.072011195306726','266.6093865484109','266.609386548410896','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','VIBEETH','4h','0.000272400000000','0.000275000000000','0.072144500000000','0.072833103891336','264.84765051395004','264.847650513950043','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','VIBEETH','4h','0.000270000000000','0.000268800000000','0.072144500000000','0.071823857777778','267.20185185185187','267.201851851851870','test'),('2019-03-01 15:59:59','2019-03-01 19:59:59','VIBEETH','4h','0.000272500000000','0.000270500000000','0.072144500000000','0.071614999082569','264.7504587155963','264.750458715596324','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','VIBEETH','4h','0.000304800000000','0.000303100000000','0.072144500000000','0.071742119258530','236.6945538057743','236.694553805774291','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','VIBEETH','4h','0.000314700000000','0.000313200000000','0.072144500000000','0.071800627264061','229.248490625993','229.248490625993014','test'),('2019-03-23 15:59:59','2019-03-23 23:59:59','VIBEETH','4h','0.000315800000000','0.000314800000000','0.072144500000000','0.071916050031666','228.44996833438887','228.449968334388871','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','VIBEETH','4h','0.000316400000000','0.000322100000000','0.072144500000000','0.073444195480405','228.01675094816687','228.016750948166873','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','VIBEETH','4h','0.000275400000000','0.000249200000000','0.072144500000000','0.065281079883805','261.9625998547567','261.962599854756718','test'),('2019-05-01 19:59:59','2019-05-02 03:59:59','VIBEETH','4h','0.000241300000000','0.000235600000000','0.072144500000000','0.070440299212598','298.98259428097805','298.982594280978049','test'),('2019-05-02 15:59:59','2019-05-02 19:59:59','VIBEETH','4h','0.000239100000000','0.000241200000000','0.072144500000000','0.072778140526976','301.73358427436216','301.733584274362158','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','VIBEETH','4h','0.000245100000000','0.000237000000000','0.072144500000000','0.069760287637699','294.34720522235824','294.347205222358241','test'),('2019-05-22 15:59:59','2019-05-24 19:59:59','VIBEETH','4h','0.000182900000000','0.000189000000000','0.072144500000000','0.074550631492619','394.44778567523235','394.447785675232353','test'),('2019-05-26 07:59:59','2019-05-26 19:59:59','VIBEETH','4h','0.000187900000000','0.000175500000000','0.072144500000000','0.067383500532198','383.9515699840341','383.951569984034109','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEETH','4h','0.000188100000000','0.000182200000000','0.072144500000000','0.069881594364700','383.54332801701224','383.543328017012243','test'),('2019-05-29 07:59:59','2019-05-29 15:59:59','VIBEETH','4h','0.000183500000000','0.000180300000000','0.072144500000000','0.070886394277929','393.158038147139','393.158038147138996','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEETH','4h','0.000185600000000','0.000184300000000','0.072144500000000','0.071639177532328','388.70959051724134','388.709590517241338','test'),('2019-06-07 11:59:59','2019-06-12 15:59:59','VIBEETH','4h','0.000190000000000','0.000192400000000','0.072144500000000','0.073055798947368','379.7078947368421','379.707894736842093','test'),('2019-07-05 15:59:59','2019-07-07 03:59:59','VIBEETH','4h','0.000118400000000','0.000120100000000','0.072144500000000','0.073180358530405','609.3285472972973','609.328547297297291','test'),('2019-07-22 11:59:59','2019-07-22 15:59:59','VIBEETH','4h','0.000101000000000','0.000099600000000','0.072144500000000','0.071144477227723','714.3019801980198','714.301980198019805','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','VIBEETH','4h','0.000100200000000','0.000099000000000','0.072144500000000','0.071280494011976','720.0049900199601','720.004990019960132','test'),('2019-07-27 11:59:59','2019-07-27 19:59:59','VIBEETH','4h','0.000099600000000','0.000098400000000','0.072144500000000','0.071275289156627','724.3423694779117','724.342369477911689','test'),('2019-07-28 03:59:59','2019-07-28 07:59:59','VIBEETH','4h','0.000100800000000','0.000100600000000','0.072144500000000','0.072001356150794','715.719246031746','715.719246031746025','test'),('2019-07-28 19:59:59','2019-07-31 15:59:59','VIBEETH','4h','0.000102900000000','0.000097800000000','0.072144500000000','0.068568825072886','701.1127308066084','701.112730806608397','test'),('2019-08-12 23:59:59','2019-08-13 07:59:59','VIBEETH','4h','0.000082800000000','0.000080900000000','0.072144500000000','0.070489010265700','871.3103864734301','871.310386473430071','test'),('2019-08-14 11:59:59','2019-08-14 15:59:59','VIBEETH','4h','0.000081400000000','0.000080900000000','0.072144500000000','0.071701351965602','886.2960687960688','886.296068796068766','test'),('2019-08-17 19:59:59','2019-08-18 03:59:59','VIBEETH','4h','0.000080100000000','0.000080300000000','0.072144500000000','0.072324636079900','900.6803995006243','900.680399500624276','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','VIBEETH','4h','0.000080100000000','0.000075900000000','0.072144500000000','0.068361642322097','900.6803995006243','900.680399500624276','test'),('2019-08-21 15:59:59','2019-08-23 15:59:59','VIBEETH','4h','0.000079900000000','0.000079300000000','0.072144500000000','0.071602739048811','902.9349186483104','902.934918648310372','test'),('2019-08-29 11:59:59','2019-08-29 19:59:59','VIBEETH','4h','0.000090500000000','0.000092000000000','0.072144500000000','0.073340265193370','797.1767955801105','797.176795580110479','test'),('2019-09-09 23:59:59','2019-09-11 03:59:59','VIBEETH','4h','0.000086700000000','0.000085200000000','0.072144500000000','0.070896325259516','832.116493656286','832.116493656286025','test'),('2019-09-13 11:59:59','2019-09-13 23:59:59','VIBEETH','4h','0.000086700000000','0.000084500000000','0.072144500000000','0.070313843713956','832.116493656286','832.116493656286025','test'),('2019-09-14 23:59:59','2019-09-16 11:59:59','VIBEETH','4h','0.000086800000000','0.000085700000000','0.072144500000000','0.071230226382488','831.1578341013825','831.157834101382491','test'),('2019-09-18 15:59:59','2019-09-18 19:59:59','VIBEETH','4h','0.000087300000000','0.000084300000000','0.072144500000000','0.069665307560137','826.397479954181','826.397479954180994','test'),('2019-09-20 19:59:59','2019-09-21 03:59:59','VIBEETH','4h','0.000087000000000','0.000086600000000','0.072144500000000','0.071812801149425','829.2471264367816','829.247126436781627','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','VIBEETH','4h','0.000089100000000','0.000084100000000','0.072144500000000','0.068095987093154','809.702581369248','809.702581369248037','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','VIBEETH','4h','0.000087000000000','0.000087000000000','0.072144500000000','0.072144500000000','829.2471264367816','829.247126436781627','test'),('2019-09-27 11:59:59','2019-10-09 15:59:59','VIBEETH','4h','0.000090000000000','0.000119000000000','0.072144500000000','0.095391061111111','801.6055555555555','801.605555555555497','test'),('2019-10-21 23:59:59','2019-10-22 03:59:59','VIBEETH','4h','0.000113600000000','0.000112800000000','0.072144500000000','0.071636440140845','635.074823943662','635.074823943661954','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','VIBEETH','4h','0.000115300000000','0.000105800000000','0.072144500000000','0.066200243712056','625.7111882046835','625.711188204683481','test'),('2019-10-30 23:59:59','2019-10-31 07:59:59','VIBEETH','4h','0.000104900000000','0.000103500000000','0.072144500000000','0.071181656339371','687.7454718779791','687.745471877979071','test'),('2019-11-01 11:59:59','2019-11-01 15:59:59','VIBEETH','4h','0.000104500000000','0.000104000000000','0.072144500000000','0.071799311004785','690.3779904306219','690.377990430621935','test'),('2019-11-02 03:59:59','2019-11-02 07:59:59','VIBEETH','4h','0.000104900000000','0.000103100000000','0.072144500000000','0.070906558150620','687.7454718779791','687.745471877979071','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','VIBEETH','4h','0.000103900000000','0.000102600000000','0.072144500000000','0.071241825794033','694.3647738209817','694.364773820981668','test'),('2019-11-03 11:59:59','2019-11-03 23:59:59','VIBEETH','4h','0.000104500000000','0.000103900000000','0.072144500000000','0.071730273205742','690.3779904306219','690.377990430621935','test'),('2019-11-08 03:59:59','2019-11-08 07:59:59','VIBEETH','4h','0.000104300000000','0.000102000000000','0.072144500000000','0.070553585810163','691.7018216682646','691.701821668264643','test'),('2019-11-10 11:59:59','2019-11-10 19:59:59','VIBEETH','4h','0.000102600000000','0.000100600000000','0.072144500000000','0.070738174463938','703.1627680311891','703.162768031189103','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','VIBEETH','4h','0.000102500000000','0.000100700000000','0.072144500000000','0.070877572195122','703.8487804878049','703.848780487804902','test'),('2019-11-18 11:59:59','2019-11-18 15:59:59','VIBEETH','4h','0.000102500000000','0.000099800000000','0.072144500000000','0.070244108292683','703.8487804878049','703.848780487804902','test'),('2019-11-25 11:59:59','2019-11-27 11:59:59','VIBEETH','4h','0.000098000000000','0.000099100000000','0.072144500000000','0.072954285204082','736.1683673469388','736.168367346938794','test'),('2019-11-28 03:59:59','2019-12-04 03:59:59','VIBEETH','4h','0.000098900000000','0.000101300000000','0.072144500000000','0.073895225985844','729.469160768453','729.469160768452980','test'),('2019-12-07 03:59:59','2019-12-08 03:59:59','VIBEETH','4h','0.000102400000000','0.000102100000000','0.072144500000000','0.071933139160156','704.5361328125','704.536132812500000','test'),('2019-12-15 11:59:59','2019-12-15 15:59:59','VIBEETH','4h','0.000099900000000','0.000098000000000','0.072144500000000','0.070772382382382','722.1671671671671','722.167167167167122','test'),('2019-12-19 23:59:59','2019-12-20 03:59:59','VIBEETH','4h','0.000097700000000','0.000096700000000','0.072144500000000','0.071406071136131','738.4288638689867','738.428863868986696','test'),('2019-12-28 23:59:59','2019-12-29 03:59:59','VIBEETH','4h','0.000097000000000','0.000094000000000','0.072144500000000','0.069913226804124','743.7577319587629','743.757731958762861','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:29:03
