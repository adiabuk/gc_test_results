-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 15:59:59','LTCBNB','4h','5.460000000000000','5.390000000000000','0.711908500000000','0.702781467948718','0.13038617216117218','0.130386172161172','test'),('2019-01-03 23:59:59','2019-01-04 15:59:59','LTCBNB','4h','5.420000000000000','5.240000000000000','0.711908500000000','0.688265782287823','0.13134843173431734','0.131348431734317','test'),('2019-01-05 03:59:59','2019-01-09 07:59:59','LTCBNB','4h','5.450000000000000','5.700000000000000','0.711908500000000','0.744564853211009','0.1306254128440367','0.130625412844037','test'),('2019-01-24 23:59:59','2019-01-25 03:59:59','LTCBNB','4h','5.040000000000000','5.030000000000000','0.711908500000000','0.710495983134921','0.1412516865079365','0.141251686507937','test'),('2019-01-28 19:59:59','2019-01-28 23:59:59','LTCBNB','4h','4.960000000000000','5.040000000000000','0.711908500000000','0.723390895161290','0.14352993951612905','0.143529939516129','test'),('2019-02-01 19:59:59','2019-02-02 07:59:59','LTCBNB','4h','5.020000000000000','4.940000000000000','0.714397620435940','0.703012797799511','0.1423102829553666','0.142310282955367','test'),('2019-02-02 23:59:59','2019-02-03 03:59:59','LTCBNB','4h','5.060000000000000','5.020000000000000','0.714397620435940','0.708750208416684','0.1411853004814111','0.141185300481411','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','LTCBNB','4h','5.030000000000000','4.920000000000000','0.714397620435940','0.698774610843902','0.14202735992762228','0.142027359927622','test'),('2019-02-08 15:59:59','2019-02-10 03:59:59','LTCBNB','4h','4.860000000000000','4.790000000000000','0.714397620435940','0.704107942775340','0.14699539515142798','0.146995395151428','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','LTCBNB','4h','4.810000000000000','4.740000000000000','0.714397620435940','0.704000981469097','0.14852341381204576','0.148523413812046','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','LTCBNB','4h','4.840000000000000','4.740000000000000','0.714397620435940','0.699637339021974','0.14760281413965703','0.147602814139657','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','LTCBNB','4h','4.790000000000000','4.830000000000000','0.714397620435940','0.720363362569017','0.1491435533269186','0.149143553326919','test'),('2019-02-18 11:59:59','2019-02-19 15:59:59','LTCBNB','4h','4.910000000000000','4.650000000000000','0.714397620435940','0.676568011207153','0.14549849703379633','0.145498497033796','test'),('2019-02-21 03:59:59','2019-02-21 07:59:59','LTCBNB','4h','4.790000000000000','4.860000000000000','0.714397620435940','0.724837669168824','0.1491435533269186','0.149143553326919','test'),('2019-02-23 19:59:59','2019-02-24 11:59:59','LTCBNB','4h','4.740000000000000','4.790000000000000','0.714397620435940','0.721933460313956','0.15071679756032488','0.150716797560325','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LTCBNB','4h','4.690000000000000','4.710000000000000','0.714397620435940','0.717444092164878','0.1523235864468955','0.152323586446896','test'),('2019-03-15 23:59:59','2019-03-16 03:59:59','LTCBNB','4h','3.920000000000000','4.060000000000000','0.714397620435940','0.739911821165795','0.18224429092753572','0.182244290927536','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','LTCBNB','4h','3.900000000000000','3.950000000000000','0.714397620435940','0.723556564287683','0.1831788770348564','0.183178877034856','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','LTCBNB','4h','3.760000000000000','3.710000000000000','0.714397620435940','0.704897652079079','0.1899993671372181','0.189999367137218','test'),('2019-04-02 15:59:59','2019-04-02 23:59:59','LTCBNB','4h','3.750000000000000','3.900000000000000','0.714397620435940','0.742973525253378','0.19050603211625067','0.190506032116251','test'),('2019-04-30 23:59:59','2019-05-01 03:59:59','LTCBNB','4h','3.370000000000000','3.360000000000000','0.714397620435940','0.712277746191323','0.21198742446170327','0.211987424461703','test'),('2019-05-03 15:59:59','2019-05-04 07:59:59','LTCBNB','4h','3.400000000000000','3.380000000000000','0.714397620435940','0.710195281492199','0.2101169471870412','0.210116947187041','test'),('2019-05-05 19:59:59','2019-05-05 23:59:59','LTCBNB','4h','3.350000000000000','3.290000000000000','0.714397620435940','0.701602439174401','0.21325302102565374','0.213253021025654','test'),('2019-05-06 11:59:59','2019-05-06 15:59:59','LTCBNB','4h','3.340000000000000','3.390000000000000','0.714397620435940','0.725092195592167','0.21389150312453295','0.213891503124533','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','LTCBNB','4h','3.870000000000000','3.800000000000000','0.714397620435940','0.701475699652861','0.18459886832970027','0.184598868329700','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','LTCBNB','4h','3.780000000000000','3.670000000000000','0.714397620435940','0.693608271693095','0.18899407948040742','0.188994079480407','test'),('2019-05-26 23:59:59','2019-05-30 03:59:59','LTCBNB','4h','3.350000000000000','3.370000000000000','0.714397620435940','0.718662680856453','0.21325302102565374','0.213253021025654','test'),('2019-06-06 19:59:59','2019-06-13 07:59:59','LTCBNB','4h','3.450000000000000','3.780000000000000','0.714397620435940','0.782731305868943','0.20707177403940288','0.207071774039403','test'),('2019-06-14 03:59:59','2019-06-14 07:59:59','LTCBNB','4h','3.770000000000000','3.860000000000000','0.715715217693713','0.732801257373404','0.18984488532989743','0.189844885329897','test'),('2019-06-18 23:59:59','2019-06-19 03:59:59','LTCBNB','4h','3.930000000000000','3.850000000000000','0.719986727613636','0.705330509239822','0.18320272967268095','0.183202729672681','test'),('2019-06-19 15:59:59','2019-06-19 19:59:59','LTCBNB','4h','3.900000000000000','3.920000000000000','0.719986727613636','0.723678967242424','0.18461198143939386','0.184611981439394','test'),('2019-06-20 03:59:59','2019-06-20 07:59:59','LTCBNB','4h','3.910000000000000','3.870000000000000','0.719986727613636','0.712621134492269','0.184139828034178','0.184139828034178','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','LTCBNB','4h','3.780000000000000','3.670000000000000','0.719986727613636','0.699034732894721','0.19047267926286668','0.190472679262867','test'),('2019-06-29 11:59:59','2019-07-01 11:59:59','LTCBNB','4h','3.760000000000000','3.670000000000000','0.719986727613636','0.702753002750544','0.19148583181213724','0.191485831812137','test'),('2019-07-02 15:59:59','2019-07-02 19:59:59','LTCBNB','4h','3.720000000000000','3.700000000000000','0.719986727613636','0.716115831228616','0.1935448192509774','0.193544819250977','test'),('2019-07-03 15:59:59','2019-07-03 19:59:59','LTCBNB','4h','3.710000000000000','3.680000000000000','0.719986727613636','0.714164732511639','0.1940665033999019','0.194066503399902','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','LTCBNB','4h','3.740000000000000','3.680000000000000','0.719986727613636','0.708436138400583','0.19250982021754973','0.192509820217550','test'),('2019-07-04 07:59:59','2019-07-04 11:59:59','LTCBNB','4h','3.840000000000000','3.610000000000000','0.719986727613636','0.676862522574278','0.1874965436493844','0.187496543649384','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','LTCBNB','4h','3.730000000000000','3.630000000000000','0.719986727613636','0.700684134380026','0.19302593233609544','0.193025932336095','test'),('2019-07-09 03:59:59','2019-07-09 07:59:59','LTCBNB','4h','3.690000000000000','3.640000000000000','0.719986727613636','0.710230809895294','0.19511835436683903','0.195118354366839','test'),('2019-07-09 23:59:59','2019-07-10 03:59:59','LTCBNB','4h','3.670000000000000','3.720000000000000','0.719986727613636','0.729795811096111','0.1961816696494921','0.196181669649492','test'),('2019-07-18 15:59:59','2019-07-19 07:59:59','LTCBNB','4h','3.409000000000000','3.321000000000000','0.719986727613636','0.701400974598089','0.21120173881303492','0.211201738813035','test'),('2019-07-19 23:59:59','2019-07-20 03:59:59','LTCBNB','4h','3.394000000000000','3.259000000000000','0.719986727613636','0.691348481229475','0.21213515840118916','0.212135158401189','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','LTCBNB','4h','3.310000000000000','3.241000000000000','0.719986727613636','0.704977940844651','0.2175186488258719','0.217518648825872','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','LTCBNB','4h','3.278000000000000','3.248000000000000','0.719986727613636','0.713397465310888','0.21964207675827824','0.219642076758278','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','LTCBNB','4h','3.262000000000000','3.243000000000000','0.719986727613636','0.715793058752612','0.22071941373808585','0.220719413738086','test'),('2019-07-26 23:59:59','2019-07-27 03:59:59','LTCBNB','4h','3.252000000000000','3.221000000000000','0.719986727613636','0.713123385499238','0.22139813272252032','0.221398132722520','test'),('2019-07-28 23:59:59','2019-08-02 19:59:59','LTCBNB','4h','3.242000000000000','3.343000000000000','0.719986727613636','0.742416912526954','0.22208103874572363','0.222081038745724','test'),('2019-08-04 07:59:59','2019-08-04 11:59:59','LTCBNB','4h','3.355000000000000','3.344000000000000','0.719986727613636','0.717626115391952','0.2146011110621866','0.214601111062187','test'),('2019-08-04 15:59:59','2019-08-06 03:59:59','LTCBNB','4h','3.380000000000000','3.421000000000000','0.719986727613636','0.728720294427884','0.21301382473776215','0.213013824737762','test'),('2019-08-23 23:59:59','2019-08-24 03:59:59','LTCBNB','4h','2.799000000000000','2.764000000000000','0.719986727613636','0.710983678143655','0.25722998485660453','0.257229984856605','test'),('2019-08-24 23:59:59','2019-08-25 03:59:59','LTCBNB','4h','2.787000000000000','2.792000000000000','0.719986727613636','0.721278415320155','0.25833754130378045','0.258337541303780','test'),('2019-08-26 03:59:59','2019-08-26 07:59:59','LTCBNB','4h','2.839000000000000','2.728000000000000','0.719986727613636','0.691836489232124','0.25360575118479606','0.253605751184796','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','LTCBNB','4h','2.829000000000000','2.840000000000000','0.719986727613636','0.722786251828465','0.2545022013480509','0.254502201348051','test'),('2019-09-07 11:59:59','2019-09-18 11:59:59','LTCBNB','4h','2.990000000000000','3.356000000000000','0.719986727613636','0.808118882231225','0.2407982366600789','0.240798236660079','test'),('2019-09-29 07:59:59','2019-09-29 11:59:59','LTCBNB','4h','3.533000000000000','3.561000000000000','0.719986727613636','0.725692821124302','0.20378905395234534','0.203789053952345','test'),('2019-10-02 03:59:59','2019-10-03 07:59:59','LTCBNB','4h','3.565000000000000','3.548000000000000','0.719986727613636','0.716553410819966','0.20195981139232427','0.201959811392324','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','LTCBNB','4h','3.070000000000000','3.030000000000000','0.719986727613636','0.710605793051895','0.23452336404352966','0.234523364043530','test'),('2019-10-27 15:59:59','2019-10-28 03:59:59','LTCBNB','4h','3.131000000000000','2.920000000000000','0.719986727613636','0.671466382827153','0.22995424069423062','0.229954240694231','test'),('2019-11-04 15:59:59','2019-11-12 07:59:59','LTCBNB','4h','3.001000000000000','3.043000000000000','0.719986727613636','0.730063182981771','0.23991560400321094','0.239915604003211','test'),('2019-11-17 11:59:59','2019-11-17 15:59:59','LTCBNB','4h','2.961000000000000','2.920000000000000','0.719986727613636','0.710017306528814','0.2431566118249362','0.243156611824936','test'),('2019-11-17 19:59:59','2019-11-17 23:59:59','LTCBNB','4h','2.969000000000000','2.936000000000000','0.719986727613636','0.711984180624330','0.24250142391836849','0.242501423918368','test'),('2019-11-19 07:59:59','2019-11-19 23:59:59','LTCBNB','4h','2.999000000000000','2.983000000000000','0.719986727613636','0.716145517996491','0.2400756010715692','0.240075601071569','test'),('2019-11-22 11:59:59','2019-11-23 19:59:59','LTCBNB','4h','3.017000000000000','2.981000000000000','0.719986727613636','0.711395570108137','0.2386432640416427','0.238643264041643','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','LTCBNB','4h','2.997000000000000','3.029000000000000','0.719986727613636','0.727674273587489','0.2402358116828949','0.240235811682895','test'),('2019-11-26 07:59:59','2019-11-27 19:59:59','LTCBNB','4h','3.000000000000000','2.991000000000000','0.719986727613636','0.717826767430795','0.239995575871212','0.239995575871212','test'),('2019-11-28 03:59:59','2019-11-28 07:59:59','LTCBNB','4h','2.998000000000000','3.008000000000000','0.719986727613636','0.722388284410213','0.24015567965765042','0.240155679657650','test'),('2019-11-28 19:59:59','2019-11-28 23:59:59','LTCBNB','4h','3.004000000000000','3.014000000000000','0.719986727613636','0.722383487692243','0.23967600786073104','0.239676007860731','test'),('2019-12-10 15:59:59','2019-12-11 15:59:59','LTCBNB','4h','2.998000000000000','2.962000000000000','0.719986727613636','0.711341123145961','0.24015567965765042','0.240155679657650','test'),('2019-12-17 03:59:59','2019-12-17 19:59:59','LTCBNB','4h','3.016000000000000','3.014000000000000','0.719986727613636','0.719509282834051','0.23872238979231963','0.238722389792320','test'),('2019-12-18 19:59:59','2019-12-19 03:59:59','LTCBNB','4h','3.029000000000000','3.051000000000000','0.719986727613636','0.725216079877585','0.23769783017947707','0.237697830179477','test'),('2019-12-21 11:59:59','2019-12-21 15:59:59','LTCBNB','4h','2.995000000000000','2.983000000000000','0.719986727613636','0.717101972778456','0.240396236264987','0.240396236264987','test'),('2019-12-21 19:59:59','2019-12-21 23:59:59','LTCBNB','4h','2.988000000000000','2.983000000000000','0.719986727613636','0.718781930546009','0.24095941352531325','0.240959413525313','test'),('2019-12-22 07:59:59','2019-12-24 15:59:59','LTCBNB','4h','3.052000000000000','3.004000000000000','0.719986727613636','0.708663214204247','0.23590652936226605','0.235906529362266','test'),('2019-12-26 19:59:59','2019-12-27 03:59:59','LTCBNB','4h','3.079000000000000','3.059000000000000','0.719986727613636','0.715309970695067','0.23383784592843002','0.233837845928430','test'),('2019-12-30 07:59:59','2019-12-30 11:59:59','LTCBNB','4h','3.070000000000000','3.039000000000000','0.719986727613636','0.712716503328287','0.23452336404352966','0.234523364043530','test'),('2019-12-30 23:59:59','2019-12-31 11:59:59','LTCBNB','4h','3.061000000000000','3.039000000000000','0.719986727613636','0.714812043521019','0.23521291330076316','0.235212913300763','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 11:31:31
