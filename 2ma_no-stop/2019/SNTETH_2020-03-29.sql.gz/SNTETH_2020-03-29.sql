-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 19:59:59','2019-01-08 23:59:59','SNTETH','4h','0.000128640000000','0.000128880000000','0.072144500000000','0.072279097947761','560.8247823383085','560.824782338308523','test'),('2019-01-26 03:59:59','2019-01-26 19:59:59','SNTETH','4h','0.000184910000000','0.000182210000000','0.072178149486940','0.071124225937025','390.342055523986','390.342055523986005','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','SNTETH','4h','0.000181730000000','0.000180430000000','0.072178149486940','0.071661825300878','397.17245081681614','397.172450816816138','test'),('2019-02-02 07:59:59','2019-02-02 11:59:59','SNTETH','4h','0.000181430000000','0.000176560000000','0.072178149486940','0.070240721343847','397.82918749346857','397.829187493468567','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','SNTETH','4h','0.000162270000000','0.000157920000000','0.072178149486940','0.070243257330237','444.80279464435813','444.802794644358130','test'),('2019-02-21 23:59:59','2019-02-22 03:59:59','SNTETH','4h','0.000154280000000','0.000149130000000','0.072178149486940','0.069768780353820','467.8386666252269','467.838666625226892','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','SNTETH','4h','0.000149140000000','0.000147050000000','0.072178149486940','0.071166668110866','483.9623808967413','483.962380896741308','test'),('2019-02-27 15:59:59','2019-02-27 19:59:59','SNTETH','4h','0.000148030000000','0.000152290000000','0.072178149486940','0.074255288693955','487.59136314895625','487.591363148956248','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','SNTETH','4h','0.000148320000000','0.000147810000000','0.072178149486940','0.071929964102377','486.63800894646715','486.638008946467153','test'),('2019-03-07 19:59:59','2019-03-07 23:59:59','SNTETH','4h','0.000148780000000','0.000148060000000','0.072178149486940','0.071828853428124','485.1334150217771','485.133415021777125','test'),('2019-03-08 23:59:59','2019-03-09 03:59:59','SNTETH','4h','0.000148910000000','0.000148850000000','0.072178149486940','0.072149066893634','484.70988843556506','484.709888435565063','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','SNTETH','4h','0.000161040000000','0.000160840000000','0.072178149486940','0.072088509460255','448.20013342610537','448.200133426105367','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','SNTETH','4h','0.000162210000000','0.000160500000000','0.072178149486940','0.071417255364366','444.96732314246964','444.967323142469638','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','SNTETH','4h','0.000161990000000','0.000167850000000','0.072178149486940','0.074789199280097','445.5716370574726','445.571637057472628','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','SNTETH','4h','0.000165530000000','0.000163640000000','0.072178149486940','0.071354028768458','436.04270819150605','436.042708191506051','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','SNTETH','4h','0.000166580000000','0.000165390000000','0.072178149486940','0.071662529377146','433.2942099107936','433.294209910793597','test'),('2019-03-28 03:59:59','2019-04-02 07:59:59','SNTETH','4h','0.000165320000000','0.000174590000000','0.072178149486940','0.076225399945106','436.5965974288652','436.596597428865209','test'),('2019-04-03 03:59:59','2019-04-05 15:59:59','SNTETH','4h','0.000178310000000','0.000173620000000','0.072178149486940','0.070279683214192','404.79025005294153','404.790250052941531','test'),('2019-04-07 07:59:59','2019-04-07 15:59:59','SNTETH','4h','0.000174490000000','0.000172960000000','0.072178149486940','0.071545261821658','413.6520688116225','413.652068811622485','test'),('2019-04-14 15:59:59','2019-04-14 23:59:59','SNTETH','4h','0.000163330000000','0.000158820000000','0.072178149486940','0.070185108072711','441.91605637017085','441.916056370170850','test'),('2019-04-16 15:59:59','2019-04-16 23:59:59','SNTETH','4h','0.000164880000000','0.000159500000000','0.072178149486940','0.069822991528184','437.7617023710577','437.761702371057709','test'),('2019-04-17 07:59:59','2019-04-17 15:59:59','SNTETH','4h','0.000160680000000','0.000159270000000','0.072178149486940','0.071544771401450','449.204315950585','449.204315950584999','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','SNTETH','4h','0.000109500000000','0.000107530000000','0.072178149486940','0.070879601957358','659.1611825291324','659.161182529132361','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','SNTETH','4h','0.000109680000000','0.000108200000000','0.072178149486940','0.071204191962864','658.0794081595551','658.079408159555101','test'),('2019-05-27 23:59:59','2019-05-29 07:59:59','SNTETH','4h','0.000112160000000','0.000110410000000','0.072178149486940','0.071051974722299','643.5284369377675','643.528436937767538','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','SNTETH','4h','0.000110730000000','0.000109050000000','0.072178149486940','0.071083059708758','651.8391536795809','651.839153679580932','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','SNTETH','4h','0.000110730000000','0.000107870000000','0.072178149486940','0.070313889507416','651.8391536795809','651.839153679580932','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','SNTETH','4h','0.000109070000000','0.000106940000000','0.072178149486940','0.070768600954739','661.7598742728524','661.759874272852358','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','SNTETH','4h','0.000109030000000','0.000108420000000','0.072178149486940','0.071774327867321','662.0026551127212','662.002655112721186','test'),('2019-06-05 07:59:59','2019-06-05 11:59:59','SNTETH','4h','0.000109550000000','0.000106480000000','0.072178149486940','0.070155448264440','658.8603330619808','658.860333061980782','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','SNTETH','4h','0.000108260000000','0.000106160000000','0.072178149486940','0.070778056064415','666.7111535834104','666.711153583410351','test'),('2019-06-07 07:59:59','2019-06-13 03:59:59','SNTETH','4h','0.000123320000000','0.000115760000000','0.072178149486940','0.067753345642298','585.2915138415505','585.291513841550454','test'),('2019-07-14 23:59:59','2019-07-15 03:59:59','SNTETH','4h','0.000091130000000','0.000089230000000','0.072178149486940','0.070673282988255','792.0349993080215','792.034999308021497','test'),('2019-07-19 03:59:59','2019-07-27 23:59:59','SNTETH','4h','0.000091700000000','0.000096910000000','0.072178149486940','0.076279001818750','787.111771940458','787.111771940457970','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','SNTETH','4h','0.000096860000000','0.000094970000000','0.072178149486940','0.070769759000358','745.1801516306008','745.180151630600790','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','SNTETH','4h','0.000095670000000','0.000095100000000','0.072178149486940','0.071748113475572','754.4491427504965','754.449142750496549','test'),('2019-07-30 11:59:59','2019-07-30 15:59:59','SNTETH','4h','0.000095430000000','0.000095980000000','0.072178149486940','0.072594140079184','756.3465313521954','756.346531352195370','test'),('2019-08-09 11:59:59','2019-08-11 19:59:59','SNTETH','4h','0.000094060000000','0.000093240000000','0.072178149486940','0.071548911951545','767.3628480431639','767.362848043163922','test'),('2019-08-12 03:59:59','2019-08-12 07:59:59','SNTETH','4h','0.000093710000000','0.000094130000000','0.072178149486940','0.072501645621659','770.228892188027','770.228892188026975','test'),('2019-08-14 07:59:59','2019-08-14 11:59:59','SNTETH','4h','0.000094200000000','0.000093140000000','0.072178149486940','0.071365953749614','766.2223937042463','766.222393704246315','test'),('2019-08-14 19:59:59','2019-08-16 19:59:59','SNTETH','4h','0.000097600000000','0.000094390000000','0.072178149486940','0.069804257480249','739.5302201530737','739.530220153073742','test'),('2019-08-21 15:59:59','2019-08-26 03:59:59','SNTETH','4h','0.000094840000000','0.000095410000000','0.072178149486940','0.072611948993557','761.0517659947279','761.051765994727930','test'),('2019-08-27 19:59:59','2019-08-28 07:59:59','SNTETH','4h','0.000097860000000','0.000095530000000','0.072178149486940','0.070459622118203','737.5653943075822','737.565394307582210','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','SNTETH','4h','0.000075550000000','0.000073000000000','0.072178149486940','0.069741957810015','955.3692850686963','955.369285068696286','test'),('2019-10-05 07:59:59','2019-10-06 07:59:59','SNTETH','4h','0.000072600000000','0.000073590000000','0.072178149486940','0.073162396979944','994.1893868724518','994.189386872451792','test'),('2019-10-17 07:59:59','2019-10-18 07:59:59','SNTETH','4h','0.000072980000000','0.000071870000000','0.072178149486940','0.071080345349772','989.0127361871746','989.012736187174596','test'),('2019-10-22 15:59:59','2019-10-22 23:59:59','SNTETH','4h','0.000071480000000','0.000071180000000','0.072178149486940','0.071875219368780','1009.7670605335758','1009.767060533575773','test'),('2019-10-24 03:59:59','2019-10-25 11:59:59','SNTETH','4h','0.000071850000000','0.000070930000000','0.072178149486940','0.071253947712020','1004.5671466519137','1004.567146651913731','test'),('2019-10-28 03:59:59','2019-10-28 07:59:59','SNTETH','4h','0.000071580000000','0.000070150000000','0.072178149486940','0.070736199867405','1008.3563772972897','1008.356377297289669','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','SNTETH','4h','0.000070850000000','0.000071270000000','0.072178149486940','0.072606022779594','1018.7459348897671','1018.745934889767113','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','SNTETH','4h','0.000071430000000','0.000069690000000','0.072178149486940','0.070419924929929','1010.4738833394932','1010.473883339493227','test'),('2019-10-31 11:59:59','2019-11-04 11:59:59','SNTETH','4h','0.000070590000000','0.000073650000000','0.072178149486940','0.075306994046085','1022.498221942768','1022.498221942768055','test'),('2019-11-04 23:59:59','2019-11-05 15:59:59','SNTETH','4h','0.000073000000000','0.000074370000000','0.072178149486940','0.073532725717037','988.7417737936986','988.741773793698599','test'),('2019-11-06 11:59:59','2019-11-06 15:59:59','SNTETH','4h','0.000073560000000','0.000072860000000','0.072178149486940','0.071491299233530','981.2146477289289','981.214647728928867','test'),('2019-11-16 07:59:59','2019-11-16 11:59:59','SNTETH','4h','0.000070400000000','0.000069620000000','0.072178149486940','0.071378448398874','1025.2578052122158','1025.257805212215771','test'),('2019-11-17 03:59:59','2019-11-17 11:59:59','SNTETH','4h','0.000070560000000','0.000069380000000','0.072178149486940','0.070971088596994','1022.9329575813491','1022.932957581349115','test'),('2019-11-21 19:59:59','2019-11-22 11:59:59','SNTETH','4h','0.000070200000000','0.000069970000000','0.072178149486940','0.071941668370387','1028.178767620228','1028.178767620227973','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','SNTETH','4h','0.000070130000000','0.000069740000000','0.072178149486940','0.071776759521164','1029.205040452588','1029.205040452588037','test'),('2019-11-23 11:59:59','2019-11-23 15:59:59','SNTETH','4h','0.000069920000000','0.000069490000000','0.072178149486940','0.071734262125965','1032.2961883143594','1032.296188314359370','test'),('2019-11-27 11:59:59','2019-12-02 11:59:59','SNTETH','4h','0.000070770000000','0.000072580000000','0.072178149486940','0.074024164049203','1019.8975482116716','1019.897548211671619','test'),('2019-12-06 23:59:59','2019-12-08 15:59:59','SNTETH','4h','0.000075370000000','0.000072780000000','0.072178149486940','0.069697833616286','957.6509153103356','957.650915310335563','test'),('2019-12-14 11:59:59','2019-12-14 15:59:59','SNTETH','4h','0.000071820000000','0.000071610000000','0.072178149486940','0.071967102266218','1004.9867653430799','1004.986765343079924','test'),('2019-12-15 11:59:59','2019-12-15 15:59:59','SNTETH','4h','0.000072010000000','0.000072010000000','0.072178149486940','0.072178149486940','1002.3350852234412','1002.335085223441183','test'),('2019-12-19 07:59:59','2019-12-19 11:59:59','SNTETH','4h','0.000072110000000','0.000072930000000','0.072178149486940','0.072998924449903','1000.9450767846346','1000.945076784634580','test'),('2019-12-23 19:59:59','2019-12-24 07:59:59','SNTETH','4h','0.000073160000000','0.000073070000000','0.072178149486940','0.072089357340223','986.5794079680153','986.579407968015289','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:58:36
