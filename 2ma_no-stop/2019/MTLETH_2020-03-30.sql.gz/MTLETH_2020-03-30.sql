-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 19:59:59','2019-01-13 19:59:59','MTLETH','4h','0.001817000000000','0.001862000000000','0.072144500000000','0.073931237754540','39.70528343423225','39.705283434232250','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','MTLETH','4h','0.001809000000000','0.001860000000000','0.072591184438635','0.074637702076208','40.12779681516583','40.127796815165830','test'),('2019-02-09 03:59:59','2019-02-09 11:59:59','MTLETH','4h','0.002475000000000','0.002444000000000','0.073102813848028','0.072187182644275','29.536490443647775','29.536490443647775','test'),('2019-02-11 11:59:59','2019-02-12 03:59:59','MTLETH','4h','0.002572000000000','0.002467000000000','0.073102813848028','0.070118445475539','28.422555928471226','28.422555928471226','test'),('2019-02-14 15:59:59','2019-02-15 03:59:59','MTLETH','4h','0.002472000000000','0.002419000000000','0.073102813848028','0.071535480055979','29.572335699040455','29.572335699040455','test'),('2019-02-15 23:59:59','2019-02-16 03:59:59','MTLETH','4h','0.002441000000000','0.002414000000000','0.073102813848028','0.072294220659213','29.947895882027037','29.947895882027037','test'),('2019-02-16 15:59:59','2019-02-16 19:59:59','MTLETH','4h','0.002432000000000','0.002435000000000','0.073102813848028','0.073192990016426','30.058722799353617','30.058722799353617','test'),('2019-02-20 15:59:59','2019-02-20 23:59:59','MTLETH','4h','0.002475000000000','0.002427000000000','0.073102813848028','0.071685062306733','29.536490443647672','29.536490443647672','test'),('2019-02-22 15:59:59','2019-02-22 19:59:59','MTLETH','4h','0.002457000000000','0.002460000000000','0.073102813848028','0.073192072472995','29.752874989022384','29.752874989022384','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','MTLETH','4h','0.002400000000000','0.002382000000000','0.073102813848028','0.072554542744168','30.459505770011667','30.459505770011667','test'),('2019-02-26 23:59:59','2019-02-27 07:59:59','MTLETH','4h','0.002382000000000','0.002358000000000','0.073102813848028','0.072366261567443','30.689678357694373','30.689678357694373','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','MTLETH','4h','0.002404000000000','0.002363000000000','0.073102813848028','0.071856052047791','30.408824396018304','30.408824396018304','test'),('2019-03-04 23:59:59','2019-03-05 15:59:59','MTLETH','4h','0.002413000000000','0.002349000000000','0.073102813848028','0.071163907886041','30.29540565604144','30.295405656041439','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','MTLETH','4h','0.002322000000000','0.002287000000000','0.073102813848028','0.072000919582446','31.48269330233764','31.482693302337641','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','MTLETH','4h','0.002322000000000','0.002325000000000','0.073102813848028','0.073197261927935','31.48269330233764','31.482693302337641','test'),('2019-03-08 15:59:59','2019-03-10 11:59:59','MTLETH','4h','0.002363000000000','0.002354000000000','0.073102813848028','0.072824385864688','30.93644259332543','30.936442593325431','test'),('2019-03-26 19:59:59','2019-03-26 23:59:59','MTLETH','4h','0.002616000000000','0.002614000000000','0.073102813848028','0.073046924846615','27.944500706432724','27.944500706432724','test'),('2019-03-27 11:59:59','2019-03-28 07:59:59','MTLETH','4h','0.002648000000000','0.002626000000000','0.073102813848028','0.072495464186149','27.606802812699392','27.606802812699392','test'),('2019-04-15 03:59:59','2019-04-18 07:59:59','MTLETH','4h','0.003369000000000','0.003115000000000','0.073102813848028','0.067591352073793','21.69866840250163','21.698668402501632','test'),('2019-04-20 23:59:59','2019-04-21 03:59:59','MTLETH','4h','0.003100000000000','0.003047000000000','0.073102813848028','0.071852991546755','23.58155285420258','23.581552854202581','test'),('2019-04-25 15:59:59','2019-04-25 23:59:59','MTLETH','4h','0.003039000000000','0.003107000000000','0.073102813848028','0.074738546438244','24.05489103258572','24.054891032585719','test'),('2019-05-02 19:59:59','2019-05-02 23:59:59','MTLETH','4h','0.003005000000000','0.002950000000000','0.073102813848028','0.071764825574603','24.327059516814643','24.327059516814643','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','MTLETH','4h','0.001980000000000','0.001918000000000','0.073102813848028','0.070813735838645','36.920613054559595','36.920613054559595','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','MTLETH','4h','0.001961000000000','0.001948000000000','0.073102813848028','0.072618195500234','37.27833444570525','37.278334445705248','test'),('2019-06-02 15:59:59','2019-06-03 07:59:59','MTLETH','4h','0.001865000000000','0.001833000000000','0.073102813848028','0.071848502832941','39.19721922146274','39.197219221462738','test'),('2019-06-17 03:59:59','2019-06-17 07:59:59','MTLETH','4h','0.002137000000000','0.002190000000000','0.073102813848028','0.074915845731016','34.20814873562377','34.208148735623773','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','MTLETH','4h','0.001919000000000','0.001836000000000','0.073102813848028','0.069940993342876','38.09422295363627','38.094222953636269','test'),('2019-07-02 07:59:59','2019-07-02 15:59:59','MTLETH','4h','0.001950000000000','0.001923000000000','0.073102813848028','0.072090621040901','37.488622486168204','37.488622486168204','test'),('2019-07-04 15:59:59','2019-07-08 19:59:59','MTLETH','4h','0.001939000000000','0.001991000000000','0.073102813848028','0.075063281264272','37.70129646623414','37.701296466234140','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','MTLETH','4h','0.002001000000000','0.001988000000000','0.073102813848028','0.072627883023428','36.53314035383708','36.533140353837076','test'),('2019-07-10 07:59:59','2019-07-10 11:59:59','MTLETH','4h','0.002015000000000','0.001972000000000','0.073102813848028','0.071542803428442','36.27931208338859','36.279312083388589','test'),('2019-07-20 07:59:59','2019-07-20 15:59:59','MTLETH','4h','0.001759000000000','0.001720000000000','0.073102813848028','0.071482001033888','41.5593029266788','41.559302926678797','test'),('2019-07-21 15:59:59','2019-07-24 07:59:59','MTLETH','4h','0.001820000000000','0.001798000000000','0.073102813848028','0.072219153460854','40.16638123518022','40.166381235180218','test'),('2019-07-25 15:59:59','2019-07-27 03:59:59','MTLETH','4h','0.001814000000000','0.001826000000000','0.073102813848028','0.073586404678335','40.299235858890846','40.299235858890846','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','MTLETH','4h','0.001836000000000','0.001790000000000','0.073102813848028','0.071271261867086','39.81634741177996','39.816347411779958','test'),('2019-07-29 11:59:59','2019-07-30 11:59:59','MTLETH','4h','0.001835000000000','0.001817000000000','0.073102813848028','0.072385729025541','39.83804569374823','39.838045693748228','test'),('2019-08-14 15:59:59','2019-08-15 01:59:59','MTLETH','4h','0.001538000000000','0.001442000000000','0.073102813848028','0.068539829368567','47.53108832771651','47.531088327716510','test'),('2019-08-15 11:59:59','2019-08-15 15:59:59','MTLETH','4h','0.001473000000000','0.001486000000000','0.073102813848028','0.073747984642342','49.62852263953021','49.628522639530210','test'),('2019-08-17 19:59:59','2019-08-19 11:59:59','MTLETH','4h','0.001600000000000','0.001518000000000','0.073102813848028','0.069356294638317','45.6892586550175','45.689258655017497','test'),('2019-09-02 23:59:59','2019-09-03 03:59:59','MTLETH','4h','0.002211000000000','0.002155000000000','0.073102813848028','0.071251272656038','33.063235571247404','33.063235571247404','test'),('2019-09-03 11:59:59','2019-09-04 03:59:59','MTLETH','4h','0.002302000000000','0.002246000000000','0.073102813848028','0.071324465639735','31.756218005225023','31.756218005225023','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','MTLETH','4h','0.002293000000000','0.002255000000000','0.073102813848028','0.071891341137071','31.880860814665503','31.880860814665503','test'),('2019-09-26 15:59:59','2019-09-26 19:59:59','MTLETH','4h','0.001571000000000','0.001583000000000','0.073102813848028','0.073661205806129','46.532663175065565','46.532663175065565','test'),('2019-10-08 19:59:59','2019-10-08 23:59:59','MTLETH','4h','0.002181000000000','0.002136000000000','0.073102813848028','0.071594502695730','33.51802560661531','33.518025606615311','test'),('2019-10-24 23:59:59','2019-10-25 03:59:59','MTLETH','4h','0.001835000000000','0.001760000000000','0.073102813848028','0.070114960420997','39.83804569374823','39.838045693748228','test'),('2019-10-25 07:59:59','2019-10-25 19:59:59','MTLETH','4h','0.001846000000000','0.001759000000000','0.073102813848028','0.069657556640672','39.60065755581148','39.600657555811480','test'),('2019-10-28 15:59:59','2019-10-29 23:59:59','MTLETH','4h','0.001961000000000','0.001796000000000','0.073102813848028','0.066951888664487','37.27833444570525','37.278334445705248','test'),('2019-11-06 11:59:59','2019-11-06 15:59:59','MTLETH','4h','0.001999000000000','0.002007000000000','0.073102813848028','0.073395371382187','36.56969176989895','36.569691769898952','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','MTLETH','4h','0.001944000000000','0.001925000000000','0.073102813848028','0.072388331613917','37.60432811112551','37.604328111125511','test'),('2019-11-18 07:59:59','2019-11-18 11:59:59','MTLETH','4h','0.001932000000000','0.001919000000000','0.073102813848028','0.072610921208264','37.83789536647412','37.837895366474122','test'),('2019-11-22 03:59:59','2019-11-22 11:59:59','MTLETH','4h','0.001939000000000','0.001877000000000','0.073102813848028','0.070765333467121','37.70129646623414','37.701296466234140','test'),('2019-11-22 15:59:59','2019-11-22 23:59:59','MTLETH','4h','0.001933000000000','0.001955000000000','0.073102813848028','0.073934816902687','37.81832066633626','37.818320666336263','test'),('2019-11-26 11:59:59','2019-12-01 03:59:59','MTLETH','4h','0.002009000000000','0.001989000000000','0.073102813848028','0.072375060599168','36.38766244302041','36.387662443020410','test'),('2019-12-03 07:59:59','2019-12-03 11:59:59','MTLETH','4h','0.001989000000000','0.001998000000000','0.073102813848028','0.073433595811141','36.753551457027655','36.753551457027655','test'),('2019-12-08 23:59:59','2019-12-09 23:59:59','MTLETH','4h','0.002064000000000','0.002030000000000','0.073102813848028','0.071898600829214','35.41802996512985','35.418029965129847','test'),('2019-12-16 11:59:59','2019-12-16 23:59:59','MTLETH','4h','0.001989000000000','0.001911000000000','0.073102813848028','0.070236036834380','36.753551457027655','36.753551457027655','test'),('2019-12-17 07:59:59','2019-12-18 15:59:59','MTLETH','4h','0.001970000000000','0.001982000000000','0.073102813848028','0.073548110176036','37.108027334024364','37.108027334024364','test'),('2019-12-19 11:59:59','2019-12-19 15:59:59','MTLETH','4h','0.001994000000000','0.001950000000000','0.073102813848028','0.071489712639747','36.661391097305916','36.661391097305916','test'),('2019-12-19 23:59:59','2019-12-20 03:59:59','MTLETH','4h','0.001966000000000','0.001954000000000','0.073102813848028','0.072656611525456','37.18352688099085','37.183526880990847','test'),('2019-12-20 07:59:59','2019-12-20 23:59:59','MTLETH','4h','0.001966000000000','0.001977000000000','0.073102813848028','0.073511832643719','37.18352688099085','37.183526880990847','test'),('2019-12-27 11:59:59','2019-12-27 15:59:59','MTLETH','4h','0.001965000000000','0.001936000000000','0.073102813848028','0.072023942803960','37.20244979543409','37.202449795434092','test'),('2019-12-27 19:59:59','2019-12-27 23:59:59','MTLETH','4h','0.001964000000000','0.001922000000000','0.073102813848028','0.071539515384883','37.221391979647656','37.221391979647656','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:03:14
