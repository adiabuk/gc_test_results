-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 07:59:59','2019-01-06 11:59:59','APPCETH','4h','0.000330400000000','0.000331700000000','0.072144500000000','0.072428361531477','218.35502421307507','218.355024213075069','test'),('2019-01-07 11:59:59','2019-01-07 15:59:59','APPCETH','4h','0.000320200000000','0.000316700000000','0.072215465382869','0.071426102082307','225.53237158922315','225.532371589223146','test'),('2019-01-07 23:59:59','2019-01-08 03:59:59','APPCETH','4h','0.000317600000000','0.000310200000000','0.072215465382869','0.070532863229742','227.3786693415271','227.378669341527086','test'),('2019-01-09 11:59:59','2019-01-09 15:59:59','APPCETH','4h','0.000317700000000','0.000310000000000','0.072215465382869','0.070465200719828','227.3070990962197','227.307099096219702','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','APPCETH','4h','0.000318700000000','0.000314900000000','0.072215465382869','0.071354408688627','226.59386690577034','226.593866905770341','test'),('2019-02-01 15:59:59','2019-02-01 23:59:59','APPCETH','4h','0.000401000000000','0.000390600000000','0.072215465382869','0.070342545582416','180.08844235129428','180.088442351294276','test'),('2019-02-11 15:59:59','2019-02-18 03:59:59','APPCETH','4h','0.000407400000000','0.000457400000000','0.072215465382869','0.081078433642917','177.25936520095485','177.259365200954846','test'),('2019-02-26 15:59:59','2019-02-27 19:59:59','APPCETH','4h','0.000433500000000','0.000418900000000','0.072692155795025','0.070243930940106','167.6866338985582','167.686633898558199','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','APPCETH','4h','0.000408000000000','0.000409800000000','0.072692155795025','0.073012856482356','178.16704851721815','178.167048517218149','test'),('2019-03-12 11:59:59','2019-03-13 11:59:59','APPCETH','4h','0.000567600000000','0.000557900000000','0.072692155795025','0.071449883224180','128.06933720053735','128.069337200537348','test'),('2019-03-13 19:59:59','2019-03-13 23:59:59','APPCETH','4h','0.000556000000000','0.000558300000000','0.072692155795025','0.072992860756048','130.7412874011241','130.741287401124112','test'),('2019-03-18 15:59:59','2019-03-20 03:59:59','APPCETH','4h','0.000583800000000','0.000556000000000','0.072692155795025','0.069230624566690','124.51551181059438','124.515511810594376','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','APPCETH','4h','0.000598900000000','0.000558800000000','0.072692155795025','0.067824973548606','121.37611587080481','121.376115870804810','test'),('2019-04-27 19:59:59','2019-04-27 23:59:59','APPCETH','4h','0.000441000000000','0.000424000000000','0.072692155795025','0.069889963848278','164.8348203968821','164.834820396882094','test'),('2019-04-28 11:59:59','2019-04-28 15:59:59','APPCETH','4h','0.000433600000000','0.000427000000000','0.072692155795025','0.071585679253865','167.64796078188422','167.647960781884223','test'),('2019-05-06 11:59:59','2019-05-06 15:59:59','APPCETH','4h','0.000437300000000','0.000406800000000','0.072692155795025','0.067622156362717','166.2294895838669','166.229489583866894','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','APPCETH','4h','0.000333300000000','0.000323200000000','0.072692155795025','0.070489363195176','218.09827721279626','218.098277212796262','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','APPCETH','4h','0.000356700000000','0.000344400000000','0.072692155795025','0.070185529733128','203.79073673962714','203.790736739627135','test'),('2019-05-28 03:59:59','2019-05-28 07:59:59','APPCETH','4h','0.000365200000000','0.000361200000000','0.072692155795025','0.071895965698694','199.04752408276286','199.047524082762862','test'),('2019-05-29 07:59:59','2019-05-30 03:59:59','APPCETH','4h','0.000358400000000','0.000349800000000','0.072692155795025','0.070947868574497','202.82409541022602','202.824095410226022','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','APPCETH','4h','0.000362100000000','0.000345400000000','0.072692155795025','0.069339604008842','200.75160396306268','200.751603963062678','test'),('2019-05-30 23:59:59','2019-05-31 03:59:59','APPCETH','4h','0.000359400000000','0.000355000000000','0.072692155795025','0.071802212874886','202.25975457714244','202.259754577142445','test'),('2019-05-31 07:59:59','2019-05-31 11:59:59','APPCETH','4h','0.000358000000000','0.000364400000000','0.072692155795025','0.073991680367897','203.05071451124303','203.050714511243029','test'),('2019-06-01 19:59:59','2019-06-03 23:59:59','APPCETH','4h','0.000367100000000','0.000366800000000','0.072692155795025','0.072632750600968','198.0173135249932','198.017313524993199','test'),('2019-06-04 11:59:59','2019-06-04 19:59:59','APPCETH','4h','0.000382100000000','0.000363700000000','0.072692155795025','0.069191669883932','190.24379951589896','190.243799515898957','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','APPCETH','4h','0.000370000000000','0.000365800000000','0.072692155795025','0.071867001594108','196.4652859325','196.465285932499995','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','APPCETH','4h','0.000366100000000','0.000358000000000','0.072692155795025','0.071083834402128','198.55819665398798','198.558196653987977','test'),('2019-06-07 07:59:59','2019-06-12 15:59:59','APPCETH','4h','0.000372900000000','0.000389800000000','0.072692155795025','0.075986597824888','194.9373982167471','194.937398216747113','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','APPCETH','4h','0.000384700000000','0.000383800000000','0.072692155795025','0.072522093564155','188.95803429951908','188.958034299519085','test'),('2019-06-19 15:59:59','2019-06-19 19:59:59','APPCETH','4h','0.000368500000000','0.000378600000000','0.072692155795025','0.074684532385336','197.26500894172318','197.265008941723181','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','APPCETH','4h','0.000292800000000','0.000279400000000','0.072692155795025','0.069365397298941','248.26555940923836','248.265559409238364','test'),('2019-07-22 15:59:59','2019-07-22 23:59:59','APPCETH','4h','0.000224700000000','0.000234500000000','0.072692155795025','0.075862530191070','323.5075914331331','323.507591433133086','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','APPCETH','4h','0.000236000000000','0.000220400000000','0.072692155795025','0.067887081089930','308.0176093009534','308.017609300953382','test'),('2019-08-12 11:59:59','2019-08-13 15:59:59','APPCETH','4h','0.000199300000000','0.000195200000000','0.072692155795025','0.071196732620115','364.7373597341947','364.737359734194683','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','APPCETH','4h','0.000197800000000','0.000188500000000','0.072692155795025','0.069274374961386','367.5033154450202','367.503315445020178','test'),('2019-08-21 15:59:59','2019-08-22 15:59:59','APPCETH','4h','0.000191500000000','0.000192900000000','0.072692155795025','0.073223586699010','379.59350284608354','379.593502846083538','test'),('2019-09-04 15:59:59','2019-09-04 23:59:59','APPCETH','4h','0.000210700000000','0.000210400000000','0.072692155795025','0.072588654861287','345.0031124585904','345.003112458590408','test'),('2019-09-07 19:59:59','2019-09-08 03:59:59','APPCETH','4h','0.000209300000000','0.000207400000000','0.072692155795025','0.072032265226413','347.31082558540373','347.310825585403734','test'),('2019-09-09 11:59:59','2019-09-09 15:59:59','APPCETH','4h','0.000208200000000','0.000207600000000','0.072692155795025','0.072482668314348','349.1458011288425','349.145801128842493','test'),('2019-09-13 07:59:59','2019-09-13 11:59:59','APPCETH','4h','0.000211700000000','0.000208400000000','0.072692155795025','0.071559023465674','343.373433136632','343.373433136632002','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','APPCETH','4h','0.000192600000000','0.000180300000000','0.072692155795025','0.068049821857960','377.42552333865524','377.425523338655239','test'),('2019-09-23 11:59:59','2019-09-23 15:59:59','APPCETH','4h','0.000194100000000','0.000190500000000','0.072692155795025','0.071343924157405','374.5087882278465','374.508788227846480','test'),('2019-09-27 15:59:59','2019-09-27 23:59:59','APPCETH','4h','0.000187600000000','0.000191500000000','0.072692155795025','0.074203346667096','387.4848389926706','387.484838992670575','test'),('2019-09-29 03:59:59','2019-09-29 15:59:59','APPCETH','4h','0.000188800000000','0.000185300000000','0.072692155795025','0.071344578754333','385.0220116261917','385.022011626191727','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','APPCETH','4h','0.000187500000000','0.000185000000000','0.072692155795025','0.071722927051091','387.6914975734667','387.691497573466677','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','APPCETH','4h','0.000187400000000','0.000180900000000','0.072692155795025','0.070170816346425','387.8983767077108','387.898376707710781','test'),('2019-10-01 11:59:59','2019-10-01 15:59:59','APPCETH','4h','0.000190500000000','0.000186900000000','0.072692155795025','0.071318445764253','381.5861196589239','381.586119658923906','test'),('2019-10-13 11:59:59','2019-10-13 15:59:59','APPCETH','4h','0.000197900000000','0.000187600000000','0.072692155795025','0.068908784371636','367.31761392129863','367.317613921298630','test'),('2019-10-15 11:59:59','2019-10-15 19:59:59','APPCETH','4h','0.000204300000000','0.000197900000000','0.072692155795025','0.070414966381965','355.8108457906265','355.810845790626502','test'),('2019-10-20 11:59:59','2019-10-25 15:59:59','APPCETH','4h','0.000192600000000','0.000207700000000','0.072692155795025','0.078391281197439','377.42552333865524','377.425523338655239','test'),('2019-10-26 19:59:59','2019-10-26 23:59:59','APPCETH','4h','0.000214300000000','0.000212000000000','0.072692155795025','0.071911978667967','339.20744654701355','339.207446547013546','test'),('2019-10-28 03:59:59','2019-10-28 07:59:59','APPCETH','4h','0.000212600000000','0.000212300000000','0.072692155795025','0.072589579846114','341.91982970378643','341.919829703786434','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','APPCETH','4h','0.000213200000000','0.000208500000000','0.072692155795025','0.071089655174778','340.9575787759146','340.957578775914612','test'),('2019-10-31 07:59:59','2019-10-31 11:59:59','APPCETH','4h','0.000212800000000','0.000206000000000','0.072692155795025','0.070369286154958','341.5984764803806','341.598476480380612','test'),('2019-11-01 15:59:59','2019-11-01 23:59:59','APPCETH','4h','0.000213200000000','0.000214300000000','0.072692155795025','0.073067209131679','340.9575787759146','340.957578775914612','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','APPCETH','4h','0.000211900000000','0.000207600000000','0.072692155795025','0.071217043619855','343.04934306288345','343.049343062883452','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','APPCETH','4h','0.000214400000000','0.000208400000000','0.072692155795025','0.070657860390313','339.04923411858675','339.049234118586753','test'),('2019-11-16 19:59:59','2019-11-16 23:59:59','APPCETH','4h','0.000199400000000','0.000200700000000','0.072692155795025','0.073166076570018','364.5544423020311','364.554442302031077','test'),('2019-11-26 11:59:59','2019-11-27 11:59:59','APPCETH','4h','0.000195800000000','0.000195700000000','0.072692155795025','0.072655030077050','371.2571797498723','371.257179749872307','test'),('2019-12-06 19:59:59','2019-12-10 03:59:59','APPCETH','4h','0.000200000000000','0.000190800000000','0.072692155795025','0.069348316628454','363.460778975125','363.460778975124981','test'),('2019-12-16 19:59:59','2019-12-16 23:59:59','APPCETH','4h','0.000191900000000','0.000191900000000','0.072692155795025','0.072692155795025','378.8022709485409','378.802270948540922','test'),('2019-12-19 07:59:59','2019-12-19 15:59:59','APPCETH','4h','0.000191000000000','0.000194000000000','0.072692155795025','0.073833917404371','380.58720311531414','380.587203115314139','test'),('2019-12-23 23:59:59','2019-12-24 07:59:59','APPCETH','4h','0.000193000000000','0.000192400000000','0.072692155795025','0.072466169818460','376.6432942747409','376.643294274740924','test'),('2019-12-27 03:59:59','2019-12-27 07:59:59','APPCETH','4h','0.000191000000000','0.000193800000000','0.072692155795025','0.073757799963748','380.58720311531414','380.587203115314139','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','APPCETH','4h','0.000206300000000','0.000191300000000','0.072692155795025','0.067406734869551','352.3613950316287','352.361395031628717','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:28:02
