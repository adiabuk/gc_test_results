-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 19:59:59','SNMETH','4h','0.000155320000000','0.000149750000000','0.072144500000000','0.069557293812774','464.4894411537471','464.489441153747123','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','SNMETH','4h','0.000154170000000','0.000158610000000','0.072144500000000','0.074222216676396','467.9542063955374','467.954206395537426','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','SNMETH','4h','0.000161090000000','0.000158190000000','0.072144500000000','0.070845728816190','447.8521323483767','447.852132348376699','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','SNMETH','4h','0.000179940000000','0.000181660000000','0.072144500000000','0.072834110647994','400.9364232521952','400.936423252195198','test'),('2019-01-31 15:59:59','2019-01-31 19:59:59','SNMETH','4h','0.000183000000000','0.000178600000000','0.072144500000000','0.070409878142077','394.23224043715845','394.232240437158453','test'),('2019-02-26 19:59:59','2019-02-27 03:59:59','SNMETH','4h','0.000146330000000','0.000144150000000','0.072144500000000','0.071069703239254','493.0260370395681','493.026037039568109','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','SNMETH','4h','0.000147430000000','0.000144130000000','0.072144500000000','0.070529653293088','489.34748694295604','489.347486942956039','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','SNMETH','4h','0.000145150000000','0.000143300000000','0.072144500000000','0.071224986910093','497.0341026524285','497.034102652428487','test'),('2019-03-06 19:59:59','2019-03-07 03:59:59','SNMETH','4h','0.000151670000000','0.000150260000000','0.072144500000000','0.071473808729478','475.66756774576385','475.667567745763847','test'),('2019-03-07 07:59:59','2019-03-07 11:59:59','SNMETH','4h','0.000150850000000','0.000150050000000','0.072144500000000','0.071761897414650','478.2532316871064','478.253231687106393','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','SNMETH','4h','0.000150800000000','0.000149660000000','0.072144500000000','0.071599110543767','478.41180371352783','478.411803713527831','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','SNMETH','4h','0.000151180000000','0.000152710000000','0.072144500000000','0.072874630209022','477.2092869427173','477.209286942717313','test'),('2019-03-26 03:59:59','2019-03-26 15:59:59','SNMETH','4h','0.000177370000000','0.000180800000000','0.072144500000000','0.073539638044765','406.74578564582515','406.745785645825151','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','SNMETH','4h','0.000194450000000','0.000186180000000','0.072144500000000','0.069076179017742','371.0182566212394','371.018256621239402','test'),('2019-04-04 07:59:59','2019-04-05 07:59:59','SNMETH','4h','0.000207930000000','0.000200090000000','0.072144500000000','0.069424291853027','346.9653248689463','346.965324868946311','test'),('2019-04-19 19:59:59','2019-04-20 03:59:59','SNMETH','4h','0.000180150000000','0.000177490000000','0.072144500000000','0.071079252317513','400.46905356647244','400.469053566472439','test'),('2019-05-03 03:59:59','2019-05-03 07:59:59','SNMETH','4h','0.000160430000000','0.000153800000000','0.072144500000000','0.069163024995325','449.69457084086514','449.694570840865140','test'),('2019-05-12 11:59:59','2019-05-12 15:59:59','SNMETH','4h','0.000144400000000','0.000140630000000','0.072144500000000','0.070260948995845','499.61565096952904','499.615650969529042','test'),('2019-05-13 03:59:59','2019-05-13 07:59:59','SNMETH','4h','0.000143070000000','0.000143050000000','0.072144500000000','0.072134414796953','504.2601523729643','504.260152372964285','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','SNMETH','4h','0.000118990000000','0.000116680000000','0.072144500000000','0.070743930246239','606.3072527103118','606.307252710311786','test'),('2019-05-23 11:59:59','2019-05-23 15:59:59','SNMETH','4h','0.000122440000000','0.000116490000000','0.072144500000000','0.068638621406403','589.2232930414897','589.223293041489683','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','SNMETH','4h','0.000117040000000','0.000114130000000','0.072144500000000','0.070350750042720','616.4089200273411','616.408920027341082','test'),('2019-06-02 03:59:59','2019-06-02 07:59:59','SNMETH','4h','0.000107000000000','0.000103900000000','0.072144500000000','0.070054332242991','674.2476635514018','674.247663551401843','test'),('2019-06-02 11:59:59','2019-06-04 19:59:59','SNMETH','4h','0.000107440000000','0.000108650000000','0.072144500000000','0.072956998557334','671.4864110201042','671.486411020104242','test'),('2019-06-05 23:59:59','2019-06-06 15:59:59','SNMETH','4h','0.000114640000000','0.000110000000000','0.072144500000000','0.069224485345429','629.3135031402652','629.313503140265198','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','SNMETH','4h','0.000110220000000','0.000110610000000','0.072144500000000','0.072399774496462','654.5499909272364','654.549990927236422','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','SNMETH','4h','0.000113490000000','0.000107760000000','0.072144500000000','0.068501994184510','635.6903691955239','635.690369195523886','test'),('2019-06-16 19:59:59','2019-06-16 23:59:59','SNMETH','4h','0.000110960000000','0.000108600000000','0.072144500000000','0.070610063987022','650.184751261716','650.184751261715974','test'),('2019-06-17 03:59:59','2019-06-17 07:59:59','SNMETH','4h','0.000113120000000','0.000109750000000','0.072144500000000','0.069995216363154','637.7696251768034','637.769625176803402','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','SNMETH','4h','0.000109320000000','0.000104950000000','0.072144500000000','0.069260567828394','659.9387120380534','659.938712038053382','test'),('2019-07-04 15:59:59','2019-07-04 23:59:59','SNMETH','4h','0.000076660000000','0.000072840000000','0.072144500000000','0.068549509261675','941.097051917558','941.097051917558019','test'),('2019-07-05 19:59:59','2019-07-05 23:59:59','SNMETH','4h','0.000074560000000','0.000072110000000','0.072144500000000','0.069773871982296','967.6032725321888','967.603272532188839','test'),('2019-07-07 19:59:59','2019-07-07 23:59:59','SNMETH','4h','0.000071900000000','0.000069300000000','0.072144500000000','0.069535658553547','1003.4005563282336','1003.400556328233620','test'),('2019-07-22 07:59:59','2019-07-22 15:59:59','SNMETH','4h','0.000062510000000','0.000063700000000','0.072144500000000','0.073517911534155','1154.12733962566','1154.127339625659943','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','SNMETH','4h','0.000063100000000','0.000063480000000','0.072144500000000','0.072578967670364','1143.335974643423','1143.335974643423015','test'),('2019-07-28 03:59:59','2019-07-28 07:59:59','SNMETH','4h','0.000063590000000','0.000061150000000','0.072144500000000','0.069376256880013','1134.525868847303','1134.525868847302945','test'),('2019-07-30 11:59:59','2019-07-30 15:59:59','SNMETH','4h','0.000062840000000','0.000061370000000','0.072144500000000','0.070456842218332','1148.0665181413112','1148.066518141311235','test'),('2019-08-06 15:59:59','2019-08-06 19:59:59','SNMETH','4h','0.000060280000000','0.000057920000000','0.072144500000000','0.069319997345720','1196.8231585932317','1196.823158593231710','test'),('2019-08-07 11:59:59','2019-08-07 15:59:59','SNMETH','4h','0.000058330000000','0.000058450000000','0.072144500000000','0.072292920024001','1236.8335333447626','1236.833533344762600','test'),('2019-08-13 15:59:59','2019-08-13 19:59:59','SNMETH','4h','0.000057940000000','0.000054280000000','0.072144500000000','0.067587218847083','1245.1587849499483','1245.158784949948313','test'),('2019-08-22 11:59:59','2019-09-01 15:59:59','SNMETH','4h','0.000054130000000','0.000057170000000','0.072144500000000','0.076196214021799','1332.800665065583','1332.800665065582962','test'),('2019-09-02 03:59:59','2019-09-02 11:59:59','SNMETH','4h','0.000057740000000','0.000058900000000','0.072144500000000','0.073593887253204','1249.471770003464','1249.471770003463917','test'),('2019-09-04 19:59:59','2019-09-04 23:59:59','SNMETH','4h','0.000057090000000','0.000056900000000','0.072144500000000','0.071904397442634','1263.6976703450694','1263.697670345069355','test'),('2019-09-06 23:59:59','2019-09-07 03:59:59','SNMETH','4h','0.000056610000000','0.000056620000000','0.072144500000000','0.072157244126479','1274.4126479420597','1274.412647942059721','test'),('2019-09-07 15:59:59','2019-09-07 19:59:59','SNMETH','4h','0.000057500000000','0.000054280000000','0.072144500000000','0.068104408000000','1254.6869565217391','1254.686956521739148','test'),('2019-09-08 19:59:59','2019-09-08 23:59:59','SNMETH','4h','0.000056000000000','0.000056060000000','0.072144500000000','0.072221797678571','1288.294642857143','1288.294642857142890','test'),('2019-09-09 23:59:59','2019-09-10 11:59:59','SNMETH','4h','0.000056310000000','0.000053940000000','0.072144500000000','0.069108050612680','1281.2022731308825','1281.202273130882531','test'),('2019-09-11 15:59:59','2019-09-12 03:59:59','SNMETH','4h','0.000058130000000','0.000053350000000','0.072144500000000','0.066212094873559','1241.0889385859282','1241.088938585928190','test'),('2019-09-20 15:59:59','2019-09-20 19:59:59','SNMETH','4h','0.000046690000000','0.000046840000000','0.072144500000000','0.072376277147141','1545.1809809381023','1545.180980938102266','test'),('2019-09-30 15:59:59','2019-09-30 23:59:59','SNMETH','4h','0.000071270000000','0.000070190000000','0.072144500000000','0.071051248140873','1012.2702399326505','1012.270239932650497','test'),('2019-10-02 11:59:59','2019-10-02 19:59:59','SNMETH','4h','0.000072350000000','0.000069100000000','0.072144500000000','0.068903731167934','997.1596406357983','997.159640635798269','test'),('2019-10-02 23:59:59','2019-10-05 03:59:59','SNMETH','4h','0.000070240000000','0.000072290000000','0.072144500000000','0.074250084068907','1027.1141799544419','1027.114179954441852','test'),('2019-10-14 19:59:59','2019-10-14 23:59:59','SNMETH','4h','0.000066980000000','0.000067360000000','0.072144500000000','0.072553799940281','1077.1051060017917','1077.105106001791683','test'),('2019-10-17 03:59:59','2019-10-17 07:59:59','SNMETH','4h','0.000067830000000','0.000066350000000','0.072144500000000','0.070570360828542','1063.6075482824708','1063.607548282470816','test'),('2019-10-17 23:59:59','2019-10-18 03:59:59','SNMETH','4h','0.000067280000000','0.000066840000000','0.072144500000000','0.071672686979786','1072.302318668252','1072.302318668251928','test'),('2019-10-20 07:59:59','2019-10-20 11:59:59','SNMETH','4h','0.000067530000000','0.000066680000000','0.072144500000000','0.071236417296017','1068.3325929216644','1068.332592921664400','test'),('2019-10-20 23:59:59','2019-10-21 03:59:59','SNMETH','4h','0.000067820000000','0.000067820000000','0.072144500000000','0.072144500000000','1063.7643762901798','1063.764376290179825','test'),('2019-10-24 15:59:59','2019-10-25 07:59:59','SNMETH','4h','0.000069140000000','0.000068780000000','0.072144500000000','0.071768856089095','1043.4553080705814','1043.455308070581395','test'),('2019-10-28 07:59:59','2019-10-28 11:59:59','SNMETH','4h','0.000070200000000','0.000067620000000','0.072144500000000','0.069493035470085','1027.6994301994303','1027.699430199430253','test'),('2019-10-30 15:59:59','2019-10-30 23:59:59','SNMETH','4h','0.000069160000000','0.000067790000000','0.048096333333333','0.047143586417968','695.435704646231','695.435704646230988','test'),('2019-11-11 11:59:59','2019-11-18 15:59:59','SNMETH','4h','0.000072460000000','0.000079090000000','0.053856375424005','0.058784166882205','743.2566301960358','743.256630196035758','test'),('2019-11-19 07:59:59','2019-11-19 11:59:59','SNMETH','4h','0.000080300000000','0.000081590000000','0.055088323288555','0.055973303824573','686.031423269673','686.031423269673041','test'),('2019-12-31 15:59:59','2020-01-01 15:59:59','SNMETH','4h','0.000093770000000','0.000101870000000','0.055309568422559','0.060087295885743','589.8428966893381','589.842896689338090','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:46:04
