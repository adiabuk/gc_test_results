-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 07:59:59','2019-01-09 11:59:59','QSPETH','4h','0.000110370000000','0.000109390000000','0.072144500000000','0.071503912793332','653.6604149678354','653.660414967835436','test'),('2019-01-11 03:59:59','2019-01-11 07:59:59','QSPETH','4h','0.000110230000000','0.000109520000000','0.072144500000000','0.071679811666515','654.4906105415948','654.490610541594833','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','QSPETH','4h','0.000136700000000','0.000132630000000','0.072144500000000','0.069996525493782','527.7578639356256','527.757863935625551','test'),('2019-02-02 03:59:59','2019-02-02 07:59:59','QSPETH','4h','0.000135640000000','0.000135730000000','0.072144500000000','0.072192369396933','531.8821881450899','531.882188145089913','test'),('2019-02-05 07:59:59','2019-02-05 11:59:59','QSPETH','4h','0.000133910000000','0.000132880000000','0.072144500000000','0.071589583750280','538.7536405048166','538.753640504816644','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','QSPETH','4h','0.000127450000000','0.000127400000000','0.072144500000000','0.072116196939976','566.0612004707729','566.061200470772860','test'),('2019-02-26 07:59:59','2019-03-21 15:59:59','QSPETH','4h','0.000113420000000','0.000150420000000','0.072144500000000','0.095679559954153','636.0827014635867','636.082701463586659','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','QSPETH','4h','0.000171910000000','0.000169920000000','0.077081114998743','0.076188837534678','448.3806352087881','448.380635208788078','test'),('2019-04-03 23:59:59','2019-04-06 19:59:59','QSPETH','4h','0.000171160000000','0.000176410000000','0.077081114998743','0.079445428236318','450.34537858578517','450.345378585785170','test'),('2019-04-13 15:59:59','2019-04-13 23:59:59','QSPETH','4h','0.000168460000000','0.000167630000000','0.077449123942120','0.077067533221047','459.74785671447376','459.747856714473755','test'),('2019-04-15 11:59:59','2019-04-16 11:59:59','QSPETH','4h','0.000177200000000','0.000167570000000','0.077449123942120','0.073240122454746','437.0718055424379','437.071805542437914','test'),('2019-04-16 19:59:59','2019-04-16 23:59:59','QSPETH','4h','0.000168260000000','0.000168200000000','0.077449123942120','0.077421506282328','460.2943298592655','460.294329859265474','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','QSPETH','4h','0.000168670000000','0.000167470000000','0.077449123942120','0.076898113396495','459.17545468737774','459.175454687377737','test'),('2019-05-22 15:59:59','2019-05-22 19:59:59','QSPETH','4h','0.000099930000000','0.000103520000000','0.077449123942120','0.080231495151489','775.0337630553388','775.033763055338795','test'),('2019-05-26 07:59:59','2019-05-26 19:59:59','QSPETH','4h','0.000107150000000','0.000099710000000','0.077449123942120','0.072071415289489','722.8103027729352','722.810302772935188','test'),('2019-05-28 15:59:59','2019-05-28 19:59:59','QSPETH','4h','0.000108690000000','0.000103660000000','0.077449123942120','0.073864901903028','712.5689938551844','712.568993855184431','test'),('2019-06-02 03:59:59','2019-06-02 07:59:59','QSPETH','4h','0.000103560000000','0.000098760000000','0.077449123942120','0.073859361534606','747.8671682321359','747.867168232135896','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','QSPETH','4h','0.000102710000000','0.000101620000000','0.077449123942120','0.076627202560590','754.0563133299581','754.056313329958130','test'),('2019-06-07 07:59:59','2019-06-12 15:59:59','QSPETH','4h','0.000103070000000','0.000103250000000','0.077449123942120','0.077584380004113','751.4225666257884','751.422566625788363','test'),('2019-06-19 23:59:59','2019-06-20 03:59:59','QSPETH','4h','0.000101800000000','0.000100600000000','0.077449123942120','0.076536167667753','760.7968953056975','760.796895305697490','test'),('2019-06-20 07:59:59','2019-06-20 11:59:59','QSPETH','4h','0.000102050000000','0.000101830000000','0.077449123942120','0.077282158657776','758.9331106528173','758.933110652817277','test'),('2019-07-07 19:59:59','2019-07-07 23:59:59','QSPETH','4h','0.000074420000000','0.000070600000000','0.077449123942120','0.073473638139125','1040.703089789304','1040.703089789303931','test'),('2019-07-08 03:59:59','2019-07-08 07:59:59','QSPETH','4h','0.000072870000000','0.000070700000000','0.077449123942120','0.075142761941922','1062.8396314274737','1062.839631427473705','test'),('2019-07-13 19:59:59','2019-07-14 07:59:59','QSPETH','4h','0.000073780000000','0.000069080000000','0.077449123942120','0.072515390104658','1049.73060371537','1049.730603715370080','test'),('2019-07-18 07:59:59','2019-07-18 11:59:59','QSPETH','4h','0.000069830000000','0.000068020000000','0.077449123942120','0.075441635551239','1109.1096082216811','1109.109608221681128','test'),('2019-07-18 23:59:59','2019-07-19 03:59:59','QSPETH','4h','0.000069400000000','0.000068150000000','0.077449123942120','0.076054146925871','1115.9816129988471','1115.981612998847140','test'),('2019-07-19 15:59:59','2019-07-20 03:59:59','QSPETH','4h','0.000070990000000','0.000068430000000','0.077449123942120','0.074656198779536','1090.9863916343147','1090.986391634314714','test'),('2019-08-15 11:59:59','2019-08-16 19:59:59','QSPETH','4h','0.000057430000000','0.000055030000000','0.077449123942120','0.074212524648004','1348.5830392150444','1348.583039215044437','test'),('2019-08-17 19:59:59','2019-08-17 23:59:59','QSPETH','4h','0.000057900000000','0.000055710000000','0.077449123942120','0.074519701119439','1337.6359920918826','1337.635992091882599','test'),('2019-08-21 19:59:59','2019-08-23 15:59:59','QSPETH','4h','0.000059160000000','0.000056800000000','0.077449123942120','0.074359537523875','1309.1467873921567','1309.146787392156739','test'),('2019-08-29 15:59:59','2019-09-01 23:59:59','QSPETH','4h','0.000062030000000','0.000064640000000','0.077449123942120','0.080707905394465','1248.5752690975335','1248.575269097533464','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','QSPETH','4h','0.000071450000000','0.000072120000000','0.077449123942120','0.078175378848225','1083.9625464257522','1083.962546425752180','test'),('2019-09-07 07:59:59','2019-09-07 11:59:59','QSPETH','4h','0.000065550000000','0.000065000000000','0.077449123942120','0.076799283848021','1181.5274438157132','1181.527443815713241','test'),('2019-09-11 15:59:59','2019-09-11 23:59:59','QSPETH','4h','0.000065090000000','0.000066250000000','0.077449123942120','0.078829381796980','1189.8774610864957','1189.877461086495714','test'),('2019-09-22 11:59:59','2019-09-23 23:59:59','QSPETH','4h','0.000060080000000','0.000059230000000','0.077449123942120','0.076353388999530','1289.0999324587217','1289.099932458721696','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','QSPETH','4h','0.000060950000000','0.000059110000000','0.077449123942120','0.075111037181603','1270.6993263678426','1270.699326367842559','test'),('2019-10-02 15:59:59','2019-10-09 15:59:59','QSPETH','4h','0.000059280000000','0.000060000000000','0.077449123942120','0.078389801560850','1306.4966926808368','1306.496692680836759','test'),('2019-10-11 19:59:59','2019-10-11 23:59:59','QSPETH','4h','0.000063050000000','0.000062760000000','0.077449123942120','0.077092894823274','1228.376271881364','1228.376271881363891','test'),('2019-10-14 23:59:59','2019-10-15 19:59:59','QSPETH','4h','0.000063930000000','0.000062790000000','0.077449123942120','0.076068050873232','1211.4676042878148','1211.467604287814765','test'),('2019-10-17 23:59:59','2019-10-18 03:59:59','QSPETH','4h','0.000062830000000','0.000063160000000','0.077449123942120','0.077855907499352','1232.6774461582045','1232.677446158204475','test'),('2019-10-18 15:59:59','2019-10-18 19:59:59','QSPETH','4h','0.000063090000000','0.000061130000000','0.077449123942120','0.075043032914595','1227.5974630229832','1227.597463022983220','test'),('2019-10-19 19:59:59','2019-10-20 15:59:59','QSPETH','4h','0.000063400000000','0.000065410000000','0.077449123942120','0.079904529921988','1221.595014859937','1221.595014859937010','test'),('2019-10-25 11:59:59','2019-10-25 15:59:59','QSPETH','4h','0.000064450000000','0.000064400000000','0.077449123942120','0.077389039284291','1201.6931565883633','1201.693156588363308','test'),('2019-10-28 15:59:59','2019-10-28 19:59:59','QSPETH','4h','0.000063320000000','0.000062340000000','0.077449123942120','0.076250448303092','1223.1384071718257','1223.138407171825747','test'),('2019-10-29 19:59:59','2019-10-29 23:59:59','QSPETH','4h','0.000063790000000','0.000063760000000','0.077449123942120','0.077412700149703','1214.1264138912056','1214.126413891205630','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','QSPETH','4h','0.000064130000000','0.000063380000000','0.077449123942120','0.076543356860308','1207.689442415718','1207.689442415718077','test'),('2019-11-12 15:59:59','2019-11-12 23:59:59','QSPETH','4h','0.000061500000000','0.000060660000000','0.077449123942120','0.076391282249252','1259.3353486523577','1259.335348652357652','test'),('2019-11-14 03:59:59','2019-11-14 07:59:59','QSPETH','4h','0.000061130000000','0.000060490000000','0.077449123942120','0.076638271016830','1266.9576957650906','1266.957695765090648','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','QSPETH','4h','0.000061000000000','0.000060110000000','0.077449123942120','0.076319128527227','1269.657769542951','1269.657769542950973','test'),('2019-11-16 03:59:59','2019-11-16 11:59:59','QSPETH','4h','0.000061130000000','0.000060810000000','0.077449123942120','0.077043697479475','1266.9576957650906','1266.957695765090648','test'),('2019-11-21 23:59:59','2019-11-22 03:59:59','QSPETH','4h','0.000064060000000','0.000064080000000','0.077449123942120','0.077473304124431','1209.009115549797','1209.009115549796888','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','QSPETH','4h','0.000062970000000','0.000062160000000','0.077449123942120','0.076452875087219','1229.9368579024933','1229.936857902493330','test'),('2019-11-24 19:59:59','2019-11-27 19:59:59','QSPETH','4h','0.000064240000000','0.000066810000000','0.077449123942120','0.080547571148397','1205.6214810417187','1205.621481041718653','test'),('2019-12-03 23:59:59','2019-12-04 03:59:59','QSPETH','4h','0.000067600000000','0.000067370000000','0.077449123942120','0.077185613609181','1145.697099735503','1145.697099735502889','test'),('2019-12-04 19:59:59','2019-12-04 23:59:59','QSPETH','4h','0.000067600000000','0.000067200000000','0.077449123942120','0.076990845102226','1145.697099735503','1145.697099735502889','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','QSPETH','4h','0.000068090000000','0.000068000000000','0.077449123942120','0.077346753239303','1137.4522535191659','1137.452253519165879','test'),('2019-12-06 15:59:59','2019-12-06 19:59:59','QSPETH','4h','0.000067840000000','0.000067950000000','0.077449123942120','0.077574704773984','1141.6439260336085','1141.643926033608523','test'),('2019-12-11 15:59:59','2019-12-11 23:59:59','QSPETH','4h','0.000068880000000','0.000069080000000','0.077449123942120','0.077674005254379','1124.406561296748','1124.406561296747896','test'),('2019-12-19 19:59:59','2019-12-19 23:59:59','QSPETH','4h','0.000073160000000','0.000073420000000','0.077449123942120','0.077724366864823','1058.6266257807545','1058.626625780754466','test'),('2019-12-20 19:59:59','2019-12-20 23:59:59','QSPETH','4h','0.000073560000000','0.000074740000000','0.077449123942120','0.078691510650273','1052.8700916547039','1052.870091654703856','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:43:38
