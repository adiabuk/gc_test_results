-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 03:59:59','2019-01-08 07:59:59','GTOETH','4h','0.000182300000000','0.000178840000000','0.072144500000000','0.070775218760285','395.74602303894676','395.746023038946760','test'),('2019-01-08 15:59:59','2019-01-08 19:59:59','GTOETH','4h','0.000182870000000','0.000179270000000','0.072144500000000','0.070724255017225','394.5124952151802','394.512495215180195','test'),('2019-01-09 07:59:59','2019-01-09 15:59:59','GTOETH','4h','0.000183940000000','0.000180840000000','0.072144500000000','0.070928625530064','392.21757094704793','392.217570947047932','test'),('2019-01-11 11:59:59','2019-01-12 03:59:59','GTOETH','4h','0.000188000000000','0.000182680000000','0.072144500000000','0.070102964148936','383.74734042553195','383.747340425531945','test'),('2019-01-15 03:59:59','2019-01-27 15:59:59','GTOETH','4h','0.000203220000000','0.000235270000000','0.072144500000000','0.083522470795197','355.00688908571993','355.006889085719934','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','GTOETH','4h','0.000237280000000','0.000230600000000','0.073477258562927','0.071408697844787','309.6647781647284','309.664778164728375','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','GTOETH','4h','0.000243200000000','0.000234280000000','0.073477258562927','0.070782286743925','302.12688553835113','302.126885538351132','test'),('2019-02-06 11:59:59','2019-02-06 15:59:59','GTOETH','4h','0.000239080000000','0.000223000000000','0.073477258562927','0.068535338211196','307.3333552071566','307.333355207156615','test'),('2019-02-08 03:59:59','2019-02-08 19:59:59','GTOETH','4h','0.000229500000000','0.000234440000000','0.073477258562927','0.075058860555523','320.16234667942047','320.162346679420466','test'),('2019-02-09 07:59:59','2019-02-10 07:59:59','GTOETH','4h','0.000233680000000','0.000228960000000','0.073477258562927','0.071993123590242','314.435375568842','314.435375568842005','test'),('2019-02-17 03:59:59','2019-02-17 11:59:59','GTOETH','4h','0.000228540000000','0.000221480000000','0.073477258562927','0.071207417635937','321.50721345465564','321.507213454655641','test'),('2019-02-17 19:59:59','2019-02-17 23:59:59','GTOETH','4h','0.000226150000000','0.000213240000000','0.073477258562927','0.069282735423208','324.90496821988506','324.904968219885063','test'),('2019-02-18 03:59:59','2019-02-18 15:59:59','GTOETH','4h','0.000240200000000','0.000220950000000','0.073477258562927','0.067588677266772','305.90032707296837','305.900327072968366','test'),('2019-02-26 03:59:59','2019-03-05 03:59:59','GTOETH','4h','0.000212470000000','0.000226280000000','0.073477258562927','0.078253090166231','345.8241566476538','345.824156647653808','test'),('2019-03-07 19:59:59','2019-03-08 07:59:59','GTOETH','4h','0.000223060000000','0.000223630000000','0.073477258562927','0.073665019871009','329.4058036533982','329.405803653398209','test'),('2019-03-17 03:59:59','2019-03-17 07:59:59','GTOETH','4h','0.000251290000000','0.000247840000000','0.073477258562927','0.072468477703991','292.4002489670381','292.400248967038124','test'),('2019-03-17 11:59:59','2019-03-18 03:59:59','GTOETH','4h','0.000256460000000','0.000254350000000','0.073477258562927','0.072872731480467','286.5057262845161','286.505726284516072','test'),('2019-03-24 11:59:59','2019-03-24 19:59:59','GTOETH','4h','0.000256530000000','0.000254550000000','0.073477258562927','0.072910132020399','286.4275467310919','286.427546731091923','test'),('2019-03-25 07:59:59','2019-03-25 11:59:59','GTOETH','4h','0.000268840000000','0.000259410000000','0.073477258562927','0.070899924281390','273.3122249774103','273.312224977410324','test'),('2019-03-28 15:59:59','2019-03-28 19:59:59','GTOETH','4h','0.000255590000000','0.000256920000000','0.073477258562927','0.073859608239709','287.48095998641185','287.480959986411847','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','GTOETH','4h','0.000257560000000','0.000253830000000','0.073477258562927','0.072413156317082','285.28210344357433','285.282103443574329','test'),('2019-04-14 15:59:59','2019-04-14 19:59:59','GTOETH','4h','0.000222180000000','0.000218480000000','0.073477258562927','0.072253629718374','330.71049852789184','330.710498527891843','test'),('2019-04-19 03:59:59','2019-04-20 11:59:59','GTOETH','4h','0.000228360000000','0.000221180000000','0.073477258562927','0.071167017205063','321.7606347999956','321.760634799995614','test'),('2019-04-22 23:59:59','2019-04-23 03:59:59','GTOETH','4h','0.000215640000000','0.000210050000000','0.073477258562927','0.071572519760447','340.7403940035569','340.740394003556901','test'),('2019-04-23 19:59:59','2019-04-24 03:59:59','GTOETH','4h','0.000220060000000','0.000219130000000','0.073477258562927','0.073166734840017','333.8964762470553','333.896476247055318','test'),('2019-05-21 03:59:59','2019-05-22 03:59:59','GTOETH','4h','0.000139170000000','0.000136650000000','0.073477258562927','0.072146780072027','527.9676551191133','527.967655119113260','test'),('2019-05-28 03:59:59','2019-05-30 03:59:59','GTOETH','4h','0.000144250000000','0.000133510000000','0.073477258562927','0.068006577405452','509.3744094483674','509.374409448367373','test'),('2019-06-07 19:59:59','2019-06-07 23:59:59','GTOETH','4h','0.000138140000000','0.000137100000000','0.073477258562927','0.072924078101761','531.9042895825032','531.904289582503225','test'),('2019-07-01 07:59:59','2019-07-02 07:59:59','GTOETH','4h','0.000103190000000','0.000091320000000','0.073477258562927','0.065025130845687','712.0579374253997','712.057937425399700','test'),('2019-07-08 15:59:59','2019-07-08 19:59:59','GTOETH','4h','0.000090400000000','0.000093940000000','0.073477258562927','0.076354575988953','812.8015327757412','812.801532775741180','test'),('2019-07-14 23:59:59','2019-07-15 03:59:59','GTOETH','4h','0.000084760000000','0.000080170000000','0.073477258562927','0.069498251757785','866.8860141921543','866.886014192154335','test'),('2019-07-19 15:59:59','2019-07-26 23:59:59','GTOETH','4h','0.000084430000000','0.000087990000000','0.073477258562927','0.076575435046215','870.2742930584744','870.274293058474427','test'),('2019-08-13 07:59:59','2019-08-13 11:59:59','GTOETH','4h','0.000071930000000','0.000070530000000','0.073477258562927','0.072047143701421','1021.5106153611429','1021.510615361142868','test'),('2019-08-14 15:59:59','2019-08-14 19:59:59','GTOETH','4h','0.000072320000000','0.000070990000000','0.073477258562927','0.072125976014687','1016.0019159696765','1016.001915969676475','test'),('2019-08-14 23:59:59','2019-08-15 01:59:59','GTOETH','4h','0.000071400000000','0.000069460000000','0.073477258562927','0.071480817643990','1029.0932571838516','1029.093257183851620','test'),('2019-08-22 11:59:59','2019-08-22 19:59:59','GTOETH','4h','0.000071440000000','0.000067090000000','0.073477258562927','0.069003209364317','1028.5170571518338','1028.517057151833797','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','GTOETH','4h','0.000068210000000','0.000069140000000','0.073477258562927','0.074479074285893','1077.2212074904999','1077.221207490499864','test'),('2019-08-23 23:59:59','2019-08-28 19:59:59','GTOETH','4h','0.000069210000000','0.000070430000000','0.073477258562927','0.074772479707946','1061.6566762451525','1061.656676245152539','test'),('2019-09-01 11:59:59','2019-09-01 15:59:59','GTOETH','4h','0.000072030000000','0.000072620000000','0.073477258562927','0.074079113103426','1020.0924415233513','1020.092441523351340','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','GTOETH','4h','0.000071140000000','0.000068860000000','0.073477258562927','0.071122350641596','1032.85435146088','1032.854351460880025','test'),('2019-09-03 07:59:59','2019-09-03 11:59:59','GTOETH','4h','0.000071850000000','0.000074420000000','0.073477258562927','0.076105463914447','1022.6479967004454','1022.647996700445447','test'),('2019-09-10 23:59:59','2019-09-11 07:59:59','GTOETH','4h','0.000071080000000','0.000071830000000','0.073477258562927','0.074252553215743','1033.726203755304','1033.726203755303914','test'),('2019-09-18 23:59:59','2019-09-19 11:59:59','GTOETH','4h','0.000070700000000','0.000067270000000','0.073477258562927','0.069912520276211','1039.2822993341867','1039.282299334186746','test'),('2019-09-20 15:59:59','2019-09-21 03:59:59','GTOETH','4h','0.000070620000000','0.000068700000000','0.073477258562927','0.071479576087130','1040.459622811201','1040.459622811200916','test'),('2019-09-22 15:59:59','2019-09-22 19:59:59','GTOETH','4h','0.000066650000000','0.000066660000000','0.073477258562927','0.073488282907798','1102.4344870656714','1102.434487065671419','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','GTOETH','4h','0.000068050000000','0.000064440000000','0.073477258562927','0.069579346683248','1079.7539832906245','1079.753983290624546','test'),('2019-09-27 07:59:59','2019-09-30 15:59:59','GTOETH','4h','0.000074500000000','0.000070600000000','0.073477258562927','0.069630798047552','986.2719270191544','986.271927019154418','test'),('2019-10-12 15:59:59','2019-10-12 19:59:59','GTOETH','4h','0.000075000000000','0.000074440000000','0.073477258562927','0.072928628365657','979.6967808390267','979.696780839026701','test'),('2019-10-19 15:59:59','2019-10-19 23:59:59','GTOETH','4h','0.000073530000000','0.000071500000000','0.073477258562927','0.071448714636873','999.2827221940297','999.282722194029702','test'),('2019-10-20 23:59:59','2019-10-21 03:59:59','GTOETH','4h','0.000072490000000','0.000072710000000','0.073477258562927','0.073700254795288','1013.619238004235','1013.619238004234944','test'),('2019-10-22 11:59:59','2019-10-23 07:59:59','GTOETH','4h','0.000073170000000','0.000073360000000','0.073477258562927','0.073668056418974','1004.1992423524258','1004.199242352425813','test'),('2019-10-28 03:59:59','2019-10-28 07:59:59','GTOETH','4h','0.000070840000000','0.000067540000000','0.073477258562927','0.070054404903163','1037.2283817465695','1037.228381746569539','test'),('2019-10-28 15:59:59','2019-10-28 19:59:59','GTOETH','4h','0.000070390000000','0.000070120000000','0.073477258562927','0.073195416542583','1043.8593346061516','1043.859334606151606','test'),('2019-10-31 15:59:59','2019-10-31 19:59:59','GTOETH','4h','0.000069550000000','0.000073380000000','0.073477258562927','0.077523526000684','1056.4666939313731','1056.466693931373129','test'),('2019-11-11 15:59:59','2019-11-12 07:59:59','GTOETH','4h','0.000072520000000','0.000073250000000','0.073477258562927','0.074216894508196','1013.1999250265719','1013.199925026571918','test'),('2019-11-17 03:59:59','2019-11-18 07:59:59','GTOETH','4h','0.000072160000000','0.000070970000000','0.073477258562927','0.072265535479641','1018.2546918365715','1018.254691836571510','test'),('2019-11-18 15:59:59','2019-11-18 19:59:59','GTOETH','4h','0.000071800000000','0.000070200000000','0.073477258562927','0.071839882327541','1023.360147115975','1023.360147115974996','test'),('2019-11-19 07:59:59','2019-11-19 11:59:59','GTOETH','4h','0.000071970000000','0.000071560000000','0.073477258562927','0.073058671985036','1020.9428729043628','1020.942872904362844','test'),('2019-11-25 19:59:59','2019-11-26 07:59:59','GTOETH','4h','0.000071070000000','0.000069890000000','0.073477258562927','0.072257290009328','1033.8716555920503','1033.871655592050274','test'),('2019-11-27 23:59:59','2019-11-28 03:59:59','GTOETH','4h','0.000070100000000','0.000069290000000','0.073477258562927','0.072628234605210','1048.1777255767047','1048.177725576704688','test'),('2019-11-28 07:59:59','2019-11-28 19:59:59','GTOETH','4h','0.000070160000000','0.000070760000000','0.073477258562927','0.074105627364776','1047.2813364157212','1047.281336415721171','test'),('2019-12-09 19:59:59','2019-12-09 23:59:59','GTOETH','4h','0.000072680000000','0.000071070000000','0.073477258562927','0.071849597771976','1010.9694353732389','1010.969435373238866','test'),('2019-12-19 11:59:59','2019-12-23 11:59:59','GTOETH','4h','0.000072180000000','0.000071500000000','0.073477258562927','0.072785037229832','1017.9725486689803','1017.972548668980266','test'),('2019-12-24 07:59:59','2019-12-24 11:59:59','GTOETH','4h','0.000071760000000','0.000070520000000','0.073477258562927','0.072207584641271','1023.930581980588','1023.930581980588045','test'),('2019-12-25 11:59:59','2019-12-25 15:59:59','GTOETH','4h','0.000071630000000','0.000070840000000','0.073477258562927','0.072666885335722','1025.7888951965238','1025.788895196523754','test'),('2019-12-26 03:59:59','2019-12-26 07:59:59','GTOETH','4h','0.000071440000000','0.000071440000000','0.073477258562927','0.073477258562927','1028.5170571518338','1028.517057151833797','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  8:56:25
