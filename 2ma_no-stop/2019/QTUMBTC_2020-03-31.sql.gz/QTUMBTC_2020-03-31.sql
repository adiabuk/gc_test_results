-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-02 23:59:59','QTUMBTC','4h','0.000600000000000','0.000597000000000','0.001467500000000','0.001460162500000','2.4458333333333337','2.445833333333334','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','QTUMBTC','4h','0.000595000000000','0.000578000000000','0.001467500000000','0.001425571428571','2.466386554621849','2.466386554621849','test'),('2019-01-09 07:59:59','2019-01-10 11:59:59','QTUMBTC','4h','0.000596000000000','0.000587000000000','0.001467500000000','0.001445339765101','2.4622483221476514','2.462248322147651','test'),('2019-01-12 19:59:59','2019-01-13 19:59:59','QTUMBTC','4h','0.000630000000000','0.000581000000000','0.001467500000000','0.001353361111111','2.3293650793650795','2.329365079365080','test'),('2019-01-14 03:59:59','2019-01-14 07:59:59','QTUMBTC','4h','0.000592000000000','0.000588000000000','0.001467500000000','0.001457584459459','2.4788851351351355','2.478885135135136','test'),('2019-01-14 15:59:59','2019-01-14 19:59:59','QTUMBTC','4h','0.000591000000000','0.000588000000000','0.001467500000000','0.001460050761421','2.4830795262267342','2.483079526226734','test'),('2019-01-26 19:59:59','2019-01-26 23:59:59','QTUMBTC','4h','0.000579000000000','0.000576000000000','0.001467500000000','0.001459896373057','2.5345423143350607','2.534542314335061','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','QTUMBTC','4h','0.000536000000000','0.000528000000000','0.001467500000000','0.001445597014925','2.737873134328358','2.737873134328358','test'),('2019-02-09 07:59:59','2019-02-09 11:59:59','QTUMBTC','4h','0.000534000000000','0.000532000000000','0.001467500000000','0.001462003745318','2.74812734082397','2.748127340823970','test'),('2019-02-12 19:59:59','2019-02-13 15:59:59','QTUMBTC','4h','0.000535000000000','0.000530000000000','0.001467500000000','0.001453785046729','2.7429906542056077','2.742990654205608','test'),('2019-02-16 03:59:59','2019-02-17 03:59:59','QTUMBTC','4h','0.000544000000000','0.000532000000000','0.001467500000000','0.001435128676471','2.697610294117647','2.697610294117647','test'),('2019-02-22 19:59:59','2019-02-22 23:59:59','QTUMBTC','4h','0.000536000000000','0.000536000000000','0.001467500000000','0.001467500000000','2.737873134328358','2.737873134328358','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','QTUMBTC','4h','0.000547000000000','0.000544000000000','0.001467500000000','0.001459451553931','2.6828153564899453','2.682815356489945','test'),('2019-02-27 07:59:59','2019-02-27 11:59:59','QTUMBTC','4h','0.000547000000000','0.000542000000000','0.001467500000000','0.001454085923218','2.6828153564899453','2.682815356489945','test'),('2019-03-01 03:59:59','2019-03-01 15:59:59','QTUMBTC','4h','0.000565000000000','0.000554000000000','0.001467500000000','0.001438929203540','2.597345132743363','2.597345132743363','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','QTUMBTC','4h','0.000547000000000','0.000543000000000','0.001467500000000','0.001456768738574','2.6828153564899453','2.682815356489945','test'),('2019-03-12 15:59:59','2019-03-14 03:59:59','QTUMBTC','4h','0.000551000000000','0.000548000000000','0.001467500000000','0.001459509981851','2.663339382940109','2.663339382940109','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','QTUMBTC','4h','0.000627000000000','0.000630000000000','0.001467500000000','0.001474521531100','2.3405103668261567','2.340510366826157','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','QTUMBTC','4h','0.000691000000000','0.000648000000000','0.001467500000000','0.001376179450072','2.1237337192474675','2.123733719247467','test'),('2019-04-05 07:59:59','2019-04-05 19:59:59','QTUMBTC','4h','0.000670000000000','0.000667000000000','0.001467500000000','0.001460929104478','2.1902985074626864','2.190298507462686','test'),('2019-04-07 07:59:59','2019-04-07 15:59:59','QTUMBTC','4h','0.000665000000000','0.000663000000000','0.001467500000000','0.001463086466165','2.206766917293233','2.206766917293233','test'),('2019-05-15 19:59:59','2019-05-16 15:59:59','QTUMBTC','4h','0.000387000000000','0.000413000000000','0.001467500000000','0.001566091731266','3.7919896640826876','3.791989664082688','test'),('2019-05-18 23:59:59','2019-05-19 03:59:59','QTUMBTC','4h','0.000389000000000','0.000378000000000','0.001467500000000','0.001426002570694','3.7724935732647813','3.772493573264781','test'),('2019-05-19 19:59:59','2019-05-19 23:59:59','QTUMBTC','4h','0.000396000000000','0.000385000000000','0.001467500000000','0.001426736111111','3.7058080808080813','3.705808080808081','test'),('2019-05-20 15:59:59','2019-05-20 23:59:59','QTUMBTC','4h','0.000399000000000','0.000391000000000','0.001467500000000','0.001438076441103','3.6779448621553885','3.677944862155389','test'),('2019-05-29 15:59:59','2019-05-30 23:59:59','QTUMBTC','4h','0.000383000000000','0.000377000000000','0.001467500000000','0.001444510443864','3.8315926892950394','3.831592689295039','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','QTUMBTC','4h','0.000391000000000','0.000386000000000','0.001467500000000','0.001448734015345','3.7531969309462916','3.753196930946292','test'),('2019-06-07 11:59:59','2019-06-07 15:59:59','QTUMBTC','4h','0.000389000000000','0.000396000000000','0.001467500000000','0.001493907455013','3.7724935732647813','3.772493573264781','test'),('2019-06-10 03:59:59','2019-06-12 19:59:59','QTUMBTC','4h','0.000390000000000','0.000395000000000','0.001467500000000','0.001486314102564','3.762820512820513','3.762820512820513','test'),('2019-06-15 03:59:59','2019-06-15 15:59:59','QTUMBTC','4h','0.000406000000000','0.000397000000000','0.001467500000000','0.001434969211823','3.6145320197044337','3.614532019704434','test'),('2019-06-16 11:59:59','2019-06-16 15:59:59','QTUMBTC','4h','0.000401000000000','0.000398000000000','0.001467500000000','0.001456521197007','3.6596009975062347','3.659600997506235','test'),('2019-06-19 03:59:59','2019-06-19 11:59:59','QTUMBTC','4h','0.000399000000000','0.000394000000000','0.001467500000000','0.001449110275689','3.6779448621553885','3.677944862155389','test'),('2019-06-24 23:59:59','2019-06-25 07:59:59','QTUMBTC','4h','0.000378000000000','0.000376000000000','0.001467500000000','0.001459735449735','3.882275132275132','3.882275132275132','test'),('2019-07-04 07:59:59','2019-07-04 15:59:59','QTUMBTC','4h','0.000433000000000','0.000436000000000','0.001467500000000','0.001477667436490','3.389145496535797','3.389145496535797','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','QTUMBTC','4h','0.000311000000000','0.000310000000000','0.001467500000000','0.001462781350482','4.718649517684887','4.718649517684887','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','QTUMBTC','4h','0.000310000000000','0.000306000000000','0.001467500000000','0.001448564516129','4.733870967741936','4.733870967741936','test'),('2019-08-18 03:59:59','2019-08-19 19:59:59','QTUMBTC','4h','0.000246000000000','0.000242000000000','0.001467500000000','0.001443638211382','5.965447154471544','5.965447154471544','test'),('2019-08-21 07:59:59','2019-08-21 11:59:59','QTUMBTC','4h','0.000245000000000','0.000245000000000','0.001467500000000','0.001467500000000','5.9897959183673475','5.989795918367347','test'),('2019-09-15 11:59:59','2019-09-15 15:59:59','QTUMBTC','4h','0.000202000000000','0.000199000000000','0.001467500000000','0.001445705445545','7.264851485148515','7.264851485148515','test'),('2019-09-16 03:59:59','2019-09-16 11:59:59','QTUMBTC','4h','0.000204000000000','0.000198000000000','0.001467500000000','0.001424338235294','7.193627450980393','7.193627450980393','test'),('2019-09-17 11:59:59','2019-09-22 19:59:59','QTUMBTC','4h','0.000201300000000','0.000206500000000','0.001467500000000','0.001505408594138','7.290114257327373','7.290114257327373','test'),('2019-09-28 19:59:59','2019-09-28 23:59:59','QTUMBTC','4h','0.000203500000000','0.000202000000000','0.001467500000000','0.001456683046683','7.211302211302211','7.211302211302211','test'),('2019-09-29 23:59:59','2019-09-30 03:59:59','QTUMBTC','4h','0.000202200000000','0.000201400000000','0.001467500000000','0.001461693867458','7.257665677546983','7.257665677546983','test'),('2019-09-30 07:59:59','2019-10-02 03:59:59','QTUMBTC','4h','0.000203200000000','0.000203400000000','0.001467500000000','0.001468944389764','7.221948818897638','7.221948818897638','test'),('2019-10-11 03:59:59','2019-10-11 07:59:59','QTUMBTC','4h','0.000212300000000','0.000211600000000','0.001467500000000','0.001462661328309','6.91238813000471','6.912388130004710','test'),('2019-10-17 15:59:59','2019-10-18 03:59:59','QTUMBTC','4h','0.000217200000000','0.000214200000000','0.001467500000000','0.001447230662983','6.756445672191529','6.756445672191529','test'),('2019-10-18 23:59:59','2019-10-19 03:59:59','QTUMBTC','4h','0.000213800000000','0.000213900000000','0.001467500000000','0.001468186389149','6.863891487371376','6.863891487371376','test'),('2019-10-24 15:59:59','2019-10-25 07:59:59','QTUMBTC','4h','0.000214000000000','0.000211700000000','0.001467500000000','0.001451727803738','6.857476635514019','6.857476635514019','test'),('2019-10-27 15:59:59','2019-11-03 15:59:59','QTUMBTC','4h','0.000232900000000','0.000231000000000','0.001467500000000','0.001455528123658','6.300987548303993','6.300987548303993','test'),('2019-11-28 11:59:59','2019-11-30 07:59:59','QTUMBTC','4h','0.000243700000000','0.000241600000000','0.001467500000000','0.001454854329093','6.021748050882233','6.021748050882233','test'),('2019-12-01 03:59:59','2019-12-01 07:59:59','QTUMBTC','4h','0.000238500000000','0.000238500000000','0.001467500000000','0.001467500000000','6.153039832285115','6.153039832285115','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','QTUMBTC','4h','0.000236600000000','0.000234200000000','0.001467500000000','0.001452614116653','6.202451394759088','6.202451394759088','test'),('2019-12-10 15:59:59','2019-12-10 19:59:59','QTUMBTC','4h','0.000237100000000','0.000237400000000','0.001467500000000','0.001469356811472','6.189371573175876','6.189371573175876','test'),('2019-12-29 15:59:59','2019-12-29 19:59:59','QTUMBTC','4h','0.000226300000000','0.000227300000000','0.001467500000000','0.001473984754750','6.484754750331419','6.484754750331419','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  4:21:21
