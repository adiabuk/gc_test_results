-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 15:59:59','2019-01-11 19:59:59','OSTETH','4h','0.000171960000000','0.000170250000000','0.072144500000000','0.071427082606420','419.54233542684347','419.542335426843465','test'),('2019-01-14 11:59:59','2019-01-14 15:59:59','OSTETH','4h','0.000171340000000','0.000164000000000','0.072144500000000','0.069053916190032','421.06046457336294','421.060464573362935','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','OSTETH','4h','0.000174790000000','0.000171850000000','0.072144500000000','0.070931016219463','412.7495852165456','412.749585216545597','test'),('2019-01-29 19:59:59','2019-01-30 03:59:59','OSTETH','4h','0.000190640000000','0.000186490000000','0.072144500000000','0.070574002334243','378.43317247167437','378.433172471674368','test'),('2019-02-07 11:59:59','2019-02-07 23:59:59','OSTETH','4h','0.000183880000000','0.000182780000000','0.072144500000000','0.071712919893409','392.3455514465956','392.345551446595607','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','OSTETH','4h','0.000181410000000','0.000170190000000','0.072144500000000','0.067682445592856','397.68755856898736','397.687558568987356','test'),('2019-02-17 03:59:59','2019-02-17 23:59:59','OSTETH','4h','0.000180290000000','0.000167470000000','0.072144500000000','0.067014473431693','400.15807865106217','400.158078651062169','test'),('2019-02-25 19:59:59','2019-02-28 07:59:59','OSTETH','4h','0.000164600000000','0.000163450000000','0.072144500000000','0.071640452764277','438.30194410692593','438.301944106925930','test'),('2019-03-06 19:59:59','2019-03-07 03:59:59','OSTETH','4h','0.000172420000000','0.000171210000000','0.072144500000000','0.071638208125507','418.4230367706762','418.423036770676219','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','OSTETH','4h','0.000173520000000','0.000174910000000','0.072144500000000','0.072722421017750','415.7705163669894','415.770516366989398','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','OSTETH','4h','0.000197580000000','0.000197080000000','0.072144500000000','0.071961929648750','365.1407025002531','365.140702500253099','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','OSTETH','4h','0.000200620000000','0.000203000000000','0.072144500000000','0.073000366364271','359.60771608015153','359.607716080151533','test'),('2019-03-30 19:59:59','2019-03-30 23:59:59','OSTETH','4h','0.000205140000000','0.000204490000000','0.072144500000000','0.071915905259823','351.6842156575997','351.684215657599680','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','OSTETH','4h','0.000205720000000','0.000204310000000','0.072144500000000','0.071650023308380','350.69268909196967','350.692689091969669','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','OSTETH','4h','0.000205320000000','0.000205250000000','0.072144500000000','0.072119903686928','351.3759010325346','351.375901032534614','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','OSTETH','4h','0.000206570000000','0.000201340000000','0.072144500000000','0.070317924335576','349.2496490293847','349.249649029384727','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','OSTETH','4h','0.000171140000000','0.000170310000000','0.072144500000000','0.071794611400023','421.5525300923221','421.552530092322115','test'),('2019-05-22 19:59:59','2019-05-23 07:59:59','OSTETH','4h','0.000106030000000','0.000101030000000','0.072144500000000','0.068742420399887','680.4159200226351','680.415920022635078','test'),('2019-05-25 15:59:59','2019-05-26 23:59:59','OSTETH','4h','0.000103310000000','0.000105650000000','0.072144500000000','0.073778592827413','698.3302681250605','698.330268125060456','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','OSTETH','4h','0.000105830000000','0.000103840000000','0.072144500000000','0.070787913446093','681.70178588302','681.701785883019966','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','OSTETH','4h','0.000105810000000','0.000103120000000','0.072144500000000','0.070310375578868','681.8306398261034','681.830639826103379','test'),('2019-06-03 11:59:59','2019-06-04 03:59:59','OSTETH','4h','0.000106500000000','0.000104720000000','0.072144500000000','0.070938704600939','677.413145539906','677.413145539906054','test'),('2019-06-05 11:59:59','2019-06-06 15:59:59','OSTETH','4h','0.000109900000000','0.000105300000000','0.072144500000000','0.069124803002730','656.4558689717925','656.455868971792484','test'),('2019-06-14 03:59:59','2019-06-14 07:59:59','OSTETH','4h','0.000112430000000','0.000112740000000','0.072144500000000','0.072343421951436','641.6837143111269','641.683714311126892','test'),('2019-06-20 03:59:59','2019-06-20 11:59:59','OSTETH','4h','0.000113050000000','0.000109320000000','0.072144500000000','0.069764146306944','638.1645289694826','638.164528969482603','test'),('2019-07-19 23:59:59','2019-07-20 03:59:59','OSTETH','4h','0.000065950000000','0.000064500000000','0.072144500000000','0.070558305534496','1093.9272175890826','1093.927217589082602','test'),('2019-07-21 19:59:59','2019-07-25 11:59:59','OSTETH','4h','0.000066310000000','0.000067990000000','0.072144500000000','0.073972320238275','1087.9882370683156','1087.988237068315584','test'),('2019-07-29 15:59:59','2019-07-30 11:59:59','OSTETH','4h','0.000070750000000','0.000069180000000','0.072144500000000','0.070543554911661','1019.7102473498234','1019.710247349823362','test'),('2019-07-30 23:59:59','2019-07-31 03:59:59','OSTETH','4h','0.000069670000000','0.000068980000000','0.072144500000000','0.071429992966844','1035.5174393569685','1035.517439356968453','test'),('2019-08-17 19:59:59','2019-08-18 11:59:59','OSTETH','4h','0.000054110000000','0.000052490000000','0.072144500000000','0.069984564867862','1333.293291443356','1333.293291443356111','test'),('2019-08-21 07:59:59','2019-08-28 15:59:59','OSTETH','4h','0.000052940000000','0.000060270000000','0.072144500000000','0.082133528806196','1362.7597279939555','1362.759727993955494','test'),('2019-08-29 15:59:59','2019-08-29 19:59:59','OSTETH','4h','0.000061010000000','0.000063120000000','0.072144500000000','0.074639581052287','1182.5028683822325','1182.502868382232464','test'),('2019-09-04 11:59:59','2019-09-04 15:59:59','OSTETH','4h','0.000062060000000','0.000061310000000','0.072144500000000','0.071272628021270','1162.495971640348','1162.495971640347989','test'),('2019-09-05 11:59:59','2019-09-06 07:59:59','OSTETH','4h','0.000063120000000','0.000061820000000','0.072144500000000','0.070658634188847','1142.973700887199','1142.973700887198902','test'),('2019-09-06 15:59:59','2019-09-09 11:59:59','OSTETH','4h','0.000061070000000','0.000061920000000','0.072144500000000','0.073148639921402','1181.341084001965','1181.341084001965100','test'),('2019-09-20 03:59:59','2019-09-20 07:59:59','OSTETH','4h','0.000062270000000','0.000063040000000','0.072144500000000','0.073036603179701','1158.5755580536375','1158.575558053637451','test'),('2019-09-25 23:59:59','2019-09-26 11:59:59','OSTETH','4h','0.000063700000000','0.000061090000000','0.072144500000000','0.069188500863422','1132.5667189952903','1132.566718995290330','test'),('2019-09-27 07:59:59','2019-09-27 23:59:59','OSTETH','4h','0.000063200000000','0.000061300000000','0.072144500000000','0.069975598892405','1141.5268987341772','1141.526898734177166','test'),('2019-10-03 03:59:59','2019-10-06 07:59:59','OSTETH','4h','0.000061090000000','0.000063460000000','0.072144500000000','0.074943361761336','1180.954329677525','1180.954329677525038','test'),('2019-10-10 19:59:59','2019-10-11 03:59:59','OSTETH','4h','0.000066270000000','0.000065810000000','0.072144500000000','0.071643723328806','1088.6449373773955','1088.644937377395536','test'),('2019-10-14 23:59:59','2019-10-15 03:59:59','OSTETH','4h','0.000067010000000','0.000066240000000','0.072144500000000','0.071315500373079','1076.6228921056559','1076.622892105655865','test'),('2019-10-15 07:59:59','2019-10-16 11:59:59','OSTETH','4h','0.000068410000000','0.000065890000000','0.072144500000000','0.069486933269990','1054.5899722262827','1054.589972226282725','test'),('2019-10-21 11:59:59','2019-10-23 03:59:59','OSTETH','4h','0.000065910000000','0.000066480000000','0.072144500000000','0.072768416932180','1094.5911090881505','1094.591109088150461','test'),('2019-10-29 03:59:59','2019-10-29 07:59:59','OSTETH','4h','0.000064090000000','0.000061550000000','0.072144500000000','0.069285285926041','1125.6748322671242','1125.674832267124202','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','OSTETH','4h','0.000064550000000','0.000065310000000','0.072144500000000','0.072993916266460','1117.6529821843533','1117.652982184353277','test'),('2019-11-02 23:59:59','2019-11-04 23:59:59','OSTETH','4h','0.000064700000000','0.000066750000000','0.072144500000000','0.074430376738794','1115.0618238021639','1115.061823802163872','test'),('2019-11-13 07:59:59','2019-11-13 11:59:59','OSTETH','4h','0.000061950000000','0.000061710000000','0.072144500000000','0.071865005569007','1164.5601291364003','1164.560129136400292','test'),('2019-11-15 23:59:59','2019-11-16 07:59:59','OSTETH','4h','0.000061490000000','0.000061810000000','0.072144500000000','0.072519947064563','1173.272076760449','1173.272076760448954','test'),('2019-11-17 03:59:59','2019-11-19 03:59:59','OSTETH','4h','0.000073440000000','0.000064300000000','0.072144500000000','0.063165731889978','982.3597494553377','982.359749455337692','test'),('2019-11-19 19:59:59','2019-11-19 23:59:59','OSTETH','4h','0.000064290000000','0.000063360000000','0.072144500000000','0.071100879141391','1122.1729662466948','1122.172966246694841','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','OSTETH','4h','0.000062930000000','0.000062220000000','0.072144500000000','0.071330538534880','1146.4245987605277','1146.424598760527715','test'),('2019-12-06 19:59:59','2019-12-10 03:59:59','OSTETH','4h','0.000070210000000','0.000068230000000','0.072144500000000','0.070109944950862','1027.5530551203533','1027.553055120353292','test'),('2019-12-12 07:59:59','2019-12-22 19:59:59','OSTETH','4h','0.000071310000000','0.000091380000000','0.072144500000000','0.092449367690366','1011.7024260272051','1011.702426027205092','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 12:19:46
