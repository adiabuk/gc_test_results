-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-17 15:59:59','2019-01-17 19:59:59','ICXBTC','4h','0.000065500000000','0.000065800000000','0.001467500000000','0.001474221374046','22.404580152671755','22.404580152671755','test'),('2019-01-19 07:59:59','2019-01-19 15:59:59','ICXBTC','4h','0.000065700000000','0.000065100000000','0.001469180343512','0.001455763171425','22.361953478105026','22.361953478105026','test'),('2019-01-23 15:59:59','2019-01-23 19:59:59','ICXBTC','4h','0.000065100000000','0.000064300000000','0.001469180343512','0.001451125899967','22.568054431827957','22.568054431827957','test'),('2019-02-07 03:59:59','2019-02-13 15:59:59','ICXBTC','4h','0.000058100000000','0.000060600000000','0.001469180343512','0.001532398086348','25.287097134457827','25.287097134457827','test'),('2019-02-14 23:59:59','2019-02-15 03:59:59','ICXBTC','4h','0.000060300000000','0.000060600000000','0.001477116875313','0.001484465715489','24.49613391894693','24.496133918946931','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','ICXBTC','4h','0.000061500000000','0.000060900000000','0.001478954085357','0.001464525265012','24.048033908235773','24.048033908235773','test'),('2019-02-20 19:59:59','2019-02-20 23:59:59','ICXBTC','4h','0.000061300000000','0.000061300000000','0.001478954085357','0.001478954085357','24.126494051500817','24.126494051500817','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','ICXBTC','4h','0.000083600000000','0.000083200000000','0.001478954085357','0.001471877750020','17.69083834159091','17.690838341590911','test'),('2019-03-19 03:59:59','2019-03-19 15:59:59','ICXBTC','4h','0.000085000000000','0.000084400000000','0.001478954085357','0.001468514409460','17.399459827729412','17.399459827729412','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ICXBTC','4h','0.000084400000000','0.000080300000000','0.001478954085357','0.001407109159410','17.523152670106636','17.523152670106636','test'),('2019-03-24 15:59:59','2019-03-25 07:59:59','ICXBTC','4h','0.000085900000000','0.000084800000000','0.001478954085357','0.001460015208827','17.21716048145518','17.217160481455181','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ICXBTC','4h','0.000082000000000','0.000081100000000','0.001478954085357','0.001462721662469','18.036025431182928','18.036025431182928','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','ICXBTC','4h','0.000081900000000','0.000082500000000','0.001478954085357','0.001489788913821','18.058047440256413','18.058047440256413','test'),('2019-04-03 07:59:59','2019-04-03 23:59:59','ICXBTC','4h','0.000083100000000','0.000081300000000','0.001478954085357','0.001446918978815','17.797281412238267','17.797281412238267','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','ICXBTC','4h','0.000085600000000','0.000082400000000','0.001478954085357','0.001423666082166','17.277500997161216','17.277500997161216','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','ICXBTC','4h','0.000083100000000','0.000083200000000','0.001478954085357','0.001480733813498','17.797281412238267','17.797281412238267','test'),('2019-04-22 11:59:59','2019-04-23 07:59:59','ICXBTC','4h','0.000074300000000','0.000072900000000','0.001478954085357','0.001451086848217','19.905169385693135','19.905169385693135','test'),('2019-05-18 03:59:59','2019-05-18 07:59:59','ICXBTC','4h','0.000051800000000','0.000049800000000','0.001478954085357','0.001421851611019','28.55123716905406','28.551237169054058','test'),('2019-05-18 11:59:59','2019-05-18 23:59:59','ICXBTC','4h','0.000051500000000','0.000051300000000','0.001478954085357','0.001473210574346','28.71755505547573','28.717555055475732','test'),('2019-05-21 19:59:59','2019-05-22 11:59:59','ICXBTC','4h','0.000051400000000','0.000049200000000','0.001478954085357','0.001415652548630','28.77342578515564','28.773425785155641','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','ICXBTC','4h','0.000050100000000','0.000049000000000','0.001478954085357','0.001446482039571','29.52004162389222','29.520041623892219','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','ICXBTC','4h','0.000047400000000','0.000047200000000','0.001478954085357','0.001472713772761','31.201562982215194','31.201562982215194','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','ICXBTC','4h','0.000047600000000','0.000051200000000','0.001478954085357','0.001590807755678','31.070463978088238','31.070463978088238','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','ICXBTC','4h','0.000047500000000','0.000047800000000','0.001478954085357','0.001488294848001','31.1358754812','31.135875481199999','test'),('2019-06-09 07:59:59','2019-06-09 11:59:59','ICXBTC','4h','0.000047300000000','0.000047500000000','0.001478954085357','0.001485207591003','31.267528231649052','31.267528231649052','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ICXBTC','4h','0.000048100000000','0.000046800000000','0.001478954085357','0.001438982353320','30.747486182058218','30.747486182058218','test'),('2019-06-10 15:59:59','2019-06-10 19:59:59','ICXBTC','4h','0.000047400000000','0.000047400000000','0.001478954085357','0.001478954085357','31.201562982215194','31.201562982215194','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ICXBTC','4h','0.000048100000000','0.000047300000000','0.001478954085357','0.001454356096411','30.747486182058218','30.747486182058218','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','ICXBTC','4h','0.000029300000000','0.000028300000000','0.001478954085357','0.001428477836710','50.47624864699659','50.476248646996588','test'),('2019-07-07 19:59:59','2019-07-08 11:59:59','ICXBTC','4h','0.000029900000000','0.000029200000000','0.001478954085357','0.001444329742222','49.46334733635452','49.463347336354524','test'),('2019-07-14 07:59:59','2019-07-15 03:59:59','ICXBTC','4h','0.000028600000000','0.000027000000000','0.001478954085357','0.001396215395267','51.711681306188815','51.711681306188815','test'),('2019-07-18 07:59:59','2019-07-18 11:59:59','ICXBTC','4h','0.000027000000000','0.000026400000000','0.001478954085357','0.001446088439016','54.77607723544445','54.776077235444447','test'),('2019-07-23 03:59:59','2019-07-23 19:59:59','ICXBTC','4h','0.000026700000000','0.000026400000000','0.001478954085357','0.001462336623724','55.39153877741574','55.391538777415740','test'),('2019-07-31 03:59:59','2019-07-31 07:59:59','ICXBTC','4h','0.000027100000000','0.000026900000000','0.001478954085357','0.001468039295059','54.57395148918819','54.573951489188190','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','ICXBTC','4h','0.000027300000000','0.000026400000000','0.001478954085357','0.001430197357268','54.174142320769235','54.174142320769235','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','ICXBTC','4h','0.000020300000000','0.000019500000000','0.001478954085357','0.001420670180515','72.85488105206898','72.854881052068976','test'),('2019-08-17 23:59:59','2019-08-18 03:59:59','ICXBTC','4h','0.000019300000000','0.000019400000000','0.001478954085357','0.001486617059893','76.62974535528497','76.629745355284967','test'),('2019-08-18 15:59:59','2019-08-19 03:59:59','ICXBTC','4h','0.000019700000000','0.000019400000000','0.001478954085357','0.001456431941925','75.07381143944163','75.073811439441627','test'),('2019-08-22 11:59:59','2019-08-28 07:59:59','ICXBTC','4h','0.000019900000000','0.000021300000000','0.001478954085357','0.001583001106437','74.31930077170855','74.319300771708555','test'),('2019-08-29 03:59:59','2019-08-31 11:59:59','ICXBTC','4h','0.000022300000000','0.000021700000000','0.001478954085357','0.001439161598755','66.32081100255606','66.320811002556056','test'),('2019-09-02 03:59:59','2019-09-02 15:59:59','ICXBTC','4h','0.000022100000000','0.000021800000000','0.001478954085357','0.001458877785556','66.92099933742082','66.920999337420824','test'),('2019-09-09 23:59:59','2019-09-10 11:59:59','ICXBTC','4h','0.000020200000000','0.000019900000000','0.001478954085357','0.001456989420723','73.21554878004952','73.215548780049517','test'),('2019-09-12 11:59:59','2019-09-12 15:59:59','ICXBTC','4h','0.000020000000000','0.000020400000000','0.001478954085357','0.001508533167064','73.94770426785','73.947704267850000','test'),('2019-09-17 15:59:59','2019-09-22 03:59:59','ICXBTC','4h','0.000019960000000','0.000020300000000','0.001478954085357','0.001504146690017','74.09589605996995','74.095896059969945','test'),('2019-09-23 07:59:59','2019-09-23 15:59:59','ICXBTC','4h','0.000020440000000','0.000020410000000','0.001478954085357','0.001476783409106','72.35587501746575','72.355875017465749','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','ICXBTC','4h','0.000020110000000','0.000020140000000','0.001478954085357','0.001481160381854','73.54321657667828','73.543216576678276','test'),('2019-09-27 11:59:59','2019-09-27 15:59:59','ICXBTC','4h','0.000020140000000','0.000019910000000','0.001478954085357','0.001462064341582','73.43366858773585','73.433668587735852','test'),('2019-09-27 19:59:59','2019-09-28 03:59:59','ICXBTC','4h','0.000020110000000','0.000020260000000','0.001478954085357','0.001489985567844','73.54321657667828','73.543216576678276','test'),('2019-09-29 23:59:59','2019-09-30 03:59:59','ICXBTC','4h','0.000020200000000','0.000020020000000','0.001478954085357','0.001465775286577','73.21554878004952','73.215548780049517','test'),('2019-10-01 15:59:59','2019-10-01 19:59:59','ICXBTC','4h','0.000020240000000','0.000019880000000','0.001478954085357','0.001452648577910','73.07085401961463','73.070854019614629','test'),('2019-10-02 03:59:59','2019-10-02 07:59:59','ICXBTC','4h','0.000020130000000','0.000020110000000','0.001478954085357','0.001477484682391','73.47014830387482','73.470148303874822','test'),('2019-10-03 07:59:59','2019-10-03 15:59:59','ICXBTC','4h','0.000020550000000','0.000020130000000','0.001478954085357','0.001448727286532','71.96856863051094','71.968568630510944','test'),('2019-10-04 03:59:59','2019-10-09 15:59:59','ICXBTC','4h','0.000020290000000','0.000020470000000','0.001478954085357','0.001492074427169','72.8907878441104','72.890787844110406','test'),('2019-10-29 15:59:59','2019-10-29 19:59:59','ICXBTC','4h','0.000018570000000','0.000017850000000','0.001478954085357','0.001421611762177','79.64211552810985','79.642115528109855','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','ICXBTC','4h','0.000018570000000','0.000018160000000','0.001478954085357','0.001446300817990','79.64211552810985','79.642115528109855','test'),('2019-10-30 15:59:59','2019-10-30 19:59:59','ICXBTC','4h','0.000018330000000','0.000018170000000','0.001478954085357','0.001466044502506','80.68489281816694','80.684892818166944','test'),('2019-10-30 23:59:59','2019-10-31 07:59:59','ICXBTC','4h','0.000018480000000','0.000018190000000','0.001478954085357','0.001455745390295','80.02998297386364','80.029982973863639','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','ICXBTC','4h','0.000018090000000','0.000018190000000','0.001478954085357','0.001487129619273','81.75533915737977','81.755339157379765','test'),('2019-11-13 19:59:59','2019-11-14 07:59:59','ICXBTC','4h','0.000018740000000','0.000018700000000','0.001478954085357','0.001475797299689','78.91964169461046','78.919641694610462','test'),('2019-11-16 07:59:59','2019-11-16 19:59:59','ICXBTC','4h','0.000018680000000','0.000018560000000','0.001478954085357','0.001469453309648','79.17313090776231','79.173130907762314','test'),('2019-11-27 15:59:59','2019-11-27 19:59:59','ICXBTC','4h','0.000018630000000','0.000018340000000','0.001478954085357','0.001455932255794','79.38561918180355','79.385619181803548','test'),('2019-12-03 15:59:59','2019-12-03 19:59:59','ICXBTC','4h','0.000018260000000','0.000018220000000','0.001478954085357','0.001475714317372','80.99419963619934','80.994199636199340','test'),('2019-12-07 19:59:59','2019-12-07 23:59:59','ICXBTC','4h','0.000018200000000','0.000018210000000','0.001478954085357','0.001479766697492','81.26121348115386','81.261213481153860','test'),('2019-12-09 03:59:59','2019-12-09 11:59:59','ICXBTC','4h','0.000018140000000','0.000018150000000','0.001478954085357','0.001479769385294','81.52999368009924','81.529993680099238','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','ICXBTC','4h','0.000018200000000','0.000017270000000','0.001478954085357','0.001403381156820','81.26121348115386','81.261213481153860','test'),('2019-12-12 03:59:59','2019-12-14 11:59:59','ICXBTC','4h','0.000018640000000','0.000018140000000','0.001478954085357','0.001439282570192','79.34303033031117','79.343030330311166','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 12:53:46
