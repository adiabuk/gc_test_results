-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-10 07:59:59','NASBTC','4h','0.000158200000000','0.000153700000000','0.001467500000000','0.001425756953224','9.276232616940582','9.276232616940582','test'),('2019-01-16 15:59:59','2019-01-17 11:59:59','NASBTC','4h','0.000153000000000','0.000151300000000','0.001467500000000','0.001451194444444','9.591503267973856','9.591503267973856','test'),('2019-01-21 11:59:59','2019-01-21 15:59:59','NASBTC','4h','0.000153400000000','0.000155000000000','0.001467500000000','0.001482806388527','9.566492829204694','9.566492829204694','test'),('2019-01-26 15:59:59','2019-01-27 19:59:59','NASBTC','4h','0.000159200000000','0.000157500000000','0.001467500000000','0.001451829459799','9.217964824120603','9.217964824120603','test'),('2019-02-09 07:59:59','2019-02-09 23:59:59','NASBTC','4h','0.000154900000000','0.000151200000000','0.001467500000000','0.001432446739832','9.47385409941898','9.473854099418981','test'),('2019-02-13 03:59:59','2019-02-13 07:59:59','NASBTC','4h','0.000150900000000','0.000151300000000','0.001467500000000','0.001471389993373','9.724983432736911','9.724983432736911','test'),('2019-02-14 03:59:59','2019-02-14 07:59:59','NASBTC','4h','0.000151500000000','0.000149700000000','0.001467500000000','0.001450064356436','9.686468646864688','9.686468646864688','test'),('2019-02-15 19:59:59','2019-02-19 03:59:59','NASBTC','4h','0.000150800000000','0.000153600000000','0.001467500000000','0.001494748010610','9.731432360742705','9.731432360742705','test'),('2019-02-22 11:59:59','2019-02-24 19:59:59','NASBTC','4h','0.000156300000000','0.000160400000000','0.001467500000000','0.001505994881638','9.388995521433142','9.388995521433142','test'),('2019-03-05 15:59:59','2019-03-05 19:59:59','NASBTC','4h','0.000160000000000','0.000159700000000','0.001467500000000','0.001464748437500','9.171875','9.171875000000000','test'),('2019-03-06 11:59:59','2019-03-08 07:59:59','NASBTC','4h','0.000160100000000','0.000159900000000','0.001467500000000','0.001465666770768','9.166146158650845','9.166146158650845','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','NASBTC','4h','0.000161800000000','0.000162900000000','0.001467500000000','0.001477476823239','9.069839307787392','9.069839307787392','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','NASBTC','4h','0.000236800000000','0.000236400000000','0.001467500000000','0.001465021114865','6.197212837837838','6.197212837837838','test'),('2019-04-10 15:59:59','2019-04-11 03:59:59','NASBTC','4h','0.000238100000000','0.000226000000000','0.001467500000000','0.001392923141537','6.163376732465351','6.163376732465351','test'),('2019-04-11 11:59:59','2019-04-11 15:59:59','NASBTC','4h','0.000238500000000','0.000238800000000','0.001467500000000','0.001469345911950','6.153039832285115','6.153039832285115','test'),('2019-04-18 03:59:59','2019-04-18 07:59:59','NASBTC','4h','0.000254400000000','0.000254800000000','0.001467500000000','0.001469807389937','5.768474842767295','5.768474842767295','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','NASBTC','4h','0.000152900000000','0.000154400000000','0.001467500000000','0.001481896664487','9.59777632439503','9.597776324395030','test'),('2019-05-18 03:59:59','2019-05-18 07:59:59','NASBTC','4h','0.000152900000000','0.000149300000000','0.001467500000000','0.001432948005232','9.59777632439503','9.597776324395030','test'),('2019-05-18 23:59:59','2019-05-19 03:59:59','NASBTC','4h','0.000158400000000','0.000148600000000','0.001467500000000','0.001376707702020','9.264520202020202','9.264520202020202','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','NASBTC','4h','0.000140800000000','0.000137200000000','0.001467500000000','0.001429978693182','10.422585227272727','10.422585227272727','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','NASBTC','4h','0.000139600000000','0.000140200000000','0.001467500000000','0.001473807306590','10.5121776504298','10.512177650429800','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','NASBTC','4h','0.000139600000000','0.000138800000000','0.001467500000000','0.001459090257880','10.5121776504298','10.512177650429800','test'),('2019-06-15 11:59:59','2019-06-15 19:59:59','NASBTC','4h','0.000181000000000','0.000179000000000','0.001467500000000','0.001451284530387','8.107734806629834','8.107734806629834','test'),('2019-06-16 03:59:59','2019-06-16 07:59:59','NASBTC','4h','0.000188100000000','0.000181300000000','0.001467500000000','0.001414448431685','7.801701222753855','7.801701222753855','test'),('2019-06-23 15:59:59','2019-06-23 19:59:59','NASBTC','4h','0.000167900000000','0.000158200000000','0.001467500000000','0.001382718880286','8.740321620011914','8.740321620011914','test'),('2019-06-23 23:59:59','2019-06-24 03:59:59','NASBTC','4h','0.000163700000000','0.000161900000000','0.001467500000000','0.001451363775199','8.964569334147832','8.964569334147832','test'),('2019-06-24 07:59:59','2019-06-24 19:59:59','NASBTC','4h','0.000170600000000','0.000159800000000','0.001467500000000','0.001374598475967','8.601992966002346','8.601992966002346','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','NASBTC','4h','0.000145100000000','0.000145300000000','0.001467500000000','0.001469522742936','10.113714679531357','10.113714679531357','test'),('2019-07-04 23:59:59','2019-07-06 07:59:59','NASBTC','4h','0.000143100000000','0.000142100000000','0.001467500000000','0.001457244933613','10.25506638714186','10.255066387141859','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','NASBTC','4h','0.000095300000000','0.000093100000000','0.001467500000000','0.001433622770199','15.398740818467996','15.398740818467996','test'),('2019-07-26 11:59:59','2019-07-27 03:59:59','NASBTC','4h','0.000094900000000','0.000093900000000','0.001467500000000','0.001452036354057','15.463645943097998','15.463645943097998','test'),('2019-07-27 19:59:59','2019-07-28 03:59:59','NASBTC','4h','0.000095500000000','0.000094000000000','0.001467500000000','0.001444450261780','15.366492146596858','15.366492146596858','test'),('2019-08-01 07:59:59','2019-08-01 11:59:59','NASBTC','4h','0.000094100000000','0.000093200000000','0.001467500000000','0.001453464399575','15.595111583421893','15.595111583421893','test'),('2019-08-03 11:59:59','2019-08-03 19:59:59','NASBTC','4h','0.000095500000000','0.000091900000000','0.001467500000000','0.001412180628272','15.366492146596858','15.366492146596858','test'),('2019-08-22 15:59:59','2019-08-23 03:59:59','NASBTC','4h','0.000068500000000','0.000068100000000','0.001467500000000','0.001458930656934','21.423357664233578','21.423357664233578','test'),('2019-08-26 19:59:59','2019-08-27 03:59:59','NASBTC','4h','0.000070200000000','0.000068300000000','0.001467500000000','0.001427781339031','20.904558404558404','20.904558404558404','test'),('2019-08-27 15:59:59','2019-08-28 19:59:59','NASBTC','4h','0.000071800000000','0.000070300000000','0.001467500000000','0.001436841922006','20.43871866295265','20.438718662952649','test'),('2019-08-30 15:59:59','2019-08-30 19:59:59','NASBTC','4h','0.000070300000000','0.000068800000000','0.001467500000000','0.001436187766714','20.874822190611663','20.874822190611663','test'),('2019-09-09 23:59:59','2019-09-10 03:59:59','NASBTC','4h','0.000064900000000','0.000064600000000','0.001467500000000','0.001460716486903','22.61171032357473','22.611710323574730','test'),('2019-09-14 19:59:59','2019-09-14 23:59:59','NASBTC','4h','0.000063800000000','0.000063700000000','0.001467500000000','0.001465199843260','23.00156739811912','23.001567398119121','test'),('2019-09-16 19:59:59','2019-09-16 23:59:59','NASBTC','4h','0.000064000000000','0.000063300000000','0.001467500000000','0.001451449218750','22.929687500000004','22.929687500000004','test'),('2019-09-21 15:59:59','2019-09-22 07:59:59','NASBTC','4h','0.000064900000000','0.000064700000000','0.001467500000000','0.001462977657935','22.61171032357473','22.611710323574730','test'),('2019-09-22 15:59:59','2019-09-22 19:59:59','NASBTC','4h','0.000064800000000','0.000063900000000','0.001467500000000','0.001447118055556','22.646604938271604','22.646604938271604','test'),('2019-09-30 03:59:59','2019-09-30 15:59:59','NASBTC','4h','0.000061100000000','0.000060200000000','0.001467500000000','0.001445883797054','24.018003273322424','24.018003273322424','test'),('2019-10-04 19:59:59','2019-10-04 23:59:59','NASBTC','4h','0.000059500000000','0.000059000000000','0.001467500000000','0.001455168067227','24.66386554621849','24.663865546218489','test'),('2019-10-05 11:59:59','2019-10-05 15:59:59','NASBTC','4h','0.000059800000000','0.000059800000000','0.001467500000000','0.001467500000000','24.540133779264217','24.540133779264217','test'),('2019-10-24 19:59:59','2019-10-24 23:59:59','NASBTC','4h','0.000058200000000','0.000057700000000','0.001467500000000','0.001454892611684','25.214776632302407','25.214776632302407','test'),('2019-10-27 15:59:59','2019-10-29 23:59:59','NASBTC','4h','0.000064600000000','0.000062900000000','0.001467500000000','0.001428881578947','22.71671826625387','22.716718266253871','test'),('2019-11-30 03:59:59','2019-11-30 07:59:59','NASBTC','4h','0.000060600000000','0.000059600000000','0.001467500000000','0.001443283828383','24.216171617161717','24.216171617161717','test'),('2019-12-08 15:59:59','2019-12-09 03:59:59','NASBTC','4h','0.000058200000000','0.000057400000000','0.001467500000000','0.001447328178694','25.214776632302407','25.214776632302407','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','NASBTC','4h','0.000057800000000','0.000057200000000','0.001467500000000','0.001452266435986','25.389273356401382','25.389273356401382','test'),('2019-12-30 03:59:59','2019-12-30 07:59:59','NASBTC','4h','0.000051700000000','0.000051900000000','0.001467500000000','0.001473176982592','28.384912959381044','28.384912959381044','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:04:08
