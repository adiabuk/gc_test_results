-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 15:59:59','2019-01-08 19:59:59','ASTETH','4h','0.000202900000000','0.000198500000000','0.072144500000000','0.070580006160670','355.56678166584527','355.566781665845269','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','ASTETH','4h','0.000200200000000','0.000193200000000','0.072144500000000','0.069621965034965','360.3621378621379','360.362137862137899','test'),('2019-01-12 23:59:59','2019-01-13 19:59:59','ASTETH','4h','0.000200600000000','0.000204000000000','0.072144500000000','0.073367288135593','359.64356929212363','359.643569292123630','test'),('2019-01-15 19:59:59','2019-01-27 11:59:59','ASTETH','4h','0.000201600000000','0.000247900000000','0.072144500000000','0.088713400545635','357.859623015873','357.859623015873012','test'),('2019-01-27 19:59:59','2019-01-28 03:59:59','ASTETH','4h','0.000248300000000','0.000244200000000','0.075570664969216','0.074322820722846','304.35225521230666','304.352255212306659','test'),('2019-01-29 23:59:59','2019-01-30 11:59:59','ASTETH','4h','0.000250400000000','0.000248400000000','0.075570664969216','0.074967065408759','301.7997802284984','301.799780228498378','test'),('2019-02-07 15:59:59','2019-02-08 15:59:59','ASTETH','4h','0.000262600000000','0.000236400000000','0.075570664969216','0.068030865189348','287.77861755223154','287.778617552231538','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','ASTETH','4h','0.000238700000000','0.000224300000000','0.075570664969216','0.071011730844554','316.5926475459405','316.592647545940508','test'),('2019-02-22 03:59:59','2019-02-23 03:59:59','ASTETH','4h','0.000228400000000','0.000221200000000','0.075570664969216','0.073188402325703','330.8698115990193','330.869811599019272','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','ASTETH','4h','0.000220300000000','0.000219200000000','0.075570664969216','0.075193326197241','343.0352472501861','343.035247250186103','test'),('2019-03-06 19:59:59','2019-03-06 23:59:59','ASTETH','4h','0.000261400000000','0.000255000000000','0.075570664969216','0.073720426806236','289.09971296563117','289.099712965631170','test'),('2019-03-07 15:59:59','2019-03-11 11:59:59','ASTETH','4h','0.000263400000000','0.000272900000000','0.075570664969216','0.078296258428622','286.9045746743204','286.904574674320372','test'),('2019-03-19 11:59:59','2019-03-19 15:59:59','ASTETH','4h','0.000286200000000','0.000294700000000','0.075570664969216','0.077815076752019','264.0484450356953','264.048445035695295','test'),('2019-03-25 15:59:59','2019-03-26 15:59:59','ASTETH','4h','0.000295900000000','0.000302300000000','0.075570664969216','0.077205177493052','255.39258184932748','255.392581849327485','test'),('2019-04-19 15:59:59','2019-04-21 11:59:59','ASTETH','4h','0.000269400000000','0.000269900000000','0.075570664969216','0.075710922328105','280.51471777734224','280.514717777342241','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','ASTETH','4h','0.000169000000000','0.000159800000000','0.075570664969216','0.071456758947223','447.16369804269823','447.163698042698229','test'),('2019-05-28 03:59:59','2019-05-29 07:59:59','ASTETH','4h','0.000231900000000','0.000205200000000','0.075570664969216','0.066869773400962','325.87608869864596','325.876088698645958','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','ASTETH','4h','0.000199900000000','0.000197000000000','0.075570664969216','0.074474342165761','378.0423460190895','378.042346019089507','test'),('2019-06-07 19:59:59','2019-06-08 07:59:59','ASTETH','4h','0.000191800000000','0.000200400000000','0.075570664969216','0.078959130656053','394.00763800425443','394.007638004254432','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ASTETH','4h','0.000193300000000','0.000187900000000','0.075570664969216','0.073459534132000','390.9501550399172','390.950155039917206','test'),('2019-06-10 15:59:59','2019-06-10 19:59:59','ASTETH','4h','0.000194500000000','0.000195800000000','0.075570664969216','0.076075764529422','388.53812323504366','388.538123235043656','test'),('2019-06-11 11:59:59','2019-06-12 15:59:59','ASTETH','4h','0.000196800000000','0.000197700000000','0.075570664969216','0.075916262522429','383.99728134764223','383.997281347642229','test'),('2019-06-13 11:59:59','2019-06-13 23:59:59','ASTETH','4h','0.000202500000000','0.000198000000000','0.075570664969216','0.073891316858789','373.1884689837827','373.188468983782684','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','ASTETH','4h','0.000284400000000','0.000220800000000','0.075570664969216','0.058670896009855','265.71963772579466','265.719637725794655','test'),('2019-06-29 19:59:59','2019-06-29 23:59:59','ASTETH','4h','0.000194800000000','0.000180600000000','0.075570664969216','0.070061920397538','387.9397585688706','387.939758568870616','test'),('2019-07-01 07:59:59','2019-07-01 23:59:59','ASTETH','4h','0.000198500000000','0.000188600000000','0.075570664969216','0.071801649436746','380.7086396434055','380.708639643405490','test'),('2019-07-15 03:59:59','2019-07-15 19:59:59','ASTETH','4h','0.000200600000000','0.000191800000000','0.075570664969216','0.072255501201873','376.7231553799402','376.723155379940181','test'),('2019-07-16 07:59:59','2019-07-16 15:59:59','ASTETH','4h','0.000194000000000','0.000206800000000','0.075570664969216','0.080556770699144','389.5395101505979','389.539510150597891','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','ASTETH','4h','0.000194000000000','0.000192300000000','0.075570664969216','0.074908447801960','389.5395101505979','389.539510150597891','test'),('2019-07-22 03:59:59','2019-07-22 07:59:59','ASTETH','4h','0.000193500000000','0.000204300000000','0.075570664969216','0.079788562548893','390.54607219233077','390.546072192330769','test'),('2019-07-25 15:59:59','2019-07-25 19:59:59','ASTETH','4h','0.000200400000000','0.000199700000000','0.075570664969216','0.075306695580601','377.0991265928942','377.099126592894208','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','ASTETH','4h','0.000197700000000','0.000192600000000','0.075570664969216','0.073621194097476','382.2491905372584','382.249190537258414','test'),('2019-07-27 19:59:59','2019-07-28 15:59:59','ASTETH','4h','0.000204200000000','0.000198500000000','0.075570664969216','0.073461199786432','370.0816110147698','370.081611014769805','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','ASTETH','4h','0.000160400000000','0.000150000000000','0.075570664969216','0.070670821355252','471.13880903501246','471.138809035012457','test'),('2019-08-20 23:59:59','2019-08-21 11:59:59','ASTETH','4h','0.000148300000000','0.000147800000000','0.075570664969216','0.075315875134525','509.57966938109234','509.579669381092344','test'),('2019-08-30 19:59:59','2019-08-31 11:59:59','ASTETH','4h','0.000158800000000','0.000153800000000','0.075570664969216','0.073191235971445','475.88579955425683','475.885799554256835','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','ASTETH','4h','0.000149800000000','0.000136700000000','0.075570664969216','0.068962015362429','504.4770692204005','504.477069220400494','test'),('2019-09-10 07:59:59','2019-09-10 11:59:59','ASTETH','4h','0.000142200000000','0.000139000000000','0.075570664969216','0.073870059287771','531.4392754515893','531.439275451589310','test'),('2019-09-15 11:59:59','2019-09-15 15:59:59','ASTETH','4h','0.000140100000000','0.000146000000000','0.075570664969216','0.078753155499683','539.4051746553605','539.405174655360497','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','ASTETH','4h','0.000136700000000','0.000133900000000','0.075570664969216','0.074022765467286','552.8212506892173','552.821250689217322','test'),('2019-09-19 07:59:59','2019-09-19 15:59:59','ASTETH','4h','0.000141300000000','0.000131600000000','0.075570664969216','0.070382869851018','534.8242389894975','534.824238989497530','test'),('2019-09-20 23:59:59','2019-09-21 03:59:59','ASTETH','4h','0.000135800000000','0.000132100000000','0.075570664969216','0.073511670415563','556.4850145008542','556.485014500854163','test'),('2019-09-21 07:59:59','2019-09-21 11:59:59','ASTETH','4h','0.000135900000000','0.000132900000000','0.075570664969216','0.073902438369454','556.0755332539809','556.075533253980893','test'),('2019-09-22 15:59:59','2019-09-23 23:59:59','ASTETH','4h','0.000144400000000','0.000141400000000','0.075570664969216','0.074000637303651','523.3425551884764','523.342555188476354','test'),('2019-09-25 23:59:59','2019-09-26 03:59:59','ASTETH','4h','0.000138100000000','0.000135700000000','0.075570664969216','0.074257344216674','547.216980226039','547.216980226039027','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','ASTETH','4h','0.000139600000000','0.000131100000000','0.050380443312811','0.047312866177002','360.8914277421967','360.891427742196697','test'),('2019-09-28 11:59:59','2019-09-29 15:59:59','ASTETH','4h','0.000142100000000','0.000135300000000','0.055664125126898','0.053000395001191','391.7250184862619','391.725018486261888','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ASTETH','4h','0.000140200000000','0.000136200000000','0.055664125126898','0.054075990315860','397.03370275961487','397.033702759614869','test'),('2019-09-30 19:59:59','2019-10-01 03:59:59','ASTETH','4h','0.000141900000000','0.000140500000000','0.055664125126898','0.055114937141150','392.2771326772234','392.277132677223392','test'),('2019-10-01 23:59:59','2019-10-02 03:59:59','ASTETH','4h','0.000138900000000','0.000136700000000','0.055664125126898','0.054782475916825','400.7496409423903','400.749640942390272','test'),('2019-10-02 07:59:59','2019-10-08 11:59:59','ASTETH','4h','0.000141500000000','0.000154500000000','0.055664125126898','0.060778143689793','393.38604329963255','393.386043299632547','test'),('2019-10-10 03:59:59','2019-10-10 07:59:59','ASTETH','4h','0.000151600000000','0.000143700000000','0.055664125126898','0.052763422036512','367.17760637795516','367.177606377955158','test'),('2019-10-11 19:59:59','2019-10-12 07:59:59','ASTETH','4h','0.000151400000000','0.000149100000000','0.055664125126898','0.054818501033160','367.66264945110964','367.662649451109644','test'),('2019-10-12 19:59:59','2019-10-13 03:59:59','ASTETH','4h','0.000149500000000','0.000150300000000','0.055664125126898','0.055961993355002','372.3352851297525','372.335285129752492','test'),('2019-10-15 11:59:59','2019-10-16 15:59:59','ASTETH','4h','0.000153200000000','0.000145200000000','0.055664125126898','0.052757382300428','363.34285330873365','363.342853308733652','test'),('2019-10-17 11:59:59','2019-10-17 15:59:59','ASTETH','4h','0.000153800000000','0.000151800000000','0.055664125126898','0.054940274345014','361.92539094211963','361.925390942119634','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','ASTETH','4h','0.000151400000000','0.000148100000000','0.055664125126898','0.054450838383709','367.66264945110964','367.662649451109644','test'),('2019-10-19 19:59:59','2019-10-19 23:59:59','ASTETH','4h','0.000151600000000','0.000150500000000','0.055664125126898','0.055260229759882','367.17760637795516','367.177606377955158','test'),('2019-10-20 23:59:59','2019-10-21 03:59:59','ASTETH','4h','0.000151000000000','0.000150700000000','0.055664125126898','0.055553534149825','368.6365902443576','368.636590244357592','test'),('2019-10-24 23:59:59','2019-10-25 03:59:59','ASTETH','4h','0.000152000000000','0.000150100000000','0.055664125126898','0.054968323562812','366.2113495190658','366.211349519065777','test'),('2019-11-03 15:59:59','2019-11-03 19:59:59','ASTETH','4h','0.000140900000000','0.000139300000000','0.055664125126898','0.055032027183654','395.06121452731014','395.061214527310142','test'),('2019-11-13 15:59:59','2019-11-13 19:59:59','ASTETH','4h','0.000131900000000','0.000131700000000','0.055664125126898','0.055579721601308','422.01762795222135','422.017627952221346','test'),('2019-11-14 03:59:59','2019-11-14 11:59:59','ASTETH','4h','0.000132600000000','0.000128300000000','0.055664125126898','0.053859029063205','419.7897822541327','419.789782254132717','test'),('2019-11-16 23:59:59','2019-11-17 03:59:59','ASTETH','4h','0.000133600000000','0.000135000000000','0.055664125126898','0.056247431827330','416.6476431654042','416.647643165404190','test'),('2019-11-19 03:59:59','2019-11-19 07:59:59','ASTETH','4h','0.000130900000000','0.000132300000000','0.055664125126898','0.056259463363549','425.2415976080825','425.241597608082486','test'),('2019-11-21 15:59:59','2019-11-21 23:59:59','ASTETH','4h','0.000133000000000','0.000131000000000','0.055664125126898','0.054827070613712','418.52725659321806','418.527256593218056','test'),('2019-11-22 03:59:59','2019-11-22 11:59:59','ASTETH','4h','0.000134100000000','0.000131600000000','0.055664125126898','0.054626389759133','415.0941471058762','415.094147105876175','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','ASTETH','4h','0.000133000000000','0.000135500000000','0.055664125126898','0.056710443268381','418.52725659321806','418.527256593218056','test'),('2019-11-25 07:59:59','2019-12-04 03:59:59','ASTETH','4h','0.000141800000000','0.000146900000000','0.055664125126898','0.057666149373352','392.5537738145134','392.553773814513420','test'),('2019-12-17 03:59:59','2019-12-17 11:59:59','ASTETH','4h','0.000149800000000','0.000149800000000','0.055664125126898','0.055664125126898','371.58962033977303','371.589620339773035','test'),('2019-12-17 23:59:59','2019-12-18 03:59:59','ASTETH','4h','0.000149100000000','0.000148500000000','0.055664125126898','0.055440124623369','373.334172547941','373.334172547941023','test'),('2019-12-18 11:59:59','2019-12-18 15:59:59','ASTETH','4h','0.000152700000000','0.000147200000000','0.055664125126898','0.053659195931103','364.53258105368695','364.532581053686954','test'),('2019-12-19 19:59:59','2019-12-19 23:59:59','ASTETH','4h','0.000151200000000','0.000148000000000','0.055664125126898','0.054486048404636','368.14897570699736','368.148975706997362','test'),('2019-12-20 11:59:59','2019-12-22 15:59:59','ASTETH','4h','0.000152500000000','0.000147800000000','0.055664125126898','0.053948575041020','365.01065656982297','365.010656569822970','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','ASTETH','4h','0.000144000000000','0.000137100000000','0.055664125126898','0.052996885797901','386.5564244923472','386.556424492347219','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:59:22
