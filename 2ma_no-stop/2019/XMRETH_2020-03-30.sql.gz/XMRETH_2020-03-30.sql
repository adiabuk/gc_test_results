-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 03:59:59','2019-01-08 15:59:59','XMRETH','4h','0.354570000000000','0.357550000000000','0.072144500000000','0.072750841794286','0.20347040076712639','0.203470400767126','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','XMRETH','4h','0.358000000000000','0.350220000000000','0.072296085448571','0.070724958228488','0.2019443727613729','0.201944372761373','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','XMRETH','4h','0.357530000000000','0.357100000000000','0.072296085448571','0.072209135215743','0.20220984378533546','0.202209843785335','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','XMRETH','4h','0.399460000000000','0.398850000000000','0.072296085448571','0.072185684877491','0.1809845427541456','0.180984542754146','test'),('2019-02-05 07:59:59','2019-02-05 11:59:59','XMRETH','4h','0.400340000000000','0.403000000000000','0.072296085448571','0.072776446110242','0.1805867149137508','0.180586714913751','test'),('2019-02-09 03:59:59','2019-02-09 07:59:59','XMRETH','4h','0.407830000000000','0.404520000000000','0.072296085448571','0.071709321250658','0.17727015042682243','0.177270150426822','test'),('2019-02-10 03:59:59','2019-02-10 07:59:59','XMRETH','4h','0.406520000000000','0.409840000000000','0.072296085448571','0.072886518892656','0.1778413988206509','0.177841398820651','test'),('2019-02-13 11:59:59','2019-02-13 15:59:59','XMRETH','4h','0.404820000000000','0.409480000000000','0.072296085448571','0.073128306579420','0.17858822550410305','0.178588225504103','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XMRETH','4h','0.360210000000000','0.356210000000000','0.072296085448571','0.071493263922810','0.20070538144019046','0.200705381440190','test'),('2019-03-02 03:59:59','2019-03-05 15:59:59','XMRETH','4h','0.357020000000000','0.363350000000000','0.072296085448571','0.073577902212028','0.20249869880838886','0.202498698808389','test'),('2019-03-07 03:59:59','2019-03-08 07:59:59','XMRETH','4h','0.363450000000000','0.363720000000000','0.072302777511671','0.072356489851548','0.19893459213556408','0.198934592135564','test'),('2019-03-08 23:59:59','2019-03-09 11:59:59','XMRETH','4h','0.365890000000000','0.364380000000000','0.072316205596640','0.072017762156123','0.19764466259433167','0.197644662594332','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','XMRETH','4h','0.387050000000000','0.383230000000000','0.072316205596640','0.071602478932439','0.1868394408904276','0.186839440890428','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','XMRETH','4h','0.381880000000000','0.384130000000000','0.072316205596640','0.072742285680940','0.18936892635550434','0.189368926355504','test'),('2019-03-28 23:59:59','2019-03-29 03:59:59','XMRETH','4h','0.382740000000000','0.379430000000000','0.072316205596640','0.071690802867568','0.18894342268025288','0.188943422680253','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','XMRETH','4h','0.383040000000000','0.378580000000000','0.072316205596640','0.071474177931224','0.18879544067627402','0.188795440676274','test'),('2019-03-31 15:59:59','2019-04-05 07:59:59','XMRETH','4h','0.382720000000000','0.401070000000000','0.072316205596640','0.075783498585505','0.188953296395903','0.188953296395903','test'),('2019-04-11 23:59:59','2019-04-12 23:59:59','XMRETH','4h','0.401340000000000','0.401360000000000','0.072669648740130','0.072673270091041','0.18106754557265603','0.181067545572656','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','XMRETH','4h','0.399910000000000','0.396070000000000','0.072670554077858','0.071972759754988','0.1817172715807495','0.181717271580749','test'),('2019-04-15 11:59:59','2019-04-15 19:59:59','XMRETH','4h','0.399650000000000','0.405390000000000','0.072670554077858','0.073714289797630','0.18183549124948828','0.181835491249488','test'),('2019-04-16 11:59:59','2019-04-16 15:59:59','XMRETH','4h','0.400460000000000','0.406950000000000','0.072757039427083','0.073936166395773','0.18168366235599814','0.181683662355998','test'),('2019-04-20 19:59:59','2019-04-20 23:59:59','XMRETH','4h','0.401280000000000','0.400720000000000','0.073051821169256','0.072949874847848','0.18204700251509048','0.182047002515090','test'),('2019-04-23 15:59:59','2019-04-23 19:59:59','XMRETH','4h','0.401790000000000','0.401750000000000','0.073051821169256','0.073044548532190','0.1818159266513751','0.181815926651375','test'),('2019-04-26 07:59:59','2019-04-26 19:59:59','XMRETH','4h','0.406910000000000','0.402800000000000','0.073051821169256','0.072313960254052','0.17952820321264162','0.179528203212642','test'),('2019-05-01 19:59:59','2019-05-02 23:59:59','XMRETH','4h','0.406670000000000','0.402210000000000','0.073051821169256','0.072250652845025','0.1796341534149458','0.179634153414946','test'),('2019-05-03 15:59:59','2019-05-06 15:59:59','XMRETH','4h','0.404410000000000','0.396040000000000','0.073051821169256','0.071539880952183','0.1806380187662422','0.180638018766242','test'),('2019-05-11 07:59:59','2019-05-11 11:59:59','XMRETH','4h','0.398440000000000','0.388380000000000','0.073051821169256','0.071207374524936','0.18334459685085835','0.183344596850858','test'),('2019-05-11 23:59:59','2019-05-12 15:59:59','XMRETH','4h','0.407500000000000','0.395150000000000','0.073051821169256','0.070837858000077','0.1792682728079902','0.179268272807990','test'),('2019-05-12 19:59:59','2019-05-13 15:59:59','XMRETH','4h','0.398090000000000','0.400000000000000','0.073051821169256','0.073402317234049','0.18350579308512147','0.183505793085121','test'),('2019-05-14 11:59:59','2019-05-14 19:59:59','XMRETH','4h','0.400280000000000','0.398920000000000','0.073051821169256','0.072803618718996','0.1825018016619766','0.182501801661977','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','XMRETH','4h','0.356070000000000','0.356990000000000','0.073051821169256','0.073240569661057','0.20516140413192913','0.205161404131929','test'),('2019-05-30 23:59:59','2019-05-31 15:59:59','XMRETH','4h','0.361740000000000','0.355200000000000','0.073051821169256','0.071731096586830','0.20194565480526344','0.201945654805263','test'),('2019-06-02 15:59:59','2019-06-02 23:59:59','XMRETH','4h','0.358020000000000','0.352990000000000','0.073051821169256','0.072025480013786','0.20404396729025195','0.204043967290252','test'),('2019-06-07 11:59:59','2019-06-07 19:59:59','XMRETH','4h','0.352670000000000','0.354010000000000','0.073051821169256','0.073329387847360','0.20713931201762556','0.207139312017626','test'),('2019-06-11 03:59:59','2019-06-11 07:59:59','XMRETH','4h','0.356140000000000','0.355770000000000','0.073051821169256','0.072975926369928','0.2051210792644915','0.205121079264491','test'),('2019-06-15 11:59:59','2019-06-15 15:59:59','XMRETH','4h','0.355340000000000','0.352390000000000','0.073051821169256','0.072445351668357','0.2055828816605392','0.205582881660539','test'),('2019-06-15 23:59:59','2019-06-16 03:59:59','XMRETH','4h','0.354110000000000','0.352490000000000','0.073051821169256','0.072717620072720','0.2062969731700771','0.206296973170077','test'),('2019-06-16 11:59:59','2019-06-16 15:59:59','XMRETH','4h','0.354110000000000','0.355480000000000','0.073051821169256','0.073334448022499','0.2062969731700771','0.206296973170077','test'),('2019-07-06 11:59:59','2019-07-08 23:59:59','XMRETH','4h','0.331120000000000','0.324190000000000','0.073051821169256','0.071522921916106','0.22062038284989127','0.220620382849891','test'),('2019-07-10 07:59:59','2019-07-10 15:59:59','XMRETH','4h','0.327670000000000','0.331480000000000','0.073051821169256','0.073901235026658','0.22294326965927913','0.222943269659279','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','XMRETH','4h','0.372670000000000','0.370220000000000','0.073051821169256','0.072571565281031','0.1960228115202619','0.196022811520262','test'),('2019-07-27 07:59:59','2019-07-29 19:59:59','XMRETH','4h','0.374270000000000','0.371230000000000','0.073051821169256','0.072458459327926','0.19518481622693779','0.195184816226938','test'),('2019-07-30 07:59:59','2019-07-30 19:59:59','XMRETH','4h','0.378470000000000','0.376460000000000','0.073051821169256','0.072663853402854','0.19301878925477847','0.193018789254778','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','XMRETH','4h','0.378890000000000','0.379010000000000','0.073051821169256','0.073074957748581','0.1928048277052865','0.192804827705287','test'),('2019-08-01 03:59:59','2019-08-13 19:59:59','XMRETH','4h','0.379190000000000','0.412960000000000','0.073051821169256','0.079557688942367','0.19265228821766395','0.192652288217664','test'),('2019-08-14 19:59:59','2019-08-19 11:59:59','XMRETH','4h','0.423050000000000','0.432620000000000','0.073051821169256','0.074704358525573','0.17267892960467085','0.172678929604671','test'),('2019-08-25 15:59:59','2019-08-25 19:59:59','XMRETH','4h','0.430280000000000','0.431030000000000','0.073051821169256','0.073179154221866','0.16977740347972484','0.169777403479725','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','XMRETH','4h','0.430700000000000','0.428990000000000','0.073051821169256','0.072761784916181','0.16961184390354306','0.169611843903543','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','XMRETH','4h','0.418660000000000','0.413560000000000','0.073051821169256','0.072161924145506','0.17448961250001435','0.174489612500014','test'),('2019-09-04 19:59:59','2019-09-04 23:59:59','XMRETH','4h','0.415790000000000','0.423250000000000','0.073051821169256','0.074362498640871','0.17569403104753842','0.175694031047538','test'),('2019-09-13 23:59:59','2019-09-14 07:59:59','XMRETH','4h','0.423790000000000','0.417500000000000','0.073051821169256','0.071967567281353','0.1723774066619222','0.172377406661922','test'),('2019-10-16 15:59:59','2019-10-19 15:59:59','XMRETH','4h','0.308430000000000','0.310000000000000','0.073051821169256','0.073423676563465','0.23685056955956296','0.236850569559563','test'),('2019-10-27 19:59:59','2019-10-28 23:59:59','XMRETH','4h','0.325220000000000','0.327080000000000','0.073051821169256','0.073469619543817','0.22462278202218805','0.224622782022188','test'),('2019-10-31 15:59:59','2019-10-31 23:59:59','XMRETH','4h','0.330500000000000','0.323790000000000','0.073051821169256','0.071568681320404','0.2210342546724841','0.221034254672484','test'),('2019-11-06 11:59:59','2019-11-06 15:59:59','XMRETH','4h','0.333540000000000','0.333270000000000','0.073051821169256','0.072992685858002','0.21901967131155484','0.219019671311555','test'),('2019-11-09 07:59:59','2019-11-09 11:59:59','XMRETH','4h','0.333970000000000','0.335190000000000','0.073051821169256','0.073318681132206','0.2187376745493787','0.218737674549379','test'),('2019-11-09 23:59:59','2019-11-10 07:59:59','XMRETH','4h','0.335270000000000','0.335830000000000','0.073051821169256','0.073173839303461','0.21788952536539505','0.217889525365395','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','XMRETH','4h','0.336470000000000','0.333620000000000','0.073051821169256','0.072433050728110','0.2171124354898089','0.217112435489809','test'),('2019-11-13 07:59:59','2019-11-16 03:59:59','XMRETH','4h','0.339980000000000','0.340300000000000','0.073051821169256','0.073120579869104','0.21487093702351903','0.214870937023519','test'),('2019-11-17 07:59:59','2019-11-17 11:59:59','XMRETH','4h','0.342140000000000','0.338320000000000','0.073051821169256','0.072236196112652','0.21351441272361021','0.213514412723610','test'),('2019-11-19 19:59:59','2019-11-19 23:59:59','XMRETH','4h','0.339980000000000','0.332910000000000','0.073051821169256','0.071532683644500','0.21487093702351903','0.214870937023519','test'),('2019-11-22 03:59:59','2019-11-22 07:59:59','XMRETH','4h','0.339330000000000','0.337400000000000','0.073051821169256','0.072636325884852','0.21528253077905282','0.215282530779053','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','XMRETH','4h','0.341360000000000','0.334630000000000','0.073051821169256','0.071611585768304','0.2140022884030232','0.214002288403023','test'),('2019-11-23 07:59:59','2019-11-23 11:59:59','XMRETH','4h','0.337960000000000','0.339630000000000','0.073051821169256','0.073412800401569','0.2161552289302166','0.216155228930217','test'),('2019-12-09 15:59:59','2019-12-10 19:59:59','XMRETH','4h','0.361590000000000','0.363530000000000','0.073051821169256','0.073443758261179','0.20202942882617328','0.202029428826173','test'),('2019-12-16 19:59:59','2019-12-17 15:59:59','XMRETH','4h','0.372030000000000','0.366010000000000','0.073051821169256','0.071869733801466','0.19636002787209633','0.196360027872096','test'),('2019-12-19 03:59:59','2019-12-20 15:59:59','XMRETH','4h','0.366640000000000','0.366450000000000','0.073051821169256','0.073013964290513','0.19924673022380535','0.199246730223805','test'),('2019-12-23 19:59:59','2019-12-24 11:59:59','XMRETH','4h','0.372800000000000','0.369620000000000','0.073051821169256','0.072428685999411','0.19595445592611588','0.195954455926116','test'),('2019-12-25 07:59:59','2019-12-25 15:59:59','XMRETH','4h','0.372000000000000','0.364880000000000','0.073051821169256','0.071653625022146','0.19637586335821505','0.196375863358215','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 16:15:09
