-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-10 19:59:59','POAETH','4h','0.000207470000000','0.000199510000000','0.072144500000000','0.069376532486625','347.73461223309397','347.734612233093969','test'),('2019-01-11 07:59:59','2019-01-11 11:59:59','POAETH','4h','0.000201320000000','0.000205400000000','0.072144500000000','0.073606597953507','358.35734154579774','358.357341545797738','test'),('2019-02-01 11:59:59','2019-02-01 23:59:59','POAETH','4h','0.000251000000000','0.000252510000000','0.072144500000000','0.072578516713147','287.4282868525897','287.428286852589679','test'),('2019-02-03 07:59:59','2019-02-03 11:59:59','POAETH','4h','0.000251220000000','0.000250640000000','0.072144500000000','0.071977937584587','287.1765782979062','287.176578297906190','test'),('2019-02-04 03:59:59','2019-02-04 15:59:59','POAETH','4h','0.000255230000000','0.000250000000000','0.072144500000000','0.070666163852212','282.6646554088469','282.664655408846897','test'),('2019-02-26 03:59:59','2019-02-27 15:59:59','POAETH','4h','0.000203470000000','0.000200170000000','0.072144500000000','0.070974416695336','354.57069838305404','354.570698383054037','test'),('2019-03-06 15:59:59','2019-03-16 07:59:59','POAETH','4h','0.000215540000000','0.000237990000000','0.072144500000000','0.079658854760137','334.7151340818409','334.715134081840915','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','POAETH','4h','0.000236160000000','0.000236390000000','0.073101380011388','0.073172574614211','309.54175140323406','309.541751403234059','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','POAETH','4h','0.000234910000000','0.000240500000000','0.073119178662093','0.074859148049182','311.2646488531501','311.264648853150106','test'),('2019-04-11 03:59:59','2019-04-11 11:59:59','POAETH','4h','0.000252010000000','0.000234830000000','0.073554171008866','0.068539843569747','291.8700488427671','291.870048842767119','test'),('2019-04-12 03:59:59','2019-04-12 07:59:59','POAETH','4h','0.000248440000000','0.000245620000000','0.073554171008866','0.072719270178706','296.0641241702866','296.064124170286618','test'),('2019-04-13 23:59:59','2019-04-16 15:59:59','POAETH','4h','0.000247520000000','0.000246180000000','0.073554171008866','0.073155970503243','297.16455643530225','297.164556435302245','test'),('2019-04-17 07:59:59','2019-04-18 03:59:59','POAETH','4h','0.000248410000000','0.000247160000000','0.073554171008866','0.073184046159781','296.09987926760596','296.099879267605957','test'),('2019-04-18 23:59:59','2019-04-19 03:59:59','POAETH','4h','0.000248390000000','0.000250090000000','0.073554171008866','0.074057581334222','296.12372079739924','296.123720797399244','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','POAETH','4h','0.000134520000000','0.000125510000000','0.073554171008866','0.068627594434454','546.7898528758996','546.789852875899555','test'),('2019-05-22 19:59:59','2019-05-23 03:59:59','POAETH','4h','0.000139780000000','0.000133770000000','0.073554171008866','0.070391625810960','526.2138432455716','526.213843245571638','test'),('2019-05-26 03:59:59','2019-05-26 19:59:59','POAETH','4h','0.000135960000000','0.000127760000000','0.073554171008866','0.069117982407272','540.9986099504708','540.998609950470836','test'),('2019-05-26 23:59:59','2019-05-30 03:59:59','POAETH','4h','0.000154040000000','0.000143360000000','0.073554171008866','0.068454466085634','477.50046097679825','477.500460976798252','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','POAETH','4h','0.000140040000000','0.000138930000000','0.073554171008866','0.072971158085274','525.236868101014','525.236868101014011','test'),('2019-06-08 23:59:59','2019-06-09 11:59:59','POAETH','4h','0.000142780000000','0.000139020000000','0.073554171008866','0.071617179252364','515.1573820483682','515.157382048368163','test'),('2019-06-10 07:59:59','2019-06-11 07:59:59','POAETH','4h','0.000141380000000','0.000141260000000','0.073554171008866','0.073491739968259','520.2586717277268','520.258671727726778','test'),('2019-06-12 19:59:59','2019-06-13 19:59:59','POAETH','4h','0.000157260000000','0.000140000000000','0.073554171008866','0.065481266318461','467.7233308461529','467.723330846152919','test'),('2019-06-16 11:59:59','2019-06-16 15:59:59','POAETH','4h','0.000142830000000','0.000135610000000','0.073554171008866','0.069836036760571','514.977042700175','514.977042700175048','test'),('2019-06-19 23:59:59','2019-06-20 03:59:59','POAETH','4h','0.000140430000000','0.000137790000000','0.073554171008866','0.072171396591267','523.7781884844122','523.778188484412226','test'),('2019-06-24 19:59:59','2019-06-24 23:59:59','POAETH','4h','0.000134000000000','0.000129000000000','0.073554171008866','0.070809612389132','548.9117239467612','548.911723946761185','test'),('2019-06-25 11:59:59','2019-06-25 15:59:59','POAETH','4h','0.000130550000000','0.000124570000000','0.073554171008866','0.070184933608383','563.4176254987822','563.417625498782172','test'),('2019-07-22 15:59:59','2019-07-24 23:59:59','POAETH','4h','0.000096470000000','0.000096470000000','0.073554171008866','0.073554171008866','762.4564217774024','762.456421777402397','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','POAETH','4h','0.000097630000000','0.000096730000000','0.073554171008866','0.072876113506992','753.397224304681','753.397224304681004','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','POAETH','4h','0.000097750000000','0.000096750000000','0.073554171008866','0.072801698671179','752.4723376866087','752.472337686608739','test'),('2019-08-12 11:59:59','2019-08-12 19:59:59','POAETH','4h','0.000081430000000','0.000075470000000','0.073554171008866','0.068170616308966','903.2809899160752','903.280989916075214','test'),('2019-08-18 23:59:59','2019-08-19 03:59:59','POAETH','4h','0.000082580000000','0.000074250000000','0.073554171008866','0.066134623364111','890.7019981698476','890.701998169847570','test'),('2019-08-19 23:59:59','2019-08-20 03:59:59','POAETH','4h','0.000074630000000','0.000073800000000','0.073554171008866','0.072736135876381','985.5844969699318','985.584496969931820','test'),('2019-08-21 19:59:59','2019-08-22 03:59:59','POAETH','4h','0.000074810000000','0.000074590000000','0.073554171008866','0.073337864129813','983.2130866042776','983.213086604277578','test'),('2019-08-29 19:59:59','2019-08-31 19:59:59','POAETH','4h','0.000091860000000','0.000080760000000','0.073554171008866','0.064666175165208','800.7203462754844','800.720346275484417','test'),('2019-09-09 23:59:59','2019-09-10 03:59:59','POAETH','4h','0.000077780000000','0.000076140000000','0.073554171008866','0.072003273085820','945.6694652721266','945.669465272126558','test'),('2019-09-13 15:59:59','2019-09-14 23:59:59','POAETH','4h','0.000079050000000','0.000078470000000','0.073554171008866','0.073014494611837','930.4765466017205','930.476546601720543','test'),('2019-09-16 19:59:59','2019-09-16 23:59:59','POAETH','4h','0.000080190000000','0.000084910000000','0.073554171008866','0.077883584740776','917.2486720147899','917.248672014789918','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','POAETH','4h','0.000084140000000','0.000078990000000','0.073554171008866','0.069052103256362','874.1879131075113','874.187913107511349','test'),('2019-09-23 11:59:59','2019-09-23 23:59:59','POAETH','4h','0.000081440000000','0.000075420000000','0.073554171008866','0.068117087149910','903.1700762385315','903.170076238531465','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','POAETH','4h','0.000082340000000','0.000078060000000','0.049036114005911','0.046487236571550','595.5321108320461','595.532110832046101','test'),('2019-10-12 15:59:59','2019-10-12 19:59:59','POAETH','4h','0.000097460000000','0.000099680000000','0.053550580167268','0.054770386118133','549.4621400294295','549.462140029429520','test'),('2019-10-13 11:59:59','2019-10-13 15:59:59','POAETH','4h','0.000096340000000','0.000093200000000','0.053855531654984','0.052100223689480','559.0152756382028','559.015275638202752','test'),('2019-10-14 15:59:59','2019-10-15 23:59:59','POAETH','4h','0.000101590000000','0.000098990000000','0.053855531654984','0.052477203253537','530.126308248686','530.126308248685973','test'),('2019-10-17 11:59:59','2019-10-18 07:59:59','POAETH','4h','0.000101010000000','0.000094780000000','0.053855531654984','0.050533880707449','533.1702965546382','533.170296554638185','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','POAETH','4h','0.000097520000000','0.000100220000000','0.053855531654984','0.055346609746334','552.2511449444627','552.251144944462681','test'),('2019-10-30 15:59:59','2019-10-30 19:59:59','POAETH','4h','0.000096840000000','0.000095680000000','0.053855531654984','0.053210422023429','556.1289927197853','556.128992719785288','test'),('2019-11-03 19:59:59','2019-11-03 23:59:59','POAETH','4h','0.000095720000000','0.000094670000000','0.053855531654984','0.053264763704318','562.6361434912662','562.636143491266239','test'),('2019-11-04 03:59:59','2019-11-04 07:59:59','POAETH','4h','0.000095300000000','0.000094280000000','0.053855531654984','0.053279113582706','565.1157571351941','565.115757135194144','test'),('2019-11-17 07:59:59','2019-11-17 15:59:59','POAETH','4h','0.000088650000000','0.000089550000000','0.053855531654984','0.054402288321532','607.5074072756232','607.507407275623223','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','POAETH','4h','0.000088280000000','0.000087630000000','0.053855531654984','0.053458996816111','610.0535982666969','610.053598266696895','test'),('2019-12-03 07:59:59','2019-12-03 11:59:59','POAETH','4h','0.000096840000000','0.000096300000000','0.053855531654984','0.053555221998915','556.1289927197853','556.128992719785288','test'),('2019-12-06 11:59:59','2019-12-10 03:59:59','POAETH','4h','0.000099390000000','0.000093560000000','0.053855531654984','0.050696483968612','541.8606666161988','541.860666616198841','test'),('2019-12-18 07:59:59','2019-12-19 11:59:59','POAETH','4h','0.000096320000000','0.000096840000000','0.053855531654984','0.054146279957108','559.1313502386213','559.131350238621280','test'),('2019-12-24 11:59:59','2019-12-24 15:59:59','POAETH','4h','0.000096840000000','0.000094350000000','0.053855531654984','0.052470770463112','556.1289927197853','556.128992719785288','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:51:09
