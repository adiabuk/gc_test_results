-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 23:59:59','2019-01-07 03:59:59','ENGETH','4h','0.002168200000000','0.002183300000000','0.072144500000000','0.072646936099068','33.2739138455862','33.273913845586200','test'),('2019-01-07 11:59:59','2019-01-14 19:59:59','ENGETH','4h','0.002196200000000','0.002242800000000','0.072270109024767','0.073803570039499','32.9068887281518','32.906888728151799','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','ENGETH','4h','0.002295200000000','0.002285900000000','0.072653474278450','0.072359087161515','31.654528702705647','31.654528702705647','test'),('2019-01-20 07:59:59','2019-01-20 11:59:59','ENGETH','4h','0.002359900000000','0.002350800000000','0.072653474278450','0.072373315536158','30.78667497709649','30.786674977096489','test'),('2019-01-20 23:59:59','2019-01-21 03:59:59','ENGETH','4h','0.002362300000000','0.002365500000000','0.072653474278450','0.072751891548776','30.755396976865764','30.755396976865764','test'),('2019-01-22 11:59:59','2019-01-27 15:59:59','ENGETH','4h','0.002370400000000','0.002469000000000','0.072653474278450','0.075675593989830','30.650301332454436','30.650301332454436','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENGETH','4h','0.002486100000000','0.002478200000000','0.073289972059070','0.073057080872365','29.479897051232754','29.479897051232754','test'),('2019-01-31 23:59:59','2019-02-01 07:59:59','ENGETH','4h','0.002492500000000','0.002477400000000','0.073289972059070','0.072845968617509','29.404201427911733','29.404201427911733','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','ENGETH','4h','0.002507300000000','0.002468600000000','0.073289972059070','0.072158746470315','29.23063536835241','29.230635368352409','test'),('2019-02-04 15:59:59','2019-02-04 19:59:59','ENGETH','4h','0.002594800000000','0.002430700000000','0.073289972059070','0.068654977294582','28.24494067329659','28.244940673296590','test'),('2019-02-08 11:59:59','2019-02-08 15:59:59','ENGETH','4h','0.002473400000000','0.002333800000000','0.073289972059070','0.069153447396886','29.631265488424837','29.631265488424837','test'),('2019-02-09 23:59:59','2019-02-11 19:59:59','ENGETH','4h','0.002582600000000','0.002498000000000','0.073289972059070','0.070889162163539','28.378367559463328','28.378367559463328','test'),('2019-02-12 11:59:59','2019-02-12 23:59:59','ENGETH','4h','0.002487000000000','0.002473500000000','0.073289972059070','0.072892137470088','29.469228813457978','29.469228813457978','test'),('2019-02-13 15:59:59','2019-02-14 07:59:59','ENGETH','4h','0.002493300000000','0.002501200000000','0.073289972059070','0.073522190716779','29.394766798648376','29.394766798648376','test'),('2019-02-21 23:59:59','2019-02-22 03:59:59','ENGETH','4h','0.002408700000000','0.002353200000000','0.073289972059070','0.071601263025451','30.427189794939174','30.427189794939174','test'),('2019-02-22 23:59:59','2019-02-23 19:59:59','ENGETH','4h','0.002459600000000','0.002300500000000','0.073289972059070','0.068549187153151','29.79751669339323','29.797516693393231','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','ENGETH','4h','0.002405400000000','0.002407500000000','0.073289972059070','0.073353956818912','30.468933258115076','30.468933258115076','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','ENGETH','4h','0.002470800000000','0.002431400000000','0.073289972059070','0.072121271678980','29.66244619518779','29.662446195187790','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','ENGETH','4h','0.002453700000000','0.002458600000000','0.073289972059070','0.073436330971361','29.869165773757995','29.869165773757995','test'),('2019-03-18 19:59:59','2019-03-19 11:59:59','ENGETH','4h','0.003015500000000','0.003014900000000','0.073289972059070','0.073275389408354','24.304417860742827','24.304417860742827','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','ENGETH','4h','0.004085100000000','0.004081500000000','0.073289972059070','0.073225385170276','17.94080244279699','17.940802442796990','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','ENGETH','4h','0.004048800000000','0.003894900000000','0.073289972059070','0.070504127685455','18.101652849997528','18.101652849997528','test'),('2019-04-05 11:59:59','2019-04-06 15:59:59','ENGETH','4h','0.004058300000000','0.003902600000000','0.073289972059070','0.070478142315188','18.059279023007168','18.059279023007168','test'),('2019-04-20 19:59:59','2019-04-20 23:59:59','ENGETH','4h','0.003194100000000','0.003096000000000','0.073289972059070','0.071039026171654','22.945421890069188','22.945421890069188','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','ENGETH','4h','0.003217300000000','0.002970000000000','0.073289972059070','0.067656487432144','22.779962098365086','22.779962098365086','test'),('2019-05-02 19:59:59','2019-05-03 11:59:59','ENGETH','4h','0.002734800000000','0.002708600000000','0.073289972059070','0.072587837618545','26.799024447517183','26.799024447517183','test'),('2019-05-22 23:59:59','2019-05-23 03:59:59','ENGETH','4h','0.002060300000000','0.001986600000000','0.073289972059070','0.070668280586589','35.572475881701685','35.572475881701685','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','ENGETH','4h','0.002004300000000','0.001977000000000','0.073289972059070','0.072291710203453','36.566368337609134','36.566368337609134','test'),('2019-06-04 07:59:59','2019-06-04 19:59:59','ENGETH','4h','0.001845000000000','0.001850000000000','0.073289972059070','0.073488589869528','39.72356209163685','39.723562091636850','test'),('2019-06-18 15:59:59','2019-06-18 19:59:59','ENGETH','4h','0.002144200000000','0.002160000000000','0.073289972059070','0.073830025019863','34.180567138825666','34.180567138825666','test'),('2019-06-19 11:59:59','2019-06-19 15:59:59','ENGETH','4h','0.002162900000000','0.002162400000000','0.073289972059070','0.073273029534668','33.88504880441536','33.885048804415362','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','ENGETH','4h','0.001911000000000','0.001885200000000','0.073289972059070','0.072300499908822','38.351633730544215','38.351633730544215','test'),('2019-07-03 15:59:59','2019-07-03 19:59:59','ENGETH','4h','0.001898200000000','0.001904900000000','0.073289972059070','0.073548660718219','38.61024763411126','38.610247634111261','test'),('2019-07-04 23:59:59','2019-07-09 07:59:59','ENGETH','4h','0.001932900000000','0.002010800000000','0.073289972059070','0.076243714530694','37.91710489889285','37.917104898892852','test'),('2019-07-22 19:59:59','2019-07-22 23:59:59','ENGETH','4h','0.002093700000000','0.002083700000000','0.073289972059070','0.072939922042071','35.00500169989492','35.005001699894919','test'),('2019-07-30 19:59:59','2019-08-02 03:59:59','ENGETH','4h','0.002155500000000','0.002119600000000','0.073289972059070','0.072069322559223','34.001378825826954','34.001378825826954','test'),('2019-08-05 23:59:59','2019-08-06 07:59:59','ENGETH','4h','0.002146600000000','0.002010200000000','0.073289972059070','0.068632955293554','34.142351653344825','34.142351653344825','test'),('2019-08-17 03:59:59','2019-08-17 07:59:59','ENGETH','4h','0.001970500000000','0.001976400000000','0.073289972059070','0.073509414248945','37.193591504222276','37.193591504222276','test'),('2019-08-17 15:59:59','2019-08-18 07:59:59','ENGETH','4h','0.001972100000000','0.001968900000000','0.073289972059070','0.073171049128900','37.16341567824654','37.163415678246537','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','ENGETH','4h','0.001977800000000','0.002008700000000','0.073289972059070','0.074435012071521','37.05631108255132','37.056311082551318','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','ENGETH','4h','0.001759000000000','0.001767100000000','0.073289972059070','0.073627464255590','41.66570327405912','41.665703274059119','test'),('2019-09-20 19:59:59','2019-09-20 23:59:59','ENGETH','4h','0.001748800000000','0.001745300000000','0.073289972059070','0.073143291534020','41.90872144274359','41.908721442743591','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','ENGETH','4h','0.001820200000000','0.001748700000000','0.073289972059070','0.070411039522962','40.264790714795076','40.264790714795076','test'),('2019-10-02 11:59:59','2019-10-08 03:59:59','ENGETH','4h','0.001745000000000','0.001880200000000','0.073289972059070','0.078968369894248','41.999983988005724','41.999983988005724','test'),('2019-10-12 19:59:59','2019-10-13 11:59:59','ENGETH','4h','0.001799800000000','0.001766200000000','0.073289972059070','0.071921740554911','40.72117571900766','40.721175719007661','test'),('2019-10-20 07:59:59','2019-10-20 11:59:59','ENGETH','4h','0.001703900000000','0.001675900000000','0.073289972059070','0.072085606064790','43.01307122429133','43.013071224291330','test'),('2019-10-20 15:59:59','2019-10-22 23:59:59','ENGETH','4h','0.001750700000000','0.001720400000000','0.073289972059070','0.072021515925301','41.86323873825898','41.863238738258978','test'),('2019-10-24 15:59:59','2019-10-24 23:59:59','ENGETH','4h','0.001744400000000','0.001738700000000','0.073289972059070','0.073050489806871','42.014430210427655','42.014430210427655','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','ENGETH','4h','0.001697300000000','0.001690300000000','0.073289972059070','0.072987709757524','43.180328792240616','43.180328792240616','test'),('2019-11-03 11:59:59','2019-11-04 07:59:59','ENGETH','4h','0.001773400000000','0.001640300000000','0.073289972059070','0.067789298053734','41.327377951432275','41.327377951432275','test'),('2019-11-07 15:59:59','2019-11-07 19:59:59','ENGETH','4h','0.001650600000000','0.001618200000000','0.073289972059070','0.071851346653330','44.40201869566824','44.402018695668239','test'),('2019-11-12 07:59:59','2019-11-12 11:59:59','ENGETH','4h','0.001605800000000','0.001560200000000','0.073289972059070','0.071208752277096','45.640784692408765','45.640784692408765','test'),('2019-11-13 15:59:59','2019-11-13 19:59:59','ENGETH','4h','0.001602700000000','0.001589600000000','0.073289972059070','0.072690921310974','45.729064740169704','45.729064740169704','test'),('2019-11-16 19:59:59','2019-11-21 11:59:59','ENGETH','4h','0.001658200000000','0.001906300000000','0.073289972059070','0.084255622805575','44.198511674749724','44.198511674749724','test'),('2019-12-04 15:59:59','2019-12-04 23:59:59','ENGETH','4h','0.003283500000000','0.003053600000000','0.073289972059070','0.068158446377212','22.320685871499922','22.320685871499922','test'),('2019-12-05 11:59:59','2019-12-05 15:59:59','ENGETH','4h','0.003151400000000','0.003134700000000','0.073289972059070','0.072901591487455','23.256321653573014','23.256321653573014','test'),('2019-12-05 19:59:59','2019-12-08 23:59:59','ENGETH','4h','0.003432300000000','0.003349900000000','0.073289972059070','0.071530483174745','21.353020440832676','21.353020440832676','test'),('2019-12-12 23:59:59','2019-12-14 15:59:59','ENGETH','4h','0.003358900000000','0.003257300000000','0.073289972059070','0.071073097141329','21.819635017139536','21.819635017139536','test'),('2019-12-15 11:59:59','2019-12-15 15:59:59','ENGETH','4h','0.003314800000000','0.003297600000000','0.073289972059070','0.072909681387109','22.109922788424637','22.109922788424637','test'),('2019-12-15 19:59:59','2019-12-16 07:59:59','ENGETH','4h','0.003340100000000','0.003315200000000','0.073289972059070','0.072743605092730','21.942448447372833','21.942448447372833','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','ENGETH','4h','0.003410900000000','0.003327700000000','0.073289972059070','0.071502254543073','21.48698937496555','21.486989374965550','test'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ENGETH','4h','0.003224000000000','0.003128000000000','0.073289972059070','0.071107640384855','22.73262160641129','22.732621606411289','test'),('2019-12-21 15:59:59','2019-12-22 11:59:59','ENGETH','4h','0.003420900000000','0.003204100000000','0.073289972059070','0.068645210171144','21.424178449843605','21.424178449843605','test'),('2019-12-23 19:59:59','2019-12-23 23:59:59','ENGETH','4h','0.003232700000000','0.003270500000000','0.073289972059070','0.074146952584276','22.671442465762365','22.671442465762365','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:15:47
