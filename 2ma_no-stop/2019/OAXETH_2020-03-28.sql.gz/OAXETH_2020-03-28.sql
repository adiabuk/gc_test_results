-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 15:59:59','2019-01-08 19:59:59','OAXETH','4h','0.000663500000000','0.000648500000000','0.072144500000000','0.070513501507159','108.73323285606631','108.733232856066309','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','OAXETH','4h','0.000654400000000','0.000642100000000','0.072144500000000','0.070788483267115','110.24526283618583','110.245262836185830','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','OAXETH','4h','0.000660800000000','0.000656200000000','0.072144500000000','0.071642283444310','109.17751210653753','109.177512106537534','test'),('2019-01-27 23:59:59','2019-01-28 07:59:59','OAXETH','4h','0.001330000000000','0.001319800000000','0.072144500000000','0.071591211353383','54.24398496240602','54.243984962406017','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','OAXETH','4h','0.001260000000000','0.001242800000000','0.072144500000000','0.071159670317460','57.25753968253968','57.257539682539679','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','OAXETH','4h','0.001273800000000','0.001248500000000','0.072144500000000','0.070711578151986','56.637227194222014','56.637227194222014','test'),('2019-02-02 07:59:59','2019-02-02 15:59:59','OAXETH','4h','0.001247800000000','0.001253600000000','0.072144500000000','0.072479840679596','57.81735855104984','57.817358551049843','test'),('2019-02-26 11:59:59','2019-02-26 23:59:59','OAXETH','4h','0.000965000000000','0.000935000000000','0.072144500000000','0.069901665803109','74.76113989637305','74.761139896373052','test'),('2019-03-01 15:59:59','2019-03-01 19:59:59','OAXETH','4h','0.000935300000000','0.000934000000000','0.072144500000000','0.072044224313055','77.13514380412701','77.135143804127011','test'),('2019-03-06 03:59:59','2019-03-06 07:59:59','OAXETH','4h','0.000960000000000','0.000938600000000','0.072144500000000','0.070536278854167','75.15052083333333','75.150520833333331','test'),('2019-03-06 19:59:59','2019-03-07 07:59:59','OAXETH','4h','0.000956100000000','0.000946600000000','0.072144500000000','0.071427657880975','75.45706516054805','75.457065160548055','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','OAXETH','4h','0.001123700000000','0.002593600000000','0.072144500000000','0.166515951944469','64.20263415502357','64.202634155023574','test'),('2019-04-09 19:59:59','2019-04-10 11:59:59','OAXETH','4h','0.001642600000000','0.001404300000000','0.093039086879196','0.079541452395261','56.64135326871789','56.641353268717893','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','OAXETH','4h','0.001480000000000','0.001610000000000','0.093039086879196','0.101211439105071','62.86424789134865','62.864247891348647','test'),('2019-04-15 11:59:59','2019-04-15 19:59:59','OAXETH','4h','0.001463000000000','0.001490900000000','0.093039086879196','0.094813379786872','63.59472787368147','63.594727873681471','test'),('2019-04-20 11:59:59','2019-04-20 15:59:59','OAXETH','4h','0.001449000000000','0.001425900000000','0.093039086879196','0.091555855059383','64.20916968888613','64.209169688886135','test'),('2019-05-06 11:59:59','2019-05-06 15:59:59','OAXETH','4h','0.001233800000000','0.001139200000000','0.093039086879196','0.085905436677565','75.40856449926731','75.408564499267314','test'),('2019-05-22 15:59:59','2019-05-24 15:59:59','OAXETH','4h','0.000954800000000','0.000878200000000','0.093039086879196','0.085574912125377','97.4435346451571','97.443534645157101','test'),('2019-05-26 11:59:59','2019-05-26 15:59:59','OAXETH','4h','0.000899600000000','0.000922600000000','0.093039086879196','0.095417809642893','103.42272885637617','103.422728856376168','test'),('2019-06-07 15:59:59','2019-06-09 19:59:59','OAXETH','4h','0.000864100000000','0.000850900000000','0.093039086879196','0.091617820883587','107.67166633398449','107.671666333984490','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','OAXETH','4h','0.000883200000000','0.000822200000000','0.093039086879196','0.086613153568925','105.34316902082881','105.343169020828810','test'),('2019-06-15 03:59:59','2019-06-15 19:59:59','OAXETH','4h','0.000878200000000','0.000862000000000','0.093039086879196','0.091322811307068','105.94293655112276','105.942936551122756','test'),('2019-06-19 03:59:59','2019-06-19 07:59:59','OAXETH','4h','0.000863400000000','0.000848800000000','0.093039086879196','0.091465806049411','107.75896094416957','107.758960944169573','test'),('2019-06-20 07:59:59','2019-06-20 11:59:59','OAXETH','4h','0.000909400000000','0.000859500000000','0.093039086879196','0.087933907161501','102.30821077545195','102.308210775451954','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','OAXETH','4h','0.000621000000000','0.000600300000000','0.093039086879196','0.089937783983223','149.8213959407343','149.821395940734305','test'),('2019-07-22 15:59:59','2019-07-23 07:59:59','OAXETH','4h','0.000489200000000','0.000470800000000','0.093039086879196','0.089539660880469','190.18619558298448','190.186195582984482','test'),('2019-07-26 11:59:59','2019-07-26 23:59:59','OAXETH','4h','0.000476500000000','0.000466300000000','0.093039086879196','0.091047484179998','195.2551665880294','195.255166588029397','test'),('2019-08-21 15:59:59','2019-08-22 11:59:59','OAXETH','4h','0.000417200000000','0.000397100000000','0.093039086879196','0.088556618887173','223.00835781207095','223.008357812070955','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','OAXETH','4h','0.000402500000000','0.000394100000000','0.093039086879196','0.091097401587804','231.15301087999006','231.153010879990063','test'),('2019-08-24 07:59:59','2019-08-26 03:59:59','OAXETH','4h','0.000412800000000','0.000419400000000','0.093039086879196','0.094526630419416','225.38538488177326','225.385384881773263','test'),('2019-09-01 07:59:59','2019-09-02 03:59:59','OAXETH','4h','0.000455900000000','0.000442500000000','0.093039086879196','0.090304443834271','204.07783917349417','204.077839173494169','test'),('2019-09-10 19:59:59','2019-09-10 23:59:59','OAXETH','4h','0.000419900000000','0.000415200000000','0.093039086879196','0.091997687240396','221.57439123409384','221.574391234093838','test'),('2019-09-11 15:59:59','2019-09-11 19:59:59','OAXETH','4h','0.000420100000000','0.000393600000000','0.093039086879196','0.087170160903717','221.46890473505354','221.468904735053542','test'),('2019-09-21 23:59:59','2019-09-22 03:59:59','OAXETH','4h','0.000382000000000','0.000385800000000','0.093039086879196','0.093964606591607','243.5578190554869','243.557819055486902','test'),('2019-09-30 23:59:59','2019-10-01 03:59:59','OAXETH','4h','0.000373700000000','0.000369600000000','0.093039086879196','0.092018320873832','248.96731838157882','248.967318381578821','test'),('2019-10-16 19:59:59','2019-10-18 03:59:59','OAXETH','4h','0.000418400000000','0.000400000000000','0.093039086879196','0.088947501796555','222.36875449138626','222.368754491386255','test'),('2019-10-21 19:59:59','2019-10-21 23:59:59','OAXETH','4h','0.000396600000000','0.000393800000000','0.093039086879196','0.092382229987462','234.59174704789714','234.591747047897144','test'),('2019-10-24 15:59:59','2019-10-25 07:59:59','OAXETH','4h','0.000399500000000','0.000395300000000','0.093039086879196','0.092060953800616','232.8888282332816','232.888828233281600','test'),('2019-10-28 11:59:59','2019-10-29 19:59:59','OAXETH','4h','0.000418800000000','0.000390400000000','0.093039086879196','0.086729846030655','222.1563679063897','222.156367906389704','test'),('2019-11-20 23:59:59','2019-11-21 11:59:59','OAXETH','4h','0.000387500000000','0.000373500000000','0.093039086879196','0.089677674708077','240.1008693656671','240.100869365667108','test'),('2019-11-25 19:59:59','2019-11-27 19:59:59','OAXETH','4h','0.000393900000000','0.000393800000000','0.093039086879196','0.093015466902837','236.1997635927799','236.199763592779902','test'),('2019-12-06 11:59:59','2019-12-08 03:59:59','OAXETH','4h','0.000415000000000','0.000417400000000','0.093039086879196','0.093577144249100','224.19057079324338','224.190570793243381','test'),('2019-12-19 23:59:59','2019-12-20 03:59:59','OAXETH','4h','0.000393100000000','0.000387800000000','0.093039086879196','0.091784680467444','236.6804550475604','236.680455047560400','test'),('2019-12-24 03:59:59','2019-12-24 07:59:59','OAXETH','4h','0.000395900000000','0.000389200000000','0.093039086879196','0.091464543100235','235.006534173266','235.006534173266004','test'),('2019-12-24 15:59:59','2019-12-24 19:59:59','OAXETH','4h','0.000406200000000','0.000389200000000','0.093039086879196','0.089145279698137','229.04748123878878','229.047481238788777','test'),('2019-12-24 23:59:59','2019-12-25 03:59:59','OAXETH','4h','0.000394100000000','0.000396200000000','0.093039086879196','0.093534854660080','236.07989565895966','236.079895658959657','test'),('2019-12-25 11:59:59','2019-12-25 15:59:59','OAXETH','4h','0.000395100000000','0.000397400000000','0.093039086879196','0.093580696344704','235.48237630776006','235.482376307760063','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','OAXETH','4h','0.000394200000000','0.000395800000000','0.093039086879196','0.093416718890882','236.0200073038965','236.020007303896506','test'),('2019-12-27 07:59:59','2019-12-27 11:59:59','OAXETH','4h','0.000395900000000','0.000386800000000','0.093039086879196','0.090900527418219','235.006534173266','235.006534173266004','test'),('2019-12-27 19:59:59','2019-12-27 23:59:59','OAXETH','4h','0.000395800000000','0.000399100000000','0.093039086879196','0.093814804379705','235.06590924506315','235.065909245063153','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 20:17:35
