-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 15:59:59','2019-01-08 07:59:59','NAVBNB','4h','0.028790000000000','0.027980000000000','0.711908500000000','0.691879118791247','24.727631121917334','24.727631121917334','test'),('2019-01-15 15:59:59','2019-01-16 11:59:59','NAVBNB','4h','0.028100000000000','0.026400000000000','0.711908500000000','0.668839302491103','25.33482206405694','25.334822064056940','test'),('2019-01-17 19:59:59','2019-01-17 23:59:59','NAVBNB','4h','0.027570000000000','0.026920000000000','0.711908500000000','0.695124295248459','25.82185346391005','25.821853463910049','test'),('2019-01-18 15:59:59','2019-01-18 23:59:59','NAVBNB','4h','0.027970000000000','0.026720000000000','0.711908500000000','0.680092782266714','25.452574186628535','25.452574186628535','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','NAVBNB','4h','0.027220000000000','0.026760000000000','0.711908500000000','0.699877717119765','26.15387582659809','26.153875826598089','test'),('2019-01-20 07:59:59','2019-01-20 11:59:59','NAVBNB','4h','0.027010000000000','0.024970000000000','0.711908500000000','0.658139772121436','26.35721954831544','26.357219548315442','test'),('2019-01-22 03:59:59','2019-01-22 07:59:59','NAVBNB','4h','0.027680000000000','0.027050000000000','0.711908500000000','0.695705380238439','25.719237716763008','25.719237716763008','test'),('2019-01-23 11:59:59','2019-01-23 19:59:59','NAVBNB','4h','0.026810000000000','0.025640000000000','0.711908500000000','0.680840505035435','26.55384185005595','26.553841850055949','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','NAVBNB','4h','0.016070000000000','0.016020000000000','0.711908500000000','0.709693476664592','44.30046670815184','44.300466708151838','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','NAVBNB','4h','0.016420000000000','0.016240000000000','0.711908500000000','0.704104387332521','43.35618148599269','43.356181485992693','test'),('2019-03-12 19:59:59','2019-03-12 23:59:59','NAVBNB','4h','0.013520000000000','0.012560000000000','0.711908500000000','0.661358784023669','52.655954142011836','52.655954142011836','test'),('2019-03-13 07:59:59','2019-03-13 11:59:59','NAVBNB','4h','0.012880000000000','0.012300000000000','0.711908500000000','0.679850508540373','55.27239906832298','55.272399068322983','test'),('2019-03-17 11:59:59','2019-03-17 15:59:59','NAVBNB','4h','0.013030000000000','0.012920000000000','0.711908500000000','0.705898528012279','54.63610897927859','54.636108979278589','test'),('2019-03-20 07:59:59','2019-03-23 07:59:59','NAVBNB','4h','0.012950000000000','0.012490000000000','0.711908500000000','0.686620630501931','54.97362934362935','54.973629343629348','test'),('2019-03-23 11:59:59','2019-03-24 11:59:59','NAVBNB','4h','0.012990000000000','0.011440000000000','0.711908500000000','0.626961758275597','54.80434949961509','54.804349499615093','test'),('2019-03-26 23:59:59','2019-03-27 07:59:59','NAVBNB','4h','0.012730000000000','0.012390000000000','0.711908500000000','0.692894447368421','55.92368421052632','55.923684210526318','test'),('2019-04-02 11:59:59','2019-04-02 19:59:59','NAVBNB','4h','0.012970000000000','0.012440000000000','0.711908500000000','0.682817404780262','54.88885890516577','54.888858905165769','test'),('2019-04-03 11:59:59','2019-04-04 03:59:59','NAVBNB','4h','0.012840000000000','0.012880000000000','0.711908500000000','0.714126283489097','55.44458722741433','55.444587227414331','test'),('2019-04-05 07:59:59','2019-04-09 11:59:59','NAVBNB','4h','0.013090000000000','0.013010000000000','0.711908500000000','0.707557645912911','54.385676088617274','54.385676088617274','test'),('2019-04-10 07:59:59','2019-04-10 19:59:59','NAVBNB','4h','0.013260000000000','0.013070000000000','0.711908500000000','0.701707699472097','53.6884238310709','53.688423831070899','test'),('2019-05-03 19:59:59','2019-05-04 03:59:59','NAVBNB','4h','0.009070000000000','0.008660000000000','0.711908500000000','0.679727410143330','78.49046306504962','78.490463065049624','test'),('2019-05-04 11:59:59','2019-05-04 15:59:59','NAVBNB','4h','0.009050000000000','0.008800000000000','0.711908500000000','0.692242519337017','78.6639226519337','78.663922651933703','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','NAVBNB','4h','0.008910000000000','0.008940000000000','0.711908500000000','0.714305498316498','79.89994388327723','79.899943883277231','test'),('2019-05-05 15:59:59','2019-05-05 23:59:59','NAVBNB','4h','0.008920000000000','0.009100000000000','0.711908500000000','0.726274366591928','79.81036995515694','79.810369955156943','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','NAVBNB','4h','0.009210000000000','0.009090000000000','0.711908500000000','0.702632819218241','77.29733984799132','77.297339847991324','test'),('2019-05-16 19:59:59','2019-05-16 23:59:59','NAVBNB','4h','0.009040000000000','0.008300000000000','0.711908500000000','0.653632804203540','78.75094026548673','78.750940265486733','test'),('2019-05-17 07:59:59','2019-05-17 11:59:59','NAVBNB','4h','0.008670000000000','0.007940000000000','0.711908500000000','0.651966953863898','82.11170703575547','82.111707035755472','test'),('2019-05-18 07:59:59','2019-05-18 11:59:59','NAVBNB','4h','0.008510000000000','0.008330000000000','0.711908500000000','0.696850505875441','83.65552291421857','83.655522914218565','test'),('2019-05-18 15:59:59','2019-05-18 23:59:59','NAVBNB','4h','0.008840000000000','0.007670000000000','0.711908500000000','0.617685316176471','80.53263574660633','80.532635746606331','test'),('2019-05-31 23:59:59','2019-06-01 03:59:59','NAVBNB','4h','0.006920000000000','0.006840000000000','0.474605666666667','0.469118895953758','68.58463391136802','68.584633911368016','test'),('2019-06-01 11:59:59','2019-06-01 15:59:59','NAVBNB','4h','0.006950000000000','0.007170000000000','0.519052337674950','0.535482771385524','74.68378959351804','74.683789593518043','test'),('2019-06-05 07:59:59','2019-06-05 23:59:59','NAVBNB','4h','0.007100000000000','0.006970000000000','0.523159946102594','0.513580961173955','73.68449945106957','73.684499451069570','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','NAVBNB','4h','0.007200000000000','0.007090000000000','0.523159946102594','0.515167224703804','72.66110362536028','72.661103625360283','test'),('2019-06-09 11:59:59','2019-06-09 15:59:59','NAVBNB','4h','0.007070000000000','0.007100000000000','0.523159946102594','0.525379861008263','73.99716352229052','73.997163522290521','test'),('2019-06-10 15:59:59','2019-06-10 23:59:59','NAVBNB','4h','0.007130000000000','0.007110000000000','0.523159946102594','0.521692456772713','73.37446649405246','73.374466494052456','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','NAVBNB','4h','0.007190000000000','0.006950000000000','0.523159946102594','0.505697027178446','72.76216218394909','72.762162183949087','test'),('2019-06-16 11:59:59','2019-06-17 07:59:59','NAVBNB','4h','0.007440000000000','0.007060000000000','0.523159946102594','0.496439411221010','70.31719705680027','70.317197056800268','test'),('2019-06-18 19:59:59','2019-06-18 23:59:59','NAVBNB','4h','0.007550000000000','0.006910000000000','0.523159946102594','0.478812612923036','69.2927080930588','69.292708093058806','test'),('2019-06-30 15:59:59','2019-07-01 11:59:59','NAVBNB','4h','0.006250000000000','0.006050000000000','0.523159946102594','0.506418827827311','83.70559137641503','83.705591376415029','test'),('2019-07-01 23:59:59','2019-07-02 03:59:59','NAVBNB','4h','0.006270000000000','0.006180000000000','0.523159946102594','0.515650473192030','83.43858789515055','83.438587895150548','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','NAVBNB','4h','0.006020000000000','0.005880000000000','0.523159946102594','0.510993435728115','86.90364553199235','86.903645531992353','test'),('2019-07-13 15:59:59','2019-07-13 19:59:59','NAVBNB','4h','0.005834000000000','0.005459000000000','0.523159946102594','0.489532078466586','89.67431369602228','89.674313696022281','test'),('2019-07-24 03:59:59','2019-07-24 15:59:59','NAVBNB','4h','0.004856000000000','0.005068000000000','0.523159946102594','0.545999713107073','107.73475002112725','107.734750021127255','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','NAVBNB','4h','0.004847000000000','0.004725000000000','0.523159946102594','0.509991901245050','107.93479391429626','107.934793914296264','test'),('2019-07-26 19:59:59','2019-07-27 15:59:59','NAVBNB','4h','0.004848000000000','0.004876000000000','0.523159946102594','0.526181496946421','107.91253013667368','107.912530136673681','test'),('2019-07-28 11:59:59','2019-07-28 23:59:59','NAVBNB','4h','0.004830000000000','0.004794000000000','0.523159946102594','0.519260617311767','108.31468863407743','108.314688634077427','test'),('2019-07-31 19:59:59','2019-08-01 11:59:59','NAVBNB','4h','0.004893000000000','0.004569000000000','0.523159946102594','0.488517840536021','106.92007890917515','106.920078909175146','test'),('2019-08-01 19:59:59','2019-08-02 03:59:59','NAVBNB','4h','0.005450000000000','0.004943000000000','0.523159946102594','0.474491672217454','95.99265066102642','95.992650661026417','test'),('2019-08-02 23:59:59','2019-08-03 03:59:59','NAVBNB','4h','0.004939000000000','0.004868000000000','0.523159946102594','0.515639323269372','105.92426525664993','105.924265256649932','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','NAVBNB','4h','0.004157000000000','0.004015000000000','0.523159946102594','0.505289194996852','125.8503598995896','125.850359899589606','test'),('2019-08-14 07:59:59','2019-08-15 01:59:59','NAVBNB','4h','0.004157000000000','0.004148000000000','0.523159946102594','0.522027292863498','125.8503598995896','125.850359899589606','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','NAVBNB','4h','0.004030000000000','0.003705000000000','0.523159946102594','0.480969627868514','129.81636379716974','129.816363797169743','test'),('2019-08-22 15:59:59','2019-08-26 03:59:59','NAVBNB','4h','0.004008000000000','0.003987000000000','0.523159946102594','0.520418838600559','130.52892866831186','130.528928668311863','test'),('2019-09-03 07:59:59','2019-09-05 19:59:59','NAVBNB','4h','0.004995000000000','0.004564000000000','0.523159946102594','0.478018417219667','104.73672594646526','104.736725946465256','test'),('2019-09-05 23:59:59','2019-09-06 07:59:59','NAVBNB','4h','0.004907000000000','0.004670000000000','0.523159946102594','0.497892184287572','106.61502875536866','106.615028755368655','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','NAVBNB','4h','0.004799000000000','0.004617000000000','0.523159946102594','0.503319331351464','109.01436676444966','109.014366764449662','test'),('2019-09-07 23:59:59','2019-09-11 19:59:59','NAVBNB','4h','0.004762000000000','0.005191000000000','0.523159946102594','0.570290483036238','109.86139145371567','109.861391453715669','test'),('2019-09-13 11:59:59','2019-09-17 15:59:59','NAVBNB','4h','0.005005000000000','0.005058000000000','0.523159946102594','0.528699901575808','104.52746175876004','104.527461758760040','test'),('2019-09-17 23:59:59','2019-09-18 03:59:59','NAVBNB','4h','0.005201000000000','0.004958000000000','0.523159946102594','0.498716979960904','100.5883380316466','100.588338031646600','test'),('2019-09-19 15:59:59','2019-09-19 23:59:59','NAVBNB','4h','0.005436000000000','0.005065000000000','0.523159946102594','0.487454953460198','96.23987235147057','96.239872351470567','test'),('2019-10-26 15:59:59','2019-10-27 15:59:59','NAVBNB','4h','0.005159000000000','0.004855000000000','0.523159946102594','0.492332145440607','101.40723901969257','101.407239019692568','test'),('2019-10-28 23:59:59','2019-10-29 03:59:59','NAVBNB','4h','0.004861000000000','0.004730000000000','0.523159946102594','0.509061210669671','107.62393460246739','107.623934602467386','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','NAVBNB','4h','0.005209000000000','0.004776000000000','0.523159946102594','0.479672087269339','100.43385411837089','100.433854118370888','test'),('2019-11-02 11:59:59','2019-11-02 15:59:59','NAVBNB','4h','0.004922000000000','0.004735000000000','0.523159946102594','0.503283694594836','106.29011501474888','106.290115014748878','test'),('2019-11-04 07:59:59','2019-11-04 15:59:59','NAVBNB','4h','0.004834000000000','0.004858000000000','0.348773297401729','0.350504898381796','72.15004083610454','72.150040836104537','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  2:39:54
