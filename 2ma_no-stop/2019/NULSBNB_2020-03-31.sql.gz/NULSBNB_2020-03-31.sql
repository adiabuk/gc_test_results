-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 03:59:59','2019-01-06 07:59:59','NULSBNB','4h','0.071780000000000','0.070030000000000','0.711908500000000','0.694552135065478','9.917922819726945','9.917922819726945','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','NULSBNB','4h','0.073190000000000','0.070910000000000','0.711908500000000','0.689731271143599','9.726854761579451','9.726854761579451','test'),('2019-01-17 11:59:59','2019-01-17 15:59:59','NULSBNB','4h','0.066480000000000','0.065000000000000','0.711908500000000','0.696059754813478','10.708611612515043','10.708611612515043','test'),('2019-01-17 19:59:59','2019-01-17 23:59:59','NULSBNB','4h','0.066160000000000','0.064600000000000','0.711908500000000','0.695122265719468','10.760406590084644','10.760406590084644','test'),('2019-01-24 19:59:59','2019-01-27 03:59:59','NULSBNB','4h','0.065730000000000','0.066820000000000','0.711908500000000','0.723714072265328','10.830800243420054','10.830800243420054','test'),('2019-01-29 03:59:59','2019-01-31 11:59:59','NULSBNB','4h','0.065790000000000','0.063510000000000','0.711908500000000','0.687236796397629','10.82092263261894','10.820922632618940','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','NULSBNB','4h','0.044190000000000','0.042920000000000','0.711908500000000','0.691448581579543','16.110171984611906','16.110171984611906','test'),('2019-03-09 15:59:59','2019-03-10 19:59:59','NULSBNB','4h','0.038540000000000','0.035730000000000','0.711908500000000','0.660002353528801','18.471938245978208','18.471938245978208','test'),('2019-03-14 07:59:59','2019-03-14 15:59:59','NULSBNB','4h','0.036090000000000','0.035740000000000','0.711908500000000','0.705004427542256','19.72592130784151','19.725921307841510','test'),('2019-03-17 03:59:59','2019-03-19 11:59:59','NULSBNB','4h','0.036000000000000','0.036140000000000','0.711908500000000','0.714677033055556','19.775236111111113','19.775236111111113','test'),('2019-03-27 03:59:59','2019-04-04 19:59:59','NULSBNB','4h','0.039850000000000','0.046060000000000','0.711908500000000','0.822848318946048','17.864705144291094','17.864705144291094','test'),('2019-04-17 23:59:59','2019-04-18 07:59:59','NULSBNB','4h','0.046200000000000','0.043700000000000','0.711908500000000','0.673385312770563','15.409274891774894','15.409274891774894','test'),('2019-04-23 23:59:59','2019-04-24 03:59:59','NULSBNB','4h','0.042120000000000','0.041770000000000','0.711908500000000','0.705992831077873','16.901911206077877','16.901911206077877','test'),('2019-05-08 03:59:59','2019-05-08 07:59:59','NULSBNB','4h','0.032920000000000','0.031970000000000','0.711908500000000','0.691364360419198','21.625410085054682','21.625410085054682','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','NULSBNB','4h','0.032470000000000','0.031800000000000','0.711908500000000','0.697218672620881','21.92511549122267','21.925115491222670','test'),('2019-05-09 07:59:59','2019-05-09 11:59:59','NULSBNB','4h','0.032180000000000','0.031770000000000','0.711908500000000','0.702838192821628','22.12270043505283','22.122700435052831','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','NULSBNB','4h','0.032420000000000','0.031810000000000','0.711908500000000','0.698513552899445','21.958929673041336','21.958929673041336','test'),('2019-05-11 11:59:59','2019-05-11 15:59:59','NULSBNB','4h','0.032520000000000','0.030710000000000','0.711908500000000','0.672285056426814','21.89140528905289','21.891405289052891','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','NULSBNB','4h','0.032740000000000','0.031270000000000','0.711908500000000','0.679944373701894','21.74430360415394','21.744303604153941','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','NULSBNB','4h','0.024230000000000','0.023630000000000','0.711908500000000','0.694279729880314','29.381283532810567','29.381283532810567','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','NULSBNB','4h','0.024960000000000','0.024030000000000','0.711908500000000','0.685383063100962','28.521975160256414','28.521975160256414','test'),('2019-06-06 23:59:59','2019-06-07 03:59:59','NULSBNB','4h','0.024370000000000','0.024240000000000','0.711908500000000','0.708110875666804','29.21249487074272','29.212494870742720','test'),('2019-06-07 07:59:59','2019-06-08 15:59:59','NULSBNB','4h','0.024370000000000','0.024900000000000','0.711908500000000','0.727391122281494','29.21249487074272','29.212494870742720','test'),('2019-06-14 03:59:59','2019-06-18 15:59:59','NULSBNB','4h','0.027010000000000','0.029000000000000','0.711908500000000','0.764359366901148','26.35721954831544','26.357219548315442','test'),('2019-07-01 07:59:59','2019-07-02 07:59:59','NULSBNB','4h','0.028140000000000','0.026170000000000','0.711908500000000','0.662069845238095','25.298809523809528','25.298809523809528','test'),('2019-08-04 11:59:59','2019-08-05 07:59:59','NULSBNB','4h','0.019440000000000','0.019480000000000','0.711908500000000','0.713373332304527','36.62080761316873','36.620807613168729','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','NULSBNB','4h','0.016500000000000','0.015510000000000','0.711908500000000','0.669193990000000','43.1459696969697','43.145969696969701','test'),('2019-08-21 19:59:59','2019-08-22 07:59:59','NULSBNB','4h','0.015940000000000','0.015570000000000','0.711908500000000','0.695383647741531','44.661762860727734','44.661762860727734','test'),('2019-08-22 11:59:59','2019-08-23 19:59:59','NULSBNB','4h','0.015850000000000','0.016080000000000','0.711908500000000','0.722239033438486','44.91536277602524','44.915362776025241','test'),('2019-09-06 03:59:59','2019-09-06 07:59:59','NULSBNB','4h','0.019380000000000','0.018870000000000','0.711908500000000','0.693174065789474','36.73418472652219','36.734184726522187','test'),('2019-09-08 11:59:59','2019-09-08 23:59:59','NULSBNB','4h','0.019800000000000','0.018820000000000','0.711908500000000','0.676672624747475','35.95497474747475','35.954974747474751','test'),('2019-09-09 03:59:59','2019-09-09 07:59:59','NULSBNB','4h','0.019200000000000','0.020190000000000','0.711908500000000','0.748616282031250','37.07856770833334','37.078567708333338','test'),('2019-09-11 15:59:59','2019-09-13 03:59:59','NULSBNB','4h','0.019630000000000','0.019500000000000','0.711908500000000','0.707193874172185','36.26635252165053','36.266352521650532','test'),('2019-09-13 15:59:59','2019-09-14 23:59:59','NULSBNB','4h','0.019620000000000','0.019390000000000','0.711908500000000','0.703562987512742','36.28483690112131','36.284836901121309','test'),('2019-09-15 03:59:59','2019-09-15 19:59:59','NULSBNB','4h','0.019990000000000','0.019970000000000','0.711908500000000','0.711196235367684','35.613231615807905','35.613231615807905','test'),('2019-09-18 15:59:59','2019-09-19 03:59:59','NULSBNB','4h','0.020740000000000','0.020010000000000','0.711908500000000','0.686850968418515','34.32538572806172','34.325385728061718','test'),('2019-09-19 19:59:59','2019-09-21 15:59:59','NULSBNB','4h','0.020660000000000','0.020200000000000','0.711908500000000','0.696057681510165','34.45830106485963','34.458301064859633','test'),('2019-09-23 03:59:59','2019-09-24 19:59:59','NULSBNB','4h','0.020240000000000','0.018950000000000','0.711908500000000','0.666534885128459','35.17334486166008','35.173344861660077','test'),('2019-09-24 23:59:59','2019-10-07 11:59:59','NULSBNB','4h','0.021000000000000','0.023350000000000','0.711908500000000','0.791574451190476','33.90040476190476','33.900404761904760','test'),('2019-10-27 15:59:59','2019-11-04 03:59:59','NULSBNB','4h','0.019730000000000','0.020150000000000','0.711908500000000','0.727063166497719','36.08253928028383','36.082539280283832','test'),('2019-11-06 19:59:59','2019-11-07 03:59:59','NULSBNB','4h','0.020450000000000','0.019990000000000','0.711908500000000','0.695894910268949','34.812151589242056','34.812151589242056','test'),('2019-11-07 23:59:59','2019-11-08 03:59:59','NULSBNB','4h','0.020350000000000','0.020320000000000','0.711908500000000','0.710859003439804','34.98321867321867','34.983218673218673','test'),('2019-11-08 19:59:59','2019-11-09 03:59:59','NULSBNB','4h','0.020040000000000','0.019910000000000','0.711908500000000','0.707290331087824','35.524376247504996','35.524376247504996','test'),('2019-11-09 07:59:59','2019-11-09 11:59:59','NULSBNB','4h','0.020260000000000','0.019900000000000','0.711908500000000','0.699258595755183','35.138622902270484','35.138622902270484','test'),('2019-11-12 07:59:59','2019-11-12 15:59:59','NULSBNB','4h','0.020880000000000','0.019880000000000','0.711908500000000','0.677813265325671','34.095234674329504','34.095234674329504','test'),('2019-11-14 03:59:59','2019-11-14 07:59:59','NULSBNB','4h','0.020270000000000','0.020220000000000','0.711908500000000','0.710152435619142','35.121287617168235','35.121287617168235','test'),('2019-11-18 11:59:59','2019-11-18 15:59:59','NULSBNB','4h','0.019840000000000','0.018980000000000','0.711908500000000','0.681049563004032','35.88248487903226','35.882484879032262','test'),('2019-11-23 15:59:59','2019-11-24 03:59:59','NULSBNB','4h','0.019190000000000','0.019300000000000','0.711908500000000','0.715989267847838','37.09788952579469','37.097889525794692','test'),('2019-11-26 11:59:59','2019-11-26 15:59:59','NULSBNB','4h','0.019140000000000','0.018870000000000','0.711908500000000','0.701865903605016','37.19480146290491','37.194801462904913','test'),('2019-11-26 23:59:59','2019-11-27 07:59:59','NULSBNB','4h','0.019230000000000','0.019170000000000','0.711908500000000','0.709687256630265','37.02072282891316','37.020722828913158','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','NULSBNB','4h','0.019190000000000','0.019200000000000','0.711908500000000','0.712279478895258','37.09788952579469','37.097889525794692','test'),('2019-12-08 15:59:59','2019-12-09 03:59:59','NULSBNB','4h','0.019320000000000','0.019200000000000','0.711908500000000','0.707486708074534','36.848266045548655','36.848266045548655','test'),('2019-12-10 15:59:59','2019-12-10 19:59:59','NULSBNB','4h','0.019430000000000','0.018490000000000','0.711908500000000','0.677467224137931','36.639655172413796','36.639655172413796','test'),('2019-12-11 19:59:59','2019-12-11 23:59:59','NULSBNB','4h','0.019300000000000','0.019110000000000','0.711908500000000','0.704900074352332','36.88645077720207','36.886450777202072','test'),('2019-12-14 15:59:59','2019-12-14 19:59:59','NULSBNB','4h','0.019170000000000','0.018970000000000','0.711908500000000','0.704481181272822','37.13659363588941','37.136593635889412','test'),('2019-12-15 11:59:59','2019-12-16 19:59:59','NULSBNB','4h','0.019340000000000','0.019410000000000','0.711908500000000','0.714485211220269','36.81016028955533','36.810160289555327','test'),('2019-12-27 07:59:59','2019-12-28 19:59:59','NULSBNB','4h','0.018800000000000','0.018720000000000','0.711908500000000','0.708879102127660','37.86747340425532','37.867473404255321','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  5:33:13
