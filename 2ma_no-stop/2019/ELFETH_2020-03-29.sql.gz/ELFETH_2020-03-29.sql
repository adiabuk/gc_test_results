-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-10 11:59:59','ELFETH','4h','0.000827960000000','0.000806330000000','0.072144500000000','0.070259764584038','87.13524807961737','87.135248079617369','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','ELFETH','4h','0.000826420000000','0.000802480000000','0.072144500000000','0.070054594951719','87.29762106434984','87.297621064349840','test'),('2019-01-11 11:59:59','2019-01-12 03:59:59','ELFETH','4h','0.000847830000000','0.000820300000000','0.072144500000000','0.069801886404114','85.09312008303552','85.093120083035515','test'),('2019-01-15 23:59:59','2019-01-27 11:59:59','ELFETH','4h','0.000848620000000','0.000922210000000','0.072144500000000','0.078400673263652','85.01390492800076','85.013904928000755','test'),('2019-01-28 07:59:59','2019-01-28 11:59:59','ELFETH','4h','0.000931770000000','0.000942260000000','0.072144500000000','0.072956713105165','77.42736941519904','77.427369415199038','test'),('2019-02-01 11:59:59','2019-02-01 15:59:59','ELFETH','4h','0.000951920000000','0.000937940000000','0.072332283077172','0.071270003350494','75.98567429739053','75.985674297390531','test'),('2019-02-02 15:59:59','2019-02-02 19:59:59','ELFETH','4h','0.000948810000000','0.000940490000000','0.072332283077172','0.071698010045477','76.23473938635976','76.234739386359763','test'),('2019-02-04 03:59:59','2019-02-04 07:59:59','ELFETH','4h','0.000947630000000','0.000940760000000','0.072332283077172','0.071807898259532','76.32966777874488','76.329667778744877','test'),('2019-02-04 11:59:59','2019-02-04 15:59:59','ELFETH','4h','0.000944150000000','0.000933840000000','0.072332283077172','0.071542423586068','76.61100786651697','76.611007866516971','test'),('2019-02-06 03:59:59','2019-02-06 07:59:59','ELFETH','4h','0.000950150000000','0.000931020000000','0.072332283077172','0.070875969258021','76.12722525619324','76.127225256193242','test'),('2019-02-06 11:59:59','2019-02-06 23:59:59','ELFETH','4h','0.000976430000000','0.000959380000000','0.072332283077172','0.071069247911860','74.07830881596428','74.078308815964277','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','ELFETH','4h','0.000931210000000','0.000924600000000','0.072332283077172','0.071818847449183','77.67558668525038','77.675586685250380','test'),('2019-02-20 11:59:59','2019-02-20 15:59:59','ELFETH','4h','0.000943750000000','0.000936760000000','0.072332283077172','0.071796545160659','76.64347875726834','76.643478757268340','test'),('2019-02-23 03:59:59','2019-02-23 19:59:59','ELFETH','4h','0.000938900000000','0.000929040000000','0.072332283077172','0.071572674693808','77.03938979355843','77.039389793558428','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','ELFETH','4h','0.000946490000000','0.000927300000000','0.072332283077172','0.070865752514513','76.42160305673805','76.421603056738050','test'),('2019-03-05 07:59:59','2019-03-05 15:59:59','ELFETH','4h','0.001094150000000','0.001087820000000','0.072332283077172','0.071913818194040','66.10819638730705','66.108196387307046','test'),('2019-03-06 03:59:59','2019-03-06 07:59:59','ELFETH','4h','0.001088110000000','0.001092090000000','0.072332283077172','0.072596854202010','66.47515699439579','66.475156994395789','test'),('2019-03-17 15:59:59','2019-03-18 03:59:59','ELFETH','4h','0.001220090000000','0.001205690000000','0.072332283077172','0.071478587959344','59.284383182529155','59.284383182529155','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','ELFETH','4h','0.001222690000000','0.001222110000000','0.072332283077172','0.072297971253092','59.15831737985262','59.158317379852619','test'),('2019-04-04 07:59:59','2019-04-07 19:59:59','ELFETH','4h','0.001349670000000','0.001312080000000','0.072332283077172','0.070317738395234','53.59256935189491','53.592569351894909','test'),('2019-04-20 23:59:59','2019-04-21 03:59:59','ELFETH','4h','0.001126820000000','0.001166060000000','0.072332283077172','0.074851158130817','64.19151512856712','64.191515128567119','test'),('2019-04-22 15:59:59','2019-04-23 03:59:59','ELFETH','4h','0.001147870000000','0.001121390000000','0.072332283077172','0.070663663062812','63.01435099547161','63.014350995471609','test'),('2019-05-02 11:59:59','2019-05-02 15:59:59','ELFETH','4h','0.001063310000000','0.001053820000000','0.072332283077172','0.071686720290776','68.0255833925873','68.025583392587293','test'),('2019-05-20 15:59:59','2019-05-20 19:59:59','ELFETH','4h','0.000881800000000','0.000875680000000','0.072332283077172','0.071830271767995','82.02799169559084','82.027991695590842','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','ELFETH','4h','0.000902270000000','0.000868000000000','0.072332283077172','0.069584959835731','80.1670044190453','80.167004419045298','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','ELFETH','4h','0.000889750000000','0.000872720000000','0.072332283077172','0.070947828139488','81.2950638686957','81.295063868695706','test'),('2019-05-23 07:59:59','2019-05-26 19:59:59','ELFETH','4h','0.000899790000000','0.000926250000000','0.072332283077172','0.074459348514910','80.38796060988898','80.387960609888978','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','ELFETH','4h','0.000941280000000','0.000904710000000','0.072332283077172','0.069522076133295','76.84459786373024','76.844597863730243','test'),('2019-05-28 03:59:59','2019-05-28 11:59:59','ELFETH','4h','0.000973190000000','0.000921740000000','0.072332283077172','0.068508265193387','74.32493457307618','74.324934573076177','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','ELFETH','4h','0.000832100000000','0.000794360000000','0.072332283077172','0.069051643294294','86.9273922331114','86.927392233111405','test'),('2019-06-08 23:59:59','2019-06-09 03:59:59','ELFETH','4h','0.000825950000000','0.000830630000000','0.072332283077172','0.072742132444326','87.5746511013645','87.574651101364495','test'),('2019-06-10 03:59:59','2019-06-11 23:59:59','ELFETH','4h','0.000831070000000','0.000839210000000','0.072332283077172','0.073040749011748','87.03512709780404','87.035127097804036','test'),('2019-06-14 15:59:59','2019-06-14 19:59:59','ELFETH','4h','0.000828530000000','0.000804830000000','0.072332283077172','0.070263226906691','87.30194812157919','87.301948121579187','test'),('2019-06-15 23:59:59','2019-06-16 03:59:59','ELFETH','4h','0.000820990000000','0.000789950000000','0.072332283077172','0.069597543230505','88.1037321735612','88.103732173561198','test'),('2019-06-25 19:59:59','2019-06-25 23:59:59','ELFETH','4h','0.000745100000000','0.000745000000000','0.072332283077172','0.072322575348937','97.07728234756678','97.077282347566779','test'),('2019-07-01 03:59:59','2019-07-01 11:59:59','ELFETH','4h','0.000686130000000','0.000693150000000','0.072332283077172','0.073072336167988','105.42066820744175','105.420668207441750','test'),('2019-07-21 07:59:59','2019-07-21 11:59:59','ELFETH','4h','0.000604350000000','0.000591990000000','0.072332283077172','0.070852963115504','119.68608104107223','119.686081041072228','test'),('2019-07-22 11:59:59','2019-07-23 15:59:59','ELFETH','4h','0.000616310000000','0.000589340000000','0.072332283077172','0.069166990165178','117.36347467536143','117.363474675361431','test'),('2019-07-29 07:59:59','2019-07-29 11:59:59','ELFETH','4h','0.000598570000000','0.000599720000000','0.072332283077172','0.072471251160335','120.8418114458994','120.841811445899395','test'),('2019-08-15 15:59:59','2019-08-15 23:59:59','ELFETH','4h','0.000461800000000','0.000450000000000','0.072332283077172','0.070484035047049','156.63118899344306','156.631188993443061','test'),('2019-08-16 03:59:59','2019-08-18 11:59:59','ELFETH','4h','0.000465890000000','0.000462510000000','0.072332283077172','0.071807517323881','155.25614002698492','155.256140026984923','test'),('2019-08-20 07:59:59','2019-08-20 11:59:59','ELFETH','4h','0.000467310000000','0.000469250000000','0.072332283077172','0.072632564751371','154.78436814357065','154.784368143570646','test'),('2019-08-20 23:59:59','2019-08-21 03:59:59','ELFETH','4h','0.000468910000000','0.000454710000000','0.072332283077172','0.070141844784758','154.25621777563285','154.256217775632848','test'),('2019-08-24 15:59:59','2019-08-25 07:59:59','ELFETH','4h','0.000458630000000','0.000458860000000','0.072332283077172','0.072368557252668','157.7138065045287','157.713806504528691','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','ELFETH','4h','0.000453830000000','0.000448410000000','0.072332283077172','0.071468433234107','159.381889864425','159.381889864425005','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','ELFETH','4h','0.000458540000000','0.000448450000000','0.072332283077172','0.070740638430579','157.74476180305317','157.744761803053166','test'),('2019-09-03 19:59:59','2019-09-03 23:59:59','ELFETH','4h','0.000454150000000','0.000455760000000','0.072332283077172','0.072588707112742','159.26958731073876','159.269587310738757','test'),('2019-09-08 15:59:59','2019-09-08 19:59:59','ELFETH','4h','0.000466440000000','0.000460540000000','0.072332283077172','0.071417351960297','155.07307065683048','155.073070656830481','test'),('2019-09-09 03:59:59','2019-09-09 07:59:59','ELFETH','4h','0.000463450000000','0.000461970000000','0.072332283077172','0.072101294234893','156.07354208042292','156.073542080422925','test'),('2019-09-10 15:59:59','2019-09-10 19:59:59','ELFETH','4h','0.000465660000000','0.000457710000000','0.072332283077172','0.071097387122047','155.33282454402783','155.332824544027829','test'),('2019-09-13 11:59:59','2019-09-13 15:59:59','ELFETH','4h','0.000459710000000','0.000462370000000','0.072332283077172','0.072750816224124','157.34328832779795','157.343288327797950','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','ELFETH','4h','0.000413260000000','0.000385780000000','0.072332283077172','0.067522499553577','175.02851250344094','175.028512503440936','test'),('2019-09-25 19:59:59','2019-09-25 23:59:59','ELFETH','4h','0.000410250000000','0.000416020000000','0.072332283077172','0.073349607326667','176.31269488646436','176.312694886464357','test'),('2019-10-02 03:59:59','2019-10-07 11:59:59','ELFETH','4h','0.000426760000000','0.000437750000000','0.072332283077172','0.074194996993701','169.49171215008906','169.491712150089057','test'),('2019-10-08 03:59:59','2019-10-09 15:59:59','ELFETH','4h','0.000445650000000','0.000434560000000','0.072332283077172','0.070532294253373','162.30737816037697','162.307378160376970','test'),('2019-10-11 23:59:59','2019-10-12 03:59:59','ELFETH','4h','0.000436650000000','0.000430950000000','0.072332283077172','0.071388062274378','165.6527724199519','165.652772419951901','test'),('2019-10-13 15:59:59','2019-10-14 03:59:59','ELFETH','4h','0.000444050000000','0.000431920000000','0.072332283077172','0.070356400645630','162.8922037544691','162.892203754469108','test'),('2019-10-22 07:59:59','2019-10-22 23:59:59','ELFETH','4h','0.000462210000000','0.000457950000000','0.072332283077172','0.071665626090286','156.49225044281172','156.492250442811724','test'),('2019-10-24 03:59:59','2019-10-24 07:59:59','ELFETH','4h','0.000460190000000','0.000456520000000','0.072332283077172','0.071755435516614','157.1791718141898','157.179171814189800','test'),('2019-10-24 11:59:59','2019-10-25 19:59:59','ELFETH','4h','0.000471050000000','0.000454630000000','0.072332283077172','0.069810902994108','153.55542527793654','153.555425277936536','test'),('2019-10-26 07:59:59','2019-10-26 11:59:59','ELFETH','4h','0.000471220000000','0.000464470000000','0.072332283077172','0.071296157889848','153.5000277517338','153.500027751733796','test'),('2019-10-30 19:59:59','2019-10-31 07:59:59','ELFETH','4h','0.000485260000000','0.000478250000000','0.072332283077172','0.071287380747759','149.05882017304538','149.058820173045376','test'),('2019-11-15 07:59:59','2019-11-15 15:59:59','ELFETH','4h','0.000468650000000','0.000463960000000','0.072332283077172','0.071608420050111','154.34179681462072','154.341796814620722','test'),('2019-11-19 19:59:59','2019-11-19 23:59:59','ELFETH','4h','0.000455290000000','0.000455970000000','0.072332283077172','0.072440315216012','158.87079241180786','158.870792411807855','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','ELFETH','4h','0.000466620000000','0.000454660000000','0.072332283077172','0.070478324597889','155.01325077616048','155.013250776160476','test'),('2019-11-23 15:59:59','2019-11-23 19:59:59','ELFETH','4h','0.000460790000000','0.000450710000000','0.072332283077172','0.070749980046685','156.97450699271252','156.974506992712520','test'),('2019-11-29 11:59:59','2019-11-29 15:59:59','ELFETH','4h','0.000447920000000','0.000443120000000','0.072332283077172','0.071557155914352','161.48482558754242','161.484825587542417','test'),('2019-12-01 07:59:59','2019-12-02 07:59:59','ELFETH','4h','0.000450650000000','0.000437340000000','0.072332283077172','0.070195940710020','160.50656402345945','160.506564023459447','test'),('2019-12-02 15:59:59','2019-12-02 19:59:59','ELFETH','4h','0.000444980000000','0.000441970000000','0.072332283077172','0.071843002273400','162.5517620503663','162.551762050366307','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','ELFETH','4h','0.000406980000000','0.000398500000000','0.072332283077172','0.070825138351401','177.7293308692614','177.729330869261389','test'),('2019-12-19 03:59:59','2019-12-19 07:59:59','ELFETH','4h','0.000404940000000','0.000405440000000','0.072332283077172','0.072421595423541','178.6246927376204','178.624692737620393','test'),('2019-12-22 23:59:59','2019-12-23 03:59:59','ELFETH','4h','0.000409690000000','0.000406910000000','0.072332283077172','0.071841463806615','176.55369444499988','176.553694444999877','test'),('2019-12-31 03:59:59','2019-12-31 07:59:59','ELFETH','4h','0.000396620000000','0.000391000000000','0.072332283077172','0.071307353847951','182.37174897174123','182.371748971741226','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 11:08:32
