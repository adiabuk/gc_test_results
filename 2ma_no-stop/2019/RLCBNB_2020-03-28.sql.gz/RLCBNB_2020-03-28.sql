-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 11:59:59','2019-01-06 19:59:59','RLCBNB','4h','0.033120000000000','0.033390000000000','0.711908500000000','0.717712101902174','21.494821859903386','21.494821859903386','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','RLCBNB','4h','0.032980000000000','0.032110000000000','0.713359400475544','0.694541247703751','21.630060657232974','21.630060657232974','test'),('2019-01-24 15:59:59','2019-02-01 07:59:59','RLCBNB','4h','0.032030000000000','0.036270000000000','0.713359400475544','0.807790991422041','22.27160163832482','22.271601638324821','test'),('2019-02-01 15:59:59','2019-02-01 19:59:59','RLCBNB','4h','0.037210000000000','0.038340000000000','0.732262760019220','0.754500247759659','19.679192690653576','19.679192690653576','test'),('2019-02-03 11:59:59','2019-02-04 03:59:59','RLCBNB','4h','0.037700000000000','0.036880000000000','0.737822131954329','0.721774011312352','19.570878831679824','19.570878831679824','test'),('2019-02-17 23:59:59','2019-02-18 03:59:59','RLCBNB','4h','0.028600000000000','0.027220000000000','0.737822131954329','0.702220924188701','25.797976641759753','25.797976641759753','test'),('2019-02-23 03:59:59','2019-02-24 07:59:59','RLCBNB','4h','0.027860000000000','0.027920000000000','0.737822131954329','0.739411124341883','26.483206459236506','26.483206459236506','test'),('2019-02-25 11:59:59','2019-02-28 11:59:59','RLCBNB','4h','0.033410000000000','0.029360000000000','0.737822131954329','0.648382454180757','22.083871055202902','22.083871055202902','test'),('2019-03-03 15:59:59','2019-03-03 19:59:59','RLCBNB','4h','0.030030000000000','0.029830000000000','0.737822131954329','0.732908231641613','24.56950156358072','24.569501563580719','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','RLCBNB','4h','0.029880000000000','0.029220000000000','0.737822131954329','0.721524855947306','24.692842434883836','24.692842434883836','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','RLCBNB','4h','0.029830000000000','0.027870000000000','0.737822131954329','0.689343037799770','24.734231711509523','24.734231711509523','test'),('2019-03-12 19:59:59','2019-03-13 23:59:59','RLCBNB','4h','0.034830000000000','0.027510000000000','0.737822131954329','0.582758738158587','21.183523742587685','21.183523742587685','test'),('2019-03-17 07:59:59','2019-03-17 11:59:59','RLCBNB','4h','0.026790000000000','0.026860000000000','0.737822131954329','0.739749998667162','27.540953040475138','27.540953040475138','test'),('2019-03-18 15:59:59','2019-03-18 23:59:59','RLCBNB','4h','0.027060000000000','0.026310000000000','0.737822131954329','0.717372516323666','27.266154174217625','27.266154174217625','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','RLCBNB','4h','0.026750000000000','0.027520000000000','0.737822131954329','0.759060376500304','27.582135773993606','27.582135773993606','test'),('2019-03-26 11:59:59','2019-03-26 19:59:59','RLCBNB','4h','0.026960000000000','0.025410000000000','0.737822131954329','0.695402832824907','27.367289760917245','27.367289760917245','test'),('2019-03-27 03:59:59','2019-03-27 07:59:59','RLCBNB','4h','0.025650000000000','0.025360000000000','0.737822131954329','0.729480283288959','28.76499539782959','28.764995397829590','test'),('2019-03-27 11:59:59','2019-03-30 07:59:59','RLCBNB','4h','0.025960000000000','0.025720000000000','0.737822131954329','0.731000972028711','28.421499690074306','28.421499690074306','test'),('2019-03-30 19:59:59','2019-03-31 03:59:59','RLCBNB','4h','0.026250000000000','0.025490000000000','0.737822131954329','0.716460424514889','28.107509788736344','28.107509788736344','test'),('2019-03-31 15:59:59','2019-04-01 07:59:59','RLCBNB','4h','0.026680000000000','0.025940000000000','0.737822131954329','0.717357799958594','27.65450269693887','27.654502696938870','test'),('2019-04-01 15:59:59','2019-04-03 03:59:59','RLCBNB','4h','0.026730000000000','0.026200000000000','0.737822131954329','0.723192662072705','27.60277336155365','27.602773361553648','test'),('2019-04-04 11:59:59','2019-04-09 15:59:59','RLCBNB','4h','0.026630000000000','0.028250000000000','0.737822131954329','0.782706542535103','27.706426284428424','27.706426284428424','test'),('2019-04-30 19:59:59','2019-04-30 23:59:59','RLCBNB','4h','0.022400000000000','0.021650000000000','0.737822131954329','0.713118265929072','32.938488033675405','32.938488033675405','test'),('2019-05-03 07:59:59','2019-05-03 11:59:59','RLCBNB','4h','0.021950000000000','0.021700000000000','0.737822131954329','0.729418690815897','33.61376455372797','33.613764553727968','test'),('2019-05-03 15:59:59','2019-05-12 11:59:59','RLCBNB','4h','0.022610000000000','0.027250000000000','0.737822131954329','0.889237200166097','32.63255780426046','32.632557804260458','test'),('2019-05-12 19:59:59','2019-05-13 23:59:59','RLCBNB','4h','0.030200000000000','0.029690000000000','0.737822131954329','0.725362221778941','24.431196422328775','24.431196422328775','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','RLCBNB','4h','0.014210000000000','0.014220000000000','0.737822131954329','0.738341359351904','51.922739757517874','51.922739757517874','test'),('2019-06-26 19:59:59','2019-06-27 03:59:59','RLCBNB','4h','0.013810000000000','0.010210000000000','0.737822131954329','0.545486167071231','53.42665691197169','53.426656911971691','test'),('2019-06-28 15:59:59','2019-07-02 07:59:59','RLCBNB','4h','0.011370000000000','0.011070000000000','0.737822131954329','0.718354529528093','64.89200808745198','64.892008087451984','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','RLCBNB','4h','0.011320000000000','0.010700000000000','0.737822131954329','0.697411379144110','65.17863356487005','65.178633564870054','test'),('2019-07-06 15:59:59','2019-07-07 03:59:59','RLCBNB','4h','0.011070000000000','0.010850000000000','0.737822131954329','0.723159000153972','66.65059909253198','66.650599092531976','test'),('2019-07-07 19:59:59','2019-07-07 23:59:59','RLCBNB','4h','0.011050000000000','0.010720000000000','0.737822131954329','0.715787624846191','66.77123366102525','66.771233661025249','test'),('2019-07-14 07:59:59','2019-07-14 11:59:59','RLCBNB','4h','0.010270000000000','0.009760000000000','0.737822131954329','0.701182473989703','71.84246659730564','71.842466597305645','test'),('2019-07-15 07:59:59','2019-07-16 03:59:59','RLCBNB','4h','0.010370000000000','0.009760000000000','0.737822131954329','0.694420830074662','71.14967521256789','71.149675212567885','test'),('2019-07-16 07:59:59','2019-07-16 11:59:59','RLCBNB','4h','0.010270000000000','0.009970000000000','0.737822131954329','0.716269391975137','71.84246659730564','71.842466597305645','test'),('2019-07-16 15:59:59','2019-07-16 19:59:59','RLCBNB','4h','0.010370000000000','0.010270000000000','0.737822131954329','0.730707164433072','71.14967521256789','71.149675212567885','test'),('2019-07-25 03:59:59','2019-07-31 07:59:59','RLCBNB','4h','0.009670000000000','0.010030000000000','0.737822131954329','0.765290174095338','76.30011705835874','76.300117058358737','test'),('2019-08-01 15:59:59','2019-08-01 23:59:59','RLCBNB','4h','0.010370000000000','0.010440000000000','0.737822131954329','0.742802609219209','71.14967521256789','71.149675212567885','test'),('2019-08-06 15:59:59','2019-08-06 19:59:59','RLCBNB','4h','0.010570000000000','0.010970000000000','0.737822131954329','0.765743499294133','69.80341834951079','69.803418349510792','test'),('2019-08-22 19:59:59','2019-08-23 07:59:59','RLCBNB','4h','0.008570000000000','0.008340000000000','0.737822131954329','0.718020604492311','86.09359766094855','86.093597660948546','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','RLCBNB','4h','0.008520000000000','0.008180000000000','0.737822131954329','0.708378525749579','86.59884177867711','86.598841778677112','test'),('2019-08-24 07:59:59','2019-08-26 03:59:59','RLCBNB','4h','0.008850000000000','0.008730000000000','0.737822131954329','0.727817764063423','83.36973242421796','83.369732424217958','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','RLCBNB','4h','0.008680000000000','0.008770000000000','0.737822131954329','0.745472361433118','85.00254976432362','85.002549764323618','test'),('2019-09-08 15:59:59','2019-09-08 19:59:59','RLCBNB','4h','0.008660000000000','0.008530000000000','0.737822131954329','0.726746280088964','85.19886050280935','85.198860502809353','test'),('2019-09-10 03:59:59','2019-09-11 03:59:59','RLCBNB','4h','0.008670000000000','0.008510000000000','0.737822131954329','0.724206037246983','85.10059192091452','85.100591920914525','test'),('2019-09-24 11:59:59','2019-09-24 19:59:59','RLCBNB','4h','0.010910000000000','0.011300000000000','0.491881421302886','0.509464716839836','45.08537317166691','45.085373171666909','test'),('2019-10-12 23:59:59','2019-10-18 23:59:59','RLCBNB','4h','0.016900000000000','0.017800000000000','0.557751588613472','0.587454335936083','33.00305258067881','33.003052580678812','test'),('2019-10-20 19:59:59','2019-10-21 03:59:59','RLCBNB','4h','0.017590000000000','0.017050000000000','0.565177275444125','0.547826750785806','32.13060121910885','32.130601219108847','test'),('2019-10-21 23:59:59','2019-10-23 15:59:59','RLCBNB','4h','0.017530000000000','0.019390000000000','0.565177275444125','0.625144744487255','32.240574754371075','32.240574754371075','test'),('2019-11-28 03:59:59','2019-11-28 11:59:59','RLCBNB','4h','0.041430000000000','0.045220000000000','0.575831511540327','0.628508350274043','13.898902040558228','13.898902040558228','test'),('2019-12-08 15:59:59','2019-12-08 23:59:59','RLCBNB','4h','0.037760000000000','0.038920000000000','0.589000721223756','0.607095023041011','15.598536049357953','15.598536049357953','test'),('2019-12-12 07:59:59','2019-12-13 11:59:59','RLCBNB','4h','0.038100000000000','0.037280000000000','0.593524296678070','0.580750282943791','15.578065529608137','15.578065529608137','test'),('2019-12-31 19:59:59','2020-01-01 03:59:59','RLCBNB','4h','0.030120000000000','0.029850000000000','0.593524296678070','0.588203859755657','19.705321934862884','19.705321934862884','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:57:10
