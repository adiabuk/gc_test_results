-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 11:59:59','2019-01-09 15:59:59','GNTETH','4h','0.000490090000000','0.000497120000000','0.072144500000000','0.073179362647677','147.20663551592565','147.206635515925655','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','GNTETH','4h','0.000503830000000','0.000500830000000','0.072403215661919','0.071972098723694','143.7056460749047','143.705646074904706','test'),('2019-02-04 07:59:59','2019-02-04 11:59:59','GNTETH','4h','0.000548810000000','0.000544780000000','0.072403215661919','0.071871547217252','131.92765376345','131.927653763449996','test'),('2019-02-04 19:59:59','2019-02-04 23:59:59','GNTETH','4h','0.000534580000000','0.000531890000000','0.072403215661919','0.072038883569191','135.43943967585582','135.439439675855823','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','GNTETH','4h','0.000540250000000','0.000539470000000','0.072403215661919','0.072298681634679','134.01798364075705','134.017983640757052','test'),('2019-02-16 23:59:59','2019-02-17 03:59:59','GNTETH','4h','0.000501980000000','0.000515740000000','0.072403215661919','0.074387892835328','144.23525969544406','144.235259695444057','test'),('2019-02-26 07:59:59','2019-02-28 03:59:59','GNTETH','4h','0.000469930000000','0.000470630000000','0.072541472079556','0.072649528663421','154.36654837860212','154.366548378602118','test'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GNTETH','4h','0.000491160000000','0.000489070000000','0.072568486225523','0.072259690443677','147.7491779166112','147.749177916611188','test'),('2019-03-17 03:59:59','2019-03-18 03:59:59','GNTETH','4h','0.000540100000000','0.000536790000000','0.072568486225523','0.072123750640619','134.36120389839476','134.361203898394763','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','GNTETH','4h','0.000617860000000','0.000602510000000','0.072568486225523','0.070765608124397','117.45134209290616','117.451342092906160','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GNTETH','4h','0.000617040000000','0.000599380000000','0.072568486225523','0.070491539079888','117.60742614015786','117.607426140157855','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','GNTETH','4h','0.000624370000000','0.000598590000000','0.072568486225523','0.069572161009875','116.22673450922211','116.226734509222112','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','GNTETH','4h','0.000613180000000','0.000612820000000','0.072568486225523','0.072525881027961','118.34777100610425','118.347771006104253','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','GNTETH','4h','0.000564390000000','0.000551500000000','0.072568486225523','0.070911107839217','128.57861802215314','128.578618022153137','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','GNTETH','4h','0.000567750000000','0.000528440000000','0.072568486225523','0.067543973335122','127.8176771915861','127.817677191586100','test'),('2019-04-21 19:59:59','2019-04-22 03:59:59','GNTETH','4h','0.000547250000000','0.000537890000000','0.072568486225523','0.071327296584462','132.60573088263683','132.605730882636834','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','GNTETH','4h','0.000393840000000','0.000367150000000','0.072568486225523','0.067650618824144','184.2588011007592','184.258801100759200','test'),('2019-05-24 07:59:59','2019-05-24 11:59:59','GNTETH','4h','0.000378620000000','0.000371650000000','0.072568486225523','0.071232575948750','191.66574989573454','191.665749895734535','test'),('2019-05-28 23:59:59','2019-05-30 03:59:59','GNTETH','4h','0.000377410000000','0.000369130000000','0.072568486225523','0.070976405819738','192.28024224456956','192.280242244569564','test'),('2019-05-31 07:59:59','2019-05-31 11:59:59','GNTETH','4h','0.000387160000000','0.000367010000000','0.072568486225523','0.068791611038406','187.43797454675845','187.437974546758454','test'),('2019-06-07 19:59:59','2019-06-07 23:59:59','GNTETH','4h','0.000365360000000','0.000365360000000','0.072568486225523','0.072568486225523','198.62186945895283','198.621869458952830','test'),('2019-06-29 15:59:59','2019-06-29 19:59:59','GNTETH','4h','0.000327640000000','0.000318770000000','0.072568486225523','0.070603883390642','221.48848194824507','221.488481948245067','test'),('2019-06-30 23:59:59','2019-07-01 03:59:59','GNTETH','4h','0.000322570000000','0.000320540000000','0.072568486225523','0.072111797670983','224.96973130025424','224.969731300254239','test'),('2019-07-01 15:59:59','2019-07-01 19:59:59','GNTETH','4h','0.000321490000000','0.000321550000000','0.072568486225523','0.072582029754633','225.72548516446236','225.725485164462356','test'),('2019-07-02 19:59:59','2019-07-02 23:59:59','GNTETH','4h','0.000323000000000','0.000318080000000','0.072568486225523','0.071463108664441','224.6702359923313','224.670235992331300','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','GNTETH','4h','0.000324820000000','0.000319410000000','0.072568486225523','0.071359830630178','223.4113854612493','223.411385461249296','test'),('2019-07-06 07:59:59','2019-07-07 11:59:59','GNTETH','4h','0.000323060000000','0.000317980000000','0.072568486225523','0.071427373398105','224.6285093342506','224.628509334250595','test'),('2019-07-19 19:59:59','2019-07-20 03:59:59','GNTETH','4h','0.000284290000000','0.000284000000000','0.072568486225523','0.072494460192228','255.26218377545115','255.262183775451149','test'),('2019-07-24 03:59:59','2019-07-24 07:59:59','GNTETH','4h','0.000289840000000','0.000289730000000','0.072568486225523','0.072540945052859','250.37429694149534','250.374296941495345','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','GNTETH','4h','0.000289040000000','0.000288640000000','0.072568486225523','0.072468059314057','251.0672786656622','251.067278665662201','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','GNTETH','4h','0.000291310000000','0.000289160000000','0.072568486225523','0.072032897864722','249.11086548873368','249.110865488733680','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','GNTETH','4h','0.000290000000000','0.000287480000000','0.072568486225523','0.071937891103839','250.2361593983552','250.236159398355198','test'),('2019-07-27 15:59:59','2019-07-27 19:59:59','GNTETH','4h','0.000290330000000','0.000289880000000','0.072568486225523','0.072456007946318','249.95173156588368','249.951731565883676','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','GNTETH','4h','0.000292110000000','0.000289000000000','0.072568486225523','0.071795873195632','248.4286269745062','248.428626974506187','test'),('2019-07-30 15:59:59','2019-08-01 19:59:59','GNTETH','4h','0.000306810000000','0.000286900000000','0.072568486225523','0.067859257188822','236.52581801611095','236.525818016110946','test'),('2019-08-09 15:59:59','2019-08-09 19:59:59','GNTETH','4h','0.000274140000000','0.000265920000000','0.072568486225523','0.070392543434344','264.7132349366127','264.713234936612707','test'),('2019-08-12 15:59:59','2019-08-12 19:59:59','GNTETH','4h','0.000270400000000','0.000267260000000','0.072568486225523','0.071725790046721','268.37457923640164','268.374579236401644','test'),('2019-08-13 15:59:59','2019-08-13 19:59:59','GNTETH','4h','0.000268740000000','0.000267010000000','0.072568486225523','0.072101330308391','270.032322041836','270.032322041835982','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','GNTETH','4h','0.000269560000000','0.000267250000000','0.072568486225523','0.071946609080617','269.21088524084803','269.210885240848029','test'),('2019-08-14 19:59:59','2019-08-15 01:59:59','GNTETH','4h','0.000273000000000','0.000269070000000','0.072568486225523','0.071523819006233','265.8186308627216','265.818630862721591','test'),('2019-08-17 03:59:59','2019-08-17 23:59:59','GNTETH','4h','0.000280020000000','0.000268560000000','0.072568486225523','0.069598573890174','259.1546540444361','259.154654044436086','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','GNTETH','4h','0.000277990000000','0.000268210000000','0.072568486225523','0.070015445485620','261.0471104195223','261.047110419522312','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','GNTETH','4h','0.000275930000000','0.000263790000000','0.072568486225523','0.069375714787920','262.9959998025695','262.995999802569486','test'),('2019-08-21 15:59:59','2019-08-21 19:59:59','GNTETH','4h','0.000268840000000','0.000268770000000','0.072568486225523','0.072549590994025','269.93187853564575','269.931878535645751','test'),('2019-09-04 03:59:59','2019-09-05 23:59:59','GNTETH','4h','0.000338870000000','0.000334280000000','0.072568486225523','0.071585544826830','214.14845287432644','214.148452874326438','test'),('2019-09-06 19:59:59','2019-09-07 03:59:59','GNTETH','4h','0.000335200000000','0.000334120000000','0.072568486225523','0.072334673680405','216.49309733151253','216.493097331512530','test'),('2019-09-09 07:59:59','2019-09-09 11:59:59','GNTETH','4h','0.000335620000000','0.000327560000000','0.072568486225523','0.070825735498577','216.22217455909362','216.222174559093617','test'),('2019-09-09 15:59:59','2019-09-09 19:59:59','GNTETH','4h','0.000330890000000','0.000335690000000','0.072568486225523','0.073621188736577','219.31302313615703','219.313023136157028','test'),('2019-09-13 03:59:59','2019-09-14 03:59:59','GNTETH','4h','0.000332680000000','0.000330480000000','0.072568486225523','0.072088593626941','218.1329993553054','218.132999355305401','test'),('2019-10-05 07:59:59','2019-10-06 11:59:59','GNTETH','4h','0.000278900000000','0.000276550000000','0.072568486225523','0.071957027126814','260.1953611528254','260.195361152825399','test'),('2019-10-11 15:59:59','2019-10-13 11:59:59','GNTETH','4h','0.000279720000000','0.000280450000000','0.072568486225523','0.072757872021836','259.4325976888424','259.432597688842407','test'),('2019-10-28 19:59:59','2019-10-29 03:59:59','GNTETH','4h','0.000260580000000','0.000259700000000','0.072568486225523','0.072323416504599','278.4883192321859','278.488319232185916','test'),('2019-11-03 07:59:59','2019-11-03 15:59:59','GNTETH','4h','0.000253270000000','0.000254930000000','0.072568486225523','0.073044119688366','286.52618243583134','286.526182435831345','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','GNTETH','4h','0.000255350000000','0.000251310000000','0.072568486225523','0.071420349611655','284.19223115536715','284.192231155367153','test'),('2019-11-09 03:59:59','2019-11-10 19:59:59','GNTETH','4h','0.000261580000000','0.000251000000000','0.072568486225523','0.069633343690673','277.42368004252234','277.423680042522335','test'),('2019-11-15 15:59:59','2019-11-16 03:59:59','GNTETH','4h','0.000248480000000','0.000249670000000','0.072568486225523','0.072916025257270','292.04960650967087','292.049606509670866','test'),('2019-11-17 03:59:59','2019-11-17 07:59:59','GNTETH','4h','0.000248420000000','0.000249800000000','0.072568486225523','0.072971612024538','292.1201442135215','292.120144213521485','test'),('2019-11-21 19:59:59','2019-11-22 03:59:59','GNTETH','4h','0.000250890000000','0.000250720000000','0.072568486225523','0.072519314705501','289.2442354239827','289.244235423982673','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','GNTETH','4h','0.000249270000000','0.000244200000000','0.072568486225523','0.071092487408323','291.12402706111044','291.124027061110439','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','GNTETH','4h','0.000246640000000','0.000247080000000','0.072568486225523','0.072697946710194','294.22837425203943','294.228374252039430','test'),('2019-11-26 19:59:59','2019-11-26 23:59:59','GNTETH','4h','0.000249210000000','0.000249080000000','0.072568486225523','0.072530630990142','291.1941183159705','291.194118315970513','test'),('2019-12-01 07:59:59','2019-12-03 07:59:59','GNTETH','4h','0.000252050000000','0.000248790000000','0.072568486225523','0.071629889657004','287.91305782790323','287.913057827903231','test'),('2019-12-07 07:59:59','2019-12-07 23:59:59','GNTETH','4h','0.000249690000000','0.000249930000000','0.072568486225523','0.072638238465077','290.63433147311866','290.634331473118664','test'),('2019-12-08 07:59:59','2019-12-08 11:59:59','GNTETH','4h','0.000249820000000','0.000247550000000','0.072568486225523','0.071909089605029','290.48309272885683','290.483092728856832','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','GNTETH','4h','0.000242070000000','0.000240920000000','0.072568486225523','0.072223735702289','299.78306368208786','299.783063682087857','test'),('2019-12-16 23:59:59','2019-12-17 03:59:59','GNTETH','4h','0.000243920000000','0.000243920000000','0.072568486225523','0.072568486225523','297.50937284979915','297.509372849799149','test'),('2019-12-18 07:59:59','2019-12-18 11:59:59','GNTETH','4h','0.000242030000000','0.000240560000000','0.072568486225523','0.072127732291087','299.8326084597901','299.832608459790094','test'),('2019-12-20 11:59:59','2019-12-20 15:59:59','GNTETH','4h','0.000242000000000','0.000241580000000','0.072568486225523','0.072442540918851','299.8697777914174','299.869777791417391','test'),('2019-12-25 11:59:59','2019-12-25 15:59:59','GNTETH','4h','0.000241930000000','0.000236940000000','0.072568486225523','0.071071703080542','299.9565420804489','299.956542080448912','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  6:10:32
