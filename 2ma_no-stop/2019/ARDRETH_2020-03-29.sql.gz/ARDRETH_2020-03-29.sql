-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 11:59:59','2019-01-06 15:59:59','ARDRETH','4h','0.000397370000000','0.000395350000000','0.072144500000000','0.071777758952613','181.55497395374587','181.554973953745872','test'),('2019-01-15 19:59:59','2019-01-25 19:59:59','ARDRETH','4h','0.000413860000000','0.000457220000000','0.072144500000000','0.079703059706181','174.32102643405983','174.321026434059831','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','ARDRETH','4h','0.000481990000000','0.000474000000000','0.073942454664698','0.072716702651646','153.41076508786176','153.410765087861762','test'),('2019-02-08 03:59:59','2019-02-08 11:59:59','ARDRETH','4h','0.000482250000000','0.000469110000000','0.073942454664698','0.071927724018158','153.32805529227164','153.328055292271642','test'),('2019-02-17 03:59:59','2019-02-17 11:59:59','ARDRETH','4h','0.000445110000000','0.000427010000000','0.073942454664698','0.070935650887135','166.12175566645996','166.121755666459961','test'),('2019-02-26 15:59:59','2019-02-28 07:59:59','ARDRETH','4h','0.000411740000000','0.000413380000000','0.073942454664698','0.074236974569614','179.58530787559624','179.585307875596243','test'),('2019-03-06 19:59:59','2019-03-06 23:59:59','ARDRETH','4h','0.000423480000000','0.000420400000000','0.073942454664698','0.073404665960704','174.60672207589022','174.606722075890218','test'),('2019-03-07 07:59:59','2019-03-09 15:59:59','ARDRETH','4h','0.000425160000000','0.000433030000000','0.073942454664698','0.075311179658139','173.91677172052403','173.916771720524025','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','ARDRETH','4h','0.000580000000000','0.000545370000000','0.073942454664698','0.069527580173252','127.48699080120345','127.486990801203447','test'),('2019-04-04 19:59:59','2019-04-04 23:59:59','ARDRETH','4h','0.000554350000000','0.000553610000000','0.073942454664698','0.073843749124061','133.3858657250798','133.385865725079810','test'),('2019-05-28 03:59:59','2019-05-28 15:59:59','ARDRETH','4h','0.000337200000000','0.000330380000000','0.073942454664698','0.072446940012227','219.2836733828529','219.283673382852896','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','ARDRETH','4h','0.000330510000000','0.000329480000000','0.073942454664698','0.073712020704138','223.72229180568817','223.722291805688172','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','ARDRETH','4h','0.000327750000000','0.000324870000000','0.073942454664698','0.073292708609978','225.60626899984132','225.606268999841319','test'),('2019-06-02 15:59:59','2019-06-04 07:59:59','ARDRETH','4h','0.000343090000000','0.000330510000000','0.073942454664698','0.071231224143022','215.51911937013028','215.519119370130284','test'),('2019-06-06 03:59:59','2019-06-13 23:59:59','ARDRETH','4h','0.000333570000000','0.000402780000000','0.073942454664698','0.089284233863498','221.66997830949424','221.669978309494240','test'),('2019-06-14 19:59:59','2019-06-14 23:59:59','ARDRETH','4h','0.000395220000000','0.000392370000000','0.074097315598323','0.073562986997910','187.4837194431532','187.483719443153205','test'),('2019-06-17 03:59:59','2019-06-17 07:59:59','ARDRETH','4h','0.000395220000000','0.000388720000000','0.074097315598323','0.072878671421943','187.48371944315318','187.483719443153177','test'),('2019-06-18 07:59:59','2019-06-21 03:59:59','ARDRETH','4h','0.000397600000000','0.000414510000000','0.074097315598323','0.077248687848745','186.36145774226105','186.361457742261052','test'),('2019-06-29 07:59:59','2019-06-29 19:59:59','ARDRETH','4h','0.000405300000000','0.000379280000000','0.074446915466730','0.069667471251471','183.68348252339075','183.683482523390751','test'),('2019-07-02 19:59:59','2019-07-03 03:59:59','ARDRETH','4h','0.000400100000000','0.000383010000000','0.074446915466730','0.071266965990783','186.07077097408148','186.070770974081483','test'),('2019-07-22 03:59:59','2019-07-24 07:59:59','ARDRETH','4h','0.000315710000000','0.000313100000000','0.074446915466730','0.073831456819971','235.80791063548827','235.807910635488270','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','ARDRETH','4h','0.000315050000000','0.000312870000000','0.074446915466730','0.073931777311778','236.301905941057','236.301905941056987','test'),('2019-07-26 03:59:59','2019-07-30 07:59:59','ARDRETH','4h','0.000317720000000','0.000322870000000','0.074446915466730','0.075653643449399','234.31611313965126','234.316113139651264','test'),('2019-07-30 23:59:59','2019-07-31 03:59:59','ARDRETH','4h','0.000326790000000','0.000326380000000','0.074446915466730','0.074353512255673','227.81270989543745','227.812709895437450','test'),('2019-08-04 19:59:59','2019-08-04 23:59:59','ARDRETH','4h','0.000328200000000','0.000313100000000','0.074446915466730','0.071021722220089','226.83398984378428','226.833989843784281','test'),('2019-08-14 23:59:59','2019-08-15 01:59:59','ARDRETH','4h','0.000291920000000','0.000283240000000','0.074446915466730','0.072233297947371','255.0250598339614','255.025059833961393','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','ARDRETH','4h','0.000288000000000','0.000284610000000','0.074446915466730','0.073570613232590','258.4962342594792','258.496234259479195','test'),('2019-08-16 03:59:59','2019-08-16 07:59:59','ARDRETH','4h','0.000288500000000','0.000283710000000','0.074446915466730','0.073210864426572','258.0482338534835','258.048233853483509','test'),('2019-08-16 15:59:59','2019-08-18 07:59:59','ARDRETH','4h','0.000286370000000','0.000284680000000','0.074446915466730','0.074007570258996','259.96757854080386','259.967578540803856','test'),('2019-08-18 11:59:59','2019-08-18 15:59:59','ARDRETH','4h','0.000300610000000','0.000289000000000','0.074446915466730','0.071571666178387','247.65282414666848','247.652824146668479','test'),('2019-08-20 03:59:59','2019-08-20 07:59:59','ARDRETH','4h','0.000292440000000','0.000287090000000','0.074446915466730','0.073084957465954','254.57158893013954','254.571588930139541','test'),('2019-08-30 19:59:59','2019-08-31 03:59:59','ARDRETH','4h','0.000318860000000','0.000313920000000','0.074446915466730','0.073293532281615','233.47837755356582','233.478377553565821','test'),('2019-09-01 11:59:59','2019-09-01 19:59:59','ARDRETH','4h','0.000321200000000','0.000317640000000','0.074446915466730','0.073621787761059','231.77744541323165','231.777445413231646','test'),('2019-09-03 23:59:59','2019-09-04 03:59:59','ARDRETH','4h','0.000317070000000','0.000331760000000','0.074446915466730','0.077896075551904','234.7964659751159','234.796465975115893','test'),('2019-09-09 07:59:59','2019-09-10 23:59:59','ARDRETH','4h','0.000337450000000','0.000330490000000','0.074446915466730','0.072911427152466','220.61613710691955','220.616137106919552','test'),('2019-09-22 11:59:59','2019-09-22 15:59:59','ARDRETH','4h','0.000301460000000','0.000300990000000','0.074446915466730','0.074330846833182','246.95453946370998','246.954539463709978','test'),('2019-09-30 07:59:59','2019-09-30 11:59:59','ARDRETH','4h','0.000308450000000','0.000300830000000','0.074446915466730','0.072607766509504','241.35813086960613','241.358130869606128','test'),('2019-10-02 11:59:59','2019-10-02 15:59:59','ARDRETH','4h','0.000306110000000','0.000311530000000','0.074446915466730','0.075765076525923','243.20314745264776','243.203147452647755','test'),('2019-10-08 07:59:59','2019-10-08 11:59:59','ARDRETH','4h','0.000316620000000','0.000322650000000','0.074446915466730','0.075864750411662','235.13017328889524','235.130173288895236','test'),('2019-10-19 23:59:59','2019-10-20 03:59:59','ARDRETH','4h','0.000301310000000','0.000299700000000','0.074446915466730','0.074049120724101','247.07747989356477','247.077479893564771','test'),('2019-10-22 19:59:59','2019-10-22 23:59:59','ARDRETH','4h','0.000300860000000','0.000297760000000','0.074446915466730','0.073679829652907','247.4470367171774','247.447036717177411','test'),('2019-10-27 23:59:59','2019-10-28 03:59:59','ARDRETH','4h','0.000295880000000','0.000298420000000','0.074446915466730','0.075086009576793','251.61185435558338','251.611854355583375','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','ARDRETH','4h','0.000301530000000','0.000299030000000','0.074446915466730','0.073829672443924','246.89720912257488','246.897209122574878','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','ARDRETH','4h','0.000297180000000','0.000299600000000','0.074446915466730','0.075053152546713','250.51119007581264','250.511190075812635','test'),('2019-11-15 15:59:59','2019-11-16 07:59:59','ARDRETH','4h','0.000295730000000','0.000293920000000','0.074446915466730','0.073991267013767','251.73947677520036','251.739476775200359','test'),('2019-11-16 19:59:59','2019-11-16 23:59:59','ARDRETH','4h','0.000295000000000','0.000294290000000','0.074446915466730','0.074267738144759','252.36242531094916','252.362425310949163','test'),('2019-11-21 15:59:59','2019-11-22 03:59:59','ARDRETH','4h','0.000295730000000','0.000293890000000','0.074446915466730','0.073983714829464','251.73947677520036','251.739476775200359','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','ARDRETH','4h','0.000324160000000','0.000317490000000','0.074446915466730','0.072915076479307','229.66101760467055','229.661017604670548','test'),('2019-12-14 03:59:59','2019-12-14 07:59:59','ARDRETH','4h','0.000319960000000','0.000320020000000','0.074446915466730','0.074460876008448','232.6756952954432','232.675695295443205','test'),('2019-12-15 23:59:59','2019-12-16 11:59:59','ARDRETH','4h','0.000318480000000','0.000317230000000','0.074446915466730','0.074154719271260','233.75695637631878','233.756956376318783','test'),('2019-12-16 19:59:59','2019-12-20 15:59:59','ARDRETH','4h','0.000331780000000','0.000322420000000','0.074446915466730','0.072346658884752','224.38638696343963','224.386386963439634','test'),('2019-12-21 03:59:59','2019-12-21 07:59:59','ARDRETH','4h','0.000324160000000','0.000325560000000','0.074446915466730','0.074768440891377','229.66101760467055','229.661017604670548','test'),('2019-12-22 03:59:59','2019-12-22 07:59:59','ARDRETH','4h','0.000325290000000','0.000322270000000','0.074446915466730','0.073755748555022','228.8632157973808','228.863215797380803','test'),('2019-12-24 03:59:59','2019-12-24 07:59:59','ARDRETH','4h','0.000324060000000','0.000320660000000','0.074446915466730','0.073665827049193','229.73188751073877','229.731887510738773','test'),('2019-12-25 11:59:59','2019-12-25 15:59:59','ARDRETH','4h','0.000323230000000','0.000320170000000','0.074446915466730','0.073742130758231','230.32180016313464','230.321800163134640','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:57:26
