-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 11:59:59','DASHBTC','4h','0.021439000000000','0.021156000000000','0.001467500000000','0.001448128644060','0.06845002098978498','0.068450020989785','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','DASHBTC','4h','0.021280000000000','0.020942000000000','0.001467500000000','0.001444191024436','0.06896146616541353','0.068961466165414','test'),('2019-01-09 19:59:59','2019-01-10 07:59:59','DASHBTC','4h','0.021501000000000','0.020148000000000','0.001467500000000','0.001375154178875','0.06825263941212037','0.068252639412120','test'),('2019-01-22 19:59:59','2019-01-22 23:59:59','DASHBTC','4h','0.019778000000000','0.019822000000000','0.001467500000000','0.001470764738598','0.07419860451006169','0.074198604510062','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','DASHBTC','4h','0.019753000000000','0.019540000000000','0.001467500000000','0.001451675694831','0.07429251252974232','0.074292512529742','test'),('2019-02-07 15:59:59','2019-02-08 19:59:59','DASHBTC','4h','0.019546000000000','0.020011000000000','0.001467500000000','0.001502411874552','0.075079300112555','0.075079300112555','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','DASHBTC','4h','0.021582000000000','0.021403000000000','0.001467500000000','0.001455328630340','0.06799647854693726','0.067996478546937','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','DASHBTC','4h','0.021608000000000','0.021530000000000','0.001467500000000','0.001462202656424','0.06791466123657905','0.067914661236579','test'),('2019-02-22 23:59:59','2019-02-23 03:59:59','DASHBTC','4h','0.021591000000000','0.021556000000000','0.001467500000000','0.001465121115280','0.06796813487101107','0.067968134871011','test'),('2019-02-23 19:59:59','2019-02-23 23:59:59','DASHBTC','4h','0.021700000000000','0.021609000000000','0.001467500000000','0.001461345967742','0.06762672811059908','0.067626728110599','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','DASHBTC','4h','0.021721000000000','0.021578000000000','0.001467500000000','0.001457838727499','0.0675613461626997','0.067561346162700','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','DASHBTC','4h','0.021570000000000','0.021442000000000','0.001467500000000','0.001458791608716','0.06803430690774225','0.068034306907742','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','DASHBTC','4h','0.021384000000000','0.021007000000000','0.001467500000000','0.001441627969510','0.06862607557052001','0.068626075570520','test'),('2019-03-06 19:59:59','2019-03-07 07:59:59','DASHBTC','4h','0.021475000000000','0.021240000000000','0.001467500000000','0.001451441210710','0.06833527357392316','0.068335273573923','test'),('2019-03-11 23:59:59','2019-03-20 07:59:59','DASHBTC','4h','0.021448000000000','0.022860000000000','0.001467500000000','0.001564110872809','0.0684212980231257','0.068421298023126','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','DASHBTC','4h','0.022649000000000','0.022543000000000','0.001467500000000','0.001460631926354','0.06479314760033555','0.064793147600336','test'),('2019-03-27 11:59:59','2019-04-02 07:59:59','DASHBTC','4h','0.023291000000000','0.025451000000000','0.001467500000000','0.001603595487527','0.0630071701515607','0.063007170151561','test'),('2019-05-01 15:59:59','2019-05-02 03:59:59','DASHBTC','4h','0.021819000000000','0.021674000000000','0.001474215582066','0.001464418558399','0.06756568046499609','0.067565680464996','test'),('2019-05-16 03:59:59','2019-05-16 11:59:59','DASHBTC','4h','0.019515000000000','0.019012000000000','0.001474215582066','0.001436217609338','0.07554268931929285','0.075542689319293','test'),('2019-05-17 23:59:59','2019-05-18 03:59:59','DASHBTC','4h','0.018936000000000','0.019002000000000','0.001474215582066','0.001479353849304','0.07785253390716096','0.077852533907161','test'),('2019-05-18 15:59:59','2019-05-19 07:59:59','DASHBTC','4h','0.018940000000000','0.019147000000000','0.001474215582066','0.001490327653105','0.07783609197814151','0.077836091978142','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','DASHBTC','4h','0.019777000000000','0.019986000000000','0.001474215582066','0.001489794843665','0.074541921528341','0.074541921528341','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','DASHBTC','4h','0.019857000000000','0.019791000000000','0.001474215582066','0.001469315636031','0.07424160659042152','0.074241606590422','test'),('2019-05-28 19:59:59','2019-05-28 23:59:59','DASHBTC','4h','0.019540000000000','0.019424000000000','0.001474215582066','0.001465463841661','0.07544603797676562','0.075446037976766','test'),('2019-05-29 15:59:59','2019-05-30 03:59:59','DASHBTC','4h','0.019681000000000','0.019647000000000','0.001474215582066','0.001471668794312','0.07490552218210457','0.074905522182105','test'),('2019-05-30 23:59:59','2019-05-31 07:59:59','DASHBTC','4h','0.019650000000000','0.019324000000000','0.001474215582066','0.001449757857906','0.07502369374381679','0.075023693743817','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','DASHBTC','4h','0.019386000000000','0.018854000000000','0.001474215582066','0.001433759444149','0.07604537202445064','0.076045372024451','test'),('2019-06-12 23:59:59','2019-06-13 19:59:59','DASHBTC','4h','0.019161000000000','0.018946000000000','0.001474215582066','0.001457673838413','0.07693834257429152','0.076938342574292','test'),('2019-07-25 15:59:59','2019-07-28 19:59:59','DASHBTC','4h','0.011519000000000','0.011430000000000','0.001474215582066','0.001462825254190','0.127981212090112','0.127981212090112','test'),('2019-08-14 03:59:59','2019-08-14 15:59:59','DASHBTC','4h','0.009598000000000','0.009551000000000','0.001474215582066','0.001466996564317','0.15359612232402584','0.153596122324026','test'),('2019-08-23 07:59:59','2019-08-23 15:59:59','DASHBTC','4h','0.009269000000000','0.009042000000000','0.001474215582066','0.001438111694146','0.15904796440457442','0.159047964404574','test'),('2019-08-24 15:59:59','2019-08-24 23:59:59','DASHBTC','4h','0.009138000000000','0.009092000000000','0.001474215582066','0.001466794492465','0.16132803480695995','0.161328034806960','test'),('2019-09-08 03:59:59','2019-09-10 23:59:59','DASHBTC','4h','0.008228000000000','0.008223000000000','0.001474215582066','0.001473319729136','0.1791705860556636','0.179170586055664','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','DASHBTC','4h','0.008312000000000','0.008193000000000','0.001474215582066','0.001453109752631','0.17735991122064487','0.177359911220645','test'),('2019-09-23 15:59:59','2019-09-23 19:59:59','DASHBTC','4h','0.009143000000000','0.009050000000000','0.001474215582066','0.001459220279744','0.16123980991643883','0.161239809916439','test'),('2019-10-06 03:59:59','2019-10-07 23:59:59','DASHBTC','4h','0.008641000000000','0.008640000000000','0.001474215582066','0.001474044975009','0.17060705729267447','0.170607057292674','test'),('2019-10-15 03:59:59','2019-10-15 11:59:59','DASHBTC','4h','0.008613000000000','0.008770000000000','0.001474215582066','0.001501087966413','0.17116168374155347','0.171161683741553','test'),('2019-10-17 19:59:59','2019-10-17 23:59:59','DASHBTC','4h','0.008585000000000','0.008545000000000','0.001474215582066','0.001467346784945','0.1717199280216657','0.171719928021666','test'),('2019-10-18 19:59:59','2019-10-18 23:59:59','DASHBTC','4h','0.008614000000000','0.008535000000000','0.001474215582066','0.001460695378794','0.171141813566984','0.171141813566984','test'),('2019-11-05 19:59:59','2019-11-06 11:59:59','DASHBTC','4h','0.007901000000000','0.007882000000000','0.001474215582066','0.001470670449037','0.18658594887558538','0.186585948875585','test'),('2019-11-06 23:59:59','2019-11-07 03:59:59','DASHBTC','4h','0.007934000000000','0.007900000000000','0.001474215582066','0.001467898046171','0.18580987926216286','0.185809879262163','test'),('2019-11-08 23:59:59','2019-11-09 03:59:59','DASHBTC','4h','0.007897000000000','0.007897000000000','0.001474215582066','0.001474215582066','0.18668045866354313','0.186680458663543','test'),('2019-11-18 03:59:59','2019-11-18 11:59:59','DASHBTC','4h','0.007983000000000','0.007881000000000','0.001474215582066','0.001455379306309','0.18466937016986096','0.184669370169861','test'),('2019-11-19 19:59:59','2019-11-20 11:59:59','DASHBTC','4h','0.008025000000000','0.007951000000000','0.001474215582066','0.001460621569222','0.18370287626990658','0.183702876269907','test'),('2019-11-21 19:59:59','2019-11-21 23:59:59','DASHBTC','4h','0.007943000000000','0.007911000000000','0.001474215582066','0.001468276403088','0.18559934307767845','0.185599343077678','test'),('2019-11-30 03:59:59','2019-11-30 07:59:59','DASHBTC','4h','0.007393000000000','0.007295000000000','0.001474215582066','0.001454673700957','0.19940695009684836','0.199406950096848','test'),('2019-12-14 03:59:59','2019-12-14 11:59:59','DASHBTC','4h','0.007042000000000','0.006994000000000','0.001474215582066','0.001464166966908','0.20934614911474014','0.209346149114740','test'),('2019-12-14 19:59:59','2019-12-15 03:59:59','DASHBTC','4h','0.007007000000000','0.007021000000000','0.001474215582066','0.001477161067744','0.2103918341752533','0.210391834175253','test'),('2019-12-29 11:59:59','2019-12-29 23:59:59','DASHBTC','4h','0.005985000000000','0.006024000000000','0.001474215582066','0.001483821999393','0.24631839299348374','0.246318392993484','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 11:28:57
