-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 11:59:59','2019-01-08 15:59:59','XZCETH','4h','0.038597000000000','0.039778000000000','0.072144500000000','0.074351994222349','1.869173769982123','1.869173769982123','test'),('2019-01-10 07:59:59','2019-01-13 11:59:59','XZCETH','4h','0.039020000000000','0.039375000000000','0.072696373555587','0.073357757784501','1.8630541659555933','1.863054165955593','test'),('2019-01-16 03:59:59','2019-01-25 19:59:59','XZCETH','4h','0.039712000000000','0.043092000000000','0.072861719612816','0.079063185474302','1.8347532134572864','1.834753213457286','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','XZCETH','4h','0.043029000000000','0.043409000000000','0.074412086078187','0.075069238061959','1.729347325714919','1.729347325714919','test'),('2019-01-29 19:59:59','2019-01-30 19:59:59','XZCETH','4h','0.043248000000000','0.043670000000000','0.074576374074130','0.075304066218490','1.7243889676778177','1.724388967677818','test'),('2019-02-01 07:59:59','2019-02-01 11:59:59','XZCETH','4h','0.043811000000000','0.043348000000000','0.074758297110220','0.073968242293803','1.7063818929086358','1.706381892908636','test'),('2019-02-03 07:59:59','2019-02-03 11:59:59','XZCETH','4h','0.043503000000000','0.042829000000000','0.074758297110220','0.073600053029299','1.718463028072087','1.718463028072087','test'),('2019-02-03 15:59:59','2019-02-05 03:59:59','XZCETH','4h','0.043379000000000','0.043828000000000','0.074758297110220','0.075532092619625','1.723375299343461','1.723375299343461','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','XZCETH','4h','0.043581000000000','0.043961000000000','0.074758297110220','0.075410144312025','1.715387373172254','1.715387373172254','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','XZCETH','4h','0.042963000000000','0.041017000000000','0.074758297110220','0.071372135851079','1.740062311994507','1.740062311994507','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','XZCETH','4h','0.041776000000000','0.040356000000000','0.074758297110220','0.072217202177806','1.7895034735307354','1.789503473530735','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','XZCETH','4h','0.039481000000000','0.038366000000000','0.074758297110220','0.072647015702001','1.8935259266538333','1.893525926653833','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','XZCETH','4h','0.038680000000000','0.038310000000000','0.074758297110220','0.074043184133726','1.9327377743076526','1.932737774307653','test'),('2019-02-25 23:59:59','2019-03-16 07:59:59','XZCETH','4h','0.038726000000000','0.047190000000000','0.074758297110220','0.091097558245914','1.930442005634974','1.930442005634974','test'),('2019-03-30 15:59:59','2019-03-30 19:59:59','XZCETH','4h','0.050316000000000','0.050514000000000','0.076524035703545','0.076825167730521','1.5208688231088472','1.520868823108847','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','XZCETH','4h','0.053354000000000','0.050279000000000','0.076599318710289','0.072184599944421','1.43568089946937','1.435680899469370','test'),('2019-04-03 23:59:59','2019-04-06 19:59:59','XZCETH','4h','0.052155000000000','0.051170000000000','0.076599318710289','0.075152662993107','1.4686860072915155','1.468686007291516','test'),('2019-04-07 11:59:59','2019-04-07 23:59:59','XZCETH','4h','0.053221000000000','0.051483000000000','0.076599318710289','0.074097869734913','1.4392686854867252','1.439268685486725','test'),('2019-06-02 15:59:59','2019-06-02 23:59:59','XZCETH','4h','0.029602000000000','0.028329000000000','0.076599318710289','0.073305253014789','2.587639980754307','2.587639980754307','test'),('2019-06-07 03:59:59','2019-06-21 19:59:59','XZCETH','4h','0.028228000000000','0.042404000000000','0.076599318710289','0.115067220865492','2.713593549322977','2.713593549322977','test'),('2019-06-29 15:59:59','2019-06-29 23:59:59','XZCETH','4h','0.041470000000000','0.040036000000000','0.083302071960608','0.080421551796839','2.0087309370775985','2.008730937077599','test'),('2019-07-03 23:59:59','2019-07-04 11:59:59','XZCETH','4h','0.041070000000000','0.039480000000000','0.083302071960608','0.080077083053441','2.0282949101682006','2.028294910168201','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','XZCETH','4h','0.039609000000000','0.039357000000000','0.083302071960608','0.082772088317141','2.1031096962964986','2.103109696296499','test'),('2019-07-06 15:59:59','2019-07-06 23:59:59','XZCETH','4h','0.040375000000000','0.039487000000000','0.083302071960608','0.081469942179778','2.0632092126466377','2.063209212646638','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','XZCETH','4h','0.039426000000000','0.038094000000000','0.083302071960608','0.080487727115797','2.1128715051135796','2.112871505113580','test'),('2019-07-13 11:59:59','2019-07-13 19:59:59','XZCETH','4h','0.040500000000000','0.038847000000000','0.083302071960608','0.079902113319845','2.056841282977975','2.056841282977975','test'),('2019-07-14 11:59:59','2019-07-25 03:59:59','XZCETH','4h','0.039934000000000','0.043289000000000','0.083302071960608','0.090300580785866','2.0859936886013926','2.085993688601393','test'),('2019-07-29 03:59:59','2019-07-29 07:59:59','XZCETH','4h','0.043168000000000','0.043242000000000','0.083302071960608','0.083444871101756','1.929718123624166','1.929718123624166','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','XZCETH','4h','0.043212000000000','0.043518000000000','0.083302071960608','0.083891964444639','1.9277532157874664','1.927753215787466','test'),('2019-08-09 03:59:59','2019-08-09 11:59:59','XZCETH','4h','0.040185000000000','0.038928000000000','0.083302071960608','0.080696355786551','2.0729643389475676','2.072964338947568','test'),('2019-08-09 19:59:59','2019-08-10 03:59:59','XZCETH','4h','0.039177000000000','0.038283000000000','0.083302071960608','0.081401159375857','2.126300430370064','2.126300430370064','test'),('2019-08-22 03:59:59','2019-08-22 07:59:59','XZCETH','4h','0.036374000000000','0.036157000000000','0.083302071960608','0.082805108480775','2.290154284945511','2.290154284945511','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','XZCETH','4h','0.036151000000000','0.035967000000000','0.083302071960608','0.082878084208105','2.3042812636056538','2.304281263605654','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','XZCETH','4h','0.036487000000000','0.035947000000000','0.083302071960608','0.082069218646860','2.283061692126182','2.283061692126182','test'),('2019-08-24 03:59:59','2019-08-24 07:59:59','XZCETH','4h','0.036268000000000','0.035993000000000','0.083302071960608','0.082670438846315','2.2968476883370466','2.296847688337047','test'),('2019-09-10 03:59:59','2019-09-10 15:59:59','XZCETH','4h','0.034031000000000','0.031340000000000','0.083302071960608','0.076714963863696','2.4478290958422617','2.447829095842262','test'),('2019-09-13 07:59:59','2019-09-13 11:59:59','XZCETH','4h','0.030900000000000','0.030479000000000','0.083302071960608','0.082167114928394','2.695859934000259','2.695859934000259','test'),('2019-09-24 23:59:59','2019-09-25 03:59:59','XZCETH','4h','0.027034000000000','0.026032000000000','0.083302071960608','0.080214527531203','3.0813816660726494','3.081381666072649','test'),('2019-09-25 07:59:59','2019-09-25 11:59:59','XZCETH','4h','0.026855000000000','0.026327000000000','0.083302071960608','0.081664257996907','3.101920385798101','3.101920385798101','test'),('2019-09-26 15:59:59','2019-09-26 19:59:59','XZCETH','4h','0.026916000000000','0.027041000000000','0.083302071960608','0.083688933269683','3.0948904726039532','3.094890472603953','test'),('2019-09-30 23:59:59','2019-10-09 15:59:59','XZCETH','4h','0.028800000000000','0.029153000000000','0.083302071960608','0.084323100828736','2.892433054187778','2.892433054187778','test'),('2019-10-10 23:59:59','2019-10-11 03:59:59','XZCETH','4h','0.031025000000000','0.029859000000000','0.083302071960608','0.080171363953966','2.684998290430556','2.684998290430556','test'),('2019-10-11 11:59:59','2019-10-12 07:59:59','XZCETH','4h','0.030919000000000','0.030330000000000','0.083302071960608','0.081715186214471','2.694203304136874','2.694203304136874','test'),('2019-10-13 19:59:59','2019-10-13 23:59:59','XZCETH','4h','0.030679000000000','0.030330000000000','0.083302071960608','0.082354439276549','2.7152798970177647','2.715279897017765','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','XZCETH','4h','0.030095000000000','0.029035000000000','0.083302071960608','0.080368023238952','2.7679704921285264','2.767970492128526','test'),('2019-10-28 03:59:59','2019-10-28 07:59:59','XZCETH','4h','0.028329000000000','0.027600000000000','0.083302071960608','0.081158430799279','2.9405228550463485','2.940522855046348','test'),('2019-11-07 23:59:59','2019-11-08 03:59:59','XZCETH','4h','0.026916000000000','0.026680000000000','0.083302071960608','0.082571677809073','3.0948904726039532','3.094890472603953','test'),('2019-11-21 19:59:59','2019-11-21 23:59:59','XZCETH','4h','0.025280000000000','0.025268000000000','0.083302071960608','0.083262529837842','3.295176897175949','3.295176897175949','test'),('2019-11-25 03:59:59','2019-11-25 11:59:59','XZCETH','4h','0.025198000000000','0.024820000000000','0.083302071960608','0.082052441704194','3.3059001492423206','3.305900149242321','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','XZCETH','4h','0.025024000000000','0.024600000000000','0.083302071960608','0.081890623810380','3.328887146763427','3.328887146763427','test'),('2019-12-16 19:59:59','2019-12-18 19:59:59','XZCETH','4h','0.023591000000000','0.023308000000000','0.083302071960608','0.082302771957859','3.5310954160742654','3.531095416074265','test'),('2019-12-19 03:59:59','2019-12-22 11:59:59','XZCETH','4h','0.023591000000000','0.023969000000000','0.083302071960608','0.084636826027884','3.5310954160742654','3.531095416074265','test'),('2019-12-22 23:59:59','2019-12-23 03:59:59','XZCETH','4h','0.024053000000000','0.023779000000000','0.083302071960608','0.082353135540319','3.4632716068934433','3.463271606893443','test'),('2019-12-23 19:59:59','2019-12-24 11:59:59','XZCETH','4h','0.023804000000000','0.023591000000000','0.083302071960608','0.082556678693610','3.4994989060917496','3.499498906091750','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','XZCETH','4h','0.023193000000000','0.022995000000000','0.083302071960608','0.082590917291173','3.5916902496705045','3.591690249670505','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  9:34:17
