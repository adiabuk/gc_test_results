-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-07 23:59:59','TNTETH','4h','0.000087260000000','0.000084910000000','0.072144500000000','0.070201575693330','826.7763007105202','826.776300710520218','test'),('2019-01-09 11:59:59','2019-01-10 19:59:59','TNTETH','4h','0.000091280000000','0.000089450000000','0.072144500000000','0.070698132394829','790.3648115687994','790.364811568799382','test'),('2019-01-29 19:59:59','2019-01-30 03:59:59','TNTETH','4h','0.000132760000000','0.000130700000000','0.072144500000000','0.071025053856583','543.4204579692679','543.420457969267886','test'),('2019-02-01 11:59:59','2019-02-02 23:59:59','TNTETH','4h','0.000131980000000','0.000132200000000','0.072144500000000','0.072264759054402','546.6320654644643','546.632065464464290','test'),('2019-02-10 07:59:59','2019-02-10 19:59:59','TNTETH','4h','0.000129040000000','0.000126420000000','0.072144500000000','0.070679693815871','559.0863298202108','559.086329820210835','test'),('2019-02-22 19:59:59','2019-02-23 11:59:59','TNTETH','4h','0.000120000000000','0.000113600000000','0.072144500000000','0.068296793333333','601.2041666666667','601.204166666666652','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','TNTETH','4h','0.000114000000000','0.000112680000000','0.072144500000000','0.071309142631579','632.8464912280701','632.846491228070136','test'),('2019-02-26 07:59:59','2019-02-27 15:59:59','TNTETH','4h','0.000113920000000','0.000111040000000','0.072144500000000','0.070320622191011','633.2909058988764','633.290905898876417','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','TNTETH','4h','0.000116340000000','0.000116490000000','0.072144500000000','0.072237517663744','620.1177582946536','620.117758294653640','test'),('2019-03-07 15:59:59','2019-03-21 15:59:59','TNTETH','4h','0.000116420000000','0.000134840000000','0.072144500000000','0.083559219893489','619.6916337399073','619.691633739907275','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','TNTETH','4h','0.000136620000000','0.000137540000000','0.072144500000000','0.072630321548822','528.0669008929879','528.066900892987860','test'),('2019-04-20 15:59:59','2019-04-20 19:59:59','TNTETH','4h','0.000124770000000','0.000123830000000','0.072144500000000','0.071600973270818','578.2199246613769','578.219924661376922','test'),('2019-05-08 07:59:59','2019-05-08 11:59:59','TNTETH','4h','0.000106220000000','0.000105900000000','0.072144500000000','0.071927156373564','679.198832611561','679.198832611560988','test'),('2019-05-21 19:59:59','2019-05-26 23:59:59','TNTETH','4h','0.000111540000000','0.000115710000000','0.072144500000000','0.074841672001076','646.8038371884526','646.803837188452576','test'),('2019-05-28 03:59:59','2019-05-30 03:59:59','TNTETH','4h','0.000116000000000','0.000112300000000','0.072536908430613','0.070223231178947','625.318176125972','625.318176125971945','test'),('2019-05-31 03:59:59','2019-06-01 03:59:59','TNTETH','4h','0.000118650000000','0.000113250000000','0.072536908430613','0.069235607920497','611.3519463178509','611.351946317850889','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','TNTETH','4h','0.000118210000000','0.000118450000000','0.072536908430613','0.072684179033974','613.6275140056933','613.627514005693342','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','TNTETH','4h','0.000119420000000','0.000118600000000','0.072536908430613','0.072038832187830','607.4100521739491','607.410052173949111','test'),('2019-06-05 11:59:59','2019-06-06 23:59:59','TNTETH','4h','0.000121850000000','0.000117260000000','0.072536908430613','0.069804496369091','595.2967454297333','595.296745429733278','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','TNTETH','4h','0.000128000000000','0.000127140000000','0.072536908430613','0.072049551077095','566.6945971141641','566.694597114164139','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','TNTETH','4h','0.000207330000000','0.000202200000000','0.072536908430613','0.070742115876477','349.86209632283317','349.862096322833168','test'),('2019-07-12 19:59:59','2019-07-12 23:59:59','TNTETH','4h','0.000203450000000','0.000195530000000','0.072536908430613','0.069713156576249','356.53432504602114','356.534325046021138','test'),('2019-07-16 15:59:59','2019-07-16 19:59:59','TNTETH','4h','0.000205650000000','0.000195050000000','0.072536908430613','0.068798074346662','352.7201965991393','352.720196599139285','test'),('2019-07-21 07:59:59','2019-07-21 11:59:59','TNTETH','4h','0.000196760000000','0.000203900000000','0.072536908430613','0.075169117854249','368.65678202181846','368.656782021818458','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','TNTETH','4h','0.000196140000000','0.000194830000000','0.072536908430613','0.072052441468014','369.82210885394613','369.822108853946133','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','TNTETH','4h','0.000196850000000','0.000194190000000','0.072536908430613','0.071556729734014','368.48823180397767','368.488231803977669','test'),('2019-08-10 11:59:59','2019-08-10 23:59:59','TNTETH','4h','0.000189180000000','0.000168540000000','0.072536908430613','0.064622954577099','383.427996778798','383.427996778797990','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','TNTETH','4h','0.000166070000000','0.000162770000000','0.072536908430613','0.071095517464026','436.7851413898537','436.785141389853720','test'),('2019-08-16 03:59:59','2019-08-16 07:59:59','TNTETH','4h','0.000166050000000','0.000164140000000','0.072536908430613','0.071702548327617','436.83775025963865','436.837750259638653','test'),('2019-08-16 11:59:59','2019-08-16 15:59:59','TNTETH','4h','0.000166360000000','0.000158150000000','0.072536908430613','0.068957153572382','436.02373425470665','436.023734254706653','test'),('2019-08-17 19:59:59','2019-08-17 23:59:59','TNTETH','4h','0.000164750000000','0.000160750000000','0.072536908430613','0.070775769530932','440.284724920261','440.284724920260999','test'),('2019-08-19 11:59:59','2019-08-19 15:59:59','TNTETH','4h','0.000165630000000','0.000167790000000','0.072536908430613','0.073482870648871','437.9454714158848','437.945471415884811','test'),('2019-08-20 15:59:59','2019-08-21 07:59:59','TNTETH','4h','0.000164850000000','0.000167260000000','0.072536908430613','0.073597350949981','440.017642891192','440.017642891191997','test'),('2019-08-28 07:59:59','2019-08-28 11:59:59','TNTETH','4h','0.000174910000000','0.000171760000000','0.072536908430613','0.071230572248826','414.70989898012124','414.709898980121238','test'),('2019-08-29 11:59:59','2019-08-29 15:59:59','TNTETH','4h','0.000177120000000','0.000175810000000','0.072536908430613','0.072000417068575','409.53539086841124','409.535390868411241','test'),('2019-09-02 11:59:59','2019-09-02 15:59:59','TNTETH','4h','0.000181600000000','0.000177930000000','0.072536908430613','0.071070991834025','399.43231514654735','399.432315146547353','test'),('2019-09-19 03:59:59','2019-09-19 11:59:59','TNTETH','4h','0.000164830000000','0.000156860000000','0.072536908430613','0.069029542294643','440.07103337143116','440.071033371431156','test'),('2019-10-27 07:59:59','2019-10-27 11:59:59','TNTETH','4h','0.000444620000000','0.000399740000000','0.072536908430613','0.065215023561813','163.14360224599207','163.143602245992071','test'),('2019-11-07 15:59:59','2019-11-07 19:59:59','TNTETH','4h','0.000384550000000','0.000370110000000','0.072536908430613','0.069813119696409','188.62802868447017','188.628028684470166','test'),('2019-11-08 07:59:59','2019-11-08 15:59:59','TNTETH','4h','0.000381680000000','0.000352480000000','0.072536908430613','0.066987553667005','190.04639601397244','190.046396013972441','test'),('2019-11-12 03:59:59','2019-11-12 07:59:59','TNTETH','4h','0.000365940000000','0.000364680000000','0.072536908430613','0.072287150260906','198.22076960871456','198.220769608714562','test'),('2019-11-13 11:59:59','2019-11-18 19:59:59','TNTETH','4h','0.000373970000000','0.000392330000000','0.072536908430613','0.076098096864942','193.96451167369844','193.964511673698439','test'),('2019-11-20 07:59:59','2019-11-20 11:59:59','TNTETH','4h','0.000396470000000','0.000391220000000','0.072536908430613','0.071576384887191','182.95686541380937','182.956865413809368','test'),('2019-11-23 03:59:59','2019-11-24 15:59:59','TNTETH','4h','0.000391220000000','0.000395930000000','0.072536908430613','0.073410199261113','185.4120659235545','185.412065923554508','test'),('2019-12-19 07:59:59','2019-12-20 11:59:59','TNTETH','4h','0.000349720000000','0.000361480000000','0.072536908430613','0.074976099907063','207.41424119470722','207.414241194707216','test'),('2019-12-22 03:59:59','2019-12-22 07:59:59','TNTETH','4h','0.000347020000000','0.000347920000000','0.072536908430613','0.072725033661400','209.02803420728776','209.028034207287760','test'),('2019-12-23 19:59:59','2019-12-25 03:59:59','TNTETH','4h','0.000359710000000','0.000343970000000','0.072536908430613','0.069362876742037','201.65385569100943','201.653855691009426','test'),('2019-12-27 23:59:59','2019-12-28 03:59:59','TNTETH','4h','0.000348070000000','0.000338800000000','0.072536908430613','0.070605063855810','208.39747301006406','208.397473010064061','test'),('2020-01-01 03:59:59','2020-01-01 15:59:59','TNTETH','4h','0.000344860000000','0.000362890000000','0.072536908430613','0.076329289277925','210.33726274607957','210.337262746079574','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 18:05:54
