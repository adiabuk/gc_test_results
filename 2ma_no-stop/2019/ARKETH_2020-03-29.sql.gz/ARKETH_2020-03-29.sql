-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-04 15:59:59','ARKETH','4h','0.003107000000000','0.002999000000000','0.072144500000000','0.069636741390409','23.219987125844867','23.219987125844867','test'),('2019-01-06 19:59:59','2019-01-07 07:59:59','ARKETH','4h','0.002998000000000','0.002920000000000','0.072144500000000','0.070267491661107','24.06420947298199','24.064209472981990','test'),('2019-01-07 15:59:59','2019-01-07 19:59:59','ARKETH','4h','0.002948000000000','0.002973000000000','0.072144500000000','0.072756308853460','24.472354138398913','24.472354138398913','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','ARKETH','4h','0.003105000000000','0.003116000000000','0.072144500000000','0.072400084380032','23.234943639291465','23.234943639291465','test'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ARKETH','4h','0.003100000000000','0.003123000000000','0.072144500000000','0.072679765645161','23.27241935483871','23.272419354838711','test'),('2019-02-08 15:59:59','2019-02-09 11:59:59','ARKETH','4h','0.004223000000000','0.003526000000000','0.072144500000000','0.060237155339806','17.08370826426711','17.083708264267109','test'),('2019-02-10 11:59:59','2019-02-15 11:59:59','ARKETH','4h','0.004389000000000','0.003962000000000','0.072144500000000','0.065125657097289','16.437571200729096','16.437571200729096','test'),('2019-02-17 03:59:59','2019-02-18 03:59:59','ARKETH','4h','0.003966000000000','0.004236000000000','0.072144500000000','0.077056001512859','18.190746343923347','18.190746343923347','test'),('2019-02-21 15:59:59','2019-02-21 19:59:59','ARKETH','4h','0.004287000000000','0.004269000000000','0.072144500000000','0.071841583974808','16.82866806624679','16.828668066246792','test'),('2019-02-22 15:59:59','2019-02-22 19:59:59','ARKETH','4h','0.004290000000000','0.004311000000000','0.072144500000000','0.072497654895105','16.816899766899766','16.816899766899766','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ARKETH','4h','0.004223000000000','0.004144000000000','0.072144500000000','0.070794887047123','17.08370826426711','17.083708264267109','test'),('2019-02-27 03:59:59','2019-02-27 11:59:59','ARKETH','4h','0.004336000000000','0.004505000000000','0.072144500000000','0.074956405096863','16.638491697416974','16.638491697416974','test'),('2019-02-28 23:59:59','2019-03-01 15:59:59','ARKETH','4h','0.004281000000000','0.004190000000000','0.072144500000000','0.070610944872693','16.852254146227516','16.852254146227516','test'),('2019-03-01 23:59:59','2019-03-02 15:59:59','ARKETH','4h','0.004232000000000','0.004209000000000','0.072144500000000','0.071752410326087','17.047377126654066','17.047377126654066','test'),('2019-03-05 03:59:59','2019-03-05 07:59:59','ARKETH','4h','0.004238000000000','0.004215000000000','0.072144500000000','0.071752965431807','17.023242095327987','17.023242095327987','test'),('2019-03-09 15:59:59','2019-03-11 07:59:59','ARKETH','4h','0.004184000000000','0.004257000000000','0.072144500000000','0.073403235301147','17.242949330783937','17.242949330783937','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','ARKETH','4h','0.004569000000000','0.004560000000000','0.072144500000000','0.072002390019698','15.789997811337273','15.789997811337273','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','ARKETH','4h','0.004616000000000','0.004551000000000','0.072144500000000','0.071128600411612','15.629224436741767','15.629224436741767','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','ARKETH','4h','0.004575000000000','0.004555000000000','0.072144500000000','0.071829114207650','15.769289617486338','15.769289617486338','test'),('2019-03-21 03:59:59','2019-03-21 07:59:59','ARKETH','4h','0.004602000000000','0.004608000000000','0.072144500000000','0.072238560625815','15.676770969143849','15.676770969143849','test'),('2019-03-22 03:59:59','2019-03-22 19:59:59','ARKETH','4h','0.004625000000000','0.004624000000000','0.072144500000000','0.072128901189189','15.59881081081081','15.598810810810811','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','ARKETH','4h','0.004604000000000','0.004609000000000','0.072144500000000','0.072222849804518','15.66996090356212','15.669960903562121','test'),('2019-03-26 07:59:59','2019-03-26 15:59:59','ARKETH','4h','0.004583000000000','0.004484000000000','0.072144500000000','0.070586065459306','15.741763037311804','15.741763037311804','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','ARKETH','4h','0.004621000000000','0.004617000000000','0.072144500000000','0.072082050746592','15.612313352088293','15.612313352088293','test'),('2019-03-30 15:59:59','2019-04-02 07:59:59','ARKETH','4h','0.004756000000000','0.004775000000000','0.072144500000000','0.072432713940286','15.169154751892346','15.169154751892346','test'),('2019-04-14 15:59:59','2019-04-14 23:59:59','ARKETH','4h','0.004068000000000','0.003997000000000','0.072144500000000','0.070885340830875','17.734636184857425','17.734636184857425','test'),('2019-04-15 11:59:59','2019-04-15 15:59:59','ARKETH','4h','0.003988000000000','0.003867000000000','0.072144500000000','0.069955562061184','18.090396188565695','18.090396188565695','test'),('2019-04-25 15:59:59','2019-04-25 19:59:59','ARKETH','4h','0.003743000000000','0.003426000000000','0.072144500000000','0.066034479561849','19.274512423189957','19.274512423189957','test'),('2019-05-13 11:59:59','2019-05-13 15:59:59','ARKETH','4h','0.002817000000000','0.002707000000000','0.072144500000000','0.069327355875044','25.61040113596024','25.610401135960242','test'),('2019-05-14 15:59:59','2019-05-14 19:59:59','ARKETH','4h','0.002883000000000','0.002782000000000','0.072144500000000','0.069617065209851','25.0241068331599','25.024106833159902','test'),('2019-05-22 23:59:59','2019-05-23 03:59:59','ARKETH','4h','0.002542000000000','0.002508000000000','0.072144500000000','0.071179546026751','28.38099921321794','28.380999213217940','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','ARKETH','4h','0.002514000000000','0.002522000000000','0.072144500000000','0.072374076770088','28.697096260938743','28.697096260938743','test'),('2019-06-07 11:59:59','2019-06-07 19:59:59','ARKETH','4h','0.002377000000000','0.002410000000000','0.072144500000000','0.073146085401767','30.351072780816153','30.351072780816153','test'),('2019-07-07 07:59:59','2019-07-07 15:59:59','ARKETH','4h','0.001616000000000','0.001584000000000','0.072144500000000','0.070715896039604','44.64387376237624','44.643873762376238','test'),('2019-07-16 11:59:59','2019-07-16 15:59:59','ARKETH','4h','0.001489000000000','0.001435000000000','0.072144500000000','0.069528111148422','48.45164539959704','48.451645399597041','test'),('2019-07-22 07:59:59','2019-07-30 15:59:59','ARKETH','4h','0.001467000000000','0.001718000000000','0.072144500000000','0.084488241990457','49.17825494205862','49.178254942058622','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','ARKETH','4h','0.001212000000000','0.001202000000000','0.072144500000000','0.071549248349835','59.52516501650165','59.525165016501653','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','ARKETH','4h','0.001215000000000','0.001200000000000','0.072144500000000','0.071253827160494','59.37818930041153','59.378189300411528','test'),('2019-08-26 19:59:59','2019-08-27 11:59:59','ARKETH','4h','0.001217000000000','0.001226000000000','0.072144500000000','0.072678025472473','59.280608052588335','59.280608052588335','test'),('2019-08-30 19:59:59','2019-08-30 23:59:59','ARKETH','4h','0.001225000000000','0.001206000000000','0.072144500000000','0.071025524081633','58.893469387755104','58.893469387755104','test'),('2019-09-01 07:59:59','2019-09-01 23:59:59','ARKETH','4h','0.001262000000000','0.001209000000000','0.072144500000000','0.069114659667195','57.16679873217115','57.166798732171152','test'),('2019-09-03 23:59:59','2019-09-04 19:59:59','ARKETH','4h','0.001294000000000','0.001212000000000','0.072144500000000','0.067572746522411','55.753091190108194','55.753091190108194','test'),('2019-09-06 15:59:59','2019-09-07 19:59:59','ARKETH','4h','0.001259000000000','0.001224000000000','0.072144500000000','0.070138894360604','57.30301826846704','57.303018268467042','test'),('2019-09-08 19:59:59','2019-09-09 07:59:59','ARKETH','4h','0.001248000000000','0.001223000000000','0.072144500000000','0.070699297676282','57.80809294871795','57.808092948717949','test'),('2019-09-09 19:59:59','2019-09-11 03:59:59','ARKETH','4h','0.001309000000000','0.001246000000000','0.072144500000000','0.068672304812834','55.11420932009167','55.114209320091668','test'),('2019-09-12 15:59:59','2019-09-13 03:59:59','ARKETH','4h','0.001311000000000','0.001258000000000','0.072144500000000','0.069227903127384','55.0301296720061','55.030129672006098','test'),('2019-10-04 03:59:59','2019-10-04 15:59:59','ARKETH','4h','0.001028000000000','0.001018000000000','0.072144500000000','0.071442705252918','70.1794747081712','70.179474708171199','test'),('2019-10-11 19:59:59','2019-10-20 03:59:59','ARKETH','4h','0.001043000000000','0.001105000000000','0.072144500000000','0.076433051294343','69.17018216682645','69.170182166826450','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','ARKETH','4h','0.001112000000000','0.001087000000000','0.072144500000000','0.070522546312950','64.8781474820144','64.878147482014398','test'),('2019-10-24 23:59:59','2019-10-25 03:59:59','ARKETH','4h','0.001118000000000','0.001090000000000','0.072144500000000','0.070337661001789','64.52996422182468','64.529964221824685','test'),('2019-10-25 07:59:59','2019-10-25 19:59:59','ARKETH','4h','0.001138000000000','0.001107000000000','0.072144500000000','0.070179228031634','63.395869947275926','63.395869947275926','test'),('2019-10-28 11:59:59','2019-10-29 23:59:59','ARKETH','4h','0.001125000000000','0.001076000000000','0.072144500000000','0.069002206222222','64.12844444444445','64.128444444444455','test'),('2019-11-01 19:59:59','2019-11-01 23:59:59','ARKETH','4h','0.001128000000000','0.001116000000000','0.072144500000000','0.071377005319149','63.957890070921984','63.957890070921984','test'),('2019-11-11 23:59:59','2019-11-12 03:59:59','ARKETH','4h','0.001149000000000','0.001165000000000','0.072144500000000','0.073149123150566','62.78894691035683','62.788946910356827','test'),('2019-11-14 15:59:59','2019-11-14 19:59:59','ARKETH','4h','0.001158000000000','0.001149000000000','0.072144500000000','0.071583791450777','62.30094991364422','62.300949913644217','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','ARKETH','4h','0.001161000000000','0.001137000000000','0.072144500000000','0.070653140826873','62.13996554694229','62.139965546942292','test'),('2019-11-17 07:59:59','2019-11-17 11:59:59','ARKETH','4h','0.001152000000000','0.001148000000000','0.072144500000000','0.071893998263889','62.62543402777778','62.625434027777779','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','ARKETH','4h','0.001116000000000','0.001102000000000','0.072144500000000','0.071239461469534','64.64560931899642','64.645609318996421','test'),('2019-11-26 07:59:59','2019-11-26 19:59:59','ARKETH','4h','0.001119000000000','0.001139000000000','0.072144500000000','0.073433945933870','64.47229669347632','64.472296693476324','test'),('2019-12-06 07:59:59','2019-12-10 03:59:59','ARKETH','4h','0.001200000000000','0.001200000000000','0.072144500000000','0.072144500000000','60.12041666666667','60.120416666666671','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','ARKETH','4h','0.001207000000000','0.001195000000000','0.072144500000000','0.071427239022370','59.77174813587407','59.771748135874070','test'),('2019-12-16 03:59:59','2019-12-16 11:59:59','ARKETH','4h','0.001202000000000','0.001187000000000','0.072144500000000','0.071244194259567','60.02038269550749','60.020382695507493','test'),('2019-12-16 19:59:59','2019-12-17 03:59:59','ARKETH','4h','0.001225000000000','0.001201000000000','0.072144500000000','0.070731056734694','58.893469387755104','58.893469387755104','test'),('2019-12-19 19:59:59','2019-12-21 15:59:59','ARKETH','4h','0.001197000000000','0.001196000000000','0.072144500000000','0.072084228905597','60.271094402673356','60.271094402673356','test'),('2019-12-23 23:59:59','2019-12-24 03:59:59','ARKETH','4h','0.001201000000000','0.001174000000000','0.072144500000000','0.070522600333056','60.07035803497086','60.070358034970859','test'),('2019-12-29 03:59:59','2019-12-29 15:59:59','ARKETH','4h','0.001180000000000','0.001141000000000','0.072144500000000','0.069760063135593','61.139406779661016','61.139406779661016','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 22:24:57
