-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 07:59:59','2019-01-04 11:59:59','OSTBNB','4h','0.004281000000000','0.004116000000000','0.711908500000000','0.684469840224247','166.29490773183838','166.294907731838379','test'),('2019-01-06 15:59:59','2019-01-06 23:59:59','OSTBNB','4h','0.004305000000000','0.004107000000000','0.711908500000000','0.679165670034843','165.36782810685253','165.367828106852528','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','OSTBNB','4h','0.003874000000000','0.003638000000000','0.711908500000000','0.668539783944244','183.7657459989675','183.765745998967503','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','OSTBNB','4h','0.003822000000000','0.003858000000000','0.711908500000000','0.718614074568289','186.26596023024595','186.265960230245952','test'),('2019-02-17 03:59:59','2019-02-18 03:59:59','OSTBNB','4h','0.002465000000000','0.002355000000000','0.711908500000000','0.680139763691684','288.80669371196757','288.806693711967569','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','OSTBNB','4h','0.002390000000000','0.002349000000000','0.711908500000000','0.699695843723849','297.86966527196654','297.869665271966539','test'),('2019-02-25 19:59:59','2019-02-27 23:59:59','OSTBNB','4h','0.002363000000000','0.002312000000000','0.711908500000000','0.696543568345324','301.2731696995345','301.273169699534492','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','OSTBNB','4h','0.001876000000000','0.001839000000000','0.711908500000000','0.697867660714286','379.4821428571429','379.482142857142890','test'),('2019-03-15 23:59:59','2019-03-16 03:59:59','OSTBNB','4h','0.001855000000000','0.001832000000000','0.711908500000000','0.703081602156334','383.778167115903','383.778167115902988','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','OSTBNB','4h','0.001829000000000','0.001828000000000','0.711908500000000','0.711519266265719','389.2337342810279','389.233734281027921','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','OSTBNB','4h','0.001826000000000','0.001805000000000','0.711908500000000','0.703721162376780','389.8732201533407','389.873220153340696','test'),('2019-03-27 03:59:59','2019-03-28 15:59:59','OSTBNB','4h','0.001817000000000','0.001793000000000','0.711908500000000','0.702505195652174','391.804347826087','391.804347826086996','test'),('2019-04-08 03:59:59','2019-04-08 07:59:59','OSTBNB','4h','0.001676000000000','0.001651000000000','0.711908500000000','0.701289339797136','424.7664081145585','424.766408114558487','test'),('2019-04-08 23:59:59','2019-04-09 03:59:59','OSTBNB','4h','0.001672000000000','0.001651000000000','0.711908500000000','0.702967065490431','425.7825956937799','425.782595693779911','test'),('2019-05-06 19:59:59','2019-05-07 03:59:59','OSTBNB','4h','0.001031000000000','0.001016000000000','0.711908500000000','0.701550956353055','690.5029097963143','690.502909796314270','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','OSTBNB','4h','0.001035000000000','0.001009000000000','0.711908500000000','0.694024808212560','687.8342995169083','687.834299516908345','test'),('2019-05-11 23:59:59','2019-05-12 03:59:59','OSTBNB','4h','0.001034000000000','0.001013000000000','0.711908500000000','0.697450010154739','688.4995164410059','688.499516441005881','test'),('2019-05-26 11:59:59','2019-05-26 19:59:59','OSTBNB','4h','0.000835000000000','0.000833000000000','0.711908500000000','0.710203329940120','852.5850299401199','852.585029940119853','test'),('2019-05-27 19:59:59','2019-05-27 23:59:59','OSTBNB','4h','0.000824000000000','0.000846000000000','0.711908500000000','0.730915765776699','863.9666262135923','863.966626213592349','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','OSTBNB','4h','0.000849000000000','0.000868000000000','0.711908500000000','0.727840492343934','838.5259128386338','838.525912838633758','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','OSTBNB','4h','0.000852000000000','0.000860000000000','0.711908500000000','0.718593086854460','835.5733568075118','835.573356807511800','test'),('2019-06-05 11:59:59','2019-06-05 23:59:59','OSTBNB','4h','0.000910000000000','0.000848000000000','0.711908500000000','0.663404843956044','782.317032967033','782.317032967033015','test'),('2019-06-07 07:59:59','2019-06-10 11:59:59','OSTBNB','4h','0.000855000000000','0.000862000000000','0.711908500000000','0.717736990643275','832.6415204678364','832.641520467836358','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','OSTBNB','4h','0.000946000000000','0.000864000000000','0.711908500000000','0.650199729386892','752.5459830866808','752.545983086680849','test'),('2019-06-15 15:59:59','2019-06-15 19:59:59','OSTBNB','4h','0.000862000000000','0.000867000000000','0.711908500000000','0.716037899651972','825.8799303944315','825.879930394431540','test'),('2019-06-20 03:59:59','2019-06-20 07:59:59','OSTBNB','4h','0.000879000000000','0.000826000000000','0.711908500000000','0.668983414106940','809.9072810011377','809.907281001137676','test'),('2019-07-07 23:59:59','2019-07-08 07:59:59','OSTBNB','4h','0.000651000000000','0.000639000000000','0.711908500000000','0.698785762672811','1093.5614439324117','1093.561443932411748','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','OSTBNB','4h','0.000551000000000','0.000520000000000','0.711908500000000','0.671855571687840','1292.0299455535392','1292.029945553539164','test'),('2019-07-23 15:59:59','2019-07-23 19:59:59','OSTBNB','4h','0.000522200000000','0.000526900000000','0.711908500000000','0.718315949157411','1363.287054768288','1363.287054768288044','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','OSTBNB','4h','0.000520800000000','0.000514500000000','0.711908500000000','0.703296703629032','1366.9518049155147','1366.951804915514685','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','OSTBNB','4h','0.000536800000000','0.000509000000000','0.711908500000000','0.675039915238450','1326.208084947839','1326.208084947839097','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','OSTBNB','4h','0.000522000000000','0.000508400000000','0.711908500000000','0.693360692337165','1363.8093869731802','1363.809386973180153','test'),('2019-07-26 11:59:59','2019-07-27 11:59:59','OSTBNB','4h','0.000526100000000','0.000505600000000','0.711908500000000','0.684168290439080','1353.1809541912185','1353.180954191218461','test'),('2019-07-28 07:59:59','2019-07-28 11:59:59','OSTBNB','4h','0.000521000000000','0.000517500000000','0.711908500000000','0.707126005278311','1366.4270633397314','1366.427063339731376','test'),('2019-07-28 15:59:59','2019-07-28 23:59:59','OSTBNB','4h','0.000523800000000','0.000508000000000','0.711908500000000','0.690434360442917','1359.122756777396','1359.122756777396035','test'),('2019-07-29 07:59:59','2019-07-31 07:59:59','OSTBNB','4h','0.000528200000000','0.000523200000000','0.711908500000000','0.705169494888300','1347.8010223400227','1347.801022340022655','test'),('2019-08-21 11:59:59','2019-08-28 19:59:59','OSTBNB','4h','0.000371000000000','0.000430300000000','0.711908500000000','0.825698726549865','1918.890835579515','1918.890835579514942','test'),('2019-09-04 03:59:59','2019-09-05 19:59:59','OSTBNB','4h','0.000491600000000','0.000470700000000','0.711908500000000','0.681642251729048','1448.1458502847845','1448.145850284784501','test'),('2019-09-06 15:59:59','2019-09-06 19:59:59','OSTBNB','4h','0.000471600000000','0.000482700000000','0.711908500000000','0.728664616094148','1509.5600084817643','1509.560008481764271','test'),('2019-09-13 15:59:59','2019-09-15 07:59:59','OSTBNB','4h','0.000538000000000','0.000533600000000','0.711908500000000','0.706086200000000','1323.2500000000002','1323.250000000000227','test'),('2019-09-18 23:59:59','2019-09-25 07:59:59','OSTBNB','4h','0.000539000000000','0.000607600000000','0.711908500000000','0.802515036363637','1320.7949907235623','1320.794990723562250','test'),('2019-10-02 11:59:59','2019-10-09 15:59:59','OSTBNB','4h','0.000669300000000','0.000702200000000','0.711908500000000','0.746902956372329','1063.661287912745','1063.661287912744910','test'),('2019-10-10 15:59:59','2019-10-10 23:59:59','OSTBNB','4h','0.000764400000000','0.000715500000000','0.711908500000000','0.666366472723705','931.3298011512297','931.329801151229731','test'),('2019-10-21 23:59:59','2019-10-22 07:59:59','OSTBNB','4h','0.000669900000000','0.000641800000000','0.711908500000000','0.682046387968354','1062.7086132258548','1062.708613225854833','test'),('2019-10-22 15:59:59','2019-10-22 19:59:59','OSTBNB','4h','0.000670000000000','0.000643000000000','0.711908500000000','0.683219650000000','1062.55','1062.549999999999955','test'),('2019-10-22 23:59:59','2019-10-23 03:59:59','OSTBNB','4h','0.000654900000000','0.000624300000000','0.711908500000000','0.678644795464956','1087.0491678118797','1087.049167811879670','test'),('2019-10-30 15:59:59','2019-10-31 07:59:59','OSTBNB','4h','0.000628600000000','0.000589000000000','0.711908500000000','0.667060303054407','1132.530225898823','1132.530225898822891','test'),('2019-10-31 11:59:59','2019-10-31 15:59:59','OSTBNB','4h','0.000611900000000','0.000595700000000','0.711908500000000','0.693060783543063','1163.4392874652722','1163.439287465272173','test'),('2019-11-01 15:59:59','2019-11-01 19:59:59','OSTBNB','4h','0.000606700000000','0.000589800000000','0.711908500000000','0.692077852810285','1173.4110763144884','1173.411076314488355','test'),('2019-11-03 11:59:59','2019-11-04 03:59:59','OSTBNB','4h','0.000599100000000','0.000591600000000','0.711908500000000','0.702996275413120','1188.296611584043','1188.296611584042921','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','OSTBNB','4h','0.000602500000000','0.000598200000000','0.711908500000000','0.706827659253112','1181.5908713692947','1181.590871369294746','test'),('2019-11-16 11:59:59','2019-11-19 15:59:59','OSTBNB','4h','0.000559400000000','0.000590600000000','0.711908500000000','0.751614515731141','1272.6287093314265','1272.628709331426535','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','OSTBNB','4h','0.000595200000000','0.000574700000000','0.711908500000000','0.687388801999328','1196.0828293010752','1196.082829301075208','test'),('2019-11-23 11:59:59','2019-11-23 15:59:59','OSTBNB','4h','0.000587400000000','0.000574700000000','0.711908500000000','0.696516538900238','1211.9654409261152','1211.965440926115207','test'),('2019-11-23 23:59:59','2019-11-24 07:59:59','OSTBNB','4h','0.000587300000000','0.000580200000000','0.711908500000000','0.703302080197514','1212.1718031670357','1212.171803167035705','test'),('2019-12-06 19:59:59','2019-12-08 11:59:59','OSTBNB','4h','0.000667200000000','0.000667300000000','0.711908500000000','0.712015200914269','1067.0091426858514','1067.009142685851430','test'),('2019-12-11 03:59:59','2019-12-11 07:59:59','OSTBNB','4h','0.000666100000000','0.000661800000000','0.711908500000000','0.707312783816244','1068.7712055246961','1068.771205524696143','test'),('2019-12-11 23:59:59','2019-12-12 03:59:59','OSTBNB','4h','0.000672600000000','0.000657300000000','0.711908500000000','0.695714328055308','1058.4426107641987','1058.442610764198662','test'),('2019-12-12 07:59:59','2019-12-22 19:59:59','OSTBNB','4h','0.000705700000000','0.000882100000000','0.711908500000000','0.889860405058807','1008.7976477256626','1008.797647725662614','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:20:06
