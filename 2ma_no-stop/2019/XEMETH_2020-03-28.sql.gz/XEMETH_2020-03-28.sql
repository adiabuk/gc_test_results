-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-12 03:59:59','XEMETH','4h','0.000469060000000','0.000442470000000','0.072144500000000','0.068054783854944','153.80654926875027','153.806549268750274','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','XEMETH','4h','0.000454900000000','0.000450730000000','0.072144500000000','0.071483162200484','158.59419652670917','158.594196526709169','test'),('2019-01-15 23:59:59','2019-01-16 11:59:59','XEMETH','4h','0.000460760000000','0.000454820000000','0.072144500000000','0.071214431569581','156.5771768382672','156.577176838267206','test'),('2019-02-14 23:59:59','2019-02-15 11:59:59','XEMETH','4h','0.000351740000000','0.000343350000000','0.072144500000000','0.070423648362427','205.10746574174104','205.107465741741038','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','XEMETH','4h','0.000316490000000','0.000305280000000','0.072144500000000','0.069589159088755','227.95191001295458','227.951910012954585','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','XEMETH','4h','0.000312620000000','0.000310200000000','0.072144500000000','0.071586027445461','230.77378286737894','230.773782867378941','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','XEMETH','4h','0.000312200000000','0.000311970000000','0.072144500000000','0.072091350624600','231.08424087123637','231.084240871236375','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','XEMETH','4h','0.000314230000000','0.000313380000000','0.072144500000000','0.071949347325208','229.59138210864654','229.591382108646542','test'),('2019-04-08 19:59:59','2019-04-09 11:59:59','XEMETH','4h','0.000418070000000','0.000408960000000','0.072144500000000','0.070572427392542','172.565599062358','172.565599062357990','test'),('2019-04-13 03:59:59','2019-04-13 15:59:59','XEMETH','4h','0.000411210000000','0.000405500000000','0.072144500000000','0.071142712361081','175.44442012596969','175.444420125969685','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','XEMETH','4h','0.000405730000000','0.000409150000000','0.072144500000000','0.072752624097306','177.81406353979247','177.814063539792471','test'),('2019-04-26 11:59:59','2019-04-26 15:59:59','XEMETH','4h','0.000378100000000','0.000372990000000','0.072144500000000','0.071169471184872','190.80798730494578','190.807987304945783','test'),('2019-04-27 03:59:59','2019-04-27 19:59:59','XEMETH','4h','0.000381070000000','0.000370700000000','0.072144500000000','0.070181242685071','189.32085968457238','189.320859684572383','test'),('2019-05-15 23:59:59','2019-05-16 03:59:59','XEMETH','4h','0.000323690000000','0.000359530000000','0.072144500000000','0.080132571549940','222.88146065680127','222.881460656801266','test'),('2019-05-24 03:59:59','2019-05-24 11:59:59','XEMETH','4h','0.000347960000000','0.000339640000000','0.072144500000000','0.070419467697436','207.33561328888376','207.335613288883764','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','XEMETH','4h','0.000339390000000','0.000336770000000','0.072144500000000','0.071587563761454','212.57108341436106','212.571083414361055','test'),('2019-05-27 07:59:59','2019-05-27 11:59:59','XEMETH','4h','0.000338630000000','0.000343670000000','0.072144500000000','0.073218262749904','213.04816466349706','213.048164663497062','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','XEMETH','4h','0.000338430000000','0.000331720000000','0.072144500000000','0.070714102000414','213.1740684927459','213.174068492745903','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','XEMETH','4h','0.000342000000000','0.000336230000000','0.072144500000000','0.070927325248538','210.9488304093567','210.948830409356702','test'),('2019-05-30 07:59:59','2019-05-30 11:59:59','XEMETH','4h','0.000344080000000','0.000344430000000','0.072144500000000','0.072217885767845','209.67362241339222','209.673622413392224','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','XEMETH','4h','0.000348790000000','0.000344840000000','0.072144500000000','0.071327473207374','206.84222598124944','206.842225981249442','test'),('2019-06-17 07:59:59','2019-06-17 11:59:59','XEMETH','4h','0.000336700000000','0.000330670000000','0.072144500000000','0.070852455643006','214.26937926937927','214.269379269379272','test'),('2019-06-28 03:59:59','2019-06-29 23:59:59','XEMETH','4h','0.000309170000000','0.000309090000000','0.072144500000000','0.072125832082673','233.3489665879613','233.348966587961314','test'),('2019-06-30 23:59:59','2019-07-01 03:59:59','XEMETH','4h','0.000310930000000','0.000315720000000','0.072144500000000','0.073255914643167','232.02810922072493','232.028109220724929','test'),('2019-07-04 19:59:59','2019-07-05 07:59:59','XEMETH','4h','0.000311250000000','0.000311000000000','0.072144500000000','0.072086552610442','231.78955823293174','231.789558232931739','test'),('2019-07-06 19:59:59','2019-07-06 23:59:59','XEMETH','4h','0.000310230000000','0.000311110000000','0.072144500000000','0.072349145456597','232.55165522354383','232.551655223543833','test'),('2019-07-15 23:59:59','2019-07-20 03:59:59','XEMETH','4h','0.000316380000000','0.000300340000000','0.072144500000000','0.068486880112523','228.03116505468108','228.031165054681082','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','XEMETH','4h','0.000302140000000','0.000306250000000','0.072144500000000','0.073125879145429','238.77838088303434','238.778380883034345','test'),('2019-07-27 11:59:59','2019-07-28 07:59:59','XEMETH','4h','0.000305900000000','0.000303530000000','0.072144500000000','0.071585551111474','235.84341288002614','235.843412880026136','test'),('2019-07-29 19:59:59','2019-07-29 23:59:59','XEMETH','4h','0.000302980000000','0.000300540000000','0.072144500000000','0.071563496039343','238.1163773186349','238.116377318634903','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','XEMETH','4h','0.000303240000000','0.000304270000000','0.072144500000000','0.072389549581190','237.9122147473948','237.912214747394813','test'),('2019-08-01 03:59:59','2019-08-01 07:59:59','XEMETH','4h','0.000304860000000','0.000302580000000','0.072144500000000','0.071604942629404','236.64796955979793','236.647969559797929','test'),('2019-08-01 19:59:59','2019-08-01 23:59:59','XEMETH','4h','0.000304630000000','0.000299080000000','0.072144500000000','0.070830112136034','236.82664215605817','236.826642156058170','test'),('2019-08-11 03:59:59','2019-08-11 11:59:59','XEMETH','4h','0.000289350000000','0.000285970000000','0.072144500000000','0.071301754501469','249.33298773112148','249.332987731121477','test'),('2019-08-14 19:59:59','2019-08-18 15:59:59','XEMETH','4h','0.000284010000000','0.000284850000000','0.072144500000000','0.072357877627548','254.02098517657828','254.020985176578279','test'),('2019-08-19 15:59:59','2019-08-19 19:59:59','XEMETH','4h','0.000284920000000','0.000284280000000','0.072144500000000','0.071982445809350','253.209672890636','253.209672890636000','test'),('2019-08-21 03:59:59','2019-08-22 15:59:59','XEMETH','4h','0.000289830000000','0.000282870000000','0.072144500000000','0.070412016406169','248.9200565848946','248.920056584894610','test'),('2019-08-22 19:59:59','2019-08-22 23:59:59','XEMETH','4h','0.000286740000000','0.000291180000000','0.072144500000000','0.073261615086838','251.60249703564205','251.602497035642045','test'),('2019-08-30 07:59:59','2019-08-31 19:59:59','XEMETH','4h','0.000293240000000','0.000286280000000','0.072144500000000','0.070432162938208','246.02543991269948','246.025439912699483','test'),('2019-09-02 03:59:59','2019-09-02 11:59:59','XEMETH','4h','0.000294090000000','0.000286530000000','0.072144500000000','0.070289923441804','245.31435954979767','245.314359549797672','test'),('2019-09-04 19:59:59','2019-09-04 23:59:59','XEMETH','4h','0.000289450000000','0.000283930000000','0.072144500000000','0.070768657401969','249.24684746933838','249.246847469338377','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','XEMETH','4h','0.000227150000000','0.000234760000000','0.072144500000000','0.074561491613471','317.60730794629103','317.607307946291030','test'),('2019-10-06 19:59:59','2019-10-06 23:59:59','XEMETH','4h','0.000232780000000','0.000228320000000','0.072144500000000','0.070762231463184','309.925680900421','309.925680900421014','test'),('2019-10-09 03:59:59','2019-10-09 11:59:59','XEMETH','4h','0.000230800000000','0.000226880000000','0.072144500000000','0.070919168804159','312.58448873483536','312.584488734835361','test'),('2019-10-17 07:59:59','2019-10-22 23:59:59','XEMETH','4h','0.000241130000000','0.000225030000000','0.072144500000000','0.067327486563265','299.19338116368766','299.193381163687661','test'),('2019-10-28 03:59:59','2019-10-28 07:59:59','XEMETH','4h','0.000233450000000','0.000230510000000','0.072144500000000','0.071235933583208','309.0361961876205','309.036196187620476','test'),('2019-11-01 19:59:59','2019-11-01 23:59:59','XEMETH','4h','0.000228740000000','0.000228200000000','0.072144500000000','0.071974184226633','315.3995803095217','315.399580309521696','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','XEMETH','4h','0.000234620000000','0.000229340000000','0.072144500000000','0.070520925880147','307.4950984570795','307.495098457079507','test'),('2019-11-15 07:59:59','2019-11-15 11:59:59','XEMETH','4h','0.000221570000000','0.000221990000000','0.072144500000000','0.072281254479397','325.6059033262626','325.605903326262592','test'),('2019-12-03 11:59:59','2019-12-03 15:59:59','XEMETH','4h','0.000239640000000','0.000238370000000','0.072144500000000','0.071762161846937','301.0536638290769','301.053663829076925','test'),('2019-12-04 03:59:59','2019-12-04 07:59:59','XEMETH','4h','0.000238960000000','0.000238680000000','0.072144500000000','0.072059965098761','301.9103615667894','301.910361566789391','test'),('2019-12-09 11:59:59','2019-12-09 15:59:59','XEMETH','4h','0.000242100000000','0.000240620000000','0.072144500000000','0.071703467947129','297.9946303180504','297.994630318050383','test'),('2019-12-11 11:59:59','2019-12-12 23:59:59','XEMETH','4h','0.000244820000000','0.000244090000000','0.072144500000000','0.071929380789968','294.68384935871256','294.683849358712564','test'),('2019-12-22 19:59:59','2019-12-22 23:59:59','XEMETH','4h','0.000252140000000','0.000252130000000','0.072144500000000','0.072141638712620','286.12873800269693','286.128738002696934','test'),('2019-12-23 19:59:59','2019-12-23 23:59:59','XEMETH','4h','0.000251910000000','0.000253930000000','0.072144500000000','0.072723007760708','286.38998054860866','286.389980548608662','test'),('2019-12-24 07:59:59','2019-12-24 11:59:59','XEMETH','4h','0.000252010000000','0.000251760000000','0.072144500000000','0.072072930915440','286.276338240546','286.276338240546011','test'),('2019-12-25 03:59:59','2019-12-26 15:59:59','XEMETH','4h','0.000253260000000','0.000255620000000','0.072144500000000','0.072816777580352','284.8633815051725','284.863381505172526','test'),('2019-12-26 23:59:59','2019-12-27 03:59:59','XEMETH','4h','0.000254270000000','0.000254330000000','0.072144500000000','0.072161523911590','283.73185983403465','283.731859834034651','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:08:00
