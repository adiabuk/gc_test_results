-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 23:59:59','2019-01-14 19:59:59','POEETH','4h','0.000039110000000','0.000040120000000','0.072144500000000','0.074007602659166','1844.6560981846073','1844.656098184607345','test'),('2019-03-02 11:59:59','2019-03-05 19:59:59','POEETH','4h','0.000033990000000','0.000034420000000','0.072610275664792','0.073528852261905','2136.224644448117','2136.224644448117033','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','POEETH','4h','0.000034360000000','0.000033930000000','0.072839919814070','0.071928360864127','2119.904534751739','2119.904534751738993','test'),('2019-03-09 23:59:59','2019-03-11 15:59:59','POEETH','4h','0.000034680000000','0.000035620000000','0.072839919814070','0.074814242900149','2100.343708594867','2100.343708594867167','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','POEETH','4h','0.000036150000000','0.000035890000000','0.073105610848104','0.072579816689860','2022.2852240139352','2022.285224013935249','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','POEETH','4h','0.000036170000000','0.000035810000000','0.073105610848104','0.072377990723544','2021.1670126653028','2021.167012665302764','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','POEETH','4h','0.000036170000000','0.000035950000000','0.073105610848104','0.072660954105318','2021.1670126653028','2021.167012665302764','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','POEETH','4h','0.000035970000000','0.000035870000000','0.073105610848104','0.072902370339769','2032.405083350125','2032.405083350125096','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','POEETH','4h','0.000038890000000','0.000036440000000','0.073105610848104','0.068500088951013','1879.8048559553613','1879.804855955361290','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','POEETH','4h','0.000036760000000','0.000035880000000','0.073105610848104','0.071355530936615','1988.7271721464638','1988.727172146463772','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','POEETH','4h','0.000036750000000','0.000036220000000','0.073105610848104','0.072051298637233','1989.268322397388','1989.268322397387919','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','POEETH','4h','0.000036760000000','0.000036300000000','0.073105610848104','0.072190796348917','1988.7271721464638','1988.727172146463772','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','POEETH','4h','0.000036490000000','0.000035750000000','0.073105610848104','0.071623063519313','2003.4423362045495','2003.442336204549520','test'),('2019-04-19 19:59:59','2019-04-19 23:59:59','POEETH','4h','0.000036300000000','0.000036020000000','0.073105610848104','0.072541710819524','2013.9286735014878','2013.928673501487765','test'),('2019-04-20 19:59:59','2019-04-22 23:59:59','POEETH','4h','0.000036590000000','0.000037140000000','0.073105610848104','0.074204492672823','1997.9669540339985','1997.966954033998491','test'),('2019-05-21 19:59:59','2019-05-22 03:59:59','POEETH','4h','0.000023890000000','0.000022230000000','0.073105610848104','0.068025857227013','3060.092542825618','3060.092542825617784','test'),('2019-05-22 15:59:59','2019-05-24 19:59:59','POEETH','4h','0.000023140000000','0.000024340000000','0.073105610848104','0.076896740191999','3159.274453245636','3159.274453245635868','test'),('2019-06-07 11:59:59','2019-06-07 15:59:59','POEETH','4h','0.000021760000000','0.000022270000000','0.073105610848104','0.074819023602356','3359.632851475368','3359.632851475368170','test'),('2019-06-08 11:59:59','2019-06-09 11:59:59','POEETH','4h','0.000022050000000','0.000021720000000','0.073105610848104','0.072011513270785','3315.4472039956463','3315.447203995646305','test'),('2019-06-09 19:59:59','2019-06-09 23:59:59','POEETH','4h','0.000021670000000','0.000021240000000','0.073105610848104','0.071654968823892','3373.586102819751','3373.586102819750977','test'),('2019-06-10 11:59:59','2019-06-10 15:59:59','POEETH','4h','0.000021860000000','0.000021640000000','0.073105610848104','0.072369872770035','3344.2639912215923','3344.263991221592278','test'),('2019-06-12 07:59:59','2019-06-12 19:59:59','POEETH','4h','0.000022220000000','0.000021850000000','0.073105610848104','0.071888280694468','3290.0814963143116','3290.081496314311607','test'),('2019-06-13 07:59:59','2019-06-13 11:59:59','POEETH','4h','0.000021640000000','0.000021440000000','0.073105610848104','0.072429958252465','3378.262978193346','3378.262978193346044','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','POEETH','4h','0.000021990000000','0.000021920000000','0.073105610848104','0.072872896306978','3324.4934446613915','3324.493444661391550','test'),('2019-06-20 15:59:59','2019-06-20 19:59:59','POEETH','4h','0.000022530000000','0.000021550000000','0.073105610848104','0.069925695240863','3244.811844123569','3244.811844123568790','test'),('2019-06-30 23:59:59','2019-07-01 03:59:59','POEETH','4h','0.000019360000000','0.000018490000000','0.073105610848104','0.069820389699455','3776.1162628152892','3776.116262815289247','test'),('2019-07-14 15:59:59','2019-07-14 23:59:59','POEETH','4h','0.000019090000000','0.000018080000000','0.073105610848104','0.069237791730420','3829.5238788949196','3829.523878894919562','test'),('2019-07-21 03:59:59','2019-07-21 07:59:59','POEETH','4h','0.000017070000000','0.000016780000000','0.073105610848104','0.071863629175816','4282.695421681547','4282.695421681546577','test'),('2019-07-21 11:59:59','2019-07-23 03:59:59','POEETH','4h','0.000016990000000','0.000017500000000','0.073105610848104','0.075300070031891','4302.861144679458','4302.861144679458448','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','POEETH','4h','0.000017140000000','0.000016850000000','0.073105610848104','0.071868701446357','4265.2048336116695','4265.204833611669528','test'),('2019-07-26 07:59:59','2019-07-26 19:59:59','POEETH','4h','0.000017140000000','0.000016980000000','0.073105610848104','0.072423178074726','4265.2048336116695','4265.204833611669528','test'),('2019-08-22 19:59:59','2019-08-29 11:59:59','POEETH','4h','0.000012390000000','0.000014550000000','0.073105610848104','0.085850414676345','5900.372142704116','5900.372142704116413','test'),('2019-08-31 11:59:59','2019-08-31 15:59:59','POEETH','4h','0.000014360000000','0.000013960000000','0.073105610848104','0.071069242857906','5090.919975494708','5090.919975494707614','test'),('2019-08-31 19:59:59','2019-08-31 23:59:59','POEETH','4h','0.000014190000000','0.000014110000000','0.073105610848104','0.072693458003294','5151.910560120085','5151.910560120085393','test'),('2019-09-01 03:59:59','2019-09-01 15:59:59','POEETH','4h','0.000014770000000','0.000014920000000','0.073105610848104','0.073848051039520','4949.601276107245','4949.601276107245212','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','POEETH','4h','0.000014390000000','0.000014320000000','0.073105610848104','0.072749989391581','5080.3065217584435','5080.306521758443523','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','POEETH','4h','0.000014370000000','0.000014000000000','0.073105610848104','0.071223281271639','5087.377233688519','5087.377233688518572','test'),('2019-09-07 03:59:59','2019-09-07 07:59:59','POEETH','4h','0.000014180000000','0.000014170000000','0.073105610848104','0.073054055410270','5155.543783364175','5155.543783364175397','test'),('2019-09-07 15:59:59','2019-09-08 11:59:59','POEETH','4h','0.000015320000000','0.000014350000000','0.073105610848104','0.068476861336181','4771.906713322716','4771.906713322716314','test'),('2019-09-13 11:59:59','2019-09-14 19:59:59','POEETH','4h','0.000016350000000','0.000015580000000','0.073105610848104','0.069662716636909','4471.291183370276','4471.291183370275576','test'),('2019-09-15 07:59:59','2019-09-15 19:59:59','POEETH','4h','0.000015860000000','0.000015390000000','0.073105610848104','0.070939177235329','4609.433218669861','4609.433218669861162','test'),('2019-09-17 15:59:59','2019-09-17 19:59:59','POEETH','4h','0.000015450000000','0.000015340000000','0.073105610848104','0.072585117825884','4731.754747450098','4731.754747450097966','test'),('2019-09-19 11:59:59','2019-09-19 19:59:59','POEETH','4h','0.000015760000000','0.000016000000000','0.073105610848104','0.074218894262035','4638.680891377157','4638.680891377157423','test'),('2019-10-04 19:59:59','2019-10-07 15:59:59','POEETH','4h','0.000014740000000','0.000014700000000','0.073105610848104','0.072907223844446','4959.675091458888','4959.675091458888346','test'),('2019-10-08 11:59:59','2019-10-09 15:59:59','POEETH','4h','0.000015610000000','0.000014610000000','0.073105610848104','0.068422355829007','4683.255019096989','4683.255019096988690','test'),('2019-10-12 11:59:59','2019-10-13 15:59:59','POEETH','4h','0.000014950000000','0.000014530000000','0.073105610848104','0.071051807733977','4890.007414588897','4890.007414588896609','test'),('2019-10-15 07:59:59','2019-10-15 19:59:59','POEETH','4h','0.000014850000000','0.000014800000000','0.073105610848104','0.072859464010232','4922.936757448081','4922.936757448081153','test'),('2019-10-17 03:59:59','2019-10-17 11:59:59','POEETH','4h','0.000014890000000','0.000014690000000','0.073105610848104','0.072123668459278','4909.711944130558','4909.711944130557640','test'),('2019-11-05 15:59:59','2019-11-06 07:59:59','POEETH','4h','0.000013270000000','0.000013040000000','0.073105610848104','0.071838520381257','5509.088986292691','5509.088986292690606','test'),('2019-11-06 23:59:59','2019-11-07 03:59:59','POEETH','4h','0.000013140000000','0.000013340000000','0.073105610848104','0.074218329430267','5563.592910814613','5563.592910814612878','test'),('2019-11-09 11:59:59','2019-11-09 15:59:59','POEETH','4h','0.000013260000000','0.000013200000000','0.073105610848104','0.072774816228882','5513.243653703168','5513.243653703168093','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','POEETH','4h','0.000012980000000','0.000013350000000','0.073105610848104','0.075189515009414','5632.173408944839','5632.173408944839139','test'),('2019-11-22 07:59:59','2019-11-25 19:59:59','POEETH','4h','0.000014760000000','0.000015220000000','0.073105610848104','0.075383969993777','4952.954664505692','4952.954664505691653','test'),('2019-11-29 19:59:59','2019-12-01 03:59:59','POEETH','4h','0.000014640000000','0.000014360000000','0.073105610848104','0.071707416105107','4993.552653559017','4993.552653559017017','test'),('2019-12-02 11:59:59','2019-12-02 15:59:59','POEETH','4h','0.000014440000000','0.000014460000000','0.073105610848104','0.073206865156758','5062.715432694183','5062.715432694182709','test'),('2019-12-03 03:59:59','2019-12-03 11:59:59','POEETH','4h','0.000014450000000','0.000014310000000','0.073105610848104','0.072397321192828','5059.211823398201','5059.211823398200977','test'),('2019-12-04 07:59:59','2019-12-04 11:59:59','POEETH','4h','0.000014370000000','0.000014260000000','0.073105610848104','0.072545999352398','5087.377233688519','5087.377233688518572','test'),('2019-12-06 07:59:59','2019-12-08 15:59:59','POEETH','4h','0.000014560000000','0.000014810000000','0.073105610848104','0.074360858287117','5020.989756051099','5020.989756051098993','test'),('2019-12-19 11:59:59','2019-12-19 19:59:59','POEETH','4h','0.000013740000000','0.000013720000000','0.073105610848104','0.072999198022998','5320.641255320525','5320.641255320524579','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:39:00
