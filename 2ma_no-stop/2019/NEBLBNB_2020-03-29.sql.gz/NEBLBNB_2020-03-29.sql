-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-02 03:59:59','NEBLBNB','4h','0.219530000000000','0.215500000000000','0.711908500000000','0.698839710973443','3.242875688971895','3.242875688971895','test'),('2019-01-07 19:59:59','2019-01-08 07:59:59','NEBLBNB','4h','0.220430000000000','0.217240000000000','0.711908500000000','0.701605963525836','3.229635258358663','3.229635258358663','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','NEBLBNB','4h','0.116110000000000','0.117410000000000','0.711908500000000','0.719879226466282','6.131328050986134','6.131328050986134','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','NEBLBNB','4h','0.119480000000000','0.112450000000000','0.711908500000000','0.670021014604955','5.958390525610981','5.958390525610981','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','NEBLBNB','4h','0.092670000000000','0.090630000000000','0.711908500000000','0.696236833441243','7.6821894895867056','7.682189489586706','test'),('2019-03-15 11:59:59','2019-03-18 11:59:59','NEBLBNB','4h','0.091900000000000','0.095420000000000','0.711908500000000','0.739176377257889','7.746556039173015','7.746556039173015','test'),('2019-03-23 23:59:59','2019-03-24 07:59:59','NEBLBNB','4h','0.097840000000000','0.095870000000000','0.711908500000000','0.697574283473017','7.276252044153721','7.276252044153721','test'),('2019-03-28 15:59:59','2019-03-28 19:59:59','NEBLBNB','4h','0.090360000000000','0.089220000000000','0.711908500000000','0.702926918658699','7.878580123948651','7.878580123948651','test'),('2019-03-28 23:59:59','2019-03-30 23:59:59','NEBLBNB','4h','0.093820000000000','0.090370000000000','0.711908500000000','0.685729813952249','7.588024941377106','7.588024941377106','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','NEBLBNB','4h','0.094510000000000','0.087340000000000','0.711908500000000','0.657899570310020','7.532626177124115','7.532626177124115','test'),('2019-04-06 07:59:59','2019-04-06 11:59:59','NEBLBNB','4h','0.088770000000000','0.087500000000000','0.711908500000000','0.701723484848485','8.01969696969697','8.019696969696970','test'),('2019-04-06 15:59:59','2019-04-06 23:59:59','NEBLBNB','4h','0.090200000000000','0.090810000000000','0.711908500000000','0.716722958813747','7.892555432372506','7.892555432372506','test'),('2019-05-07 15:59:59','2019-05-07 23:59:59','NEBLBNB','4h','0.061050000000000','0.061800000000000','0.711908500000000','0.720654304668305','11.661072891072893','11.661072891072893','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','NEBLBNB','4h','0.062530000000000','0.060360000000000','0.711908500000000','0.687202895570126','11.385071165840397','11.385071165840397','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','NEBLBNB','4h','0.063040000000000','0.061000000000000','0.711908500000000','0.688870851840102','11.29296478426396','11.292964784263960','test'),('2019-05-12 03:59:59','2019-05-12 07:59:59','NEBLBNB','4h','0.061050000000000','0.061000000000000','0.711908500000000','0.711325446355446','11.661072891072893','11.661072891072893','test'),('2019-06-01 07:59:59','2019-06-01 11:59:59','NEBLBNB','4h','0.042280000000000','0.042790000000000','0.711908500000000','0.720495854186377','16.837949385052035','16.837949385052035','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','NEBLBNB','4h','0.042300000000000','0.042630000000000','0.711908500000000','0.717462396099291','16.829988179669034','16.829988179669034','test'),('2019-06-08 19:59:59','2019-06-09 03:59:59','NEBLBNB','4h','0.042000000000000','0.041090000000000','0.711908500000000','0.696483815833333','16.95020238095238','16.950202380952380','test'),('2019-06-16 15:59:59','2019-06-17 03:59:59','NEBLBNB','4h','0.042170000000000','0.040810000000000','0.711908500000000','0.688949155442258','16.881870998340055','16.881870998340055','test'),('2019-06-27 07:59:59','2019-06-27 11:59:59','NEBLBNB','4h','0.034380000000000','0.035160000000000','0.711908500000000','0.728060001745201','20.707053519488074','20.707053519488074','test'),('2019-06-30 11:59:59','2019-07-02 07:59:59','NEBLBNB','4h','0.034000000000000','0.032000000000000','0.711908500000000','0.670031529411765','20.938485294117648','20.938485294117648','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','NEBLBNB','4h','0.032960000000000','0.033010000000000','0.711908500000000','0.712988458282767','21.599165655339807','21.599165655339807','test'),('2019-07-03 15:59:59','2019-07-04 11:59:59','NEBLBNB','4h','0.033800000000000','0.031810000000000','0.711908500000000','0.669994360502959','21.06238165680474','21.062381656804739','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','NEBLBNB','4h','0.033440000000000','0.032510000000000','0.711908500000000','0.692109609300239','21.289129784689','21.289129784688999','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','NEBLBNB','4h','0.033250000000000','0.032660000000000','0.711908500000000','0.699276138646617','21.41078195488722','21.410781954887220','test'),('2019-07-07 15:59:59','2019-07-07 23:59:59','NEBLBNB','4h','0.033900000000000','0.033040000000000','0.711908500000000','0.693848284365782','21.00025073746313','21.000250737463130','test'),('2019-07-09 19:59:59','2019-07-10 19:59:59','NEBLBNB','4h','0.036420000000000','0.033720000000000','0.711908500000000','0.659131098846787','19.547185612300936','19.547185612300936','test'),('2019-07-11 11:59:59','2019-07-11 15:59:59','NEBLBNB','4h','0.033470000000000','0.034630000000000','0.711908500000000','0.736581755452644','21.270047804003585','21.270047804003585','test'),('2019-07-17 11:59:59','2019-07-17 15:59:59','NEBLBNB','4h','0.032660000000000','0.031000000000000','0.711908500000000','0.675724540722596','21.797565829761176','21.797565829761176','test'),('2019-07-28 03:59:59','2019-07-31 11:59:59','NEBLBNB','4h','0.030100000000000','0.029670000000000','0.711908500000000','0.701738378571429','23.651445182724256','23.651445182724256','test'),('2019-08-04 15:59:59','2019-08-04 19:59:59','NEBLBNB','4h','0.029900000000000','0.029990000000000','0.711908500000000','0.714051368394649','23.809648829431442','23.809648829431442','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','NEBLBNB','4h','0.020510000000000','0.020510000000000','0.711908500000000','0.711908500000000','34.710312042905905','34.710312042905905','test'),('2019-08-22 19:59:59','2019-08-23 07:59:59','NEBLBNB','4h','0.020890000000000','0.020890000000000','0.711908500000000','0.711908500000000','34.078913355672576','34.078913355672576','test'),('2019-09-04 11:59:59','2019-09-04 15:59:59','NEBLBNB','4h','0.024030000000000','0.023560000000000','0.711908500000000','0.697984363712027','29.625821889305037','29.625821889305037','test'),('2019-09-04 19:59:59','2019-09-04 23:59:59','NEBLBNB','4h','0.023870000000000','0.023490000000000','0.711908500000000','0.700575226853791','29.824403016338504','29.824403016338504','test'),('2019-09-10 03:59:59','2019-09-10 07:59:59','NEBLBNB','4h','0.023000000000000','0.022590000000000','0.711908500000000','0.699217957173913','30.95254347826087','30.952543478260871','test'),('2019-09-10 11:59:59','2019-09-10 23:59:59','NEBLBNB','4h','0.023400000000000','0.022570000000000','0.711908500000000','0.686657044658120','30.42344017094017','30.423440170940172','test'),('2019-09-11 03:59:59','2019-09-11 07:59:59','NEBLBNB','4h','0.022990000000000','0.023480000000000','0.711908500000000','0.727081843410178','30.96600695954763','30.966006959547631','test'),('2019-09-11 19:59:59','2019-09-12 07:59:59','NEBLBNB','4h','0.023080000000000','0.022760000000000','0.711908500000000','0.702038018197574','30.845255632582326','30.845255632582326','test'),('2019-09-14 03:59:59','2019-09-14 11:59:59','NEBLBNB','4h','0.022750000000000','0.022090000000000','0.711908500000000','0.691255330329670','31.29268131868132','31.292681318681321','test'),('2019-09-14 23:59:59','2019-09-16 07:59:59','NEBLBNB','4h','0.022770000000000','0.022480000000000','0.711908500000000','0.702841593324550','31.26519543258674','31.265195432586740','test'),('2019-09-19 15:59:59','2019-09-19 23:59:59','NEBLBNB','4h','0.022850000000000','0.021940000000000','0.711908500000000','0.683556782932166','31.155733041575495','31.155733041575495','test'),('2019-09-21 15:59:59','2019-09-24 15:59:59','NEBLBNB','4h','0.023020000000000','0.022630000000000','0.711908500000000','0.699847495873154','30.925651607298004','30.925651607298004','test'),('2019-09-24 23:59:59','2019-09-25 19:59:59','NEBLBNB','4h','0.023080000000000','0.022580000000000','0.711908500000000','0.696485872183709','30.845255632582326','30.845255632582326','test'),('2019-09-26 23:59:59','2019-10-09 15:59:59','NEBLBNB','4h','0.023000000000000','0.026740000000000','0.711908500000000','0.827671012608696','30.95254347826087','30.952543478260871','test'),('2019-10-21 19:59:59','2019-10-22 11:59:59','NEBLBNB','4h','0.024740000000000','0.024290000000000','0.711908500000000','0.698959477162490','28.775606305578012','28.775606305578012','test'),('2019-10-23 11:59:59','2019-10-23 19:59:59','NEBLBNB','4h','0.024980000000000','0.025170000000000','0.711908500000000','0.717323336469176','28.499139311449163','28.499139311449163','test'),('2019-10-25 07:59:59','2019-10-25 15:59:59','NEBLBNB','4h','0.025000000000000','0.024930000000000','0.711908500000000','0.709915156200000','28.47634','28.476340000000000','test'),('2019-10-28 15:59:59','2019-10-28 19:59:59','NEBLBNB','4h','0.025900000000000','0.024970000000000','0.711908500000000','0.686345762355212','27.486814671814674','27.486814671814674','test'),('2019-11-02 23:59:59','2019-11-04 03:59:59','NEBLBNB','4h','0.025290000000000','0.024420000000000','0.711908500000000','0.687418172004745','28.1498022933966','28.149802293396601','test'),('2019-11-05 15:59:59','2019-11-06 23:59:59','NEBLBNB','4h','0.025580000000000','0.023760000000000','0.711908500000000','0.661256683346364','27.830668491008606','27.830668491008606','test'),('2019-11-16 11:59:59','2019-11-16 15:59:59','NEBLBNB','4h','0.023220000000000','0.023000000000000','0.711908500000000','0.705163458225668','30.65928079242033','30.659280792420329','test'),('2019-11-16 19:59:59','2019-11-22 07:59:59','NEBLBNB','4h','0.023250000000000','0.024170000000000','0.711908500000000','0.740078642795699','30.61972043010753','30.619720430107531','test'),('2019-11-24 15:59:59','2019-11-24 19:59:59','NEBLBNB','4h','0.024580000000000','0.024500000000000','0.711908500000000','0.709591466639544','28.96291700569569','28.962917005695690','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','NEBLBNB','4h','0.031120000000000','0.030560000000000','0.711908500000000','0.699097807197944','22.876237146529565','22.876237146529565','test'),('2019-12-14 15:59:59','2019-12-14 19:59:59','NEBLBNB','4h','0.031000000000000','0.029840000000000','0.711908500000000','0.685269343225806','22.964790322580647','22.964790322580647','test'),('2019-12-16 03:59:59','2019-12-21 11:59:59','NEBLBNB','4h','0.030840000000000','0.031780000000000','0.711908500000000','0.733607397211414','23.08393320363165','23.083933203631648','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:03:33
