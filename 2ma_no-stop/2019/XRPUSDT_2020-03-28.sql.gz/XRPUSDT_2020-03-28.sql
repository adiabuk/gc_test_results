-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-02 07:59:59','XRPUSDT','4h','0.360800000000000','0.356850000000000','15.000000000000000','14.835781596452328','41.574279379157424','41.574279379157424','test'),('2019-01-06 19:59:59','2019-01-08 03:59:59','XRPUSDT','4h','0.361950000000000','0.356740000000000','15.000000000000000','14.784086199751346','41.44218814753419','41.442188147534189','test'),('2019-01-30 15:59:59','2019-01-31 11:59:59','XRPUSDT','4h','0.318430000000000','0.306010000000000','15.000000000000000','14.414942059479321','47.1061143736457','47.106114373645703','test'),('2019-02-02 23:59:59','2019-02-03 03:59:59','XRPUSDT','4h','0.310300000000000','0.308090000000000','15.000000000000000','14.893167902030291','48.34031582339671','48.340315823396708','test'),('2019-02-08 15:59:59','2019-02-10 07:59:59','XRPUSDT','4h','0.307260000000000','0.301860000000000','15.000000000000000','14.736379613356767','48.81859011911736','48.818590119117360','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','XRPUSDT','4h','0.303830000000000','0.309880000000000','15.000000000000000','15.298686765625515','49.36971332653128','49.369713326531283','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','XRPUSDT','4h','0.304290000000000','0.302550000000000','15.000000000000000','14.914226560189292','49.295080350980975','49.295080350980975','test'),('2019-02-12 23:59:59','2019-02-13 11:59:59','XRPUSDT','4h','0.305140000000000','0.302320000000000','15.000000000000000','14.861375106508486','49.15776364947237','49.157763649472372','test'),('2019-02-13 23:59:59','2019-02-14 03:59:59','XRPUSDT','4h','0.303820000000000','0.302890000000000','15.000000000000000','14.954084655388060','49.37133829240998','49.371338292409980','test'),('2019-02-18 03:59:59','2019-02-22 07:59:59','XRPUSDT','4h','0.313910000000000','0.317190000000000','15.000000000000000','15.156732821509351','47.78439680163104','47.784396801631040','test'),('2019-02-25 19:59:59','2019-02-26 07:59:59','XRPUSDT','4h','0.332460000000000','0.318220000000000','15.000000000000000','14.357516693737594','45.11820970943873','45.118209709438730','test'),('2019-03-01 07:59:59','2019-03-01 23:59:59','XRPUSDT','4h','0.321830000000000','0.315640000000000','15.000000000000000','14.711493645713574','46.608457881490224','46.608457881490224','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','XRPUSDT','4h','0.315500000000000','0.314710000000000','15.000000000000000','14.962440570522979','47.543581616481774','47.543581616481774','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','XRPUSDT','4h','0.313200000000000','0.314380000000000','15.000000000000000','15.056513409961685','47.89272030651341','47.892720306513411','test'),('2019-03-09 07:59:59','2019-03-09 11:59:59','XRPUSDT','4h','0.315830000000000','0.312920000000000','15.000000000000000','14.861792736598801','47.493904948864895','47.493904948864895','test'),('2019-03-10 19:59:59','2019-03-10 23:59:59','XRPUSDT','4h','0.313380000000000','0.312890000000000','15.000000000000000','14.976546046333524','47.86521156423512','47.865211564235118','test'),('2019-03-13 15:59:59','2019-03-14 07:59:59','XRPUSDT','4h','0.315770000000000','0.310840000000000','15.000000000000000','14.765810558317764','47.50292934730975','47.502929347309752','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','XRPUSDT','4h','0.312740000000000','0.311330000000000','15.000000000000000','14.932371938351345','47.963164289825414','47.963164289825414','test'),('2019-03-15 11:59:59','2019-03-18 11:59:59','XRPUSDT','4h','0.314610000000000','0.313350000000000','15.000000000000000','14.939925622198913','47.67807761991037','47.678077619910368','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','XRPUSDT','4h','0.314520000000000','0.313940000000000','15.000000000000000','14.972338801983975','47.691720717283474','47.691720717283474','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','XRPUSDT','4h','0.315210000000000','0.313070000000000','15.000000000000000','14.898163129342343','47.587322737222806','47.587322737222806','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','XRPUSDT','4h','0.318250000000000','0.308860000000000','15.000000000000000','14.557423409269445','47.13275726630008','47.132757266300082','test'),('2019-03-27 23:59:59','2019-03-28 03:59:59','XRPUSDT','4h','0.310120000000000','0.307600000000000','15.000000000000000','14.878111698697277','48.368373532826','48.368373532825998','test'),('2019-03-30 03:59:59','2019-03-31 03:59:59','XRPUSDT','4h','0.315320000000000','0.308920000000000','15.000000000000000','14.695547380438919','47.57072180641888','47.570721806418881','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','XRPUSDT','4h','0.310230000000000','0.309240000000000','15.000000000000000','14.952132288946910','48.35122328594913','48.351223285949132','test'),('2019-04-17 19:59:59','2019-04-19 03:59:59','XRPUSDT','4h','0.333810000000000','0.329330000000000','15.000000000000000','14.798687876336839','44.93574188909859','44.935741889098587','test'),('2019-04-30 23:59:59','2019-05-01 03:59:59','XRPUSDT','4h','0.308700000000000','0.306080000000000','15.000000000000000','14.872691933916427','48.590864917395535','48.590864917395535','test'),('2019-05-03 15:59:59','2019-05-03 19:59:59','XRPUSDT','4h','0.306600000000000','0.307300000000000','15.000000000000000','15.034246575342467','48.923679060665364','48.923679060665364','test'),('2019-05-07 03:59:59','2019-05-07 07:59:59','XRPUSDT','4h','0.306740000000000','0.304920000000000','15.000000000000000','14.910999543587403','48.90134967725109','48.901349677251090','test'),('2019-05-11 11:59:59','2019-05-12 15:59:59','XRPUSDT','4h','0.310740000000000','0.306460000000000','15.000000000000000','14.793396408573082','48.27186715582158','48.271867155821582','test'),('2019-05-23 23:59:59','2019-05-24 03:59:59','XRPUSDT','4h','0.379560000000000','0.376680000000000','15.000000000000000','14.886184002529244','39.519443566234585','39.519443566234585','test'),('2019-06-06 23:59:59','2019-06-07 03:59:59','XRPUSDT','4h','0.419370000000000','0.418300000000000','15.000000000000000','14.961728306745833','35.767937620716786','35.767937620716786','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','XRPUSDT','4h','0.405000000000000','0.404170000000000','15.000000000000000','14.969259259259257','37.03703703703704','37.037037037037038','test'),('2019-07-09 03:59:59','2019-07-09 07:59:59','XRPUSDT','4h','0.406370000000000','0.397540000000000','15.000000000000000','14.674065506804144','36.91217363486478','36.912173634864779','test'),('2019-07-20 19:59:59','2019-07-20 23:59:59','XRPUSDT','4h','0.335480000000000','0.332790000000000','15.000000000000000','14.879724573745079','44.712054369858116','44.712054369858116','test'),('2019-07-30 19:59:59','2019-07-30 23:59:59','XRPUSDT','4h','0.318840000000000','0.318230000000000','15.000000000000000','14.971302220549491','47.04554008280015','47.045540082800152','test'),('2019-07-31 23:59:59','2019-08-01 03:59:59','XRPUSDT','4h','0.319590000000000','0.315720000000000','15.000000000000000','14.818361025063362','46.93513564254201','46.935135642542008','test'),('2019-08-04 15:59:59','2019-08-06 03:59:59','XRPUSDT','4h','0.318170000000000','0.319530000000000','15.000000000000000','15.064116667190495','47.14460822830562','47.144608228305621','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','XRPUSDT','4h','0.287190000000000','0.287710000000000','15.000000000000000','15.027159720045963','52.23023085762039','52.230230857620391','test'),('2019-09-07 19:59:59','2019-09-08 11:59:59','XRPUSDT','4h','0.261060000000000','0.259380000000000','15.000000000000000','14.903470466559410','57.45805561939784','57.458055619397840','test'),('2019-09-09 11:59:59','2019-09-09 19:59:59','XRPUSDT','4h','0.261810000000000','0.258740000000000','15.000000000000000','14.824109086742297','57.29345708720064','57.293457087200643','test'),('2019-09-10 03:59:59','2019-09-10 11:59:59','XRPUSDT','4h','0.261140000000000','0.260790000000000','15.000000000000000','14.979895841311176','57.44045339664548','57.440453396645481','test'),('2019-09-14 15:59:59','2019-09-15 15:59:59','XRPUSDT','4h','0.263360000000000','0.260640000000000','15.000000000000000','14.845078979343864','56.95625759416768','56.956257594167681','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','XRPUSDT','4h','0.279220000000000','0.267860000000000','15.000000000000000','14.389728529474965','53.72108015185158','53.721080151851581','test'),('2019-09-30 15:59:59','2019-09-30 23:59:59','XRPUSDT','4h','0.257270000000000','0.256600000000000','15.000000000000000','14.960935981653515','58.3045049947526','58.304504994752598','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','XRPUSDT','4h','0.253030000000000','0.253340000000000','15.000000000000000','15.018377267517687','59.28150812156662','59.281508121566617','test'),('2019-10-05 15:59:59','2019-10-05 23:59:59','XRPUSDT','4h','0.255220000000000','0.253250000000000','15.000000000000000','14.884217537810514','58.772823446438366','58.772823446438366','test'),('2019-10-25 15:59:59','2019-10-26 19:59:59','XRPUSDT','4h','0.290990000000000','0.292230000000000','15.000000000000000','15.063919722327228','51.54816316711914','51.548163167119142','test'),('2019-11-02 03:59:59','2019-11-02 07:59:59','XRPUSDT','4h','0.293490000000000','0.293290000000000','15.000000000000000','14.989778186650312','51.10906674844118','51.109066748441180','test'),('2019-11-04 11:59:59','2019-11-07 11:59:59','XRPUSDT','4h','0.294210000000000','0.287900000000000','15.000000000000000','14.678291016620779','50.98399102681758','50.983991026817577','test'),('2019-12-06 23:59:59','2019-12-07 11:59:59','XRPUSDT','4h','0.225460000000000','0.224340000000000','15.000000000000000','14.925485673733702','66.53064845205358','66.530648452053583','test'),('2019-12-29 15:59:59','2019-12-30 11:59:59','XRPUSDT','4h','0.195010000000000','0.193970000000000','15.000000000000000','14.920004102353728','76.91913235218708','76.919132352187077','test'),('2020-01-01 07:59:59','2020-01-01 11:59:59','XRPUSDT','4h','0.194380000000000','0.193580000000000','15.000000000000000','14.938265253626916','77.16843296635456','77.168432966354558','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:50:45
