-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 15:59:59','2019-01-10 19:59:59','EOSETH','4h','0.018773000000000','0.018863000000000','0.072144500000000','0.072490369333617','3.842992595749214','3.842992595749214','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','EOSETH','4h','0.019130000000000','0.018778000000000','0.072230967333404','0.070901887328106','3.775795469597713','3.775795469597713','test'),('2019-01-15 19:59:59','2019-01-20 11:59:59','EOSETH','4h','0.019077000000000','0.019506000000000','0.072230967333404','0.073855283787041','3.786285439712953','3.786285439712953','test'),('2019-02-15 03:59:59','2019-02-15 15:59:59','EOSETH','4h','0.022883000000000','0.022767000000000','0.072304776445489','0.071938244344467','3.15975949156531','3.159759491565310','test'),('2019-02-18 19:59:59','2019-02-25 11:59:59','EOSETH','4h','0.023667000000000','0.024841000000000','0.072304776445489','0.075891450191507','3.055088369691511','3.055088369691511','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','EOSETH','4h','0.025726000000000','0.025764000000000','0.073109811856738','0.073217802716201','2.8418647227216822','2.841864722721682','test'),('2019-03-05 11:59:59','2019-03-11 07:59:59','EOSETH','4h','0.026105000000000','0.026933000000000','0.073136809571604','0.075456567408236','2.801639899314451','2.801639899314451','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','EOSETH','4h','0.026974000000000','0.026938000000000','0.073716749030762','0.073618365292158','2.732881627892109','2.732881627892109','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','EOSETH','4h','0.026951000000000','0.026976000000000','0.073716749030762','0.073785129377531','2.7352138707566325','2.735213870756632','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','EOSETH','4h','0.026967000000000','0.026856000000000','0.073716749030762','0.073413320427565','2.7335910197931543','2.733591019793154','test'),('2019-03-19 11:59:59','2019-03-19 15:59:59','EOSETH','4h','0.026934000000000','0.026864000000000','0.073716749030762','0.073525163212385','2.7369402625217942','2.736940262521794','test'),('2019-03-25 03:59:59','2019-03-25 07:59:59','EOSETH','4h','0.026886000000000','0.026739000000000','0.073716749030762','0.073313700525684','2.741826565155174','2.741826565155174','test'),('2019-03-25 19:59:59','2019-03-30 19:59:59','EOSETH','4h','0.027283000000000','0.029271000000000','0.073716749030762','0.079088185349098','2.7019297375934466','2.701929737593447','test'),('2019-04-09 11:59:59','2019-04-18 03:59:59','EOSETH','4h','0.031281000000000','0.032035000000000','0.074827591530724','0.076631242437478','2.392109955906908','2.392109955906908','test'),('2019-05-03 19:59:59','2019-05-04 07:59:59','EOSETH','4h','0.030137000000000','0.029837000000000','0.075278504257413','0.074529141305652','2.4978765058702757','2.497876505870276','test'),('2019-05-04 23:59:59','2019-05-05 07:59:59','EOSETH','4h','0.030252000000000','0.030131000000000','0.075278504257413','0.074977410147432','2.4883810742236214','2.488381074223621','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','EOSETH','4h','0.025757000000000','0.025781000000000','0.075278504257413','0.075348647678703','2.9226425537684126','2.922642553768413','test'),('2019-05-26 23:59:59','2019-06-02 19:59:59','EOSETH','4h','0.025934000000000','0.028200000000000','0.075278504257413','0.081856012187054','2.9026954676260126','2.902695467626013','test'),('2019-06-16 15:59:59','2019-06-16 19:59:59','EOSETH','4h','0.026052000000000','0.025901000000000','0.076677802829710','0.076233370608488','2.943259743194755','2.943259743194755','test'),('2019-07-15 07:59:59','2019-07-15 11:59:59','EOSETH','4h','0.018830000000000','0.018889000000000','0.076677802829710','0.076918057230504','4.072108488035582','4.072108488035582','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','EOSETH','4h','0.018802000000000','0.018717000000000','0.076677802829710','0.076331158151456','4.078172685337198','4.078172685337198','test'),('2019-07-16 07:59:59','2019-07-16 11:59:59','EOSETH','4h','0.018817000000000','0.018866000000000','0.076677802829710','0.076877473996137','4.074921763815167','4.074921763815167','test'),('2019-07-20 11:59:59','2019-07-20 15:59:59','EOSETH','4h','0.018618000000000','0.018577000000000','0.076677802829710','0.076508945277018','4.118476894924804','4.118476894924804','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','EOSETH','4h','0.020166000000000','0.020057000000000','0.076677802829710','0.076263348772959','3.8023307958796986','3.802330795879699','test'),('2019-07-30 23:59:59','2019-07-31 03:59:59','EOSETH','4h','0.020031000000000','0.019931000000000','0.076677802829710','0.076295007148867','3.82795680843243','3.827956808432430','test'),('2019-07-31 15:59:59','2019-07-31 19:59:59','EOSETH','4h','0.020002000000000','0.020040000000000','0.076677802829710','0.076823476087761','3.8335067908064193','3.833506790806419','test'),('2019-08-10 19:59:59','2019-08-11 07:59:59','EOSETH','4h','0.019753000000000','0.019699000000000','0.076677802829710','0.076468183969142','3.8818307512636054','3.881830751263605','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','EOSETH','4h','0.019593000000000','0.019270000000000','0.076677802829710','0.075413732482443','3.9135304868937886','3.913530486893789','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','EOSETH','4h','0.019442000000000','0.019369000000000','0.076677802829710','0.076389896255974','3.943925667611871','3.943925667611871','test'),('2019-08-17 19:59:59','2019-08-17 23:59:59','EOSETH','4h','0.019383000000000','0.019184000000000','0.076677802829710','0.075890572640208','3.9559306005112727','3.955930600511273','test'),('2019-08-22 19:59:59','2019-08-22 23:59:59','EOSETH','4h','0.019086000000000','0.019087000000000','0.076677802829710','0.076681820319117','4.017489407403857','4.017489407403857','test'),('2019-08-24 11:59:59','2019-08-24 19:59:59','EOSETH','4h','0.019118000000000','0.019267000000000','0.076677802829710','0.077275406795691','4.010764872356418','4.010764872356418','test'),('2019-08-26 19:59:59','2019-08-26 23:59:59','EOSETH','4h','0.019105000000000','0.019006000000000','0.076677802829710','0.076280466923919','4.0134939978911275','4.013493997891127','test'),('2019-08-30 03:59:59','2019-08-30 19:59:59','EOSETH','4h','0.019122000000000','0.019078000000000','0.076677802829710','0.076501366090639','4.009925887967262','4.009925887967262','test'),('2019-08-31 11:59:59','2019-08-31 15:59:59','EOSETH','4h','0.019225000000000','0.019113000000000','0.076677802829710','0.076231097294369','3.9884422798288686','3.988442279828869','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','EOSETH','4h','0.019002000000000','0.019003000000000','0.076677802829710','0.076681838078780','4.035249070082623','4.035249070082623','test'),('2019-09-07 15:59:59','2019-09-16 23:59:59','EOSETH','4h','0.019671000000000','0.020706000000000','0.076677802829710','0.080712245711554','3.8980124462259162','3.898012446225916','test'),('2019-10-04 19:59:59','2019-10-04 23:59:59','EOSETH','4h','0.017227000000000','0.017116000000000','0.076677802829710','0.076183739085930','4.4510247187386085','4.451024718738608','test'),('2019-10-06 15:59:59','2019-10-06 19:59:59','EOSETH','4h','0.017142000000000','0.017201000000000','0.076677802829710','0.076941715463414','4.473095486507408','4.473095486507408','test'),('2019-10-12 19:59:59','2019-10-13 03:59:59','EOSETH','4h','0.017073000000000','0.017051000000000','0.076677802829710','0.076578997015720','4.491173363188074','4.491173363188074','test'),('2019-10-13 23:59:59','2019-10-14 19:59:59','EOSETH','4h','0.017127000000000','0.017010000000000','0.076677802829710','0.076153992300658','4.477013068821743','4.477013068821743','test'),('2019-10-21 15:59:59','2019-10-21 19:59:59','EOSETH','4h','0.016822000000000','0.016772000000000','0.076677802829710','0.076449893535840','4.558185877405184','4.558185877405184','test'),('2019-10-24 15:59:59','2019-11-03 19:59:59','EOSETH','4h','0.017009000000000','0.017893000000000','0.076677802829710','0.080662938798989','4.508072363437591','4.508072363437591','test'),('2019-11-15 07:59:59','2019-11-15 15:59:59','EOSETH','4h','0.018734000000000','0.018473000000000','0.077378720152916','0.076300688447999','4.1303896740107024','4.130389674010702','test'),('2019-11-18 11:59:59','2019-11-18 15:59:59','EOSETH','4h','0.018542000000000','0.018540000000000','0.077378720152916','0.077370373834272','4.1731593222368675','4.173159322236867','test'),('2019-11-26 15:59:59','2019-11-26 23:59:59','EOSETH','4h','0.017888000000000','0.017688000000000','0.077378720152916','0.076513573460688','4.325733461142441','4.325733461142441','test'),('2019-11-29 11:59:59','2019-12-04 03:59:59','EOSETH','4h','0.017894000000000','0.017966000000000','0.077378720152916','0.077690068529523','4.324283008433889','4.324283008433889','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','EOSETH','4h','0.018233000000000','0.018137000000000','0.077378720152916','0.076971307377471','4.243883077547085','4.243883077547085','test'),('2019-12-16 03:59:59','2019-12-16 07:59:59','EOSETH','4h','0.018097000000000','0.017931000000000','0.077378720152916','0.076668941319663','4.275776103935238','4.275776103935238','test'),('2019-12-18 03:59:59','2019-12-18 07:59:59','EOSETH','4h','0.018053000000000','0.018126000000000','0.077378720152916','0.077691612557013','4.286197316397053','4.286197316397053','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 21:55:10
