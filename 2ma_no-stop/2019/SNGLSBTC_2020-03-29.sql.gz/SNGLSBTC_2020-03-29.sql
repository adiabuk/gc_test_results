-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-02 03:59:59','SNGLSBTC','4h','0.000002690000000','0.000002720000000','0.001467500000000','0.001483866171004','545.539033457249','545.539033457249047','test'),('2019-01-05 15:59:59','2019-01-07 07:59:59','SNGLSBTC','4h','0.000002870000000','0.000002710000000','0.001471591542751','0.001389551596117','512.749666463763','512.749666463762992','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','SNGLSBTC','4h','0.000002710000000','0.000002720000000','0.001471591542751','0.001477021769846','543.0227095022141','543.022709502214070','test'),('2019-01-09 03:59:59','2019-01-09 07:59:59','SNGLSBTC','4h','0.000002720000000','0.000002720000000','0.001471591542751','0.001471591542751','541.0263024819853','541.026302481985340','test'),('2019-01-12 23:59:59','2019-01-13 03:59:59','SNGLSBTC','4h','0.000002730000000','0.000002700000000','0.001471591542751','0.001455420207116','539.0445211542124','539.044521154212362','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','SNGLSBTC','4h','0.000002750000000','0.000002700000000','0.001471591542751','0.001444835332883','535.124197364','535.124197363999997','test'),('2019-01-14 23:59:59','2019-01-31 11:59:59','SNGLSBTC','4h','0.000002710000000','0.000003550000000','0.001471591542751','0.001927730618733','543.0227095022141','543.022709502214070','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','SNGLSBTC','4h','0.000003400000000','0.000003270000000','0.001555741995486','0.001496257742717','457.5711751429412','457.571175142941172','test'),('2019-02-20 19:59:59','2019-02-21 07:59:59','SNGLSBTC','4h','0.000003220000000','0.000003190000000','0.001555741995486','0.001541247504845','483.14968803913047','483.149688039130467','test'),('2019-02-21 23:59:59','2019-02-23 19:59:59','SNGLSBTC','4h','0.000003600000000','0.000003400000000','0.001555741995486','0.001469311884626','432.1505543016667','432.150554301666716','test'),('2019-02-25 15:59:59','2019-02-25 23:59:59','SNGLSBTC','4h','0.000003400000000','0.000003310000000','0.001555741995486','0.001514560589723','457.5711751429412','457.571175142941172','test'),('2019-02-28 19:59:59','2019-03-02 11:59:59','SNGLSBTC','4h','0.000003390000000','0.000003340000000','0.001555741995486','0.001532795948355','458.92094262123896','458.920942621238964','test'),('2019-03-15 11:59:59','2019-03-15 15:59:59','SNGLSBTC','4h','0.000004160000000','0.000004130000000','0.001555741995486','0.001544522702249','373.9764412225962','373.976441222596179','test'),('2019-03-15 19:59:59','2019-03-16 03:59:59','SNGLSBTC','4h','0.000004190000000','0.000004150000000','0.001555741995486','0.001540890043262','371.29880560525066','371.298805605250664','test'),('2019-03-17 07:59:59','2019-03-17 11:59:59','SNGLSBTC','4h','0.000004160000000','0.000004120000000','0.001555741995486','0.001540782937837','373.9764412225962','373.976441222596179','test'),('2019-03-17 15:59:59','2019-03-17 19:59:59','SNGLSBTC','4h','0.000004160000000','0.000004160000000','0.001555741995486','0.001555741995486','373.9764412225962','373.976441222596179','test'),('2019-03-18 03:59:59','2019-03-18 07:59:59','SNGLSBTC','4h','0.000004140000000','0.000004060000000','0.001555741995486','0.001525679348230','375.78309069710144','375.783090697101443','test'),('2019-03-20 23:59:59','2019-03-21 07:59:59','SNGLSBTC','4h','0.000004110000000','0.000004120000000','0.001555741995486','0.001559527255816','378.5260329649636','378.526032964963576','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','SNGLSBTC','4h','0.000004100000000','0.000004090000000','0.001555741995486','0.001551947502814','379.44926719170735','379.449267191707349','test'),('2019-03-23 15:59:59','2019-03-23 19:59:59','SNGLSBTC','4h','0.000004100000000','0.000004090000000','0.001555741995486','0.001551947502814','379.44926719170735','379.449267191707349','test'),('2019-03-23 23:59:59','2019-03-24 11:59:59','SNGLSBTC','4h','0.000004110000000','0.000004180000000','0.001555741995486','0.001582238817794','378.5260329649636','378.526032964963576','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','SNGLSBTC','4h','0.000004150000000','0.000004110000000','0.001555741995486','0.001540746891915','374.87758927373494','374.877589273734941','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','SNGLSBTC','4h','0.000003600000000','0.000003500000000','0.001555741995486','0.001512526940056','432.1505543016667','432.150554301666716','test'),('2019-04-19 07:59:59','2019-04-21 11:59:59','SNGLSBTC','4h','0.000003560000000','0.000003520000000','0.001555741995486','0.001538261748346','437.00617850730345','437.006178507303446','test'),('2019-05-21 23:59:59','2019-05-22 03:59:59','SNGLSBTC','4h','0.000002040000000','0.000002020000000','0.001555741995486','0.001540489622981','762.6186252382354','762.618625238235381','test'),('2019-05-22 07:59:59','2019-05-24 15:59:59','SNGLSBTC','4h','0.000002270000000','0.000002120000000','0.001555741995486','0.001452939660983','685.348896689868','685.348896689867956','test'),('2019-05-26 07:59:59','2019-05-26 19:59:59','SNGLSBTC','4h','0.000002200000000','0.000002020000000','0.001555741995486','0.001428454014037','707.1554524936364','707.155452493636403','test'),('2019-05-28 15:59:59','2019-05-28 19:59:59','SNGLSBTC','4h','0.000002120000000','0.000002060000000','0.001555741995486','0.001511711561651','733.8405639084906','733.840563908490594','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','SNGLSBTC','4h','0.000002120000000','0.000002140000000','0.001555741995486','0.001570418806764','733.8405639084906','733.840563908490594','test'),('2019-05-31 11:59:59','2019-05-31 15:59:59','SNGLSBTC','4h','0.000002120000000','0.000002120000000','0.001555741995486','0.001555741995486','733.8405639084906','733.840563908490594','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','SNGLSBTC','4h','0.000002110000000','0.000002140000000','0.001555741995486','0.001577861549924','737.3184812729858','737.318481272985764','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','SNGLSBTC','4h','0.000002130000000','0.000002110000000','0.001555741995486','0.001541134089425','730.3953030450705','730.395303045070477','test'),('2019-06-05 11:59:59','2019-06-06 19:59:59','SNGLSBTC','4h','0.000002180000000','0.000002150000000','0.001555741995486','0.001534332701970','713.643117195413','713.643117195412970','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','SNGLSBTC','4h','0.000002360000000','0.000002100000000','0.001555741995486','0.001384346690899','659.212709951695','659.212709951695047','test'),('2019-07-22 11:59:59','2019-07-22 15:59:59','SNGLSBTC','4h','0.000001020000000','0.000000990000000','0.001555741995486','0.001509984877972','1525.2372504764708','1525.237250476470763','test'),('2019-07-23 11:59:59','2019-07-23 15:59:59','SNGLSBTC','4h','0.000000990000000','0.000000960000000','0.001555741995486','0.001508598298653','1571.4565610969696','1571.456561096969608','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','SNGLSBTC','4h','0.000000980000000','0.000000970000000','0.001555741995486','0.001539867077165','1587.4918321285716','1587.491832128571559','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','SNGLSBTC','4h','0.000000980000000','0.000000980000000','0.001555741995486','0.001555741995486','1587.4918321285716','1587.491832128571559','test'),('2019-08-19 15:59:59','2019-08-19 19:59:59','SNGLSBTC','4h','0.000000780000000','0.000000700000000','0.001555741995486','0.001396178713898','1994.5410198538461','1994.541019853846137','test'),('2019-08-21 19:59:59','2019-08-22 11:59:59','SNGLSBTC','4h','0.000000740000000','0.000000770000000','0.001555741995486','0.001618812616925','2102.3540479540543','2102.354047954054295','test'),('2019-08-31 07:59:59','2019-08-31 11:59:59','SNGLSBTC','4h','0.000000760000000','0.000000750000000','0.001555741995486','0.001535271706072','2047.0289414289473','2047.028941428947292','test'),('2019-09-01 11:59:59','2019-09-01 15:59:59','SNGLSBTC','4h','0.000000760000000','0.000000760000000','0.001555741995486','0.001555741995486','2047.0289414289473','2047.028941428947292','test'),('2019-09-09 19:59:59','2019-09-12 03:59:59','SNGLSBTC','4h','0.000000750000000','0.000000680000000','0.001555741995486','0.001410539409241','2074.3226606480002','2074.322660648000237','test'),('2019-09-13 19:59:59','2019-09-13 23:59:59','SNGLSBTC','4h','0.000000680000000','0.000000670000000','0.001555741995486','0.001532863436729','2287.855875714706','2287.855875714706144','test'),('2019-09-15 07:59:59','2019-09-15 11:59:59','SNGLSBTC','4h','0.000000680000000','0.000000700000000','0.001555741995486','0.001601499113000','2287.855875714706','2287.855875714706144','test'),('2019-10-19 15:59:59','2019-10-19 19:59:59','SNGLSBTC','4h','0.000001290000000','0.000001260000000','0.001555741995486','0.001519561949079','1206.0015468883723','1206.001546888372332','test'),('2019-10-19 23:59:59','2019-10-20 03:59:59','SNGLSBTC','4h','0.000001290000000','0.000001240000000','0.001555741995486','0.001495441918142','1206.0015468883723','1206.001546888372332','test'),('2019-11-10 11:59:59','2019-11-15 15:59:59','SNGLSBTC','4h','0.000001080000000','0.000001070000000','0.001555741995486','0.001541336977009','1440.5018476722223','1440.501847672222311','test'),('2019-11-16 23:59:59','2019-11-17 03:59:59','SNGLSBTC','4h','0.000001100000000','0.000001090000000','0.001555741995486','0.001541598886436','1414.3109049872728','1414.310904987272806','test'),('2019-11-19 23:59:59','2019-11-20 03:59:59','SNGLSBTC','4h','0.000001120000000','0.000001110000000','0.001555741995486','0.001541851441955','1389.0553531125','1389.055353112499915','test'),('2019-11-23 07:59:59','2019-11-24 11:59:59','SNGLSBTC','4h','0.000001110000000','0.000001100000000','0.001555741995486','0.001541726301833','1401.5693653027029','1401.569365302702863','test'),('2019-11-25 07:59:59','2019-11-27 15:59:59','SNGLSBTC','4h','0.000001130000000','0.000001170000000','0.001555741995486','0.001610812508601','1376.762827863717','1376.762827863716893','test'),('2019-12-09 07:59:59','2019-12-09 11:59:59','SNGLSBTC','4h','0.000001230000000','0.000001190000000','0.001555741995486','0.001505148759860','1264.8308906390243','1264.830890639024346','test'),('2019-12-16 03:59:59','2019-12-16 07:59:59','SNGLSBTC','4h','0.000001140000000','0.000001100000000','0.001555741995486','0.001501154557048','1364.6859609526316','1364.685960952631604','test'),('2019-12-27 15:59:59','2019-12-27 19:59:59','SNGLSBTC','4h','0.000001000000000','0.000001000000000','0.001555741995486','0.001555741995486','1555.7419954860002','1555.741995486000178','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:58:26
