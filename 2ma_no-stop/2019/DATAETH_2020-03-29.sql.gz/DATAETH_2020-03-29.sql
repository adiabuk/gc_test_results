-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 23:59:59','2019-01-07 03:59:59','DATAETH','4h','0.000140040000000','0.000131840000000','0.072144500000000','0.067920100542702','515.170665524136','515.170665524135984','test'),('2019-01-08 03:59:59','2019-01-08 07:59:59','DATAETH','4h','0.000130950000000','0.000128250000000','0.072144500000000','0.070656984536082','550.9316533027873','550.931653302787254','test'),('2019-01-08 23:59:59','2019-01-09 03:59:59','DATAETH','4h','0.000130440000000','0.000129720000000','0.072144500000000','0.071746278288868','553.0857099049371','553.085709904937062','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','DATAETH','4h','0.000130800000000','0.000129020000000','0.072144500000000','0.071162717048930','551.5634556574923','551.563455657492341','test'),('2019-01-10 07:59:59','2019-01-10 19:59:59','DATAETH','4h','0.000134090000000','0.000131380000000','0.072144500000000','0.070686437541949','538.030427324931','538.030427324930997','test'),('2019-01-31 23:59:59','2019-02-01 03:59:59','DATAETH','4h','0.000162510000000','0.000162320000000','0.072144500000000','0.072060151621439','443.9388345332595','443.938834533259524','test'),('2019-02-08 03:59:59','2019-02-08 07:59:59','DATAETH','4h','0.000162370000000','0.000161140000000','0.072144500000000','0.071597984418304','444.32161113506186','444.321611135061858','test'),('2019-02-26 11:59:59','2019-02-27 07:59:59','DATAETH','4h','0.000132770000000','0.000129200000000','0.072144500000000','0.070204635083227','543.3795285079461','543.379528507946134','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','DATAETH','4h','0.000131900000000','0.000132060000000','0.072144500000000','0.072232014177407','546.9636087945413','546.963608794541301','test'),('2019-03-01 03:59:59','2019-03-02 11:59:59','DATAETH','4h','0.000132190000000','0.000133340000000','0.072144500000000','0.072772128224525','545.7636735002648','545.763673500264758','test'),('2019-03-06 19:59:59','2019-03-06 23:59:59','DATAETH','4h','0.000136820000000','0.000134370000000','0.072144500000000','0.070852627284023','527.2949861131414','527.294986113141363','test'),('2019-03-07 03:59:59','2019-03-07 07:59:59','DATAETH','4h','0.000135590000000','0.000134520000000','0.072144500000000','0.071575176192935','532.0783243602036','532.078324360203624','test'),('2019-03-07 11:59:59','2019-03-08 07:59:59','DATAETH','4h','0.000138250000000','0.000136110000000','0.072144500000000','0.071027760542495','521.8408679927667','521.840867992766675','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','DATAETH','4h','0.000146310000000','0.000144510000000','0.072144500000000','0.071256931822842','493.0934317544939','493.093431754493906','test'),('2019-03-25 03:59:59','2019-03-25 07:59:59','DATAETH','4h','0.000145420000000','0.000143740000000','0.072144500000000','0.071311033076606','496.11126392518224','496.111263925182243','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','DATAETH','4h','0.000153350000000','0.000163370000000','0.072144500000000','0.076858473850668','470.4564721225954','470.456472122595414','test'),('2019-04-04 19:59:59','2019-04-04 23:59:59','DATAETH','4h','0.000158290000000','0.000155300000000','0.072144500000000','0.070781735106450','455.77421188956976','455.774211889569756','test'),('2019-04-06 11:59:59','2019-04-06 15:59:59','DATAETH','4h','0.000158180000000','0.000155360000000','0.072144500000000','0.070858322923252','456.0911619673789','456.091161967378923','test'),('2019-04-15 07:59:59','2019-04-15 11:59:59','DATAETH','4h','0.000149390000000','0.000148000000000','0.072144500000000','0.071473231139969','482.9272374322244','482.927237432224388','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','DATAETH','4h','0.000147970000000','0.000149000000000','0.072144500000000','0.072646688517943','487.5616679056565','487.561667905656520','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','DATAETH','4h','0.000108920000000','0.000086030000000','0.072144500000000','0.056983027313625','662.3622842453177','662.362284245317710','test'),('2019-05-22 15:59:59','2019-05-24 15:59:59','DATAETH','4h','0.000090190000000','0.000089340000000','0.072144500000000','0.071464570684111','799.9168422219758','799.916842221975799','test'),('2019-05-25 19:59:59','2019-05-25 23:59:59','DATAETH','4h','0.000091790000000','0.000091990000000','0.072144500000000','0.072301694683517','785.9734175836147','785.973417583614719','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','DATAETH','4h','0.000100280000000','0.000099310000000','0.072144500000000','0.071446652323494','719.4305943358596','719.430594335859610','test'),('2019-06-07 19:59:59','2019-06-09 19:59:59','DATAETH','4h','0.000098170000000','0.000101450000000','0.072144500000000','0.074554950850565','734.8935520016298','734.893552001629814','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','DATAETH','4h','0.000100240000000','0.000097630000000','0.072144500000000','0.070266036861532','719.7176775738228','719.717677573822812','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','DATAETH','4h','0.000100850000000','0.000100600000000','0.072144500000000','0.071965658899355','715.3644025780862','715.364402578086242','test'),('2019-07-05 15:59:59','2019-07-05 19:59:59','DATAETH','4h','0.000071980000000','0.000072320000000','0.072144500000000','0.072485277021395','1002.2853570436232','1002.285357043623208','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','DATAETH','4h','0.000072140000000','0.000068970000000','0.072144500000000','0.068974302259495','1000.0623787080677','1000.062378708067740','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','DATAETH','4h','0.000071880000000','0.000066650000000','0.072144500000000','0.066895254938787','1003.6797440178075','1003.679744017807479','test'),('2019-07-14 11:59:59','2019-07-14 23:59:59','DATAETH','4h','0.000067330000000','0.000067410000000','0.072144500000000','0.072230220481212','1071.5060151492648','1071.506015149264840','test'),('2019-07-21 23:59:59','2019-07-22 03:59:59','DATAETH','4h','0.000065920000000','0.000065380000000','0.072144500000000','0.071553510467233','1094.4250606796115','1094.425060679611533','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','DATAETH','4h','0.000065690000000','0.000065770000000','0.072144500000000','0.072232360557162','1098.25696453037','1098.256964530369942','test'),('2019-07-25 15:59:59','2019-07-26 11:59:59','DATAETH','4h','0.000067130000000','0.000066050000000','0.072144500000000','0.070983825785789','1074.6983464918815','1074.698346491881466','test'),('2019-08-15 11:59:59','2019-08-15 23:59:59','DATAETH','4h','0.000056450000000','0.000066860000000','0.072144500000000','0.085448738175376','1278.0248007085916','1278.024800708591556','test'),('2019-08-20 23:59:59','2019-08-21 03:59:59','DATAETH','4h','0.000057180000000','0.000057800000000','0.072144500000000','0.072926759356418','1261.7086393844002','1261.708639384400158','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','DATAETH','4h','0.000059280000000','0.000056470000000','0.072144500000000','0.068724694922402','1217.0124831309042','1217.012483130904229','test'),('2019-08-23 23:59:59','2019-09-02 23:59:59','DATAETH','4h','0.000059210000000','0.000064340000000','0.072144500000000','0.078395155041378','1218.4512751224456','1218.451275122445622','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','DATAETH','4h','0.000066170000000','0.000066280000000','0.072144500000000','0.072264431917788','1090.2901617047','1090.290161704700040','test'),('2019-09-19 11:59:59','2019-09-19 15:59:59','DATAETH','4h','0.000065310000000','0.000067660000000','0.072144500000000','0.074740420609401','1104.6470678303476','1104.647067830347623','test'),('2019-09-20 07:59:59','2019-09-20 15:59:59','DATAETH','4h','0.000064610000000','0.000063280000000','0.072144500000000','0.070659401950163','1116.6150750657791','1116.615075065779138','test'),('2019-09-22 15:59:59','2019-09-23 03:59:59','DATAETH','4h','0.000066510000000','0.000065440000000','0.072144500000000','0.070983853255150','1084.716583972335','1084.716583972335002','test'),('2019-10-01 15:59:59','2019-10-08 03:59:59','DATAETH','4h','0.000062900000000','0.000066930000000','0.072144500000000','0.076766794674086','1146.9713831478539','1146.971383147853885','test'),('2019-10-08 15:59:59','2019-10-08 19:59:59','DATAETH','4h','0.000068110000000','0.000067450000000','0.072144500000000','0.071445404859786','1059.235060930847','1059.235060930847112','test'),('2019-10-11 11:59:59','2019-10-13 15:59:59','DATAETH','4h','0.000067370000000','0.000066060000000','0.072144500000000','0.070741660531394','1070.869823363515','1070.869823363515025','test'),('2019-10-14 07:59:59','2019-10-15 03:59:59','DATAETH','4h','0.000069000000000','0.000067670000000','0.072144500000000','0.070753888623188','1045.572463768116','1045.572463768115995','test'),('2019-10-20 11:59:59','2019-10-23 19:59:59','DATAETH','4h','0.000073970000000','0.000072050000000','0.072144500000000','0.070271883533865','975.3210761119373','975.321076111937259','test'),('2019-10-24 15:59:59','2019-10-25 19:59:59','DATAETH','4h','0.000072730000000','0.000068990000000','0.072144500000000','0.068434608208442','991.9496768871167','991.949676887116652','test'),('2019-10-28 07:59:59','2019-10-28 11:59:59','DATAETH','4h','0.000070620000000','0.000070020000000','0.072144500000000','0.071531547578590','1021.5873690172756','1021.587369017275591','test'),('2019-11-01 15:59:59','2019-11-01 19:59:59','DATAETH','4h','0.000069530000000','0.000069240000000','0.072144500000000','0.071843595282612','1037.6024737523371','1037.602473752337119','test'),('2019-11-07 15:59:59','2019-11-07 23:59:59','DATAETH','4h','0.000069100000000','0.000067480000000','0.072144500000000','0.070453123878437','1044.0593342981188','1044.059334298118756','test'),('2019-11-11 11:59:59','2019-11-11 15:59:59','DATAETH','4h','0.000068190000000','0.000066720000000','0.072144500000000','0.070589251209855','1057.9923742484236','1057.992374248423630','test'),('2019-11-12 03:59:59','2019-11-12 11:59:59','DATAETH','4h','0.000067540000000','0.000065910000000','0.072144500000000','0.070403375703287','1068.174415161386','1068.174415161385923','test'),('2019-11-16 23:59:59','2019-11-17 03:59:59','DATAETH','4h','0.000065750000000','0.000065810000000','0.072144500000000','0.072210335285171','1097.2547528517111','1097.254752851711146','test'),('2019-11-19 07:59:59','2019-11-19 11:59:59','DATAETH','4h','0.000066070000000','0.000066150000000','0.072144500000000','0.072231855229302','1091.94036627819','1091.940366278189913','test'),('2019-12-06 07:59:59','2019-12-06 11:59:59','DATAETH','4h','0.000139020000000','0.000136110000000','0.072144500000000','0.070634354013811','518.9505107178823','518.950510717882253','test'),('2019-12-13 19:59:59','2019-12-14 07:59:59','DATAETH','4h','0.000119120000000','0.000122620000000','0.072144500000000','0.074264259486232','605.6455674949631','605.645567494963075','test'),('2019-12-19 19:59:59','2019-12-22 11:59:59','DATAETH','4h','0.000119500000000','0.000113190000000','0.072144500000000','0.068335028912134','603.7196652719665','603.719665271966505','test'),('2019-12-24 19:59:59','2019-12-25 19:59:59','DATAETH','4h','0.000117310000000','0.000113110000000','0.072144500000000','0.069561541172961','614.990196914159','614.990196914159014','test'),('2019-12-27 07:59:59','2019-12-27 11:59:59','DATAETH','4h','0.000115140000000','0.000112890000000','0.072144500000000','0.070734693460135','626.5806843842279','626.580684384227879','test'),('2019-12-28 15:59:59','2019-12-28 19:59:59','DATAETH','4h','0.000117120000000','0.000114130000000','0.072144500000000','0.070302696251708','615.9878756830601','615.987875683060111','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','DATAETH','4h','0.000114870000000','0.000110610000000','0.072144500000000','0.069468992295639','628.0534517280404','628.053451728040386','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 22:43:05
