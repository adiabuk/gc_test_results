-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-07 11:59:59','OAXBTC','4h','0.000023730000000','0.000024190000000','0.001467500000000','0.001495947113359','61.84155077960388','61.841550779603878','test'),('2019-01-14 19:59:59','2019-01-27 11:59:59','OAXBTC','4h','0.000023820000000','0.000039560000000','0.001474611778340','0.002449019393414','61.90645584969564','61.906455849695639','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','OAXBTC','4h','0.000042060000000','0.000038850000000','0.001718213682108','0.001587080398238','40.85149030214574','40.851490302145741','test'),('2019-02-02 11:59:59','2019-02-02 15:59:59','OAXBTC','4h','0.000040000000000','0.000038910000000','0.001718213682108','0.001671392359271','42.9553420527','42.955342052699997','test'),('2019-02-10 23:59:59','2019-02-11 03:59:59','OAXBTC','4h','0.000036180000000','0.000035420000000','0.001718213682108','0.001682120746829','47.49070431475953','47.490704314759533','test'),('2019-02-11 11:59:59','2019-02-11 15:59:59','OAXBTC','4h','0.000035930000000','0.000037480000000','0.001718213682108','0.001792336454367','47.82114339293069','47.821143392930693','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','OAXBTC','4h','0.000037340000000','0.000035840000000','0.001718213682108','0.001649190636496','46.01536374151045','46.015363741510448','test'),('2019-02-13 11:59:59','2019-02-13 15:59:59','OAXBTC','4h','0.000036000000000','0.000036040000000','0.001718213682108','0.001720122808421','47.72815783633333','47.728157836333331','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','OAXBTC','4h','0.000033860000000','0.000033120000000','0.001718213682108','0.001680662644755','50.744645071116366','50.744645071116366','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','OAXBTC','4h','0.000034520000000','0.000033580000000','0.001718213682108','0.001671425708146','49.77444038551564','49.774440385515639','test'),('2019-03-01 19:59:59','2019-03-01 23:59:59','OAXBTC','4h','0.000033160000000','0.000033270000000','0.001718213682108','0.001723913425927','51.81585289831121','51.815852898311213','test'),('2019-03-02 23:59:59','2019-03-04 03:59:59','OAXBTC','4h','0.000033720000000','0.000033010000000','0.001718213682108','0.001682035398766','50.955328650889676','50.955328650889676','test'),('2019-03-05 19:59:59','2019-03-06 15:59:59','OAXBTC','4h','0.000033280000000','0.000033750000000','0.001718213682108','0.001742479320046','51.629016890264424','51.629016890264424','test'),('2019-03-12 11:59:59','2019-03-18 07:59:59','OAXBTC','4h','0.000035100000000','0.000037600000000','0.001718213682108','0.001840593573996','48.95195675521367','48.951956755213672','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','OAXBTC','4h','0.000038230000000','0.000088340000000','0.001718213682108','0.003970363501894','44.944119333193825','44.944119333193825','test'),('2019-04-09 19:59:59','2019-04-10 11:59:59','OAXBTC','4h','0.000054850000000','0.000047570000000','0.002237448459545','0.001940481736017','40.79213235269371','40.792132352693713','test'),('2019-04-11 23:59:59','2019-04-12 03:59:59','OAXBTC','4h','0.000052690000000','0.000052420000000','0.002237448459545','0.002225983075524','42.46438526371228','42.464385263712281','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','OAXBTC','4h','0.000048760000000','0.000047500000000','0.002237448459545','0.002179630882453','45.886965946369976','45.886965946369976','test'),('2019-04-16 03:59:59','2019-04-16 07:59:59','OAXBTC','4h','0.000048680000000','0.000049080000000','0.002237448459545','0.002255833409911','45.96237591505752','45.962375915057521','test'),('2019-04-20 11:59:59','2019-04-20 15:59:59','OAXBTC','4h','0.000047010000000','0.000046460000000','0.002237448459545','0.002211271121686','47.595159743565205','47.595159743565205','test'),('2019-05-15 23:59:59','2019-05-16 03:59:59','OAXBTC','4h','0.000028040000000','0.000026810000000','0.002237448459545','0.002139300756077','79.79488086822397','79.794880868223970','test'),('2019-05-18 15:59:59','2019-05-18 23:59:59','OAXBTC','4h','0.000027130000000','0.000027230000000','0.002237448459545','0.002245695597251','82.47137705657944','82.471377056579442','test'),('2019-05-20 11:59:59','2019-05-20 15:59:59','OAXBTC','4h','0.000027360000000','0.000026790000000','0.002237448459545','0.002190834949971','81.77808697167399','81.778086971673986','test'),('2019-05-21 03:59:59','2019-05-21 23:59:59','OAXBTC','4h','0.000027770000000','0.000026960000000','0.002237448459545','0.002172186189029','80.57070434083543','80.570704340835434','test'),('2019-05-25 03:59:59','2019-05-25 07:59:59','OAXBTC','4h','0.000027670000000','0.000028130000000','0.002237448459545','0.002274644928334','80.86188867166607','80.861888671666065','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','OAXBTC','4h','0.000027950000000','0.000027930000000','0.002237448459545','0.002235847423080','80.0518232395349','80.051823239534897','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','OAXBTC','4h','0.000025900000000','0.000025580000000','0.002237448459545','0.002209804308693','86.38797141100386','86.387971411003861','test'),('2019-06-10 03:59:59','2019-06-10 11:59:59','OAXBTC','4h','0.000026090000000','0.000026000000000','0.002237448459545','0.002229730162828','85.75885241644309','85.758852416443091','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','OAXBTC','4h','0.000026570000000','0.000025420000000','0.002237448459545','0.002140607446053','84.209576949379','84.209576949378999','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','OAXBTC','4h','0.000027370000000','0.000025390000000','0.002237448459545','0.002075587007229','81.7482082405919','81.748208240591893','test'),('2019-06-15 07:59:59','2019-06-15 15:59:59','OAXBTC','4h','0.000027880000000','0.000026200000000','0.002237448459545','0.002102623731710','80.25281418741034','80.252814187410337','test'),('2019-07-26 11:59:59','2019-07-27 03:59:59','OAXBTC','4h','0.000010620000000','0.000010270000000','0.002237448459545','0.002163709574343','210.68252914736348','210.682529147363482','test'),('2019-07-27 11:59:59','2019-07-30 15:59:59','OAXBTC','4h','0.000010400000000','0.000010840000000','0.002237448459545','0.002332109740526','215.13927495625','215.139274956250006','test'),('2019-08-14 03:59:59','2019-08-14 11:59:59','OAXBTC','4h','0.000008240000000','0.000008050000000','0.002237448459545','0.002185856808172','271.5350072263349','271.535007226334926','test'),('2019-08-21 15:59:59','2019-08-22 07:59:59','OAXBTC','4h','0.000007590000000','0.000007470000000','0.002237448459545','0.002202073780343','294.78899335243744','294.788993352437444','test'),('2019-08-24 07:59:59','2019-08-26 03:59:59','OAXBTC','4h','0.000007670000000','0.000007750000000','0.002237448459545','0.002260785601235','291.7142711271187','291.714271127118707','test'),('2019-08-29 11:59:59','2019-08-29 15:59:59','OAXBTC','4h','0.000008130000000','0.000008140000000','0.002237448459545','0.002240200548671','275.20891261316115','275.208912613161147','test'),('2019-08-30 11:59:59','2019-08-30 19:59:59','OAXBTC','4h','0.000008200000000','0.000008200000000','0.002237448459545','0.002237448459545','272.85956823719516','272.859568237195163','test'),('2019-09-01 11:59:59','2019-09-01 15:59:59','OAXBTC','4h','0.000008200000000','0.000008130000000','0.002237448459545','0.002218348289768','272.85956823719516','272.859568237195163','test'),('2019-09-10 07:59:59','2019-09-10 11:59:59','OAXBTC','4h','0.000007380000000','0.000007190000000','0.002237448459545','0.002179844772917','303.17729804132796','303.177298041327958','test'),('2019-09-11 15:59:59','2019-09-11 19:59:59','OAXBTC','4h','0.000007340000000','0.000006840000000','0.002237448459545','0.002085033714344','304.82949040122617','304.829490401226167','test'),('2019-09-15 03:59:59','2019-09-15 19:59:59','OAXBTC','4h','0.000007140000000','0.000007340000000','0.002237448459545','0.002300122085863','313.36813158893557','313.368131588935569','test'),('2019-09-27 11:59:59','2019-09-27 15:59:59','OAXBTC','4h','0.000007500000000','0.000007390000000','0.002237448459545','0.002204632548805','298.3264612726667','298.326461272666677','test'),('2019-09-27 19:59:59','2019-09-27 23:59:59','OAXBTC','4h','0.000007580000000','0.000007560000000','0.002237448459545','0.002231544901604','295.17789703759894','295.177897037598939','test'),('2019-09-29 23:59:59','2019-09-30 07:59:59','OAXBTC','4h','0.000007530000000','0.000007610000000','0.002237448459545','0.002261219492316','297.13790963413015','297.137909634130153','test'),('2019-10-15 11:59:59','2019-10-15 15:59:59','OAXBTC','4h','0.000008690000000','0.000008550000000','0.002237448459545','0.002201402109219','257.4739309027618','257.473930902761822','test'),('2019-10-16 19:59:59','2019-10-18 03:59:59','OAXBTC','4h','0.000009010000000','0.000008740000000','0.002237448459545','0.002170399504597','248.32946276859047','248.329462768590474','test'),('2019-10-24 15:59:59','2019-10-25 07:59:59','OAXBTC','4h','0.000008540000000','0.000008570000000','0.002237448459545','0.002245308348747','261.9963067382904','261.996306738290400','test'),('2019-10-28 15:59:59','2019-10-28 19:59:59','OAXBTC','4h','0.000008040000000','0.000007930000000','0.002237448459545','0.002206836602511','278.28960939614433','278.289609396144328','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','OAXBTC','4h','0.000008000000000','0.000007810000000','0.002237448459545','0.002184309058631','279.68105744312504','279.681057443125042','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','OAXBTC','4h','0.000008140000000','0.000007940000000','0.002237448459545','0.002182474295920','274.8708181259214','274.870818125921403','test'),('2019-11-05 11:59:59','2019-11-05 15:59:59','OAXBTC','4h','0.000008180000000','0.000008180000000','0.002237448459545','0.002237448459545','273.5267065458435','273.526706545843524','test'),('2019-11-07 19:59:59','2019-11-07 23:59:59','OAXBTC','4h','0.000008230000000','0.000008220000000','0.002237448459545','0.002234729810141','271.8649404064398','271.864940406439814','test'),('2019-11-12 19:59:59','2019-11-12 23:59:59','OAXBTC','4h','0.000008180000000','0.000008120000000','0.002237448459545','0.002221036857152','273.5267065458435','273.526706545843524','test'),('2019-11-13 11:59:59','2019-11-13 15:59:59','OAXBTC','4h','0.000008160000000','0.000008220000000','0.002237448459545','0.002253900286453','274.19711514031866','274.197115140318658','test'),('2019-11-14 15:59:59','2019-11-14 19:59:59','OAXBTC','4h','0.000008140000000','0.000008070000000','0.002237448459545','0.002218207502276','274.8708181259214','274.870818125921403','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','OAXBTC','4h','0.000008180000000','0.000008050000000','0.002237448459545','0.002201889987694','273.5267065458435','273.526706545843524','test'),('2019-11-16 03:59:59','2019-11-16 23:59:59','OAXBTC','4h','0.000008150000000','0.000008190000000','0.002237448459545','0.002248429801678','274.5335533184049','274.533553318404927','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','OAXBTC','4h','0.000008190000000','0.000008110000000','0.002237448459545','0.002215593041137','273.19273010317465','273.192730103174654','test'),('2019-11-20 15:59:59','2019-11-20 19:59:59','OAXBTC','4h','0.000008310000000','0.000008240000000','0.002237448459545','0.002218601119934','269.24770872984357','269.247708729843566','test'),('2019-11-26 03:59:59','2019-11-26 07:59:59','OAXBTC','4h','0.000008060000000','0.000007980000000','0.002237448459545','0.002215240534388','277.5990644596774','277.599064459677379','test'),('2019-11-28 07:59:59','2019-11-28 15:59:59','OAXBTC','4h','0.000008110000000','0.000008030000000','0.002237448459545','0.002215377451313','275.8876029032059','275.887602903205902','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','OAXBTC','4h','0.000008320000000','0.000007990000000','0.002237448459545','0.002148703508626','268.92409369531254','268.924093695312536','test'),('2019-12-06 15:59:59','2019-12-07 07:59:59','OAXBTC','4h','0.000008520000000','0.000008250000000','0.002237448459545','0.002166543402728','262.6113215428404','262.611321542840415','test'),('2019-12-08 07:59:59','2019-12-08 11:59:59','OAXBTC','4h','0.000008280000000','0.000008390000000','0.002237448459545','0.002267173016375','270.22324390640097','270.223243906400967','test'),('2019-12-21 19:59:59','2019-12-21 23:59:59','OAXBTC','4h','0.000007670000000','0.000007250000000','0.002237448459545','0.002114928465672','291.7142711271187','291.714271127118707','test'),('2019-12-29 03:59:59','2019-12-29 07:59:59','OAXBTC','4h','0.000007220000000','0.000007060000000','0.002237448459545','0.002187865114181','309.8959085242382','309.895908524238223','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:57:04
