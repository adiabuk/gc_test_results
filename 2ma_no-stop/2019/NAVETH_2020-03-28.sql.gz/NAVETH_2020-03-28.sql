-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-07 23:59:59','NAVETH','4h','0.001226000000000','0.001214000000000','0.072144500000000','0.071438354812398','58.845432300163125','58.845432300163125','test'),('2019-01-10 07:59:59','2019-01-11 03:59:59','NAVETH','4h','0.001206000000000','0.001192000000000','0.072144500000000','0.071307001658375','59.82131011608623','59.821310116086231','test'),('2019-01-28 15:59:59','2019-01-29 07:59:59','NAVETH','4h','0.001443000000000','0.001393000000000','0.072144500000000','0.069644690575191','49.996188496188495','49.996188496188495','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','NAVETH','4h','0.001418000000000','0.001402000000000','0.072144500000000','0.071330457686883','50.877644569816646','50.877644569816646','test'),('2019-02-03 15:59:59','2019-02-04 15:59:59','NAVETH','4h','0.001389000000000','0.001405000000000','0.072144500000000','0.072975538156947','51.939884809215265','51.939884809215265','test'),('2019-02-05 23:59:59','2019-02-06 03:59:59','NAVETH','4h','0.001374000000000','0.001382000000000','0.072144500000000','0.072564555312955','52.506914119359536','52.506914119359536','test'),('2019-02-07 07:59:59','2019-02-07 11:59:59','NAVETH','4h','0.001371000000000','0.001349000000000','0.072144500000000','0.070986820204230','52.62180889861415','52.621808898614148','test'),('2019-02-07 15:59:59','2019-02-07 19:59:59','NAVETH','4h','0.001379000000000','0.001372000000000','0.072144500000000','0.071778284263959','52.31653372008702','52.316533720087023','test'),('2019-02-26 19:59:59','2019-02-27 15:59:59','NAVETH','4h','0.001158000000000','0.001141000000000','0.072144500000000','0.071085383851468','62.30094991364422','62.300949913644217','test'),('2019-02-28 15:59:59','2019-03-06 03:59:59','NAVETH','4h','0.001148000000000','0.001195000000000','0.072144500000000','0.075098151132404','62.84364111498258','62.843641114982582','test'),('2019-03-16 15:59:59','2019-03-16 19:59:59','NAVETH','4h','0.001314000000000','0.001314000000000','0.072144500000000','0.072144500000000','54.9044901065449','54.904490106544898','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','NAVETH','4h','0.001565000000000','0.001506000000000','0.072144500000000','0.069424675399361','46.09872204472843','46.098722044728433','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','NAVETH','4h','0.001549000000000','0.001549000000000','0.072144500000000','0.072144500000000','46.574887023886376','46.574887023886376','test'),('2019-04-17 23:59:59','2019-04-18 03:59:59','NAVETH','4h','0.001428000000000','0.001354000000000','0.072144500000000','0.068405919467787','50.521358543417364','50.521358543417364','test'),('2019-04-18 23:59:59','2019-04-19 03:59:59','NAVETH','4h','0.001404000000000','0.001384000000000','0.072144500000000','0.071116800569801','51.38497150997151','51.384971509971507','test'),('2019-05-02 23:59:59','2019-05-03 03:59:59','NAVETH','4h','0.001242000000000','0.001233000000000','0.072144500000000','0.071621713768116','58.08735909822866','58.087359098228660','test'),('2019-05-03 19:59:59','2019-05-04 03:59:59','NAVETH','4h','0.001275000000000','0.001212000000000','0.072144500000000','0.068579712941176','56.583921568627446','56.583921568627446','test'),('2019-05-18 15:59:59','2019-05-18 23:59:59','NAVETH','4h','0.001021000000000','0.000947000000000','0.072144500000000','0.066915613614104','70.66062683643487','70.660626836434872','test'),('2019-05-22 23:59:59','2019-05-23 07:59:59','NAVETH','4h','0.000957000000000','0.000940000000000','0.072144500000000','0.070862936259143','75.38610240334378','75.386102403343784','test'),('2019-05-31 23:59:59','2019-06-01 03:59:59','NAVETH','4h','0.000862000000000','0.000835000000000','0.072144500000000','0.069884753480278','83.69431554524361','83.694315545243612','test'),('2019-06-01 15:59:59','2019-06-03 23:59:59','NAVETH','4h','0.000897000000000','0.000861000000000','0.072144500000000','0.069249068561873','80.42865105908584','80.428651059085837','test'),('2019-06-05 11:59:59','2019-06-06 15:59:59','NAVETH','4h','0.000883000000000','0.000875000000000','0.072144500000000','0.071490869195923','81.70385050962628','81.703850509626278','test'),('2019-06-07 07:59:59','2019-06-12 15:59:59','NAVETH','4h','0.000884000000000','0.000903000000000','0.072144500000000','0.073695117081448','81.61142533936652','81.611425339366519','test'),('2019-06-13 15:59:59','2019-06-14 15:59:59','NAVETH','4h','0.000968000000000','0.000874000000000','0.072144500000000','0.065138732438017','74.52944214876032','74.529442148760324','test'),('2019-06-16 15:59:59','2019-06-16 19:59:59','NAVETH','4h','0.000925000000000','0.000892000000000','0.072144500000000','0.069570696216216','77.99405405405405','77.994054054054047','test'),('2019-06-18 19:59:59','2019-06-19 03:59:59','NAVETH','4h','0.000962000000000','0.000886000000000','0.072144500000000','0.066444934511435','74.99428274428274','74.994282744282742','test'),('2019-07-12 15:59:59','2019-07-12 19:59:59','NAVETH','4h','0.000654000000000','0.000630000000000','0.072144500000000','0.069496995412844','110.31269113149848','110.312691131498482','test'),('2019-07-13 03:59:59','2019-07-13 11:59:59','NAVETH','4h','0.000635000000000','0.000657000000000','0.072144500000000','0.074643994488189','113.61338582677165','113.613385826771648','test'),('2019-07-22 07:59:59','2019-07-22 15:59:59','NAVETH','4h','0.000611000000000','0.000610000000000','0.072144500000000','0.072026423895254','118.07610474631751','118.076104746317512','test'),('2019-07-30 19:59:59','2019-07-31 07:59:59','NAVETH','4h','0.000633000000000','0.000630000000000','0.072144500000000','0.071802582938389','113.97235387045814','113.972353870458136','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','NAVETH','4h','0.000636000000000','0.000608000000000','0.072144500000000','0.068968327044025','113.43474842767296','113.434748427672957','test'),('2019-07-31 23:59:59','2019-08-01 07:59:59','NAVETH','4h','0.000647000000000','0.000634000000000','0.072144500000000','0.070694919629057','111.50618238021639','111.506182380216387','test'),('2019-08-01 19:59:59','2019-08-01 23:59:59','NAVETH','4h','0.000742000000000','0.000751000000000','0.072144500000000','0.073019568059299','97.22978436657681','97.229784366576808','test'),('2019-08-13 15:59:59','2019-08-13 19:59:59','NAVETH','4h','0.000585000000000','0.000538000000000','0.072144500000000','0.066348275213675','123.32393162393161','123.323931623931614','test'),('2019-08-22 15:59:59','2019-08-25 15:59:59','NAVETH','4h','0.000564000000000','0.000567000000000','0.072144500000000','0.072528247340426','127.91578014184397','127.915780141843967','test'),('2019-08-26 11:59:59','2019-09-01 23:59:59','NAVETH','4h','0.000584000000000','0.000597000000000','0.072144500000000','0.073750456335616','123.53510273972603','123.535102739726028','test'),('2019-09-02 03:59:59','2019-09-02 07:59:59','NAVETH','4h','0.000607000000000','0.000593000000000','0.072144500000000','0.070480541186161','118.85420098846788','118.854200988467881','test'),('2019-09-03 07:59:59','2019-09-03 15:59:59','NAVETH','4h','0.000624000000000','0.000598000000000','0.072144500000000','0.069138479166667','115.6161858974359','115.616185897435898','test'),('2019-09-03 23:59:59','2019-09-04 03:59:59','NAVETH','4h','0.000606000000000','0.000609000000000','0.072144500000000','0.072501650990099','119.0503300330033','119.050330033003306','test'),('2019-09-06 03:59:59','2019-09-06 07:59:59','NAVETH','4h','0.000613000000000','0.000608000000000','0.072144500000000','0.071556045676998','117.69086460032625','117.690864600326250','test'),('2019-09-06 23:59:59','2019-09-07 15:59:59','NAVETH','4h','0.000620000000000','0.000607000000000','0.072144500000000','0.070631792741935','116.36209677419355','116.362096774193546','test'),('2019-09-08 23:59:59','2019-09-09 03:59:59','NAVETH','4h','0.000616000000000','0.000610000000000','0.072144500000000','0.071441793831169','117.1176948051948','117.117694805194802','test'),('2019-09-09 19:59:59','2019-09-10 11:59:59','NAVETH','4h','0.000630000000000','0.000606000000000','0.072144500000000','0.069396138095238','114.51507936507936','114.515079365079359','test'),('2019-09-22 19:59:59','2019-09-22 23:59:59','NAVETH','4h','0.000552000000000','0.000514000000000','0.072144500000000','0.067178030797101','130.6965579710145','130.696557971014499','test'),('2019-09-25 07:59:59','2019-09-25 11:59:59','NAVETH','4h','0.000551000000000','0.000564000000000','0.072144500000000','0.073846638838476','130.93375680580763','130.933756805807633','test'),('2019-10-01 19:59:59','2019-10-01 23:59:59','NAVETH','4h','0.000550000000000','0.000526000000000','0.072144500000000','0.068996376363636','131.17181818181817','131.171818181818168','test'),('2019-10-02 11:59:59','2019-10-02 19:59:59','NAVETH','4h','0.000539000000000','0.000537000000000','0.072144500000000','0.071876802411874','133.8487940630798','133.848794063079794','test'),('2019-10-06 15:59:59','2019-10-08 03:59:59','NAVETH','4h','0.000585000000000','0.000555000000000','0.072144500000000','0.068444782051282','123.32393162393161','123.323931623931614','test'),('2019-10-21 19:59:59','2019-10-22 03:59:59','NAVETH','4h','0.000495000000000','0.000492000000000','0.072144500000000','0.071707260606061','145.74646464646466','145.746464646464659','test'),('2019-10-22 15:59:59','2019-10-22 23:59:59','NAVETH','4h','0.000504000000000','0.000489000000000','0.072144500000000','0.069997342261905','143.14384920634922','143.143849206349216','test'),('2019-10-24 15:59:59','2019-10-24 19:59:59','NAVETH','4h','0.000507000000000','0.000484000000000','0.072144500000000','0.068871672583826','142.2968441814596','142.296844181459591','test'),('2019-10-26 15:59:59','2019-10-27 15:59:59','NAVETH','4h','0.000536000000000','0.000506000000000','0.048096333333333','0.045404374378109','89.73196517412934','89.731965174129343','test'),('2019-10-30 15:59:59','2019-10-31 11:59:59','NAVETH','4h','0.000510000000000','0.000516000000000','0.052690365040867','0.053310251688407','103.31444125660097','103.314441256600972','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:31:51
