-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-08-23 03:59:59','2019-08-23 07:59:59','BTTBNB','4h','0.000023320000000','0.000023030000000','0.711908500000000','0.703055435463122','30527.80874785592','30527.808747855920956','test'),('2019-08-23 11:59:59','2019-08-24 11:59:59','BTTBNB','4h','0.000023320000000','0.000023320000000','0.711908500000000','0.711908500000000','30527.80874785592','30527.808747855920956','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','BTTBNB','4h','0.000023880000000','0.000023910000000','0.711908500000000','0.712802857412060','29811.913735343387','29811.913735343387089','test'),('2019-09-03 19:59:59','2019-09-04 03:59:59','BTTBNB','4h','0.000024090000000','0.000024130000000','0.711908500000000','0.713090581361561','29552.034039020342','29552.034039020341879','test'),('2019-09-08 03:59:59','2019-09-08 15:59:59','BTTBNB','4h','0.000024120000000','0.000026500000000','0.711908500000000','0.782154861111111','29515.27777777778','29515.277777777781012','test'),('2019-09-21 11:59:59','2019-09-21 15:59:59','BTTBNB','4h','0.000027250000000','0.000027660000000','0.727775933836963','0.738725957061666','26707.37371878765','26707.373718787650432','test'),('2019-09-22 11:59:59','2019-09-22 15:59:59','BTTBNB','4h','0.000027370000000','0.000027120000000','0.730513439643139','0.723840865294919','26690.297392880497','26690.297392880496773','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','BTTBNB','4h','0.000027410000000','0.000026970000000','0.730513439643139','0.718786846668204','26651.347670307878','26651.347670307877706','test'),('2019-09-25 15:59:59','2019-09-25 19:59:59','BTTBNB','4h','0.000027440000000','0.000026510000000','0.730513439643139','0.705754784436575','26622.209899531303','26622.209899531302653','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','BTTBNB','4h','0.000027250000000','0.000027200000000','0.730513439643139','0.729173048010766','26807.83264745464','26807.832647454641119','test'),('2019-10-02 07:59:59','2019-10-02 11:59:59','BTTBNB','4h','0.000027480000000','0.000026850000000','0.730513439643139','0.713765860786691','26583.45850229763','26583.458502297631640','test'),('2019-10-02 23:59:59','2019-10-03 07:59:59','BTTBNB','4h','0.000027670000000','0.000027130000000','0.730513439643139','0.716256943170161','26400.91939440329','26400.919394403288607','test'),('2019-10-04 11:59:59','2019-10-04 15:59:59','BTTBNB','4h','0.000027270000000','0.000027190000000','0.730513439643139','0.728370385914813','26788.1716040755','26788.171604075501818','test'),('2019-10-05 07:59:59','2019-10-05 15:59:59','BTTBNB','4h','0.000027380000000','0.000027280000000','0.730513439643139','0.727845384713836','26680.549293029184','26680.549293029183900','test'),('2019-10-27 15:59:59','2019-10-28 07:59:59','BTTBNB','4h','0.000024270000000','0.000022940000000','0.730513439643139','0.690481182752930','30099.441270833908','30099.441270833907765','test'),('2019-10-28 19:59:59','2019-10-28 23:59:59','BTTBNB','4h','0.000023290000000','0.000023210000000','0.730513439643139','0.728004162048830','31365.969928859555','31365.969928859554784','test'),('2019-10-29 23:59:59','2019-10-30 19:59:59','BTTBNB','4h','0.000023920000000','0.000023550000000','0.730513439643139','0.719213691621903','30539.859516853634','30539.859516853633977','test'),('2019-11-02 03:59:59','2019-11-02 07:59:59','BTTBNB','4h','0.000023460000000','0.000023020000000','0.730513439643139','0.716812420314794','31138.680291693905','31138.680291693905019','test'),('2019-11-19 11:59:59','2019-11-20 03:59:59','BTTBNB','4h','0.000021550000000','0.000021510000000','0.730513439643139','0.729157498223848','33898.53548228023','33898.535482280232827','test'),('2019-11-28 03:59:59','2019-11-28 07:59:59','BTTBNB','4h','0.000020630000000','0.000020110000000','0.730513439643139','0.712100110093239','35410.24913442264','35410.249134422636416','test'),('2019-11-28 19:59:59','2019-11-29 03:59:59','BTTBNB','4h','0.000020510000000','0.000020490000000','0.730513439643139','0.729801091091561','35617.42757889513','35617.427578895127226','test'),('2019-11-29 19:59:59','2019-11-30 03:59:59','BTTBNB','4h','0.000020340000000','0.000020110000000','0.730513439643139','0.722252963186997','35915.115026703','35915.115026703002513','test'),('2019-12-03 03:59:59','2019-12-03 07:59:59','BTTBNB','4h','0.000020470000000','0.000020170000000','0.730513439643139','0.719807331587793','35687.02685115481','35687.026851154812903','test'),('2019-12-07 03:59:59','2019-12-07 11:59:59','BTTBNB','4h','0.000020140000000','0.000020190000000','0.730513439643139','0.732327028122889','36271.769594992','36271.769594992001657','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','BTTBNB','4h','0.000019970000000','0.000020720000000','0.730513439643139','0.757948846740403','36580.542796351474','36580.542796351473953','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','BTTBNB','4h','0.000020140000000','0.000019410000000','0.730513439643139','0.704035047838795','36271.769594992','36271.769594992001657','test'),('2019-12-13 23:59:59','2019-12-20 03:59:59','BTTBNB','4h','0.000020270000000','0.000020930000000','0.730513439643139','0.754299274382383','36039.143544308776','36039.143544308775745','test'),('2019-12-20 15:59:59','2019-12-21 03:59:59','BTTBNB','4h','0.000021220000000','0.000021020000000','0.730513439643139','0.723628298835946','34425.704035963194','34425.704035963193746','test'),('2019-12-23 19:59:59','2019-12-23 23:59:59','BTTBNB','4h','0.000021300000000','0.000021310000000','0.730513439643139','0.730856403699309','34296.40561704878','34296.405617048782005','test'),('2019-12-25 15:59:59','2019-12-26 03:59:59','BTTBNB','4h','0.000021460000000','0.000021070000000','0.730513439643139','0.717237566322504','34040.70082214068','34040.700822140679520','test'),('2019-12-30 03:59:59','2019-12-31 11:59:59','BTTBNB','4h','0.000021340000000','0.000021130000000','0.730513439643139','0.723324694454523','34232.11994578908','34232.119945789083431','test'),('2020-01-01 07:59:59','2020-01-01 11:59:59','BTTBNB','4h','0.000021140000000','0.000020980000000','0.730513439643139','0.724984482673276','34555.98106164328','34555.981061643280555','test'),('2020-01-01 15:59:59','2020-01-01 23:59:59','BTTBNB','4h','0.000021120000000','0.000020770000000','0.730513439643139','0.718407393058144','34588.70452855771','34588.704528557711456','test'),('2020-01-03 03:59:59','2020-01-03 07:59:59','BTTBNB','4h','0.000021140000000','0.000021040000000','0.730513439643139','0.727057841536975','34555.98106164328','34555.981061643280555','test'),('2020-01-04 03:59:59','2020-01-04 11:59:59','BTTBNB','4h','0.000021150000000','0.000020980000000','0.730513439643139','0.724641700411965','34539.64253631863','34539.642536318628117','test'),('2020-01-05 07:59:59','2020-01-05 15:59:59','BTTBNB','4h','0.000021320000000','0.000020990000000','0.730513439643139','0.719206242875680','34264.23262866506','34264.232628665056836','test'),('2020-01-12 15:59:59','2020-01-13 03:59:59','BTTBNB','4h','0.000020640000000','0.000020560000000','0.730513439643139','0.727681992202662','35393.09300596604','35393.093005966038618','test'),('2020-01-17 07:59:59','2020-01-17 19:59:59','BTTBNB','4h','0.000020950000000','0.000021080000000','0.730513439643139','0.735046458600352','34869.37659394458','34869.376593944580236','test'),('2020-01-22 15:59:59','2020-01-23 03:59:59','BTTBNB','4h','0.000020950000000','0.000020770000000','0.730513439643139','0.724236951856229','34869.37659394458','34869.376593944580236','test'),('2020-01-28 19:59:59','2020-01-29 03:59:59','BTTBNB','4h','0.000020790000000','0.000020670000000','0.730513439643139','0.726296911852991','35137.73158456657','35137.731584566572565','test'),('2020-01-29 19:59:59','2020-01-29 23:59:59','BTTBNB','4h','0.000020690000000','0.000020360000000','0.730513439643139','0.718861944472417','35307.56112339966','35307.561123399660573','test'),('2020-01-30 07:59:59','2020-01-30 11:59:59','BTTBNB','4h','0.000020560000000','0.000020350000000','0.730513439643139','0.723051969685695','35530.80932116435','35530.809321164349967','test'),('2020-01-31 15:59:59','2020-01-31 19:59:59','BTTBNB','4h','0.000020570000000','0.000020570000000','0.730513439643139','0.730513439643139','35513.53620044429','35513.536200444286806','test'),('2020-02-14 03:59:59','2020-02-16 15:59:59','BTTBNB','4h','0.000020450000000','0.000022630000000','0.730513439643139','0.808387243966955','35721.92858890655','35721.928588906550431','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  9:16:58
