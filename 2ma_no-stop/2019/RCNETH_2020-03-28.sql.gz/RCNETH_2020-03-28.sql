-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','RCNETH','4h','0.000085540000000','0.000084960000000','0.072144500000000','0.071655327566051','843.4007481879822','843.400748187982231','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','RCNETH','4h','0.000102840000000','0.000101210000000','0.072144500000000','0.071001019496305','701.5217814080124','701.521781408012430','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','RCNETH','4h','0.000103250000000','0.000102500000000','0.072144500000000','0.071620447941889','698.7360774818402','698.736077481840198','test'),('2019-02-05 15:59:59','2019-02-05 19:59:59','RCNETH','4h','0.000100230000000','0.000098020000000','0.072144500000000','0.070553765239948','719.7894841863714','719.789484186371396','test'),('2019-02-06 03:59:59','2019-02-06 11:59:59','RCNETH','4h','0.000099390000000','0.000099670000000','0.072144500000000','0.072347744390784','725.8728242277896','725.872824227789579','test'),('2019-02-07 19:59:59','2019-02-08 03:59:59','RCNETH','4h','0.000102610000000','0.000099030000000','0.072144500000000','0.069627422619628','703.0942403274535','703.094240327453463','test'),('2019-02-21 23:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000108920000000','0.000169370000000','0.072144500000000','0.112184300082629','662.3622842453177','662.362284245317710','test'),('2019-03-24 15:59:59','2019-03-25 07:59:59','RCNETH','4h','0.000175890000000','0.000170290000000','0.080639131834309','0.078071736653957','458.4634250628717','458.463425062871693','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','RCNETH','4h','0.000173410000000','0.000169610000000','0.080639131834309','0.078872055535535','465.02007862469867','465.020078624698670','test'),('2019-03-27 11:59:59','2019-04-02 07:59:59','RCNETH','4h','0.000177820000000','0.000208630000000','0.080639131834309','0.094611079038308','453.48741330732764','453.487413307327643','test'),('2019-04-04 23:59:59','2019-04-05 03:59:59','RCNETH','4h','0.000196350000000','0.000195170000000','0.083048500765527','0.082549406133985','422.96155215445253','422.961552154452534','test'),('2019-04-13 07:59:59','2019-04-14 23:59:59','RCNETH','4h','0.000187440000000','0.000184500000000','0.083048500765527','0.081745883435978','443.0671188941901','443.067118894190116','test'),('2019-04-15 07:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000185420000000','0.000187050000000','0.083048500765527','0.083778567944083','447.89397457408586','447.893974574085860','test'),('2019-04-19 19:59:59','2019-04-20 03:59:59','RCNETH','4h','0.000188180000000','0.000185700000000','0.083048500765527','0.081954015262825','441.32479947670845','441.324799476708449','test'),('2019-04-20 11:59:59','2019-04-20 23:59:59','RCNETH','4h','0.000193870000000','0.000185540000000','0.083048500765527','0.079480161097828','428.3721089674885','428.372108967488487','test'),('2019-05-02 07:59:59','2019-05-02 11:59:59','RCNETH','4h','0.000162370000000','0.000191310000000','0.083048500765527','0.097850641629938','511.47687852144486','511.476878521444860','test'),('2019-05-10 15:59:59','2019-05-11 11:59:59','RCNETH','4h','0.000179030000000','0.000152390000000','0.085315418493395','0.072620324103270','476.5425822118946','476.542582211894626','test'),('2019-05-11 19:59:59','2019-05-11 23:59:59','RCNETH','4h','0.000157550000000','0.000151990000000','0.085315418493395','0.082304604613209','541.5132878032052','541.513287803205230','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','RCNETH','4h','0.000134020000000','0.000128840000000','0.085315418493395','0.082017896722049','636.5872145455529','636.587214545552911','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','RCNETH','4h','0.000132450000000','0.000128080000000','0.085315418493395','0.082500557196180','644.1330199576821','644.133019957682109','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','RCNETH','4h','0.000131150000000','0.000131330000000','0.085315418493395','0.085432511709779','650.5178688020968','650.517868802096814','test'),('2019-05-27 23:59:59','2019-05-28 07:59:59','RCNETH','4h','0.000137390000000','0.000130730000000','0.085315418493395','0.081179741317720','620.9725489001746','620.972548900174615','test'),('2019-06-01 23:59:59','2019-06-02 03:59:59','RCNETH','4h','0.000126140000000','0.000127600000000','0.085315418493395','0.086302896779429','676.3549904343982','676.354990434398246','test'),('2019-06-07 11:59:59','2019-06-07 23:59:59','RCNETH','4h','0.000124930000000','0.000126490000000','0.085315418493395','0.086380751502678','682.9057751812614','682.905775181261447','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','RCNETH','4h','0.000131500000000','0.000119820000000','0.085315418493395','0.077737592729115','648.7864524212547','648.786452421254694','test'),('2019-06-20 03:59:59','2019-06-20 07:59:59','RCNETH','4h','0.000123090000000','0.000123180000000','0.085315418493395','0.085377798765264','693.1141318823219','693.114131882321885','test'),('2019-07-10 23:59:59','2019-07-11 19:59:59','RCNETH','4h','0.000090450000000','0.000086860000000','0.085315418493395','0.081929212275691','943.2329297224433','943.232929722443259','test'),('2019-07-12 19:59:59','2019-07-12 23:59:59','RCNETH','4h','0.000088000000000','0.000084650000000','0.085315418493395','0.082067615630294','969.4933919703977','969.493391970397738','test'),('2019-07-19 23:59:59','2019-07-20 03:59:59','RCNETH','4h','0.000082780000000','0.000080910000000','0.085315418493395','0.083388143395755','1030.628394459954','1030.628394459954052','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','RCNETH','4h','0.000082250000000','0.000082430000000','0.085315418493395','0.085502127008031','1037.2695257555624','1037.269525755562427','test'),('2019-07-30 11:59:59','2019-07-31 03:59:59','RCNETH','4h','0.000089170000000','0.000087140000000','0.085315418493395','0.083373169984462','956.7726644992149','956.772664499214898','test'),('2019-08-09 07:59:59','2019-08-09 11:59:59','RCNETH','4h','0.000083070000000','0.000078560000000','0.085315418493395','0.080683511217541','1027.0304381051521','1027.030438105152143','test'),('2019-08-10 19:59:59','2019-08-11 07:59:59','RCNETH','4h','0.000085660000000','0.000081180000000','0.085315418493395','0.080853440033782','995.9773347349404','995.977334734940428','test'),('2019-08-12 11:59:59','2019-08-12 15:59:59','RCNETH','4h','0.000081320000000','0.000080820000000','0.085315418493395','0.084790852467243','1049.1320523044146','1049.132052304414628','test'),('2019-08-18 11:59:59','2019-08-18 19:59:59','RCNETH','4h','0.000079940000000','0.000075940000000','0.085315418493395','0.081046445839235','1067.2431635400926','1067.243163540092610','test'),('2019-08-20 19:59:59','2019-08-20 23:59:59','RCNETH','4h','0.000079750000000','0.000078150000000','0.085315418493395','0.083603761194468','1069.7858118294043','1069.785811829404338','test'),('2019-08-29 03:59:59','2019-08-29 07:59:59','RCNETH','4h','0.000085240000000','0.000082110000000','0.085315418493395','0.082182649137643','1000.884778195624','1000.884778195623994','test'),('2019-08-29 19:59:59','2019-09-01 23:59:59','RCNETH','4h','0.000085250000000','0.000084950000000','0.085315418493395','0.085015188281688','1000.7673723565396','1000.767372356539568','test'),('2019-09-16 11:59:59','2019-09-16 15:59:59','RCNETH','4h','0.000075610000000','0.000078610000000','0.085315418493395','0.088700503210763','1128.3615724559581','1128.361572455958139','test'),('2019-09-19 03:59:59','2019-09-30 19:59:59','RCNETH','4h','0.000097280000000','0.000188800000000','0.085315418493395','0.165579266154944','877.0088249732215','877.008824973221522','test'),('2019-10-10 19:59:59','2019-10-11 07:59:59','RCNETH','4h','0.000220250000000','0.000215220000000','0.091065547850584','0.088985821604553','413.4644624317084','413.464462431708398','test'),('2019-10-12 07:59:59','2019-10-12 11:59:59','RCNETH','4h','0.000218480000000','0.000216220000000','0.091065547850584','0.090123547950628','416.814115024643','416.814115024643002','test'),('2019-10-15 15:59:59','2019-10-15 19:59:59','RCNETH','4h','0.000219030000000','0.000227200000000','0.091065547850584','0.094462368039322','415.76746496180436','415.767464961804365','test'),('2019-10-16 23:59:59','2019-10-17 03:59:59','RCNETH','4h','0.000216170000000','0.000220050000000','0.091159321361272','0.092795525121654','421.7020000984018','421.702000098401811','test'),('2019-10-17 23:59:59','2019-10-18 03:59:59','RCNETH','4h','0.000215740000000','0.000215000000000','0.091568372301367','0.091254287775998','424.4385477953417','424.438547795341719','test'),('2019-10-18 19:59:59','2019-10-18 23:59:59','RCNETH','4h','0.000215160000000','0.000217240000000','0.091568372301367','0.092453584303537','425.5826933508412','425.582693350841225','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','RCNETH','4h','0.000214670000000','0.000214120000000','0.091711154170567','0.091476183588773','427.21923962625084','427.219239626250840','test'),('2019-10-21 07:59:59','2019-10-25 07:59:59','RCNETH','4h','0.000215740000000','0.000240460000000','0.091711154170567','0.102219635356700','425.10037160733754','425.100371607337536','test'),('2019-10-29 23:59:59','2019-10-30 03:59:59','RCNETH','4h','0.000227020000000','0.000216780000000','0.094279531821652','0.090026944358637','415.2917444350807','415.291744435080716','test'),('2019-11-01 03:59:59','2019-11-01 11:59:59','RCNETH','4h','0.000227070000000','0.000221710000000','0.094279531821652','0.092054058220718','415.20029868169286','415.200298681692857','test'),('2019-11-06 15:59:59','2019-11-10 19:59:59','RCNETH','4h','0.000228300000000','0.000250730000000','0.094279531821652','0.103542299665540','412.9633456927376','412.963345692737619','test'),('2019-11-19 23:59:59','2019-11-21 11:59:59','RCNETH','4h','0.000253580000000','0.000254040000000','0.094975708516637','0.095147996654178','374.5394294370092','374.539429437009176','test'),('2019-12-05 11:59:59','2019-12-05 15:59:59','RCNETH','4h','0.000321180000000','0.000316430000000','0.095018780551022','0.093613527398219','295.84276901121495','295.842769011214955','test'),('2019-12-06 11:59:59','2019-12-08 03:59:59','RCNETH','4h','0.000326180000000','0.000324160000000','0.095018780551022','0.094430338780487','291.307807195481','291.307807195481018','test'),('2019-12-16 03:59:59','2019-12-16 07:59:59','RCNETH','4h','0.000313830000000','0.000310230000000','0.095018780551022','0.093928803142923','302.7715022496957','302.771502249695686','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','RCNETH','4h','0.000313580000000','0.000311500000000','0.095018780551022','0.094388513749740','303.01288523190897','303.012885231908967','test'),('2019-12-18 03:59:59','2019-12-18 19:59:59','RCNETH','4h','0.000324620000000','0.000312030000000','0.095018780551022','0.091333590337427','292.70772149289013','292.707721492890130','test'),('2019-12-27 15:59:59','2019-12-27 19:59:59','RCNETH','4h','0.000355150000000','0.000349810000000','0.095018780551022','0.093590087637767','267.5454893735661','267.545489373566113','test'),('2019-12-30 03:59:59','2019-12-30 07:59:59','RCNETH','4h','0.000351600000000','0.000339010000000','0.095018780551022','0.091616373135956','270.2468161291866','270.246816129186584','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','RCNETH','4h','0.000349810000000','0.000346420000000','0.095018780551022','0.094097955914597','271.62968626117606','271.629686261176062','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:25:38
