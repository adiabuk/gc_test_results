-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 03:59:59','2019-01-12 07:59:59','EVXBTC','4h','0.000060460000000','0.000060150000000','0.001467500000000','0.001459975603705','24.27224611313265','24.272246113132649','test'),('2019-01-12 23:59:59','2019-01-13 07:59:59','EVXBTC','4h','0.000060320000000','0.000060170000000','0.001467500000000','0.001463850712865','24.328580901856764','24.328580901856764','test'),('2019-01-15 15:59:59','2019-01-18 11:59:59','EVXBTC','4h','0.000060040000000','0.000061090000000','0.001467500000000','0.001493164140573','24.442038640906063','24.442038640906063','test'),('2019-02-08 19:59:59','2019-02-08 23:59:59','EVXBTC','4h','0.000082530000000','0.000080580000000','0.001471122614286','0.001436363264984','17.825307334130013','17.825307334130013','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','EVXBTC','4h','0.000068700000000','0.000067050000000','0.001471122614286','0.001435789975078','21.413720731965064','21.413720731965064','test'),('2019-03-01 03:59:59','2019-03-02 11:59:59','EVXBTC','4h','0.000069390000000','0.000068310000000','0.001471122614286','0.001448225764258','21.200787062775614','21.200787062775614','test'),('2019-03-12 11:59:59','2019-03-18 07:59:59','EVXBTC','4h','0.000075510000000','0.000075770000000','0.001471122614286','0.001476188060978','19.482487276996423','19.482487276996423','test'),('2019-03-19 07:59:59','2019-03-20 03:59:59','EVXBTC','4h','0.000076570000000','0.000077450000000','0.001471122614286','0.001488029861257','19.212780648896434','19.212780648896434','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','EVXBTC','4h','0.000229540000000','0.000162480000000','0.001471122614286','0.001041334853922','6.4090032860765005','6.409003286076500','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','EVXBTC','4h','0.000223920000000','0.000219590000000','0.001471122614286','0.001442675128935','6.569858048794211','6.569858048794211','test'),('2019-05-06 03:59:59','2019-05-07 15:59:59','EVXBTC','4h','0.000135300000000','0.000120940000000','0.001471122614286','0.001314985727803','10.873042234190686','10.873042234190686','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','EVXBTC','4h','0.000112830000000','0.000095300000000','0.001471122614286','0.001242559471253','13.038399488487103','13.038399488487103','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','EVXBTC','4h','0.000090240000000','0.000088130000000','0.001471122614286','0.001436724689683','16.302333934906915','16.302333934906915','test'),('2019-06-02 03:59:59','2019-06-03 23:59:59','EVXBTC','4h','0.000093120000000','0.000091030000000','0.001471122614286','0.001438104505782','15.798138040012885','15.798138040012885','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','EVXBTC','4h','0.000091700000000','0.000091700000000','0.001471122614286','0.001471122614286','16.042776600719737','16.042776600719737','test'),('2019-06-05 07:59:59','2019-06-05 15:59:59','EVXBTC','4h','0.000091610000000','0.000089440000000','0.001471122614286','0.001436275588055','16.058537433533456','16.058537433533456','test'),('2019-06-06 11:59:59','2019-06-14 11:59:59','EVXBTC','4h','0.000093190000000','0.000101770000000','0.001471122614286','0.001606568821289','15.786271212426227','15.786271212426227','test'),('2019-06-15 07:59:59','2019-06-15 11:59:59','EVXBTC','4h','0.000104980000000','0.000105760000000','0.001471122614286','0.001482053035691','14.01336077620499','14.013360776204991','test'),('2019-07-26 23:59:59','2019-07-27 03:59:59','EVXBTC','4h','0.000041980000000','0.000040790000000','0.001471122614286','0.001429420948945','35.043416252644114','35.043416252644114','test'),('2019-07-27 11:59:59','2019-07-31 15:59:59','EVXBTC','4h','0.000043160000000','0.000049300000000','0.001471122614286','0.001680406507977','34.085324705421684','34.085324705421684','test'),('2019-08-04 11:59:59','2019-08-04 15:59:59','EVXBTC','4h','0.000051360000000','0.000047150000000','0.001471122614286','0.001350534097811','28.64335308189252','28.643353081892521','test'),('2019-08-09 11:59:59','2019-08-09 19:59:59','EVXBTC','4h','0.000050300000000','0.000042360000000','0.001471122614286','0.001238901668810','29.246970462942343','29.246970462942343','test'),('2019-08-10 11:59:59','2019-08-10 15:59:59','EVXBTC','4h','0.000046940000000','0.000043260000000','0.001471122614286','0.001355789610013','31.340490291563697','31.340490291563697','test'),('2019-08-13 07:59:59','2019-08-13 11:59:59','EVXBTC','4h','0.000044700000000','0.000044270000000','0.001471122614286','0.001456970875491','32.9110204538255','32.911020453825500','test'),('2019-08-13 15:59:59','2019-08-14 19:59:59','EVXBTC','4h','0.000044730000000','0.000044300000000','0.001471122614286','0.001456980366932','32.888947334808854','32.888947334808854','test'),('2019-08-17 23:59:59','2019-08-19 07:59:59','EVXBTC','4h','0.000045800000000','0.000043390000000','0.001471122614286','0.001393712013840','32.12058109794759','32.120581097947593','test'),('2019-08-20 23:59:59','2019-08-23 19:59:59','EVXBTC','4h','0.000044940000000','0.000047840000000','0.001471122614286','0.001566054870215','32.73526066502003','32.735260665020029','test'),('2019-08-24 07:59:59','2019-08-24 15:59:59','EVXBTC','4h','0.000048020000000','0.000048040000000','0.001471122614286','0.001471735326745','30.635622954727197','30.635622954727197','test'),('2019-08-29 19:59:59','2019-08-29 23:59:59','EVXBTC','4h','0.000049100000000','0.000048320000000','0.001471122614286','0.001447752438336','29.961764038411403','29.961764038411403','test'),('2019-08-30 03:59:59','2019-08-30 07:59:59','EVXBTC','4h','0.000049180000000','0.000048960000000','0.001471122614286','0.001464541748586','29.913025910654735','29.913025910654735','test'),('2019-09-17 19:59:59','2019-09-17 23:59:59','EVXBTC','4h','0.000040340000000','0.000039440000000','0.001471122614286','0.001438301336327','36.46808662087258','36.468086620872583','test'),('2019-09-20 07:59:59','2019-09-20 11:59:59','EVXBTC','4h','0.000039820000000','0.000039890000000','0.001471122614286','0.001473708716320','36.94431477363134','36.944314773631341','test'),('2019-09-21 03:59:59','2019-09-21 07:59:59','EVXBTC','4h','0.000040300000000','0.000039800000000','0.001471122614286','0.001452870472670','36.50428323290323','36.504283232903227','test'),('2019-09-27 11:59:59','2019-09-27 23:59:59','EVXBTC','4h','0.000040320000000','0.000039330000000','0.001471122614286','0.001435001300096','36.48617594955357','36.486175949553569','test'),('2019-09-30 11:59:59','2019-10-09 15:59:59','EVXBTC','4h','0.000040080000000','0.000043570000000','0.001471122614286','0.001599221863883','36.70465604505988','36.704656045059878','test'),('2019-10-12 11:59:59','2019-10-13 15:59:59','EVXBTC','4h','0.000043620000000','0.000043390000000','0.001471122614286','0.001463365663317','33.72587378005502','33.725873780055018','test'),('2019-10-14 23:59:59','2019-10-15 03:59:59','EVXBTC','4h','0.000043500000000','0.000044220000000','0.001471122614286','0.001495472229971','33.818910673241376','33.818910673241376','test'),('2019-10-22 03:59:59','2019-10-22 23:59:59','EVXBTC','4h','0.000042990000000','0.000042400000000','0.001471122614286','0.001450932748214','34.22011198618283','34.220111986182829','test'),('2019-10-24 07:59:59','2019-10-24 11:59:59','EVXBTC','4h','0.000042790000000','0.000043000000000','0.001471122614286','0.001478342426135','34.38005642173405','34.380056421734047','test'),('2019-10-25 11:59:59','2019-10-25 15:59:59','EVXBTC','4h','0.000043090000000','0.000041690000000','0.001471122614286','0.001423325639118','34.140696548758406','34.140696548758406','test'),('2019-11-01 23:59:59','2019-11-02 03:59:59','EVXBTC','4h','0.000039370000000','0.000038930000000','0.001471122614286','0.001454681315066','37.36658913604267','37.366589136042670','test'),('2019-11-06 15:59:59','2019-11-07 03:59:59','EVXBTC','4h','0.000038570000000','0.000037890000000','0.001471122614286','0.001445186306852','38.14162857884366','38.141628578843658','test'),('2019-11-07 11:59:59','2019-11-07 15:59:59','EVXBTC','4h','0.000038500000000','0.000038360000000','0.001471122614286','0.001465773077507','38.21097699444156','38.210976994441559','test'),('2019-11-08 23:59:59','2019-11-09 03:59:59','EVXBTC','4h','0.000038560000000','0.000038490000000','0.001471122614286','0.001468452007880','38.15152008003112','38.151520080031119','test'),('2019-11-11 03:59:59','2019-11-11 07:59:59','EVXBTC','4h','0.000038550000000','0.000038260000000','0.001471122614286','0.001460055803439','38.16141671299611','38.161416712996107','test'),('2019-11-13 15:59:59','2019-11-15 11:59:59','EVXBTC','4h','0.000038760000000','0.000038730000000','0.001471122614286','0.001469983974492','37.95465981130031','37.954659811300310','test'),('2019-11-26 03:59:59','2019-11-26 07:59:59','EVXBTC','4h','0.000038260000000','0.000038270000000','0.001471122614286','0.001471507120981','38.45066947950862','38.450669479508619','test'),('2019-11-28 23:59:59','2019-11-29 03:59:59','EVXBTC','4h','0.000038220000000','0.000038610000000','0.001471122614286','0.001486134069534','38.49091089183673','38.490910891836727','test'),('2019-12-03 07:59:59','2019-12-03 11:59:59','EVXBTC','4h','0.000038040000000','0.000038150000000','0.001471122614286','0.001475376649185','38.6730445395899','38.673044539589903','test'),('2019-12-07 03:59:59','2019-12-08 11:59:59','EVXBTC','4h','0.000038800000000','0.000038160000000','0.001471122614286','0.001446856674257','37.91553129603093','37.915531296030927','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','EVXBTC','4h','0.000037190000000','0.000036310000000','0.001471122614286','0.001436312506715','39.55694042178005','39.556940421780048','test'),('2019-12-30 07:59:59','2019-12-30 11:59:59','EVXBTC','4h','0.000032990000000','0.000032510000000','0.001471122614286','0.001449717980917','44.59298618629887','44.592986186298873','test'),('2019-12-30 15:59:59','2019-12-30 19:59:59','EVXBTC','4h','0.000032640000000','0.000032440000000','0.001471122614286','0.001462108382581','45.07115852591912','45.071158525919117','test'),('2019-12-30 23:59:59','2019-12-31 03:59:59','EVXBTC','4h','0.000032670000000','0.000032670000000','0.001471122614286','0.001471122614286','45.02977086887053','45.029770868870528','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:03:27
