-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 19:59:59','ARNETH','4h','0.001964900000000','0.001903900000000','0.072144500000000','0.069904785765179','36.71662680034608','36.716626800346077','test'),('2019-01-11 19:59:59','2019-01-12 03:59:59','ARNETH','4h','0.001954880000000','0.001935560000000','0.072144500000000','0.071431498823457','36.90482280242266','36.904822802422657','test'),('2019-01-12 19:59:59','2019-01-14 15:59:59','ARNETH','4h','0.002028740000000','0.001926760000000','0.072144500000000','0.068517965249367','35.56123505229847','35.561235052298471','test'),('2019-01-15 03:59:59','2019-01-15 11:59:59','ARNETH','4h','0.001981450000000','0.001989830000000','0.072144500000000','0.072449615400338','36.409952307653484','36.409952307653484','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','ARNETH','4h','0.002484470000000','0.002428710000000','0.072144500000000','0.070525330792885','29.038185206502796','29.038185206502796','test'),('2019-02-03 11:59:59','2019-02-04 15:59:59','ARNETH','4h','0.002481130000000','0.002464770000000','0.072144500000000','0.071668795776521','29.077275273766393','29.077275273766393','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','ARNETH','4h','0.002479760000000','0.002402130000000','0.072144500000000','0.069885984040794','29.093339678033356','29.093339678033356','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','ARNETH','4h','0.002432460000000','0.002400190000000','0.072144500000000','0.071187401829835','29.65906941943547','29.659069419435468','test'),('2019-02-26 07:59:59','2019-02-27 15:59:59','ARNETH','4h','0.002173580000000','0.002115230000000','0.072144500000000','0.070207772768888','33.19155494621776','33.191554946217757','test'),('2019-03-01 07:59:59','2019-03-21 15:59:59','ARNETH','4h','0.002138560000000','0.002930770000000','0.072144500000000','0.098869770436649','33.73508342061948','33.735083420619482','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','ARNETH','4h','0.002982200000000','0.003016650000000','0.075445480220978','0.076317016936695','25.298598424310324','25.298598424310324','test'),('2019-03-24 15:59:59','2019-03-25 03:59:59','ARNETH','4h','0.003044610000000','0.002904900000000','0.075663364399908','0.072191350368452','24.851578494423755','24.851578494423755','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','ARNETH','4h','0.003040000000000','0.002956400000000','0.075663364399908','0.073582621878911','24.889264605232896','24.889264605232896','test'),('2019-04-13 23:59:59','2019-04-14 03:59:59','ARNETH','4h','0.002866110000000','0.002847750000000','0.075663364399908','0.075178672824783','26.39932326390404','26.399323263904041','test'),('2019-04-16 19:59:59','2019-04-16 23:59:59','ARNETH','4h','0.002892860000000','0.002784630000000','0.075663364399908','0.072832585886948','26.155211244204008','26.155211244204008','test'),('2019-04-19 11:59:59','2019-04-21 07:59:59','ARNETH','4h','0.002879660000000','0.002773950000000','0.075663364399908','0.072885823214242','26.275103449680866','26.275103449680866','test'),('2019-04-22 11:59:59','2019-04-22 15:59:59','ARNETH','4h','0.002850910000000','0.002776350000000','0.075663364399908','0.073684536429310','26.540074712954112','26.540074712954112','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','ARNETH','4h','0.001816970000000','0.001759260000000','0.075663364399908','0.073260169652874','41.64260521632608','41.642605216326082','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','ARNETH','4h','0.001847530000000','0.001762100000000','0.075663364399908','0.072164681715089','40.953794742119484','40.953794742119484','test'),('2019-05-25 15:59:59','2019-05-30 07:59:59','ARNETH','4h','0.001867800000000','0.001933530000000','0.075663364399908','0.078326043991945','40.50935025158368','40.509350251583683','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','ARNETH','4h','0.002039420000000','0.002030760000000','0.075663364399908','0.075342074652969','37.1004326719891','37.100432671989097','test'),('2019-06-11 03:59:59','2019-06-11 07:59:59','ARNETH','4h','0.002014610000000','0.001977930000000','0.075663364399908','0.074285761684649','37.55732593400609','37.557325934006087','test'),('2019-06-12 11:59:59','2019-06-12 15:59:59','ARNETH','4h','0.002059300000000','0.002040000000000','0.075663364399908','0.074954238515909','36.74227378230855','36.742273782308551','test'),('2019-06-13 07:59:59','2019-06-13 15:59:59','ARNETH','4h','0.002027800000000','0.001968480000000','0.075663364399908','0.073449955396948','37.31303106810731','37.313031068107307','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','ARNETH','4h','0.001511530000000','0.001452560000000','0.075663364399908','0.072711475519990','50.057467863626925','50.057467863626925','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','ARNETH','4h','0.001505210000000','0.001411910000000','0.075663364399908','0.070973392968339','50.26764664060696','50.267646640606962','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','ARNETH','4h','0.001194050000000','0.001187030000000','0.075663364399908','0.075218528071373','63.36699836682551','63.366998366825513','test'),('2019-07-21 19:59:59','2019-07-21 23:59:59','ARNETH','4h','0.001192580000000','0.001193630000000','0.075663364399908','0.075729981761108','63.44510590476782','63.445105904767821','test'),('2019-07-28 23:59:59','2019-07-29 03:59:59','ARNETH','4h','0.001258530000000','0.001275050000000','0.075663364399908','0.076656553898678','60.12042970760174','60.120429707601737','test'),('2019-07-30 07:59:59','2019-07-30 11:59:59','ARNETH','4h','0.001258000000000','0.001254010000000','0.075663364399908','0.075423382822837','60.145758664473775','60.145758664473775','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','ARNETH','4h','0.001058250000000','0.001049000000000','0.075663364399908','0.075002002603830','71.49857254893269','71.498572548932685','test'),('2019-08-29 23:59:59','2019-08-31 23:59:59','ARNETH','4h','0.001113780000000','0.001211490000000','0.075663364399908','0.082301180966479','67.93385085017509','67.933850850175091','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','ARNETH','4h','0.001142180000000','0.001132210000000','0.075663364399908','0.075002904802413','66.24469383101437','66.244693831014374','test'),('2019-09-10 19:59:59','2019-09-10 23:59:59','ARNETH','4h','0.001053840000000','0.001056380000000','0.075663364399908','0.075845730741645','71.79777233726942','71.797772337269421','test'),('2019-09-22 03:59:59','2019-09-22 07:59:59','ARNETH','4h','0.000983760000000','0.000966410000000','0.075663364399908','0.074328933875859','76.91242213538669','76.912422135386691','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','ARNETH','4h','0.000991810000000','0.001007910000000','0.075663364399908','0.076891603847825','76.28816446689184','76.288164466891843','test'),('2019-09-27 07:59:59','2019-09-29 19:59:59','ARNETH','4h','0.001096640000000','0.001039740000000','0.075663364399908','0.071737513223264','68.99562700604392','68.995627006043918','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ARNETH','4h','0.001011770000000','0.000982520000000','0.075663364399908','0.073475956778910','74.78316652985166','74.783166529851655','test'),('2019-09-30 19:59:59','2019-10-09 15:59:59','ARNETH','4h','0.001031130000000','0.001094380000000','0.075663364399908','0.080304590819752','73.37907383153241','73.379073831532409','test'),('2019-10-13 11:59:59','2019-10-13 15:59:59','ARNETH','4h','0.001107860000000','0.001074060000000','0.075663364399908','0.073354930376912','68.29686458569495','68.296864585694948','test'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ARNETH','4h','0.001107470000000','0.001094310000000','0.075663364399908','0.074764261150608','68.32091560033952','68.320915600339518','test'),('2019-10-19 19:59:59','2019-10-19 23:59:59','ARNETH','4h','0.001068890000000','0.001046990000000','0.075663364399908','0.074113132214783','70.78685776825304','70.786857768253043','test'),('2019-10-20 11:59:59','2019-10-20 15:59:59','ARNETH','4h','0.001051200000000','0.001037100000000','0.075663364399908','0.074648473381987','71.97808637738585','71.978086377385850','test'),('2019-10-21 19:59:59','2019-10-23 15:59:59','ARNETH','4h','0.001080550000000','0.001054300000000','0.075663364399908','0.073825260364465','70.02301087400676','70.023010874006758','test'),('2019-10-24 11:59:59','2019-10-25 03:59:59','ARNETH','4h','0.001078400000000','0.001072650000000','0.075663364399908','0.075259929361611','70.16261535599779','70.162615355997787','test'),('2019-11-03 03:59:59','2019-11-03 07:59:59','ARNETH','4h','0.001018510000000','0.001012560000000','0.075663364399908','0.075221349085204','74.28828818559268','74.288288185592677','test'),('2019-11-07 15:59:59','2019-11-08 03:59:59','ARNETH','4h','0.001019310000000','0.001003880000000','0.075663364399908','0.074517995755736','74.22998342006652','74.229983420066517','test'),('2019-11-11 19:59:59','2019-11-11 23:59:59','ARNETH','4h','0.000995770000000','0.000985840000000','0.075663364399908','0.074908835534315','75.98478001939003','75.984780019390030','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','ARNETH','4h','0.000991330000000','0.000982630000000','0.075663364399908','0.074999336003431','76.32510304329337','76.325103043293367','test'),('2019-11-15 19:59:59','2019-11-16 07:59:59','ARNETH','4h','0.000998400000000','0.000980710000000','0.075663364399908','0.074322734475795','75.78461979157453','75.784619791574528','test'),('2019-11-16 11:59:59','2019-11-16 15:59:59','ARNETH','4h','0.000995020000000','0.000982700000000','0.075663364399908','0.074726526296747','76.0420538279713','76.042053827971301','test'),('2019-11-17 03:59:59','2019-11-18 15:59:59','ARNETH','4h','0.000990450000000','0.000984480000000','0.075663364399908','0.075207298686881','76.39291675491748','76.392916754917479','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','ARNETH','4h','0.000997090000000','0.000986750000000','0.075663364399908','0.074878721902345','75.88418738519894','75.884187385198942','test'),('2019-11-20 23:59:59','2019-11-21 03:59:59','ARNETH','4h','0.000989290000000','0.000987470000000','0.075663364399908','0.075524166264672','76.48249188802879','76.482491888028790','test'),('2019-11-23 15:59:59','2019-11-23 19:59:59','ARNETH','4h','0.000983840000000','0.000975700000000','0.075663364399908','0.075037348191769','76.90616807601644','76.906168076016442','test'),('2019-11-24 07:59:59','2019-11-24 11:59:59','ARNETH','4h','0.000982630000000','0.000975760000000','0.075663364399908','0.075134368426421','77.00086950317821','77.000869503178208','test'),('2019-11-24 19:59:59','2019-11-24 23:59:59','ARNETH','4h','0.000985950000000','0.000973280000000','0.075663364399908','0.074691048535060','76.74158365019322','76.741583650193220','test'),('2019-11-25 19:59:59','2019-12-02 15:59:59','ARNETH','4h','0.001010000000000','0.001042530000000','0.075663364399908','0.078100324047362','74.91422217812674','74.914222178126735','test'),('2019-12-03 07:59:59','2019-12-03 11:59:59','ARNETH','4h','0.001039130000000','0.001039890000000','0.075663364399908','0.075718703151502','72.81414683428252','72.814146834282525','test'),('2019-12-05 11:59:59','2019-12-06 11:59:59','ARNETH','4h','0.001081620000000','0.001066040000000','0.075663364399908','0.074573485128675','69.95374013045988','69.953740130459877','test'),('2019-12-10 07:59:59','2019-12-10 11:59:59','ARNETH','4h','0.001083530000000','0.001020190000000','0.075663364399908','0.071240305046600','69.83042869132188','69.830428691321885','test'),('2019-12-12 07:59:59','2019-12-12 15:59:59','ARNETH','4h','0.001086580000000','0.000989300000000','0.075663364399908','0.068889328352104','69.63441660982902','69.634416609829017','test'),('2019-12-16 03:59:59','2019-12-16 07:59:59','ARNETH','4h','0.001026650000000','0.001003480000000','0.075663364399908','0.073955752114177','73.69927862456339','73.699278624563391','test'),('2019-12-17 07:59:59','2019-12-17 11:59:59','ARNETH','4h','0.001034520000000','0.001011380000000','0.075663364399908','0.073970936750163','73.13861926295094','73.138619262950940','test'),('2019-12-18 11:59:59','2019-12-18 15:59:59','ARNETH','4h','0.001022130000000','0.001016790000000','0.075663364399908','0.075268069901267','74.0251870113469','74.025187011346901','test'),('2019-12-18 23:59:59','2019-12-20 03:59:59','ARNETH','4h','0.001045620000000','0.001032730000000','0.075663364399908','0.074730615631603','72.36220079943766','72.362200799437659','test'),('2019-12-23 07:59:59','2019-12-23 11:59:59','ARNETH','4h','0.001040370000000','0.001020170000000','0.075663364399908','0.074194271710886','72.72736084268865','72.727360842688654','test'),('2019-12-23 23:59:59','2019-12-24 03:59:59','ARNETH','4h','0.001036140000000','0.001037060000000','0.075663364399908','0.075730546725895','73.0242673769066','73.024267376906593','test'),('2019-12-25 03:59:59','2019-12-25 07:59:59','ARNETH','4h','0.001040800000000','0.001040990000000','0.075663364399908','0.075677176889566','72.69731398915066','72.697313989150658','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:57:11
