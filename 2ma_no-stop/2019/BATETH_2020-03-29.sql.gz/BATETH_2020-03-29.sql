-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 19:59:59','BATETH','4h','0.000963000000000','0.000967160000000','0.072144500000000','0.072456152253375','74.91640706126688','74.916407061266881','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','BATETH','4h','0.001004180000000','0.001030120000000','0.072222413063344','0.074088064037137','71.92178002284825','71.921780022848253','test'),('2019-02-06 23:59:59','2019-02-08 11:59:59','BATETH','4h','0.001117500000000','0.001045980000000','0.072688825806792','0.068036740955157','65.04592913359464','65.045929133594640','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','BATETH','4h','0.001079190000000','0.001055870000000','0.072688825806792','0.071118107566432','67.35498457805576','67.354984578055763','test'),('2019-02-14 11:59:59','2019-02-17 15:59:59','BATETH','4h','0.001052000000000','0.001036360000000','0.072688825806792','0.071608166837573','69.0958420216654','69.095842021665405','test'),('2019-02-25 23:59:59','2019-03-16 07:59:59','BATETH','4h','0.001081560000000','0.001402780000000','0.072688825806792','0.094277183942871','67.2073909970709','67.207390997070902','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','BATETH','4h','0.001396580000000','0.001393260000000','0.076260049825508','0.076078761703509','54.604856023649376','54.604856023649376','test'),('2019-03-18 11:59:59','2019-03-19 03:59:59','BATETH','4h','0.001410000000000','0.001406240000000','0.076260049825508','0.076056689692640','54.085141720218445','54.085141720218445','test'),('2019-03-21 03:59:59','2019-04-03 19:59:59','BATETH','4h','0.001402330000000','0.001735270000000','0.076260049825508','0.094365646217873','54.38095870836965','54.380958708369647','test'),('2019-04-04 03:59:59','2019-04-04 11:59:59','BATETH','4h','0.001831660000000','0.001795180000000','0.080690286859883','0.079083230056410','44.05309220045354','44.053092200453541','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','BATETH','4h','0.001826250000000','0.001785780000000','0.080690286859883','0.078902176847990','44.183593078649146','44.183593078649146','test'),('2019-04-05 15:59:59','2019-04-05 19:59:59','BATETH','4h','0.001798000000000','0.001911530000000','0.080690286859883','0.085785263649206','44.8778013681218','44.877801368121801','test'),('2019-04-06 23:59:59','2019-04-07 07:59:59','BATETH','4h','0.001829790000000','0.001820710000000','0.081115239353372','0.080712719734548','44.330354496074406','44.330354496074406','test'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BATETH','4h','0.001743100000000','0.001750990000000','0.081115239353372','0.081482400869348','46.53504638481556','46.535046384815558','test'),('2019-05-01 15:59:59','2019-05-01 19:59:59','BATETH','4h','0.002442550000000','0.002408980000000','0.081115239353372','0.080000405026503','33.209244172431276','33.209244172431276','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','BATETH','4h','0.001435170000000','0.001358980000000','0.081115239353372','0.076809010762798','56.51960349879945','56.519603498799448','test'),('2019-06-04 11:59:59','2019-06-04 19:59:59','BATETH','4h','0.001410220000000','0.001365330000000','0.081115239353372','0.078533186131483','57.5195638647672','57.519563864767200','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','BATETH','4h','0.001406320000000','0.001373840000000','0.081115239353372','0.079241822937338','57.679076848350306','57.679076848350306','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','BATETH','4h','0.001380000000000','0.001364780000000','0.081115239353372','0.080220620554127','58.77915895171885','58.779158951718848','test'),('2019-06-08 03:59:59','2019-06-08 15:59:59','BATETH','4h','0.001385960000000','0.001365990000000','0.081115239353372','0.079946467289325','58.526392791546655','58.526392791546655','test'),('2019-06-17 15:59:59','2019-06-17 23:59:59','BATETH','4h','0.001339780000000','0.001260740000000','0.081115239353372','0.076329865248302','60.54370072203795','60.543700722037947','test'),('2019-06-18 23:59:59','2019-06-19 07:59:59','BATETH','4h','0.001324400000000','0.001296180000000','0.081115239353372','0.079386855138216','61.2467829608668','61.246782960866803','test'),('2019-07-01 03:59:59','2019-07-03 03:59:59','BATETH','4h','0.001098820000000','0.001052960000000','0.081115239353372','0.077729839673037','73.82031575087095','73.820315750870947','test'),('2019-07-10 19:59:59','2019-07-11 07:59:59','BATETH','4h','0.001053980000000','0.001010940000000','0.081115239353372','0.077802842626898','76.96089048499213','76.960890484992134','test'),('2019-07-16 19:59:59','2019-07-16 23:59:59','BATETH','4h','0.001065550000000','0.001026810000000','0.081115239353372','0.078166147924017','76.12523049446014','76.125230494460141','test'),('2019-07-17 19:59:59','2019-07-17 23:59:59','BATETH','4h','0.001048320000000','0.001024640000000','0.081115239353372','0.079282965936965','77.37641116583869','77.376411165838689','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','BATETH','4h','0.001051200000000','0.001023950000000','0.081115239353372','0.079012508881169','77.16442099826104','77.164420998261036','test'),('2019-07-19 03:59:59','2019-07-23 19:59:59','BATETH','4h','0.001119500000000','0.001089350000000','0.081115239353372','0.078930670825901','72.45666757782224','72.456667577822245','test'),('2019-07-26 11:59:59','2019-07-26 19:59:59','BATETH','4h','0.001100260000000','0.001146330000000','0.081115239353372','0.084511690262257','73.72370108280951','73.723701082809512','test'),('2019-08-15 23:59:59','2019-08-16 03:59:59','BATETH','4h','0.000997290000000','0.000979570000000','0.081115239353372','0.079673971476083','81.33565898923283','81.335658989232826','test'),('2019-08-16 11:59:59','2019-08-16 19:59:59','BATETH','4h','0.000994420000000','0.000974030000000','0.081115239353372','0.079452018852562','81.5704021976348','81.570402197634806','test'),('2019-08-21 19:59:59','2019-08-22 03:59:59','BATETH','4h','0.000980000000000','0.000976100000000','0.081115239353372','0.080792433809007','82.77065240140001','82.770652401400014','test'),('2019-08-26 15:59:59','2019-08-26 23:59:59','BATETH','4h','0.001003830000000','0.000996990000000','0.081115239353372','0.080562528000676','80.80575331816344','80.805753318163440','test'),('2019-08-27 23:59:59','2019-08-29 03:59:59','BATETH','4h','0.001007460000000','0.000994970000000','0.081115239353372','0.080109611993950','80.51460043413337','80.514600434133371','test'),('2019-08-29 11:59:59','2019-08-29 19:59:59','BATETH','4h','0.001008610000000','0.001013430000000','0.081115239353372','0.081502877244810','80.42279905352117','80.422799053521175','test'),('2019-09-10 19:59:59','2019-09-10 23:59:59','BATETH','4h','0.000994880000000','0.000961090000000','0.081115239353372','0.078360249869464','81.53268670932374','81.532686709323741','test'),('2019-09-12 07:59:59','2019-09-12 11:59:59','BATETH','4h','0.000998000000000','0.000978600000000','0.081115239353372','0.079538450131473','81.27779494325853','81.277794943258527','test'),('2019-09-20 15:59:59','2019-09-22 03:59:59','BATETH','4h','0.000964230000000','0.000932860000000','0.081115239353372','0.078476257929318','84.12436799661077','84.124367996610772','test'),('2019-09-22 11:59:59','2019-09-22 15:59:59','BATETH','4h','0.000955060000000','0.000932340000000','0.081115239353372','0.079185582328569','84.9320873592989','84.932087359298905','test'),('2019-09-23 07:59:59','2019-09-23 11:59:59','BATETH','4h','0.000965790000000','0.000937910000000','0.081115239353372','0.078773640379297','83.98848544028412','83.988485440284123','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','BATETH','4h','0.000951570000000','0.000928900000000','0.081115239353372','0.079182767253431','85.24358623471947','85.243586234719473','test'),('2019-09-25 23:59:59','2019-09-26 19:59:59','BATETH','4h','0.000946270000000','0.000940000000000','0.081115239353372','0.080577768493316','85.7210303120378','85.721030312037797','test'),('2019-09-27 15:59:59','2019-09-27 19:59:59','BATETH','4h','0.000949930000000','0.000976770000000','0.081115239353372','0.083407127202208','85.39075442755993','85.390754427559926','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','BATETH','4h','0.000946060000000','0.000938700000000','0.081115239353372','0.080484192525855','85.7400580865611','85.740058086561106','test'),('2019-09-28 23:59:59','2019-09-29 03:59:59','BATETH','4h','0.000948780000000','0.000948810000000','0.081115239353372','0.081117804181025','85.49425509957209','85.494255099572086','test'),('2019-09-30 19:59:59','2019-10-01 03:59:59','BATETH','4h','0.000950930000000','0.000941630000000','0.081115239353372','0.080321940450207','85.30095732953215','85.300957329532153','test'),('2019-10-01 15:59:59','2019-10-01 19:59:59','BATETH','4h','0.000948820000000','0.000931010000000','0.081115239353372','0.079592650861473','85.49065086462343','85.490650864623433','test'),('2019-10-02 11:59:59','2019-10-02 15:59:59','BATETH','4h','0.000951330000000','0.000953810000000','0.081115239353372','0.081326696779918','85.2650913493446','85.265091349344601','test'),('2019-10-03 07:59:59','2019-10-09 15:59:59','BATETH','4h','0.000968700000000','0.001052510000000','0.081115239353372','0.088133168753812','83.7361818451244','83.736181845124406','test'),('2019-10-11 15:59:59','2019-10-11 23:59:59','BATETH','4h','0.001057180000000','0.001051620000000','0.081115239353372','0.080688632029355','76.7279359743582','76.727935974358203','test'),('2019-10-27 07:59:59','2019-10-27 11:59:59','BATETH','4h','0.001358370000000','0.001307410000000','0.081115239353372','0.078072156395527','59.71512868612528','59.715128686125283','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','BATETH','4h','0.001328990000000','0.001319670000000','0.081115239353372','0.080546390806149','61.03525184792362','61.035251847923618','test'),('2019-10-31 07:59:59','2019-10-31 11:59:59','BATETH','4h','0.001315210000000','0.001294470000000','0.081115239353372','0.079836105173896','61.67474346558497','61.674743465584967','test'),('2019-11-01 15:59:59','2019-11-01 23:59:59','BATETH','4h','0.001306410000000','0.001286000000000','0.081115239353372','0.079847978665531','62.09018558750469','62.090185587504692','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','BATETH','4h','0.001306800000000','0.001280160000000','0.081115239353372','0.079461650451953','62.07165545865626','62.071655458656259','test'),('2019-11-04 15:59:59','2019-11-04 23:59:59','BATETH','4h','0.001299360000000','0.001304910000000','0.081115239353372','0.081461709599040','62.427071291537374','62.427071291537374','test'),('2019-11-09 11:59:59','2019-11-09 19:59:59','BATETH','4h','0.001323770000000','0.001324120000000','0.081115239353372','0.081136685929268','61.27593113106658','61.275931131066578','test'),('2019-11-13 11:59:59','2019-11-13 15:59:59','BATETH','4h','0.001314540000000','0.001316080000000','0.081115239353372','0.081210266867639','61.706178095282006','61.706178095282006','test'),('2019-11-22 19:59:59','2019-11-25 23:59:59','BATETH','4h','0.001418490000000','0.001401620000000','0.081115239353372','0.080150541619943','57.18421656365008','57.184216563650082','test'),('2019-11-26 11:59:59','2019-11-26 15:59:59','BATETH','4h','0.001416660000000','0.001421970000000','0.081115239353372','0.081419279787186','57.25808546395889','57.258085463958892','test'),('2019-12-13 15:59:59','2019-12-14 15:59:59','BATETH','4h','0.001307590000000','0.001266660000000','0.081115239353372','0.078576181432515','62.03415394226937','62.034153942269370','test'),('2019-12-15 15:59:59','2019-12-16 11:59:59','BATETH','4h','0.001289270000000','0.001279430000000','0.081115239353372','0.080496149515528','62.915633927239455','62.915633927239455','test'),('2019-12-18 03:59:59','2019-12-18 07:59:59','BATETH','4h','0.001283450000000','0.001261200000000','0.081115239353372','0.079709018561278','63.20093447611672','63.200934476116721','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','BATETH','4h','0.001290320000000','0.001268550000000','0.081115239353372','0.079746680576694','62.86443622773576','62.864436227735759','test'),('2019-12-19 03:59:59','2019-12-19 11:59:59','BATETH','4h','0.001281460000000','0.001278080000000','0.081115239353372','0.080901288462190','63.299080231432896','63.299080231432896','test'),('2019-12-24 15:59:59','2019-12-24 19:59:59','BATETH','4h','0.001303180000000','0.001301840000000','0.081115239353372','0.081031832287016','62.24407936998113','62.244079369981129','test'),('2019-12-26 03:59:59','2019-12-26 07:59:59','BATETH','4h','0.001298390000000','0.001296810000000','0.081115239353372','0.081016530892757','62.47370925020372','62.473709250203719','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','BATETH','4h','0.001335440000000','0.001283070000000','0.081115239353372','0.077934261484702','60.74045958887857','60.740459588878572','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:59:41
