-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-10 15:59:59','MDAETH','4h','0.005887700000000','0.005654800000000','0.072144500000000','0.069290676936665','12.253426635188614','12.253426635188614','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','MDAETH','4h','0.005656900000000','0.005584200000000','0.072144500000000','0.071217330499037','12.75336314942813','12.753363149428131','test'),('2019-01-17 03:59:59','2019-01-20 15:59:59','MDAETH','4h','0.005848500000000','0.005899800000000','0.072144500000000','0.072777314029238','12.335556125502265','12.335556125502265','test'),('2019-01-31 15:59:59','2019-02-06 23:59:59','MDAETH','4h','0.006709000000000','0.006697800000000','0.072144500000000','0.072024062021166','10.753390967357282','10.753390967357282','test'),('2019-02-23 07:59:59','2019-02-23 19:59:59','MDAETH','4h','0.006221500000000','0.005554200000000','0.072144500000000','0.064406490701599','11.59599774973881','11.595997749738810','test'),('2019-02-24 23:59:59','2019-03-02 15:59:59','MDAETH','4h','0.006162200000000','0.006436200000000','0.072144500000000','0.075352379166531','11.707588199019831','11.707588199019831','test'),('2019-03-07 19:59:59','2019-03-09 03:59:59','MDAETH','4h','0.006495600000000','0.006344300000000','0.072144500000000','0.070464060494796','11.106672208879857','11.106672208879857','test'),('2019-03-22 19:59:59','2019-03-28 03:59:59','MDAETH','4h','0.007632700000000','0.008177000000000','0.072144500000000','0.077289239260026','9.452028770946061','9.452028770946061','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','MDAETH','4h','0.004172600000000','0.004070200000000','0.072144500000000','0.070373997962901','17.29005895604659','17.290058956046590','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','MDAETH','4h','0.003888800000000','0.003772500000000','0.072144500000000','0.069986917879552','18.551866899814854','18.551866899814854','test'),('2019-06-02 03:59:59','2019-06-02 07:59:59','MDAETH','4h','0.003873000000000','0.003851000000000','0.072144500000000','0.071734693906532','18.627549703072553','18.627549703072553','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','MDAETH','4h','0.003863600000000','0.004003200000000','0.072144500000000','0.074751232632778','18.672869862304587','18.672869862304587','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','MDAETH','4h','0.003031800000000','0.002891500000000','0.072144500000000','0.068805931047563','23.795929810673528','23.795929810673528','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','MDAETH','4h','0.002951500000000','0.002941000000000','0.072144500000000','0.071887844994071','24.443333898017958','24.443333898017958','test'),('2019-07-08 11:59:59','2019-07-08 19:59:59','MDAETH','4h','0.003124000000000','0.002949200000000','0.072144500000000','0.068107733482714','23.09362996158771','23.093629961587709','test'),('2019-07-11 03:59:59','2019-07-11 07:59:59','MDAETH','4h','0.002907700000000','0.002869600000000','0.072144500000000','0.071199180520686','24.811534890119336','24.811534890119336','test'),('2019-07-13 19:59:59','2019-07-13 23:59:59','MDAETH','4h','0.002919100000000','0.002760100000000','0.072144500000000','0.068214872546333','24.714638073378783','24.714638073378783','test'),('2019-07-14 15:59:59','2019-07-14 23:59:59','MDAETH','4h','0.002881100000000','0.002850700000000','0.072144500000000','0.071383265471521','25.04060948943112','25.040609489431120','test'),('2019-07-15 19:59:59','2019-07-18 11:59:59','MDAETH','4h','0.002959900000000','0.002966800000000','0.072144500000000','0.072312680360823','24.373965336666778','24.373965336666778','test'),('2019-07-20 19:59:59','2019-07-20 23:59:59','MDAETH','4h','0.002930000000000','0.002931600000000','0.072144500000000','0.072183896313993','24.62269624573379','24.622696245733788','test'),('2019-07-25 15:59:59','2019-07-25 19:59:59','MDAETH','4h','0.003035300000000','0.002990700000000','0.072144500000000','0.071084425312160','23.768490758738842','23.768490758738842','test'),('2019-07-30 19:59:59','2019-07-31 15:59:59','MDAETH','4h','0.003187500000000','0.003116500000000','0.072144500000000','0.070537516627451','22.63356862745098','22.633568627450980','test'),('2019-08-01 19:59:59','2019-08-03 07:59:59','MDAETH','4h','0.003181000000000','0.003117200000000','0.072144500000000','0.070697527632820','22.67981766740019','22.679817667400190','test'),('2019-08-09 11:59:59','2019-08-09 15:59:59','MDAETH','4h','0.003191700000000','0.003165200000000','0.072144500000000','0.071545499702353','22.603784816868753','22.603784816868753','test'),('2019-08-10 11:59:59','2019-08-10 15:59:59','MDAETH','4h','0.003115600000000','0.003136700000000','0.072144500000000','0.072633089340737','23.155892925921172','23.155892925921172','test'),('2019-08-13 03:59:59','2019-08-13 07:59:59','MDAETH','4h','0.003091100000000','0.003063500000000','0.072144500000000','0.071500331839798','23.33942609427065','23.339426094270650','test'),('2019-08-14 19:59:59','2019-08-14 23:59:59','MDAETH','4h','0.003215700000000','0.003133500000000','0.072144500000000','0.070300336085456','22.435084118543397','22.435084118543397','test'),('2019-08-15 11:59:59','2019-08-17 15:59:59','MDAETH','4h','0.003298300000000','0.003093400000000','0.072144500000000','0.067662673589425','21.873237728526817','21.873237728526817','test'),('2019-08-20 19:59:59','2019-08-26 11:59:59','MDAETH','4h','0.003568200000000','0.003328800000000','0.072144500000000','0.067304134185304','20.21873773891598','20.218737738915980','test'),('2019-09-04 19:59:59','2019-09-04 23:59:59','MDAETH','4h','0.003475900000000','0.003213500000000','0.072144500000000','0.066698222258983','20.755631634972236','20.755631634972236','test'),('2019-09-09 19:59:59','2019-09-12 23:59:59','MDAETH','4h','0.003538600000000','0.003490100000000','0.072144500000000','0.071155688535014','20.38786525744645','20.387865257446450','test'),('2019-09-24 19:59:59','2019-10-07 23:59:59','MDAETH','4h','0.003246700000000','0.005117600000000','0.072144500000000','0.113717526473034','22.220870422274928','22.220870422274928','test'),('2019-10-09 11:59:59','2019-10-09 15:59:59','MDAETH','4h','0.005404400000000','0.004919800000000','0.072144500000000','0.065675470190956','13.349215454074457','13.349215454074457','test'),('2019-10-11 19:59:59','2019-10-15 19:59:59','MDAETH','4h','0.005774200000000','0.004939600000000','0.072144500000000','0.061716769803609','12.494284922586678','12.494284922586678','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','MDAETH','4h','0.004694400000000','0.004182000000000','0.072144500000000','0.064269831927403','15.368204669393322','15.368204669393322','test'),('2019-10-27 23:59:59','2019-10-28 03:59:59','MDAETH','4h','0.004637300000000','0.003974900000000','0.072144500000000','0.061839254102603','15.557436439307358','15.557436439307358','test'),('2019-11-09 15:59:59','2019-11-09 19:59:59','MDAETH','4h','0.004012900000000','0.003981000000000','0.072144500000000','0.071570997159162','17.97814548082434','17.978145480824342','test'),('2019-11-09 23:59:59','2019-11-10 19:59:59','MDAETH','4h','0.004107700000000','0.004106300000000','0.072144500000000','0.072119911471140','17.563234900309176','17.563234900309176','test'),('2019-11-22 15:59:59','2019-11-25 11:59:59','MDAETH','4h','0.003867400000000','0.003820100000000','0.072144500000000','0.071262141089621','18.654522418162074','18.654522418162074','test'),('2019-12-09 15:59:59','2019-12-09 23:59:59','MDAETH','4h','0.003756300000000','0.003637000000000','0.072144500000000','0.069853192370151','19.206266805100764','19.206266805100764','test'),('2019-12-12 23:59:59','2019-12-13 15:59:59','MDAETH','4h','0.003787200000000','0.003708800000000','0.072144500000000','0.070651014364174','19.049561681453316','19.049561681453316','test'),('2019-12-16 19:59:59','2019-12-22 11:59:59','MDAETH','4h','0.003712800000000','0.003806900000000','0.072144500000000','0.073972984553437','19.43129174746822','19.431291747468219','test'),('2019-12-23 07:59:59','2019-12-23 11:59:59','MDAETH','4h','0.003826200000000','0.003760900000000','0.072144500000000','0.070913242917255','18.855391772515812','18.855391772515812','test'),('2019-12-24 03:59:59','2019-12-24 07:59:59','MDAETH','4h','0.003808600000000','0.003826200000000','0.072144500000000','0.072477888436696','18.942524812266974','18.942524812266974','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:42:05
