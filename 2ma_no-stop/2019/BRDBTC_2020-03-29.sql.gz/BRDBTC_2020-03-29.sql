-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-01 23:59:59','BRDBTC','4h','0.000053730000000','0.000053190000000','0.001467500000000','0.001452751256281','27.31248836776475','27.312488367764750','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','BRDBTC','4h','0.000054640000000','0.000054330000000','0.001467500000000','0.001459174139824','26.85761346998536','26.857613469985360','test'),('2019-01-09 19:59:59','2019-01-10 07:59:59','BRDBTC','4h','0.000054790000000','0.000053010000000','0.001467500000000','0.001419824329257','26.784084686986677','26.784084686986677','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','BRDBTC','4h','0.000053100000000','0.000052900000000','0.001467500000000','0.001461972693032','27.63653483992467','27.636534839924671','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','BRDBTC','4h','0.000053030000000','0.000053500000000','0.001467500000000','0.001480506317179','27.673015274372997','27.673015274372997','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','BRDBTC','4h','0.000057610000000','0.000057820000000','0.001467500000000','0.001472849331713','25.473008158305852','25.473008158305852','test'),('2019-02-10 07:59:59','2019-02-10 11:59:59','BRDBTC','4h','0.000055270000000','0.000055660000000','0.001467500000000','0.001477855075086','26.5514745793378','26.551474579337800','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','BRDBTC','4h','0.000054610000000','0.000054500000000','0.001467500000000','0.001464544039553','26.87236769822377','26.872367698223769','test'),('2019-02-17 11:59:59','2019-02-17 15:59:59','BRDBTC','4h','0.000054620000000','0.000054730000000','0.001467500000000','0.001470455419260','26.867447821310876','26.867447821310876','test'),('2019-02-22 19:59:59','2019-02-22 23:59:59','BRDBTC','4h','0.000055520000000','0.000056300000000','0.001467500000000','0.001488116894813','26.43191642651297','26.431916426512970','test'),('2019-02-25 11:59:59','2019-02-25 19:59:59','BRDBTC','4h','0.000056400000000','0.000055470000000','0.001467500000000','0.001443301861702','26.01950354609929','26.019503546099291','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','BRDBTC','4h','0.000055610000000','0.000055960000000','0.001467500000000','0.001476736198525','26.389138644128757','26.389138644128757','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','BRDBTC','4h','0.000056910000000','0.000056240000000','0.001467500000000','0.001450223159374','25.786329291864348','25.786329291864348','test'),('2019-03-05 11:59:59','2019-03-05 15:59:59','BRDBTC','4h','0.000056790000000','0.000056880000000','0.001467500000000','0.001469825673534','25.84081704525445','25.840817045254450','test'),('2019-03-06 07:59:59','2019-03-07 03:59:59','BRDBTC','4h','0.000057040000000','0.000056790000000','0.001467500000000','0.001461068110098','25.727559607293127','25.727559607293127','test'),('2019-03-07 19:59:59','2019-03-08 07:59:59','BRDBTC','4h','0.000057140000000','0.000056810000000','0.001467500000000','0.001459024763738','25.682534126706337','25.682534126706337','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','BRDBTC','4h','0.000058360000000','0.000087000000000','0.001467500000000','0.002187671350240','25.14564770390679','25.145647703906789','test'),('2019-03-20 15:59:59','2019-03-21 07:59:59','BRDBTC','4h','0.000062920000000','0.000062880000000','0.001629600153302','0.001628564171005','25.89955742692705','25.899557426927050','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','BRDBTC','4h','0.000063060000000','0.000063190000000','0.001629600153302','0.001632959620792','25.84205761658738','25.842057616587379','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','BRDBTC','4h','0.000066020000000','0.000063610000000','0.001630181024600','0.001570672750300','24.692230000007573','24.692230000007573','test'),('2019-04-05 19:59:59','2019-04-05 23:59:59','BRDBTC','4h','0.000067170000000','0.000066610000000','0.001630181024600','0.001616590115358','24.26948078904273','24.269480789042731','test'),('2019-04-07 11:59:59','2019-04-07 23:59:59','BRDBTC','4h','0.000067920000000','0.000066050000000','0.001630181024600','0.001585298243151','24.001487405771496','24.001487405771496','test'),('2019-04-12 23:59:59','2019-04-13 03:59:59','BRDBTC','4h','0.000067630000000','0.000062060000000','0.001630181024600','0.001495919479324','24.10440669229632','24.104406692296319','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','BRDBTC','4h','0.000061910000000','0.000063220000000','0.001630181024600','0.001664675244310','26.331465427233084','26.331465427233084','test'),('2019-04-29 11:59:59','2019-05-07 23:59:59','BRDBTC','4h','0.000058900000000','0.000061080000000','0.001630181024600','0.001690517096478','27.677097191850596','27.677097191850596','test'),('2019-05-08 07:59:59','2019-05-09 07:59:59','BRDBTC','4h','0.000063150000000','0.000064800000000','0.001630181024600','0.001672774828093','25.8144263594616','25.814426359461599','test'),('2019-05-10 11:59:59','2019-05-10 15:59:59','BRDBTC','4h','0.000063360000000','0.000064180000000','0.001630181024600','0.001651278695689','25.728867181186867','25.728867181186867','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','BRDBTC','4h','0.000063990000000','0.000062230000000','0.001630181024600','0.001585344040645','25.475559065478983','25.475559065478983','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','BRDBTC','4h','0.000065870000000','0.000061810000000','0.001630181024600','0.001529702279194','24.74845945954152','24.748459459541522','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','BRDBTC','4h','0.000061970000000','0.000059440000000','0.001630181024600','0.001563626917899','26.305971027916733','26.305971027916733','test'),('2019-05-26 11:59:59','2019-05-26 19:59:59','BRDBTC','4h','0.000060820000000','0.000058810000000','0.001630181024600','0.001576306248877','26.803371006247946','26.803371006247946','test'),('2019-06-09 11:59:59','2019-06-09 15:59:59','BRDBTC','4h','0.000056560000000','0.000056010000000','0.001630181024600','0.001614328839955','28.822153900282885','28.822153900282885','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','BRDBTC','4h','0.000063420000000','0.000056020000000','0.001630181024600','0.001439967533871','25.704525774203724','25.704525774203724','test'),('2019-07-02 07:59:59','2019-07-02 15:59:59','BRDBTC','4h','0.000037210000000','0.000034480000000','0.001630181024600','0.001510578923091','43.810293593120136','43.810293593120136','test'),('2019-07-08 23:59:59','2019-07-09 03:59:59','BRDBTC','4h','0.000033840000000','0.000029720000000','0.001630181024600','0.001431707448319','48.173198126477544','48.173198126477544','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','BRDBTC','4h','0.000030450000000','0.000028550000000','0.001630181024600','0.001528462011571','53.53632264696223','53.536322646962233','test'),('2019-07-29 03:59:59','2019-07-29 23:59:59','BRDBTC','4h','0.000027100000000','0.000027020000000','0.001630181024600','0.001625368682092','60.154281350553504','60.154281350553504','test'),('2019-07-30 11:59:59','2019-07-30 15:59:59','BRDBTC','4h','0.000027020000000','0.000027080000000','0.001630181024600','0.001633800967660','60.33238433012584','60.332384330125841','test'),('2019-08-12 11:59:59','2019-08-27 23:59:59','BRDBTC','4h','0.000023340000000','0.000028590000000','0.001630181024600','0.001996866987717','69.84494535561268','69.844945355612680','test'),('2019-09-07 19:59:59','2019-09-07 23:59:59','BRDBTC','4h','0.000028470000000','0.000027000000000','0.001630181024600','0.001546009401623','57.25960746750966','57.259607467509660','test'),('2019-09-20 03:59:59','2019-09-22 07:59:59','BRDBTC','4h','0.000022840000000','0.000022230000000','0.001630181024600','0.001586642914924','71.37395028896672','71.373950288966725','test'),('2019-09-22 23:59:59','2019-09-23 03:59:59','BRDBTC','4h','0.000022520000000','0.000022510000000','0.001630181024600','0.001629457143150','72.38814496447603','72.388144964476027','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','BRDBTC','4h','0.000022690000000','0.000022360000000','0.001630181024600','0.001606471913180','71.84579218157779','71.845792181577792','test'),('2019-09-26 07:59:59','2019-10-25 15:59:59','BRDBTC','4h','0.000023160000000','0.000040460000000','0.001630181024600','0.002847889648330','70.38778171848014','70.387781718480142','test'),('2019-11-02 03:59:59','2019-11-04 23:59:59','BRDBTC','4h','0.000037010000000','0.000038410000000','0.001741614209551','0.001807495319883','47.05793595111455','47.057935951114551','test'),('2019-11-10 07:59:59','2019-11-11 03:59:59','BRDBTC','4h','0.000038030000000','0.000037780000000','0.001758084487134','0.001746527265946','46.2288847523994','46.228884752399402','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','BRDBTC','4h','0.000037930000000','0.000037870000000','0.001758084487134','0.001755303441280','46.35076422710256','46.350764227102559','test'),('2019-11-12 23:59:59','2019-11-15 03:59:59','BRDBTC','4h','0.000038010000000','0.000038230000000','0.001758084487134','0.001768260193189','46.253209343172855','46.253209343172855','test'),('2019-12-01 11:59:59','2019-12-02 03:59:59','BRDBTC','4h','0.000036070000000','0.000035900000000','0.001758084487134','0.001749798533078','48.74090621386194','48.740906213861940','test'),('2019-12-02 15:59:59','2019-12-03 03:59:59','BRDBTC','4h','0.000046840000000','0.000036530000000','0.001758084487134','0.001371110724061','37.5338276501708','37.533827650170799','test'),('2019-12-03 15:59:59','2019-12-03 19:59:59','BRDBTC','4h','0.000036570000000','0.000036700000000','0.001758084487134','0.001764334172213','48.07450060525021','48.074500605250208','test'),('2019-12-09 11:59:59','2019-12-09 19:59:59','BRDBTC','4h','0.000035640000000','0.000035100000000','0.001758084487134','0.001731446843390','49.32896989713805','49.328969897138052','test'),('2019-12-12 11:59:59','2019-12-13 03:59:59','BRDBTC','4h','0.000035010000000','0.000034830000000','0.001758084487134','0.001749045492342','50.21663773590403','50.216637735904030','test'),('2019-12-13 15:59:59','2019-12-15 07:59:59','BRDBTC','4h','0.000039210000000','0.000034990000000','0.001758084487134','0.001568869579312','44.837655882019895','44.837655882019895','test'),('2019-12-15 19:59:59','2019-12-15 23:59:59','BRDBTC','4h','0.000035350000000','0.000035030000000','0.001758084487134','0.001742169719499','49.73364885810467','49.733648858104672','test'),('2019-12-16 11:59:59','2019-12-16 19:59:59','BRDBTC','4h','0.000036320000000','0.000034110000000','0.001758084487134','0.001651108531281','48.40540988805066','48.405409888050663','test'),('2019-12-18 03:59:59','2019-12-18 07:59:59','BRDBTC','4h','0.000035200000000','0.000035800000000','0.001758084487134','0.001788051836347','49.94558202085227','49.945582020852271','test'),('2019-12-20 07:59:59','2019-12-20 19:59:59','BRDBTC','4h','0.000035050000000','0.000034720000000','0.001758084487134','0.001741531908510','50.15932916216833','50.159329162168333','test'),('2019-12-23 11:59:59','2019-12-23 19:59:59','BRDBTC','4h','0.000036630000000','0.000034810000000','0.001758084487134','0.001670732213954','47.995754494512695','47.995754494512695','test'),('2019-12-27 11:59:59','2019-12-28 03:59:59','BRDBTC','4h','0.000035330000000','0.000034710000000','0.001758084487134','0.001727232169500','49.76180263611661','49.761802636116613','test'),('2019-12-28 11:59:59','2019-12-29 19:59:59','BRDBTC','4h','0.000035380000000','0.000034630000000','0.001758084487134','0.001720815878730','49.691477872639915','49.691477872639915','test'),('2019-12-31 07:59:59','2019-12-31 15:59:59','BRDBTC','4h','0.000034940000000','0.000034710000000','0.001758084487134','0.001746511521134','50.31724347836291','50.317243478362911','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  0:29:36
