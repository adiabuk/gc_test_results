-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-24 07:59:59','2019-01-25 03:59:59','PIVXBNB','4h','0.127140000000000','0.120000000000000','0.711908500000000','0.671928739971685','5.599406166430707','5.599406166430707','test'),('2019-01-30 03:59:59','2019-01-30 07:59:59','PIVXBNB','4h','0.118870000000000','0.114020000000000','0.711908500000000','0.682862010347438','5.988966938672499','5.988966938672499','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','PIVXBNB','4h','0.084190000000000','0.080170000000000','0.711908500000000','0.677915482183157','8.455974581304194','8.455974581304194','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','PIVXBNB','4h','0.085980000000000','0.081380000000000','0.711908500000000','0.673820815654803','8.279931379390556','8.279931379390556','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','PIVXBNB','4h','0.083540000000000','0.082780000000000','0.711908500000000','0.705431956308355','8.521768015322001','8.521768015322001','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','PIVXBNB','4h','0.078030000000000','0.076790000000000','0.711908500000000','0.700595331475074','9.123523003972831','9.123523003972831','test'),('2019-03-14 03:59:59','2019-03-14 15:59:59','PIVXBNB','4h','0.060560000000000','0.057010000000000','0.711908500000000','0.670176743477543','11.755424372523118','11.755424372523118','test'),('2019-03-20 23:59:59','2019-03-21 15:59:59','PIVXBNB','4h','0.056120000000000','0.054480000000000','0.711908500000000','0.691104331432644','12.685468638631503','12.685468638631503','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','PIVXBNB','4h','0.056020000000000','0.055440000000000','0.711908500000000','0.704537794359158','12.708113173866478','12.708113173866478','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','PIVXBNB','4h','0.056120000000000','0.053780000000000','0.711908500000000','0.682224503385602','12.685468638631503','12.685468638631503','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','PIVXBNB','4h','0.056190000000000','0.050140000000000','0.711908500000000','0.635257024203595','12.669665420893399','12.669665420893399','test'),('2019-03-28 19:59:59','2019-03-30 11:59:59','PIVXBNB','4h','0.057040000000000','0.053910000000000','0.711908500000000','0.672843394723001','12.480864305750352','12.480864305750352','test'),('2019-03-31 03:59:59','2019-03-31 07:59:59','PIVXBNB','4h','0.055480000000000','0.052610000000000','0.711908500000000','0.675081221791637','12.83180425378515','12.831804253785149','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','PIVXBNB','4h','0.056180000000000','0.054770000000000','0.711908500000000','0.694041091936632','12.671920612317551','12.671920612317551','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','PIVXBNB','4h','0.054980000000000','0.055010000000000','0.711908500000000','0.712296954983631','12.948499454347036','12.948499454347036','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','PIVXBNB','4h','0.058200000000000','0.053640000000000','0.711908500000000','0.656130102061856','12.232104810996564','12.232104810996564','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','PIVXBNB','4h','0.054860000000000','0.055790000000000','0.711908500000000','0.723976945224207','12.976822821728037','12.976822821728037','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','PIVXBNB','4h','0.054680000000000','0.051760000000000','0.711908500000000','0.673891440380395','13.019540965618143','13.019540965618143','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','PIVXBNB','4h','0.054310000000000','0.054530000000000','0.711908500000000','0.714792312741668','13.108239734855461','13.108239734855461','test'),('2019-05-08 03:59:59','2019-05-08 07:59:59','PIVXBNB','4h','0.029110000000000','0.028290000000000','0.711908500000000','0.691854739436620','24.455805565097904','24.455805565097904','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','PIVXBNB','4h','0.029110000000000','0.029850000000000','0.711908500000000','0.730005796118173','24.455805565097904','24.455805565097904','test'),('2019-05-11 23:59:59','2019-05-12 03:59:59','PIVXBNB','4h','0.029730000000000','0.029330000000000','0.711908500000000','0.702330181802893','23.94579549276825','23.945795492768251','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','PIVXBNB','4h','0.022640000000000','0.021720000000000','0.711908500000000','0.682979356007067','31.444721731448766','31.444721731448766','test'),('2019-05-30 11:59:59','2019-05-30 19:59:59','PIVXBNB','4h','0.022490000000000','0.023020000000000','0.711908500000000','0.728685356602935','31.654446420631395','31.654446420631395','test'),('2019-06-02 15:59:59','2019-06-03 19:59:59','PIVXBNB','4h','0.022510000000000','0.022230000000000','0.711908500000000','0.703053129942248','31.62632163482897','31.626321634828969','test'),('2019-06-04 03:59:59','2019-06-04 07:59:59','PIVXBNB','4h','0.022190000000000','0.022470000000000','0.711908500000000','0.720891572555205','32.08240198287517','32.082401982875169','test'),('2019-06-04 23:59:59','2019-06-05 11:59:59','PIVXBNB','4h','0.022600000000000','0.021640000000000','0.711908500000000','0.681668138938053','31.500376106194693','31.500376106194693','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','PIVXBNB','4h','0.021970000000000','0.021550000000000','0.711908500000000','0.698298961083295','32.4036640873919','32.403664087391903','test'),('2019-06-09 03:59:59','2019-06-10 11:59:59','PIVXBNB','4h','0.022370000000000','0.021780000000000','0.711908500000000','0.693132191774698','31.82425122932499','31.824251229324990','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','PIVXBNB','4h','0.022460000000000','0.022150000000000','0.711908500000000','0.702082514470169','31.69672751558326','31.696727515583259','test'),('2019-06-14 23:59:59','2019-06-15 07:59:59','PIVXBNB','4h','0.022160000000000','0.021610000000000','0.711908500000000','0.694239290839350','32.12583483754513','32.125834837545128','test'),('2019-06-15 19:59:59','2019-06-16 03:59:59','PIVXBNB','4h','0.022320000000000','0.021880000000000','0.711908500000000','0.697874461469534','31.895542114695342','31.895542114695342','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','PIVXBNB','4h','0.020410000000000','0.019340000000000','0.711908500000000','0.674586496325331','34.880377266046054','34.880377266046054','test'),('2019-07-05 23:59:59','2019-07-06 03:59:59','PIVXBNB','4h','0.019340000000000','0.019950000000000','0.711908500000000','0.734362697776629','36.81016028955533','36.810160289555327','test'),('2019-07-10 03:59:59','2019-07-10 15:59:59','PIVXBNB','4h','0.019810000000000','0.019370000000000','0.711908500000000','0.696096297072186','35.936824835941444','35.936824835941444','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','PIVXBNB','4h','0.019690000000000','0.019450000000000','0.711908500000000','0.703231098273235','36.1558405281869','36.155840528186900','test'),('2019-07-25 19:59:59','2019-08-01 07:59:59','PIVXBNB','4h','0.016610000000000','0.017170000000000','0.711908500000000','0.735910231487056','42.86023479831427','42.860234798314274','test'),('2019-08-21 11:59:59','2019-08-21 23:59:59','PIVXBNB','4h','0.012420000000000','0.012280000000000','0.711908500000000','0.703883766505636','57.31952495974235','57.319524959742353','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','PIVXBNB','4h','0.012750000000000','0.013270000000000','0.711908500000000','0.740943199607843','55.835960784313734','55.835960784313734','test'),('2019-09-30 03:59:59','2019-09-30 07:59:59','PIVXBNB','4h','0.012890000000000','0.011860000000000','0.711908500000000','0.655022095422808','55.22951900698216','55.229519006982159','test'),('2019-10-01 11:59:59','2019-10-10 11:59:59','PIVXBNB','4h','0.012990000000000','0.015140000000000','0.711908500000000','0.829737851424172','54.80434949961509','54.804349499615093','test'),('2019-10-11 03:59:59','2019-10-11 07:59:59','PIVXBNB','4h','0.015150000000000','0.015080000000000','0.711908500000000','0.708619153795380','46.990660066006605','46.990660066006605','test'),('2019-10-11 15:59:59','2019-10-12 19:59:59','PIVXBNB','4h','0.015340000000000','0.015100000000000','0.711908500000000','0.700770426988266','46.40863754889179','46.408637548891789','test'),('2019-11-02 07:59:59','2019-11-02 11:59:59','PIVXBNB','4h','0.012390000000000','0.012440000000000','0.711908500000000','0.714781415657789','57.45831315577079','57.458313155770789','test'),('2019-11-03 07:59:59','2019-11-03 11:59:59','PIVXBNB','4h','0.012560000000000','0.012250000000000','0.711908500000000','0.694337509952229','56.68061305732485','56.680613057324848','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','PIVXBNB','4h','0.012760000000000','0.011920000000000','0.711908500000000','0.665043050156740','55.792202194357365','55.792202194357365','test'),('2019-11-04 15:59:59','2019-11-04 23:59:59','PIVXBNB','4h','0.012440000000000','0.012000000000000','0.711908500000000','0.686728456591640','57.22737138263666','57.227371382636662','test'),('2019-11-08 23:59:59','2019-11-09 11:59:59','PIVXBNB','4h','0.012120000000000','0.012080000000000','0.711908500000000','0.709558966996700','58.738325082508254','58.738325082508254','test'),('2019-11-15 07:59:59','2019-11-15 11:59:59','PIVXBNB','4h','0.011800000000000','0.011780000000000','0.711908500000000','0.710701875423729','60.33122881355933','60.331228813559328','test'),('2019-11-19 11:59:59','2019-11-22 07:59:59','PIVXBNB','4h','0.011940000000000','0.011840000000000','0.711908500000000','0.705946117252931','59.62382747068678','59.623827470686777','test'),('2019-11-22 11:59:59','2019-11-23 19:59:59','PIVXBNB','4h','0.012040000000000','0.012410000000000','0.711908500000000','0.733786086794020','59.128612956810635','59.128612956810635','test'),('2019-11-25 19:59:59','2019-12-04 03:59:59','PIVXBNB','4h','0.012360000000000','0.014010000000000','0.711908500000000','0.806944828883495','57.59777508090615','57.597775080906153','test'),('2019-12-05 23:59:59','2019-12-06 11:59:59','PIVXBNB','4h','0.014180000000000','0.013800000000000','0.711908500000000','0.692830557122708','50.20511283497885','50.205112834978848','test'),('2019-12-06 23:59:59','2019-12-07 03:59:59','PIVXBNB','4h','0.014040000000000','0.014170000000000','0.711908500000000','0.718500245370370','50.70573361823362','50.705733618233623','test'),('2019-12-10 15:59:59','2019-12-10 23:59:59','PIVXBNB','4h','0.014330000000000','0.014350000000000','0.711908500000000','0.712902091765527','49.67958827634334','49.679588276343338','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  4:21:42
