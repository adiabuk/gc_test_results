-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 19:59:59','2019-01-06 23:59:59','YOYOBNB','4h','0.002426000000000','0.002440000000000','0.711908500000000','0.716016793075021','293.449505358615','293.449505358614999','test'),('2019-01-15 15:59:59','2019-01-17 07:59:59','YOYOBNB','4h','0.002482000000000','0.002319000000000','0.712935573268755','0.666115066241033','287.2423744032052','287.242374403205190','test'),('2019-01-18 23:59:59','2019-01-19 19:59:59','YOYOBNB','4h','0.002377000000000','0.002262000000000','0.712935573268755','0.678443528285201','299.930825943944','299.930825943944001','test'),('2019-01-21 15:59:59','2019-01-21 19:59:59','YOYOBNB','4h','0.002346000000000','0.002307000000000','0.712935573268755','0.701083703124901','303.89410625266623','303.894106252666234','test'),('2019-01-22 07:59:59','2019-01-25 07:59:59','YOYOBNB','4h','0.002459000000000','0.002414000000000','0.712935573268755','0.699888765299217','289.92906598973366','289.929065989733658','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','YOYOBNB','4h','0.002436000000000','0.002329000000000','0.712935573268755','0.681620258679364','292.6664914896367','292.666491489636712','test'),('2019-02-17 03:59:59','2019-02-17 15:59:59','YOYOBNB','4h','0.001681000000000','0.001683000000000','0.712935573268755','0.713783801196499','424.1139638719542','424.113963871954184','test'),('2019-02-19 23:59:59','2019-02-20 03:59:59','YOYOBNB','4h','0.001658000000000','0.001549000000000','0.712935573268755','0.666065864290290','429.99733007765684','429.997330077656841','test'),('2019-02-20 15:59:59','2019-02-21 23:59:59','YOYOBNB','4h','0.001900000000000','0.001688000000000','0.712935573268755','0.633386972461926','375.22924908881845','375.229249088818449','test'),('2019-02-22 15:59:59','2019-02-22 19:59:59','YOYOBNB','4h','0.001720000000000','0.001655000000000','0.712935573268755','0.685993240558017','414.4974263190436','414.497426319043598','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','YOYOBNB','4h','0.001677000000000','0.001665000000000','0.712935573268755','0.707834066483290','425.1255654554293','425.125565455429296','test'),('2019-03-15 19:59:59','2019-03-16 11:59:59','YOYOBNB','4h','0.001500000000000','0.001308000000000','0.712935573268755','0.621679819890354','475.29038217916997','475.290382179169967','test'),('2019-03-17 15:59:59','2019-03-18 03:59:59','YOYOBNB','4h','0.001331000000000','0.001319000000000','0.712935573268755','0.706507904689322','535.6390482860669','535.639048286066895','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','YOYOBNB','4h','0.001313000000000','0.001320000000000','0.712935573268755','0.716736448373767','542.9821578589148','542.982157858914775','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','YOYOBNB','4h','0.001321000000000','0.001283000000000','0.712935573268755','0.692427207043007','539.6938480459917','539.693848045991672','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','YOYOBNB','4h','0.001356000000000','0.001231000000000','0.712935573268755','0.647215111131149','525.7636971008518','525.763697100851800','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','YOYOBNB','4h','0.001311000000000','0.001281000000000','0.712935573268755','0.696621258090980','543.8105059258238','543.810505925823804','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','YOYOBNB','4h','0.001298000000000','0.001312000000000','0.712935573268755','0.720625171131438','549.256990191645','549.256990191644945','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','YOYOBNB','4h','0.001307000000000','0.001289000000000','0.712935573268755','0.703117026735597','545.4748073976702','545.474807397670247','test'),('2019-04-05 03:59:59','2019-04-06 23:59:59','YOYOBNB','4h','0.001318000000000','0.001334000000000','0.712935573268755','0.721590329848649','540.922286243365','540.922286243364965','test'),('2019-04-13 19:59:59','2019-04-13 23:59:59','YOYOBNB','4h','0.001449000000000','0.001220000000000','0.712935573268755','0.600263215588600','492.01902917098346','492.019029170983458','test'),('2019-04-15 19:59:59','2019-04-16 07:59:59','YOYOBNB','4h','0.001676000000000','0.001286000000000','0.712935573268755','0.547037677341061','425.3792203274195','425.379220327419489','test'),('2019-05-06 19:59:59','2019-05-07 03:59:59','YOYOBNB','4h','0.000879000000000','0.000857000000000','0.475290382179170','0.463394604695732','540.7171583380774','540.717158338077411','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','YOYOBNB','4h','0.000900000000000','0.000827000000000','0.519058978357847','0.476957527891044','576.7321981753861','576.732198175386088','test'),('2019-05-08 11:59:59','2019-05-09 03:59:59','YOYOBNB','4h','0.000943000000000','0.000850000000000','0.519058978357847','0.467868644331039','550.4336992129872','550.433699212987221','test'),('2019-05-10 15:59:59','2019-05-10 23:59:59','YOYOBNB','4h','0.000906000000000','0.000851000000000','0.519058978357847','0.487548775477404','572.9127796444227','572.912779644422699','test'),('2019-05-12 03:59:59','2019-05-12 11:59:59','YOYOBNB','4h','0.000870000000000','0.000861000000000','0.519058978357847','0.513689402719662','596.6195153538471','596.619515353847078','test'),('2019-05-16 11:59:59','2019-05-16 15:59:59','YOYOBNB','4h','0.000853000000000','0.000842000000000','0.519058978357847','0.512365369023807','608.5099394582028','608.509939458202780','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','YOYOBNB','4h','0.000913000000000','0.000779000000000','0.519058978357847','0.442877266309707','568.5202391652213','568.520239165221255','test'),('2019-05-27 03:59:59','2019-05-27 07:59:59','YOYOBNB','4h','0.000768000000000','0.000805000000000','0.519058978357847','0.544065726013108','675.8580447367799','675.858044736779902','test'),('2019-05-28 07:59:59','2019-05-29 11:59:59','YOYOBNB','4h','0.000765000000000','0.000763000000000','0.519058978357847','0.517701961420964','678.50846844163','678.508468441630043','test'),('2019-05-31 07:59:59','2019-05-31 11:59:59','YOYOBNB','4h','0.000764000000000','0.000771000000000','0.519058978357847','0.523814754337565','679.3965685312133','679.396568531213347','test'),('2019-06-02 11:59:59','2019-06-04 03:59:59','YOYOBNB','4h','0.000773000000000','0.000774000000000','0.519058978357847','0.519730464746408','671.4863885612509','671.486388561250919','test'),('2019-06-07 11:59:59','2019-06-08 19:59:59','YOYOBNB','4h','0.000779000000000','0.000762000000000','0.519058978357847','0.507731632231938','666.3144779946688','666.314477994668778','test'),('2019-06-08 23:59:59','2019-06-09 03:59:59','YOYOBNB','4h','0.000770000000000','0.000766000000000','0.519058978357847','0.516362568080663','674.1025692959053','674.102569295905255','test'),('2019-06-10 07:59:59','2019-06-12 15:59:59','YOYOBNB','4h','0.000785000000000','0.000789000000000','0.519058978357847','0.521703864871772','661.2216284813337','661.221628481333710','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','YOYOBNB','4h','0.000819000000000','0.000784000000000','0.519058978357847','0.496876970735717','633.7716463465775','633.771646346577540','test'),('2019-06-27 07:59:59','2019-06-27 11:59:59','YOYOBNB','4h','0.000999000000000','0.000958000000000','0.519058978357847','0.497756257524342','519.5785569147616','519.578556914761634','test'),('2019-06-30 23:59:59','2019-07-01 11:59:59','YOYOBNB','4h','0.000936000000000','0.000894000000000','0.519058978357847','0.495767870354610','554.5501905532553','554.550190553255334','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','YOYOBNB','4h','0.000940000000000','0.000937000000000','0.519058978357847','0.517402407150322','552.1904025083479','552.190402508347916','test'),('2019-07-30 23:59:59','2019-07-31 03:59:59','YOYOBNB','4h','0.000635000000000','0.000636000000000','0.519058978357847','0.519876394071796','817.4157139493652','817.415713949365227','test'),('2019-08-04 11:59:59','2019-08-04 15:59:59','YOYOBNB','4h','0.000619000000000','0.000595000000000','0.519058978357847','0.498933912961097','838.5443915312552','838.544391531255201','test'),('2019-08-10 15:59:59','2019-08-10 19:59:59','YOYOBNB','4h','0.000569000000000','0.000508000000000','0.519058978357847','0.463412936741276','912.2301904355835','912.230190435583495','test'),('2019-08-21 11:59:59','2019-08-23 15:59:59','YOYOBNB','4h','0.000508000000000','0.000488000000000','0.519058978357847','0.498623585509113','1021.7696424367067','1021.769642436706704','test'),('2019-09-04 15:59:59','2019-09-04 19:59:59','YOYOBNB','4h','0.000571000000000','0.000557000000000','0.519058978357847','0.506332488520702','909.0349883675078','909.034988367507822','test'),('2019-09-08 15:59:59','2019-09-09 03:59:59','YOYOBNB','4h','0.000561000000000','0.000540000000000','0.519058978357847','0.499628963125200','925.2388206022229','925.238820602222859','test'),('2019-09-09 11:59:59','2019-09-09 15:59:59','YOYOBNB','4h','0.000577000000000','0.000559000000000','0.519058978357847','0.502866497230566','899.5822848489548','899.582284848954828','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','YOYOBNB','4h','0.000832000000000','0.000845000000000','0.519058978357847','0.527169274894688','623.8689643724123','623.868964372412279','test'),('2019-11-01 07:59:59','2019-11-02 15:59:59','YOYOBNB','4h','0.000685000000000','0.000692000000000','0.519058978357847','0.524363230691431','757.7503333691197','757.750333369119744','test'),('2019-11-17 07:59:59','2019-11-17 11:59:59','YOYOBNB','4h','0.000633000000000','0.000622000000000','0.519058978357847','0.510038996111502','819.9983860313539','819.998386031353903','test'),('2019-11-17 15:59:59','2019-11-18 03:59:59','YOYOBNB','4h','0.000653000000000','0.000641000000000','0.519058978357847','0.509520375386493','794.8835809461668','794.883580946166830','test'),('2019-12-04 07:59:59','2019-12-05 03:59:59','YOYOBNB','4h','0.000807000000000','0.000785000000000','0.519058978357847','0.504908671636815','643.1957600468984','643.195760046898386','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','YOYOBNB','4h','0.000804000000000','0.000786000000000','0.519058978357847','0.507438254961776','645.5957442261778','645.595744226177771','test'),('2019-12-05 15:59:59','2019-12-05 19:59:59','YOYOBNB','4h','0.000804000000000','0.000799000000000','0.519058978357847','0.515830999636716','645.5957442261778','645.595744226177771','test'),('2019-12-16 19:59:59','2019-12-17 07:59:59','YOYOBNB','4h','0.000787000000000','0.000792000000000','0.519058978357847','0.522356684700654','659.5412685614319','659.541268561431934','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','YOYOBNB','4h','0.000741000000000','0.000716000000000','0.519058978357847','0.501546867077218','700.4844512251645','700.484451225164548','test'),('2019-12-31 23:59:59','2020-01-01 03:59:59','YOYOBNB','4h','0.000739000000000','0.000726000000000','0.519058978357847','0.509928035572120','702.3802142866671','702.380214286667069','test'),('2020-01-01 07:59:59','2020-01-01 15:59:59','YOYOBNB','4h','0.000741000000000','0.000737000000000','0.519058978357847','0.516257040552946','700.4844512251645','700.484451225164548','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:21:25
