-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 11:59:59','2019-01-03 15:59:59','DNTBTC','4h','0.000003140000000','0.000003060000000','0.001467500000000','0.001430111464968','467.3566878980892','467.356687898089206','test'),('2019-01-05 19:59:59','2019-01-05 23:59:59','DNTBTC','4h','0.000003090000000','0.000003080000000','0.001467500000000','0.001462750809061','474.9190938511327','474.919093851132686','test'),('2019-01-06 23:59:59','2019-01-07 11:59:59','DNTBTC','4h','0.000003200000000','0.000003060000000','0.001467500000000','0.001403296875000','458.59375000000006','458.593750000000057','test'),('2019-01-08 11:59:59','2019-01-08 15:59:59','DNTBTC','4h','0.000003130000000','0.000003080000000','0.001467500000000','0.001444057507987','468.84984025559106','468.849840255591062','test'),('2019-01-09 03:59:59','2019-01-09 11:59:59','DNTBTC','4h','0.000003090000000','0.000003100000000','0.001467500000000','0.001472249190939','474.9190938511327','474.919093851132686','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','DNTBTC','4h','0.000003090000000','0.000003030000000','0.001467500000000','0.001439004854369','474.9190938511327','474.919093851132686','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','DNTBTC','4h','0.000003100000000','0.000003050000000','0.001467500000000','0.001443830645161','473.3870967741936','473.387096774193594','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','DNTBTC','4h','0.000003070000000','0.000003070000000','0.001467500000000','0.001467500000000','478.013029315961','478.013029315960978','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','DNTBTC','4h','0.000003050000000','0.000003030000000','0.001467500000000','0.001457877049180','481.1475409836066','481.147540983606575','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','DNTBTC','4h','0.000003060000000','0.000003070000000','0.001467500000000','0.001472295751634','479.57516339869284','479.575163398692837','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','DNTBTC','4h','0.000003050000000','0.000003040000000','0.001467500000000','0.001462688524590','481.1475409836066','481.147540983606575','test'),('2019-02-13 07:59:59','2019-02-13 11:59:59','DNTBTC','4h','0.000003050000000','0.000003050000000','0.001467500000000','0.001467500000000','481.1475409836066','481.147540983606575','test'),('2019-02-13 19:59:59','2019-02-13 23:59:59','DNTBTC','4h','0.000003050000000','0.000003040000000','0.001467500000000','0.001462688524590','481.1475409836066','481.147540983606575','test'),('2019-02-14 07:59:59','2019-02-14 11:59:59','DNTBTC','4h','0.000003060000000','0.000003060000000','0.001467500000000','0.001467500000000','479.57516339869284','479.575163398692837','test'),('2019-02-17 07:59:59','2019-02-17 15:59:59','DNTBTC','4h','0.000003060000000','0.000003040000000','0.001467500000000','0.001457908496732','479.57516339869284','479.575163398692837','test'),('2019-02-21 23:59:59','2019-02-22 07:59:59','DNTBTC','4h','0.000003170000000','0.000003060000000','0.001467500000000','0.001416577287066','462.93375394321765','462.933753943217653','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','DNTBTC','4h','0.000003110000000','0.000003080000000','0.001467500000000','0.001453344051447','471.86495176848877','471.864951768488766','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','DNTBTC','4h','0.000003310000000','0.000003310000000','0.001467500000000','0.001467500000000','443.3534743202417','443.353474320241673','test'),('2019-03-26 03:59:59','2019-03-26 07:59:59','DNTBTC','4h','0.000003620000000','0.000003530000000','0.001467500000000','0.001431015193370','405.3867403314917','405.386740331491694','test'),('2019-03-26 15:59:59','2019-03-31 15:59:59','DNTBTC','4h','0.000003620000000','0.000003990000000','0.001467500000000','0.001617493093923','405.3867403314917','405.386740331491694','test'),('2019-04-14 11:59:59','2019-04-15 19:59:59','DNTBTC','4h','0.000003480000000','0.000003370000000','0.001467500000000','0.001421113505747','421.6954022988506','421.695402298850581','test'),('2019-04-22 03:59:59','2019-04-22 07:59:59','DNTBTC','4h','0.000003300000000','0.000003170000000','0.001467500000000','0.001409689393939','444.6969696969697','444.696969696969688','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','DNTBTC','4h','0.000002200000000','0.000002220000000','0.001467500000000','0.001480840909091','667.0454545454545','667.045454545454504','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','DNTBTC','4h','0.000002300000000','0.000002300000000','0.001467500000000','0.001467500000000','638.0434782608696','638.043478260869620','test'),('2019-05-27 03:59:59','2019-05-27 07:59:59','DNTBTC','4h','0.000002300000000','0.000002320000000','0.001467500000000','0.001480260869565','638.0434782608696','638.043478260869620','test'),('2019-05-27 23:59:59','2019-05-30 15:59:59','DNTBTC','4h','0.000002350000000','0.000002280000000','0.001467500000000','0.001423787234043','624.468085106383','624.468085106383000','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','DNTBTC','4h','0.000002340000000','0.000002300000000','0.001467500000000','0.001442414529915','627.1367521367522','627.136752136752193','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','DNTBTC','4h','0.000002310000000','0.000002280000000','0.001467500000000','0.001448441558442','635.2813852813854','635.281385281385383','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','DNTBTC','4h','0.000002310000000','0.000002290000000','0.001467500000000','0.001454794372294','635.2813852813854','635.281385281385383','test'),('2019-06-07 07:59:59','2019-06-07 15:59:59','DNTBTC','4h','0.000002300000000','0.000002270000000','0.001467500000000','0.001448358695652','638.0434782608696','638.043478260869620','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','DNTBTC','4h','0.000002430000000','0.000002360000000','0.001467500000000','0.001425226337449','603.9094650205761','603.909465020576135','test'),('2019-06-10 15:59:59','2019-06-10 19:59:59','DNTBTC','4h','0.000002280000000','0.000002260000000','0.001467500000000','0.001454627192982','643.640350877193','643.640350877192986','test'),('2019-06-11 19:59:59','2019-06-12 15:59:59','DNTBTC','4h','0.000002330000000','0.000002280000000','0.001467500000000','0.001436008583691','629.8283261802575','629.828326180257477','test'),('2019-06-13 07:59:59','2019-06-13 11:59:59','DNTBTC','4h','0.000002280000000','0.000002300000000','0.001467500000000','0.001480372807018','643.640350877193','643.640350877192986','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','DNTBTC','4h','0.000002500000000','0.000002240000000','0.001467500000000','0.001314880000000','587.0','587.000000000000000','test'),('2019-07-01 03:59:59','2019-07-01 07:59:59','DNTBTC','4h','0.000001580000000','0.000001530000000','0.001467500000000','0.001421060126582','928.7974683544305','928.797468354430521','test'),('2019-07-26 11:59:59','2019-07-27 03:59:59','DNTBTC','4h','0.000001050000000','0.000001020000000','0.001467500000000','0.001425571428571','1397.6190476190477','1397.619047619047706','test'),('2019-07-28 23:59:59','2019-07-29 03:59:59','DNTBTC','4h','0.000001030000000','0.000001020000000','0.001467500000000','0.001453252427184','1424.757281553398','1424.757281553397888','test'),('2019-07-30 23:59:59','2019-07-31 15:59:59','DNTBTC','4h','0.000001070000000','0.000001010000000','0.001467500000000','0.001385210280374','1371.495327102804','1371.495327102803913','test'),('2019-08-22 11:59:59','2019-08-22 15:59:59','DNTBTC','4h','0.000000660000000','0.000000660000000','0.001467500000000','0.001467500000000','2223.4848484848485','2223.484848484848499','test'),('2019-08-29 19:59:59','2019-08-30 07:59:59','DNTBTC','4h','0.000000750000000','0.000000720000000','0.001467500000000','0.001408800000000','1956.6666666666667','1956.666666666666742','test'),('2019-08-30 11:59:59','2019-08-30 19:59:59','DNTBTC','4h','0.000000740000000','0.000000720000000','0.001467500000000','0.001427837837838','1983.1081081081081','1983.108108108108127','test'),('2019-08-31 03:59:59','2019-08-31 07:59:59','DNTBTC','4h','0.000000730000000','0.000000740000000','0.001467500000000','0.001487602739726','2010.2739726027398','2010.273972602739832','test'),('2019-09-09 19:59:59','2019-09-12 03:59:59','DNTBTC','4h','0.000000670000000','0.000000670000000','0.001467500000000','0.001467500000000','2190.2985074626863','2190.298507462686302','test'),('2019-09-17 11:59:59','2019-09-24 15:59:59','DNTBTC','4h','0.000000660000000','0.000000740000000','0.001467500000000','0.001645378787879','2223.4848484848485','2223.484848484848499','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','DNTBTC','4h','0.000000750000000','0.000000700000000','0.001467500000000','0.001369666666667','1956.6666666666667','1956.666666666666742','test'),('2019-09-27 11:59:59','2019-09-27 15:59:59','DNTBTC','4h','0.000000740000000','0.000000720000000','0.001467500000000','0.001427837837838','1983.1081081081081','1983.108108108108127','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','DNTBTC','4h','0.000000740000000','0.000000750000000','0.001467500000000','0.001487331081081','1983.1081081081081','1983.108108108108127','test'),('2019-09-30 15:59:59','2019-10-01 03:59:59','DNTBTC','4h','0.000000750000000','0.000000730000000','0.001467500000000','0.001428366666667','1956.6666666666667','1956.666666666666742','test'),('2019-10-01 11:59:59','2019-10-01 19:59:59','DNTBTC','4h','0.000000750000000','0.000000740000000','0.001467500000000','0.001447933333333','1956.6666666666667','1956.666666666666742','test'),('2019-10-15 15:59:59','2019-10-15 19:59:59','DNTBTC','4h','0.000000880000000','0.000000880000000','0.001467500000000','0.001467500000000','1667.6136363636363','1667.613636363636260','test'),('2019-10-22 07:59:59','2019-10-22 11:59:59','DNTBTC','4h','0.000000820000000','0.000000810000000','0.001467500000000','0.001449603658537','1789.6341463414635','1789.634146341463520','test'),('2019-10-22 15:59:59','2019-10-22 19:59:59','DNTBTC','4h','0.000000830000000','0.000000830000000','0.001467500000000','0.001467500000000','1768.0722891566265','1768.072289156626539','test'),('2019-10-25 03:59:59','2019-10-25 07:59:59','DNTBTC','4h','0.000000820000000','0.000000810000000','0.001467500000000','0.001449603658537','1789.6341463414635','1789.634146341463520','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','DNTBTC','4h','0.000000720000000','0.000000690000000','0.001467500000000','0.001406354166667','2038.1944444444446','2038.194444444444571','test'),('2019-11-07 15:59:59','2019-11-08 03:59:59','DNTBTC','4h','0.000000730000000','0.000000710000000','0.001467500000000','0.001427294520548','2010.2739726027398','2010.273972602739832','test'),('2019-11-09 03:59:59','2019-11-09 07:59:59','DNTBTC','4h','0.000000710000000','0.000000710000000','0.001467500000000','0.001467500000000','2066.9014084507044','2066.901408450704366','test'),('2019-11-10 03:59:59','2019-11-10 07:59:59','DNTBTC','4h','0.000000710000000','0.000000710000000','0.001467500000000','0.001467500000000','2066.9014084507044','2066.901408450704366','test'),('2019-11-11 23:59:59','2019-11-12 03:59:59','DNTBTC','4h','0.000000710000000','0.000000710000000','0.001467500000000','0.001467500000000','2066.9014084507044','2066.901408450704366','test'),('2019-11-13 07:59:59','2019-11-13 11:59:59','DNTBTC','4h','0.000000710000000','0.000000710000000','0.001467500000000','0.001467500000000','2066.9014084507044','2066.901408450704366','test'),('2019-11-15 07:59:59','2019-11-15 11:59:59','DNTBTC','4h','0.000000710000000','0.000000710000000','0.001467500000000','0.001467500000000','2066.9014084507044','2066.901408450704366','test'),('2019-11-16 03:59:59','2019-11-18 15:59:59','DNTBTC','4h','0.000000730000000','0.000000730000000','0.001467500000000','0.001467500000000','2010.2739726027398','2010.273972602739832','test'),('2019-11-25 07:59:59','2019-11-27 11:59:59','DNTBTC','4h','0.000000800000000','0.000000780000000','0.001467500000000','0.001430812500000','1834.3750000000002','1834.375000000000227','test'),('2019-12-05 19:59:59','2019-12-10 03:59:59','DNTBTC','4h','0.000000800000000','0.000000820000000','0.001467500000000','0.001504187500000','1834.3750000000002','1834.375000000000227','test'),('2019-12-16 23:59:59','2019-12-17 03:59:59','DNTBTC','4h','0.000000840000000','0.000000780000000','0.001467500000000','0.001362678571429','1747.0238095238096','1747.023809523809632','test'),('2019-12-22 03:59:59','2019-12-22 07:59:59','DNTBTC','4h','0.000000780000000','0.000000780000000','0.001467500000000','0.001467500000000','1881.4102564102564','1881.410256410256352','test'),('2019-12-24 23:59:59','2019-12-25 03:59:59','DNTBTC','4h','0.000000770000000','0.000000740000000','0.001467500000000','0.001410324675325','1905.844155844156','1905.844155844155921','test'),('2019-12-29 15:59:59','2019-12-29 19:59:59','DNTBTC','4h','0.000000760000000','0.000000740000000','0.001467500000000','0.001428881578947','1930.921052631579','1930.921052631578959','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 17:56:59
