-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 23:59:59','2019-01-08 03:59:59','VIBETH','4h','0.000173720000000','0.000176670000000','0.072144500000000','0.073369610954409','415.2918489523371','415.291848952337091','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','VIBETH','4h','0.000176500000000','0.000173250000000','0.072450777738602','0.071116698261829','410.48599285327055','410.485992853270545','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','VIBETH','4h','0.000177850000000','0.000175780000000','0.072450777738602','0.071607521568127','407.370130664054','407.370130664053988','test'),('2019-01-28 19:59:59','2019-01-29 07:59:59','VIBETH','4h','0.000207100000000','0.000203070000000','0.072450777738602','0.071040943676378','349.8347548942637','349.834754894263710','test'),('2019-01-29 11:59:59','2019-01-31 03:59:59','VIBETH','4h','0.000211210000000','0.000201390000000','0.072450777738602','0.069082250503182','343.02721338289854','343.027213382898537','test'),('2019-02-01 07:59:59','2019-02-01 11:59:59','VIBETH','4h','0.000208150000000','0.000212880000000','0.072450777738602','0.074097149003092','348.07003477589245','348.070034775892452','test'),('2019-02-03 15:59:59','2019-02-03 19:59:59','VIBETH','4h','0.000208160000000','0.000206190000000','0.072450777738602','0.071765112711003','348.0533135021234','348.053313502123387','test'),('2019-02-04 11:59:59','2019-02-04 15:59:59','VIBETH','4h','0.000207560000000','0.000206210000000','0.072450777738602','0.071979547492181','349.0594417932261','349.059441793226085','test'),('2019-02-04 19:59:59','2019-02-04 23:59:59','VIBETH','4h','0.000209390000000','0.000209110000000','0.072450777738602','0.072353895281146','346.0087766302212','346.008776630221178','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','VIBETH','4h','0.000210080000000','0.000210130000000','0.072450777738602','0.072468021354781','344.87232358435836','344.872323584358355','test'),('2019-02-26 07:59:59','2019-02-27 11:59:59','VIBETH','4h','0.000173570000000','0.000171150000000','0.072450777738602','0.071440632655192','417.41532372300514','417.415323723005145','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','VIBETH','4h','0.000177960000000','0.000175290000000','0.072450777738602','0.071363771801526','407.118328492931','407.118328492931028','test'),('2019-03-07 07:59:59','2019-03-07 11:59:59','VIBETH','4h','0.000179800000000','0.000181150000000','0.072450777738602','0.072994762999709','402.95204526474976','402.952045264749756','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','VIBETH','4h','0.000204270000000','0.000203740000000','0.072450777738602','0.072262796575428','354.6814399500759','354.681439950075912','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','VIBETH','4h','0.000204800000000','0.000205060000000','0.072450777738602','0.072542756265028','353.7635631767676','353.763563176767605','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','VIBETH','4h','0.000204920000000','0.000203390000000','0.072450777738602','0.071909836444731','353.556401222926','353.556401222926013','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','VIBETH','4h','0.000206190000000','0.000212710000000','0.072450777738602','0.074741766975983','351.37871738979584','351.378717389795838','test'),('2019-04-05 23:59:59','2019-04-06 07:59:59','VIBETH','4h','0.000237920000000','0.000232890000000','0.072450777738602','0.070919055260352','304.5173913021268','304.517391302126782','test'),('2019-04-07 15:59:59','2019-04-07 19:59:59','VIBETH','4h','0.000238000000000','0.000228960000000','0.072450777738602','0.069698865844665','304.41503251513444','304.415032515134442','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','VIBETH','4h','0.000237680000000','0.000221090000000','0.072450777738602','0.067393732961240','304.8248810947577','304.824881094757700','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','VIBETH','4h','0.000234710000000','0.000244880000000','0.072450777738602','0.075590074784325','308.68210872396577','308.682108723965769','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','VIBETH','4h','0.000227250000000','0.000223890000000','0.072450777738602','0.071379558318573','318.8153035802069','318.815303580206887','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','VIBETH','4h','0.000225470000000','0.000219000000000','0.072450777738602','0.070371758215079','321.33222929259773','321.332229292597731','test'),('2019-04-16 15:59:59','2019-04-16 19:59:59','VIBETH','4h','0.000227680000000','0.000224040000000','0.072450777738602','0.071292481748754','318.2131840240777','318.213184024077691','test'),('2019-04-17 07:59:59','2019-04-22 03:59:59','VIBETH','4h','0.000226000000000','0.000237490000000','0.072450777738602','0.076134226571419','320.5786625601859','320.578662560185876','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','VIBETH','4h','0.000245970000000','0.000236190000000','0.072450777738602','0.069570066244178','294.55127754848974','294.551277548489736','test'),('2019-04-26 11:59:59','2019-04-26 15:59:59','VIBETH','4h','0.000240680000000','0.000233640000000','0.072450777738602','0.070331559376961','301.0253354603706','301.025335460370627','test'),('2019-04-26 19:59:59','2019-04-26 23:59:59','VIBETH','4h','0.000237580000000','0.000238670000000','0.072450777738602','0.072783176710464','304.9531851948902','304.953185194890182','test'),('2019-04-30 15:59:59','2019-05-03 11:59:59','VIBETH','4h','0.000239730000000','0.000245900000000','0.072450777738602','0.074315464255297','302.2182360931131','302.218236093113092','test'),('2019-05-07 19:59:59','2019-05-07 23:59:59','VIBETH','4h','0.000247780000000','0.000243750000000','0.072450777738602','0.071272407271710','292.3996195762451','292.399619576245072','test'),('2019-05-08 15:59:59','2019-05-08 19:59:59','VIBETH','4h','0.000247270000000','0.000250730000000','0.072450777738602','0.073464567082136','293.0027004432483','293.002700443248273','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','VIBETH','4h','0.000195270000000','0.000185030000000','0.072450777738602','0.068651443667607','371.02871787065095','371.028717870650951','test'),('2019-05-23 11:59:59','2019-05-24 15:59:59','VIBETH','4h','0.000191060000000','0.000187500000000','0.072450777738602','0.071100810352705','379.204321881095','379.204321881094984','test'),('2019-05-26 11:59:59','2019-05-26 19:59:59','VIBETH','4h','0.000191720000000','0.000187670000000','0.072450777738602','0.070920287180281','377.8989032891822','377.898903289182215','test'),('2019-05-29 19:59:59','2019-05-30 03:59:59','VIBETH','4h','0.000190280000000','0.000187890000000','0.072450777738602','0.071540764291076','380.75876465525545','380.758764655255447','test'),('2019-06-01 11:59:59','2019-06-03 07:59:59','VIBETH','4h','0.000191710000000','0.000190150000000','0.072450777738602','0.071861224698739','377.91861529707376','377.918615297073757','test'),('2019-06-08 03:59:59','2019-06-14 15:59:59','VIBETH','4h','0.000188250000000','0.000191380000000','0.072450777738602','0.073655404215743','384.8646891824808','384.864689182480788','test'),('2019-06-21 19:59:59','2019-06-21 23:59:59','VIBETH','4h','0.000186340000000','0.000179560000000','0.072450777738602','0.069814648764320','388.8095832274445','388.809583227444477','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','VIBETH','4h','0.000151730000000','0.000144350000000','0.072450777738602','0.068926842197108','477.49804085284387','477.498040852843872','test'),('2019-07-04 07:59:59','2019-07-04 11:59:59','VIBETH','4h','0.000146430000000','0.000145570000000','0.072450777738602','0.072025266102631','494.78097205901804','494.780972059018040','test'),('2019-07-10 07:59:59','2019-07-10 11:59:59','VIBETH','4h','0.000143400000000','0.000138060000000','0.072450777738602','0.069752819906495','505.235549083696','505.235549083696014','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','VIBETH','4h','0.000142270000000','0.000134800000000','0.072450777738602','0.068646691777350','509.24845532158577','509.248455321585766','test'),('2019-07-11 23:59:59','2019-07-12 03:59:59','VIBETH','4h','0.000141140000000','0.000137040000000','0.072450777738602','0.070346142704393','513.3256180997734','513.325618099773351','test'),('2019-07-12 11:59:59','2019-07-12 23:59:59','VIBETH','4h','0.000140340000000','0.000138270000000','0.072450777738602','0.071382136510735','516.2518009021092','516.251800902109153','test'),('2019-07-14 11:59:59','2019-07-14 19:59:59','VIBETH','4h','0.000140250000000','0.000144870000000','0.072450777738602','0.074837391593521','516.5830854802282','516.583085480228192','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','VIBETH','4h','0.000139350000000','0.000136300000000','0.072450777738602','0.070865023363986','519.9194670872049','519.919467087204907','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','VIBETH','4h','0.000138250000000','0.000139210000000','0.072450777738602','0.072953871746769','524.056258507067','524.056258507067014','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','VIBETH','4h','0.000137970000000','0.000132990000000','0.072450777738602','0.069835681173130','525.11979226355','525.119792263550039','test'),('2019-08-21 19:59:59','2019-08-23 19:59:59','VIBETH','4h','0.000090980000000','0.000091490000000','0.072450777738602','0.072856909818693','796.3374119433063','796.337411943306279','test'),('2019-08-29 11:59:59','2019-08-29 19:59:59','VIBETH','4h','0.000101890000000','0.000100040000000','0.072450777738602','0.071135300863380','711.0685812013152','711.068581201315169','test'),('2019-09-01 11:59:59','2019-09-01 19:59:59','VIBETH','4h','0.000098270000000','0.000099100000000','0.072450777738602','0.073062705544881','737.262417203643','737.262417203643054','test'),('2019-09-07 11:59:59','2019-09-07 19:59:59','VIBETH','4h','0.000096050000000','0.000093180000000','0.072450777738602','0.070285928887901','754.3027354357314','754.302735435731392','test'),('2019-09-08 11:59:59','2019-09-08 15:59:59','VIBETH','4h','0.000095280000000','0.000094570000000','0.072450777738602','0.071910894739081','760.3985908753359','760.398590875335913','test'),('2019-09-09 19:59:59','2019-09-10 19:59:59','VIBETH','4h','0.000096450000000','0.000096200000000','0.072450777738602','0.072262984120824','751.1744711104407','751.174471110440663','test'),('2019-09-11 15:59:59','2019-09-11 19:59:59','VIBETH','4h','0.000096490000000','0.000094110000000','0.072450777738602','0.070663723629183','750.8630711845994','750.863071184599448','test'),('2019-09-13 15:59:59','2019-09-13 23:59:59','VIBETH','4h','0.000096550000000','0.000093480000000','0.072450777738602','0.070147060621486','750.3964550865045','750.396455086504488','test'),('2019-09-14 11:59:59','2019-09-14 19:59:59','VIBETH','4h','0.000097890000000','0.000097600000000','0.072450777738602','0.072236141661943','740.1244022740015','740.124402274001454','test'),('2019-09-18 07:59:59','2019-09-19 03:59:59','VIBETH','4h','0.000101600000000','0.000096260000000','0.072450777738602','0.068642833318089','713.0982060886024','713.098206088602410','test'),('2019-09-19 23:59:59','2019-09-20 03:59:59','VIBETH','4h','0.000099430000000','0.000095250000000','0.072450777738602','0.069404974148666','728.6611459177512','728.661145917751242','test'),('2019-09-20 07:59:59','2019-09-20 15:59:59','VIBETH','4h','0.000097480000000','0.000100470000000','0.072450777738602','0.074673057441499','743.2373588284983','743.237358828498259','test'),('2019-09-23 07:59:59','2019-09-23 23:59:59','VIBETH','4h','0.000099640000000','0.000096580000000','0.072450777738602','0.070225773926076','727.1254289301687','727.125428930168709','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','VIBETH','4h','0.000100570000000','0.000097160000000','0.072450777738602','0.069994208661455','720.4014888992941','720.401488899294122','test'),('2019-09-28 03:59:59','2019-10-05 15:59:59','VIBETH','4h','0.000101290000000','0.000117340000000','0.072450777738602','0.083931032282037','715.2806569118571','715.280656911857136','test'),('2019-10-11 11:59:59','2019-10-16 11:59:59','VIBETH','4h','0.000133860000000','0.000133220000000','0.072450777738602','0.072104382267567','541.2429234917228','541.242923491722763','test'),('2019-10-19 19:59:59','2019-10-20 03:59:59','VIBETH','4h','0.000135000000000','0.000131880000000','0.072450777738602','0.070776359764199','536.6724276933481','536.672427693348141','test'),('2019-10-20 15:59:59','2019-10-20 19:59:59','VIBETH','4h','0.000133590000000','0.000136460000000','0.072450777738602','0.074007284453998','542.3368346328468','542.336834632846831','test'),('2019-10-26 19:59:59','2019-10-27 03:59:59','VIBETH','4h','0.000140150000000','0.000136730000000','0.072450777738602','0.070682802998209','516.95167847736','516.951678477360019','test'),('2019-11-02 07:59:59','2019-11-02 11:59:59','VIBETH','4h','0.000130770000000','0.000128350000000','0.072450777738602','0.071110020056202','554.0321001651909','554.032100165190855','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','VIBETH','4h','0.000131800000000','0.000131350000000','0.072450777738602','0.072203411653759','549.7024107632928','549.702410763292846','test'),('2019-11-07 15:59:59','2019-11-07 23:59:59','VIBETH','4h','0.000130500000000','0.000133980000000','0.072450777738602','0.074382798478298','555.1783734758775','555.178373475877493','test'),('2019-11-09 03:59:59','2019-11-09 07:59:59','VIBETH','4h','0.000131010000000','0.000129760000000','0.072450777738602','0.071759506292352','553.0171570002443','553.017157000244310','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','VIBETH','4h','0.000144980000000','0.000145950000000','0.072450777738602','0.072935515319002','499.72946433026624','499.729464330266239','test'),('2019-12-24 11:59:59','2019-12-24 19:59:59','VIBETH','4h','0.000151470000000','0.000148270000000','0.072450777738602','0.070920161189031','478.317671740952','478.317671740951994','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','VIBETH','4h','0.000151790000000','0.000144240000000','0.072450777738602','0.068847092568786','477.3092940154292','477.309294015429202','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:40:10
