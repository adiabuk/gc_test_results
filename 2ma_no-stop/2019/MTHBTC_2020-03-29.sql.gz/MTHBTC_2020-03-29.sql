-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 15:59:59','2019-01-03 19:59:59','MTHBTC','4h','0.000004510000000','0.000004480000000','0.001467500000000','0.001457738359202','325.3880266075388','325.388026607538791','test'),('2019-01-04 07:59:59','2019-01-04 11:59:59','MTHBTC','4h','0.000004500000000','0.000004510000000','0.001467500000000','0.001470761111111','326.11111111111114','326.111111111111143','test'),('2019-01-09 11:59:59','2019-01-09 15:59:59','MTHBTC','4h','0.000004620000000','0.000004620000000','0.001467500000000','0.001467500000000','317.6406926406927','317.640692640692691','test'),('2019-01-15 11:59:59','2019-01-15 23:59:59','MTHBTC','4h','0.000004670000000','0.000004710000000','0.001467500000000','0.001480069593148','314.2398286937902','314.239828693790173','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','MTHBTC','4h','0.000004940000000','0.000004900000000','0.001469017265865','0.001457122389218','297.3719161670546','297.371916167054621','test'),('2019-01-25 07:59:59','2019-01-25 19:59:59','MTHBTC','4h','0.000004990000000','0.000004910000000','0.001469017265865','0.001445465886853','294.3922376482966','294.392237648296600','test'),('2019-01-30 03:59:59','2019-01-30 07:59:59','MTHBTC','4h','0.000004900000000','0.000004840000000','0.001469017265865','0.001451029299344','299.7994420132653','299.799442013265320','test'),('2019-01-30 19:59:59','2019-01-31 07:59:59','MTHBTC','4h','0.000004930000000','0.000004820000000','0.001469017265865','0.001436240004355','297.975104637931','297.975104637930997','test'),('2019-02-02 11:59:59','2019-02-03 11:59:59','MTHBTC','4h','0.000004820000000','0.000004750000000','0.001469017265865','0.001447682990220','304.7753663620332','304.775366362033196','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','MTHBTC','4h','0.000004690000000','0.000004690000000','0.001469017265865','0.001469017265865','313.22329762579955','313.223297625799546','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','MTHBTC','4h','0.000004720000000','0.000004630000000','0.001469017265865','0.001441006343423','311.2324715815678','311.232471581567779','test'),('2019-02-12 11:59:59','2019-02-12 15:59:59','MTHBTC','4h','0.000004670000000','0.000004670000000','0.001469017265865','0.001469017265865','314.56472502462526','314.564725024625261','test'),('2019-02-15 03:59:59','2019-02-15 07:59:59','MTHBTC','4h','0.000004660000000','0.000004630000000','0.001469017265865','0.001459560073166','315.2397566233905','315.239756623390520','test'),('2019-02-15 11:59:59','2019-02-15 15:59:59','MTHBTC','4h','0.000004640000000','0.000004490000000','0.001469017265865','0.001421527483563','316.5985486778017','316.598548677801716','test'),('2019-02-17 23:59:59','2019-02-18 07:59:59','MTHBTC','4h','0.000004620000000','0.000004550000000','0.001469017265865','0.001446759428503','317.96910516558444','317.969105165584438','test'),('2019-02-21 03:59:59','2019-02-21 07:59:59','MTHBTC','4h','0.000004570000000','0.000004540000000','0.001469017265865','0.001459373826483','321.4479794015317','321.447979401531711','test'),('2019-02-22 03:59:59','2019-02-22 15:59:59','MTHBTC','4h','0.000004570000000','0.000004590000000','0.001469017265865','0.001475446225453','321.4479794015317','321.447979401531711','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','MTHBTC','4h','0.000004570000000','0.000004520000000','0.001469017265865','0.001452944866895','321.4479794015317','321.447979401531711','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','MTHBTC','4h','0.000004590000000','0.000004540000000','0.001469017265865','0.001453014899134','320.04733461111107','320.047334611111069','test'),('2019-03-04 15:59:59','2019-03-05 19:59:59','MTHBTC','4h','0.000004620000000','0.000005170000000','0.001469017265865','0.001643900273706','317.96910516558444','317.969105165584438','test'),('2019-03-09 11:59:59','2019-03-09 15:59:59','MTHBTC','4h','0.000004790000000','0.000004740000000','0.001469017265865','0.001453683056409','306.6841891158664','306.684189115866388','test'),('2019-03-09 19:59:59','2019-03-09 23:59:59','MTHBTC','4h','0.000004770000000','0.000004750000000','0.001469017265865','0.001462857864331','307.9700767012578','307.970076701257824','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','MTHBTC','4h','0.000004900000000','0.000004890000000','0.001469017265865','0.001466019271445','299.7994420132653','299.799442013265320','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','MTHBTC','4h','0.000004890000000','0.000004850000000','0.001469017265865','0.001457000764713','300.41252880674847','300.412528806748469','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','MTHBTC','4h','0.000004870000000','0.000004880000000','0.001469017265865','0.001472033728423','301.6462558244353','301.646255824435286','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','MTHBTC','4h','0.000004930000000','0.000004950000000','0.001469017265865','0.001474976767958','297.975104637931','297.975104637930997','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','MTHBTC','4h','0.000005370000000','0.000005370000000','0.001469017265865','0.001469017265865','273.5600122653631','273.560012265363127','test'),('2019-04-09 07:59:59','2019-04-10 11:59:59','MTHBTC','4h','0.000005280000000','0.000005190000000','0.001469017265865','0.001443977198833','278.2229670198863','278.222967019886312','test'),('2019-04-17 03:59:59','2019-04-17 07:59:59','MTHBTC','4h','0.000005180000000','0.000005210000000','0.001469017265865','0.001477525087868','283.59406676930496','283.594066769304959','test'),('2019-04-17 19:59:59','2019-04-18 03:59:59','MTHBTC','4h','0.000005230000000','0.000005250000000','0.001469017265865','0.001474634922713','280.8828424216061','280.882842421606085','test'),('2019-05-16 23:59:59','2019-05-17 03:59:59','MTHBTC','4h','0.000003000000000','0.000002730000000','0.001469017265865','0.001336805711937','489.67242195499995','489.672421954999948','test'),('2019-05-17 23:59:59','2019-05-18 03:59:59','MTHBTC','4h','0.000002920000000','0.000002850000000','0.001469017265865','0.001433801098533','503.08810474828766','503.088104748287662','test'),('2019-05-21 03:59:59','2019-05-25 07:59:59','MTHBTC','4h','0.000002840000000','0.000003080000000','0.001469017265865','0.001593159570023','517.2596006566902','517.259600656690168','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','MTHBTC','4h','0.000003120000000','0.000003050000000','0.001469017265865','0.001436058545156','470.838867264423','470.838867264423016','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','MTHBTC','4h','0.000003160000000','0.000002860000000','0.001469017265865','0.001329553601384','464.8788816028481','464.878881602848082','test'),('2019-05-28 15:59:59','2019-05-28 19:59:59','MTHBTC','4h','0.000003150000000','0.000003040000000','0.001469017265865','0.001417718250232','466.3546875761905','466.354687576190486','test'),('2019-05-30 07:59:59','2019-05-30 15:59:59','MTHBTC','4h','0.000003060000000','0.000002860000000','0.001469017265865','0.001373003065482','480.07100191666666','480.071001916666660','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','MTHBTC','4h','0.000003020000000','0.000002950000000','0.001469017265865','0.001434967196789','486.4295582334437','486.429558233443686','test'),('2019-06-10 07:59:59','2019-06-11 03:59:59','MTHBTC','4h','0.000002970000000','0.000002940000000','0.001469017265865','0.001454178707624','494.61860803535353','494.618608035353532','test'),('2019-06-13 15:59:59','2019-06-16 07:59:59','MTHBTC','4h','0.000003160000000','0.000003290000000','0.001469017265865','0.001529451520473','464.8788816028481','464.878881602848082','test'),('2019-07-02 23:59:59','2019-07-03 03:59:59','MTHBTC','4h','0.000002600000000','0.000002340000000','0.001469017265865','0.001322115539278','565.0066407173076','565.006640717307619','test'),('2019-07-23 11:59:59','2019-07-23 15:59:59','MTHBTC','4h','0.000001650000000','0.000001610000000','0.001469017265865','0.001433404726086','890.3134944636363','890.313494463636289','test'),('2019-07-24 11:59:59','2019-07-25 03:59:59','MTHBTC','4h','0.000001680000000','0.000001640000000','0.001469017265865','0.001434040664297','874.4150392053571','874.415039205357061','test'),('2019-08-17 03:59:59','2019-08-17 07:59:59','MTHBTC','4h','0.000001210000000','0.000001170000000','0.001469017265865','0.001420454711622','1214.0638560867767','1214.063856086776696','test'),('2019-08-20 15:59:59','2019-09-02 23:59:59','MTHBTC','4h','0.000001250000000','0.000002110000000','0.001469017265865','0.002479701144780','1175.213812692','1175.213812691999919','test'),('2019-09-18 03:59:59','2019-09-18 15:59:59','MTHBTC','4h','0.000001560000000','0.000001610000000','0.001538902416824','0.001588226212235','986.4759082205134','986.475908220513361','test'),('2019-09-19 11:59:59','2019-09-19 19:59:59','MTHBTC','4h','0.000001580000000','0.000001580000000','0.001551233365677','0.001551233365677','981.7932694156651','981.793269415665122','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','MTHBTC','4h','0.000001650000000','0.000001510000000','0.001551233365677','0.001419613564953','940.1414337436363','940.141433743636298','test'),('2019-09-27 19:59:59','2019-09-29 15:59:59','MTHBTC','4h','0.000001630000000','0.000001650000000','0.001551233365677','0.001570266903906','951.6769114582821','951.676911458282120','test'),('2019-09-30 11:59:59','2019-10-01 19:59:59','MTHBTC','4h','0.000001680000000','0.000001670000000','0.001551233365677','0.001541999833738','923.3531938553571','923.353193855357063','test'),('2019-10-10 03:59:59','2019-10-10 07:59:59','MTHBTC','4h','0.000001860000000','0.000001790000000','0.001551233365677','0.001492853615356','833.9964331596774','833.996433159677395','test'),('2019-10-12 11:59:59','2019-10-13 15:59:59','MTHBTC','4h','0.000001920000000','0.000001820000000','0.001551233365677','0.001470439961215','807.9340446234376','807.934044623437558','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','MTHBTC','4h','0.000001850000000','0.000001820000000','0.001551233365677','0.001526078230017','838.5045219875675','838.504521987567500','test'),('2019-10-15 11:59:59','2019-10-15 19:59:59','MTHBTC','4h','0.000001850000000','0.000001820000000','0.001551233365677','0.001526078230017','838.5045219875675','838.504521987567500','test'),('2019-10-18 03:59:59','2019-10-18 07:59:59','MTHBTC','4h','0.000001820000000','0.000001770000000','0.001551233365677','0.001508617064422','852.3260250972527','852.326025097252682','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','MTHBTC','4h','0.000001820000000','0.000001820000000','0.001551233365677','0.001551233365677','852.3260250972527','852.326025097252682','test'),('2019-10-21 11:59:59','2019-10-23 15:59:59','MTHBTC','4h','0.000001820000000','0.000001810000000','0.001551233365677','0.001542710105426','852.3260250972527','852.326025097252682','test'),('2019-10-24 11:59:59','2019-10-24 15:59:59','MTHBTC','4h','0.000001830000000','0.000001860000000','0.001551233365677','0.001576663420852','847.6685058344261','847.668505834426128','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','MTHBTC','4h','0.000001650000000','0.000001610000000','0.001551233365677','0.001513627708327','940.1414337436363','940.141433743636298','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','MTHBTC','4h','0.000001630000000','0.000001570000000','0.001551233365677','0.001494132750990','951.6769114582821','951.676911458282120','test'),('2019-11-10 11:59:59','2019-11-10 15:59:59','MTHBTC','4h','0.000001570000000','0.000001580000000','0.001551233365677','0.001561113832974','988.0467297305732','988.046729730573247','test'),('2019-11-12 15:59:59','2019-11-12 19:59:59','MTHBTC','4h','0.000001570000000','0.000001570000000','0.001551233365677','0.001551233365677','988.0467297305732','988.046729730573247','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','MTHBTC','4h','0.000001570000000','0.000001550000000','0.001551233365677','0.001531472431082','988.0467297305732','988.046729730573247','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','MTHBTC','4h','0.000001580000000','0.000001610000000','0.001551233365677','0.001580687163759','981.7932694158228','981.793269415822806','test'),('2019-11-25 07:59:59','2019-11-26 15:59:59','MTHBTC','4h','0.000001650000000','0.000001610000000','0.001551233365677','0.001513627708327','940.1414337436363','940.141433743636298','test'),('2019-11-28 19:59:59','2019-11-29 11:59:59','MTHBTC','4h','0.000001640000000','0.000001600000000','0.001551233365677','0.001513398405539','945.8740034615853','945.874003461585289','test'),('2019-11-30 23:59:59','2019-12-01 03:59:59','MTHBTC','4h','0.000001610000000','0.000001580000000','0.001551233365677','0.001522328396130','963.4989848925466','963.498984892546559','test'),('2019-12-05 19:59:59','2019-12-05 23:59:59','MTHBTC','4h','0.000001620000000','0.000001620000000','0.001551233365677','0.001551233365677','957.5514602944444','957.551460294444382','test'),('2019-12-31 19:59:59','2020-01-01 15:59:59','MTHBTC','4h','0.000001360000000','0.000001390000000','0.001551233365677','0.001585451748743','1140.612768880147','1140.612768880147087','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:22:07
