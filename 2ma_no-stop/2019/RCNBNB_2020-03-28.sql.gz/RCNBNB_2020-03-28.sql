-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-15 11:59:59','2019-01-15 23:59:59','RCNBNB','4h','0.001898000000000','0.001889000000000','0.711908500000000','0.708532748419389','375.08350895679666','375.083508956796663','test'),('2019-01-18 03:59:59','2019-01-18 11:59:59','RCNBNB','4h','0.002010000000000','0.001912000000000','0.711908500000000','0.677198533333333','354.18333333333334','354.183333333333337','test'),('2019-01-18 23:59:59','2019-01-19 11:59:59','RCNBNB','4h','0.001935000000000','0.001935000000000','0.711908500000000','0.711908500000000','367.91136950904394','367.911369509043936','test'),('2019-01-20 11:59:59','2019-01-20 15:59:59','RCNBNB','4h','0.001919000000000','0.001936000000000','0.711908500000000','0.718215141219385','370.9788952579469','370.978895257946874','test'),('2019-01-23 07:59:59','2019-01-23 15:59:59','RCNBNB','4h','0.001950000000000','0.001922000000000','0.711908500000000','0.701686224102564','365.0812820512821','365.081282051282074','test'),('2019-01-29 19:59:59','2019-01-31 11:59:59','RCNBNB','4h','0.001835000000000','0.001779000000000','0.711908500000000','0.690182682016349','387.96103542234334','387.961035422343343','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','RCNBNB','4h','0.001278000000000','0.001200000000000','0.711908500000000','0.668458685446009','557.0489045383412','557.048904538341162','test'),('2019-02-21 23:59:59','2019-03-03 15:59:59','RCNBNB','4h','0.001531000000000','0.001731000000000','0.711908500000000','0.804907650881777','464.9957544088831','464.995754408883101','test'),('2019-03-04 15:59:59','2019-03-04 19:59:59','RCNBNB','4h','0.001807000000000','0.001810000000000','0.711908500000000','0.713090417819591','393.97260653016053','393.972606530160533','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','RCNBNB','4h','0.001670000000000','0.001611000000000','0.711908500000000','0.686757241616766','426.2925149700599','426.292514970059926','test'),('2019-03-09 07:59:59','2019-03-09 23:59:59','RCNBNB','4h','0.001712000000000','0.001643000000000','0.711908500000000','0.683215926109813','415.83440420560754','415.834404205607541','test'),('2019-03-10 15:59:59','2019-03-10 19:59:59','RCNBNB','4h','0.001670000000000','0.001653000000000','0.711908500000000','0.704661527245509','426.2925149700599','426.292514970059926','test'),('2019-03-15 15:59:59','2019-03-16 11:59:59','RCNBNB','4h','0.001603000000000','0.001559000000000','0.711908500000000','0.692367655333749','444.1101060511541','444.110106051154105','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','RCNBNB','4h','0.001598000000000','0.001604000000000','0.711908500000000','0.714581498122653','445.4996871088861','445.499687108886121','test'),('2019-03-19 19:59:59','2019-03-20 19:59:59','RCNBNB','4h','0.001595000000000','0.001618000000000','0.711908500000000','0.722174265203762','446.3376175548589','446.337617554858923','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','RCNBNB','4h','0.001594000000000','0.001582000000000','0.711908500000000','0.706549088456713','446.61762860727737','446.617628607277368','test'),('2019-03-27 23:59:59','2019-03-28 03:59:59','RCNBNB','4h','0.001506000000000','0.001488000000000','0.711908500000000','0.703399633466136','472.71480743691905','472.714807436919045','test'),('2019-03-28 07:59:59','2019-03-29 15:59:59','RCNBNB','4h','0.001532000000000','0.001584000000000','0.711908500000000','0.736072496083551','464.6922323759792','464.692232375979188','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','RCNBNB','4h','0.001645000000000','0.001644000000000','0.711908500000000','0.711475728875380','432.77112462006085','432.771124620060846','test'),('2019-04-07 19:59:59','2019-04-09 11:59:59','RCNBNB','4h','0.001647000000000','0.001653000000000','0.711908500000000','0.714501973588342','432.2455980570735','432.245598057073494','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','RCNBNB','4h','0.001681000000000','0.001654000000000','0.711908500000000','0.700473919690660','423.50297441998816','423.502974419988163','test'),('2019-04-16 23:59:59','2019-04-17 07:59:59','RCNBNB','4h','0.001658000000000','0.001647000000000','0.711908500000000','0.707185343486128','429.37786489746685','429.377864897466850','test'),('2019-05-02 07:59:59','2019-05-04 07:59:59','RCNBNB','4h','0.001186000000000','0.001204000000000','0.711908500000000','0.722713182124789','600.260118043845','600.260118043844955','test'),('2019-05-09 19:59:59','2019-05-09 23:59:59','RCNBNB','4h','0.001175000000000','0.001168000000000','0.711908500000000','0.707667342978723','605.8795744680851','605.879574468085139','test'),('2019-05-10 03:59:59','2019-05-10 07:59:59','RCNBNB','4h','0.001185000000000','0.001186000000000','0.711908500000000','0.712509266666667','600.7666666666667','600.766666666666652','test'),('2019-05-14 11:59:59','2019-05-14 15:59:59','RCNBNB','4h','0.001366000000000','0.001259000000000','0.711908500000000','0.656144071376281','521.1628843338214','521.162884333821353','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','RCNBNB','4h','0.001118000000000','0.001020000000000','0.711908500000000','0.649505071556351','636.7696779964222','636.769677996422161','test'),('2019-06-02 03:59:59','2019-06-03 19:59:59','RCNBNB','4h','0.001031000000000','0.001043000000000','0.711908500000000','0.720194534917556','690.5029097963143','690.502909796314270','test'),('2019-06-08 07:59:59','2019-06-08 19:59:59','RCNBNB','4h','0.001013000000000','0.000980000000000','0.711908500000000','0.688717008884501','702.7724580454097','702.772458045409735','test'),('2019-06-09 07:59:59','2019-06-09 11:59:59','RCNBNB','4h','0.001009000000000','0.000996000000000','0.711908500000000','0.702736239841427','705.5584737363728','705.558473736372775','test'),('2019-06-10 15:59:59','2019-06-11 07:59:59','RCNBNB','4h','0.001013000000000','0.000999000000000','0.711908500000000','0.702069685587364','702.7724580454097','702.772458045409735','test'),('2019-06-11 19:59:59','2019-06-12 03:59:59','RCNBNB','4h','0.001045000000000','0.000996000000000','0.711908500000000','0.678527144497608','681.252153110048','681.252153110047971','test'),('2019-06-14 15:59:59','2019-06-14 19:59:59','RCNBNB','4h','0.000989000000000','0.000970000000000','0.711908500000000','0.698231794742164','719.8265925176946','719.826592517694621','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','RCNBNB','4h','0.001003000000000','0.000976000000000','0.711908500000000','0.692744462612164','709.7791625124627','709.779162512462676','test'),('2019-06-15 15:59:59','2019-06-15 19:59:59','RCNBNB','4h','0.000983000000000','0.000973000000000','0.711908500000000','0.704666297558495','724.2202441505597','724.220244150559665','test'),('2019-06-20 23:59:59','2019-06-21 03:59:59','RCNBNB','4h','0.000994000000000','0.000947000000000','0.711908500000000','0.678246830482897','716.2057344064386','716.205734406438637','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','RCNBNB','4h','0.000849000000000','0.000869000000000','0.711908500000000','0.728679018256773','838.5259128386338','838.525912838633758','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','RCNBNB','4h','0.000860000000000','0.000796000000000','0.711908500000000','0.658929262790698','827.8005813953489','827.800581395348900','test'),('2019-07-10 19:59:59','2019-07-11 23:59:59','RCNBNB','4h','0.000837000000000','0.000739000000000','0.711908500000000','0.628554816606929','850.5477897252092','850.547789725209213','test'),('2019-07-25 15:59:59','2019-07-31 03:59:59','RCNBNB','4h','0.000645000000000','0.000670000000000','0.711908500000000','0.739501852713178','1103.7341085271319','1103.734108527131866','test'),('2019-08-04 23:59:59','2019-08-05 03:59:59','RCNBNB','4h','0.000669000000000','0.000678000000000','0.711908500000000','0.721485744394619','1064.1382660687593','1064.138266068759322','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','RCNBNB','4h','0.000561000000000','0.000534000000000','0.711908500000000','0.677645524064171','1268.999108734403','1268.999108734403080','test'),('2019-08-20 15:59:59','2019-08-20 23:59:59','RCNBNB','4h','0.000554000000000','0.000547000000000','0.711908500000000','0.702913266245487','1285.033393501805','1285.033393501804994','test'),('2019-08-21 19:59:59','2019-08-23 07:59:59','RCNBNB','4h','0.000548000000000','0.000573000000000','0.711908500000000','0.744386077554745','1299.103102189781','1299.103102189781112','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','RCNBNB','4h','0.000646000000000','0.000658000000000','0.711908500000000','0.725132806501548','1102.0255417956657','1102.025541795665731','test'),('2019-09-04 03:59:59','2019-09-05 11:59:59','RCNBNB','4h','0.000651000000000','0.000634000000000','0.711908500000000','0.693317955453149','1093.5614439324117','1093.561443932411748','test'),('2019-09-10 15:59:59','2019-09-10 19:59:59','RCNBNB','4h','0.000644000000000','0.000623000000000','0.711908500000000','0.688694092391304','1105.4479813664595','1105.447981366459544','test'),('2019-09-11 11:59:59','2019-09-11 19:59:59','RCNBNB','4h','0.000627000000000','0.000609000000000','0.711908500000000','0.691470935406699','1135.4202551834132','1135.420255183413246','test'),('2019-09-12 23:59:59','2019-09-13 03:59:59','RCNBNB','4h','0.000620000000000','0.000600000000000','0.711908500000000','0.688943709677419','1148.2395161290324','1148.239516129032381','test'),('2019-09-13 23:59:59','2019-09-14 03:59:59','RCNBNB','4h','0.000616000000000','0.000616000000000','0.711908500000000','0.711908500000000','1155.695616883117','1155.695616883117054','test'),('2019-09-15 03:59:59','2019-09-16 07:59:59','RCNBNB','4h','0.000616000000000','0.000684000000000','0.711908500000000','0.790495801948052','1155.695616883117','1155.695616883117054','test'),('2019-10-10 19:59:59','2019-10-10 23:59:59','RCNBNB','4h','0.002419000000000','0.002390000000000','0.711908500000000','0.703373838362960','294.2986771393138','294.298677139313781','test'),('2019-10-21 19:59:59','2019-10-25 03:59:59','RCNBNB','4h','0.002169000000000','0.002237000000000','0.711908500000000','0.734227438681420','328.2196864914708','328.219686491470782','test'),('2019-11-01 19:59:59','2019-11-02 03:59:59','RCNBNB','4h','0.002127000000000','0.002109000000000','0.711908500000000','0.705883886459803','334.7007522331923','334.700752233192304','test'),('2019-11-06 19:59:59','2019-11-13 07:59:59','RCNBNB','4h','0.002366000000000','0.002263000000000','0.711908500000000','0.680916709847844','300.89116652578195','300.891166525781955','test'),('2019-11-13 23:59:59','2019-11-14 03:59:59','RCNBNB','4h','0.002267000000000','0.002232000000000','0.711908500000000','0.700917411557124','314.0310983678871','314.031098367887125','test'),('2019-11-14 19:59:59','2019-11-15 19:59:59','RCNBNB','4h','0.002282000000000','0.002231000000000','0.711908500000000','0.695998187335670','311.9669149868536','311.966914986853624','test'),('2019-11-16 15:59:59','2019-11-17 19:59:59','RCNBNB','4h','0.002269000000000','0.002342000000000','0.711908500000000','0.734812563684442','313.75429704715737','313.754297047157365','test'),('2019-12-06 11:59:59','2019-12-08 07:59:59','RCNBNB','4h','0.003092000000000','0.003073000000000','0.711908500000000','0.707533900549806','230.2420763260026','230.242076326002604','test'),('2019-12-08 15:59:59','2019-12-08 19:59:59','RCNBNB','4h','0.003148000000000','0.003094000000000','0.711908500000000','0.699696600698856','226.1462833545108','226.146283354510814','test'),('2019-12-15 23:59:59','2019-12-16 23:59:59','RCNBNB','4h','0.003040000000000','0.003136000000000','0.711908500000000','0.734389821052632','234.18042763157897','234.180427631578965','test'),('2019-12-27 15:59:59','2019-12-27 19:59:59','RCNBNB','4h','0.003376000000000','0.003296000000000','0.711908500000000','0.695038630331754','210.8733708530806','210.873370853080587','test'),('2020-01-01 11:59:59','2020-01-01 15:59:59','RCNBNB','4h','0.003374000000000','0.003404000000000','0.711908500000000','0.718238451096621','210.99836988737405','210.998369887374054','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:11:11
