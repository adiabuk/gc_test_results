-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 23:59:59','2019-01-05 07:59:59','STORJBTC','4h','0.000038190000000','0.000037760000000','0.001467500000000','0.001450976695470','38.42628960460854','38.426289604608542','test'),('2019-01-05 15:59:59','2019-01-07 03:59:59','STORJBTC','4h','0.000038330000000','0.000037990000000','0.001467500000000','0.001454482781111','38.28593790764415','38.285937907644147','test'),('2019-01-09 11:59:59','2019-01-09 23:59:59','STORJBTC','4h','0.000038340000000','0.000038300000000','0.001467500000000','0.001465968961920','38.27595200834637','38.275952008346373','test'),('2019-01-15 23:59:59','2019-01-18 11:59:59','STORJBTC','4h','0.000036840000000','0.000036320000000','0.001467500000000','0.001446786102063','39.83441910966341','39.834419109663408','test'),('2019-01-18 19:59:59','2019-01-18 23:59:59','STORJBTC','4h','0.000036820000000','0.000036640000000','0.001467500000000','0.001460325909832','39.85605649103748','39.856056491037478','test'),('2019-01-31 11:59:59','2019-01-31 23:59:59','STORJBTC','4h','0.000038730000000','0.000038360000000','0.001467500000000','0.001453480506068','37.890524141492385','37.890524141492385','test'),('2019-02-01 23:59:59','2019-02-02 03:59:59','STORJBTC','4h','0.000038320000000','0.000037390000000','0.001467500000000','0.001431884786013','38.295929018789145','38.295929018789145','test'),('2019-02-03 11:59:59','2019-02-03 15:59:59','STORJBTC','4h','0.000038610000000','0.000038230000000','0.001467500000000','0.001453056850557','38.00828800828801','38.008288008288012','test'),('2019-02-07 11:59:59','2019-02-08 19:59:59','STORJBTC','4h','0.000044370000000','0.000039350000000','0.001467500000000','0.001301467771016','33.074149199909854','33.074149199909854','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','STORJBTC','4h','0.000039540000000','0.000039200000000','0.001467500000000','0.001454881133030','37.114314618108246','37.114314618108246','test'),('2019-02-10 23:59:59','2019-02-11 03:59:59','STORJBTC','4h','0.000039780000000','0.000038870000000','0.001467500000000','0.001433929738562','36.89039718451483','36.890397184514832','test'),('2019-02-11 11:59:59','2019-02-12 07:59:59','STORJBTC','4h','0.000040080000000','0.000040000000000','0.001467500000000','0.001464570858283','36.61427145708583','36.614271457085827','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','STORJBTC','4h','0.000040420000000','0.000040520000000','0.001467500000000','0.001471130628402','36.30628401781296','36.306284017812963','test'),('2019-02-26 15:59:59','2019-02-28 07:59:59','STORJBTC','4h','0.000058220000000','0.000057600000000','0.001467500000000','0.001451872208863','25.20611473720371','25.206114737203709','test'),('2019-03-01 11:59:59','2019-03-03 19:59:59','STORJBTC','4h','0.000058950000000','0.000058860000000','0.001467500000000','0.001465259541985','24.893977947413063','24.893977947413063','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','STORJBTC','4h','0.000058190000000','0.000057740000000','0.001467500000000','0.001456151400584','25.219109812682593','25.219109812682593','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','STORJBTC','4h','0.000057950000000','0.000057040000000','0.001467500000000','0.001444455565142','25.323554788610874','25.323554788610874','test'),('2019-03-09 07:59:59','2019-03-09 11:59:59','STORJBTC','4h','0.000057520000000','0.000056940000000','0.001467500000000','0.001452702538248','25.51286509040334','25.512865090403341','test'),('2019-03-10 03:59:59','2019-03-21 15:59:59','STORJBTC','4h','0.000057450000000','0.000065250000000','0.001467500000000','0.001666742819843','25.543951261966928','25.543951261966928','test'),('2019-05-03 23:59:59','2019-05-04 03:59:59','STORJBTC','4h','0.000045560000000','0.000043060000000','0.001467500000000','0.001386974319579','32.21027216856892','32.210272168568920','test'),('2019-05-17 15:59:59','2019-05-17 23:59:59','STORJBTC','4h','0.000035550000000','0.000036000000000','0.001467500000000','0.001486075949367','41.279887482419134','41.279887482419134','test'),('2019-05-22 03:59:59','2019-05-22 11:59:59','STORJBTC','4h','0.000034500000000','0.000034350000000','0.001467500000000','0.001461119565217','42.536231884057976','42.536231884057976','test'),('2019-06-06 23:59:59','2019-06-07 03:59:59','STORJBTC','4h','0.000033160000000','0.000032800000000','0.001467500000000','0.001451568154403','44.25512665862485','44.255126658624853','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','STORJBTC','4h','0.000033670000000','0.000034720000000','0.001467500000000','0.001513264033264','43.58479358479359','43.584793584793587','test'),('2019-07-02 03:59:59','2019-07-02 11:59:59','STORJBTC','4h','0.000024620000000','0.000024450000000','0.001467500000000','0.001457366978067','59.606011372867584','59.606011372867584','test'),('2019-07-05 15:59:59','2019-07-05 23:59:59','STORJBTC','4h','0.000023950000000','0.000024510000000','0.001467500000000','0.001501813152401','61.27348643006263','61.273486430062633','test'),('2019-07-22 07:59:59','2019-07-23 15:59:59','STORJBTC','4h','0.000017950000000','0.000017720000000','0.001467500000000','0.001448696378830','81.7548746518106','81.754874651810596','test'),('2019-07-24 19:59:59','2019-07-25 03:59:59','STORJBTC','4h','0.000017770000000','0.000017740000000','0.001467500000000','0.001465022509848','82.5830050647158','82.583005064715806','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','STORJBTC','4h','0.000017930000000','0.000018170000000','0.001467500000000','0.001487143056330','81.84606804238706','81.846068042387060','test'),('2019-07-28 19:59:59','2019-07-29 03:59:59','STORJBTC','4h','0.000018210000000','0.000018160000000','0.001467500000000','0.001463470620538','80.58758923668314','80.587589236683144','test'),('2019-08-18 11:59:59','2019-08-18 15:59:59','STORJBTC','4h','0.000013900000000','0.000014030000000','0.001467500000000','0.001481224820144','105.57553956834532','105.575539568345320','test'),('2019-08-19 15:59:59','2019-08-19 19:59:59','STORJBTC','4h','0.000014120000000','0.000013730000000','0.001467500000000','0.001426967067989','103.93059490084985','103.930594900849854','test'),('2019-08-20 15:59:59','2019-08-20 23:59:59','STORJBTC','4h','0.000013980000000','0.000013950000000','0.001467500000000','0.001464350858369','104.97138769670958','104.971387696709584','test'),('2019-08-29 23:59:59','2019-08-31 11:59:59','STORJBTC','4h','0.000014810000000','0.000014730000000','0.001467500000000','0.001459572923700','99.08845374746792','99.088453747467923','test'),('2019-09-03 19:59:59','2019-09-03 23:59:59','STORJBTC','4h','0.000015120000000','0.000014840000000','0.001467500000000','0.001440324074074','97.05687830687832','97.056878306878318','test'),('2019-09-04 03:59:59','2019-09-04 15:59:59','STORJBTC','4h','0.000015120000000','0.000015200000000','0.001467500000000','0.001475264550265','97.05687830687832','97.056878306878318','test'),('2019-09-10 03:59:59','2019-09-12 03:59:59','STORJBTC','4h','0.000014510000000','0.000014620000000','0.001467500000000','0.001478625086147','101.13714679531358','101.137146795313583','test'),('2019-09-13 15:59:59','2019-09-13 19:59:59','STORJBTC','4h','0.000014640000000','0.000014640000000','0.001467500000000','0.001467500000000','100.23907103825137','100.239071038251367','test'),('2019-09-15 15:59:59','2019-09-15 19:59:59','STORJBTC','4h','0.000014720000000','0.000014470000000','0.001467500000000','0.001442576426630','99.69429347826087','99.694293478260875','test'),('2019-09-27 03:59:59','2019-09-27 07:59:59','STORJBTC','4h','0.000015100000000','0.000015120000000','0.001467500000000','0.001469443708609','97.18543046357617','97.185430463576168','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','STORJBTC','4h','0.000015080000000','0.000015060000000','0.001467500000000','0.001465553713528','97.31432360742706','97.314323607427056','test'),('2019-09-30 03:59:59','2019-09-30 07:59:59','STORJBTC','4h','0.000015110000000','0.000015030000000','0.001467500000000','0.001459730311052','97.1211118464593','97.121111846459300','test'),('2019-10-02 07:59:59','2019-10-02 15:59:59','STORJBTC','4h','0.000015330000000','0.000014840000000','0.001467500000000','0.001420593607306','95.7273320287019','95.727332028701895','test'),('2019-10-03 07:59:59','2019-10-03 11:59:59','STORJBTC','4h','0.000015220000000','0.000015010000000','0.001467500000000','0.001447251971091','96.419185282523','96.419185282523003','test'),('2019-10-03 19:59:59','2019-10-09 15:59:59','STORJBTC','4h','0.000014980000000','0.000015710000000','0.001467500000000','0.001539013684913','97.96395193591455','97.963951935914551','test'),('2019-10-13 11:59:59','2019-10-13 15:59:59','STORJBTC','4h','0.000015860000000','0.000015590000000','0.001467500000000','0.001442517339218','92.52837326607819','92.528373266078191','test'),('2019-10-13 23:59:59','2019-10-14 07:59:59','STORJBTC','4h','0.000016110000000','0.000015780000000','0.001467500000000','0.001437439478585','91.09248913718187','91.092489137181872','test'),('2019-10-15 11:59:59','2019-10-16 03:59:59','STORJBTC','4h','0.000016020000000','0.000015790000000','0.001467500000000','0.001446431023720','91.60424469413235','91.604244694132348','test'),('2019-10-24 15:59:59','2019-10-25 15:59:59','STORJBTC','4h','0.000015620000000','0.000014900000000','0.001467500000000','0.001399855953905','93.95006402048656','93.950064020486565','test'),('2019-10-28 15:59:59','2019-10-28 19:59:59','STORJBTC','4h','0.000015250000000','0.000014760000000','0.001467500000000','0.001420347540984','96.22950819672131','96.229508196721312','test'),('2019-10-28 23:59:59','2019-10-29 07:59:59','STORJBTC','4h','0.000015090000000','0.000015300000000','0.001467500000000','0.001487922465209','97.24983432736913','97.249834327369129','test'),('2019-10-30 15:59:59','2019-10-30 19:59:59','STORJBTC','4h','0.000015120000000','0.000015060000000','0.001467500000000','0.001461676587302','97.05687830687832','97.056878306878318','test'),('2019-10-31 23:59:59','2019-11-01 03:59:59','STORJBTC','4h','0.000015140000000','0.000015040000000','0.001467500000000','0.001457807133421','96.92866578599735','96.928665785997353','test'),('2019-11-02 07:59:59','2019-11-02 15:59:59','STORJBTC','4h','0.000015290000000','0.000015090000000','0.001467500000000','0.001448304447351','95.97776324395029','95.977763243950292','test'),('2019-11-05 15:59:59','2019-11-05 23:59:59','STORJBTC','4h','0.000015400000000','0.000015450000000','0.001467500000000','0.001472264610390','95.29220779220779','95.292207792207790','test'),('2019-11-08 03:59:59','2019-11-08 07:59:59','STORJBTC','4h','0.000015310000000','0.000015320000000','0.001467500000000','0.001468458523841','95.85238406270412','95.852384062704118','test'),('2019-11-26 07:59:59','2019-11-26 11:59:59','STORJBTC','4h','0.000016900000000','0.000017030000000','0.001467500000000','0.001478788461538','86.83431952662721','86.834319526627212','test'),('2019-11-29 07:59:59','2019-11-29 11:59:59','STORJBTC','4h','0.000017150000000','0.000017290000000','0.001467500000000','0.001479479591837','85.56851311953353','85.568513119533534','test'),('2019-12-02 15:59:59','2019-12-02 19:59:59','STORJBTC','4h','0.000017610000000','0.000016700000000','0.001467500000000','0.001391666666667','83.33333333333334','83.333333333333343','test'),('2019-12-20 23:59:59','2019-12-21 03:59:59','STORJBTC','4h','0.000015190000000','0.000014470000000','0.001467500000000','0.001397941079658','96.60961158657011','96.609611586570111','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:43:56
