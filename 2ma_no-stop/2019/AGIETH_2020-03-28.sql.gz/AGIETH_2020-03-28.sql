-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 15:59:59','2019-01-10 03:59:59','AGIETH','4h','0.000353870000000','0.000353480000000','0.072144500000000','0.072064989572442','203.8728911747252','203.872891174725197','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','AGIETH','4h','0.000420000000000','0.000405970000000','0.072144500000000','0.069734530154762','171.77261904761903','171.772619047619031','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','AGIETH','4h','0.000337640000000','0.000334360000000','0.072144500000000','0.071443653062433','213.67284681909726','213.672846819097259','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','AGIETH','4h','0.000336420000000','0.000333620000000','0.072144500000000','0.071544046400333','214.4477141668153','214.447714166815302','test'),('2019-03-01 07:59:59','2019-03-01 19:59:59','AGIETH','4h','0.000342380000000','0.000347120000000','0.072144500000000','0.073143287692038','210.7147029616216','210.714702961621612','test'),('2019-03-10 07:59:59','2019-03-10 11:59:59','AGIETH','4h','0.000336160000000','0.000335920000000','0.072144500000000','0.072092992741552','214.61357686815802','214.613576868158020','test'),('2019-03-13 07:59:59','2019-03-16 07:59:59','AGIETH','4h','0.000350170000000','0.000386410000000','0.072144500000000','0.079610921109747','206.02707256475426','206.027072564754263','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','AGIETH','4h','0.000381180000000','0.000383000000000','0.073300230183327','0.073650212918344','192.298206053116','192.298206053115990','test'),('2019-03-25 03:59:59','2019-03-25 07:59:59','AGIETH','4h','0.000383310000000','0.000379340000000','0.073387725867081','0.072627638022537','191.4578953512327','191.457895351232708','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','AGIETH','4h','0.000383050000000','0.000379260000000','0.073387725867081','0.072661607916327','191.58784980310926','191.587849803109265','test'),('2019-03-28 03:59:59','2019-03-29 03:59:59','AGIETH','4h','0.000382580000000','0.000375550000000','0.073387725867081','0.072039208660626','191.8232157119583','191.823215711958312','test'),('2019-04-16 11:59:59','2019-04-16 15:59:59','AGIETH','4h','0.000291000000000','0.000287320000000','0.073387725867081','0.072459661155085','252.1914978250206','252.191497825020605','test'),('2019-04-16 19:59:59','2019-04-16 23:59:59','AGIETH','4h','0.000291770000000','0.000277220000000','0.073387725867081','0.069728023322727','251.52594806553452','251.525948065534521','test'),('2019-04-20 15:59:59','2019-04-20 19:59:59','AGIETH','4h','0.000285230000000','0.000275350000000','0.073387725867081','0.070845669521091','257.29315242814926','257.293152428149256','test'),('2019-04-28 07:59:59','2019-04-28 11:59:59','AGIETH','4h','0.000255800000000','0.000250640000000','0.073387725867081','0.071907347972342','286.89494084081707','286.894940840817071','test'),('2019-05-01 19:59:59','2019-05-01 23:59:59','AGIETH','4h','0.000253670000000','0.000240810000000','0.073387725867081','0.069667277431513','289.3039218949068','289.303921894906807','test'),('2019-05-05 03:59:59','2019-05-05 19:59:59','AGIETH','4h','0.000256980000000','0.000231960000000','0.073387725867081','0.066242574877921','285.5775775044011','285.577577504401120','test'),('2019-05-07 19:59:59','2019-05-08 07:59:59','AGIETH','4h','0.000246760000000','0.000241950000000','0.073387725867081','0.071957206490275','297.4052758432526','297.405275843252582','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','AGIETH','4h','0.000198500000000','0.000191300000000','0.073387725867081','0.070725803316739','369.7114653253451','369.711465325345102','test'),('2019-05-22 07:59:59','2019-05-22 23:59:59','AGIETH','4h','0.000196090000000','0.000193480000000','0.073387725867081','0.072410919479641','374.2553208581825','374.255320858182472','test'),('2019-05-31 19:59:59','2019-06-01 03:59:59','AGIETH','4h','0.000190750000000','0.000188810000000','0.073387725867081','0.072641344801906','384.7325078221809','384.732507822180878','test'),('2019-06-02 15:59:59','2019-06-02 23:59:59','AGIETH','4h','0.000190520000000','0.000194150000000','0.073387725867081','0.074785990851846','385.19696550011025','385.196965500110252','test'),('2019-06-07 03:59:59','2019-06-09 19:59:59','AGIETH','4h','0.000196200000000','0.000199920000000','0.073387725867081','0.074779175103705','374.0454937160092','374.045493716009219','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','AGIETH','4h','0.000200960000000','0.000197170000000','0.073387725867081','0.072003671920842','365.18573779399384','365.185737793993837','test'),('2019-06-12 15:59:59','2019-06-12 19:59:59','AGIETH','4h','0.000202950000000','0.000199360000000','0.073387725867081','0.072089564074212','361.6049562309978','361.604956230997800','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','AGIETH','4h','0.000200060000000','0.000196180000000','0.073387725867081','0.071964430973728','366.8285807611767','366.828580761176681','test'),('2019-06-19 23:59:59','2019-06-20 03:59:59','AGIETH','4h','0.000186130000000','0.000185150000000','0.073387725867081','0.073001329416483','394.282092446575','394.282092446575007','test'),('2019-07-14 23:59:59','2019-07-15 03:59:59','AGIETH','4h','0.000107620000000','0.000105400000000','0.073387725867081','0.071873873874655','681.9153119037447','681.915311903744737','test'),('2019-07-15 07:59:59','2019-07-15 11:59:59','AGIETH','4h','0.000108010000000','0.000108710000000','0.073387725867081','0.073863343014632','679.4530679296454','679.453067929645385','test'),('2019-07-30 19:59:59','2019-07-31 03:59:59','AGIETH','4h','0.000140910000000','0.000135400000000','0.073387725867081','0.070518047565132','520.812758974388','520.812758974387975','test'),('2019-08-03 07:59:59','2019-08-05 03:59:59','AGIETH','4h','0.000139650000000','0.000134430000000','0.073387725867081','0.070644554159053','525.5118214613749','525.511821461374893','test'),('2019-08-07 03:59:59','2019-08-19 11:59:59','AGIETH','4h','0.000137220000000','0.000167200000000','0.073387725867081','0.089421569486780','534.8179993228466','534.817999322846617','test'),('2019-08-20 11:59:59','2019-08-23 15:59:59','AGIETH','4h','0.000177420000000','0.000171010000000','0.073387725867081','0.070736303689153','413.6384052929828','413.638405292982782','test'),('2019-08-24 03:59:59','2019-08-25 11:59:59','AGIETH','4h','0.000174070000000','0.000177460000000','0.073387725867081','0.074816946242157','421.5989307007584','421.598930700758388','test'),('2019-08-29 11:59:59','2019-08-29 15:59:59','AGIETH','4h','0.000187480000000','0.000180400000000','0.073387725867081','0.070616309720618','391.44295854000967','391.442958540009670','test'),('2019-08-31 11:59:59','2019-08-31 15:59:59','AGIETH','4h','0.000180460000000','0.000178410000000','0.073387725867081','0.072554051711991','406.6703195560291','406.670319556029085','test'),('2019-08-31 19:59:59','2019-08-31 23:59:59','AGIETH','4h','0.000183720000000','0.000179220000000','0.073387725867081','0.071590181961127','399.4542013231058','399.454201323105792','test'),('2019-09-05 11:59:59','2019-09-05 19:59:59','AGIETH','4h','0.000179250000000','0.000173050000000','0.073387725867081','0.070849349853826','409.41548600882015','409.415486008820153','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','AGIETH','4h','0.000133860000000','0.000130400000000','0.073387725867081','0.071490807209528','548.2423865761318','548.242386576131821','test'),('2019-10-04 11:59:59','2019-10-04 23:59:59','AGIETH','4h','0.000126040000000','0.000124170000000','0.073387725867081','0.072298904482033','582.2574251593225','582.257425159322452','test'),('2019-10-05 19:59:59','2019-10-06 07:59:59','AGIETH','4h','0.000124090000000','0.000122410000000','0.073387725867081','0.072394161684176','591.4072517292368','591.407251729236805','test'),('2019-10-06 15:59:59','2019-10-08 07:59:59','AGIETH','4h','0.000124580000000','0.000126120000000','0.073387725867081','0.074294910791108','589.0811194981618','589.081119498161797','test'),('2019-10-11 19:59:59','2019-10-11 23:59:59','AGIETH','4h','0.000125460000000','0.000124750000000','0.073387725867081','0.072972411939410','584.9491939030846','584.949193903084620','test'),('2019-10-17 07:59:59','2019-10-17 23:59:59','AGIETH','4h','0.000124000000000','0.000122530000000','0.073387725867081','0.072517726213657','591.8364989280726','591.836498928072615','test'),('2019-10-18 03:59:59','2019-10-18 07:59:59','AGIETH','4h','0.000124000000000','0.000122670000000','0.073387725867081','0.072600583323507','591.8364989280726','591.836498928072615','test'),('2019-10-18 15:59:59','2019-10-19 15:59:59','AGIETH','4h','0.000125040000000','0.000125410000000','0.073387725867081','0.073604884045031','586.9139944584213','586.913994458421257','test'),('2019-10-28 03:59:59','2019-10-28 15:59:59','AGIETH','4h','0.000122830000000','0.000122010000000','0.073387725867081','0.072897797224152','597.4739547918343','597.473954791834331','test'),('2019-10-31 15:59:59','2019-10-31 19:59:59','AGIETH','4h','0.000120650000000','0.000121210000000','0.073387725867081','0.073728356836709','608.2695886206465','608.269588620646459','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','AGIETH','4h','0.000121060000000','0.000120680000000','0.073387725867081','0.073157366245162','606.2095313652817','606.209531365281691','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','AGIETH','4h','0.000120850000000','0.000120260000000','0.073387725867081','0.073029440734590','607.2629364259909','607.262936425990915','test'),('2019-11-07 11:59:59','2019-11-07 15:59:59','AGIETH','4h','0.000119790000000','0.000117690000000','0.073387725867081','0.072101189225284','612.6364960938392','612.636496093839241','test'),('2019-11-12 15:59:59','2019-11-12 19:59:59','AGIETH','4h','0.000116430000000','0.000116800000000','0.073387725867081','0.073620942895088','630.3162919099975','630.316291909997517','test'),('2019-11-13 11:59:59','2019-11-13 15:59:59','AGIETH','4h','0.000115320000000','0.000115530000000','0.073387725867081','0.073521366366839','636.3833321807233','636.383332180723301','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','AGIETH','4h','0.000115290000000','0.000124840000000','0.073387725867081','0.079466768125999','636.548927635363','636.548927635363043','test'),('2019-11-18 03:59:59','2019-11-21 11:59:59','AGIETH','4h','0.000125010000000','0.000120630000000','0.073387725867081','0.070816425656715','587.0548425492441','587.054842549244086','test'),('2019-11-21 19:59:59','2019-11-22 07:59:59','AGIETH','4h','0.000126210000000','0.000121890000000','0.073387725867081','0.070875761872581','581.473146874899','581.473146874899044','test'),('2019-12-09 03:59:59','2019-12-09 15:59:59','AGIETH','4h','0.000133990000000','0.000133610000000','0.073387725867081','0.073179595888504','547.7104699386596','547.710469938659571','test'),('2019-12-17 23:59:59','2019-12-18 03:59:59','AGIETH','4h','0.000131700000000','0.000132030000000','0.073387725867081','0.073571613107295','557.2340612534624','557.234061253462414','test'),('2019-12-24 11:59:59','2019-12-24 19:59:59','AGIETH','4h','0.000137190000000','0.000136430000000','0.073387725867081','0.072981175304657','534.9349505582112','534.934950558211199','test'),('2019-12-28 11:59:59','2019-12-28 15:59:59','AGIETH','4h','0.000135600000000','0.000135400000000','0.073387725867081','0.073279484383501','541.2074178988275','541.207417898827543','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:10:03
