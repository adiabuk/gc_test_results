-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 15:59:59','2019-01-05 19:59:59','PPTBTC','4h','0.000396600000000','0.000393600000000','0.001467500000000','0.001456399394856','3.700201714573878','3.700201714573878','test'),('2019-01-06 03:59:59','2019-01-06 11:59:59','PPTBTC','4h','0.000395700000000','0.000397700000000','0.001467500000000','0.001474917235279','3.708617639625979','3.708617639625979','test'),('2019-01-13 15:59:59','2019-01-13 23:59:59','PPTBTC','4h','0.000410200000000','0.000375700000000','0.001467500000000','0.001344075451000','3.5775231594344223','3.577523159434422','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','PPTBTC','4h','0.000373800000000','0.000372600000000','0.001467500000000','0.001462788924559','3.9258962011771006','3.925896201177101','test'),('2019-01-21 19:59:59','2019-01-22 03:59:59','PPTBTC','4h','0.000372300000000','0.000371000000000','0.001467500000000','0.001462375772227','3.9417136717700783','3.941713671770078','test'),('2019-01-23 07:59:59','2019-01-23 11:59:59','PPTBTC','4h','0.000372000000000','0.000367900000000','0.001467500000000','0.001451325940860','3.94489247311828','3.944892473118280','test'),('2019-01-24 11:59:59','2019-01-24 23:59:59','PPTBTC','4h','0.000374300000000','0.000367700000000','0.001467500000000','0.001441623697569','3.9206518835158968','3.920651883515897','test'),('2019-01-26 11:59:59','2019-01-27 03:59:59','PPTBTC','4h','0.000389000000000','0.000371700000000','0.001467500000000','0.001402235861183','3.7724935732647813','3.772493573264781','test'),('2019-02-08 11:59:59','2019-02-08 15:59:59','PPTBTC','4h','0.000349000000000','0.000346100000000','0.001467500000000','0.001455305873926','4.20487106017192','4.204871060171920','test'),('2019-02-09 07:59:59','2019-02-09 11:59:59','PPTBTC','4h','0.000348900000000','0.000343700000000','0.001467500000000','0.001445628403554','4.206076239610203','4.206076239610203','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','PPTBTC','4h','0.000352600000000','0.000347400000000','0.001467500000000','0.001445857912649','4.161939875212706','4.161939875212706','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','PPTBTC','4h','0.000343100000000','0.000340200000000','0.001467500000000','0.001455096181871','4.277178665112213','4.277178665112213','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','PPTBTC','4h','0.000343400000000','0.000342200000000','0.001467500000000','0.001462371869540','4.273442050087362','4.273442050087362','test'),('2019-02-19 11:59:59','2019-02-19 15:59:59','PPTBTC','4h','0.000346100000000','0.000342700000000','0.001467500000000','0.001453083646345','4.240104016180295','4.240104016180295','test'),('2019-03-03 23:59:59','2019-03-04 11:59:59','PPTBTC','4h','0.000330000000000','0.000318200000000','0.001467500000000','0.001415025757576','4.446969696969697','4.446969696969697','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','PPTBTC','4h','0.000321000000000','0.000318500000000','0.001467500000000','0.001456070872274','4.571651090342679','4.571651090342679','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','PPTBTC','4h','0.000318600000000','0.000316000000000','0.001467500000000','0.001455524168236','4.6060891399874455','4.606089139987446','test'),('2019-03-07 15:59:59','2019-03-08 07:59:59','PPTBTC','4h','0.000323500000000','0.000317300000000','0.001467500000000','0.001439374806801','4.536321483771252','4.536321483771252','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','PPTBTC','4h','0.000318800000000','0.000317900000000','0.001467500000000','0.001463357120452','4.6031994981179425','4.603199498117942','test'),('2019-03-12 11:59:59','2019-03-21 15:59:59','PPTBTC','4h','0.000333400000000','0.000346000000000','0.001467500000000','0.001522960407918','4.4016196760647865','4.401619676064787','test'),('2019-03-22 07:59:59','2019-03-25 07:59:59','PPTBTC','4h','0.000349700000000','0.000353300000000','0.001467500000000','0.001482607234773','4.196454103517301','4.196454103517301','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','PPTBTC','4h','0.000352300000000','0.000351700000000','0.001467500000000','0.001465000709622','4.165483962531933','4.165483962531933','test'),('2019-03-26 15:59:59','2019-04-02 07:59:59','PPTBTC','4h','0.000361300000000','0.000347700000000','0.001467500000000','0.001412260586770','4.061721561029615','4.061721561029615','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','PPTBTC','4h','0.000143100000000','0.000136500000000','0.001467500000000','0.001399816561845','10.25506638714186','10.255066387141859','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','PPTBTC','4h','0.000140400000000','0.000133300000000','0.001467500000000','0.001393288817664','10.452279202279202','10.452279202279202','test'),('2019-06-04 23:59:59','2019-06-05 11:59:59','PPTBTC','4h','0.000122000000000','0.000120100000000','0.001467500000000','0.001444645491803','12.028688524590164','12.028688524590164','test'),('2019-06-06 07:59:59','2019-06-06 11:59:59','PPTBTC','4h','0.000120500000000','0.000122800000000','0.001467500000000','0.001495510373444','12.178423236514524','12.178423236514524','test'),('2019-06-07 07:59:59','2019-06-13 23:59:59','PPTBTC','4h','0.000120300000000','0.000134500000000','0.001467500000000','0.001640721113882','12.19866999168745','12.198669991687449','test'),('2019-07-06 07:59:59','2019-07-08 11:59:59','PPTBTC','4h','0.000069300000000','0.000073700000000','0.001467500000000','0.001560674603175','21.176046176046174','21.176046176046174','test'),('2019-07-12 19:59:59','2019-07-12 23:59:59','PPTBTC','4h','0.000069300000000','0.000068900000000','0.001467500000000','0.001459029581530','21.176046176046174','21.176046176046174','test'),('2019-07-17 07:59:59','2019-07-17 11:59:59','PPTBTC','4h','0.000066200000000','0.000065000000000','0.001467500000000','0.001440898791541','22.167673716012086','22.167673716012086','test'),('2019-07-17 19:59:59','2019-07-17 23:59:59','PPTBTC','4h','0.000066000000000','0.000066600000000','0.001467500000000','0.001480840909091','22.234848484848484','22.234848484848484','test'),('2019-07-19 15:59:59','2019-07-21 11:59:59','PPTBTC','4h','0.000069600000000','0.000068000000000','0.001467500000000','0.001433764367816','21.08477011494253','21.084770114942529','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','PPTBTC','4h','0.000066900000000','0.000065100000000','0.001467500000000','0.001428015695067','21.935724962630793','21.935724962630793','test'),('2019-07-23 15:59:59','2019-07-23 19:59:59','PPTBTC','4h','0.000067100000000','0.000067900000000','0.001467500000000','0.001484996274218','21.870342771982116','21.870342771982116','test'),('2019-07-24 03:59:59','2019-08-01 11:59:59','PPTBTC','4h','0.000067100000000','0.000073900000000','0.001467500000000','0.001616218330849','21.870342771982116','21.870342771982116','test'),('2019-08-22 19:59:59','2019-08-23 15:59:59','PPTBTC','4h','0.000058000000000','0.000056100000000','0.001467500000000','0.001419426724138','25.301724137931036','25.301724137931036','test'),('2019-08-24 03:59:59','2019-08-25 15:59:59','PPTBTC','4h','0.000057000000000','0.000056400000000','0.001467500000000','0.001452052631579','25.74561403508772','25.745614035087719','test'),('2019-09-11 23:59:59','2019-09-12 03:59:59','PPTBTC','4h','0.000044000000000','0.000041000000000','0.001467500000000','0.001367443181818','33.35227272727273','33.352272727272727','test'),('2019-09-18 15:59:59','2019-09-18 19:59:59','PPTBTC','4h','0.000039240000000','0.000038620000000','0.001467500000000','0.001444313200815','37.3980632008155','37.398063200815500','test'),('2019-09-19 19:59:59','2019-09-19 23:59:59','PPTBTC','4h','0.000039120000000','0.000038050000000','0.001467500000000','0.001427361324131','37.512781186094074','37.512781186094074','test'),('2019-09-20 07:59:59','2019-09-21 23:59:59','PPTBTC','4h','0.000040170000000','0.000039280000000','0.001467500000000','0.001434986308190','36.532237988548665','36.532237988548665','test'),('2019-09-23 15:59:59','2019-09-24 03:59:59','PPTBTC','4h','0.000039860000000','0.000039280000000','0.001467500000000','0.001446146512795','36.81635725037632','36.816357250376321','test'),('2019-09-25 23:59:59','2019-09-26 15:59:59','PPTBTC','4h','0.000040900000000','0.000038870000000','0.001467500000000','0.001394663202934','35.88019559902201','35.880195599022009','test'),('2019-10-11 15:59:59','2019-10-15 11:59:59','PPTBTC','4h','0.000058570000000','0.000059720000000','0.001467500000000','0.001496313812532','25.055489158272152','25.055489158272152','test'),('2019-10-24 19:59:59','2019-10-29 03:59:59','PPTBTC','4h','0.000054870000000','0.000057610000000','0.001467500000000','0.001540781392382','26.745033716056135','26.745033716056135','test'),('2019-10-29 15:59:59','2019-10-29 23:59:59','PPTBTC','4h','0.000060020000000','0.000057200000000','0.001467500000000','0.001398550483172','24.450183272242587','24.450183272242587','test'),('2019-10-30 11:59:59','2019-10-30 15:59:59','PPTBTC','4h','0.000058440000000','0.000057610000000','0.001467500000000','0.001446657683094','25.11122518822724','25.111225188227241','test'),('2019-10-30 23:59:59','2019-10-31 03:59:59','PPTBTC','4h','0.000057660000000','0.000057350000000','0.001467500000000','0.001459610215054','25.450919181408256','25.450919181408256','test'),('2019-11-02 07:59:59','2019-11-02 15:59:59','PPTBTC','4h','0.000057980000000','0.000056500000000','0.001467500000000','0.001430040531218','25.31045187995861','25.310451879958610','test'),('2019-11-05 23:59:59','2019-11-06 07:59:59','PPTBTC','4h','0.000057590000000','0.000056760000000','0.001467500000000','0.001446350060774','25.481854488626496','25.481854488626496','test'),('2019-11-08 19:59:59','2019-11-10 11:59:59','PPTBTC','4h','0.000056450000000','0.000056880000000','0.001467500000000','0.001478678476528','25.99645704162976','25.996457041629760','test'),('2019-11-11 19:59:59','2019-11-11 23:59:59','PPTBTC','4h','0.000056730000000','0.000056710000000','0.001467500000000','0.001466982637053','25.86814736471003','25.868147364710030','test'),('2019-11-19 15:59:59','2019-11-20 19:59:59','PPTBTC','4h','0.000062980000000','0.000062450000000','0.001467500000000','0.001455150444586','23.30104795173071','23.301047951730709','test'),('2019-11-21 23:59:59','2019-11-22 07:59:59','PPTBTC','4h','0.000062690000000','0.000062020000000','0.001467500000000','0.001451816079119','23.40883713510927','23.408837135109270','test'),('2019-11-23 03:59:59','2019-11-23 07:59:59','PPTBTC','4h','0.000062670000000','0.000063150000000','0.001467500000000','0.001478739827669','23.41630764321047','23.416307643210470','test'),('2019-12-06 15:59:59','2019-12-06 19:59:59','PPTBTC','4h','0.000070800000000','0.000070200000000','0.001467500000000','0.001455063559322','20.727401129943505','20.727401129943505','test'),('2019-12-07 23:59:59','2019-12-08 03:59:59','PPTBTC','4h','0.000070520000000','0.000069590000000','0.001467500000000','0.001448146979580','20.80969937606353','20.809699376063531','test'),('2019-12-08 19:59:59','2019-12-09 15:59:59','PPTBTC','4h','0.000071200000000','0.000068700000000','0.001467500000000','0.001415972612360','20.610955056179776','20.610955056179776','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:56:18
