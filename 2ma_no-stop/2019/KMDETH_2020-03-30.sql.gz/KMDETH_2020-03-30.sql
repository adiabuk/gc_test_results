-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 23:59:59','KMDETH','4h','0.005477000000000','0.005267000000000','0.072144500000000','0.069378324173818','13.172265838962936','13.172265838962936','test'),('2019-01-12 23:59:59','2019-01-14 15:59:59','KMDETH','4h','0.005351000000000','0.005260000000000','0.072144500000000','0.070917598579705','13.482433190057934','13.482433190057934','test'),('2019-01-16 03:59:59','2019-01-16 15:59:59','KMDETH','4h','0.005343000000000','0.005500000000000','0.072144500000000','0.074264411379375','13.502620250795434','13.502620250795434','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','KMDETH','4h','0.005712000000000','0.005720000000000','0.072144500000000','0.072245542717087','12.630339635854341','12.630339635854341','test'),('2019-02-16 15:59:59','2019-02-16 19:59:59','KMDETH','4h','0.006044000000000','0.006198000000000','0.072144500000000','0.073982728491066','11.936548643282595','11.936548643282595','test'),('2019-02-21 23:59:59','2019-02-22 03:59:59','KMDETH','4h','0.006378000000000','0.006283000000000','0.072161026335263','0.071086191355356','11.314052420078825','11.314052420078825','test'),('2019-02-22 19:59:59','2019-02-23 15:59:59','KMDETH','4h','0.006433000000000','0.006274000000000','0.072161026335263','0.070377472287804','11.217321053204259','11.217321053204259','test'),('2019-02-24 03:59:59','2019-02-27 15:59:59','KMDETH','4h','0.006544000000000','0.007457000000000','0.072161026335263','0.082228724538823','11.027051701598868','11.027051701598868','test'),('2019-03-05 15:59:59','2019-03-05 19:59:59','KMDETH','4h','0.007087000000000','0.006950000000000','0.073963353629311','0.072533555485214','10.436482803627944','10.436482803627944','test'),('2019-03-09 23:59:59','2019-03-10 03:59:59','KMDETH','4h','0.006897000000000','0.006938000000000','0.073963353629311','0.074403037187206','10.723989216950994','10.723989216950994','test'),('2019-03-12 11:59:59','2019-03-13 03:59:59','KMDETH','4h','0.007010000000000','0.010143000000000','0.073963353629311','0.107020013675050','10.551120346549359','10.551120346549359','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','KMDETH','4h','0.007680000000000','0.007700000000000','0.081979989994196','0.082193479551473','10.674477863827539','10.674477863827539','test'),('2019-03-28 07:59:59','2019-03-30 03:59:59','KMDETH','4h','0.007744000000000','0.007515000000000','0.082033362383515','0.079607530773775','10.593151134234859','10.593151134234859','test'),('2019-03-30 15:59:59','2019-03-30 23:59:59','KMDETH','4h','0.007842000000000','0.007691000000000','0.082033362383515','0.080453786035656','10.460770515622928','10.460770515622928','test'),('2019-04-17 15:59:59','2019-04-18 03:59:59','KMDETH','4h','0.007138000000000','0.006620000000000','0.082033362383515','0.076080254830326','11.492485623916362','11.492485623916362','test'),('2019-04-27 11:59:59','2019-04-27 19:59:59','KMDETH','4h','0.006428000000000','0.006223000000000','0.082033362383515','0.079417177055478','12.761879648960019','12.761879648960019','test'),('2019-04-27 23:59:59','2019-04-28 07:59:59','KMDETH','4h','0.006382000000000','0.006296000000000','0.082033362383515','0.080927930048043','12.853864365953463','12.853864365953463','test'),('2019-04-28 23:59:59','2019-04-29 15:59:59','KMDETH','4h','0.006394000000000','0.006246000000000','0.082033362383515','0.080134560751867','12.82974075438145','12.829740754381451','test'),('2019-05-02 11:59:59','2019-05-03 03:59:59','KMDETH','4h','0.006335000000000','0.006228000000000','0.082033362383515','0.080647794936785','12.949228474114442','12.949228474114442','test'),('2019-05-04 03:59:59','2019-05-04 07:59:59','KMDETH','4h','0.006269000000000','0.006192000000000','0.082033362383515','0.081025774426340','13.085557885390811','13.085557885390811','test'),('2019-05-04 11:59:59','2019-05-04 15:59:59','KMDETH','4h','0.006284000000000','0.006222000000000','0.082033362383515','0.081223994390552','13.054322467141152','13.054322467141152','test'),('2019-05-04 19:59:59','2019-05-06 15:59:59','KMDETH','4h','0.006257000000000','0.006167000000000','0.082033362383515','0.080853403519120','13.110654048827712','13.110654048827712','test'),('2019-05-07 19:59:59','2019-05-10 19:59:59','KMDETH','4h','0.006528000000000','0.006568000000000','0.082033362383515','0.082536017790277','12.56638516904335','12.566385169043350','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','KMDETH','4h','0.005142000000000','0.004927000000000','0.082033362383515','0.078603340424655','15.953590506323415','15.953590506323415','test'),('2019-05-28 15:59:59','2019-05-28 19:59:59','KMDETH','4h','0.005071000000000','0.004923000000000','0.082033362383515','0.079639172355363','16.176959649677578','16.176959649677578','test'),('2019-06-30 23:59:59','2019-07-01 03:59:59','KMDETH','4h','0.004700000000000','0.004539000000000','0.082033362383515','0.079223283374207','17.45390689010957','17.453906890109572','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','KMDETH','4h','0.004639000000000','0.004941000000000','0.082033362383515','0.087373753726438','17.683415042792628','17.683415042792628','test'),('2019-07-02 23:59:59','2019-07-03 03:59:59','KMDETH','4h','0.004664000000000','0.004675000000000','0.082033362383515','0.082226837294797','17.588628298352273','17.588628298352273','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','KMDETH','4h','0.004664000000000','0.004557000000000','0.082033362383515','0.080151379155591','17.588628298352273','17.588628298352273','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','KMDETH','4h','0.004624000000000','0.004415000000000','0.082033362383515','0.078325539559520','17.74077906217885','17.740779062178849','test'),('2019-07-04 15:59:59','2019-07-08 15:59:59','KMDETH','4h','0.004983000000000','0.005029000000000','0.082033362383515','0.082790644075195','16.46264547130544','16.462645471305439','test'),('2019-07-11 11:59:59','2019-07-11 15:59:59','KMDETH','4h','0.005075000000000','0.005565000000000','0.082033362383515','0.089953824958475','16.1642093366532','16.164209336653201','test'),('2019-07-23 11:59:59','2019-07-24 11:59:59','KMDETH','4h','0.005752000000000','0.005477000000000','0.082033362383515','0.078111391824498','14.261711123698712','14.261711123698712','test'),('2019-08-12 19:59:59','2019-08-12 23:59:59','KMDETH','4h','0.004457000000000','0.004369000000000','0.082033362383515','0.080413677418348','18.40551096780682','18.405510967806819','test'),('2019-08-15 11:59:59','2019-08-16 11:59:59','KMDETH','4h','0.004320000000000','0.004323000000000','0.082033362383515','0.082090329996281','18.989204255443287','18.989204255443287','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','KMDETH','4h','0.004319000000000','0.004449000000000','0.082033362383515','0.084502530503417','18.993600922323456','18.993600922323456','test'),('2019-09-06 03:59:59','2019-09-06 07:59:59','KMDETH','4h','0.004053000000000','0.004136000000000','0.082033362383515','0.083713295538667','20.240158495809276','20.240158495809276','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','KMDETH','4h','0.003414000000000','0.003335000000000','0.082033362383515','0.080135109416820','24.028518565763033','24.028518565763033','test'),('2019-09-27 15:59:59','2019-09-27 19:59:59','KMDETH','4h','0.003421000000000','0.003390000000000','0.082033362383515','0.081290002478841','23.97935176366998','23.979351763669978','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','KMDETH','4h','0.003399000000000','0.003421000000000','0.082033362383515','0.082564322657842','24.13455792395263','24.134557923952631','test'),('2019-10-03 11:59:59','2019-10-03 23:59:59','KMDETH','4h','0.003386000000000','0.003367000000000','0.082033362383515','0.081573045228971','24.227218660222974','24.227218660222974','test'),('2019-10-11 07:59:59','2019-10-12 03:59:59','KMDETH','4h','0.003439000000000','0.003356000000000','0.082033362383515','0.080053493503657','23.85384192600029','23.853841926000289','test'),('2019-10-28 15:59:59','2019-10-29 03:59:59','KMDETH','4h','0.003205000000000','0.003120000000000','0.082033362383515','0.079857750588632','25.595432880971916','25.595432880971916','test'),('2019-11-02 07:59:59','2019-11-02 11:59:59','KMDETH','4h','0.003053000000000','0.003048000000000','0.082033362383515','0.081899013607911','26.86975512070586','26.869755120705861','test'),('2019-11-02 19:59:59','2019-11-20 19:59:59','KMDETH','4h','0.003195000000000','0.004748000000000','0.082033362383515','0.121907481876973','25.675543782007825','25.675543782007825','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','KMDETH','4h','0.004804000000000','0.004568000000000','0.085084983750346','0.080905121934134','17.711278882253442','17.711278882253442','test'),('2019-11-26 07:59:59','2019-11-26 11:59:59','KMDETH','4h','0.004718000000000','0.004730000000000','0.085084983750346','0.085301393204565','18.034121184897412','18.034121184897412','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','KMDETH','4h','0.004701000000000','0.004751000000000','0.085084983750346','0.085989950605806','18.09933710919932','18.099337109199318','test'),('2019-12-03 07:59:59','2019-12-03 19:59:59','KMDETH','4h','0.005063000000000','0.004607000000000','0.085084983750346','0.077421789480119','16.80525059260241','16.805250592602409','test'),('2019-12-07 15:59:59','2019-12-07 19:59:59','KMDETH','4h','0.004729000000000','0.004542000000000','0.085084983750346','0.081720447492931','17.992172499544512','17.992172499544512','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','KMDETH','4h','0.004269000000000','0.004254000000000','0.085084983750346','0.084786020349958','19.93089335918154','19.930893359181539','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','KMDETH','4h','0.004224000000000','0.004040000000000','0.085084983750346','0.081378630291524','20.143225319684184','20.143225319684184','test'),('2019-12-19 11:59:59','2019-12-19 19:59:59','KMDETH','4h','0.004224000000000','0.004189000000000','0.085084983750346','0.084379970864157','20.143225319684184','20.143225319684184','test'),('2019-12-23 07:59:59','2019-12-23 11:59:59','KMDETH','4h','0.004232000000000','0.004484000000000','0.085084983750346','0.090151480892380','20.10514738902316','20.105147389023159','test'),('2019-12-27 07:59:59','2019-12-27 15:59:59','KMDETH','4h','0.004310000000000','0.004250000000000','0.085084983750346','0.083900506018323','19.741295533722973','19.741295533722973','test'),('2019-12-28 15:59:59','2019-12-28 19:59:59','KMDETH','4h','0.004287000000000','0.004117000000000','0.085084983750346','0.081710958269227','19.847208712466994','19.847208712466994','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 11:10:55
