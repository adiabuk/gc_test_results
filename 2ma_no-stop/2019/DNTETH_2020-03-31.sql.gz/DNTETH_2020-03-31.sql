-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 23:59:59','2019-01-10 03:59:59','DNTETH','4h','0.000083820000000','0.000084680000000','0.072144500000000','0.072884708422811','860.7074683846338','860.707468384633785','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','DNTETH','4h','0.000102240000000','0.000101650000000','0.072329552105703','0.071912157389913','707.448670830426','707.448670830425954','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','DNTETH','4h','0.000103300000000','0.000102100000000','0.072329552105703','0.071489324975724','700.1892749826039','700.189274982603933','test'),('2019-02-07 15:59:59','2019-02-07 19:59:59','DNTETH','4h','0.000100030000000','0.000097150000000','0.072329552105703','0.070247085744967','723.0785974777866','723.078597477786616','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','DNTETH','4h','0.000099470000000','0.000096690000000','0.072329552105703','0.070308076737714','727.1494129456419','727.149412945641870','test'),('2019-02-25 23:59:59','2019-03-05 19:59:59','DNTETH','4h','0.000086830000000','0.000093970000000','0.072329552105703','0.078277185435597','833.0018669319705','833.001866931970540','test'),('2019-03-26 03:59:59','2019-03-26 07:59:59','DNTETH','4h','0.000106300000000','0.000103890000000','0.072476069544553','0.070832915004549','681.8068630719921','681.806863071992098','test'),('2019-03-26 15:59:59','2019-03-30 07:59:59','DNTETH','4h','0.000107090000000','0.000112970000000','0.072476069544553','0.076455519436438','676.7771924974601','676.777192497460078','test'),('2019-04-14 11:59:59','2019-04-16 19:59:59','DNTETH','4h','0.000107720000000','0.000104280000000','0.073060143382523','0.070726993612416','678.2412122402804','678.241212240280447','test'),('2019-04-21 19:59:59','2019-04-22 03:59:59','DNTETH','4h','0.000102660000000','0.000102830000000','0.073060143382523','0.073181127450076','711.6709856080557','711.670985608055730','test'),('2019-04-30 19:59:59','2019-05-01 03:59:59','DNTETH','4h','0.000095790000000','0.000094570000000','0.073060143382523','0.072129635240476','762.7115918417684','762.711591841768382','test'),('2019-05-02 19:59:59','2019-05-03 11:59:59','DNTETH','4h','0.000095590000000','0.000094760000000','0.073060143382523','0.072425768249062','764.3073897115074','764.307389711507426','test'),('2019-05-03 19:59:59','2019-05-04 03:59:59','DNTETH','4h','0.000097650000000','0.000095710000000','0.073060143382523','0.071608666903648','748.1837519971633','748.183751997163313','test'),('2019-05-04 19:59:59','2019-05-05 07:59:59','DNTETH','4h','0.000095900000000','0.000095810000000','0.073060143382523','0.072991578075907','761.836740172294','761.836740172293958','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','DNTETH','4h','0.000075880000000','0.000069800000000','0.073060143382523','0.067206088667635','962.8379465277147','962.837946527714735','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','DNTETH','4h','0.000073950000000','0.000072140000000','0.073060143382523','0.071271923510686','987.966780020595','987.966780020595024','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','DNTETH','4h','0.000073830000000','0.000073150000000','0.073060143382523','0.072387234029955','989.5725773062845','989.572577306284529','test'),('2019-05-27 23:59:59','2019-05-30 03:59:59','DNTETH','4h','0.000076090000000','0.000072510000000','0.073060143382523','0.069622696762607','960.1806200883558','960.180620088355795','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','DNTETH','4h','0.000075100000000','0.000075300000000','0.073060143382523','0.073254711008042','972.8381275968442','972.838127596844174','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','DNTETH','4h','0.000074690000000','0.000074030000000','0.073060143382523','0.072414545650130','978.1783824142856','978.178382414285579','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','DNTETH','4h','0.000074600000000','0.000073370000000','0.073060143382523','0.071855532439353','979.3584903823458','979.358490382345849','test'),('2019-06-07 07:59:59','2019-06-07 15:59:59','DNTETH','4h','0.000073840000000','0.000072540000000','0.073060143382523','0.071773873252549','989.4385615184588','989.438561518458755','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','DNTETH','4h','0.000077730000000','0.000075220000000','0.073060143382523','0.070700938958361','939.922081339547','939.922081339547049','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','DNTETH','4h','0.000074350000000','0.000073810000000','0.073060143382523','0.072529511540875','982.6515586082446','982.651558608244613','test'),('2019-06-11 19:59:59','2019-06-12 15:59:59','DNTETH','4h','0.000075440000000','0.000072750000000','0.073060143382523','0.070455003063077','968.4536503515774','968.453650351577380','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','DNTETH','4h','0.000080770000000','0.000072960000000','0.073060143382523','0.065995642703837','904.545541445128','904.545541445128038','test'),('2019-06-30 07:59:59','2019-06-30 15:59:59','DNTETH','4h','0.000056750000000','0.000054900000000','0.073060143382523','0.070678447078423','1287.4034076215505','1287.403407621550514','test'),('2019-07-01 03:59:59','2019-07-01 15:59:59','DNTETH','4h','0.000058860000000','0.000056120000000','0.073060143382523','0.069659110544125','1241.2528607292388','1241.252860729238819','test'),('2019-07-14 11:59:59','2019-07-15 11:59:59','DNTETH','4h','0.000050000000000','0.000049480000000','0.073060143382523','0.072300317891345','1461.20286765046','1461.202867650459893','test'),('2019-07-22 11:59:59','2019-07-23 07:59:59','DNTETH','4h','0.000049120000000','0.000046660000000','0.073060143382523','0.069401186690320','1487.3807691881718','1487.380769188171826','test'),('2019-07-26 11:59:59','2019-07-26 23:59:59','DNTETH','4h','0.000047330000000','0.000046550000000','0.073060143382523','0.071856109749766','1543.6328625084088','1543.632862508408834','test'),('2019-07-28 23:59:59','2019-07-29 03:59:59','DNTETH','4h','0.000046690000000','0.000046390000000','0.073060143382523','0.072590705751023','1564.7921050015632','1564.792105001563186','test'),('2019-07-30 23:59:59','2019-07-31 15:59:59','DNTETH','4h','0.000049020000000','0.000046430000000','0.073060143382523','0.069199968528163','1490.4150016834556','1490.415001683455557','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','DNTETH','4h','0.000035570000000','0.000034880000000','0.073060143382523','0.071642895731864','2053.9821024043576','2053.982102404357647','test'),('2019-08-22 11:59:59','2019-08-22 15:59:59','DNTETH','4h','0.000035180000000','0.000034630000000','0.073060143382523','0.071917929657100','2076.7522280421545','2076.752228042154456','test'),('2019-08-23 03:59:59','2019-08-23 07:59:59','DNTETH','4h','0.000035200000000','0.000034600000000','0.073060143382523','0.071814800029412','2075.5722551853123','2075.572255185312315','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','DNTETH','4h','0.000037430000000','0.000034980000000','0.073060143382523','0.068277953927883','1951.9140631184343','1951.914063118434342','test'),('2019-09-04 19:59:59','2019-09-05 19:59:59','DNTETH','4h','0.000039590000000','0.000039920000000','0.073060143382523','0.073669131695638','1845.4191306522605','1845.419130652260492','test'),('2019-09-09 23:59:59','2019-09-11 15:59:59','DNTETH','4h','0.000039210000000','0.000039840000000','0.073060143382523','0.074234024798769','1863.3038353104564','1863.303835310456407','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','DNTETH','4h','0.000038020000000','0.000035860000000','0.073060143382523','0.068909435604873','1921.6239711342187','1921.623971134218664','test'),('2019-09-19 11:59:59','2019-09-19 19:59:59','DNTETH','4h','0.000036910000000','0.000036190000000','0.073060143382523','0.071634965836183','1979.4132588058249','1979.413258805824853','test'),('2019-09-22 07:59:59','2019-09-22 15:59:59','DNTETH','4h','0.000037860000000','0.000039180000000','0.073060143382523','0.075607406701723','1929.744938788246','1929.744938788245918','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','DNTETH','4h','0.000037320000000','0.000034230000000','0.073060143382523','0.067010951446510','1957.6672932080114','1957.667293208011415','test'),('2019-09-29 03:59:59','2019-09-29 11:59:59','DNTETH','4h','0.000037020000000','0.000035760000000','0.073060143382523','0.070573493445679','1973.5316959082386','1973.531695908238589','test'),('2019-10-02 15:59:59','2019-10-09 15:59:59','DNTETH','4h','0.000036500000000','0.000038480000000','0.073060143382523','0.077023405955054','2001.6477639047396','2001.647763904739577','test'),('2019-10-10 11:59:59','2019-10-11 03:59:59','DNTETH','4h','0.000039360000000','0.000039660000000','0.073060143382523','0.073617004231475','1856.202829840523','1856.202829840523009','test'),('2019-10-15 15:59:59','2019-10-15 19:59:59','DNTETH','4h','0.000039820000000','0.000039810000000','0.073060143382523','0.073041795782477','1834.7600045837014','1834.760004583701402','test'),('2019-10-16 07:59:59','2019-10-16 11:59:59','DNTETH','4h','0.000039480000000','0.000038400000000','0.073060143382523','0.071061537636497','1850.5608759504303','1850.560875950430272','test'),('2019-10-21 07:59:59','2019-10-21 11:59:59','DNTETH','4h','0.000038180000000','0.000037810000000','0.073060143382523','0.072352122087302','1913.5710681645626','1913.571068164562575','test'),('2019-10-25 07:59:59','2019-10-25 11:59:59','DNTETH','4h','0.000037670000000','0.000037110000000','0.073060143382523','0.071974035596640','1939.4781890767986','1939.478189076798571','test'),('2019-11-03 23:59:59','2019-11-04 07:59:59','DNTETH','4h','0.000035850000000','0.000035030000000','0.073060143382523','0.071389032711012','2037.9398433060808','2037.939843306080775','test'),('2019-11-07 11:59:59','2019-11-08 11:59:59','DNTETH','4h','0.000034950000000','0.000034130000000','0.073060143382523','0.071345999818183','2090.4189809019454','2090.418980901945361','test'),('2019-11-16 03:59:59','2019-11-18 11:59:59','DNTETH','4h','0.000034290000000','0.000033830000000','0.073060143382523','0.072080042304776','2130.6545168423154','2130.654516842315388','test'),('2019-11-19 11:59:59','2019-11-19 15:59:59','DNTETH','4h','0.000034340000000','0.000034420000000','0.073060143382523','0.073230347560467','2127.5522243017763','2127.552224301776278','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','DNTETH','4h','0.000034020000000','0.000033540000000','0.073060143382523','0.072029312435327','2147.5644733251906','2147.564473325190647','test'),('2019-11-25 07:59:59','2019-11-27 19:59:59','DNTETH','4h','0.000039620000000','0.000037080000000','0.073060143382523','0.068376328031902','1844.0217915831145','1844.021791583114464','test'),('2019-12-13 23:59:59','2019-12-14 03:59:59','DNTETH','4h','0.000041030000000','0.000040480000000','0.048706762255015','0.048053856594760','1187.1012004634495','1187.101200463449459','test'),('2019-12-16 19:59:59','2019-12-17 03:59:59','DNTETH','4h','0.000043070000000','0.000041110000000','0.053933013971834','0.051478667387557','1252.2176450391012','1252.217645039101171','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','DNTETH','4h','0.000040440000000','0.000040280000000','0.053933013971834','0.053719629148998','1333.6551427258655','1333.655142725865517','test'),('2019-12-19 11:59:59','2019-12-20 23:59:59','DNTETH','4h','0.000041370000000','0.000041490000000','0.053933013971834','0.054089454911564','1303.6744977479816','1303.674497747981604','test'),('2019-12-24 11:59:59','2019-12-25 19:59:59','DNTETH','4h','0.000041890000000','0.000041840000000','0.053933013971834','0.053868639402758','1287.4913815190737','1287.491381519073684','test'),('2019-12-27 07:59:59','2019-12-27 23:59:59','DNTETH','4h','0.000042330000000','0.000041400000000','0.053933013971834','0.052748093041198','1274.1085275651783','1274.108527565178292','test'),('2019-12-28 03:59:59','2019-12-28 19:59:59','DNTETH','4h','0.000042340000000','0.000041570000000','0.053933013971834','0.052952182116418','1273.807604436325','1273.807604436324937','test'),('2019-12-29 03:59:59','2019-12-29 07:59:59','DNTETH','4h','0.000042230000000','0.000041710000000','0.053933013971834','0.053268908661264','1277.1255972492067','1277.125597249206749','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  7:49:00
