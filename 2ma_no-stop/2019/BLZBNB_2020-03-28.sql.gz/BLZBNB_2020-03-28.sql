-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 15:59:59','2019-01-03 19:59:59','BLZBNB','4h','0.007550000000000','0.007480000000000','0.711908500000000','0.705308023841060','94.29251655629139','94.292516556291389','test'),('2019-01-04 11:59:59','2019-01-04 15:59:59','BLZBNB','4h','0.007600000000000','0.007510000000000','0.711908500000000','0.703478004605263','93.67217105263158','93.672171052631583','test'),('2019-01-06 19:59:59','2019-01-07 03:59:59','BLZBNB','4h','0.007620000000000','0.007380000000000','0.711908500000000','0.689486185039370','93.42631233595802','93.426312335958016','test'),('2019-01-15 15:59:59','2019-01-15 23:59:59','BLZBNB','4h','0.007000000000000','0.007050000000000','0.711908500000000','0.716993560714286','101.70121428571429','101.701214285714286','test'),('2019-01-17 15:59:59','2019-01-17 23:59:59','BLZBNB','4h','0.007080000000000','0.006720000000000','0.711908500000000','0.675709762711864','100.55204802259887','100.552048022598868','test'),('2019-01-19 07:59:59','2019-01-19 11:59:59','BLZBNB','4h','0.006860000000000','0.006750000000000','0.711908500000000','0.700493057580175','103.77674927113704','103.776749271137035','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','BLZBNB','4h','0.006870000000000','0.006700000000000','0.711908500000000','0.694292132459971','103.62569141193596','103.625691411935961','test'),('2019-01-22 19:59:59','2019-01-22 23:59:59','BLZBNB','4h','0.007520000000000','0.006620000000000','0.711908500000000','0.626706684840426','94.6686835106383','94.668683510638303','test'),('2019-01-23 11:59:59','2019-01-23 15:59:59','BLZBNB','4h','0.006800000000000','0.006590000000000','0.711908500000000','0.689923090441177','104.69242647058825','104.692426470588245','test'),('2019-01-30 23:59:59','2019-01-31 03:59:59','BLZBNB','4h','0.006250000000000','0.006220000000000','0.711908500000000','0.708491339200000','113.90536','113.905360000000002','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','BLZBNB','4h','0.006510000000000','0.006080000000000','0.711908500000000','0.664885357910906','109.35614439324117','109.356144393241166','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','BLZBNB','4h','0.004710000000000','0.004600000000000','0.711908500000000','0.695282186836518','151.14830148619959','151.148301486199585','test'),('2019-02-24 03:59:59','2019-02-24 11:59:59','BLZBNB','4h','0.004460000000000','0.004390000000000','0.711908500000000','0.700735048206278','159.6207399103139','159.620739910313887','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BLZBNB','4h','0.004430000000000','0.004580000000000','0.711908500000000','0.736013753950339','160.70169300225734','160.701693002257343','test'),('2019-03-03 11:59:59','2019-03-03 15:59:59','BLZBNB','4h','0.004350000000000','0.004490000000000','0.711908500000000','0.734820497701150','163.65712643678162','163.657126436781624','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','BLZBNB','4h','0.003910000000000','0.003730000000000','0.711908500000000','0.679135218670077','182.0737851662404','182.073785166240413','test'),('2019-03-14 23:59:59','2019-03-15 03:59:59','BLZBNB','4h','0.003820000000000','0.003690000000000','0.711908500000000','0.687681247382199','186.36348167539268','186.363481675392677','test'),('2019-03-15 11:59:59','2019-03-15 15:59:59','BLZBNB','4h','0.003810000000000','0.003970000000000','0.711908500000000','0.741804919947506','186.85262467191603','186.852624671916033','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','BLZBNB','4h','0.003760000000000','0.003700000000000','0.711908500000000','0.700548257978724','189.3373670212766','189.337367021276606','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','BLZBNB','4h','0.003740000000000','0.003750000000000','0.711908500000000','0.713811998663102','190.34986631016045','190.349866310160451','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','BLZBNB','4h','0.003750000000000','0.003190000000000','0.711908500000000','0.605596830666667','189.8422666666667','189.842266666666688','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','BLZBNB','4h','0.003610000000000','0.003610000000000','0.711908500000000','0.711908500000000','197.20457063711913','197.204570637119133','test'),('2019-03-28 11:59:59','2019-03-28 15:59:59','BLZBNB','4h','0.003620000000000','0.003840000000000','0.711908500000000','0.755173657458564','196.65980662983426','196.659806629834264','test'),('2019-04-01 19:59:59','2019-04-02 07:59:59','BLZBNB','4h','0.003760000000000','0.003700000000000','0.711908500000000','0.700548257978724','189.3373670212766','189.337367021276606','test'),('2019-04-03 07:59:59','2019-04-04 03:59:59','BLZBNB','4h','0.003760000000000','0.003580000000000','0.711908500000000','0.677827773936170','189.3373670212766','189.337367021276606','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','BLZBNB','4h','0.003790000000000','0.003730000000000','0.711908500000000','0.700638180738786','187.83865435356202','187.838654353562021','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','BLZBNB','4h','0.002340000000000','0.002330000000000','0.711908500000000','0.708866155982906','304.2344017094017','304.234401709401709','test'),('2019-05-15 19:59:59','2019-05-16 07:59:59','BLZBNB','4h','0.002530000000000','0.002430000000000','0.711908500000000','0.683769824110672','281.3867588932806','281.386758893280614','test'),('2019-06-03 07:59:59','2019-06-04 03:59:59','BLZBNB','4h','0.002000000000000','0.001960000000000','0.711908500000000','0.697670330000000','355.95425','355.954250000000002','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','BLZBNB','4h','0.001980000000000','0.001950000000000','0.711908500000000','0.701122007575758','359.5497474747475','359.549747474747505','test'),('2019-06-07 07:59:59','2019-06-08 19:59:59','BLZBNB','4h','0.002040000000000','0.001960000000000','0.711908500000000','0.683990519607843','348.9747549019608','348.974754901960807','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','BLZBNB','4h','0.002000000000000','0.001910000000000','0.711908500000000','0.679872617500000','355.95425','355.954250000000002','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','BLZBNB','4h','0.001970000000000','0.001920000000000','0.711908500000000','0.693839756345178','361.3748730964467','361.374873096446720','test'),('2019-06-15 19:59:59','2019-06-15 23:59:59','BLZBNB','4h','0.001980000000000','0.001930000000000','0.711908500000000','0.693931012626263','359.5497474747475','359.549747474747505','test'),('2019-06-17 19:59:59','2019-06-17 23:59:59','BLZBNB','4h','0.001970000000000','0.001890000000000','0.711908500000000','0.682998510152284','361.3748730964467','361.374873096446720','test'),('2019-06-23 11:59:59','2019-06-23 15:59:59','BLZBNB','4h','0.001890000000000','0.001870000000000','0.711908500000000','0.704375076719577','376.67116402116403','376.671164021164032','test'),('2019-07-04 03:59:59','2019-07-04 07:59:59','BLZBNB','4h','0.001720000000000','0.001710000000000','0.711908500000000','0.707769497093023','413.90029069767445','413.900290697674450','test'),('2019-07-06 11:59:59','2019-07-06 19:59:59','BLZBNB','4h','0.001700000000000','0.001680000000000','0.711908500000000','0.703533105882353','418.769705882353','418.769705882352980','test'),('2019-07-26 07:59:59','2019-08-01 11:59:59','BLZBNB','4h','0.001292000000000','0.001421000000000','0.711908500000000','0.782989147445820','551.0127708978329','551.012770897832866','test'),('2019-08-04 15:59:59','2019-08-04 19:59:59','BLZBNB','4h','0.001410000000000','0.001380000000000','0.711908500000000','0.696761510638298','504.89964539007093','504.899645390070930','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','BLZBNB','4h','0.001355000000000','0.001086000000000','0.711908500000000','0.570577587453875','525.3937269372694','525.393726937269435','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','BLZBNB','4h','0.001160000000000','0.001150000000000','0.711908500000000','0.705771357758621','613.7142241379311','613.714224137931069','test'),('2019-08-20 11:59:59','2019-08-28 19:59:59','BLZBNB','4h','0.001163000000000','0.001271000000000','0.711908500000000','0.778018661650903','612.1311263972485','612.131126397248522','test'),('2019-09-07 19:59:59','2019-09-08 23:59:59','BLZBNB','4h','0.001415000000000','0.001376000000000','0.711908500000000','0.692286993639576','503.11554770318025','503.115547703180255','test'),('2019-09-09 19:59:59','2019-09-18 11:59:59','BLZBNB','4h','0.001411000000000','0.001500000000000','0.711908500000000','0.756812721474132','504.54181431608794','504.541814316087937','test'),('2019-09-18 15:59:59','2019-09-24 23:59:59','BLZBNB','4h','0.001593000000000','0.001590000000000','0.711908500000000','0.710567806026365','446.89799121155056','446.897991211550561','test'),('2019-09-26 03:59:59','2019-09-26 23:59:59','BLZBNB','4h','0.001701000000000','0.001696000000000','0.711908500000000','0.709815882422105','418.52351557907116','418.523515579071159','test'),('2019-10-02 19:59:59','2019-10-03 03:59:59','BLZBNB','4h','0.001675000000000','0.001650000000000','0.711908500000000','0.701283000000000','425.02000000000004','425.020000000000039','test'),('2019-10-03 11:59:59','2019-10-03 19:59:59','BLZBNB','4h','0.001692000000000','0.001655000000000','0.711908500000000','0.696340760933806','420.7497044917258','420.749704491725822','test'),('2019-10-03 23:59:59','2019-10-04 03:59:59','BLZBNB','4h','0.001693000000000','0.001661000000000','0.711908500000000','0.698452462197283','420.50118133490844','420.501181334908438','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','BLZBNB','4h','0.001691000000000','0.001664000000000','0.711908500000000','0.700541539917209','420.99852158486107','420.998521584861066','test'),('2019-10-05 03:59:59','2019-10-05 23:59:59','BLZBNB','4h','0.001698000000000','0.001672000000000','0.711908500000000','0.701007663133098','419.2629564193169','419.262956419316879','test'),('2019-10-06 11:59:59','2019-10-06 19:59:59','BLZBNB','4h','0.001686000000000','0.001653000000000','0.711908500000000','0.697974347864769','422.247034400949','422.247034400949019','test'),('2019-10-07 11:59:59','2019-10-07 19:59:59','BLZBNB','4h','0.001685000000000','0.001656000000000','0.711908500000000','0.699656068842730','422.49762611275963','422.497626112759633','test'),('2019-10-07 23:59:59','2019-10-08 03:59:59','BLZBNB','4h','0.001708000000000','0.001641000000000','0.711908500000000','0.683982346896956','416.80825526932085','416.808255269320853','test'),('2019-10-08 07:59:59','2019-10-08 11:59:59','BLZBNB','4h','0.001675000000000','0.001757000000000','0.474605666666667','0.497840093333334','283.3466666666667','283.346666666666692','test'),('2019-10-14 15:59:59','2019-10-14 19:59:59','BLZBNB','4h','0.001639000000000','0.001557000000000','0.539443182004342','0.512454566431214','329.12945820887273','329.129458208872734','test'),('2019-10-21 23:59:59','2019-10-22 03:59:59','BLZBNB','4h','0.001505000000000','0.001466000000000','0.539443182004342','0.525464255693266','358.434007976307','358.434007976306987','test'),('2019-11-08 23:59:59','2019-11-09 03:59:59','BLZBNB','4h','0.001289000000000','0.001250000000000','0.539443182004342','0.523121782393660','418.4974259149279','418.497425914927874','test'),('2019-11-09 19:59:59','2019-11-13 11:59:59','BLZBNB','4h','0.001305000000000','0.001416000000000','0.539443182004342','0.585326854956436','413.366422991833','413.366422991833019','test'),('2019-11-25 23:59:59','2019-11-27 23:59:59','BLZBNB','4h','0.001374000000000','0.001348000000000','0.539443182004342','0.529235377978059','392.6078471647322','392.607847164732220','test'),('2019-12-02 11:59:59','2019-12-04 03:59:59','BLZBNB','4h','0.001460000000000','0.001377000000000','0.539443182004342','0.508776206589027','369.48163150982333','369.481631509823330','test'),('2019-12-07 07:59:59','2019-12-07 11:59:59','BLZBNB','4h','0.001369000000000','0.001377000000000','0.539443182004342','0.542595516157764','394.0417691777517','394.041769177751689','test'),('2019-12-16 11:59:59','2019-12-16 19:59:59','BLZBNB','4h','0.001348000000000','0.001311000000000','0.539443182004342','0.524636507127368','400.18040208037246','400.180402080372460','test'),('2019-12-27 23:59:59','2019-12-28 03:59:59','BLZBNB','4h','0.001275000000000','0.001226000000000','0.539443182004342','0.518711640107705','423.09269176811137','423.092691768111365','test'),('2019-12-28 07:59:59','2019-12-28 19:59:59','BLZBNB','4h','0.001279000000000','0.001286000000000','0.539443182004342','0.542395568457845','421.76949335757786','421.769493357577858','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:18:06
