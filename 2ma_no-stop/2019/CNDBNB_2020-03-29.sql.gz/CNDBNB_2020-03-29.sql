-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 15:59:59','2019-01-06 19:59:59','CNDBNB','4h','0.001745000000000','0.001691000000000','0.711908500000000','0.689878093696275','407.97048710601723','407.970487106017231','test'),('2019-01-06 23:59:59','2019-01-07 07:59:59','CNDBNB','4h','0.001797000000000','0.001731000000000','0.711908500000000','0.685761610183639','396.1649972175849','396.164997217584926','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','CNDBNB','4h','0.001655000000000','0.001630000000000','0.711908500000000','0.701154595166163','430.15619335347435','430.156193353474350','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','CNDBNB','4h','0.001669000000000','0.001618000000000','0.711908500000000','0.690154555422409','426.54793289394854','426.547932893948541','test'),('2019-01-15 03:59:59','2019-01-17 07:59:59','CNDBNB','4h','0.001651000000000','0.001711000000000','0.711908500000000','0.737780401877650','431.19836462749856','431.198364627498563','test'),('2019-01-18 11:59:59','2019-01-19 19:59:59','CNDBNB','4h','0.001812000000000','0.001747000000000','0.711908500000000','0.686370943432671','392.88548565121414','392.885485651214140','test'),('2019-01-22 07:59:59','2019-01-22 11:59:59','CNDBNB','4h','0.001779000000000','0.001780000000000','0.711908500000000','0.712308673412029','400.17341202922995','400.173412029229951','test'),('2019-01-25 03:59:59','2019-01-25 07:59:59','CNDBNB','4h','0.001739000000000','0.001704000000000','0.711908500000000','0.697580266820012','409.37809085681425','409.378090856814254','test'),('2019-01-30 03:59:59','2019-01-30 19:59:59','CNDBNB','4h','0.001651000000000','0.001619000000000','0.711908500000000','0.698110152331920','431.19836462749856','431.198364627498563','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','CNDBNB','4h','0.001634000000000','0.001606000000000','0.711908500000000','0.699709333537332','435.68451652386784','435.684516523867842','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','CNDBNB','4h','0.001215000000000','0.001201000000000','0.711908500000000','0.703705439094650','585.9329218106997','585.932921810699668','test'),('2019-02-28 19:59:59','2019-02-28 23:59:59','CNDBNB','4h','0.001251000000000','0.001288000000000','0.711908500000000','0.732964147082334','569.0715427657874','569.071542765787399','test'),('2019-03-14 03:59:59','2019-03-14 15:59:59','CNDBNB','4h','0.001027000000000','0.001012000000000','0.711908500000000','0.701510615384616','693.1923076923078','693.192307692307850','test'),('2019-03-15 15:59:59','2019-03-16 03:59:59','CNDBNB','4h','0.001009000000000','0.001000000000000','0.711908500000000','0.705558473736373','705.5584737363728','705.558473736372775','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','CNDBNB','4h','0.000996000000000','0.001005000000000','0.711908500000000','0.718341408132530','714.7675702811246','714.767570281124563','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','CNDBNB','4h','0.000979000000000','0.000979000000000','0.711908500000000','0.711908500000000','727.1792645556691','727.179264555669079','test'),('2019-03-29 03:59:59','2019-03-29 07:59:59','CNDBNB','4h','0.000976000000000','0.000964000000000','0.711908500000000','0.703155526639344','729.4144467213115','729.414446721311492','test'),('2019-03-29 11:59:59','2019-03-31 03:59:59','CNDBNB','4h','0.000985000000000','0.000972000000000','0.711908500000000','0.702512753299492','722.7497461928934','722.749746192893440','test'),('2019-03-31 11:59:59','2019-04-01 07:59:59','CNDBNB','4h','0.000993000000000','0.001005000000000','0.711908500000000','0.720511623867070','716.9269889224573','716.926988922457326','test'),('2019-04-04 23:59:59','2019-04-06 11:59:59','CNDBNB','4h','0.001009000000000','0.001007000000000','0.711908500000000','0.710497383052527','705.5584737363728','705.558473736372775','test'),('2019-04-09 19:59:59','2019-04-09 23:59:59','CNDBNB','4h','0.001027000000000','0.001024000000000','0.711908500000000','0.709828923076923','693.1923076923078','693.192307692307850','test'),('2019-04-13 15:59:59','2019-04-13 19:59:59','CNDBNB','4h','0.001058000000000','0.001008000000000','0.711908500000000','0.678264431001890','672.8813799621929','672.881379962192909','test'),('2019-04-16 03:59:59','2019-04-16 15:59:59','CNDBNB','4h','0.001016000000000','0.001015000000000','0.711908500000000','0.711207802657480','700.6973425196851','700.697342519685094','test'),('2019-05-01 19:59:59','2019-05-01 23:59:59','CNDBNB','4h','0.000800000000000','0.000789000000000','0.711908500000000','0.702119758125000','889.885625','889.885625000000005','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','CNDBNB','4h','0.000730000000000','0.000730000000000','0.711908500000000','0.711908500000000','975.2171232876714','975.217123287671370','test'),('2019-05-11 03:59:59','2019-05-11 07:59:59','CNDBNB','4h','0.000765000000000','0.000739000000000','0.711908500000000','0.687712916993464','930.5993464052289','930.599346405228857','test'),('2019-05-11 23:59:59','2019-05-12 11:59:59','CNDBNB','4h','0.000779000000000','0.000724000000000','0.711908500000000','0.661645383825417','913.8748395378692','913.874839537869207','test'),('2019-05-21 11:59:59','2019-05-21 15:59:59','CNDBNB','4h','0.000667000000000','0.000610000000000','0.711908500000000','0.651070742128936','1067.3290854572715','1067.329085457271503','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','CNDBNB','4h','0.000594000000000','0.000601000000000','0.711908500000000','0.720297994107744','1198.4991582491582','1198.499158249158199','test'),('2019-06-02 07:59:59','2019-06-05 15:59:59','CNDBNB','4h','0.000617000000000','0.000601000000000','0.711908500000000','0.693447339546191','1153.822528363047','1153.822528363047013','test'),('2019-06-08 03:59:59','2019-06-08 07:59:59','CNDBNB','4h','0.000596000000000','0.000593000000000','0.711908500000000','0.708325067953020','1194.4773489932888','1194.477348993288842','test'),('2019-06-09 11:59:59','2019-06-09 15:59:59','CNDBNB','4h','0.000595000000000','0.000592000000000','0.711908500000000','0.708319045378151','1196.4848739495799','1196.484873949579878','test'),('2019-06-10 19:59:59','2019-06-10 23:59:59','CNDBNB','4h','0.000597000000000','0.000597000000000','0.711908500000000','0.711908500000000','1192.4765494137355','1192.476549413735484','test'),('2019-06-15 15:59:59','2019-06-15 19:59:59','CNDBNB','4h','0.000592000000000','0.000563000000000','0.711908500000000','0.677034603885135','1202.548141891892','1202.548141891892101','test'),('2019-07-05 19:59:59','2019-07-06 03:59:59','CNDBNB','4h','0.000426000000000','0.000414000000000','0.711908500000000','0.691854739436620','1671.1467136150236','1671.146713615023600','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','CNDBNB','4h','0.000458000000000','0.000415000000000','0.711908500000000','0.645069929039301','1554.3853711790393','1554.385371179039339','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','CNDBNB','4h','0.000349500000000','0.000342600000000','0.711908500000000','0.697853654077253','2036.9341917024324','2036.934191702432372','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','CNDBNB','4h','0.000356400000000','0.000360700000000','0.711908500000000','0.720497743967452','1997.4985970819307','1997.498597081930711','test'),('2019-07-29 11:59:59','2019-07-31 23:59:59','CNDBNB','4h','0.000365000000000','0.000346500000000','0.711908500000000','0.675825466438356','1950.4342465753427','1950.434246575342740','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','CNDBNB','4h','0.000403000000000','0.000363500000000','0.711908500000000','0.642130867866005','1766.5223325062036','1766.522332506203611','test'),('2019-08-05 15:59:59','2019-08-05 19:59:59','CNDBNB','4h','0.000371700000000','0.000347500000000','0.711908500000000','0.665558794054345','1915.2771051923596','1915.277105192359613','test'),('2019-08-06 19:59:59','2019-08-06 23:59:59','CNDBNB','4h','0.000365300000000','0.000330000000000','0.711908500000000','0.643114713933753','1948.8324664659187','1948.832466465918742','test'),('2019-08-20 11:59:59','2019-08-20 15:59:59','CNDBNB','4h','0.000288000000000','0.000263300000000','0.711908500000000','0.650852458506944','2471.904513888889','2471.904513888889142','test'),('2019-08-23 07:59:59','2019-08-23 15:59:59','CNDBNB','4h','0.000268100000000','0.000260600000000','0.474605666666667','0.461328745741639','1770.2561233370634','1770.256123337063400','test'),('2019-08-24 03:59:59','2019-08-24 07:59:59','CNDBNB','4h','0.000264400000000','0.000271000000000','0.524403862810846','0.537494125649543','1983.373157378391','1983.373157378390943','test'),('2019-09-09 19:59:59','2019-09-18 11:59:59','CNDBNB','4h','0.000306900000000','0.000310200000000','0.527676428520521','0.533350368612139','1719.3757853389404','1719.375785338940432','test'),('2019-10-22 03:59:59','2019-10-22 07:59:59','CNDBNB','4h','0.000435100000000','0.000430200000000','0.529094913543425','0.523136363609243','1216.030598812745','1216.030598812744984','test'),('2019-10-22 11:59:59','2019-10-22 15:59:59','CNDBNB','4h','0.000443500000000','0.000448500000000','0.529094913543425','0.535059906931739','1192.9986776627395','1192.998677662739510','test'),('2019-11-01 11:59:59','2019-11-01 19:59:59','CNDBNB','4h','0.000395500000000','0.000386000000000','0.529096524406958','0.516387505489471','1337.7914649986303','1337.791464998630317','test'),('2019-11-04 15:59:59','2019-11-04 23:59:59','CNDBNB','4h','0.000399600000000','0.000390300000000','0.529096524406958','0.516782716406496','1324.0653763937887','1324.065376393788711','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','CNDBNB','4h','0.000395700000000','0.000388100000000','0.529096524406958','0.518934448123175','1337.1153004977457','1337.115300497745693','test'),('2019-11-07 03:59:59','2019-11-07 07:59:59','CNDBNB','4h','0.000393100000000','0.000388200000000','0.529096524406958','0.522501324789573','1345.9591055888018','1345.959105588801776','test'),('2019-11-11 11:59:59','2019-11-11 15:59:59','CNDBNB','4h','0.000387200000000','0.000395700000000','0.529096524406958','0.540711504927255','1366.4682965055733','1366.468296505573335','test'),('2019-11-12 15:59:59','2019-11-12 19:59:59','CNDBNB','4h','0.000388700000000','0.000390100000000','0.529096524406958','0.531002197507472','1361.1950717956213','1361.195071795621288','test'),('2019-11-15 15:59:59','2019-11-21 15:59:59','CNDBNB','4h','0.000406000000000','0.000416400000000','0.529096524406958','0.542649735869599','1303.1934098693546','1303.193409869354582','test'),('2019-12-02 03:59:59','2019-12-02 07:59:59','CNDBNB','4h','0.000497800000000','0.000491000000000','0.529096524406958','0.521869010614336','1062.8696753856127','1062.869675385612709','test'),('2019-12-03 03:59:59','2019-12-03 11:59:59','CNDBNB','4h','0.000496800000000','0.000494700000000','0.529096524406958','0.526860005282049','1065.0091070993517','1065.009107099351695','test'),('2019-12-06 03:59:59','2019-12-12 15:59:59','CNDBNB','4h','0.000506800000000','0.000583000000000','0.529096524406958','0.608648922117712','1043.9947206135714','1043.994720613571417','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 17:23:56
