-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 15:59:59','2019-01-06 07:59:59','CMTBNB','4h','0.004440000000000','0.004340000000000','0.711908500000000','0.695874524774775','160.33975225225225','160.339752252252254','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','CMTBNB','4h','0.004370000000000','0.004260000000000','0.711908500000000','0.693988606407323','162.90812356979407','162.908123569794071','test'),('2019-01-16 11:59:59','2019-01-16 19:59:59','CMTBNB','4h','0.004210000000000','0.004180000000000','0.711908500000000','0.706835517814727','169.09940617577197','169.099406175771975','test'),('2019-01-19 07:59:59','2019-01-20 11:59:59','CMTBNB','4h','0.004450000000000','0.004030000000000','0.711908500000000','0.644717135955056','159.9794382022472','159.979438202247195','test'),('2019-01-21 03:59:59','2019-01-22 07:59:59','CMTBNB','4h','0.004160000000000','0.004260000000000','0.711908500000000','0.729021685096154','171.1318509615385','171.131850961538504','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','CMTBNB','4h','0.004200000000000','0.004160000000000','0.711908500000000','0.705128419047619','169.50202380952382','169.502023809523820','test'),('2019-01-24 19:59:59','2019-01-25 07:59:59','CMTBNB','4h','0.004210000000000','0.004140000000000','0.711908500000000','0.700071541567696','169.09940617577197','169.099406175771975','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','CMTBNB','4h','0.002940000000000','0.002840000000000','0.711908500000000','0.687693925170068','242.14574829931976','242.145748299319763','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','CMTBNB','4h','0.002760000000000','0.002710000000000','0.711908500000000','0.699011606884058','257.9378623188406','257.937862318840587','test'),('2019-02-25 15:59:59','2019-02-28 11:59:59','CMTBNB','4h','0.002760000000000','0.002770000000000','0.711908500000000','0.714487878623189','257.9378623188406','257.937862318840587','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','CMTBNB','4h','0.002330000000000','0.002330000000000','0.711908500000000','0.711908500000000','305.54012875536483','305.540128755364833','test'),('2019-03-13 03:59:59','2019-03-13 07:59:59','CMTBNB','4h','0.002320000000000','0.002270000000000','0.711908500000000','0.696565644396552','306.85711206896553','306.857112068965534','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','CMTBNB','4h','0.002280000000000','0.002240000000000','0.711908500000000','0.699418877192982','312.2405701754386','312.240570175438620','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','CMTBNB','4h','0.002230000000000','0.002260000000000','0.711908500000000','0.721485744394619','319.2414798206278','319.241479820627774','test'),('2019-03-30 03:59:59','2019-03-30 11:59:59','CMTBNB','4h','0.002130000000000','0.002080000000000','0.711908500000000','0.695197032863850','334.2293427230047','334.229342723004720','test'),('2019-04-10 03:59:59','2019-04-10 11:59:59','CMTBNB','4h','0.002430000000000','0.002380000000000','0.711908500000000','0.697260176954733','292.96646090534983','292.966460905349834','test'),('2019-05-06 19:59:59','2019-05-06 23:59:59','CMTBNB','4h','0.001430000000000','0.001410000000000','0.711908500000000','0.701951737762238','497.8381118881119','497.838111888111882','test'),('2019-05-07 03:59:59','2019-05-11 19:59:59','CMTBNB','4h','0.001480000000000','0.001560000000000','0.711908500000000','0.750390040540540','481.0192567567568','481.019256756756818','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','CMTBNB','4h','0.001510000000000','0.001520000000000','0.711908500000000','0.716623125827815','471.46258278145694','471.462582781456945','test'),('2019-05-17 15:59:59','2019-05-18 07:59:59','CMTBNB','4h','0.001540000000000','0.001470000000000','0.711908500000000','0.679549022727273','462.27824675324683','462.278246753246833','test'),('2019-05-27 19:59:59','2019-05-27 23:59:59','CMTBNB','4h','0.001310000000000','0.001320000000000','0.711908500000000','0.717342916030534','543.4416030534352','543.441603053435188','test'),('2019-06-10 15:59:59','2019-06-11 03:59:59','CMTBNB','4h','0.001230000000000','0.001160000000000','0.711908500000000','0.671393382113821','578.7873983739838','578.787398373983820','test'),('2019-06-13 19:59:59','2019-06-18 03:59:59','CMTBNB','4h','0.001250000000000','0.001350000000000','0.711908500000000','0.768861180000000','569.5268','569.526799999999980','test'),('2019-06-18 19:59:59','2019-06-19 07:59:59','CMTBNB','4h','0.001400000000000','0.001350000000000','0.711908500000000','0.686483196428571','508.5060714285715','508.506071428571488','test'),('2019-06-25 11:59:59','2019-06-26 07:59:59','CMTBNB','4h','0.001310000000000','0.001240000000000','0.711908500000000','0.673867587786260','543.4416030534352','543.441603053435188','test'),('2019-06-26 15:59:59','2019-06-26 19:59:59','CMTBNB','4h','0.001290000000000','0.001250000000000','0.711908500000000','0.689833817829457','551.8670542635659','551.867054263565933','test'),('2019-06-30 03:59:59','2019-06-30 07:59:59','CMTBNB','4h','0.001260000000000','0.001230000000000','0.711908500000000','0.694958297619048','565.006746031746','565.006746031746047','test'),('2019-06-30 23:59:59','2019-07-01 11:59:59','CMTBNB','4h','0.001250000000000','0.001260000000000','0.711908500000000','0.717603768000000','569.5268','569.526799999999980','test'),('2019-07-03 07:59:59','2019-07-08 11:59:59','CMTBNB','4h','0.001400000000000','0.001580000000000','0.711908500000000','0.803439592857143','508.5060714285715','508.506071428571488','test'),('2019-07-09 11:59:59','2019-07-09 15:59:59','CMTBNB','4h','0.001640000000000','0.002200000000000','0.711908500000000','0.954999207317073','434.09054878048784','434.090548780487836','test'),('2019-07-15 15:59:59','2019-07-15 19:59:59','CMTBNB','4h','0.001832000000000','0.001749000000000','0.729085672495793','0.696053952617436','397.9725286549089','397.972528654908899','test'),('2019-07-15 23:59:59','2019-07-16 11:59:59','CMTBNB','4h','0.001870000000000','0.001768000000000','0.729085672495793','0.689317363086932','389.8853863613867','389.885386361386679','test'),('2019-07-28 23:59:59','2019-07-29 03:59:59','CMTBNB','4h','0.001510000000000','0.001471000000000','0.729085672495793','0.710254982941266','482.8381937058232','482.838193705823187','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','CMTBNB','4h','0.001498000000000','0.001484000000000','0.729085672495793','0.722271787706113','486.7060564057363','486.706056405736319','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','CMTBNB','4h','0.001510000000000','0.001490000000000','0.729085672495793','0.719428908621677','482.8381937058232','482.838193705823187','test'),('2019-07-30 19:59:59','2019-07-31 03:59:59','CMTBNB','4h','0.001530000000000','0.001500000000000','0.729085672495793','0.714789874995876','476.5265833305837','476.526583330583719','test'),('2019-08-04 07:59:59','2019-08-04 15:59:59','CMTBNB','4h','0.001494000000000','0.001420000000000','0.729085672495793','0.692972995277126','488.0091516036098','488.009151603609780','test'),('2019-08-05 15:59:59','2019-08-05 23:59:59','CMTBNB','4h','0.001445000000000','0.001420000000000','0.729085672495793','0.716471733525278','504.557558820618','504.557558820617999','test'),('2019-08-19 11:59:59','2019-08-21 03:59:59','CMTBNB','4h','0.001169000000000','0.001120000000000','0.729085672495793','0.698525195205550','623.6832100049556','623.683210004955640','test'),('2019-08-24 03:59:59','2019-08-26 03:59:59','CMTBNB','4h','0.001140000000000','0.001160000000000','0.729085672495793','0.741876649206246','639.5488355226255','639.548835522625495','test'),('2019-08-26 15:59:59','2019-08-27 15:59:59','CMTBNB','4h','0.001177000000000','0.001136000000000','0.729085672495793','0.703688465552439','619.4440717891189','619.444071789118880','test'),('2019-08-29 11:59:59','2019-08-29 15:59:59','CMTBNB','4h','0.001157000000000','0.001136000000000','0.729085672495793','0.715852483971669','630.1518344821029','630.151834482102913','test'),('2019-08-30 19:59:59','2019-09-02 15:59:59','CMTBNB','4h','0.001150000000000','0.001140000000000','0.729085672495793','0.722745797082786','633.9875413006896','633.987541300689600','test'),('2019-09-04 23:59:59','2019-09-05 03:59:59','CMTBNB','4h','0.001166000000000','0.001140000000000','0.729085672495793','0.712828187517328','625.2878837871295','625.287883787129545','test'),('2019-09-14 15:59:59','2019-09-14 19:59:59','CMTBNB','4h','0.001060000000000','0.001030000000000','0.729085672495793','0.708451172330818','687.8166721658425','687.816672165842533','test'),('2019-09-15 23:59:59','2019-09-16 03:59:59','CMTBNB','4h','0.001050000000000','0.001021000000000','0.729085672495793','0.708949020588766','694.3673071388506','694.367307138850606','test'),('2019-09-20 19:59:59','2019-09-24 03:59:59','CMTBNB','4h','0.001052000000000','0.001070000000000','0.729085672495793','0.741560522405417','693.0472172013242','693.047217201324202','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','CMTBNB','4h','0.001074000000000','0.001040000000000','0.729085672495793','0.706004748040619','678.8507192698258','678.850719269825845','test'),('2019-09-26 19:59:59','2019-09-26 23:59:59','CMTBNB','4h','0.001079000000000','0.001072000000000','0.729085672495793','0.724355737641789','675.7049791434597','675.704979143459695','test'),('2019-09-29 15:59:59','2019-09-29 23:59:59','CMTBNB','4h','0.001071000000000','0.001059000000000','0.729085672495793','0.720916645352983','680.7522619008339','680.752261900833901','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','CMTBNB','4h','0.001081000000000','0.001080000000000','0.729085672495793','0.728411217664622','674.4548311709465','674.454831170946477','test'),('2019-10-08 15:59:59','2019-10-09 07:59:59','CMTBNB','4h','0.001142000000000','0.001122000000000','0.729085672495793','0.716317096795341','638.4287850225859','638.428785022585885','test'),('2019-10-27 15:59:59','2019-10-28 07:59:59','CMTBNB','4h','0.000943000000000','0.000884000000000','0.729085672495793','0.683469495743670','773.1555381715726','773.155538171572630','test'),('2019-10-29 11:59:59','2019-11-02 19:59:59','CMTBNB','4h','0.000980000000000','0.001001000000000','0.729085672495793','0.744708936906417','743.9649719344827','743.964971934482719','test'),('2019-11-04 23:59:59','2019-11-05 03:59:59','CMTBNB','4h','0.000983000000000','0.001061000000000','0.729085672495793','0.786937841829132','741.6944786325464','741.694478632546407','test'),('2019-11-14 15:59:59','2019-11-14 23:59:59','CMTBNB','4h','0.000963000000000','0.000969000000000','0.729085672495793','0.733628262355580','757.0983099644787','757.098309964478744','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','CMTBNB','4h','0.000966000000000','0.000961000000000','0.729085672495793','0.725311937130908','754.7470729770115','754.747072977011499','test'),('2019-11-20 15:59:59','2019-11-21 03:59:59','CMTBNB','4h','0.000966000000000','0.000967000000000','0.729085672495793','0.729840419568770','754.7470729770115','754.747072977011499','test'),('2019-11-21 23:59:59','2019-11-22 03:59:59','CMTBNB','4h','0.000974000000000','0.000955000000000','0.729085672495793','0.714863262046696','748.5479183735041','748.547918373504103','test'),('2019-11-22 19:59:59','2019-11-23 03:59:59','CMTBNB','4h','0.000967000000000','0.000949000000000','0.729085672495793','0.715514274248715','753.9665692821025','753.966569282102455','test'),('2019-11-26 19:59:59','2019-11-26 23:59:59','CMTBNB','4h','0.000952000000000','0.000925000000000','0.729085672495793','0.708407822540555','765.846294638438','765.846294638438053','test'),('2019-11-27 07:59:59','2019-11-27 11:59:59','CMTBNB','4h','0.000953000000000','0.000961000000000','0.729085672495793','0.735206013922830','765.042678379636','765.042678379635959','test'),('2019-11-28 07:59:59','2019-11-28 11:59:59','CMTBNB','4h','0.000949000000000','0.000951000000000','0.729085672495793','0.730622207105900','768.2673050535227','768.267305053522705','test'),('2019-11-30 03:59:59','2019-11-30 07:59:59','CMTBNB','4h','0.000949000000000','0.000943000000000','0.729085672495793','0.724476068665472','768.2673050535227','768.267305053522705','test'),('2019-12-04 15:59:59','2019-12-04 19:59:59','CMTBNB','4h','0.000940000000000','0.000924000000000','0.729085672495793','0.716675703602248','775.6230558465884','775.623055846588386','test'),('2019-12-08 23:59:59','2019-12-09 03:59:59','CMTBNB','4h','0.000930000000000','0.000914000000000','0.729085672495793','0.716542263076510','783.9630887051537','783.963088705153723','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','CMTBNB','4h','0.000895000000000','0.000895000000000','0.729085672495793','0.729085672495793','814.6208631237911','814.620863123791082','test'),('2019-12-17 03:59:59','2019-12-17 07:59:59','CMTBNB','4h','0.000912000000000','0.000895000000000','0.729085672495793','0.715495259740937','799.4360444032818','799.436044403281812','test'),('2019-12-20 15:59:59','2019-12-20 19:59:59','CMTBNB','4h','0.000903000000000','0.000877000000000','0.729085672495793','0.708093172512525','807.4038455102913','807.403845510291262','test'),('2019-12-21 07:59:59','2019-12-21 11:59:59','CMTBNB','4h','0.000884000000000','0.000894000000000','0.729085672495793','0.737333247976515','824.757548072164','824.757548072164013','test'),('2019-12-27 03:59:59','2019-12-27 11:59:59','CMTBNB','4h','0.000907000000000','0.000858000000000','0.729085672495793','0.689697361633286','803.8430788266736','803.843078826673604','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  4:04:56
