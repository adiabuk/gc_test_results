-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-04 15:59:59','CNDBTC','4h','0.000002640000000','0.000002580000000','0.001467500000000','0.001434147727273','555.8712121212121','555.871212121212125','test'),('2019-01-04 23:59:59','2019-01-05 11:59:59','CNDBTC','4h','0.000002650000000','0.000002670000000','0.001467500000000','0.001478575471698','553.7735849056604','553.773584905660414','test'),('2019-01-09 03:59:59','2019-01-09 11:59:59','CNDBTC','4h','0.000002730000000','0.000002670000000','0.001467500000000','0.001435247252747','537.5457875457876','537.545787545787562','test'),('2019-01-13 07:59:59','2019-01-13 11:59:59','CNDBTC','4h','0.000002640000000','0.000002650000000','0.001467500000000','0.001473058712121','555.8712121212121','555.871212121212125','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','CNDBTC','4h','0.000002660000000','0.000002630000000','0.001467500000000','0.001450949248120','551.6917293233083','551.691729323308323','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','CNDBTC','4h','0.000002940000000','0.000002950000000','0.001467500000000','0.001472491496599','499.14965986394566','499.149659863945658','test'),('2019-02-04 15:59:59','2019-02-04 19:59:59','CNDBTC','4h','0.000002950000000','0.000002920000000','0.001467500000000','0.001452576271186','497.45762711864404','497.457627118644041','test'),('2019-02-08 11:59:59','2019-02-08 19:59:59','CNDBTC','4h','0.000002940000000','0.000002890000000','0.001467500000000','0.001442542517007','499.14965986394566','499.149659863945658','test'),('2019-02-15 03:59:59','2019-02-16 11:59:59','CNDBTC','4h','0.000003130000000','0.000003080000000','0.001467500000000','0.001444057507987','468.84984025559106','468.849840255591062','test'),('2019-02-20 11:59:59','2019-02-21 07:59:59','CNDBTC','4h','0.000003150000000','0.000003080000000','0.001467500000000','0.001434888888889','465.8730158730159','465.873015873015902','test'),('2019-02-25 07:59:59','2019-02-25 11:59:59','CNDBTC','4h','0.000003100000000','0.000003090000000','0.001467500000000','0.001462766129032','473.3870967741936','473.387096774193594','test'),('2019-02-26 03:59:59','2019-03-06 07:59:59','CNDBTC','4h','0.000003180000000','0.000003350000000','0.001467500000000','0.001545951257862','461.47798742138366','461.477987421383659','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','CNDBTC','4h','0.000003360000000','0.000003330000000','0.001467500000000','0.001454397321429','436.7559523809524','436.755952380952408','test'),('2019-03-23 23:59:59','2019-03-24 03:59:59','CNDBTC','4h','0.000003780000000','0.000003740000000','0.001467500000000','0.001451970899471','388.22751322751327','388.227513227513271','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','CNDBTC','4h','0.000003850000000','0.000003750000000','0.001467500000000','0.001429383116883','381.16883116883116','381.168831168831161','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','CNDBTC','4h','0.000003890000000','0.000003900000000','0.001467500000000','0.001471272493573','377.24935732647816','377.249357326478162','test'),('2019-04-13 15:59:59','2019-04-13 19:59:59','CNDBTC','4h','0.000003860000000','0.000003700000000','0.001467500000000','0.001406670984456','380.18134715025906','380.181347150259057','test'),('2019-04-15 07:59:59','2019-04-15 23:59:59','CNDBTC','4h','0.000003790000000','0.000003770000000','0.001467500000000','0.001459755936675','387.2031662269129','387.203166226912913','test'),('2019-05-19 11:59:59','2019-05-19 15:59:59','CNDBTC','4h','0.000002350000000','0.000002360000000','0.001467500000000','0.001473744680851','624.468085106383','624.468085106383000','test'),('2019-05-21 07:59:59','2019-05-22 15:59:59','CNDBTC','4h','0.000002410000000','0.000002450000000','0.001467500000000','0.001491856846473','608.9211618257262','608.921161825726244','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','CNDBTC','4h','0.000002410000000','0.000002180000000','0.001467500000000','0.001327448132780','608.9211618257262','608.921161825726244','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','CNDBTC','4h','0.000002330000000','0.000002290000000','0.001467500000000','0.001442306866953','629.8283261802575','629.828326180257477','test'),('2019-06-02 07:59:59','2019-06-03 03:59:59','CNDBTC','4h','0.000002320000000','0.000002270000000','0.001467500000000','0.001435872844828','632.5431034482759','632.543103448275929','test'),('2019-06-07 11:59:59','2019-06-09 19:59:59','CNDBTC','4h','0.000002310000000','0.000002310000000','0.001467500000000','0.001467500000000','635.2813852813854','635.281385281385383','test'),('2019-06-10 15:59:59','2019-06-11 07:59:59','CNDBTC','4h','0.000002330000000','0.000002350000000','0.001467500000000','0.001480096566524','629.8283261802575','629.828326180257477','test'),('2019-07-24 19:59:59','2019-07-27 03:59:59','CNDBTC','4h','0.000001040000000','0.000001010000000','0.001467500000000','0.001425168269231','1411.0576923076924','1411.057692307692378','test'),('2019-07-28 15:59:59','2019-07-28 19:59:59','CNDBTC','4h','0.000001010000000','0.000001000000000','0.001467500000000','0.001452970297030','1452.970297029703','1452.970297029703033','test'),('2019-07-28 23:59:59','2019-07-29 03:59:59','CNDBTC','4h','0.000001010000000','0.000001000000000','0.001467500000000','0.001452970297030','1452.970297029703','1452.970297029703033','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','CNDBTC','4h','0.000001090000000','0.000000970000000','0.001467500000000','0.001305940366972','1346.330275229358','1346.330275229357994','test'),('2019-08-03 03:59:59','2019-08-03 07:59:59','CNDBTC','4h','0.000001000000000','0.000000970000000','0.001467500000000','0.001423475000000','1467.5000000000002','1467.500000000000227','test'),('2019-08-03 15:59:59','2019-08-03 19:59:59','CNDBTC','4h','0.000001020000000','0.000000920000000','0.001467500000000','0.001323627450980','1438.7254901960785','1438.725490196078454','test'),('2019-08-20 11:59:59','2019-08-20 15:59:59','CNDBTC','4h','0.000000740000000','0.000000680000000','0.001467500000000','0.001348513513514','1983.1081081081081','1983.108108108108127','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','CNDBTC','4h','0.000000700000000','0.000000700000000','0.001467500000000','0.001467500000000','2096.4285714285716','2096.428571428571558','test'),('2019-08-24 07:59:59','2019-08-26 03:59:59','CNDBTC','4h','0.000000710000000','0.000000720000000','0.001467500000000','0.001488169014085','2066.9014084507044','2066.901408450704366','test'),('2019-08-30 23:59:59','2019-08-31 03:59:59','CNDBTC','4h','0.000000730000000','0.000000720000000','0.001467500000000','0.001447397260274','2010.2739726027398','2010.273972602739832','test'),('2019-09-09 19:59:59','2019-09-10 11:59:59','CNDBTC','4h','0.000000650000000','0.000000620000000','0.001467500000000','0.001399769230769','2257.6923076923076','2257.692307692307622','test'),('2019-09-12 11:59:59','2019-09-12 15:59:59','CNDBTC','4h','0.000000630000000','0.000000610000000','0.001467500000000','0.001420912698413','2329.3650793650795','2329.365079365079509','test'),('2019-09-13 15:59:59','2019-09-13 19:59:59','CNDBTC','4h','0.000000630000000','0.000000630000000','0.001467500000000','0.001467500000000','2329.3650793650795','2329.365079365079509','test'),('2019-09-16 19:59:59','2019-10-01 03:59:59','CNDBTC','4h','0.000000640000000','0.000000880000000','0.001467500000000','0.002017812500000','2292.96875','2292.968750000000000','test'),('2019-10-01 11:59:59','2019-10-09 15:59:59','CNDBTC','4h','0.000000910000000','0.000000960000000','0.001467500000000','0.001548131868132','1612.6373626373627','1612.637362637362685','test'),('2019-10-19 07:59:59','2019-10-19 11:59:59','CNDBTC','4h','0.000000950000000','0.000000950000000','0.001467500000000','0.001467500000000','1544.7368421052631','1544.736842105263122','test'),('2019-10-20 03:59:59','2019-10-20 07:59:59','CNDBTC','4h','0.000000950000000','0.000000940000000','0.001467500000000','0.001452052631579','1544.7368421052631','1544.736842105263122','test'),('2019-10-21 07:59:59','2019-10-21 11:59:59','CNDBTC','4h','0.000000950000000','0.000000940000000','0.001467500000000','0.001452052631579','1544.7368421052631','1544.736842105263122','test'),('2019-10-24 23:59:59','2019-10-25 07:59:59','CNDBTC','4h','0.000000950000000','0.000000940000000','0.001467500000000','0.001452052631579','1544.7368421052631','1544.736842105263122','test'),('2019-11-01 11:59:59','2019-11-01 15:59:59','CNDBTC','4h','0.000000860000000','0.000000840000000','0.001467500000000','0.001433372093023','1706.3953488372092','1706.395348837209212','test'),('2019-11-03 15:59:59','2019-11-03 19:59:59','CNDBTC','4h','0.000000860000000','0.000000860000000','0.001467500000000','0.001467500000000','1706.3953488372092','1706.395348837209212','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','CNDBTC','4h','0.000000860000000','0.000000840000000','0.001467500000000','0.001433372093023','1706.3953488372092','1706.395348837209212','test'),('2019-11-04 15:59:59','2019-11-05 19:59:59','CNDBTC','4h','0.000000860000000','0.000000860000000','0.001467500000000','0.001467500000000','1706.3953488372092','1706.395348837209212','test'),('2019-11-08 23:59:59','2019-11-09 03:59:59','CNDBTC','4h','0.000000860000000','0.000000840000000','0.001467500000000','0.001433372093023','1706.3953488372092','1706.395348837209212','test'),('2019-11-09 15:59:59','2019-11-09 19:59:59','CNDBTC','4h','0.000000860000000','0.000000850000000','0.001467500000000','0.001450436046512','1706.3953488372092','1706.395348837209212','test'),('2019-11-10 03:59:59','2019-11-10 07:59:59','CNDBTC','4h','0.000000860000000','0.000000860000000','0.001467500000000','0.001467500000000','1706.3953488372092','1706.395348837209212','test'),('2019-11-21 19:59:59','2019-11-21 23:59:59','CNDBTC','4h','0.000000990000000','0.000000970000000','0.001467500000000','0.001437853535354','1482.3232323232323','1482.323232323232332','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','CNDBTC','4h','0.000000990000000','0.000000970000000','0.001467500000000','0.001437853535354','1482.3232323232323','1482.323232323232332','test'),('2019-11-25 07:59:59','2019-11-30 23:59:59','CNDBTC','4h','0.000001150000000','0.000001070000000','0.001467500000000','0.001365413043478','1276.0869565217392','1276.086956521739239','test'),('2019-12-03 19:59:59','2019-12-04 23:59:59','CNDBTC','4h','0.000001070000000','0.000001080000000','0.001467500000000','0.001481214953271','1371.495327102804','1371.495327102803913','test'),('2019-12-05 23:59:59','2019-12-06 03:59:59','CNDBTC','4h','0.000001060000000','0.000001060000000','0.001467500000000','0.001467500000000','1384.433962264151','1384.433962264150978','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:22:09
