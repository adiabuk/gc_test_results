-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 07:59:59','2019-01-12 15:59:59','ENJBNB','4h','0.006394000000000','0.006131000000000','0.711908500000000','0.682626057788552','111.3400844541758','111.340084454175795','test'),('2019-01-23 03:59:59','2019-01-23 07:59:59','ENJBNB','4h','0.005552000000000','0.005500000000000','0.711908500000000','0.705240769092219','128.22559438040346','128.225594380403464','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENJBNB','4h','0.005232000000000','0.005065000000000','0.711908500000000','0.689185120890673','136.06813837920492','136.068138379204925','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','ENJBNB','4h','0.005118000000000','0.005097000000000','0.711908500000000','0.708987421746776','139.0989644392341','139.098964439234095','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','ENJBNB','4h','0.003617000000000','0.003516000000000','0.711908500000000','0.692029385125795','196.82291954658558','196.822919546585581','test'),('2019-02-17 23:59:59','2019-02-18 03:59:59','ENJBNB','4h','0.003562000000000','0.003524000000000','0.711908500000000','0.704313743402583','199.86201572150478','199.862015721504775','test'),('2019-02-21 03:59:59','2019-02-21 07:59:59','ENJBNB','4h','0.003575000000000','0.003620000000000','0.711908500000000','0.720869586013986','199.13524475524477','199.135244755244770','test'),('2019-03-07 11:59:59','2019-03-07 19:59:59','ENJBNB','4h','0.006749000000000','0.006565000000000','0.711908500000000','0.692499526226108','105.4835531189806','105.483553118980595','test'),('2019-03-17 19:59:59','2019-03-18 03:59:59','ENJBNB','4h','0.010675000000000','0.010655000000000','0.711908500000000','0.710574713583138','66.68932084309134','66.689320843091338','test'),('2019-03-18 11:59:59','2019-03-24 11:59:59','ENJBNB','4h','0.013211000000000','0.010571000000000','0.711908500000000','0.569645352622814','53.887555824691546','53.887555824691546','test'),('2019-04-09 07:59:59','2019-04-09 11:59:59','ENJBNB','4h','0.008875000000000','0.008269000000000','0.711908500000000','0.663298184394366','80.21504225352113','80.215042253521133','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ENJBNB','4h','0.008592000000000','0.008274000000000','0.711908500000000','0.685559931215084','82.85713454376163','82.857134543761632','test'),('2019-04-13 19:59:59','2019-04-14 15:59:59','ENJBNB','4h','0.009085000000000','0.008346000000000','0.711908500000000','0.653999817391304','78.3608695652174','78.360869565217399','test'),('2019-04-17 11:59:59','2019-04-18 07:59:59','ENJBNB','4h','0.008369000000000','0.008102000000000','0.711908500000000','0.689196160473175','85.06494204803442','85.064942048034425','test'),('2019-04-19 07:59:59','2019-04-19 15:59:59','ENJBNB','4h','0.008866000000000','0.007818000000000','0.711908500000000','0.627757799796977','80.29646965937289','80.296469659372889','test'),('2019-04-20 19:59:59','2019-04-20 23:59:59','ENJBNB','4h','0.008436000000000','0.008080000000000','0.711908500000000','0.681865893788525','84.38934329065908','84.389343290659085','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','ENJBNB','4h','0.006727000000000','0.006688000000000','0.711908500000000','0.707781187453545','105.82852683216888','105.828526832168876','test'),('2019-06-02 19:59:59','2019-06-03 07:59:59','ENJBNB','4h','0.005154000000000','0.005001000000000','0.711908500000000','0.690775011350408','138.12737679472255','138.127376794722551','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','ENJBNB','4h','0.004997000000000','0.004919000000000','0.711908500000000','0.700796059935962','142.46718030818494','142.467180308184936','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','ENJBNB','4h','0.004935000000000','0.004787000000000','0.711908500000000','0.690558457852077','144.25704154002028','144.257041540020282','test'),('2019-06-09 15:59:59','2019-06-09 19:59:59','ENJBNB','4h','0.004984000000000','0.004765000000000','0.711908500000000','0.680626806280096','142.8387841091493','142.838784109149287','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ENJBNB','4h','0.004955000000000','0.004798000000000','0.711908500000000','0.689351560645812','143.6747729566095','143.674772956609502','test'),('2019-06-11 19:59:59','2019-06-12 03:59:59','ENJBNB','4h','0.005064000000000','0.004718000000000','0.711908500000000','0.663267042456556','140.58224723538706','140.582247235387058','test'),('2019-06-30 23:59:59','2019-07-02 07:59:59','ENJBNB','4h','0.003767000000000','0.003785000000000','0.711908500000000','0.715310239580568','188.98553225378288','188.985532253782878','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','ENJBNB','4h','0.003759000000000','0.003733000000000','0.711908500000000','0.706984418861399','189.38773610002661','189.387736100026615','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','ENJBNB','4h','0.003710000000000','0.003713000000000','0.711908500000000','0.712484167250674','191.8890835579515','191.889083557951494','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','ENJBNB','4h','0.003723000000000','0.003705000000000','0.711908500000000','0.708466557211926','191.21904378189632','191.219043781896318','test'),('2019-07-14 15:59:59','2019-07-15 07:59:59','ENJBNB','4h','0.003737000000000','0.003515000000000','0.711908500000000','0.669616905940594','190.50267594327002','190.502675943270020','test'),('2019-07-26 15:59:59','2019-07-27 03:59:59','ENJBNB','4h','0.003090000000000','0.003076000000000','0.474605666666667','0.472455349730313','153.59406688241643','153.594066882416428','test'),('2019-07-29 11:59:59','2019-07-29 15:59:59','ENJBNB','4h','0.003134000000000','0.003079000000000','0.531428390358834','0.522102110374872','169.5687269811213','169.568726981121301','test'),('2019-07-30 03:59:59','2019-07-31 15:59:59','ENJBNB','4h','0.003147000000000','0.003118000000000','0.531428390358834','0.526531211038718','168.86825241780554','168.868252417805536','test'),('2019-08-17 15:59:59','2019-08-17 19:59:59','ENJBNB','4h','0.002463000000000','0.002347000000000','0.531428390358834','0.506399688255048','215.76467330849943','215.764673308499425','test'),('2019-08-18 07:59:59','2019-08-18 11:59:59','ENJBNB','4h','0.002395000000000','0.002306000000000','0.531428390358834','0.511680111969717','221.8907684170497','221.890768417049713','test'),('2019-08-20 19:59:59','2019-08-20 23:59:59','ENJBNB','4h','0.002378000000000','0.002341000000000','0.531428390358834','0.523159740046270','223.47703547469894','223.477035474698937','test'),('2019-08-21 15:59:59','2019-08-26 07:59:59','ENJBNB','4h','0.002391000000000','0.002510000000000','0.531428390358834','0.557877565788655','222.2619784018545','222.261978401854492','test'),('2019-09-11 19:59:59','2019-09-12 03:59:59','ENJBNB','4h','0.003505000000000','0.003411000000000','0.531428390358834','0.517176102571750','151.62008284132213','151.620082841322130','test'),('2019-09-15 07:59:59','2019-09-16 15:59:59','ENJBNB','4h','0.003491000000000','0.003384000000000','0.531428390358834','0.515139980800428','152.22812671407448','152.228126714074477','test'),('2019-09-16 23:59:59','2019-09-17 07:59:59','ENJBNB','4h','0.003431000000000','0.003362000000000','0.531428390358834','0.520740964263014','154.8902332727584','154.890233272758394','test'),('2019-09-22 11:59:59','2019-09-22 15:59:59','ENJBNB','4h','0.003402000000000','0.003406000000000','0.531428390358834','0.532053232675540','156.21057917661201','156.210579176612015','test'),('2019-09-23 07:59:59','2019-09-23 11:59:59','ENJBNB','4h','0.003406000000000','0.003365000000000','0.531428390358834','0.525031278202430','156.02712576595243','156.027125765952434','test'),('2019-09-23 15:59:59','2019-09-24 19:59:59','ENJBNB','4h','0.003427000000000','0.003444000000000','0.531428390358834','0.534064597722738','155.07102140613776','155.071021406137760','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','ENJBNB','4h','0.003408000000000','0.003406000000000','0.531428390358834','0.531116519237731','155.93556055130108','155.935560551301080','test'),('2019-10-27 19:59:59','2019-10-27 23:59:59','ENJBNB','4h','0.003385000000000','0.003324000000000','0.531428390358834','0.521851689675854','156.9950931636142','156.995093163614200','test'),('2019-11-01 03:59:59','2019-11-02 11:59:59','ENJBNB','4h','0.003324000000000','0.003244000000000','0.531428390358834','0.518638296728056','159.87617038472743','159.876170384727430','test'),('2019-11-02 19:59:59','2019-11-03 07:59:59','ENJBNB','4h','0.003271000000000','0.003213000000000','0.531428390358834','0.522005325045226','162.46664333807217','162.466643338072174','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','ENJBNB','4h','0.003284000000000','0.003217000000000','0.531428390358834','0.520586215525082','161.82350498137455','161.823504981374555','test'),('2019-11-04 15:59:59','2019-11-04 23:59:59','ENJBNB','4h','0.003283000000000','0.003224000000000','0.531428390358834','0.521877895375230','161.87279633226746','161.872796332267455','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','ENJBNB','4h','0.003280000000000','0.003253000000000','0.531428390358834','0.527053827389417','162.02085071915673','162.020850719156726','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','ENJBNB','4h','0.003265000000000','0.003212000000000','0.531428390358834','0.522801834558216','162.7652037852478','162.765203785247792','test'),('2019-11-15 07:59:59','2019-11-15 11:59:59','ENJBNB','4h','0.003163000000000','0.003118000000000','0.531428390358834','0.523867758817213','168.01403425824662','168.014034258246625','test'),('2019-11-25 19:59:59','2019-11-25 23:59:59','ENJBNB','4h','0.003501000000000','0.003433000000000','0.531428390358834','0.521106445044809','151.7933134415407','151.793313441540704','test'),('2019-11-26 15:59:59','2019-11-27 07:59:59','ENJBNB','4h','0.003549000000000','0.003605000000000','0.531428390358834','0.539813848194871','149.74031850065765','149.740318500657651','test'),('2019-12-11 03:59:59','2019-12-11 07:59:59','ENJBNB','4h','0.005000000000000','0.005458000000000','0.531428390358834','0.580107230915703','106.28567807176681','106.285678071766810','test'),('2019-12-15 07:59:59','2019-12-15 11:59:59','ENJBNB','4h','0.005283000000000','0.005255000000000','0.531428390358834','0.528611809830716','100.59216171849972','100.592161718499725','test'),('2019-12-15 19:59:59','2019-12-20 23:59:59','ENJBNB','4h','0.005560000000000','0.005727000000000','0.531428390358834','0.547390358198749','95.58064574799174','95.580645747991738','test'),('2019-12-23 23:59:59','2019-12-24 03:59:59','ENJBNB','4h','0.005809000000000','0.005666000000000','0.531428390358834','0.518346231670366','91.48362719208711','91.483627192087113','test'),('2019-12-24 11:59:59','2019-12-25 19:59:59','ENJBNB','4h','0.005913000000000','0.005759000000000','0.531428390358834','0.517587705069597','89.87457980024253','89.874579800242529','test'),('2019-12-27 07:59:59','2019-12-27 11:59:59','ENJBNB','4h','0.005812000000000','0.005776000000000','0.531428390358834','0.528136679750968','91.43640577405954','91.436405774059537','test'),('2019-12-28 15:59:59','2019-12-29 03:59:59','ENJBNB','4h','0.005850000000000','0.005757000000000','0.531428390358834','0.522980041589027','90.84245989039898','90.842459890398985','test'),('2019-12-29 23:59:59','2019-12-30 03:59:59','ENJBNB','4h','0.005804000000000','0.005738000000000','0.531428390358834','0.525385269448482','91.56243803563646','91.562438035636461','test'),('2019-12-30 11:59:59','2019-12-31 23:59:59','ENJBNB','4h','0.005832000000000','0.005865000000000','0.531428390358834','0.534435444007984','91.12283785302367','91.122837853023668','test'),('2020-01-01 11:59:59','2020-01-01 15:59:59','ENJBNB','4h','0.005829000000000','0.005752000000000','0.531428390358834','0.524408320697206','91.16973586530005','91.169735865300055','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 21:14:39
