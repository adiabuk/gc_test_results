-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 11:59:59','2019-01-08 15:59:59','STORMETH','4h','0.000021520000000','0.000021500000000','0.072144500000000','0.072077451208178','3352.4395910780668','3352.439591078066769','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','STORMETH','4h','0.000022960000000','0.000023310000000','0.072144500000000','0.073244263719512','3142.1820557491287','3142.182055749128722','test'),('2019-02-01 11:59:59','2019-02-01 15:59:59','STORMETH','4h','0.000025260000000','0.000025320000000','0.072402678731922','0.072574656591143','2866.297653678642','2866.297653678641836','test'),('2019-02-06 11:59:59','2019-02-06 23:59:59','STORMETH','4h','0.000026020000000','0.000027350000000','0.072445673196728','0.076148699536146','2784.230330389229','2784.230330389229039','test'),('2019-02-26 15:59:59','2019-02-27 03:59:59','STORMETH','4h','0.000021130000000','0.000020890000000','0.073371429781582','0.072538058122918','3472.381911101858','3472.381911101857895','test'),('2019-03-02 15:59:59','2019-03-02 19:59:59','STORMETH','4h','0.000020770000000','0.000020710000000','0.073371429781582','0.073159475723474','3532.567635126721','3532.567635126721143','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','STORMETH','4h','0.000021400000000','0.000021300000000','0.073371429781582','0.073028572633070','3428.5714851206544','3428.571485120654415','test'),('2019-03-17 15:59:59','2019-03-21 15:59:59','STORMETH','4h','0.000023620000000','0.000024740000000','0.073371429781582','0.076850515359709','3106.3264090424213','3106.326409042421346','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','STORMETH','4h','0.000024440000000','0.000024210000000','0.073894155459793','0.073198752196464','3023.492449255033','3023.492449255033080','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','STORMETH','4h','0.000024400000000','0.000024750000000','0.073894155459793','0.074954112607782','3028.448994253811','3028.448994253811179','test'),('2019-03-27 11:59:59','2019-03-27 23:59:59','STORMETH','4h','0.000025060000000','0.000024580000000','0.073985293930958','0.072568177367237','2952.326174419713','2952.326174419712970','test'),('2019-03-31 03:59:59','2019-03-31 07:59:59','STORMETH','4h','0.000024980000000','0.000024490000000','0.073985293930958','0.072534021151688','2961.781182184067','2961.781182184066893','test'),('2019-03-31 11:59:59','2019-03-31 19:59:59','STORMETH','4h','0.000024650000000','0.000024870000000','0.073985293930958','0.074645608927502','3001.4318024729414','3001.431802472941399','test'),('2019-04-06 03:59:59','2019-04-06 07:59:59','STORMETH','4h','0.000024700000000','0.000024600000000','0.073985293930958','0.073685758327999','2995.3560295934412','2995.356029593441235','test'),('2019-04-07 15:59:59','2019-04-07 23:59:59','STORMETH','4h','0.000024840000000','0.000023500000000','0.073985293930958','0.069994138783314','2978.4739907793078','2978.473990779307769','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','STORMETH','4h','0.000013860000000','0.000013600000000','0.073985293930958','0.072597402414216','5338.044295162915','5338.044295162914750','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','STORMETH','4h','0.000013840000000','0.000013200000000','0.073985293930958','0.070564008662474','5345.758232005636','5345.758232005636273','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','STORMETH','4h','0.000013690000000','0.000013950000000','0.073985293930958','0.075390420039216','5404.331185606867','5404.331185606866711','test'),('2019-05-25 15:59:59','2019-05-25 19:59:59','STORMETH','4h','0.000013710000000','0.000013750000000','0.073985293930958','0.074201151827183','5396.447405613275','5396.447405613274896','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','STORMETH','4h','0.000014080000000','0.000013660000000','0.073985293930958','0.071778346242677','5254.637353050994','5254.637353050993624','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','STORMETH','4h','0.000013840000000','0.000013810000000','0.073985293930958','0.073824921183998','5345.758232005636','5345.758232005636273','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','STORMETH','4h','0.000013780000000','0.000013910000000','0.073985293930958','0.074683268402005','5369.034392667489','5369.034392667488646','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','STORMETH','4h','0.000014230000000','0.000013140000000','0.073985293930958','0.068318114002304','5199.247640966831','5199.247640966830659','test'),('2019-05-30 19:59:59','2019-05-31 03:59:59','STORMETH','4h','0.000013990000000','0.000013950000000','0.073985293930958','0.073773756278546','5288.441310290064','5288.441310290064393','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','STORMETH','4h','0.000014080000000','0.000013540000000','0.073985293930958','0.071147789760310','5254.637353050994','5254.637353050993624','test'),('2019-06-07 07:59:59','2019-06-10 19:59:59','STORMETH','4h','0.000013750000000','0.000013790000000','0.073985293930958','0.074200523876939','5380.748649524218','5380.748649524218308','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','STORMETH','4h','0.000013720000000','0.000013670000000','0.073985293930958','0.073715668224213','5392.514134909475','5392.514134909474706','test'),('2019-07-05 07:59:59','2019-07-05 11:59:59','STORMETH','4h','0.000009900000000','0.000009590000000','0.073985293930958','0.071668582706857','7473.262013228081','7473.262013228080832','test'),('2019-07-05 19:59:59','2019-07-06 03:59:59','STORMETH','4h','0.000009780000000','0.000009830000000','0.073985293930958','0.074363541854940','7564.958479648058','7564.958479648057619','test'),('2019-07-10 11:59:59','2019-07-17 03:59:59','STORMETH','4h','0.000009890000000','0.000010560000000','0.073985293930958','0.078997442255907','7480.818395445703','7480.818395445702663','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','STORMETH','4h','0.000010340000000','0.000010250000000','0.073985293930958','0.073341321353222','7155.250863729014','7155.250863729013872','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','STORMETH','4h','0.000010540000000','0.000010340000000','0.073985293930958','0.072581398410446','7019.477602557685','7019.477602557684804','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','STORMETH','4h','0.000010550000000','0.000010410000000','0.073985293930958','0.073003498561258','7012.824069285118','7012.824069285117730','test'),('2019-07-29 19:59:59','2019-07-29 23:59:59','STORMETH','4h','0.000010430000000','0.000010320000000','0.073985293930958','0.073205007993048','7093.508526458101','7093.508526458101187','test'),('2019-08-13 03:59:59','2019-08-13 07:59:59','STORMETH','4h','0.000008880000000','0.000008790000000','0.073985293930958','0.073235442978955','8331.677244477252','8331.677244477252316','test'),('2019-08-14 19:59:59','2019-08-14 23:59:59','STORMETH','4h','0.000009150000000','0.000008580000000','0.073985293930958','0.069376373981161','8085.824473328743','8085.824473328742897','test'),('2019-08-22 07:59:59','2019-08-22 19:59:59','STORMETH','4h','0.000009450000000','0.000008340000000','0.073985293930958','0.065294957818433','7829.131632905609','7829.131632905608967','test'),('2019-08-28 19:59:59','2019-08-29 03:59:59','STORMETH','4h','0.000008960000000','0.000008850000000','0.073985293930958','0.073076992331359','8257.287269080134','8257.287269080134138','test'),('2019-08-29 23:59:59','2019-08-30 03:59:59','STORMETH','4h','0.000008770000000','0.000009470000000','0.073985293930958','0.079890619558286','8436.179467612086','8436.179467612086228','test'),('2019-09-07 23:59:59','2019-09-08 07:59:59','STORMETH','4h','0.000009680000000','0.000008920000000','0.073985293930958','0.068176531184313','7643.108877165082','7643.108877165082049','test'),('2019-09-09 19:59:59','2019-09-10 03:59:59','STORMETH','4h','0.000009180000000','0.000008870000000','0.073985293930958','0.071486879865751','8059.400210344008','8059.400210344007974','test'),('2019-10-01 23:59:59','2019-10-02 03:59:59','STORMETH','4h','0.000007060000000','0.000006910000000','0.073985293930958','0.072413368422510','10479.503389654108','10479.503389654108105','test'),('2019-10-04 07:59:59','2019-10-04 11:59:59','STORMETH','4h','0.000007030000000','0.000007070000000','0.073985293930958','0.074406262886468','10524.22388776074','10524.223887760739672','test'),('2019-10-09 23:59:59','2019-10-10 03:59:59','STORMETH','4h','0.000007210000000','0.000007210000000','0.073985293930958','0.073985293930958','10261.483208177255','10261.483208177254710','test'),('2019-10-11 23:59:59','2019-10-12 03:59:59','STORMETH','4h','0.000007170000000','0.000007390000000','0.073985293930958','0.076255414525771','10318.72997642371','10318.729976423710468','test'),('2019-10-14 15:59:59','2019-10-14 19:59:59','STORMETH','4h','0.000007300000000','0.000007210000000','0.073985293930958','0.073073146471535','10134.97177136411','10134.971771364109372','test'),('2019-10-16 19:59:59','2019-10-17 03:59:59','STORMETH','4h','0.000007250000000','0.000007240000000','0.073985293930958','0.073883245249674','10204.868128408','10204.868128407999393','test'),('2019-10-18 03:59:59','2019-10-18 07:59:59','STORMETH','4h','0.000007200000000','0.000007030000000','0.073985293930958','0.072238418935366','10275.735268188611','10275.735268188611371','test'),('2019-10-18 19:59:59','2019-10-18 23:59:59','STORMETH','4h','0.000007200000000','0.000007290000000','0.073985293930958','0.074910110105095','10275.735268188611','10275.735268188611371','test'),('2019-10-19 11:59:59','2019-10-23 15:59:59','STORMETH','4h','0.000007400000000','0.000007420000000','0.073985293930958','0.074185254184825','9998.012693372702','9998.012693372702415','test'),('2019-10-25 03:59:59','2019-10-25 07:59:59','STORMETH','4h','0.000007630000000','0.000007370000000','0.073985293930958','0.071464169891371','9696.630921488597','9696.630921488596869','test'),('2019-10-28 19:59:59','2019-10-28 23:59:59','STORMETH','4h','0.000007440000000','0.000007220000000','0.073985293930958','0.071797556744828','9944.25993695672','9944.259936956719685','test'),('2019-10-29 03:59:59','2019-10-29 07:59:59','STORMETH','4h','0.000007390000000','0.000007260000000','0.073985293930958','0.072683793496449','10011.541803918537','10011.541803918536971','test'),('2019-10-29 15:59:59','2019-10-29 19:59:59','STORMETH','4h','0.000007420000000','0.000007190000000','0.073985293930958','0.071691949240376','9971.063872096765','9971.063872096765408','test'),('2019-10-31 15:59:59','2019-10-31 19:59:59','STORMETH','4h','0.000007290000000','0.000007430000000','0.073985293930958','0.075406136338411','10148.874338951715','10148.874338951714890','test'),('2019-11-02 23:59:59','2019-11-03 07:59:59','STORMETH','4h','0.000007340000000','0.000007290000000','0.073985293930958','0.073481306915080','10079.740317569209','10079.740317569208855','test'),('2019-11-04 03:59:59','2019-11-04 23:59:59','STORMETH','4h','0.000007520000000','0.000007700000000','0.073985293930958','0.075756218519731','9838.469937627393','9838.469937627392937','test'),('2019-11-06 11:59:59','2019-11-06 15:59:59','STORMETH','4h','0.000007490000000','0.000007260000000','0.073985293930958','0.071713382368325','9877.87635927343','9877.876359273430353','test'),('2019-11-07 07:59:59','2019-11-08 07:59:59','STORMETH','4h','0.000008070000000','0.000007630000000','0.073985293930958','0.069951399342405','9167.942246711027','9167.942246711027110','test'),('2019-11-11 07:59:59','2019-11-11 11:59:59','STORMETH','4h','0.000007450000000','0.000007420000000','0.073985293930958','0.073687366572847','9930.911937041343','9930.911937041342753','test'),('2019-12-02 03:59:59','2019-12-02 07:59:59','STORMETH','4h','0.000009640000000','0.000009000000000','0.073985293930958','0.069073407196952','7674.823021883611','7674.823021883610636','test'),('2019-12-02 11:59:59','2019-12-04 07:59:59','STORMETH','4h','0.000009510000000','0.000009450000000','0.073985293930958','0.073518509742119','7779.736480647529','7779.736480647528879','test'),('2019-12-07 19:59:59','2019-12-08 03:59:59','STORMETH','4h','0.000009320000000','0.000009350000000','0.073985293930958','0.074223444018719','7938.3362586864805','7938.336258686480505','test'),('2019-12-10 15:59:59','2019-12-10 19:59:59','STORMETH','4h','0.000009690000000','0.000009210000000','0.073985293930958','0.070320387730044','7635.22125190485','7635.221251904849851','test'),('2019-12-11 07:59:59','2019-12-11 11:59:59','STORMETH','4h','0.000009450000000','0.000009690000000','0.073985293930958','0.075864285522855','7829.131632905609','7829.131632905608967','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','STORMETH','4h','0.000009560000000','0.000009520000000','0.073985293930958','0.073675732031665','7739.047482317782','7739.047482317781942','test'),('2019-12-16 19:59:59','2019-12-18 23:59:59','STORMETH','4h','0.000010010000000','0.000009140000000','0.073985293930958','0.067555003649246','7391.138254840958','7391.138254840958325','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31 10:52:29
