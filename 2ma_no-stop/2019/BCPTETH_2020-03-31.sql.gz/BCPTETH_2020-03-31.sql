-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 23:59:59','2019-01-13 11:59:59','BCPTETH','4h','0.000233250000000','0.000232560000000','0.072144500000000','0.071931082186495','309.30117899249734','309.301178992497341','test'),('2019-01-14 23:59:59','2019-01-15 11:59:59','BCPTETH','4h','0.000239680000000','0.000228800000000','0.072144500000000','0.068869582777036','301.0034212283044','301.003421228304376','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','BCPTETH','4h','0.000232600000000','0.000241050000000','0.072144500000000','0.074765398645744','310.1655202063629','310.165520206362885','test'),('2019-01-28 07:59:59','2019-01-28 11:59:59','BCPTETH','4h','0.000279330000000','0.000278130000000','0.072144500000000','0.071834567661905','258.27694841227225','258.276948412272247','test'),('2019-01-29 19:59:59','2019-01-30 03:59:59','BCPTETH','4h','0.000276660000000','0.000283650000000','0.072144500000000','0.073967279060941','260.7695366153401','260.769536615340087','test'),('2019-02-01 19:59:59','2019-02-02 15:59:59','BCPTETH','4h','0.000280790000000','0.000278260000000','0.072305852583030','0.071654355709797','257.50864554660154','257.508645546601542','test'),('2019-02-04 15:59:59','2019-02-04 19:59:59','BCPTETH','4h','0.000275490000000','0.000275670000000','0.072305852583030','0.072353095871225','262.46271219655887','262.462712196558869','test'),('2019-02-06 15:59:59','2019-02-06 19:59:59','BCPTETH','4h','0.000275960000000','0.000268000000000','0.072305852583030','0.070220207610712','262.01570003996954','262.015700039969545','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','BCPTETH','4h','0.000275400000000','0.000275580000000','0.072305852583030','0.072353111310208','262.54848432472767','262.548484324727667','test'),('2019-02-21 03:59:59','2019-02-21 07:59:59','BCPTETH','4h','0.000251000000000','0.000258680000000','0.072305852583030','0.074518238829395','288.07112582880484','288.071125828804838','test'),('2019-02-26 19:59:59','2019-03-16 07:59:59','BCPTETH','4h','0.000242640000000','0.000338710000000','0.072305852583030','0.100934369141107','297.99642508667165','297.996425086671650','test'),('2019-03-20 15:59:59','2019-03-20 23:59:59','BCPTETH','4h','0.000333570000000','0.000335470000000','0.079355418326596','0.079807423287535','237.89734786280616','237.897347862806157','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','BCPTETH','4h','0.000321950000000','0.000330000000000','0.079468419566831','0.081455438599330','246.83466242221152','246.834662422211522','test'),('2019-04-05 23:59:59','2019-04-06 11:59:59','BCPTETH','4h','0.000354430000000','0.000344700000000','0.079965174324956','0.077769928024751','225.61626929141366','225.616269291413658','test'),('2019-04-07 03:59:59','2019-04-07 23:59:59','BCPTETH','4h','0.000362250000000','0.000353950000000','0.079965174324956','0.078132983995357','220.7458228432188','220.745822843218804','test'),('2019-04-10 03:59:59','2019-04-10 07:59:59','BCPTETH','4h','0.000352660000000','0.000359360000000','0.079965174324956','0.081484390192866','226.7486370015199','226.748637001519910','test'),('2019-04-13 23:59:59','2019-04-14 07:59:59','BCPTETH','4h','0.000352080000000','0.000338870000000','0.079965174324956','0.076964890432566','227.12217202043854','227.122172020438541','test'),('2019-04-14 11:59:59','2019-04-14 23:59:59','BCPTETH','4h','0.000354390000000','0.000342590000000','0.079965174324956','0.077302601856674','225.64173460017497','225.641734600174971','test'),('2019-04-16 07:59:59','2019-04-16 11:59:59','BCPTETH','4h','0.000344670000000','0.000342100000000','0.079965174324956','0.079368921393122','232.0050318419242','232.005031841924193','test'),('2019-04-19 11:59:59','2019-04-21 11:59:59','BCPTETH','4h','0.000358050000000','0.000342230000000','0.079965174324956','0.076432011197402','223.33521665956152','223.335216659561524','test'),('2019-04-21 19:59:59','2019-04-22 03:59:59','BCPTETH','4h','0.000348440000000','0.000349020000000','0.079965174324956','0.080098281319298','229.4948178307772','229.494817830777208','test'),('2019-05-22 15:59:59','2019-05-31 23:59:59','BCPTETH','4h','0.000211360000000','0.000281260000000','0.079965174324956','0.106410886310736','378.3363660340462','378.336366034046193','test'),('2019-06-18 15:59:59','2019-06-19 07:59:59','BCPTETH','4h','0.000238400000000','0.000230570000000','0.083534755774498','0.080791143619656','350.39746549705427','350.397465497054270','test'),('2019-07-01 11:59:59','2019-07-01 15:59:59','BCPTETH','4h','0.000194330000000','0.000193040000000','0.083534755774498','0.082980235963099','429.8603189136932','429.860318913693220','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','BCPTETH','4h','0.000196180000000','0.000187660000000','0.083534755774498','0.079906882804783','425.80668658628804','425.806686586288038','test'),('2019-07-04 03:59:59','2019-07-04 07:59:59','BCPTETH','4h','0.000194880000000','0.000185300000000','0.083534755774498','0.079428316117685','428.64714580510054','428.647145805100536','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','BCPTETH','4h','0.000198340000000','0.000193880000000','0.083534755774498','0.081656339868709','421.1694856029948','421.169485602994826','test'),('2019-07-12 15:59:59','2019-07-12 19:59:59','BCPTETH','4h','0.000186330000000','0.000183000000000','0.083534755774498','0.082041862860157','448.3161904926635','448.316190492663509','test'),('2019-07-13 07:59:59','2019-07-13 11:59:59','BCPTETH','4h','0.000183250000000','0.000189130000000','0.083534755774498','0.086215161580523','455.8513275552414','455.851327555241426','test'),('2019-07-18 23:59:59','2019-07-19 07:59:59','BCPTETH','4h','0.000190410000000','0.000188660000000','0.083534755774498','0.082767013415350','438.70991951314534','438.709919513145337','test'),('2019-07-19 15:59:59','2019-07-19 19:59:59','BCPTETH','4h','0.000193260000000','0.000191110000000','0.083534755774498','0.082605439180712','432.24027617974747','432.240276179747468','test'),('2019-07-21 03:59:59','2019-07-21 07:59:59','BCPTETH','4h','0.000189890000000','0.000188290000000','0.083534755774498','0.082830897702776','439.9112948259413','439.911294825941297','test'),('2019-07-21 11:59:59','2019-07-24 19:59:59','BCPTETH','4h','0.000191760000000','0.000194410000000','0.083534755774498','0.084689152430748','435.6213797168231','435.621379716823128','test'),('2019-07-25 15:59:59','2019-07-25 19:59:59','BCPTETH','4h','0.000192270000000','0.000197680000000','0.083534755774498','0.085885216214192','434.4658853409164','434.465885340916373','test'),('2019-08-12 07:59:59','2019-08-13 23:59:59','BCPTETH','4h','0.000176430000000','0.000173600000000','0.083534755774498','0.082194828557801','473.47251473387746','473.472514733877460','test'),('2019-08-17 23:59:59','2019-08-18 11:59:59','BCPTETH','4h','0.000167870000000','0.000164720000000','0.083534755774498','0.081967266165338','497.6157489396437','497.615748939643709','test'),('2019-08-21 15:59:59','2019-08-22 19:59:59','BCPTETH','4h','0.000170740000000','0.000170070000000','0.083534755774498','0.083206957447399','489.2512344763851','489.251234476385093','test'),('2019-08-29 19:59:59','2019-08-30 03:59:59','BCPTETH','4h','0.000176920000000','0.000175410000000','0.083534755774498','0.082821792394329','472.1611789198394','472.161178919839415','test'),('2019-08-31 11:59:59','2019-08-31 15:59:59','BCPTETH','4h','0.000174910000000','0.000173580000000','0.083534755774498','0.082899564961051','477.5870777799897','477.587077779989727','test'),('2019-08-31 19:59:59','2019-08-31 23:59:59','BCPTETH','4h','0.000177580000000','0.000173370000000','0.083534755774498','0.081554345132474','470.4063282717536','470.406328271753580','test'),('2019-09-01 11:59:59','2019-09-01 15:59:59','BCPTETH','4h','0.000175230000000','0.000173330000000','0.083534755774498','0.082628997422780','476.7149219568453','476.714921956845274','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','BCPTETH','4h','0.000174650000000','0.000173270000000','0.083534755774498','0.082874704454894','478.2980576839279','478.298057683927880','test'),('2019-09-02 07:59:59','2019-09-02 15:59:59','BCPTETH','4h','0.000174610000000','0.000170800000000','0.083534755774498','0.081712022715104','478.4076271376095','478.407627137609495','test'),('2019-09-10 11:59:59','2019-09-12 23:59:59','BCPTETH','4h','0.000175020000000','0.000198520000000','0.083534755774498','0.094750998265075','477.286914492618','477.286914492617996','test'),('2019-09-22 19:59:59','2019-09-22 23:59:59','BCPTETH','4h','0.000178850000000','0.000169010000000','0.083534755774498','0.078938826242370','467.06600936258315','467.066009362583145','test'),('2019-09-23 03:59:59','2019-09-23 07:59:59','BCPTETH','4h','0.000176860000000','0.000173570000000','0.083534755774498','0.081980818499263','472.32136025386177','472.321360253861769','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','BCPTETH','4h','0.000174010000000','0.000160430000000','0.083534755774498','0.077015578811003','480.05721380666625','480.057213806666255','test'),('2019-09-27 07:59:59','2019-09-27 11:59:59','BCPTETH','4h','0.000171170000000','0.000169510000000','0.083534755774498','0.082724638963225','488.02217546589935','488.022175465899352','test'),('2019-10-02 03:59:59','2019-10-02 07:59:59','BCPTETH','4h','0.000166000000000','0.000165670000000','0.083534755774498','0.083368692705790','503.2214203283012','503.221420328301178','test'),('2019-10-15 11:59:59','2019-10-15 19:59:59','BCPTETH','4h','0.000171330000000','0.000169120000000','0.083534755774498','0.082457233972936','487.5664260462149','487.566426046214872','test'),('2019-10-19 15:59:59','2019-10-20 07:59:59','BCPTETH','4h','0.000169850000000','0.000168990000000','0.083534755774498','0.083111794985766','491.8148706181807','491.814870618180692','test'),('2019-10-20 23:59:59','2019-10-21 03:59:59','BCPTETH','4h','0.000169900000000','0.000170030000000','0.083534755774498','0.083598672891924','491.6701340464861','491.670134046486112','test'),('2019-10-30 15:59:59','2019-10-31 15:59:59','BCPTETH','4h','0.000173570000000','0.000168420000000','0.083534755774498','0.081056193855741','481.27415898195534','481.274158981955338','test'),('2019-11-01 07:59:59','2019-11-02 15:59:59','BCPTETH','4h','0.000171740000000','0.000170710000000','0.083534755774498','0.083033761256926','486.40244424419467','486.402444244194669','test'),('2019-11-03 15:59:59','2019-11-03 19:59:59','BCPTETH','4h','0.000169440000000','0.000170150000000','0.083534755774498','0.083884789276622','493.00493256903917','493.004932569039170','test'),('2019-11-13 11:59:59','2019-11-13 15:59:59','BCPTETH','4h','0.000165570000000','0.000156430000000','0.083534755774498','0.078923366828560','504.5283310653983','504.528331065398277','test'),('2019-11-13 19:59:59','2019-11-13 23:59:59','BCPTETH','4h','0.000164130000000','0.000160430000000','0.083534755774498','0.081651622914170','508.9548271156888','508.954827115688772','test'),('2019-11-14 15:59:59','2019-11-14 19:59:59','BCPTETH','4h','0.000161460000000','0.000159430000000','0.083534755774498','0.082484492215584','517.371211287613','517.371211287613050','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','BCPTETH','4h','0.000160110000000','0.000159860000000','0.083534755774498','0.083404322391551','521.7335317875086','521.733531787508582','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','BCPTETH','4h','0.000160430000000','0.000159860000000','0.083534755774498','0.083237960843429','520.6928615252633','520.692861525263311','test'),('2019-11-18 11:59:59','2019-11-18 15:59:59','BCPTETH','4h','0.000162710000000','0.000160430000000','0.083534755774498','0.082364211596722','513.3965691997911','513.396569199791088','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','BCPTETH','4h','0.000159860000000','0.000154140000000','0.083534755774498','0.080545772895541','522.5494543631802','522.549454363180189','test'),('2019-11-25 07:59:59','2019-11-30 23:59:59','BCPTETH','4h','0.000171290000000','0.000168340000000','0.083534755774498','0.082096098937936','487.68028358046587','487.680283580465868','test'),('2019-12-01 07:59:59','2019-12-01 15:59:59','BCPTETH','4h','0.000167860000000','0.000166140000000','0.083534755774498','0.082678805697457','497.6453936286071','497.645393628607110','test'),('2019-12-02 03:59:59','2019-12-02 07:59:59','BCPTETH','4h','0.000167560000000','0.000164410000000','0.083534755774498','0.081964366178594','498.536379652053','498.536379652052972','test'),('2019-12-02 15:59:59','2019-12-02 23:59:59','BCPTETH','4h','0.000170400000000','0.000166710000000','0.083534755774498','0.081725816520931','490.22743999118546','490.227439991185463','test'),('2019-12-06 07:59:59','2019-12-06 11:59:59','BCPTETH','4h','0.000167290000000','0.000170340000000','0.083534755774498','0.085057745822392','499.3409993095702','499.340999309570179','test'),('2019-12-19 03:59:59','2019-12-19 07:59:59','BCPTETH','4h','0.000165000000000','0.000160530000000','0.083534755774498','0.081271723299880','506.2712471181697','506.271247118169697','test'),('2019-12-19 23:59:59','2019-12-22 19:59:59','BCPTETH','4h','0.000171290000000','0.000165150000000','0.083534755774498','0.080540398833314','487.68028358046587','487.680283580465868','test'),('2019-12-25 07:59:59','2019-12-25 15:59:59','BCPTETH','4h','0.000166110000000','0.000162980000000','0.083534755774498','0.081960715767429','502.8881811721028','502.888181172102804','test'),('2019-12-27 23:59:59','2019-12-28 03:59:59','BCPTETH','4h','0.000169230000000','0.000163820000000','0.083534755774498','0.080864289375278','493.616709652532','493.616709652531995','test'),('2019-12-29 03:59:59','2019-12-29 07:59:59','BCPTETH','4h','0.000165350000000','0.000161660000000','0.083534755774498','0.081670569207773','505.1996115784578','505.199611578457791','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','BCPTETH','4h','0.000165680000000','0.000160990000000','0.083534755774498','0.081170088919220','504.19335933424674','504.193359334246736','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31 10:23:40
