-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-25 19:59:59','CNDETH','4h','0.000072410000000','0.000091910000000','0.072144500000000','0.091573000897666','996.3333793674906','996.333379367490579','test'),('2019-01-27 03:59:59','2019-01-27 07:59:59','CNDETH','4h','0.000091990000000','0.000090880000000','0.077001625224417','0.076072482882868','837.0651725667627','837.065172566762726','test'),('2019-01-29 03:59:59','2019-01-29 23:59:59','CNDETH','4h','0.000093580000000','0.000092930000000','0.077001625224417','0.076466777432198','822.84275726028','822.842757260279996','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','CNDETH','4h','0.000091930000000','0.000091080000000','0.077001625224417','0.076289655449145','837.6115003199935','837.611500319993524','test'),('2019-02-01 07:59:59','2019-02-01 11:59:59','CNDETH','4h','0.000092890000000','0.000091530000000','0.077001625224417','0.075874246493604','828.9549491271074','828.954949127107398','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','CNDETH','4h','0.000093400000000','0.000092730000000','0.077001625224417','0.076449258105569','824.4285355933298','824.428535593329798','test'),('2019-02-09 15:59:59','2019-02-10 23:59:59','CNDETH','4h','0.000102190000000','0.000093100000000','0.077001625224417','0.070152180334604','753.5142893083179','753.514289308317871','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','CNDETH','4h','0.000095690000000','0.000095310000000','0.077001625224417','0.076695839692122','804.698769196541','804.698769196540979','test'),('2019-02-15 11:59:59','2019-02-15 19:59:59','CNDETH','4h','0.000094400000000','0.000092240000000','0.077001625224417','0.075239723630299','815.6951824620445','815.695182462044500','test'),('2019-02-15 23:59:59','2019-02-16 07:59:59','CNDETH','4h','0.000095370000000','0.000093020000000','0.077001625224417','0.075104238003306','807.3988174941491','807.398817494149057','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CNDETH','4h','0.000086030000000','0.000084950000000','0.077001625224417','0.076034965277394','895.0555065025806','895.055506502580556','test'),('2019-02-26 03:59:59','2019-03-05 19:59:59','CNDETH','4h','0.000088930000000','0.000096620000000','0.077001625224417','0.083660148759509','865.8678199079839','865.867819907983858','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','CNDETH','4h','0.000095320000000','0.000094700000000','0.077001625224417','0.076500775375076','807.822337646003','807.822337646003007','test'),('2019-03-24 15:59:59','2019-03-24 23:59:59','CNDETH','4h','0.000112540000000','0.000111000000000','0.077001625224417','0.075947933178517','684.2156142208726','684.215614220872567','test'),('2019-03-25 11:59:59','2019-03-26 11:59:59','CNDETH','4h','0.000111470000000','0.000112510000000','0.077001625224417','0.077720039956932','690.7833966485781','690.783396648578105','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','CNDETH','4h','0.000121730000000','0.000118150000000','0.077001625224417','0.074737057588638','632.5607921171198','632.560792117119831','test'),('2019-04-13 15:59:59','2019-04-20 11:59:59','CNDETH','4h','0.000119970000000','0.000119600000000','0.077001625224417','0.076764144176380','641.8406703710677','641.840670371067745','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','CNDETH','4h','0.000078800000000','0.000077000000000','0.077001625224417','0.075242704851270','977.177985081434','977.177985081434031','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','CNDETH','4h','0.000074860000000','0.000070060000000','0.077001625224417','0.072064304878742','1028.608405348878','1028.608405348878023','test'),('2019-06-02 07:59:59','2019-06-05 15:59:59','CNDETH','4h','0.000074540000000','0.000074690000000','0.077001625224417','0.077156578857147','1033.0242181971694','1033.024218197169375','test'),('2019-06-07 15:59:59','2019-06-10 03:59:59','CNDETH','4h','0.000075470000000','0.000075510000000','0.077001625224417','0.077042437004051','1020.2944908495695','1020.294490849569456','test'),('2019-07-05 19:59:59','2019-07-06 03:59:59','CNDETH','4h','0.000048080000000','0.000046690000000','0.077001625224417','0.074775496708154','1601.531306664247','1601.531306664247040','test'),('2019-07-06 07:59:59','2019-07-06 15:59:59','CNDETH','4h','0.000048070000000','0.000046650000000','0.077001625224417','0.074726977672541','1601.8644731520076','1601.864473152007577','test'),('2019-07-06 19:59:59','2019-07-06 23:59:59','CNDETH','4h','0.000047550000000','0.000046650000000','0.077001625224417','0.075544181213860','1619.3822339519875','1619.382233951987473','test'),('2019-07-07 11:59:59','2019-07-07 15:59:59','CNDETH','4h','0.000047560000000','0.000046570000000','0.077001625224417','0.075398773900360','1619.0417414721826','1619.041741472182593','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','CNDETH','4h','0.000048790000000','0.000044620000000','0.077001625224417','0.070420424626224','1578.2255631157411','1578.225563115741124','test'),('2019-07-10 03:59:59','2019-07-10 15:59:59','CNDETH','4h','0.000049470000000','0.000047390000000','0.077001625224417','0.073764039203257','1556.5317409423287','1556.531740942328724','test'),('2019-07-14 15:59:59','2019-07-15 11:59:59','CNDETH','4h','0.000046100000000','0.000047260000000','0.077001625224417','0.078939193234402','1670.3172499873535','1670.317249987353534','test'),('2019-07-16 11:59:59','2019-07-16 15:59:59','CNDETH','4h','0.000046040000000','0.000045610000000','0.077001625224417','0.076282452790740','1672.4940318074935','1672.494031807493457','test'),('2019-07-19 19:59:59','2019-07-19 23:59:59','CNDETH','4h','0.000045570000000','0.000045300000000','0.077001625224417','0.076545394396886','1689.7438056707704','1689.743805670770371','test'),('2019-07-22 03:59:59','2019-07-22 11:59:59','CNDETH','4h','0.000045440000000','0.000045050000000','0.077001625224417','0.076340739796655','1694.5780199035432','1694.578019903543236','test'),('2019-07-24 19:59:59','2019-07-27 03:59:59','CNDETH','4h','0.000047400000000','0.000046280000000','0.077001625224417','0.075182177539789','1624.5068612746204','1624.506861274620405','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','CNDETH','4h','0.000045960000000','0.000045220000000','0.077001625224417','0.075761825340473','1675.4052485730417','1675.405248573041717','test'),('2019-07-29 07:59:59','2019-07-29 23:59:59','CNDETH','4h','0.000046090000000','0.000045500000000','0.077001625224417','0.076015924228921','1670.6796533828813','1670.679653382881270','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','CNDETH','4h','0.000052270000000','0.000047450000000','0.077001625224417','0.069901035333816','1473.1514295851732','1473.151429585173219','test'),('2019-08-20 11:59:59','2019-08-20 15:59:59','CNDETH','4h','0.000040310000000','0.000037380000000','0.077001625224417','0.071404632867495','1910.2362992909204','1910.236299290920442','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','CNDETH','4h','0.000037680000000','0.000037920000000','0.077001625224417','0.077492081436038','2043.5675484187104','2043.567548418710430','test'),('2019-08-24 07:59:59','2019-08-24 11:59:59','CNDETH','4h','0.000038200000000','0.000038810000000','0.077001625224417','0.078231232328786','2015.7493514245289','2015.749351424528868','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','CNDETH','4h','0.000039510000000','0.000039270000000','0.077001625224417','0.076533885663449','1948.9148373681853','1948.914837368185317','test'),('2019-08-30 19:59:59','2019-08-31 19:59:59','CNDETH','4h','0.000041320000000','0.000039150000000','0.077001625224417','0.072957735419553','1863.5436888774686','1863.543688877468639','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','CNDETH','4h','0.000040500000000','0.000037000000000','0.077001625224417','0.070347163785270','1901.274696899185','1901.274696899185074','test'),('2019-09-10 19:59:59','2019-09-10 23:59:59','CNDETH','4h','0.000036290000000','0.000035980000000','0.077001625224417','0.076343854383426','2121.8414225521356','2121.841422552135555','test'),('2019-09-11 07:59:59','2019-09-11 19:59:59','CNDETH','4h','0.000037830000000','0.000036670000000','0.077001625224417','0.074640486306618','2035.464584309199','2035.464584309198926','test'),('2019-09-13 15:59:59','2019-09-13 19:59:59','CNDETH','4h','0.000036300000000','0.000036060000000','0.077001625224417','0.076492523570041','2121.256893234628','2121.256893234628023','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','CNDETH','4h','0.000035750000000','0.000036150000000','0.077001625224417','0.077863181870285','2153.891614669007','2153.891614669007140','test'),('2019-09-19 07:59:59','2019-09-19 11:59:59','CNDETH','4h','0.000036100000000','0.000037740000000','0.077001625224417','0.080499759999155','2133.0090089866203','2133.009008986620302','test'),('2019-09-20 07:59:59','2019-09-21 07:59:59','CNDETH','4h','0.000037520000000','0.000036920000000','0.077001625224417','0.075770255951105','2052.2821221859544','2052.282122185954449','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','CNDETH','4h','0.000044080000000','0.000043630000000','0.077001625224417','0.076215537852571','1746.8608263252497','1746.860826325249718','test'),('2019-10-01 23:59:59','2019-10-02 03:59:59','CNDETH','4h','0.000043730000000','0.000043730000000','0.077001625224417','0.077001625224417','1760.8421043772466','1760.842104377246642','test'),('2019-10-18 19:59:59','2019-10-18 23:59:59','CNDETH','4h','0.000043310000000','0.000043870000000','0.077001625224417','0.077997259261029','1777.9179225217504','1777.917922521750370','test'),('2019-10-25 03:59:59','2019-10-25 07:59:59','CNDETH','4h','0.000044470000000','0.000043400000000','0.077001625224417','0.075148876427697','1731.5409315137622','1731.540931513762189','test'),('2019-10-30 15:59:59','2019-10-30 19:59:59','CNDETH','4h','0.000043600000000','0.000042400000000','0.077001625224417','0.074882314438424','1766.0923216609403','1766.092321660940343','test'),('2019-10-31 23:59:59','2019-11-02 11:59:59','CNDETH','4h','0.000043940000000','0.000041820000000','0.077001625224417','0.073286480812133','1752.426609567979','1752.426609567979085','test'),('2019-11-03 15:59:59','2019-11-04 23:59:59','CNDETH','4h','0.000043460000000','0.000043860000000','0.077001625224417','0.077710337835778','1771.7815284035205','1771.781528403520497','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','CNDETH','4h','0.000043140000000','0.000041860000000','0.077001625224417','0.074716922389757','1784.924089578512','1784.924089578511939','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','CNDETH','4h','0.000042710000000','0.000042000000000','0.077001625224417','0.075721570110642','1802.894526443854','1802.894526443853920','test'),('2019-11-21 19:59:59','2019-11-22 03:59:59','CNDETH','4h','0.000047520000000','0.000046110000000','0.077001625224417','0.074716854778996','1620.4045712208965','1620.404571220896514','test'),('2019-11-23 11:59:59','2019-12-01 03:59:59','CNDETH','4h','0.000045530000000','0.000051210000000','0.077001625224417','0.086607802058915','1691.2283159327258','1691.228315932725764','test'),('2019-12-03 19:59:59','2019-12-05 15:59:59','CNDETH','4h','0.000052990000000','0.000051660000000','0.077001625224417','0.075068955634901','1453.135029711587','1453.135029711587094','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:27:16
