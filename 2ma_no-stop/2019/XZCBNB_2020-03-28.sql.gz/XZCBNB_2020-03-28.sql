-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 07:59:59','2019-01-03 11:59:59','XZCBNB','4h','0.944000000000000','0.930000000000000','0.711908500000000','0.701350534957627','0.7541403601694916','0.754140360169492','test'),('2019-01-19 11:59:59','2019-01-19 19:59:59','XZCBNB','4h','0.851000000000000','0.830000000000000','0.711908500000000','0.694340840188014','0.8365552291421857','0.836555229142186','test'),('2019-01-19 23:59:59','2019-01-20 03:59:59','XZCBNB','4h','0.855000000000000','0.840000000000000','0.711908500000000','0.699418877192982','0.8326415204678363','0.832641520467836','test'),('2019-01-30 07:59:59','2019-01-30 19:59:59','XZCBNB','4h','0.770000000000000','0.785000000000000','0.711908500000000','0.725776847402597','0.9245564935064936','0.924556493506494','test'),('2019-02-18 19:59:59','2019-02-18 23:59:59','XZCBNB','4h','0.577000000000000','0.578000000000000','0.711908500000000','0.713142310225303','1.233810225303293','1.233810225303293','test'),('2019-02-25 19:59:59','2019-02-27 15:59:59','XZCBNB','4h','0.553000000000000','0.547000000000000','0.711908500000000','0.704184357142857','1.2873571428571429','1.287357142857143','test'),('2019-03-12 15:59:59','2019-03-12 23:59:59','XZCBNB','4h','0.602000000000000','0.452000000000000','0.711908500000000','0.534522661129568','1.1825722591362127','1.182572259136213','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','XZCBNB','4h','0.452000000000000','0.455000000000000','0.711908500000000','0.716633556415929','1.5750188053097345','1.575018805309734','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','XZCBNB','4h','0.440000000000000','0.442000000000000','0.711908500000000','0.715144447727273','1.6179738636363639','1.617973863636364','test'),('2019-03-27 11:59:59','2019-03-28 07:59:59','XZCBNB','4h','0.434000000000000','0.435000000000000','0.711908500000000','0.713548842165899','1.6403421658986177','1.640342165898618','test'),('2019-03-29 07:59:59','2019-03-29 19:59:59','XZCBNB','4h','0.434000000000000','0.430000000000000','0.711908500000000','0.705347131336406','1.6403421658986177','1.640342165898618','test'),('2019-03-31 19:59:59','2019-03-31 23:59:59','XZCBNB','4h','0.437000000000000','0.473000000000000','0.711908500000000','0.770555424485126','1.6290812356979407','1.629081235697941','test'),('2019-04-01 23:59:59','2019-04-02 07:59:59','XZCBNB','4h','0.435000000000000','0.426000000000000','0.711908500000000','0.697179358620690','1.6365712643678163','1.636571264367816','test'),('2019-04-03 15:59:59','2019-04-04 19:59:59','XZCBNB','4h','0.459000000000000','0.437000000000000','0.711908500000000','0.677786523965142','1.5509989106753814','1.550998910675381','test'),('2019-04-11 15:59:59','2019-04-12 03:59:59','XZCBNB','4h','0.459000000000000','0.463000000000000','0.711908500000000','0.718112495642702','1.5509989106753814','1.550998910675381','test'),('2019-05-07 03:59:59','2019-05-11 11:59:59','XZCBNB','4h','0.304000000000000','0.321000000000000','0.711908500000000','0.751719172697369','2.3418042763157896','2.341804276315790','test'),('2019-05-14 19:59:59','2019-05-14 23:59:59','XZCBNB','4h','0.319000000000000','0.308000000000000','0.711908500000000','0.687359931034483','2.2316880877742946','2.231688087774295','test'),('2019-05-16 19:59:59','2019-05-17 03:59:59','XZCBNB','4h','0.313000000000000','0.300000000000000','0.711908500000000','0.682340415335463','2.274468051118211','2.274468051118211','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','XZCBNB','4h','0.238000000000000','0.230000000000000','0.711908500000000','0.687978802521009','2.99121218487395','2.991212184873950','test'),('2019-06-07 07:59:59','2019-06-21 07:59:59','XZCBNB','4h','0.233000000000000','0.342000000000000','0.711908500000000','1.044947240343348','3.0554012875536483','3.055401287553648','test'),('2019-06-22 23:59:59','2019-06-23 07:59:59','XZCBNB','4h','0.349000000000000','0.358000000000000','0.737713442632447','0.756737571525547','2.1137920992333714','2.113792099233371','test'),('2019-06-24 23:59:59','2019-06-25 03:59:59','XZCBNB','4h','0.344000000000000','0.343000000000000','0.742469474855722','0.740311133359049','2.1583414966736094','2.158341496673609','test'),('2019-06-27 11:59:59','2019-06-27 15:59:59','XZCBNB','4h','0.349000000000000','0.319000000000000','0.742469474855722','0.678646883893912','2.1274196987269973','2.127419698726997','test'),('2019-06-29 07:59:59','2019-07-01 15:59:59','XZCBNB','4h','0.362000000000000','0.351000000000000','0.742469474855722','0.719908247719222','2.0510206487727127','2.051020648772713','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','XZCBNB','4h','0.350000000000000','0.338000000000000','0.742469474855722','0.717013378574955','2.1213413567306345','2.121341356730635','test'),('2019-07-03 11:59:59','2019-07-04 11:59:59','XZCBNB','4h','0.345000000000000','0.336000000000000','0.742469474855722','0.723100705946442','2.1520854343644116','2.152085434364412','test'),('2019-07-06 03:59:59','2019-07-06 07:59:59','XZCBNB','4h','0.348000000000000','0.345000000000000','0.742469474855722','0.736068875934552','2.133532973723339','2.133532973723339','test'),('2019-07-11 15:59:59','2019-07-11 23:59:59','XZCBNB','4h','0.361000000000000','0.354800000000000','0.742469474855722','0.729717921547951','2.0567021464147426','2.056702146414743','test'),('2019-07-24 07:59:59','2019-07-24 19:59:59','XZCBNB','4h','0.338900000000000','0.328800000000000','0.742469474855722','0.720342175664094','2.1908217021414047','2.190821702141405','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','XZCBNB','4h','0.327900000000000','0.324100000000000','0.742469474855722','0.733865071060505','2.2643167882150714','2.264316788215071','test'),('2019-07-25 19:59:59','2019-07-27 07:59:59','XZCBNB','4h','0.326000000000000','0.330900000000000','0.742469474855722','0.753629292115823','2.2775137265512946','2.277513726551295','test'),('2019-07-28 03:59:59','2019-07-28 11:59:59','XZCBNB','4h','0.329700000000000','0.327100000000000','0.742469474855722','0.736614392554767','2.2519547311365544','2.251954731136554','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','XZCBNB','4h','0.329000000000000','0.330000000000000','0.742469474855722','0.744726220979904','2.2567461241815256','2.256746124181526','test'),('2019-08-04 15:59:59','2019-08-04 19:59:59','XZCBNB','4h','0.322300000000000','0.317500000000000','0.742469474855722','0.731411908987564','2.303659555866342','2.303659555866342','test'),('2019-08-22 19:59:59','2019-08-23 07:59:59','XZCBNB','4h','0.252300000000000','0.249100000000000','0.742469474855722','0.733052501730322','2.942804101687364','2.942804101687364','test'),('2019-08-23 11:59:59','2019-08-26 03:59:59','XZCBNB','4h','0.255700000000000','0.261100000000000','0.742469474855722','0.758149315153809','2.903674129275409','2.903674129275409','test'),('2019-08-26 19:59:59','2019-08-27 19:59:59','XZCBNB','4h','0.258600000000000','0.260800000000000','0.742469474855722','0.748785920504147','2.871111658374795','2.871111658374795','test'),('2019-08-28 23:59:59','2019-08-30 11:59:59','XZCBNB','4h','0.257500000000000','0.260800000000000','0.742469474855722','0.751984617640281','2.883376601381445','2.883376601381445','test'),('2019-09-09 19:59:59','2019-09-16 15:59:59','XZCBNB','4h','0.257100000000000','0.251900000000000','0.742469474855722','0.727452589327718','2.8878626015391755','2.887862601539176','test'),('2019-09-17 03:59:59','2019-09-17 07:59:59','XZCBNB','4h','0.259700000000000','0.251800000000000','0.742469474855722','0.719883764992957','2.8589506155399387','2.858950615539939','test'),('2019-09-17 23:59:59','2019-09-18 03:59:59','XZCBNB','4h','0.256600000000000','0.248900000000000','0.742469474855722','0.720189603630511','2.8934897695078803','2.893489769507880','test'),('2019-09-19 07:59:59','2019-09-19 11:59:59','XZCBNB','4h','0.257000000000000','0.251000000000000','0.742469474855722','0.725135557154810','2.8889862834852997','2.888986283485300','test'),('2019-09-19 19:59:59','2019-09-19 23:59:59','XZCBNB','4h','0.254200000000000','0.247800000000000','0.742469474855722','0.723776301609945','2.9208083196527226','2.920808319652723','test'),('2019-09-20 07:59:59','2019-09-20 11:59:59','XZCBNB','4h','0.258000000000000','0.249400000000000','0.742469474855722','0.717720492360531','2.8777886622314806','2.877788662231481','test'),('2019-09-20 19:59:59','2019-09-20 23:59:59','XZCBNB','4h','0.256700000000000','0.254700000000000','0.742469474855722','0.736684749691283','2.892362582219408','2.892362582219408','test'),('2019-10-11 11:59:59','2019-10-11 15:59:59','XZCBNB','4h','0.335300000000000','0.331700000000000','0.742469474855722','0.734497837189511','2.2143437961697643','2.214343796169764','test'),('2019-10-11 19:59:59','2019-10-12 07:59:59','XZCBNB','4h','0.334200000000000','0.325600000000000','0.742469474855722','0.723363438100009','2.2216321808968345','2.221632180896834','test'),('2019-11-09 19:59:59','2019-11-09 23:59:59','XZCBNB','4h','0.249000000000000','0.248000000000000','0.742469474855722','0.739487669735819','2.981805119902498','2.981805119902498','test'),('2019-11-18 15:59:59','2019-11-18 19:59:59','XZCBNB','4h','0.232700000000000','0.229700000000000','0.742469474855722','0.732897457560633','3.19067243169627','3.190672431696270','test'),('2019-11-19 07:59:59','2019-11-19 11:59:59','XZCBNB','4h','0.233300000000000','0.232600000000000','0.742469474855722','0.740241748184488','3.182466673192122','3.182466673192122','test'),('2019-11-24 15:59:59','2019-11-24 19:59:59','XZCBNB','4h','0.238300000000000','0.232500000000000','0.742469474855722','0.724398459521424','3.1156922990168776','3.115692299016878','test'),('2019-11-25 03:59:59','2019-11-25 07:59:59','XZCBNB','4h','0.236000000000000','0.242200000000000','0.742469474855722','0.761975028856169','3.1460570968462798','3.146057096846280','test'),('2019-11-27 03:59:59','2019-11-27 07:59:59','XZCBNB','4h','0.237100000000000','0.239900000000000','0.742469474855722','0.751237566503111','3.131461302639064','3.131461302639064','test'),('2019-11-28 19:59:59','2019-11-28 23:59:59','XZCBNB','4h','0.237500000000000','0.237400000000000','0.742469474855722','0.742156856129467','3.126187262550409','3.126187262550409','test'),('2019-11-30 15:59:59','2019-11-30 19:59:59','XZCBNB','4h','0.237500000000000','0.240900000000000','0.742469474855722','0.753098511548393','3.126187262550409','3.126187262550409','test'),('2019-12-08 23:59:59','2019-12-09 03:59:59','XZCBNB','4h','0.231900000000000','0.225200000000000','0.742469474855722','0.721018222240227','3.2016794948500302','3.201679494850030','test'),('2019-12-15 03:59:59','2019-12-15 07:59:59','XZCBNB','4h','0.227200000000000','0.224800000000000','0.742469474855722','0.734626487445274','3.267911421019903','3.267911421019903','test'),('2019-12-15 15:59:59','2019-12-16 15:59:59','XZCBNB','4h','0.230200000000000','0.224800000000000','0.742469474855722','0.725052727834780','3.2253235223967076','3.225323522396708','test'),('2019-12-16 19:59:59','2019-12-18 11:59:59','XZCBNB','4h','0.232400000000000','0.228600000000000','0.742469474855722','0.730329268296119','3.194791199895534','3.194791199895534','test'),('2019-12-18 19:59:59','2019-12-19 03:59:59','XZCBNB','4h','0.228800000000000','0.229400000000000','0.742469474855722','0.744416510191882','3.2450588936001834','3.245058893600183','test'),('2019-12-20 15:59:59','2019-12-22 03:59:59','XZCBNB','4h','0.232100000000000','0.228800000000000','0.742469474855722','0.731913036824598','3.198920615492124','3.198920615492124','test'),('2019-12-22 23:59:59','2019-12-23 03:59:59','XZCBNB','4h','0.230000000000000','0.229900000000000','0.742469474855722','0.742146662040567','3.2281281515466174','3.228128151546617','test'),('2019-12-23 23:59:59','2019-12-24 03:59:59','XZCBNB','4h','0.231300000000000','0.230000000000000','0.742469474855722','0.738296494668465','3.2099847594281106','3.209984759428111','test'),('2020-01-01 03:59:59','2020-01-01 07:59:59','XZCBNB','4h','0.219400000000000','0.220900000000000','0.742469474855722','0.747545610736686','3.3840905873095806','3.384090587309581','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:49:27
