-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 23:59:59','2019-01-08 19:59:59','LRCETH','4h','0.000313490000000','0.000296850000000','0.072144500000000','0.068315081262560','230.1333375865259','230.133337586525897','test'),('2019-01-09 11:59:59','2019-01-09 19:59:59','LRCETH','4h','0.000300580000000','0.000296680000000','0.072144500000000','0.071208431232950','240.01763257701776','240.017632577017764','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','LRCETH','4h','0.000298000000000','0.000300710000000','0.072144500000000','0.072800579177852','242.09563758389262','242.095637583892625','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','LRCETH','4h','0.000604180000000','0.000544900000000','0.072144500000000','0.065065937386209','119.40895097487505','119.408950974875054','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','LRCETH','4h','0.000594190000000','0.000571000000000','0.072144500000000','0.069328850199431','121.4165502617008','121.416550261700806','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','LRCETH','4h','0.000491070000000','0.000491990000000','0.072144500000000','0.072279659834647','146.9128637465127','146.912863746512699','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','LRCETH','4h','0.000406440000000','0.000400700000000','0.072144500000000','0.071125630228324','177.50344454285997','177.503444542859967','test'),('2019-03-07 23:59:59','2019-03-08 07:59:59','LRCETH','4h','0.000418790000000','0.000420380000000','0.072144500000000','0.072418407578978','172.26891759593113','172.268917595931129','test'),('2019-03-17 03:59:59','2019-03-17 07:59:59','LRCETH','4h','0.000459360000000','0.000457600000000','0.072144500000000','0.071868084291188','157.0543800069662','157.054380006966198','test'),('2019-03-17 15:59:59','2019-03-17 19:59:59','LRCETH','4h','0.000459390000000','0.000457680000000','0.072144500000000','0.071875954548423','157.0441237292932','157.044123729293204','test'),('2019-03-19 19:59:59','2019-03-20 03:59:59','LRCETH','4h','0.000460470000000','0.000457620000000','0.072144500000000','0.071697974004821','156.6757877820488','156.675787782048786','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','LRCETH','4h','0.000461680000000','0.000441950000000','0.072144500000000','0.069061388353405','156.26516201698146','156.265162016981463','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','LRCETH','4h','0.000457770000000','0.000447590000000','0.072144500000000','0.070540133156389','157.599886405837','157.599886405836997','test'),('2019-03-27 07:59:59','2019-03-27 15:59:59','LRCETH','4h','0.000458410000000','0.000461090000000','0.072144500000000','0.072566278015314','157.3798564603739','157.379856460373901','test'),('2019-03-28 03:59:59','2019-03-28 07:59:59','LRCETH','4h','0.000452470000000','0.000453600000000','0.072144500000000','0.072324673901032','159.44593011691381','159.445930116913814','test'),('2019-03-30 07:59:59','2019-04-02 07:59:59','LRCETH','4h','0.000469430000000','0.000479580000000','0.072144500000000','0.073704406003025','153.68532049506848','153.685320495068481','test'),('2019-04-03 07:59:59','2019-04-08 11:59:59','LRCETH','4h','0.000487890000000','0.000512050000000','0.072144500000000','0.075717049386132','147.8704216114288','147.870421611428810','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','LRCETH','4h','0.000275350000000','0.000263150000000','0.072144500000000','0.068947975939713','262.01016887597603','262.010168875976035','test'),('2019-05-23 15:59:59','2019-05-24 19:59:59','LRCETH','4h','0.000287200000000','0.000278380000000','0.072144500000000','0.069928920299443','251.19951253481895','251.199512534818950','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','LRCETH','4h','0.000277430000000','0.000260890000000','0.072144500000000','0.067843342843240','260.04577731319614','260.045777313196140','test'),('2019-05-27 03:59:59','2019-05-27 07:59:59','LRCETH','4h','0.000277680000000','0.000262670000000','0.072144500000000','0.068244727077931','259.8116537021032','259.811653702103172','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','LRCETH','4h','0.000277160000000','0.000271380000000','0.072144500000000','0.070639971171886','260.29910520998703','260.299105209987033','test'),('2019-06-07 19:59:59','2019-06-08 03:59:59','LRCETH','4h','0.000257480000000','0.000260620000000','0.072144500000000','0.073024310975610','280.19457821966756','280.194578219667562','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','LRCETH','4h','0.000271620000000','0.000262390000000','0.072144500000000','0.069692936289669','265.6082026360357','265.608202636035685','test'),('2019-06-17 03:59:59','2019-06-17 07:59:59','LRCETH','4h','0.000259990000000','0.000253790000000','0.072144500000000','0.070424064983269','277.48951882764726','277.489518827647260','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','LRCETH','4h','0.000193550000000','0.000193130000000','0.072144500000000','0.071987947739602','372.74347713769055','372.743477137690547','test'),('2019-07-07 03:59:59','2019-07-07 11:59:59','LRCETH','4h','0.000195020000000','0.000188320000000','0.072144500000000','0.069665943185314','369.93385293816016','369.933852938160157','test'),('2019-07-18 15:59:59','2019-07-18 19:59:59','LRCETH','4h','0.000176030000000','0.000177050000000','0.072144500000000','0.072562538913822','409.8420723740271','409.842072374027111','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','LRCETH','4h','0.000176090000000','0.000178380000000','0.072144500000000','0.073082718553013','409.7024248963598','409.702424896359787','test'),('2019-07-20 23:59:59','2019-07-21 11:59:59','LRCETH','4h','0.000182750000000','0.000177250000000','0.072144500000000','0.069973256497948','394.77154582763336','394.771545827633361','test'),('2019-07-21 19:59:59','2019-07-21 23:59:59','LRCETH','4h','0.000176100000000','0.000175690000000','0.072144500000000','0.071976531544577','409.67915956842705','409.679159568427053','test'),('2019-07-22 03:59:59','2019-07-22 11:59:59','LRCETH','4h','0.000177020000000','0.000174090000000','0.072144500000000','0.070950378516552','407.54999435092077','407.549994350920770','test'),('2019-07-22 15:59:59','2019-07-23 07:59:59','LRCETH','4h','0.000176660000000','0.000175030000000','0.072144500000000','0.071478839776973','408.3805049247141','408.380504924714103','test'),('2019-07-25 07:59:59','2019-07-31 19:59:59','LRCETH','4h','0.000179660000000','0.000196520000000','0.072144500000000','0.078914823221641','401.5612824223533','401.561282422353315','test'),('2019-08-01 03:59:59','2019-08-02 03:59:59','LRCETH','4h','0.000203260000000','0.000201420000000','0.072144500000000','0.071491415871298','354.9370264685624','354.937026468562408','test'),('2019-08-04 07:59:59','2019-08-04 19:59:59','LRCETH','4h','0.000203040000000','0.000201240000000','0.072144500000000','0.071504921099291','355.3216115051221','355.321611505122121','test'),('2019-08-12 07:59:59','2019-08-18 15:59:59','LRCETH','4h','0.000203900000000','0.000187300000000','0.072144500000000','0.066271038989701','353.82295242766065','353.822952427660653','test'),('2019-08-21 15:59:59','2019-08-21 19:59:59','LRCETH','4h','0.000188420000000','0.000196900000000','0.072144500000000','0.075391423681138','382.8919435304108','382.891943530410799','test'),('2019-08-30 15:59:59','2019-08-30 19:59:59','LRCETH','4h','0.000194660000000','0.000194670000000','0.072144500000000','0.072148206180006','370.6180006164594','370.618000616459426','test'),('2019-08-31 07:59:59','2019-09-01 03:59:59','LRCETH','4h','0.000195050000000','0.000193880000000','0.072144500000000','0.071711743963086','369.87695462701873','369.876954627018733','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','LRCETH','4h','0.000197500000000','0.000188540000000','0.072144500000000','0.068871514075949','365.2886075949367','365.288607594936707','test'),('2019-09-04 07:59:59','2019-09-05 11:59:59','LRCETH','4h','0.000194900000000','0.000192850000000','0.072144500000000','0.071385668676244','370.1616213442791','370.161621344279126','test'),('2019-09-07 03:59:59','2019-09-07 07:59:59','LRCETH','4h','0.000195640000000','0.000194160000000','0.072144500000000','0.071598732978941','368.7615007156001','368.761500715600107','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','LRCETH','4h','0.000197040000000','0.000193880000000','0.072144500000000','0.070987493199350','366.14139261063747','366.141392610637467','test'),('2019-09-11 11:59:59','2019-09-11 15:59:59','LRCETH','4h','0.000198120000000','0.000193030000000','0.072144500000000','0.070290999570967','364.1454673934989','364.145467393498905','test'),('2019-09-24 03:59:59','2019-09-29 19:59:59','LRCETH','4h','0.000185220000000','0.000195330000000','0.072144500000000','0.076082416504697','389.507072670338','389.507072670338005','test'),('2019-10-04 03:59:59','2019-10-04 07:59:59','LRCETH','4h','0.000191520000000','0.000187110000000','0.072144500000000','0.070483277960526','376.6943400167084','376.694340016708395','test'),('2019-10-04 23:59:59','2019-10-05 03:59:59','LRCETH','4h','0.000190050000000','0.000187850000000','0.072144500000000','0.071309362404630','379.6079978952907','379.607997895290680','test'),('2019-10-05 11:59:59','2019-10-05 15:59:59','LRCETH','4h','0.000191200000000','0.000185970000000','0.072144500000000','0.070171091344142','377.32479079497904','377.324790794979037','test'),('2019-10-05 19:59:59','2019-10-06 07:59:59','LRCETH','4h','0.000193240000000','0.000189320000000','0.072144500000000','0.070681001552474','373.34144069550814','373.341440695508140','test'),('2019-10-07 11:59:59','2019-10-07 15:59:59','LRCETH','4h','0.000190550000000','0.000190250000000','0.072144500000000','0.072030916426135','378.61191288375755','378.611912883757554','test'),('2019-10-15 15:59:59','2019-10-15 23:59:59','LRCETH','4h','0.000184100000000','0.000177090000000','0.072144500000000','0.069397444350896','391.87669744703965','391.876697447039646','test'),('2019-10-20 19:59:59','2019-10-21 03:59:59','LRCETH','4h','0.000178570000000','0.000173660000000','0.072144500000000','0.070160798958392','404.0124320994568','404.012432099456817','test'),('2019-10-21 07:59:59','2019-10-21 11:59:59','LRCETH','4h','0.000177530000000','0.000178180000000','0.072144500000000','0.072408646482285','406.3792035148989','406.379203514898904','test'),('2019-10-22 03:59:59','2019-10-22 07:59:59','LRCETH','4h','0.000176900000000','0.000173450000000','0.072144500000000','0.070737498728095','407.8264556246467','407.826455624646712','test'),('2019-10-27 15:59:59','2019-10-30 11:59:59','LRCETH','4h','0.000178230000000','0.000175890000000','0.072144500000000','0.071197307439825','404.783145373955','404.783145373954994','test'),('2019-11-15 15:59:59','2019-11-15 19:59:59','LRCETH','4h','0.000173210000000','0.000171710000000','0.072144500000000','0.071519728046880','416.51463541365973','416.514635413659732','test'),('2019-11-22 11:59:59','2019-11-22 15:59:59','LRCETH','4h','0.000166860000000','0.000159420000000','0.072144500000000','0.068927701006832','432.36545607095763','432.365456070957634','test'),('2019-11-29 07:59:59','2019-11-29 11:59:59','LRCETH','4h','0.000160330000000','0.000160280000000','0.072144500000000','0.072122001247427','449.9750514563712','449.975051456371204','test'),('2019-12-07 11:59:59','2019-12-08 03:59:59','LRCETH','4h','0.000166480000000','0.000166860000000','0.072144500000000','0.072309173894762','433.3523546371937','433.352354637193685','test'),('2019-12-09 07:59:59','2019-12-09 11:59:59','LRCETH','4h','0.000165860000000','0.000166860000000','0.072144500000000','0.072579472265766','434.97226576630896','434.972265766308965','test'),('2019-12-11 19:59:59','2019-12-11 23:59:59','LRCETH','4h','0.000165850000000','0.000165440000000','0.072144500000000','0.071966150618028','434.9984926138077','434.998492613807684','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','LRCETH','4h','0.000165910000000','0.000162970000000','0.072144500000000','0.070866066933880','434.8411789524441','434.841178952444125','test'),('2019-12-14 15:59:59','2019-12-14 19:59:59','LRCETH','4h','0.000164070000000','0.000163560000000','0.072144500000000','0.071920243920278','439.71780337660755','439.717803376607549','test'),('2019-12-15 19:59:59','2019-12-15 23:59:59','LRCETH','4h','0.000164300000000','0.000164140000000','0.072144500000000','0.072074243639684','439.1022519780888','439.102251978088816','test'),('2019-12-19 19:59:59','2019-12-21 11:59:59','LRCETH','4h','0.000171220000000','0.000168190000000','0.072144500000000','0.070867792635206','421.3555659385586','421.355565938558584','test'),('2019-12-22 15:59:59','2019-12-22 19:59:59','LRCETH','4h','0.000172070000000','0.000165920000000','0.072144500000000','0.069565964084384','419.2741326204452','419.274132620445187','test'),('2019-12-24 03:59:59','2019-12-24 07:59:59','LRCETH','4h','0.000167130000000','0.000169720000000','0.072144500000000','0.073262517441513','431.6669658349787','431.666965834978726','test'),('2019-12-30 15:59:59','2019-12-30 19:59:59','LRCETH','4h','0.000173790000000','0.000169430000000','0.072144500000000','0.070334556850222','415.1245756372634','415.124575637263376','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 11:39:38
