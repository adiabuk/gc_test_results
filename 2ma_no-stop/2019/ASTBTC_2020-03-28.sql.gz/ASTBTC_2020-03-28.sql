-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 03:59:59','2019-01-04 03:59:59','ASTBTC','4h','0.000007480000000','0.000007410000000','0.001467500000000','0.001453766711230','196.1898395721925','196.189839572192511','test'),('2019-01-06 03:59:59','2019-01-06 15:59:59','ASTBTC','4h','0.000007420000000','0.000007430000000','0.001467500000000','0.001469477762803','197.77628032345015','197.776280323450152','test'),('2019-01-07 11:59:59','2019-01-07 15:59:59','ASTBTC','4h','0.000007430000000','0.000007320000000','0.001467500000000','0.001445773889637','197.5100942126514','197.510094212651410','test'),('2019-01-07 19:59:59','2019-01-08 03:59:59','ASTBTC','4h','0.000007540000000','0.000007350000000','0.001467500000000','0.001430520557029','194.6286472148541','194.628647214854112','test'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ASTBTC','4h','0.000007090000000','0.000006920000000','0.001467500000000','0.001432313117066','206.98166431593796','206.981664315937962','test'),('2019-01-16 07:59:59','2019-01-18 15:59:59','ASTBTC','4h','0.000007160000000','0.000007810000000','0.001467500000000','0.001600722765363','204.95810055865923','204.958100558659225','test'),('2019-02-07 15:59:59','2019-02-08 15:59:59','ASTBTC','4h','0.000008050000000','0.000007510000000','0.001474393700782','0.001375490272407','183.1544969915528','183.154496991552804','test'),('2019-02-09 03:59:59','2019-02-09 11:59:59','ASTBTC','4h','0.000007580000000','0.000007390000000','0.001474393700782','0.001437436602741','194.51104231952505','194.511042319525046','test'),('2019-02-15 15:59:59','2019-02-15 19:59:59','ASTBTC','4h','0.000007340000000','0.000007340000000','0.001474393700782','0.001474393700782','200.87107640081743','200.871076400817429','test'),('2019-02-16 19:59:59','2019-02-18 19:59:59','ASTBTC','4h','0.000007500000000','0.000007420000000','0.001474393700782','0.001458666834640','196.58582677093332','196.585826770933323','test'),('2019-02-19 11:59:59','2019-02-21 11:59:59','ASTBTC','4h','0.000007550000000','0.000007450000000','0.001474393700782','0.001454865307394','195.2839338784106','195.283933878410608','test'),('2019-02-25 03:59:59','2019-02-25 11:59:59','ASTBTC','4h','0.000008040000000','0.000008110000000','0.001474393700782','0.001487230461858','183.38230109228857','183.382301092288571','test'),('2019-03-07 15:59:59','2019-03-11 07:59:59','ASTBTC','4h','0.000009210000000','0.000009390000000','0.001474393700782','0.001503209212849','160.08617815222584','160.086178152225841','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','ASTBTC','4h','0.000009460000000','0.000009390000000','0.001474393700782','0.001463483810818','155.85557090718817','155.855570907188167','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','ASTBTC','4h','0.000010170000000','0.000010150000000','0.001474393700782','0.001471494204812','144.97479850363817','144.974798503638169','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','ASTBTC','4h','0.000009890000000','0.000009890000000','0.001474393700782','0.001474393700782','149.0792417373104','149.079241737310412','test'),('2019-03-23 03:59:59','2019-03-23 15:59:59','ASTBTC','4h','0.000009950000000','0.000010140000000','0.001474393700782','0.001502547952355','148.18027143537688','148.180271435376881','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','ASTBTC','4h','0.000010280000000','0.000010080000000','0.001474393700782','0.001445708998432','143.4235117492218','143.423511749221802','test'),('2019-04-19 11:59:59','2019-04-21 11:59:59','ASTBTC','4h','0.000008770000000','0.000008650000000','0.001474393700782','0.001454219556644','168.1178678200684','168.117867820068398','test'),('2019-05-21 07:59:59','2019-05-26 15:59:59','ASTBTC','4h','0.000005380000000','0.000006500000000','0.001474393700782','0.001781330679383','274.0508737513011','274.050873751301083','test'),('2019-05-28 03:59:59','2019-05-29 07:59:59','ASTBTC','4h','0.000007160000000','0.000006350000000','0.001510133572019','0.001339294438872','210.91251005855446','210.912510058554460','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','ASTBTC','4h','0.000006260000000','0.000005940000000','0.001510133572019','0.001432938245654','241.23539489121404','241.235394891214042','test'),('2019-05-31 23:59:59','2019-06-01 03:59:59','ASTBTC','4h','0.000006200000000','0.000005960000000','0.001510133572019','0.001451676788586','243.56993097080644','243.569930970806439','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','ASTBTC','4h','0.000006120000000','0.000006430000000','0.001510133572019','0.001586627266026','246.75385163709151','246.753851637091515','test'),('2019-06-07 19:59:59','2019-06-09 15:59:59','ASTBTC','4h','0.000005980000000','0.000005980000000','0.001510133572019','0.001510133572019','252.53069766204013','252.530697662040126','test'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ASTBTC','4h','0.000006060000000','0.000005930000000','0.001510133572019','0.001477737967339','249.19695907904293','249.196959079042927','test'),('2019-06-11 11:59:59','2019-06-12 15:59:59','ASTBTC','4h','0.000006080000000','0.000006180000000','0.001510133572019','0.001534971295243','248.3772322399671','248.377232239967100','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','ASTBTC','4h','0.000008290000000','0.000006400000000','0.001510133572019','0.001165844977192','182.16327768624848','182.163277686248477','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','ASTBTC','4h','0.000005330000000','0.000005180000000','0.001510133572019','0.001467634503388','283.3271242061914','283.327124206191399','test'),('2019-07-04 15:59:59','2019-07-04 19:59:59','ASTBTC','4h','0.000005460000000','0.000005520000000','0.001510133572019','0.001526728446437','276.58124029652015','276.581240296520150','test'),('2019-07-05 07:59:59','2019-07-05 11:59:59','ASTBTC','4h','0.000005660000000','0.000005400000000','0.001510133572019','0.001440763478605','266.8080515934629','266.808051593462892','test'),('2019-07-23 11:59:59','2019-07-23 15:59:59','ASTBTC','4h','0.000004300000000','0.000004230000000','0.001510133572019','0.001485550002242','351.1938539579069','351.193853957906924','test'),('2019-07-23 19:59:59','2019-07-24 23:59:59','ASTBTC','4h','0.000004320000000','0.000004490000000','0.001510133572019','0.001569560124622','349.5679564858796','349.567956485879620','test'),('2019-07-25 15:59:59','2019-07-25 23:59:59','ASTBTC','4h','0.000004410000000','0.000004320000000','0.001510133572019','0.001479314519529','342.4339165575964','342.433916557596376','test'),('2019-07-26 11:59:59','2019-07-26 19:59:59','ASTBTC','4h','0.000004380000000','0.000004320000000','0.001510133572019','0.001489446810758','344.7793543422374','344.779354342237411','test'),('2019-07-27 15:59:59','2019-07-28 15:59:59','ASTBTC','4h','0.000004340000000','0.000004350000000','0.001510133572019','0.001513613142461','347.95704424400924','347.957044244009239','test'),('2019-08-21 11:59:59','2019-08-21 15:59:59','ASTBTC','4h','0.000002740000000','0.000002720000000','0.001510133572019','0.001499110699231','551.1436394229927','551.143639422992692','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','ASTBTC','4h','0.000002800000000','0.000002770000000','0.001510133572019','0.001493953569462','539.3334185782143','539.333418578214264','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','ASTBTC','4h','0.000002580000000','0.000002410000000','0.001510133572019','0.001410628646731','585.323089929845','585.323089929844969','test'),('2019-09-15 07:59:59','2019-09-16 11:59:59','ASTBTC','4h','0.000002410000000','0.000002430000000','0.001510133572019','0.001522665800832','626.6114406717843','626.611440671784294','test'),('2019-09-25 23:59:59','2019-09-26 03:59:59','ASTBTC','4h','0.000002800000000','0.000002740000000','0.001510133572019','0.001477773566904','539.3334185782143','539.333418578214264','test'),('2019-09-27 03:59:59','2019-09-27 15:59:59','ASTBTC','4h','0.000002820000000','0.000002790000000','0.001510133572019','0.001494068321253','535.5083588719858','535.508358871985820','test'),('2019-10-10 15:59:59','2019-10-10 23:59:59','ASTBTC','4h','0.000003360000000','0.000003170000000','0.001510133572019','0.001424739114077','449.4445154818452','449.444515481845201','test'),('2019-10-11 19:59:59','2019-10-12 19:59:59','ASTBTC','4h','0.000003310000000','0.000003240000000','0.001510133572019','0.001478197212490','456.23370755861026','456.233707558610263','test'),('2019-10-15 07:59:59','2019-10-16 15:59:59','ASTBTC','4h','0.000003250000000','0.000003160000000','0.001510133572019','0.001468314488486','464.65648369815386','464.656483698153863','test'),('2019-10-17 11:59:59','2019-10-17 15:59:59','ASTBTC','4h','0.000003360000000','0.000003320000000','0.001510133572019','0.001492155791400','449.4445154818452','449.444515481845201','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','ASTBTC','4h','0.000003290000000','0.000003230000000','0.001510133572019','0.001482593142134','459.0071647474164','459.007164747416425','test'),('2019-10-21 19:59:59','2019-10-22 23:59:59','ASTBTC','4h','0.000003300000000','0.000003250000000','0.001510133572019','0.001487252760322','457.61623394515146','457.616233945151464','test'),('2019-10-24 23:59:59','2019-10-25 03:59:59','ASTBTC','4h','0.000003270000000','0.000003250000000','0.001510133572019','0.001500897281059','461.8145480180428','461.814548018042785','test'),('2019-11-10 07:59:59','2019-11-10 11:59:59','ASTBTC','4h','0.000002720000000','0.000002710000000','0.001510133572019','0.001504581610357','555.196166183456','555.196166183455944','test'),('2019-11-11 03:59:59','2019-11-11 07:59:59','ASTBTC','4h','0.000002730000000','0.000002700000000','0.001510133572019','0.001493538697601','553.1624805930403','553.162480593040300','test'),('2019-11-11 19:59:59','2019-11-11 23:59:59','ASTBTC','4h','0.000002730000000','0.000002690000000','0.001510133572019','0.001488007072795','553.1624805930403','553.162480593040300','test'),('2019-11-12 03:59:59','2019-11-12 07:59:59','ASTBTC','4h','0.000002710000000','0.000002710000000','0.001510133572019','0.001510133572019','557.2448605236162','557.244860523616239','test'),('2019-11-12 23:59:59','2019-11-13 01:59:59','ASTBTC','4h','0.000002760000000','0.000002720000000','0.001510133572019','0.001488247578222','547.1498449344203','547.149844934420344','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','ASTBTC','4h','0.000002730000000','0.000002730000000','0.001510133572019','0.001510133572019','553.1624805930403','553.162480593040300','test'),('2019-11-23 23:59:59','2019-11-24 07:59:59','ASTBTC','4h','0.000002820000000','0.000002860000000','0.001510133572019','0.001531553906374','535.5083588719858','535.508358871985820','test'),('2019-11-25 07:59:59','2019-11-27 19:59:59','ASTBTC','4h','0.000002860000000','0.000002990000000','0.001510133572019','0.001578776007111','528.0187314751748','528.018731475174832','test'),('2019-12-04 11:59:59','2019-12-05 15:59:59','ASTBTC','4h','0.000003110000000','0.000003050000000','0.001510133572019','0.001480999162269','485.573495826045','485.573495826045018','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:06:53
