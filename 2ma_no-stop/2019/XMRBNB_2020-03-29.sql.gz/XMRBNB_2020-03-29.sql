-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-08-31 15:59:59','2019-09-05 19:59:59','XMRBNB','4h','3.080000000000000','3.299000000000000','0.711908500000000','0.762527968019481','0.2311391233766234','0.231139123376623','test'),('2019-09-10 19:59:59','2019-09-10 23:59:59','XMRBNB','4h','3.331000000000000','3.307000000000000','0.724563367004870','0.719342856405015','0.21752127499395688','0.217521274993957','test'),('2019-09-11 03:59:59','2019-09-11 07:59:59','XMRBNB','4h','3.372000000000000','3.290000000000000','0.724563367004870','0.706943498649473','0.2148764433585024','0.214876443358502','test'),('2019-09-11 11:59:59','2019-09-17 15:59:59','XMRBNB','4h','3.397000000000000','3.521000000000000','0.724563367004870','0.751011956203752','0.21329507418453636','0.213295074184536','test'),('2019-09-18 19:59:59','2019-09-19 03:59:59','XMRBNB','4h','3.554000000000000','3.580000000000000','0.725465419565778','0.730772707384774','0.20412645457675235','0.204126454576752','test'),('2019-09-22 07:59:59','2019-09-23 07:59:59','XMRBNB','4h','3.543000000000000','3.585000000000000','0.726792241520527','0.735407898913658','0.2051346998364456','0.205134699836446','test'),('2019-10-04 15:59:59','2019-10-05 03:59:59','XMRBNB','4h','3.685000000000000','3.594000000000000','0.728946155868810','0.710945043200136','0.1978144249304775','0.197814424930477','test'),('2019-10-05 15:59:59','2019-10-05 19:59:59','XMRBNB','4h','3.649000000000000','3.601000000000000','0.728946155868810','0.719357387581141','0.1997660059930967','0.199766005993097','test'),('2019-10-17 11:59:59','2019-10-17 15:59:59','XMRBNB','4h','3.236000000000000','3.162000000000000','0.728946155868810','0.712276806198139','0.225261482036097','0.225261482036097','test'),('2019-10-18 07:59:59','2019-10-18 11:59:59','XMRBNB','4h','3.236000000000000','3.169000000000000','0.728946155868810','0.713853636572391','0.225261482036097','0.225261482036097','test'),('2019-10-21 11:59:59','2019-10-22 03:59:59','XMRBNB','4h','3.162000000000000','3.095000000000000','0.728946155868810','0.713500427708402','0.23053325612549336','0.230533256125493','test'),('2019-10-22 15:59:59','2019-10-22 19:59:59','XMRBNB','4h','3.135000000000000','3.160000000000000','0.728946155868810','0.734759123618960','0.232518710006','0.232518710006000','test'),('2019-10-23 03:59:59','2019-10-23 11:59:59','XMRBNB','4h','3.171000000000000','3.133000000000000','0.728946155868810','0.720210755703873','0.22987895170886471','0.229878951708865','test'),('2019-10-25 19:59:59','2019-10-26 07:59:59','XMRBNB','4h','3.168000000000000','3.143000000000000','0.728946155868810','0.723193739866057','0.23009664011010414','0.230096640110104','test'),('2019-11-01 19:59:59','2019-11-02 03:59:59','XMRBNB','4h','3.049000000000000','3.029000000000000','0.728946155868810','0.724164613357371','0.23907712557192848','0.239077125571928','test'),('2019-11-05 15:59:59','2019-11-05 19:59:59','XMRBNB','4h','3.057000000000000','3.025000000000000','0.728946155868810','0.721315708702372','0.23845147395119723','0.238451473951197','test'),('2019-11-06 07:59:59','2019-11-06 11:59:59','XMRBNB','4h','3.074000000000000','3.057000000000000','0.728946155868810','0.724914898663290','0.2371327767953188','0.237132776795319','test'),('2019-11-12 11:59:59','2019-11-12 19:59:59','XMRBNB','4h','3.123000000000000','3.066000000000000','0.728946155868810','0.715641663110397','0.23341215365635923','0.233412153656359','test'),('2019-11-14 19:59:59','2019-11-14 23:59:59','XMRBNB','4h','3.100000000000000','3.051000000000000','0.728946155868810','0.717424103727658','0.2351439212480032','0.235143921248003','test'),('2019-11-15 03:59:59','2019-11-15 11:59:59','XMRBNB','4h','3.118000000000000','3.052000000000000','0.728946155868810','0.713516250067867','0.23378645152944516','0.233786451529445','test'),('2019-11-15 15:59:59','2019-11-15 23:59:59','XMRBNB','4h','3.125000000000000','3.051000000000000','0.728946155868810','0.711684710897837','0.2332627698780192','0.233262769878019','test'),('2019-11-16 11:59:59','2019-11-16 15:59:59','XMRBNB','4h','3.085000000000000','3.064000000000000','0.728946155868810','0.723984123689476','0.2362872466349465','0.236287246634946','test'),('2019-11-16 19:59:59','2019-11-16 23:59:59','XMRBNB','4h','3.085000000000000','3.046000000000000','0.728946155868810','0.719730953250047','0.2362872466349465','0.236287246634946','test'),('2019-11-17 03:59:59','2019-11-17 11:59:59','XMRBNB','4h','3.090000000000000','3.107000000000000','0.728946155868810','0.732956539250613','0.23590490481191262','0.235904904811913','test'),('2019-11-18 03:59:59','2019-11-18 19:59:59','XMRBNB','4h','3.081000000000000','3.078000000000000','0.728946155868810','0.728236373828042','0.23659401358935733','0.236594013589357','test'),('2019-11-19 07:59:59','2019-11-24 03:59:59','XMRBNB','4h','3.114000000000000','3.181000000000000','0.728946155868810','0.744629968470997','0.23408675525652214','0.234086755256522','test'),('2019-11-25 03:59:59','2019-12-05 03:59:59','XMRBNB','4h','3.188000000000000','3.424000000000000','0.728946155868810','0.782908292877919','0.22865312291995293','0.228653122919953','test'),('2019-12-05 19:59:59','2019-12-05 23:59:59','XMRBNB','4h','3.446000000000000','3.440000000000000','0.728946155868810','0.727676951882968','0.21153399764039754','0.211533997640398','test'),('2019-12-09 11:59:59','2019-12-09 15:59:59','XMRBNB','4h','3.452000000000000','3.471000000000000','0.728946155868810','0.732958316054646','0.21116632557033893','0.211166325570339','test'),('2019-12-16 07:59:59','2019-12-18 11:59:59','XMRBNB','4h','3.560000000000000','3.616000000000000','0.728946155868810','0.740412724612814','0.20476015614292414','0.204760156142924','test'),('2019-12-19 11:59:59','2019-12-19 15:59:59','XMRBNB','4h','3.584000000000000','3.594000000000000','0.728946155868810','0.730980045812640','0.20338899438303848','0.203388994383038','test'),('2019-12-23 19:59:59','2019-12-24 03:59:59','XMRBNB','4h','3.570000000000000','3.551000000000000','0.728946155868810','0.725066610501441','0.20418659828257982','0.204186598282580','test'),('2019-12-24 11:59:59','2019-12-24 15:59:59','XMRBNB','4h','3.528000000000000','3.467000000000000','0.728946155868810','0.716342495010534','0.20661739111927718','0.206617391119277','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','XMRBNB','4h','3.520000000000000','3.490000000000000','0.728946155868810','0.722733546585837','0.20708697609909374','0.207086976099094','test'),('2020-01-02 11:59:59','2020-01-13 15:59:59','XMRBNB','4h','3.408000000000000','3.786000000000000','0.728946155868810','0.809797578086653','0.21389265136995597','0.213892651369956','test'),('2020-01-13 19:59:59','2020-01-13 23:59:59','XMRBNB','4h','3.823000000000000','3.819000000000000','0.728946155868810','0.728183460440226','0.19067385714590895','0.190673857145909','test'),('2020-01-15 07:59:59','2020-01-15 11:59:59','XMRBNB','4h','3.840000000000000','3.717000000000000','0.728946155868810','0.705597099313637','0.18982972809083593','0.189829728090836','test'),('2020-01-15 23:59:59','2020-01-16 03:59:59','XMRBNB','4h','3.868000000000000','3.795000000000000','0.728946155868810','0.715188899049156','0.18845557287197776','0.188455572871978','test'),('2020-01-16 07:59:59','2020-01-16 15:59:59','XMRBNB','4h','3.833000000000000','3.820000000000000','0.728946155868810','0.726473862619059','0.19017640382697884','0.190176403826979','test'),('2020-01-17 23:59:59','2020-01-18 03:59:59','XMRBNB','4h','3.817000000000000','3.825000000000000','0.728946155868810','0.730473944510924','0.19097358026429392','0.190973580264294','test'),('2020-01-19 15:59:59','2020-01-19 19:59:59','XMRBNB','4h','3.836000000000000','3.738000000000000','0.728946155868810','0.710323443857563','0.19002767358415276','0.190027673584153','test'),('2020-01-27 15:59:59','2020-01-27 19:59:59','XMRBNB','4h','3.723000000000000','3.673000000000000','0.728946155868810','0.719156387458001','0.19579536821617244','0.195795368216172','test'),('2020-01-27 23:59:59','2020-01-28 03:59:59','XMRBNB','4h','3.715000000000000','3.716000000000000','0.728946155868810','0.729142372869044','0.1962170002338654','0.196217000233865','test'),('2020-02-15 11:59:59','2020-02-15 15:59:59','XMRBNB','4h','3.683000000000000','3.693000000000000','0.728946155868810','0.730925374320802','0.19792184519924247','0.197921845199242','test'),('2020-02-16 07:59:59','2020-02-16 11:59:59','XMRBNB','4h','3.680000000000000','3.683000000000000','0.728946155868810','0.729540405452399','0.1980831945295679','0.198083194529568','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 15:48:00
