-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-10 15:59:59','ZECETH','4h','0.418200000000000','0.410500000000000','0.072144500000000','0.070816157938785','0.17251195600191296','0.172511956001913','test'),('2019-01-10 19:59:59','2019-01-13 19:59:59','ZECETH','4h','0.425010000000000','0.457000000000000','0.072144500000000','0.077574731182796','0.1697477706406908','0.169747770640691','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','ZECETH','4h','0.431600000000000','0.425750000000000','0.073169972280395','0.072178210607920','0.1695319098248268','0.169531909824827','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','ZECETH','4h','0.441540000000000','0.441160000000000','0.073169972280395','0.073107000433073','0.16571538768943925','0.165715387689439','test'),('2019-02-02 15:59:59','2019-02-02 19:59:59','ZECETH','4h','0.454610000000000','0.453240000000000','0.073169972280395','0.072949469295366','0.16095108396294625','0.160951083962946','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','ZECETH','4h','0.444500000000000','0.434910000000000','0.073169972280395','0.071591344531983','0.16461186114824522','0.164611861148245','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ZECETH','4h','0.384990000000000','0.381550000000000','0.073169972280395','0.072516176845073','0.19005681259356086','0.190056812593561','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','ZECETH','4h','0.384980000000000','0.374510000000000','0.073169972280395','0.071180025764275','0.19006174939060472','0.190061749390605','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','ZECETH','4h','0.382100000000000','0.384620000000000','0.073169972280395','0.073652537918046','0.19149430065531275','0.191494300655313','test'),('2019-03-02 15:59:59','2019-03-03 03:59:59','ZECETH','4h','0.386190000000000','0.382240000000000','0.073169972280395','0.072421580580694','0.18946625308888113','0.189466253088881','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','ZECETH','4h','0.374370000000000','0.374500000000000','0.073169972280395','0.073195380556690','0.1954482791900927','0.195448279190093','test'),('2019-03-12 11:59:59','2019-03-12 15:59:59','ZECETH','4h','0.373820000000000','0.383790000000000','0.073169972280395','0.075121458620440','0.19573584152906479','0.195735841529065','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','ZECETH','4h','0.405840000000000','0.402530000000000','0.073169972280395','0.072573203582760','0.18029265789571014','0.180292657895710','test'),('2019-03-27 15:59:59','2019-03-28 07:59:59','ZECETH','4h','0.404390000000000','0.402360000000000','0.073169972280395','0.072802665859046','0.18093912381709487','0.180939123817095','test'),('2019-03-28 19:59:59','2019-03-29 03:59:59','ZECETH','4h','0.408040000000000','0.403070000000000','0.073169972280395','0.072278748963481','0.17932058690421282','0.179320586904213','test'),('2019-03-29 19:59:59','2019-03-29 23:59:59','ZECETH','4h','0.407410000000000','0.398420000000000','0.073169972280395','0.071555387339425','0.1795978799744606','0.179597879974461','test'),('2019-03-31 03:59:59','2019-04-04 11:59:59','ZECETH','4h','0.405430000000000','0.418580000000000','0.073169972280395','0.075543218304338','0.18047498280935056','0.180474982809351','test'),('2019-04-11 19:59:59','2019-04-14 07:59:59','ZECETH','4h','0.423700000000000','0.417070000000000','0.073169972280395','0.072025018501261','0.17269287769741562','0.172692877697416','test'),('2019-04-15 23:59:59','2019-04-16 03:59:59','ZECETH','4h','0.421650000000000','0.417700000000000','0.073169972280395','0.072484518964831','0.17353248495291118','0.173532484952911','test'),('2019-04-17 23:59:59','2019-04-18 03:59:59','ZECETH','4h','0.424490000000000','0.415650000000000','0.073169972280395','0.071646208340235','0.17237148644348513','0.172371486443485','test'),('2019-05-28 07:59:59','2019-05-30 07:59:59','ZECETH','4h','0.315640000000000','0.307560000000000','0.073169972280395','0.071296910006838','0.23181463781648398','0.231814637816484','test'),('2019-06-11 23:59:59','2019-06-12 03:59:59','ZECETH','4h','0.325970000000000','0.325820000000000','0.073169972280395','0.073136302016745','0.2244684243347394','0.224468424334739','test'),('2019-06-22 19:59:59','2019-06-22 23:59:59','ZECETH','4h','0.370400000000000','0.365030000000000','0.073169972280395','0.072109165716827','0.1975431217073299','0.197543121707330','test'),('2019-06-27 23:59:59','2019-06-29 03:59:59','ZECETH','4h','0.358830000000000','0.365000000000000','0.073169972280395','0.074428113263507','0.20391263907810106','0.203912639078101','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','ZECETH','4h','0.362090000000000','0.352190000000000','0.073169972280395','0.071169412404188','0.2020767551724571','0.202076755172457','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','ZECETH','4h','0.356460000000000','0.351750000000000','0.073169972280395','0.072203158137320','0.20526839555741178','0.205268395557412','test'),('2019-07-06 19:59:59','2019-07-07 11:59:59','ZECETH','4h','0.360180000000000','0.350520000000000','0.073169972280395','0.071207559230729','0.20314834882668387','0.203148348826684','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','ZECETH','4h','0.355520000000000','0.343810000000000','0.073169972280395','0.070759923969742','0.20581112815142608','0.205811128151426','test'),('2019-07-14 15:59:59','2019-07-15 15:59:59','ZECETH','4h','0.346910000000000','0.342460000000000','0.073169972280395','0.072231381935211','0.21091917869301835','0.210919178693018','test'),('2019-07-17 07:59:59','2019-07-17 11:59:59','ZECETH','4h','0.347650000000000','0.340430000000000','0.073169972280395','0.071650377285819','0.21047022085544367','0.210470220855444','test'),('2019-07-17 15:59:59','2019-07-17 19:59:59','ZECETH','4h','0.343100000000000','0.354450000000000','0.073169972280395','0.075590488705293','0.21326135902184493','0.213261359021845','test'),('2019-08-25 19:59:59','2019-08-25 23:59:59','ZECETH','4h','0.269730000000000','0.268020000000000','0.073169972280395','0.072706098582254','0.2712711685032996','0.271271168503300','test'),('2019-08-26 03:59:59','2019-08-27 15:59:59','ZECETH','4h','0.270010000000000','0.268730000000000','0.073169972280395','0.072823105258733','0.2709898606732899','0.270989860673290','test'),('2019-08-28 19:59:59','2019-08-28 23:59:59','ZECETH','4h','0.272490000000000','0.269440000000000','0.073169972280395','0.072350975563249','0.2685235138184704','0.268523513818470','test'),('2019-08-29 11:59:59','2019-08-29 15:59:59','ZECETH','4h','0.270800000000000','0.269320000000000','0.073169972280395','0.072770077306337','0.27019930679614107','0.270199306796141','test'),('2019-09-06 19:59:59','2019-09-07 19:59:59','ZECETH','4h','0.264820000000000','0.262420000000000','0.073169972280395','0.072506850410925','0.27630077894568006','0.276300778945680','test'),('2019-09-28 07:59:59','2019-09-28 11:59:59','ZECETH','4h','0.232570000000000','0.224050000000000','0.073169972280395','0.070489453882369','0.3146148354490906','0.314614835449091','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','ZECETH','4h','0.228030000000000','0.232320000000000','0.073169972280395','0.074546541947031','0.3208787101714467','0.320878710171447','test'),('2019-10-16 07:59:59','2019-10-16 11:59:59','ZECETH','4h','0.204650000000000','0.205360000000000','0.073169972280395','0.073423823637928','0.3575371232855851','0.357537123285585','test'),('2019-10-18 03:59:59','2019-10-21 11:59:59','ZECETH','4h','0.207180000000000','0.205960000000000','0.073169972280395','0.072739103633894','0.3531710217221498','0.353171021722150','test'),('2019-10-25 03:59:59','2019-10-25 07:59:59','ZECETH','4h','0.207170000000000','0.205410000000000','0.073169972280395','0.072548361278737','0.3531880691238838','0.353188069123884','test'),('2019-10-25 15:59:59','2019-10-25 19:59:59','ZECETH','4h','0.207880000000000','0.201700000000000','0.073169972280395','0.070994724884336','0.3519817792976477','0.351981779297648','test'),('2019-10-28 03:59:59','2019-10-29 19:59:59','ZECETH','4h','0.218800000000000','0.203870000000000','0.073169972280395','0.068177158358337','0.33441486416999544','0.334414864169995','test'),('2019-10-30 03:59:59','2019-10-30 07:59:59','ZECETH','4h','0.208000000000000','0.207080000000000','0.073169972280395','0.072846335864539','0.3517787128865144','0.351778712886514','test'),('2019-10-30 15:59:59','2019-10-31 15:59:59','ZECETH','4h','0.207750000000000','0.207110000000000','0.073169972280395','0.072944562979507','0.3522020326372804','0.352202032637280','test'),('2019-11-07 11:59:59','2019-11-08 07:59:59','ZECETH','4h','0.206840000000000','0.203130000000000','0.073169972280395','0.071857553999790','0.35375155811446046','0.353751558114460','test'),('2019-11-15 19:59:59','2019-11-16 03:59:59','ZECETH','4h','0.201310000000000','0.200180000000000','0.073169972280395','0.072759252153840','0.36346913854450846','0.363469138544508','test'),('2019-11-22 11:59:59','2019-11-22 15:59:59','ZECETH','4h','0.196630000000000','0.196780000000000','0.073169972280395','0.073225790293120','0.3721200848313838','0.372120084831384','test'),('2019-12-05 11:59:59','2019-12-09 03:59:59','ZECETH','4h','0.191400000000000','0.193610000000000','0.073169972280395','0.074014829327102','0.38228825642839603','0.382288256428396','test'),('2019-12-22 23:59:59','2019-12-23 03:59:59','ZECETH','4h','0.220530000000000','0.219710000000000','0.073169972280395','0.072897903277221','0.33179146728515396','0.331791467285154','test'),('2019-12-25 03:59:59','2019-12-25 15:59:59','ZECETH','4h','0.220920000000000','0.219590000000000','0.073169972280395','0.072729468644993','0.3312057409034718','0.331205740903472','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','ZECETH','4h','0.221280000000000','0.217680000000000','0.073169972280395','0.071979571429846','0.33066690293020157','0.330666902930202','test'),('2019-12-27 11:59:59','2019-12-27 15:59:59','ZECETH','4h','0.221500000000000','0.217420000000000','0.073169972280395','0.071822191301144','0.3303384753065237','0.330338475306524','test'),('2019-12-28 07:59:59','2019-12-28 19:59:59','ZECETH','4h','0.221300000000000','0.220370000000000','0.073169972280395','0.072862479852827','0.3306370188901717','0.330637018890172','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:24:33
