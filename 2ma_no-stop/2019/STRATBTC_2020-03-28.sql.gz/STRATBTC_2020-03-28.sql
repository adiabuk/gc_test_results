-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-15 19:59:59','2019-01-18 11:59:59','STRATBTC','4h','0.000279400000000','0.000274300000000','0.001467500000000','0.001440713135290','5.252326413743736','5.252326413743736','test'),('2019-01-19 11:59:59','2019-01-20 11:59:59','STRATBTC','4h','0.000291400000000','0.000273300000000','0.001467500000000','0.001376347803706','5.0360329444063145','5.036032944406315','test'),('2019-01-22 23:59:59','2019-01-23 23:59:59','STRATBTC','4h','0.000278400000000','0.000281100000000','0.001467500000000','0.001481732219828','5.271192528735632','5.271192528735632','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','STRATBTC','4h','0.000279000000000','0.000277900000000','0.001467500000000','0.001461714157706','5.259856630824373','5.259856630824373','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','STRATBTC','4h','0.000228900000000','0.000230500000000','0.001467500000000','0.001477757754478','6.411096548711227','6.411096548711227','test'),('2019-02-13 15:59:59','2019-02-13 19:59:59','STRATBTC','4h','0.000228000000000','0.000232800000000','0.001467500000000','0.001498394736842','6.43640350877193','6.436403508771930','test'),('2019-02-17 03:59:59','2019-02-17 15:59:59','STRATBTC','4h','0.000236100000000','0.000236800000000','0.001467500000000','0.001471850910631','6.215586615840746','6.215586615840746','test'),('2019-02-19 15:59:59','2019-02-19 23:59:59','STRATBTC','4h','0.000233700000000','0.000231500000000','0.001467500000000','0.001453685280274','6.279418057338469','6.279418057338469','test'),('2019-02-20 23:59:59','2019-02-21 15:59:59','STRATBTC','4h','0.000233800000000','0.000234200000000','0.001467500000000','0.001470010692900','6.276732249786143','6.276732249786143','test'),('2019-02-22 19:59:59','2019-02-23 03:59:59','STRATBTC','4h','0.000236400000000','0.000231800000000','0.001467500000000','0.001438944585448','6.207698815566836','6.207698815566836','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','STRATBTC','4h','0.000234300000000','0.000230900000000','0.001467500000000','0.001446204652155','6.2633376013657704','6.263337601365770','test'),('2019-02-26 19:59:59','2019-02-27 03:59:59','STRATBTC','4h','0.000234600000000','0.000229300000000','0.001467500000000','0.001434346760443','6.255328218243819','6.255328218243819','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','STRATBTC','4h','0.000232800000000','0.000228200000000','0.001467500000000','0.001438503006873','6.303694158075602','6.303694158075602','test'),('2019-03-03 15:59:59','2019-03-03 19:59:59','STRATBTC','4h','0.000230300000000','0.000233700000000','0.001467500000000','0.001489165219279','6.372123317412072','6.372123317412072','test'),('2019-03-10 11:59:59','2019-03-11 07:59:59','STRATBTC','4h','0.000224400000000','0.000225900000000','0.001467500000000','0.001477309491979','6.539661319073084','6.539661319073084','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','STRATBTC','4h','0.000235000000000','0.000231900000000','0.001467500000000','0.001448141489362','6.24468085106383','6.244680851063830','test'),('2019-03-24 11:59:59','2019-03-24 19:59:59','STRATBTC','4h','0.000236600000000','0.000229500000000','0.001467500000000','0.001423462595097','6.202451394759088','6.202451394759088','test'),('2019-03-26 03:59:59','2019-03-26 07:59:59','STRATBTC','4h','0.000231800000000','0.000226600000000','0.001467500000000','0.001434579378775','6.3308886971527185','6.330888697152719','test'),('2019-03-26 19:59:59','2019-03-29 11:59:59','STRATBTC','4h','0.000234100000000','0.000234000000000','0.001467500000000','0.001466873131141','6.268688594617685','6.268688594617685','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','STRATBTC','4h','0.000236800000000','0.000227000000000','0.001467500000000','0.001406767314189','6.197212837837838','6.197212837837838','test'),('2019-04-05 23:59:59','2019-04-06 03:59:59','STRATBTC','4h','0.000234000000000','0.000233700000000','0.001467500000000','0.001465618589744','6.271367521367521','6.271367521367521','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','STRATBTC','4h','0.000236800000000','0.000234500000000','0.001467500000000','0.001453246410473','6.197212837837838','6.197212837837838','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','STRATBTC','4h','0.000237700000000','0.000229700000000','0.001467500000000','0.001418110012621','6.173748422381153','6.173748422381153','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','STRATBTC','4h','0.000233500000000','0.000233900000000','0.001467500000000','0.001470013918630','6.284796573875803','6.284796573875803','test'),('2019-05-17 23:59:59','2019-05-18 03:59:59','STRATBTC','4h','0.000124300000000','0.000121800000000','0.001467500000000','0.001437984714401','11.806114239742557','11.806114239742557','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','STRATBTC','4h','0.000120100000000','0.000118400000000','0.001467500000000','0.001446727726894','12.218984179850125','12.218984179850125','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','STRATBTC','4h','0.000123500000000','0.000117400000000','0.001467500000000','0.001395016194332','11.88259109311741','11.882591093117410','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','STRATBTC','4h','0.000120700000000','0.000124000000000','0.001467500000000','0.001507622203811','12.15824357912179','12.158243579121789','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','STRATBTC','4h','0.000121400000000','0.000119400000000','0.001467500000000','0.001443323723229','12.088138385502472','12.088138385502472','test'),('2019-05-29 15:59:59','2019-05-29 19:59:59','STRATBTC','4h','0.000120400000000','0.000120300000000','0.001467500000000','0.001466281146179','12.188538205980066','12.188538205980066','test'),('2019-05-30 07:59:59','2019-05-30 15:59:59','STRATBTC','4h','0.000122200000000','0.000119500000000','0.001467500000000','0.001435075695581','12.009001636661212','12.009001636661212','test'),('2019-06-08 07:59:59','2019-06-08 15:59:59','STRATBTC','4h','0.000116300000000','0.000116400000000','0.001467500000000','0.001468761822872','12.618228718830611','12.618228718830611','test'),('2019-06-13 03:59:59','2019-06-13 07:59:59','STRATBTC','4h','0.000118700000000','0.000117500000000','0.001467500000000','0.001452664279697','12.363100252737995','12.363100252737995','test'),('2019-06-16 07:59:59','2019-06-17 03:59:59','STRATBTC','4h','0.000122500000000','0.000111300000000','0.001467500000000','0.001333328571429','11.979591836734695','11.979591836734695','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','STRATBTC','4h','0.000058000000000','0.000055700000000','0.001467500000000','0.001409306034483','25.301724137931036','25.301724137931036','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','STRATBTC','4h','0.000057300000000','0.000056900000000','0.001467500000000','0.001457255671902','25.6108202443281','25.610820244328099','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','STRATBTC','4h','0.000057500000000','0.000057600000000','0.001467500000000','0.001470052173913','25.52173913043478','25.521739130434781','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','STRATBTC','4h','0.000058200000000','0.000057800000000','0.001467500000000','0.001457414089347','25.214776632302407','25.214776632302407','test'),('2019-08-22 03:59:59','2019-08-22 07:59:59','STRATBTC','4h','0.000037700000000','0.000037500000000','0.001467500000000','0.001459714854111','38.92572944297082','38.925729442970820','test'),('2019-08-22 15:59:59','2019-08-26 03:59:59','STRATBTC','4h','0.000038400000000','0.000039400000000','0.001467500000000','0.001505716145833','38.216145833333336','38.216145833333336','test'),('2019-08-28 23:59:59','2019-09-01 19:59:59','STRATBTC','4h','0.000044500000000','0.000040200000000','0.001467500000000','0.001325696629213','32.97752808988764','32.977528089887642','test'),('2019-09-18 03:59:59','2019-09-18 07:59:59','STRATBTC','4h','0.000035350000000','0.000036500000000','0.001467500000000','0.001515240452617','41.51343705799152','41.513437057991517','test'),('2019-09-19 11:59:59','2019-09-19 23:59:59','STRATBTC','4h','0.000036780000000','0.000035400000000','0.001467500000000','0.001412438825449','39.89940184883089','39.899401848830891','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','STRATBTC','4h','0.000035930000000','0.000033550000000','0.001467500000000','0.001370292930699','40.843306429167825','40.843306429167825','test'),('2019-09-27 19:59:59','2019-09-29 07:59:59','STRATBTC','4h','0.000035400000000','0.000035350000000','0.001467500000000','0.001465427259887','41.45480225988701','41.454802259887011','test'),('2019-09-30 07:59:59','2019-09-30 11:59:59','STRATBTC','4h','0.000035500000000','0.000035800000000','0.001467500000000','0.001479901408451','41.33802816901408','41.338028169014081','test'),('2019-10-02 03:59:59','2019-10-10 11:59:59','STRATBTC','4h','0.000038100000000','0.000040970000000','0.001467500000000','0.001578043963255','38.51706036745407','38.517060367454071','test'),('2019-10-12 07:59:59','2019-10-12 11:59:59','STRATBTC','4h','0.000040800000000','0.000041200000000','0.001467500000000','0.001481887254902','35.96813725490196','35.968137254901961','test'),('2019-10-16 19:59:59','2019-10-17 03:59:59','STRATBTC','4h','0.000042690000000','0.000042000000000','0.001467500000000','0.001443780744905','34.37573202155072','34.375732021550718','test'),('2019-11-03 15:59:59','2019-11-03 19:59:59','STRATBTC','4h','0.000036140000000','0.000036270000000','0.001467500000000','0.001472778776978','40.60597675705589','40.605976757055892','test'),('2019-11-06 15:59:59','2019-11-06 23:59:59','STRATBTC','4h','0.000036590000000','0.000035830000000','0.001467500000000','0.001437018994261','40.10658649904346','40.106586499043459','test'),('2019-11-09 19:59:59','2019-11-10 19:59:59','STRATBTC','4h','0.000036180000000','0.000035320000000','0.001467500000000','0.001432617468214','40.561083471531234','40.561083471531234','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','STRATBTC','4h','0.000035610000000','0.000034700000000','0.001467500000000','0.001429998595900','41.21033417579332','41.210334175793321','test'),('2019-11-16 07:59:59','2019-11-17 11:59:59','STRATBTC','4h','0.000035500000000','0.000035800000000','0.001467500000000','0.001479901408451','41.33802816901408','41.338028169014081','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','STRATBTC','4h','0.000039450000000','0.000038830000000','0.001467500000000','0.001444436628644','37.19898605830165','37.198986058301649','test'),('2019-12-03 07:59:59','2019-12-03 15:59:59','STRATBTC','4h','0.000041130000000','0.000040590000000','0.001467500000000','0.001448233041575','35.679552637977146','35.679552637977146','test'),('2019-12-05 03:59:59','2019-12-05 07:59:59','STRATBTC','4h','0.000040800000000','0.000040150000000','0.001467500000000','0.001444120710784','35.96813725490196','35.968137254901961','test'),('2019-12-08 23:59:59','2019-12-09 11:59:59','STRATBTC','4h','0.000041240000000','0.000040460000000','0.001467500000000','0.001439744180407','35.584384093113485','35.584384093113485','test'),('2019-12-09 19:59:59','2019-12-09 23:59:59','STRATBTC','4h','0.000040310000000','0.000040000000000','0.001467500000000','0.001456214338874','36.405358471843215','36.405358471843215','test'),('2019-12-11 15:59:59','2019-12-12 07:59:59','STRATBTC','4h','0.000041010000000','0.000040210000000','0.001467500000000','0.001438872835894','35.78395513289441','35.783955132894413','test'),('2019-12-28 03:59:59','2019-12-29 15:59:59','STRATBTC','4h','0.000048930000000','0.000047790000000','0.001467500000000','0.001433309319436','29.99182505620274','29.991825056202739','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:12:05
