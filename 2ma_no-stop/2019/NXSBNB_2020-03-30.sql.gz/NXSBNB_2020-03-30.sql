-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-03 19:59:59','NXSBNB','4h','0.058300000000000','0.057800000000000','0.711908500000000','0.705802938250429','12.211123499142369','12.211123499142369','test'),('2019-01-04 23:59:59','2019-01-08 07:59:59','NXSBNB','4h','0.057900000000000','0.059800000000000','0.711908500000000','0.735269918825561','12.295483592400691','12.295483592400691','test'),('2019-01-09 15:59:59','2019-01-10 07:59:59','NXSBNB','4h','0.060200000000000','0.059800000000000','0.716222464268997','0.711463511018040','11.897383127391986','11.897383127391986','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','NXSBNB','4h','0.059000000000000','0.057600000000000','0.716222464268997','0.699227354947360','12.139363801169441','12.139363801169441','test'),('2019-01-16 19:59:59','2019-01-16 23:59:59','NXSBNB','4h','0.057500000000000','0.055900000000000','0.716222464268997','0.696292795698034','12.456042856852122','12.456042856852122','test'),('2019-01-20 07:59:59','2019-01-20 15:59:59','NXSBNB','4h','0.056600000000000','0.055400000000000','0.716222464268997','0.701037535697923','12.654107142561786','12.654107142561786','test'),('2019-01-21 19:59:59','2019-01-21 23:59:59','NXSBNB','4h','0.058600000000000','0.055800000000000','0.716222464268997','0.682000230481400','12.22222635271326','12.222226352713260','test'),('2019-01-22 15:59:59','2019-01-24 03:59:59','NXSBNB','4h','0.056500000000000','0.057100000000000','0.716222464268997','0.723828366544420','12.676503792371628','12.676503792371628','test'),('2019-01-29 07:59:59','2019-01-29 11:59:59','NXSBNB','4h','0.055800000000000','0.055200000000000','0.716222464268997','0.708521147448900','12.83552803349457','12.835528033494571','test'),('2019-01-30 03:59:59','2019-01-31 07:59:59','NXSBNB','4h','0.055100000000000','0.054800000000000','0.716222464268997','0.712322886423612','12.99859281794913','12.998592817949129','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','NXSBNB','4h','0.031100000000000','0.030600000000000','0.716222464268997','0.704707633653740','23.029661230514375','23.029661230514375','test'),('2019-03-10 07:59:59','2019-03-11 15:59:59','NXSBNB','4h','0.029200000000000','0.028400000000000','0.716222464268997','0.696599931001353','24.528166584554693','24.528166584554693','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','NXSBNB','4h','0.026600000000000','0.025900000000000','0.716222464268997','0.697374504682971','26.925656551466055','26.925656551466055','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','NXSBNB','4h','0.026800000000000','0.025900000000000','0.716222464268997','0.692170217334590','26.724718816007353','26.724718816007353','test'),('2019-03-15 07:59:59','2019-03-16 11:59:59','NXSBNB','4h','0.027500000000000','0.026200000000000','0.716222464268997','0.682364675049008','26.04445324614535','26.044453246145348','test'),('2019-03-17 07:59:59','2019-03-17 11:59:59','NXSBNB','4h','0.027100000000000','0.026400000000000','0.716222464268997','0.697722253014816','26.428873220258193','26.428873220258193','test'),('2019-03-19 23:59:59','2019-03-23 07:59:59','NXSBNB','4h','0.026800000000000','0.026700000000000','0.716222464268997','0.713549992387396','26.724718816007353','26.724718816007353','test'),('2019-03-23 15:59:59','2019-03-23 19:59:59','NXSBNB','4h','0.027300000000000','0.027000000000000','0.716222464268997','0.708351887738568','26.23525510142846','26.235255101428461','test'),('2019-03-23 23:59:59','2019-03-24 11:59:59','NXSBNB','4h','0.027200000000000','0.024100000000000','0.716222464268997','0.634594168708928','26.331708245183716','26.331708245183716','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','NXSBNB','4h','0.022900000000000','0.022500000000000','0.716222464268997','0.703712028211897','31.276090142750963','31.276090142750963','test'),('2019-04-09 07:59:59','2019-04-09 11:59:59','NXSBNB','4h','0.022500000000000','0.021800000000000','0.716222464268997','0.693939987602850','31.832109523066535','31.832109523066535','test'),('2019-04-09 19:59:59','2019-04-09 23:59:59','NXSBNB','4h','0.022600000000000','0.022100000000000','0.716222464268997','0.700376834528533','31.691259480929077','31.691259480929077','test'),('2019-04-10 11:59:59','2019-04-10 15:59:59','NXSBNB','4h','0.022500000000000','0.022400000000000','0.716222464268997','0.713039253316690','31.832109523066535','31.832109523066535','test'),('2019-05-06 23:59:59','2019-05-07 07:59:59','NXSBNB','4h','0.015300000000000','0.015000000000000','0.716222464268997','0.702178886538232','46.8119257692155','46.811925769215499','test'),('2019-05-11 07:59:59','2019-05-11 11:59:59','NXSBNB','4h','0.015100000000000','0.014300000000000','0.716222464268997','0.678276903248123','47.43195127609252','47.431951276092519','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','NXSBNB','4h','0.014300000000000','0.013900000000000','0.716222464268997','0.696188269464270','50.085487011817975','50.085487011817975','test'),('2019-05-29 11:59:59','2019-05-29 15:59:59','NXSBNB','4h','0.012000000000000','0.011300000000000','0.716222464268997','0.674442820519972','59.68520535574975','59.685205355749751','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','NXSBNB','4h','0.011800000000000','0.011400000000000','0.716222464268997','0.691943736666658','60.69681900584721','60.696819005847210','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','NXSBNB','4h','0.011400000000000','0.011600000000000','0.716222464268997','0.728787770659681','62.82653195342079','62.826531953420790','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','NXSBNB','4h','0.011400000000000','0.011200000000000','0.716222464268997','0.703657157878313','62.82653195342079','62.826531953420790','test'),('2019-06-04 23:59:59','2019-06-05 03:59:59','NXSBNB','4h','0.011600000000000','0.011300000000000','0.716222464268997','0.697699469503420','61.74331588525837','61.743315885258369','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','NXSBNB','4h','0.011600000000000','0.011600000000000','0.716222464268997','0.716222464268997','61.74331588525837','61.743315885258369','test'),('2019-06-11 15:59:59','2019-06-11 23:59:59','NXSBNB','4h','0.011700000000000','0.011300000000000','0.716222464268997','0.691736226174330','61.21559523666641','61.215595236666410','test'),('2019-06-26 15:59:59','2019-06-26 19:59:59','NXSBNB','4h','0.010400000000000','0.010000000000000','0.716222464268997','0.688675446412497','68.86754464124972','68.867544641249722','test'),('2019-06-26 23:59:59','2019-06-27 03:59:59','NXSBNB','4h','0.010400000000000','0.010100000000000','0.716222464268997','0.695562200876622','68.86754464124972','68.867544641249722','test'),('2019-06-27 11:59:59','2019-06-27 15:59:59','NXSBNB','4h','0.010400000000000','0.009500000000000','0.716222464268997','0.654241674091872','68.86754464124972','68.867544641249722','test'),('2019-07-02 15:59:59','2019-07-02 19:59:59','NXSBNB','4h','0.010100000000000','0.009600000000000','0.716222464268997','0.680765906631918','70.91311527415813','70.913115274158130','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','NXSBNB','4h','0.009900000000000','0.009600000000000','0.716222464268997','0.694518753230542','72.34570346151484','72.345703461514844','test'),('2019-07-16 19:59:59','2019-07-16 23:59:59','NXSBNB','4h','0.009200000000000','0.008400000000000','0.716222464268997','0.653942249984736','77.85026785532577','77.850267855325768','test'),('2019-07-24 03:59:59','2019-07-24 07:59:59','NXSBNB','4h','0.008300000000000','0.008200000000000','0.477481642845998','0.471728851968335','57.52790877662627','57.527908776626269','test'),('2019-07-24 11:59:59','2019-07-27 15:59:59','NXSBNB','4h','0.008300000000000','0.008500000000000','0.520235754971662','0.532771556296280','62.67900662309183','62.679006623091830','test'),('2019-08-09 11:59:59','2019-08-09 15:59:59','NXSBNB','4h','0.009190000000000','0.008420000000000','0.523369705302817','0.479518271887891','56.94991352587777','56.949913525877768','test'),('2019-08-17 19:59:59','2019-08-19 07:59:59','NXSBNB','4h','0.008520000000000','0.007980000000000','0.523369705302817','0.490198385952638','61.42836916699731','61.428369166997307','test'),('2019-08-21 19:59:59','2019-08-22 03:59:59','NXSBNB','4h','0.008210000000000','0.008210000000000','0.523369705302817','0.523369705302817','63.74783255819939','63.747832558199391','test'),('2019-08-22 11:59:59','2019-08-22 15:59:59','NXSBNB','4h','0.008200000000000','0.008210000000000','0.523369705302817','0.524007961040991','63.8255738174167','63.825573817416704','test'),('2019-09-07 07:59:59','2019-09-07 11:59:59','NXSBNB','4h','0.009890000000000','0.009490000000000','0.523369705302817','0.502202073136879','52.919080414845','52.919080414844998','test'),('2019-09-08 19:59:59','2019-09-08 23:59:59','NXSBNB','4h','0.009900000000000','0.009630000000000','0.523369705302817','0.509095986067286','52.86562679826434','52.865626798264337','test'),('2019-09-09 19:59:59','2019-09-10 07:59:59','NXSBNB','4h','0.010230000000000','0.009640000000000','0.523369705302817','0.493185137743808','51.16028399832034','51.160283998320338','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','NXSBNB','4h','0.009920000000000','0.010000000000000','0.523369705302817','0.527590428732678','52.759042873267845','52.759042873267845','test'),('2019-09-19 19:59:59','2019-09-29 15:59:59','NXSBNB','4h','0.010790000000000','0.011670000000000','0.523369705302817','0.566054166903047','48.50507000026108','48.505070000261078','test'),('2019-10-17 23:59:59','2019-10-18 03:59:59','NXSBNB','4h','0.011290000000000','0.011360000000000','0.523369705302817','0.526614690189548','46.35692695330532','46.356926953305319','test'),('2019-11-21 03:59:59','2019-11-21 11:59:59','NXSBNB','4h','0.013700000000000','0.012940000000000','0.523369705302817','0.494336057417405','38.20216827027861','38.202168270278612','test'),('2019-11-23 07:59:59','2019-11-23 11:59:59','NXSBNB','4h','0.013480000000000','0.013250000000000','0.523369705302817','0.514439806770202','38.82564579397752','38.825645793977522','test'),('2019-11-26 15:59:59','2019-11-26 19:59:59','NXSBNB','4h','0.013230000000000','0.012860000000000','0.523369705302817','0.508732759651869','39.559312570129784','39.559312570129784','test'),('2019-11-27 15:59:59','2019-11-27 19:59:59','NXSBNB','4h','0.013220000000000','0.012590000000000','0.523369705302817','0.498428486366298','39.58923640717224','39.589236407172237','test'),('2019-11-28 19:59:59','2019-11-28 23:59:59','NXSBNB','4h','0.012990000000000','0.012860000000000','0.523369705302817','0.518131979229733','40.29020056218761','40.290200562187607','test'),('2019-11-29 07:59:59','2019-11-29 15:59:59','NXSBNB','4h','0.013280000000000','0.012950000000000','0.523369705302817','0.510364283408997','39.41036937521213','39.410369375212127','test'),('2019-12-02 03:59:59','2019-12-02 07:59:59','NXSBNB','4h','0.014630000000000','0.015480000000000','0.523369705302817','0.553777377859713','35.77373241987813','35.773732419878129','test'),('2019-12-08 11:59:59','2019-12-09 15:59:59','NXSBNB','4h','0.013330000000000','0.013230000000000','0.523369705302817','0.519443450949458','39.26254353359467','39.262543533594673','test'),('2019-12-11 03:59:59','2019-12-11 07:59:59','NXSBNB','4h','0.013450000000000','0.013230000000000','0.523369705302817','0.514809011238384','38.91224574742134','38.912245747421338','test'),('2019-12-13 23:59:59','2019-12-14 11:59:59','NXSBNB','4h','0.013390000000000','0.013250000000000','0.523369705302817','0.517897579929972','39.086609806035625','39.086609806035625','test'),('2019-12-14 19:59:59','2019-12-18 15:59:59','NXSBNB','4h','0.013670000000000','0.013870000000000','0.523369705302817','0.531026906550847','38.28600624014755','38.286006240147550','test'),('2019-12-20 03:59:59','2019-12-20 15:59:59','NXSBNB','4h','0.013910000000000','0.013730000000000','0.523369705302817','0.516597128239229','37.625428131043634','37.625428131043634','test'),('2019-12-24 11:59:59','2019-12-24 15:59:59','NXSBNB','4h','0.014250000000000','0.013790000000000','0.523369705302817','0.506474963938656','36.727698617741545','36.727698617741545','test'),('2019-12-25 15:59:59','2019-12-25 19:59:59','NXSBNB','4h','0.013700000000000','0.013650000000000','0.523369705302817','0.521459596889303','38.20216827027861','38.202168270278612','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','NXSBNB','4h','0.013700000000000','0.013450000000000','0.523369705302817','0.513819163235247','38.20216827027861','38.202168270278612','test'),('2019-12-31 07:59:59','2019-12-31 11:59:59','NXSBNB','4h','0.013460000000000','0.012990000000000','0.523369705302817','0.505094537287043','38.88333620377541','38.883336203775407','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 20:07:36
