-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-02 19:59:59','POWRBTC','4h','0.000021630000000','0.000021590000000','0.001467500000000','0.001464786176607','67.8455848358761','67.845584835876096','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','POWRBTC','4h','0.000021430000000','0.000021400000000','0.001467500000000','0.001465445636958','68.47876808212786','68.478768082127857','test'),('2019-01-04 15:59:59','2019-01-04 19:59:59','POWRBTC','4h','0.000021490000000','0.000021360000000','0.001467500000000','0.001458622615170','68.28757561656585','68.287575616565846','test'),('2019-01-05 07:59:59','2019-01-05 11:59:59','POWRBTC','4h','0.000021540000000','0.000021710000000','0.001467500000000','0.001479081940576','68.12906220984216','68.129062209842161','test'),('2019-01-14 19:59:59','2019-01-15 11:59:59','POWRBTC','4h','0.000020740000000','0.000020240000000','0.001467500000000','0.001432121504339','70.7569913211186','70.756991321118605','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','POWRBTC','4h','0.000023590000000','0.000023190000000','0.001467500000000','0.001442616574820','62.208562950402715','62.208562950402715','test'),('2019-02-08 03:59:59','2019-02-08 15:59:59','POWRBTC','4h','0.000023730000000','0.000023510000000','0.001467500000000','0.001453894858828','61.84155077960388','61.841550779603878','test'),('2019-02-11 23:59:59','2019-02-12 03:59:59','POWRBTC','4h','0.000023370000000','0.000022650000000','0.001467500000000','0.001422288189987','62.79418057338468','62.794180573384679','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','POWRBTC','4h','0.000023180000000','0.000023000000000','0.001467500000000','0.001456104400345','63.30888697152718','63.308886971527180','test'),('2019-02-21 23:59:59','2019-02-22 03:59:59','POWRBTC','4h','0.000024440000000','0.000023950000000','0.001467500000000','0.001438077945990','60.04500818330606','60.045008183306059','test'),('2019-02-23 07:59:59','2019-02-23 11:59:59','POWRBTC','4h','0.000024140000000','0.000024140000000','0.001467500000000','0.001467500000000','60.79121789560895','60.791217895608952','test'),('2019-02-26 19:59:59','2019-02-27 03:59:59','POWRBTC','4h','0.000024410000000','0.000024130000000','0.001467500000000','0.001450666734945','60.11880376894716','60.118803768947160','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','POWRBTC','4h','0.000023980000000','0.000023800000000','0.001467500000000','0.001456484570475','61.19683069224354','61.196830692243537','test'),('2019-03-07 07:59:59','2019-03-08 11:59:59','POWRBTC','4h','0.000025700000000','0.000024480000000','0.001467500000000','0.001397836575875','57.1011673151751','57.101167315175097','test'),('2019-03-17 15:59:59','2019-03-17 23:59:59','POWRBTC','4h','0.000026800000000','0.000026870000000','0.001467500000000','0.001471333022388','54.757462686567166','54.757462686567166','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','POWRBTC','4h','0.000026640000000','0.000026470000000','0.001467500000000','0.001458135322823','55.08633633633634','55.086336336336338','test'),('2019-03-19 23:59:59','2019-03-20 03:59:59','POWRBTC','4h','0.000026520000000','0.000026090000000','0.001467500000000','0.001443705693816','55.33559577677225','55.335595776772251','test'),('2019-03-20 15:59:59','2019-03-21 03:59:59','POWRBTC','4h','0.000026850000000','0.000026510000000','0.001467500000000','0.001448917132216','54.655493482309126','54.655493482309126','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','POWRBTC','4h','0.000026640000000','0.000026510000000','0.001467500000000','0.001460338776276','55.08633633633634','55.086336336336338','test'),('2019-03-24 07:59:59','2019-03-24 11:59:59','POWRBTC','4h','0.000026680000000','0.000029540000000','0.001467500000000','0.001624810719640','55.00374812593704','55.003748125937037','test'),('2019-04-21 11:59:59','2019-04-21 15:59:59','POWRBTC','4h','0.000023620000000','0.000023510000000','0.001467500000000','0.001460665749365','62.12955122777307','62.129551227773071','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','POWRBTC','4h','0.000015910000000','0.000015570000000','0.001467500000000','0.001436139220616','92.23758642363295','92.237586423632948','test'),('2019-05-23 03:59:59','2019-05-23 07:59:59','POWRBTC','4h','0.000015680000000','0.000015200000000','0.001467500000000','0.001422576530612','93.5905612244898','93.590561224489804','test'),('2019-05-24 03:59:59','2019-05-24 11:59:59','POWRBTC','4h','0.000016150000000','0.000015620000000','0.001467500000000','0.001419340557276','90.86687306501548','90.866873065015483','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','POWRBTC','4h','0.000015720000000','0.000015670000000','0.001467500000000','0.001462832379135','93.352417302799','93.352417302798997','test'),('2019-06-07 07:59:59','2019-06-11 07:59:59','POWRBTC','4h','0.000014800000000','0.000015140000000','0.001467500000000','0.001501212837838','99.1554054054054','99.155405405405403','test'),('2019-07-02 07:59:59','2019-07-02 15:59:59','POWRBTC','4h','0.000010570000000','0.000010260000000','0.001467500000000','0.001424460737938','138.83632923368023','138.836329233680232','test'),('2019-07-20 03:59:59','2019-07-21 03:59:59','POWRBTC','4h','0.000007730000000','0.000007600000000','0.001467500000000','0.001442820181113','189.84476067270376','189.844760672703757','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','POWRBTC','4h','0.000007640000000','0.000007580000000','0.001467500000000','0.001455975130890','192.08115183246076','192.081151832460762','test'),('2019-07-22 03:59:59','2019-07-22 11:59:59','POWRBTC','4h','0.000007670000000','0.000007670000000','0.001467500000000','0.001467500000000','191.3298565840939','191.329856584093903','test'),('2019-08-21 19:59:59','2019-08-26 03:59:59','POWRBTC','4h','0.000005600000000','0.000005690000000','0.001467500000000','0.001491084821429','262.05357142857144','262.053571428571445','test'),('2019-08-31 11:59:59','2019-08-31 23:59:59','POWRBTC','4h','0.000006030000000','0.000005620000000','0.001467500000000','0.001367719734660','243.3665008291874','243.366500829187402','test'),('2019-09-10 19:59:59','2019-09-11 03:59:59','POWRBTC','4h','0.000005270000000','0.000005150000000','0.001467500000000','0.001434084440228','278.46299810246677','278.462998102466770','test'),('2019-09-12 19:59:59','2019-09-14 03:59:59','POWRBTC','4h','0.000005670000000','0.000005340000000','0.001467500000000','0.001382089947090','258.8183421516755','258.818342151675495','test'),('2019-09-15 19:59:59','2019-09-15 23:59:59','POWRBTC','4h','0.000005300000000','0.000005270000000','0.001467500000000','0.001459193396226','276.8867924528302','276.886792452830207','test'),('2019-09-23 15:59:59','2019-09-23 23:59:59','POWRBTC','4h','0.000005460000000','0.000005390000000','0.001467500000000','0.001448685897436','268.7728937728938','268.772893772893781','test'),('2019-09-24 11:59:59','2019-09-24 23:59:59','POWRBTC','4h','0.000006350000000','0.000005280000000','0.001467500000000','0.001220220472441','231.10236220472441','231.102362204724415','test'),('2019-09-25 03:59:59','2019-09-25 07:59:59','POWRBTC','4h','0.000005860000000','0.000005580000000','0.001467500000000','0.001397380546075','250.42662116040958','250.426621160409582','test'),('2019-10-02 11:59:59','2019-10-03 03:59:59','POWRBTC','4h','0.000005710000000','0.000005670000000','0.001467500000000','0.001457219789842','257.00525394045536','257.005253940455361','test'),('2019-10-15 11:59:59','2019-10-16 15:59:59','POWRBTC','4h','0.000005840000000','0.000005580000000','0.001467500000000','0.001402166095890','251.28424657534248','251.284246575342479','test'),('2019-10-18 19:59:59','2019-10-18 23:59:59','POWRBTC','4h','0.000005790000000','0.000005560000000','0.001467500000000','0.001409205526770','253.45423143350607','253.454231433506067','test'),('2019-10-22 19:59:59','2019-10-23 15:59:59','POWRBTC','4h','0.000005720000000','0.000005600000000','0.001467500000000','0.001436713286713','256.55594405594405','256.555944055944053','test'),('2019-10-24 19:59:59','2019-10-25 03:59:59','POWRBTC','4h','0.000005680000000','0.000005630000000','0.001467500000000','0.001454581866197','258.36267605633805','258.362676056338046','test'),('2019-10-31 23:59:59','2019-11-01 03:59:59','POWRBTC','4h','0.000005320000000','0.000005310000000','0.001467500000000','0.001464741541353','275.84586466165416','275.845864661654161','test'),('2019-11-01 19:59:59','2019-11-01 23:59:59','POWRBTC','4h','0.000005270000000','0.000005270000000','0.001467500000000','0.001467500000000','278.46299810246677','278.462998102466770','test'),('2019-11-03 03:59:59','2019-11-04 07:59:59','POWRBTC','4h','0.000005310000000','0.000005250000000','0.001467500000000','0.001450918079096','276.3653483992467','276.365348399246727','test'),('2019-11-06 23:59:59','2019-11-07 11:59:59','POWRBTC','4h','0.000005330000000','0.000005210000000','0.001467500000000','0.001434460600375','275.328330206379','275.328330206379007','test'),('2019-11-09 15:59:59','2019-11-09 19:59:59','POWRBTC','4h','0.000005260000000','0.000005240000000','0.001467500000000','0.001461920152091','278.9923954372624','278.992395437262417','test'),('2019-11-13 11:59:59','2019-11-13 19:59:59','POWRBTC','4h','0.000005220000000','0.000005240000000','0.001467500000000','0.001473122605364','281.13026819923374','281.130268199233740','test'),('2019-11-20 19:59:59','2019-11-20 23:59:59','POWRBTC','4h','0.000005410000000','0.000005370000000','0.001467500000000','0.001456649722736','271.25693160813313','271.256931608133129','test'),('2019-11-21 07:59:59','2019-11-21 11:59:59','POWRBTC','4h','0.000005360000000','0.000005170000000','0.001467500000000','0.001415480410448','273.7873134328358','273.787313432835788','test'),('2019-11-23 19:59:59','2019-11-24 07:59:59','POWRBTC','4h','0.000005360000000','0.000005300000000','0.001467500000000','0.001451072761194','273.7873134328358','273.787313432835788','test'),('2019-11-26 15:59:59','2019-11-29 19:59:59','POWRBTC','4h','0.000005370000000','0.000005460000000','0.001467500000000','0.001492094972067','273.2774674115456','273.277467411545615','test'),('2019-12-01 19:59:59','2019-12-02 03:59:59','POWRBTC','4h','0.000005500000000','0.000005460000000','0.001467500000000','0.001456827272727','266.8181818181818','266.818181818181813','test'),('2019-12-07 23:59:59','2019-12-08 03:59:59','POWRBTC','4h','0.000005410000000','0.000005300000000','0.001467500000000','0.001437661737523','271.25693160813313','271.256931608133129','test'),('2019-12-09 07:59:59','2019-12-09 23:59:59','POWRBTC','4h','0.000005760000000','0.000005360000000','0.001467500000000','0.001365590277778','254.77430555555557','254.774305555555571','test'),('2019-12-11 23:59:59','2019-12-12 03:59:59','POWRBTC','4h','0.000005410000000','0.000005370000000','0.001467500000000','0.001456649722736','271.25693160813313','271.256931608133129','test'),('2019-12-12 11:59:59','2019-12-17 07:59:59','POWRBTC','4h','0.000005410000000','0.000005540000000','0.001467500000000','0.001502763401109','271.25693160813313','271.256931608133129','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:15:32
