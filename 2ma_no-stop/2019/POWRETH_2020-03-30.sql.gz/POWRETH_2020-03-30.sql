-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 23:59:59','2019-01-12 03:59:59','POWRETH','4h','0.000573100000000','0.000563230000000','0.072144500000000','0.070902018382481','125.88466236258942','125.884662362589424','test'),('2019-01-12 11:59:59','2019-01-12 15:59:59','POWRETH','4h','0.000566510000000','0.000571390000000','0.072144500000000','0.072765963275141','127.34903179114225','127.349031791142252','test'),('2019-01-24 23:59:59','2019-01-25 03:59:59','POWRETH','4h','0.000809680000000','0.000808040000000','0.072144500000000','0.071998371924711','89.10248493231894','89.102484932318944','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','POWRETH','4h','0.000810200000000','0.000802760000000','0.072144500000000','0.071482002986917','89.04529745741793','89.045297457417931','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','POWRETH','4h','0.000774460000000','0.000755630000000','0.072144500000000','0.070390399161997','93.15458513028432','93.154585130284318','test'),('2019-02-17 03:59:59','2019-02-17 11:59:59','POWRETH','4h','0.000727320000000','0.000713210000000','0.072144500000000','0.070744897493538','99.19224000439971','99.192240004399707','test'),('2019-02-26 19:59:59','2019-02-27 11:59:59','POWRETH','4h','0.000689990000000','0.000670520000000','0.072144500000000','0.070108740909289','104.55876172118437','104.558761721184368','test'),('2019-03-07 07:59:59','2019-03-08 11:59:59','POWRETH','4h','0.000720610000000','0.000698180000000','0.072144500000000','0.069898900945033','100.11587405115111','100.115874051151110','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','POWRETH','4h','0.000765140000000','0.000767340000000','0.072144500000000','0.072351936416865','94.28928039313067','94.289280393130667','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','POWRETH','4h','0.000768730000000','0.000772610000000','0.072144500000000','0.072508633909175','93.84894566362702','93.848945663627021','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','POWRETH','4h','0.000772260000000','0.000763180000000','0.072144500000000','0.071296246743325','93.41996218890012','93.419962188900115','test'),('2019-03-22 15:59:59','2019-03-23 19:59:59','POWRETH','4h','0.000772800000000','0.000766860000000','0.072144500000000','0.071589973175466','93.35468426501035','93.354684265010349','test'),('2019-04-17 19:59:59','2019-04-18 03:59:59','POWRETH','4h','0.000736960000000','0.000727220000000','0.072144500000000','0.071191005332718','97.89472970039078','97.894729700390783','test'),('2019-04-21 07:59:59','2019-04-21 11:59:59','POWRETH','4h','0.000729450000000','0.000737530000000','0.072144500000000','0.072943632990609','98.90259784769347','98.902597847693471','test'),('2019-04-23 15:59:59','2019-04-23 19:59:59','POWRETH','4h','0.000730280000000','0.000725620000000','0.072144500000000','0.071684137714301','98.79019006408501','98.790190064085010','test'),('2019-04-24 19:59:59','2019-04-24 23:59:59','POWRETH','4h','0.000734680000000','0.000725760000000','0.072144500000000','0.071268569064082','98.19853541678009','98.198535416780089','test'),('2019-04-28 03:59:59','2019-04-28 15:59:59','POWRETH','4h','0.000748050000000','0.000725300000000','0.072144500000000','0.069950412205067','96.44341955751621','96.443419557516208','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','POWRETH','4h','0.000519850000000','0.000513400000000','0.072144500000000','0.071249372511301','138.77945561219582','138.779455612195818','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','POWRETH','4h','0.000510790000000','0.000506820000000','0.072144500000000','0.071583773155308','141.241018813994','141.241018813994003','test'),('2019-05-25 23:59:59','2019-05-26 03:59:59','POWRETH','4h','0.000509990000000','0.000514970000000','0.072144500000000','0.072848983636934','141.46257769760192','141.462577697601915','test'),('2019-06-07 07:59:59','2019-06-12 15:59:59','POWRETH','4h','0.000475460000000','0.000481050000000','0.072144500000000','0.072992705432634','151.73621335128087','151.736213351280867','test'),('2019-06-19 11:59:59','2019-06-19 15:59:59','POWRETH','4h','0.000464710000000','0.000458810000000','0.072144500000000','0.071228546932496','155.24628262787544','155.246282627875445','test'),('2019-06-19 23:59:59','2019-06-20 03:59:59','POWRETH','4h','0.000469580000000','0.000457690000000','0.072144500000000','0.070317765247668','153.6362281187444','153.636228118744413','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','POWRETH','4h','0.000379860000000','0.000371380000000','0.072144500000000','0.070533945164008','189.92391933870374','189.923919338703740','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','POWRETH','4h','0.000376110000000','0.000371900000000','0.072144500000000','0.071336948100290','191.81755337534233','191.817553375342328','test'),('2019-07-04 11:59:59','2019-07-05 03:59:59','POWRETH','4h','0.000370010000000','0.000369910000000','0.072144500000000','0.072125002013459','194.97986540904301','194.979865409043015','test'),('2019-07-06 19:59:59','2019-07-07 07:59:59','POWRETH','4h','0.000374230000000','0.000372740000000','0.072144500000000','0.071857256045747','192.78117735082702','192.781177350827022','test'),('2019-07-16 11:59:59','2019-07-16 23:59:59','POWRETH','4h','0.000344750000000','0.000331410000000','0.072144500000000','0.069352889760696','209.2661348803481','209.266134880348091','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','POWRETH','4h','0.000340660000000','0.000318290000000','0.072144500000000','0.067407012578524','211.77860623495567','211.778606234955674','test'),('2019-07-19 03:59:59','2019-07-19 11:59:59','POWRETH','4h','0.000338650000000','0.000340000000000','0.072144500000000','0.072432098036321','213.03558245976672','213.035582459766715','test'),('2019-08-21 15:59:59','2019-08-26 03:59:59','POWRETH','4h','0.000301070000000','0.000307500000000','0.072144500000000','0.073685301590992','239.62699704387683','239.626997043876827','test'),('2019-08-28 03:59:59','2019-08-28 07:59:59','POWRETH','4h','0.000307490000000','0.000305000000000','0.072144500000000','0.071560286513383','234.62389020781163','234.623890207811627','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','POWRETH','4h','0.000308120000000','0.000302560000000','0.072144500000000','0.070842658444762','234.14416461119046','234.144164611190462','test'),('2019-08-30 15:59:59','2019-08-31 23:59:59','POWRETH','4h','0.000309970000000','0.000311710000000','0.072144500000000','0.072549479288318','232.74671742426685','232.746717424266848','test'),('2019-09-05 11:59:59','2019-09-05 23:59:59','POWRETH','4h','0.000312500000000','0.000308750000000','0.072144500000000','0.071278766000000','230.8624','230.862400000000008','test'),('2019-09-12 19:59:59','2019-09-13 23:59:59','POWRETH','4h','0.000327470000000','0.000300820000000','0.072144500000000','0.066273272330290','220.3087305707393','220.308730570739300','test'),('2019-09-24 11:59:59','2019-09-24 23:59:59','POWRETH','4h','0.000312500000000','0.000270340000000','0.072144500000000','0.062411341216000','230.8624','230.862400000000008','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','POWRETH','4h','0.000279410000000','0.000275000000000','0.072144500000000','0.071005824773630','258.2029991768369','258.202999176836897','test'),('2019-10-02 15:59:59','2019-10-02 19:59:59','POWRETH','4h','0.000272500000000','0.000263880000000','0.072144500000000','0.069862351045872','264.7504587155963','264.750458715596324','test'),('2019-10-03 11:59:59','2019-10-04 07:59:59','POWRETH','4h','0.000272440000000','0.000271850000000','0.072144500000000','0.071988262828513','264.8087652327118','264.808765232711778','test'),('2019-10-04 23:59:59','2019-10-05 03:59:59','POWRETH','4h','0.000271240000000','0.000265900000000','0.072144500000000','0.070724165130512','265.9803126382539','265.980312638253906','test'),('2019-10-05 07:59:59','2019-10-05 11:59:59','POWRETH','4h','0.000271250000000','0.000269860000000','0.072144500000000','0.071774800995392','265.9705069124424','265.970506912442374','test'),('2019-10-06 15:59:59','2019-10-07 03:59:59','POWRETH','4h','0.000271250000000','0.000270640000000','0.072144500000000','0.071982257990783','265.9705069124424','265.970506912442374','test'),('2019-10-08 11:59:59','2019-10-08 15:59:59','POWRETH','4h','0.000269760000000','0.000274320000000','0.072144500000000','0.073364024466192','267.4395759193357','267.439575919335709','test'),('2019-10-15 15:59:59','2019-10-16 11:59:59','POWRETH','4h','0.000268570000000','0.000264990000000','0.072144500000000','0.071182824049596','268.62456715195293','268.624567151952931','test'),('2019-10-22 15:59:59','2019-10-23 15:59:59','POWRETH','4h','0.000265730000000','0.000262160000000','0.072144500000000','0.071175261054454','271.4955029541264','271.495502954126380','test'),('2019-10-24 23:59:59','2019-10-25 03:59:59','POWRETH','4h','0.000264210000000','0.000260250000000','0.072144500000000','0.071063192630862','273.05741644903674','273.057416449036737','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','POWRETH','4h','0.000260450000000','0.000260370000000','0.072144500000000','0.072122340046074','276.99942407371856','276.999424073718558','test'),('2019-10-31 11:59:59','2019-10-31 15:59:59','POWRETH','4h','0.000267960000000','0.000263180000000','0.072144500000000','0.070857551537543','269.2360800119421','269.236080011942079','test'),('2019-11-07 03:59:59','2019-11-07 07:59:59','POWRETH','4h','0.000262360000000','0.000260450000000','0.072144500000000','0.071619282760329','274.98284799512123','274.982847995121233','test'),('2019-11-15 03:59:59','2019-11-16 19:59:59','POWRETH','4h','0.000253630000000','0.000253800000000','0.072144500000000','0.072192856129007','284.44781768718207','284.447817687182066','test'),('2019-11-19 03:59:59','2019-11-19 07:59:59','POWRETH','4h','0.000256040000000','0.000250850000000','0.072144500000000','0.070682111486486','281.77042649586','281.770426495860022','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','POWRETH','4h','0.000252050000000','0.000249200000000','0.072144500000000','0.071328741916286','286.23090656615756','286.230906566157557','test'),('2019-11-23 07:59:59','2019-11-23 11:59:59','POWRETH','4h','0.000252240000000','0.000256360000000','0.072144500000000','0.073322883047891','286.0153028861402','286.015302886140205','test'),('2019-12-04 23:59:59','2019-12-05 03:59:59','POWRETH','4h','0.000269570000000','0.000267270000000','0.072144500000000','0.071528955429017','267.62807434061654','267.628074340616536','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','POWRETH','4h','0.000269920000000','0.000265900000000','0.072144500000000','0.071070030194132','267.2810462359218','267.281046235921792','test'),('2019-12-07 07:59:59','2019-12-07 19:59:59','POWRETH','4h','0.000270000000000','0.000270170000000','0.072144500000000','0.072189924314815','267.20185185185187','267.201851851851870','test'),('2019-12-09 07:59:59','2019-12-09 23:59:59','POWRETH','4h','0.000287970000000','0.000268630000000','0.072144500000000','0.067299291714415','250.52783276035697','250.527832760356972','test'),('2019-12-11 15:59:59','2019-12-12 07:59:59','POWRETH','4h','0.000270680000000','0.000272550000000','0.072144500000000','0.072642912202601','266.5305896261268','266.530589626126812','test'),('2019-12-22 15:59:59','2019-12-22 19:59:59','POWRETH','4h','0.000287580000000','0.000282080000000','0.072144500000000','0.070764728284303','250.86758467209123','250.867584672091226','test'),('2019-12-24 07:59:59','2019-12-24 11:59:59','POWRETH','4h','0.000286360000000','0.000286060000000','0.072144500000000','0.072068919087861','251.9363737952228','251.936373795222806','test'),('2019-12-25 03:59:59','2019-12-25 19:59:59','POWRETH','4h','0.000286360000000','0.000284490000000','0.072144500000000','0.071673378981003','251.9363737952228','251.936373795222806','test'),('2019-12-28 07:59:59','2019-12-28 11:59:59','POWRETH','4h','0.000285560000000','0.000281260000000','0.072144500000000','0.071058138639866','252.64217677545872','252.642176775458722','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  7:38:20
