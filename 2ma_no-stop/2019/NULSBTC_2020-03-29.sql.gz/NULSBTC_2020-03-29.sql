-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 11:59:59','2019-01-05 15:59:59','NULSBTC','4h','0.000110110000000','0.000109370000000','0.001467500000000','0.001457637589683','13.32758150939969','13.327581509399691','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','NULSBTC','4h','0.000112970000000','0.000108960000000','0.001467500000000','0.001415409400726','12.990174382579447','12.990174382579447','test'),('2019-01-09 23:59:59','2019-01-10 07:59:59','NULSBTC','4h','0.000110070000000','0.000105200000000','0.001467500000000','0.001402571091124','13.33242482056873','13.332424820568731','test'),('2019-01-12 19:59:59','2019-01-12 23:59:59','NULSBTC','4h','0.000107820000000','0.000106780000000','0.001467500000000','0.001453344926730','13.610647375255056','13.610647375255056','test'),('2019-01-16 19:59:59','2019-01-17 03:59:59','NULSBTC','4h','0.000106910000000','0.000106800000000','0.001467500000000','0.001465990085118','13.726498924328874','13.726498924328874','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','NULSBTC','4h','0.000121580000000','0.000116260000000','0.001467500000000','0.001403286313538','12.070241816088172','12.070241816088172','test'),('2019-01-29 11:59:59','2019-01-30 03:59:59','NULSBTC','4h','0.000122160000000','0.000118300000000','0.001467500000000','0.001421130075311','12.01293385723641','12.012933857236410','test'),('2019-01-30 15:59:59','2019-01-30 23:59:59','NULSBTC','4h','0.000119800000000','0.000119060000000','0.001467500000000','0.001458435308848','12.24958263772955','12.249582637729549','test'),('2019-02-03 03:59:59','2019-02-03 07:59:59','NULSBTC','4h','0.000117200000000','0.000117530000000','0.001467500000000','0.001471632039249','12.521331058020477','12.521331058020477','test'),('2019-02-13 07:59:59','2019-02-13 11:59:59','NULSBTC','4h','0.000112700000000','0.000112190000000','0.001467500000000','0.001460859139308','13.021295474711623','13.021295474711623','test'),('2019-02-14 03:59:59','2019-02-14 07:59:59','NULSBTC','4h','0.000112670000000','0.000111910000000','0.001467500000000','0.001457601180438','13.024762580988728','13.024762580988728','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','NULSBTC','4h','0.000111970000000','0.000112410000000','0.001467500000000','0.001473266723229','13.106189157810128','13.106189157810128','test'),('2019-02-16 03:59:59','2019-02-16 15:59:59','NULSBTC','4h','0.000114200000000','0.000112720000000','0.001467500000000','0.001448481611208','12.850262697022767','12.850262697022767','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','NULSBTC','4h','0.000113300000000','0.000112930000000','0.001467500000000','0.001462707634598','12.952338923212709','12.952338923212709','test'),('2019-02-20 19:59:59','2019-02-21 03:59:59','NULSBTC','4h','0.000113870000000','0.000113420000000','0.001467500000000','0.001461700623518','12.887503293229122','12.887503293229122','test'),('2019-02-21 15:59:59','2019-02-22 03:59:59','NULSBTC','4h','0.000113130000000','0.000112240000000','0.001467500000000','0.001455955095907','12.971802351277292','12.971802351277292','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','NULSBTC','4h','0.000113090000000','0.000112420000000','0.001467500000000','0.001458805818375','12.976390485454063','12.976390485454063','test'),('2019-02-28 23:59:59','2019-03-01 07:59:59','NULSBTC','4h','0.000110590000000','0.000110260000000','0.001467500000000','0.001463120987431','13.269735057419297','13.269735057419297','test'),('2019-03-04 19:59:59','2019-03-06 23:59:59','NULSBTC','4h','0.000113170000000','0.000110670000000','0.001467500000000','0.001435081956349','12.967217460457718','12.967217460457718','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','NULSBTC','4h','0.000111070000000','0.000111790000000','0.001467500000000','0.001477012919780','13.212388583775997','13.212388583775997','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','NULSBTC','4h','0.000188380000000','0.000185530000000','0.001467500000000','0.001445298200446','7.790105106699225','7.790105106699225','test'),('2019-04-06 03:59:59','2019-04-06 19:59:59','NULSBTC','4h','0.000189000000000','0.000188090000000','0.001467500000000','0.001460434259259','7.764550264550264','7.764550264550264','test'),('2019-04-15 15:59:59','2019-04-15 19:59:59','NULSBTC','4h','0.000175550000000','0.000167610000000','0.001467500000000','0.001401126032469','8.359441754485902','8.359441754485902','test'),('2019-04-16 03:59:59','2019-04-16 07:59:59','NULSBTC','4h','0.000173140000000','0.000172820000000','0.001467500000000','0.001464787744022','8.475799930691926','8.475799930691926','test'),('2019-04-17 19:59:59','2019-04-18 07:59:59','NULSBTC','4h','0.000170960000000','0.000170670000000','0.001467500000000','0.001465010675012','8.58387927000468','8.583879270004680','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','NULSBTC','4h','0.000169260000000','0.000165910000000','0.001467500000000','0.001438455187286','8.670093347512703','8.670093347512703','test'),('2019-04-23 15:59:59','2019-04-23 19:59:59','NULSBTC','4h','0.000168500000000','0.000164100000000','0.001467500000000','0.001429179525223','8.70919881305638','8.709198813056380','test'),('2019-04-23 23:59:59','2019-04-24 03:59:59','NULSBTC','4h','0.000173430000000','0.000168540000000','0.001467500000000','0.001426122643141','8.461627169463185','8.461627169463185','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','NULSBTC','4h','0.000096210000000','0.000097110000000','0.001467500000000','0.001481227782975','15.253092194158612','15.253092194158612','test'),('2019-05-25 03:59:59','2019-05-25 19:59:59','NULSBTC','4h','0.000096320000000','0.000095530000000','0.001467500000000','0.001455463818522','15.235672757475085','15.235672757475085','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','NULSBTC','4h','0.000095830000000','0.000094450000000','0.001467500000000','0.001446367264948','15.313576124386936','15.313576124386936','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','NULSBTC','4h','0.000092810000000','0.000090160000000','0.001467500000000','0.001425598534641','15.811873720504256','15.811873720504256','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','NULSBTC','4h','0.000092450000000','0.000091930000000','0.001467500000000','0.001459245808545','15.873445105462412','15.873445105462412','test'),('2019-06-04 11:59:59','2019-06-14 15:59:59','NULSBTC','4h','0.000092930000000','0.000103680000000','0.001467500000000','0.001637258151297','15.79145593457441','15.791455934574410','test'),('2019-06-17 23:59:59','2019-06-18 03:59:59','NULSBTC','4h','0.000108730000000','0.000107810000000','0.001467500000000','0.001455083003771','13.496735031729974','13.496735031729974','test'),('2019-06-18 15:59:59','2019-06-18 19:59:59','NULSBTC','4h','0.000110400000000','0.000108650000000','0.001467500000000','0.001444237998188','13.292572463768117','13.292572463768117','test'),('2019-07-01 19:59:59','2019-07-02 11:59:59','NULSBTC','4h','0.000083640000000','0.000084370000000','0.001467500000000','0.001480308165949','17.545432807269247','17.545432807269247','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','NULSBTC','4h','0.000082900000000','0.000077910000000','0.001467500000000','0.001379166767189','17.702050663449942','17.702050663449942','test'),('2019-07-05 15:59:59','2019-07-07 23:59:59','NULSBTC','4h','0.000082040000000','0.000082510000000','0.001467500000000','0.001475907179425','17.887615797172113','17.887615797172113','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','NULSBTC','4h','0.000059510000000','0.000058960000000','0.001467500000000','0.001453937153420','24.659721055284827','24.659721055284827','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','NULSBTC','4h','0.000042440000000','0.000041350000000','0.001467500000000','0.001429809731385','34.57822808671065','34.578228086710652','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','NULSBTC','4h','0.000042230000000','0.000042150000000','0.001467500000000','0.001464719985792','34.75017759886337','34.750177598863367','test'),('2019-08-24 07:59:59','2019-08-27 07:59:59','NULSBTC','4h','0.000042700000000','0.000045170000000','0.001467500000000','0.001552388173302','34.36768149882904','34.367681498829043','test'),('2019-08-31 07:59:59','2019-08-31 11:59:59','NULSBTC','4h','0.000045650000000','0.000045560000000','0.001467500000000','0.001464606790800','32.14676889375685','32.146768893756850','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','NULSBTC','4h','0.000045670000000','0.000046020000000','0.001467500000000','0.001478746441866','32.13269104444931','32.132691044449309','test'),('2019-09-09 07:59:59','2019-09-09 11:59:59','NULSBTC','4h','0.000043460000000','0.000042220000000','0.001467500000000','0.001425629314312','33.76668200644271','33.766682006442707','test'),('2019-09-16 19:59:59','2019-09-16 23:59:59','NULSBTC','4h','0.000041300000000','0.000041090000000','0.001467500000000','0.001460038135593','35.53268765133172','35.532687651331720','test'),('2019-09-27 15:59:59','2019-09-27 23:59:59','NULSBTC','4h','0.000041360000000','0.000041370000000','0.001467500000000','0.001467854811412','35.48114119922631','35.481141199226307','test'),('2019-09-29 15:59:59','2019-09-30 07:59:59','NULSBTC','4h','0.000042080000000','0.000042180000000','0.001467500000000','0.001470987404943','34.8740494296578','34.874049429657802','test'),('2019-10-28 03:59:59','2019-11-04 23:59:59','NULSBTC','4h','0.000044740000000','0.000043430000000','0.001467500000000','0.001424531180152','32.80062583817613','32.800625838176131','test'),('2019-11-06 03:59:59','2019-11-06 07:59:59','NULSBTC','4h','0.000043890000000','0.000043720000000','0.001467500000000','0.001461815903395','33.435862383230806','33.435862383230806','test'),('2019-11-06 15:59:59','2019-11-07 03:59:59','NULSBTC','4h','0.000044320000000','0.000044040000000','0.001467500000000','0.001458228790614','33.11146209386281','33.111462093862812','test'),('2019-11-11 15:59:59','2019-11-15 15:59:59','NULSBTC','4h','0.000045280000000','0.000045850000000','0.001467500000000','0.001485973387809','32.40945229681979','32.409452296819786','test'),('2019-11-17 03:59:59','2019-11-17 07:59:59','NULSBTC','4h','0.000045920000000','0.000046000000000','0.001467500000000','0.001470056620209','31.95775261324042','31.957752613240419','test'),('2019-12-01 11:59:59','2019-12-02 19:59:59','NULSBTC','4h','0.000043620000000','0.000041630000000','0.001467500000000','0.001400550779459','33.64282439248051','33.642824392480513','test'),('2019-12-03 15:59:59','2019-12-03 19:59:59','NULSBTC','4h','0.000041790000000','0.000041550000000','0.001467500000000','0.001459072146447','35.1160564728404','35.116056472840398','test'),('2019-12-08 23:59:59','2019-12-09 03:59:59','NULSBTC','4h','0.000040900000000','0.000040200000000','0.001467500000000','0.001442383863081','35.88019559902201','35.880195599022009','test'),('2019-12-09 07:59:59','2019-12-09 11:59:59','NULSBTC','4h','0.000040540000000','0.000040450000000','0.001467500000000','0.001464242106561','36.19881598421312','36.198815984213120','test'),('2019-12-09 15:59:59','2019-12-10 03:59:59','NULSBTC','4h','0.000041010000000','0.000039280000000','0.001467500000000','0.001405593757620','35.78395513289441','35.783955132894413','test'),('2019-12-27 11:59:59','2019-12-28 15:59:59','NULSBTC','4h','0.000035610000000','0.000034510000000','0.001467500000000','0.001422168632407','41.21033417579332','41.210334175793321','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  5:43:57
