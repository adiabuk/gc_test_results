-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 23:59:59','2019-01-04 03:59:59','WTCBNB','4h','0.195100000000000','0.192800000000000','0.711908500000000','0.703515934392619','3.6489415684264483','3.648941568426448','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','WTCBNB','4h','0.194400000000000','0.192800000000000','0.711908500000000','0.706049170781893','3.662080761316873','3.662080761316873','test'),('2019-01-09 23:59:59','2019-01-10 07:59:59','WTCBNB','4h','0.194000000000000','0.191900000000000','0.711908500000000','0.704202273969072','3.6696314432989694','3.669631443298969','test'),('2019-01-13 23:59:59','2019-01-14 07:59:59','WTCBNB','4h','0.189400000000000','0.192200000000000','0.711908500000000','0.722433018479409','3.7587565997888066','3.758756599788807','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','WTCBNB','4h','0.188600000000000','0.185800000000000','0.711908500000000','0.701339338812301','3.7747004241781554','3.774700424178155','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','WTCBNB','4h','0.189200000000000','0.189000000000000','0.711908500000000','0.711155954016913','3.762729915433404','3.762729915433404','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','WTCBNB','4h','0.118200000000000','0.115700000000000','0.711908500000000','0.696851213620981','6.022914551607445','6.022914551607445','test'),('2019-02-19 03:59:59','2019-02-19 07:59:59','WTCBNB','4h','0.118900000000000','0.114800000000000','0.711908500000000','0.687359931034483','5.987455845248108','5.987455845248108','test'),('2019-02-26 07:59:59','2019-02-27 15:59:59','WTCBNB','4h','0.107900000000000','0.107100000000000','0.711908500000000','0.706630216404078','6.5978544949026885','6.597854494902688','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','WTCBNB','4h','0.108700000000000','0.105100000000000','0.711908500000000','0.688331033578657','6.549296228150874','6.549296228150874','test'),('2019-03-15 19:59:59','2019-03-16 03:59:59','WTCBNB','4h','0.086400000000000','0.086900000000000','0.711908500000000','0.716028340856481','8.239681712962962','8.239681712962962','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','WTCBNB','4h','0.085400000000000','0.085500000000000','0.711908500000000','0.712742116510539','8.336165105386417','8.336165105386417','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','WTCBNB','4h','0.086700000000000','0.085500000000000','0.711908500000000','0.702055095155710','8.211170703575549','8.211170703575549','test'),('2019-03-24 07:59:59','2019-03-24 11:59:59','WTCBNB','4h','0.084300000000000','0.072900000000000','0.711908500000000','0.615636176156584','8.444940688018981','8.444940688018981','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','WTCBNB','4h','0.081700000000000','0.079900000000000','0.711908500000000','0.696223857405141','8.713690330477357','8.713690330477357','test'),('2019-03-27 19:59:59','2019-03-27 23:59:59','WTCBNB','4h','0.080500000000000','0.080200000000000','0.711908500000000','0.709255424844720','8.843583850931678','8.843583850931678','test'),('2019-03-28 03:59:59','2019-03-28 07:59:59','WTCBNB','4h','0.080600000000000','0.085900000000000','0.711908500000000','0.758721341811414','8.832611662531017','8.832611662531017','test'),('2019-04-11 23:59:59','2019-04-12 03:59:59','WTCBNB','4h','0.112900000000000','0.115400000000000','0.711908500000000','0.727672638618246','6.305655447298495','6.305655447298495','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','WTCBNB','4h','0.112900000000000','0.113400000000000','0.711908500000000','0.715061327723649','6.305655447298495','6.305655447298495','test'),('2019-04-15 03:59:59','2019-04-15 11:59:59','WTCBNB','4h','0.113400000000000','0.111800000000000','0.711908500000000','0.701863935626102','6.277852733686068','6.277852733686068','test'),('2019-04-17 11:59:59','2019-04-17 23:59:59','WTCBNB','4h','0.113600000000000','0.112900000000000','0.711908500000000','0.707521739876761','6.266800176056338','6.266800176056338','test'),('2019-04-20 19:59:59','2019-04-20 23:59:59','WTCBNB','4h','0.111400000000000','0.109800000000000','0.711908500000000','0.701683602333932','6.3905610412926395','6.390561041292639','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','WTCBNB','4h','0.116500000000000','0.108300000000000','0.711908500000000','0.661799918884120','6.1108025751072965','6.110802575107297','test'),('2019-04-23 07:59:59','2019-04-23 11:59:59','WTCBNB','4h','0.110200000000000','0.113600000000000','0.711908500000000','0.733873009074410','6.460149727767695','6.460149727767695','test'),('2019-04-24 03:59:59','2019-04-24 11:59:59','WTCBNB','4h','0.115600000000000','0.113800000000000','0.711908500000000','0.700823419550173','6.158378027681661','6.158378027681661','test'),('2019-05-01 11:59:59','2019-05-01 15:59:59','WTCBNB','4h','0.100600000000000','0.099400000000000','0.711908500000000','0.703416549701789','7.076625248508948','7.076625248508948','test'),('2019-05-10 07:59:59','2019-05-11 15:59:59','WTCBNB','4h','0.100200000000000','0.092900000000000','0.711908500000000','0.660042910678643','7.104875249500998','7.104875249500998','test'),('2019-05-12 03:59:59','2019-05-12 11:59:59','WTCBNB','4h','0.095900000000000','0.093600000000000','0.711908500000000','0.694834573514077','7.42344629822732','7.423446298227320','test'),('2019-05-13 15:59:59','2019-05-13 19:59:59','WTCBNB','4h','0.097300000000000','0.092100000000000','0.711908500000000','0.673862002569373','7.31663412127441','7.316634121274410','test'),('2019-05-14 03:59:59','2019-05-14 07:59:59','WTCBNB','4h','0.096100000000000','0.094400000000000','0.711908500000000','0.699314905306972','7.407996878251821','7.407996878251821','test'),('2019-05-30 07:59:59','2019-05-31 07:59:59','WTCBNB','4h','0.080200000000000','0.074100000000000','0.711908500000000','0.657760846009975','8.87666458852868','8.876664588528680','test'),('2019-06-09 23:59:59','2019-06-10 19:59:59','WTCBNB','4h','0.068500000000000','0.068300000000000','0.711908500000000','0.709829935036496','10.392824817518248','10.392824817518248','test'),('2019-07-02 07:59:59','2019-07-09 11:59:59','WTCBNB','4h','0.046900000000000','0.065320000000000','0.711908500000000','0.991510942857143','15.179285714285717','15.179285714285717','test'),('2019-07-15 07:59:59','2019-07-15 19:59:59','WTCBNB','4h','0.072790000000000','0.067910000000000','0.711908500000000','0.664180604959473','9.780306360763843','9.780306360763843','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','WTCBNB','4h','0.062890000000000','0.064340000000000','0.711908500000000','0.728322354746383','11.31989982509143','11.319899825091429','test'),('2019-07-31 23:59:59','2019-08-01 03:59:59','WTCBNB','4h','0.065840000000000','0.065700000000000','0.711908500000000','0.710394721294046','10.812705042527341','10.812705042527341','test'),('2019-08-03 03:59:59','2019-08-03 07:59:59','WTCBNB','4h','0.065360000000000','0.063890000000000','0.711908500000000','0.695897094017748','10.892112913096696','10.892112913096696','test'),('2019-08-04 11:59:59','2019-08-05 03:59:59','WTCBNB','4h','0.065850000000000','0.063660000000000','0.711908500000000','0.688232271981777','10.811063022019741','10.811063022019741','test'),('2019-08-19 23:59:59','2019-08-20 03:59:59','WTCBNB','4h','0.053430000000000','0.052710000000000','0.711908500000000','0.702315123245368','13.324134381433653','13.324134381433653','test'),('2019-08-22 03:59:59','2019-08-22 15:59:59','WTCBNB','4h','0.053600000000000','0.052330000000000','0.711908500000000','0.695040518750000','13.281875000000001','13.281875000000001','test'),('2019-08-23 23:59:59','2019-08-24 03:59:59','WTCBNB','4h','0.052880000000000','0.052870000000000','0.711908500000000','0.711773872825265','13.462717473524963','13.462717473524963','test'),('2019-08-26 19:59:59','2019-08-26 23:59:59','WTCBNB','4h','0.053500000000000','0.052530000000000','0.711908500000000','0.699001000093458','13.30670093457944','13.306700934579441','test'),('2019-08-27 03:59:59','2019-08-27 07:59:59','WTCBNB','4h','0.053960000000000','0.052750000000000','0.711908500000000','0.695944651130467','13.19326352853966','13.193263528539660','test'),('2019-08-29 11:59:59','2019-08-29 15:59:59','WTCBNB','4h','0.053590000000000','0.051650000000000','0.711908500000000','0.686136854357156','13.284353424146298','13.284353424146298','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','WTCBNB','4h','0.052970000000000','0.051920000000000','0.711908500000000','0.697796664527091','13.439843307532566','13.439843307532566','test'),('2019-08-31 07:59:59','2019-08-31 11:59:59','WTCBNB','4h','0.052890000000000','0.052910000000000','0.711908500000000','0.712177703441104','13.460172055208925','13.460172055208925','test'),('2019-09-04 03:59:59','2019-09-04 07:59:59','WTCBNB','4h','0.053480000000000','0.053100000000000','0.711908500000000','0.706850062640239','13.311677262528049','13.311677262528049','test'),('2019-09-16 11:59:59','2019-09-16 19:59:59','WTCBNB','4h','0.047890000000000','0.048000000000000','0.711908500000000','0.713543704322406','14.865493840050116','14.865493840050116','test'),('2019-09-18 23:59:59','2019-09-19 03:59:59','WTCBNB','4h','0.047620000000000','0.045590000000000','0.711908500000000','0.681560447606048','14.949779504409912','14.949779504409912','test'),('2019-09-21 15:59:59','2019-09-24 03:59:59','WTCBNB','4h','0.047020000000000','0.049580000000000','0.711908500000000','0.750668299234369','15.14054657592514','15.140546575925139','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','WTCBNB','4h','0.047630000000000','0.045850000000000','0.711908500000000','0.685303479424732','14.946640772622299','14.946640772622299','test'),('2019-09-28 11:59:59','2019-09-28 15:59:59','WTCBNB','4h','0.047130000000000','0.046360000000000','0.711908500000000','0.700277489072778','15.105208996392957','15.105208996392957','test'),('2019-10-04 23:59:59','2019-10-05 03:59:59','WTCBNB','4h','0.046670000000000','0.046680000000000','0.711908500000000','0.712061040925648','15.2540925648168','15.254092564816800','test'),('2019-10-06 03:59:59','2019-10-06 07:59:59','WTCBNB','4h','0.046250000000000','0.045730000000000','0.711908500000000','0.703904339567568','15.392616216216217','15.392616216216217','test'),('2019-10-06 11:59:59','2019-10-06 15:59:59','WTCBNB','4h','0.046380000000000','0.045990000000000','0.711908500000000','0.705922206015524','15.34947175506684','15.349471755066840','test'),('2019-10-07 07:59:59','2019-10-07 11:59:59','WTCBNB','4h','0.046120000000000','0.045000000000000','0.711908500000000','0.694620175628795','15.4360039028621','15.436003902862099','test'),('2019-10-08 23:59:59','2019-10-09 07:59:59','WTCBNB','4h','0.046600000000000','0.044060000000000','0.711908500000000','0.673104903648069','15.277006437768241','15.277006437768241','test'),('2019-10-11 19:59:59','2019-10-12 15:59:59','WTCBNB','4h','0.045480000000000','0.044010000000000','0.711908500000000','0.688898264841689','15.653221196130168','15.653221196130168','test'),('2019-10-27 19:59:59','2019-10-28 03:59:59','WTCBNB','4h','0.039280000000000','0.037050000000000','0.711908500000000','0.671492106033605','18.123943482688393','18.123943482688393','test'),('2019-10-28 11:59:59','2019-10-28 23:59:59','WTCBNB','4h','0.039560000000000','0.037720000000000','0.711908500000000','0.678796476744186','17.99566481294237','17.995664812942369','test'),('2019-10-29 11:59:59','2019-10-29 15:59:59','WTCBNB','4h','0.038560000000000','0.037390000000000','0.711908500000000','0.690307541882780','18.46235736514523','18.462357365145230','test'),('2019-10-31 07:59:59','2019-10-31 11:59:59','WTCBNB','4h','0.038060000000000','0.036260000000000','0.711908500000000','0.678239679716238','18.704900157645824','18.704900157645824','test'),('2019-11-02 15:59:59','2019-11-02 19:59:59','WTCBNB','4h','0.037270000000000','0.036920000000000','0.711908500000000','0.705223016367051','19.10138180842501','19.101381808425010','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','WTCBNB','4h','0.037100000000000','0.036840000000000','0.711908500000000','0.706919383827493','19.18890835579515','19.188908355795149','test'),('2019-11-03 15:59:59','2019-11-03 23:59:59','WTCBNB','4h','0.037680000000000','0.036890000000000','0.711908500000000','0.696982605228238','18.893537685774948','18.893537685774948','test'),('2019-11-04 11:59:59','2019-11-04 15:59:59','WTCBNB','4h','0.037960000000000','0.038010000000000','0.711908500000000','0.712846208772392','18.75417544783983','18.754175447839831','test'),('2019-11-05 15:59:59','2019-11-07 15:59:59','WTCBNB','4h','0.038930000000000','0.038580000000000','0.711908500000000','0.705508089648086','18.286886719753404','18.286886719753404','test'),('2019-11-17 11:59:59','2019-11-17 15:59:59','WTCBNB','4h','0.035410000000000','0.034560000000000','0.711908500000000','0.694819479243152','20.10473030217453','20.104730302174531','test'),('2019-11-17 19:59:59','2019-11-19 07:59:59','WTCBNB','4h','0.036620000000000','0.035360000000000','0.711908500000000','0.687413559803386','19.44042872747133','19.440428727471328','test'),('2019-11-19 19:59:59','2019-11-20 07:59:59','WTCBNB','4h','0.035830000000000','0.035570000000000','0.711908500000000','0.706742543818030','19.869062238347755','19.869062238347755','test'),('2019-11-20 23:59:59','2019-11-21 03:59:59','WTCBNB','4h','0.036010000000000','0.035640000000000','0.711908500000000','0.704593694529297','19.769744515412388','19.769744515412388','test'),('2019-11-28 19:59:59','2019-11-29 19:59:59','WTCBNB','4h','0.035120000000000','0.033950000000000','0.711908500000000','0.688191730495444','20.27074316628702','20.270743166287019','test'),('2019-12-08 11:59:59','2019-12-08 23:59:59','WTCBNB','4h','0.032930000000000','0.032560000000000','0.711908500000000','0.703909528089888','21.618843000303677','21.618843000303677','test'),('2019-12-09 07:59:59','2019-12-09 23:59:59','WTCBNB','4h','0.032280000000000','0.032560000000000','0.711908500000000','0.718083666666667','22.054166666666667','22.054166666666667','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','WTCBNB','4h','0.031850000000000','0.031010000000000','0.711908500000000','0.693132891208791','22.35191522762951','22.351915227629512','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:55:09
