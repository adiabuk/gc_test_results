-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 03:59:59','2019-01-03 07:59:59','XZCBTC','4h','0.001418000000000','0.001458000000000','0.001467500000000','0.001508896332863','1.0349083215796897','1.034908321579690','test'),('2019-01-05 03:59:59','2019-01-05 07:59:59','XZCBTC','4h','0.001428000000000','0.001410000000000','0.001477849083216','0.001459220733428','1.0349083215796568','1.034908321579657','test'),('2019-01-08 11:59:59','2019-01-09 15:59:59','XZCBTC','4h','0.001448000000000','0.001420000000000','0.001477849083216','0.001449271890999','1.0206140077458563','1.020614007745856','test'),('2019-01-17 15:59:59','2019-01-20 15:59:59','XZCBTC','4h','0.001411000000000','0.001424000000000','0.001477849083216','0.001491464985471','1.047377096538625','1.047377096538625','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','XZCBTC','4h','0.001376000000000','0.001360000000000','0.001477849083216','0.001460664791551','1.0740182290813953','1.074018229081395','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','XZCBTC','4h','0.001348000000000','0.001350000000000','0.001477849083216','0.001480041737642','1.096327213068249','1.096327213068249','test'),('2019-02-22 15:59:59','2019-02-22 23:59:59','XZCBTC','4h','0.001397000000000','0.001383000000000','0.001477849083216','0.001463038856183','1.057873359496063','1.057873359496063','test'),('2019-02-23 03:59:59','2019-02-23 07:59:59','XZCBTC','4h','0.001386000000000','0.001400000000000','0.001477849083216','0.001492776851733','1.0662691798095236','1.066269179809524','test'),('2019-02-24 03:59:59','2019-02-24 07:59:59','XZCBTC','4h','0.001395000000000','0.001374000000000','0.001477849083216','0.001455601892716','1.0593900238107525','1.059390023810753','test'),('2019-02-24 23:59:59','2019-02-25 07:59:59','XZCBTC','4h','0.001390000000000','0.001390000000000','0.001477849083216','0.001477849083216','1.0632007792920863','1.063200779292086','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','XZCBTC','4h','0.001644000000000','0.001661000000000','0.001477849083216','0.001493130977629','0.898934965459854','0.898934965459854','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','XZCBTC','4h','0.001813000000000','0.001699000000000','0.001477849083216','0.001384923106665','0.8151401451825703','0.815140145182570','test'),('2019-04-05 15:59:59','2019-04-05 19:59:59','XZCBTC','4h','0.001749000000000','0.001748000000000','0.001477849083216','0.001477004115187','0.8449680292830188','0.844968029283019','test'),('2019-04-07 19:59:59','2019-04-07 23:59:59','XZCBTC','4h','0.001755000000000','0.001735000000000','0.001477849083216','0.001461007498222','0.8420792496957265','0.842079249695726','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','XZCBTC','4h','0.001606000000000','0.001600000000000','0.001477849083216','0.001472327853764','0.9202049086027396','0.920204908602740','test'),('2019-05-16 23:59:59','2019-05-17 03:59:59','XZCBTC','4h','0.001047000000000','0.000982000000000','0.001477849083216','0.001386101050352','1.41150819791404','1.411508197914040','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','XZCBTC','4h','0.000984000000000','0.000933000000000','0.001477849083216','0.001401253246586','1.5018791496097559','1.501879149609756','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','XZCBTC','4h','0.000907000000000','0.000880000000000','0.001477849083216','0.001433855780849','1.6293815691466371','1.629381569146637','test'),('2019-06-06 19:59:59','2019-06-06 23:59:59','XZCBTC','4h','0.000875000000000','0.000881000000000','0.001477849083216','0.001487982905501','1.6889703808182857','1.688970380818286','test'),('2019-07-17 19:59:59','2019-07-17 23:59:59','XZCBTC','4h','0.000954000000000','0.000937000000000','0.001477849083216','0.001451514246303','1.5491080536855344','1.549108053685534','test'),('2019-07-20 03:59:59','2019-07-20 07:59:59','XZCBTC','4h','0.000928000000000','0.000914000000000','0.001477849083216','0.001455553946185','1.5925097879482757','1.592509787948276','test'),('2019-07-20 19:59:59','2019-07-20 23:59:59','XZCBTC','4h','0.000932000000000','0.000915000000000','0.001477849083216','0.001450892608522','1.5856749819914162','1.585674981991416','test'),('2019-07-22 03:59:59','2019-07-22 15:59:59','XZCBTC','4h','0.000935000000000','0.000934000000000','0.001477849083216','0.001476268495961','1.5805872547764706','1.580587254776471','test'),('2019-08-22 03:59:59','2019-08-22 07:59:59','XZCBTC','4h','0.000680000000000','0.000673000000000','0.001477849083216','0.001462635930889','2.173307475317647','2.173307475317647','test'),('2019-08-24 03:59:59','2019-08-24 07:59:59','XZCBTC','4h','0.000673000000000','0.000670000000000','0.001477849083216','0.001471261345847','2.19591245648737','2.195912456487370','test'),('2019-09-10 03:59:59','2019-09-11 07:59:59','XZCBTC','4h','0.000602000000000','0.000545000000000','0.001477849083216','0.001337919851084','2.4548988093289035','2.454898809328903','test'),('2019-09-16 03:59:59','2019-09-16 07:59:59','XZCBTC','4h','0.000539000000000','0.000518000000000','0.001477849083216','0.001420270547506','2.741835033795918','2.741835033795918','test'),('2019-09-18 03:59:59','2019-09-18 07:59:59','XZCBTC','4h','0.000528700000000','0.000531800000000','0.001477849083216','0.001486514360610','2.795250772112729','2.795250772112729','test'),('2019-09-20 03:59:59','2019-09-20 07:59:59','XZCBTC','4h','0.000531100000000','0.000531400000000','0.001477849083216','0.001478683868991','2.782619249135756','2.782619249135756','test'),('2019-09-21 03:59:59','2019-09-22 15:59:59','XZCBTC','4h','0.000548000000000','0.000535200000000','0.001477849083216','0.001443329980542','2.696804896379562','2.696804896379562','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','XZCBTC','4h','0.000537600000000','0.000532500000000','0.001477849083216','0.001463829309547','2.7489752291964287','2.748975229196429','test'),('2019-09-26 11:59:59','2019-09-26 19:59:59','XZCBTC','4h','0.000532300000000','0.000551400000000','0.001477849083216','0.001530877295670','2.7763462017959797','2.776346201795980','test'),('2019-10-10 15:59:59','2019-10-10 19:59:59','XZCBTC','4h','0.000654400000000','0.000642600000000','0.001477849083216','0.001451200826520','2.2583268386552566','2.258326838655257','test'),('2019-10-10 23:59:59','2019-10-11 07:59:59','XZCBTC','4h','0.000690200000000','0.000657700000000','0.001477849083216','0.001408260420213','2.1411896308548246','2.141189630854825','test'),('2019-10-13 19:59:59','2019-10-14 03:59:59','XZCBTC','4h','0.000665000000000','0.000657900000000','0.001477849083216','0.001462070544132','2.2223294484451124','2.222329448445112','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','XZCBTC','4h','0.000654700000000','0.000627000000000','0.001477849083216','0.001415322094358','2.2572920165205437','2.257292016520544','test'),('2019-11-07 23:59:59','2019-11-08 03:59:59','XZCBTC','4h','0.000542700000000','0.000540200000000','0.001477849083216','0.001471041228585','2.7231418522498614','2.723141852249861','test'),('2019-11-09 15:59:59','2019-11-11 11:59:59','XZCBTC','4h','0.000542700000000','0.000540900000000','0.001477849083216','0.001472947427882','2.7231418522498614','2.723141852249861','test'),('2019-11-11 19:59:59','2019-11-11 23:59:59','XZCBTC','4h','0.000543200000000','0.000543400000000','0.001477849083216','0.001478393210272','2.7206352783799703','2.720635278379970','test'),('2019-11-13 15:59:59','2019-11-13 19:59:59','XZCBTC','4h','0.000543800000000','0.000541500000000','0.001477849083216','0.001471598526226','2.717633474100772','2.717633474100772','test'),('2019-11-19 03:59:59','2019-11-19 07:59:59','XZCBTC','4h','0.000538300000000','0.000528400000000','0.001477849083216','0.001450669618375','2.745400488976407','2.745400488976407','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','XZCBTC','4h','0.000414100000000','0.000413700000000','0.001477849083216','0.001476421554519','3.568821741646945','3.568821741646945','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  5:00:05
