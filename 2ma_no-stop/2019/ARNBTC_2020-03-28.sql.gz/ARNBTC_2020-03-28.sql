-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-02 19:59:59','ARNBTC','4h','0.000073200000000','0.000073020000000','0.001467500000000','0.001463891393443','20.047814207650273','20.047814207650273','test'),('2019-01-03 03:59:59','2019-01-03 07:59:59','ARNBTC','4h','0.000072450000000','0.000072230000000','0.001467500000000','0.001463043823326','20.25534851621808','20.255348516218081','test'),('2019-01-04 19:59:59','2019-01-04 23:59:59','ARNBTC','4h','0.000072650000000','0.000073760000000','0.001467500000000','0.001489921541638','20.19958706125258','20.199587061252579','test'),('2019-01-15 15:59:59','2019-01-15 23:59:59','ARNBTC','4h','0.000073480000000','0.000070600000000','0.001471089189602','0.001413430821801','20.020266597737482','20.020266597737482','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','ARNBTC','4h','0.000080640000000','0.000080260000000','0.001471089189602','0.001464156973679','18.242673482167657','18.242673482167657','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','ARNBTC','4h','0.000080090000000','0.000075290000000','0.001471089189602','0.001382923025161','18.367950925234112','18.367950925234112','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','ARNBTC','4h','0.000078460000000','0.000077360000000','0.001471089189602','0.001450464691660','18.74954358401733','18.749543584017331','test'),('2019-01-30 23:59:59','2019-01-31 11:59:59','ARNBTC','4h','0.000080140000000','0.000078880000000','0.001471089189602','0.001447960010928','18.356491010756177','18.356491010756177','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','ARNBTC','4h','0.000078980000000','0.000077230000000','0.001471089189602','0.001438493518776','18.626097614611293','18.626097614611293','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','ARNBTC','4h','0.000076780000000','0.000076020000000','0.001471089189602','0.001456527744120','19.159796686663196','19.159796686663196','test'),('2019-02-10 15:59:59','2019-02-12 07:59:59','ARNBTC','4h','0.000076430000000','0.000076170000000','0.001471089189602','0.001466084830197','19.247536171686512','19.247536171686512','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','ARNBTC','4h','0.000076810000000','0.000076030000000','0.001471089189602','0.001456150385177','19.152313365473244','19.152313365473244','test'),('2019-02-13 03:59:59','2019-02-13 15:59:59','ARNBTC','4h','0.000077710000000','0.000077430000000','0.001471089189602','0.001465788649477','18.93050044527088','18.930500445270880','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','ARNBTC','4h','0.000078020000000','0.000075870000000','0.001471089189602','0.001430550330878','18.855283127428862','18.855283127428862','test'),('2019-02-18 11:59:59','2019-02-19 03:59:59','ARNBTC','4h','0.000083380000000','0.000075810000000','0.001471089189602','0.001337530240630','17.643190088774286','17.643190088774286','test'),('2019-02-20 15:59:59','2019-02-20 19:59:59','ARNBTC','4h','0.000077190000000','0.000076210000000','0.001471089189602','0.001452412322057','19.05802810729369','19.058028107293691','test'),('2019-02-22 15:59:59','2019-02-22 19:59:59','ARNBTC','4h','0.000076920000000','0.000076480000000','0.001471089189602','0.001462674222839','19.124924461804472','19.124924461804472','test'),('2019-02-26 07:59:59','2019-02-27 15:59:59','ARNBTC','4h','0.000077940000000','0.000076170000000','0.001471089189602','0.001437681082525','18.87463676676931','18.874636766769310','test'),('2019-03-01 11:59:59','2019-03-02 07:59:59','ARNBTC','4h','0.000076310000000','0.000076110000000','0.001471089189602','0.001467233628890','19.277803559192765','19.277803559192765','test'),('2019-03-05 03:59:59','2019-03-05 07:59:59','ARNBTC','4h','0.000076970000000','0.000080280000000','0.001471089189602','0.001534351567380','19.112500839314016','19.112500839314016','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','ARNBTC','4h','0.000102760000000','0.000100770000000','0.001471089189602','0.001442600794436','14.315776465570261','14.315776465570261','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','ARNBTC','4h','0.000103890000000','0.000104360000000','0.001471089189602','0.001477744420318','14.160065353758784','14.160065353758784','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','ARNBTC','4h','0.000102810000000','0.000100190000000','0.001471089189602','0.001433600096355','14.308814216535357','14.308814216535357','test'),('2019-03-26 03:59:59','2019-03-27 11:59:59','ARNBTC','4h','0.000107650000000','0.000114070000000','0.001471089189602','0.001558821587161','13.6654824858523','13.665482485852300','test'),('2019-04-17 11:59:59','2019-04-17 19:59:59','ARNBTC','4h','0.000094270000000','0.000091330000000','0.001471089189602','0.001425210307482','15.605061945496976','15.605061945496976','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','ARNBTC','4h','0.000091670000000','0.000094870000000','0.001471089189602','0.001522441708493','16.047662153398058','16.047662153398058','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','ARNBTC','4h','0.000055010000000','0.000053580000000','0.001471089189602','0.001432847823648','26.742213953862937','26.742213953862937','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','ARNBTC','4h','0.000055150000000','0.000054030000000','0.001471089189602','0.001441213942234','26.674328007289212','26.674328007289212','test'),('2019-06-08 07:59:59','2019-06-08 15:59:59','ARNBTC','4h','0.000063050000000','0.000063110000000','0.001471089189602','0.001472489115873','23.332104513909595','23.332104513909595','test'),('2019-06-12 11:59:59','2019-06-13 15:59:59','ARNBTC','4h','0.000063840000000','0.000062720000000','0.001471089189602','0.001445280607328','23.043377030106516','23.043377030106516','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','ARNBTC','4h','0.000041870000000','0.000039290000000','0.001471089189602','0.001380441706698','35.1346832959637','35.134683295963697','test'),('2019-07-23 19:59:59','2019-07-24 03:59:59','ARNBTC','4h','0.000027170000000','0.000027990000000','0.001471089189602','0.001515487170297','54.14387889591461','54.143878895914611','test'),('2019-07-28 23:59:59','2019-07-29 03:59:59','ARNBTC','4h','0.000027870000000','0.000028080000000','0.001471089189602','0.001482173822893','52.783968051740224','52.783968051740224','test'),('2019-07-29 19:59:59','2019-07-29 23:59:59','ARNBTC','4h','0.000027560000000','0.000027560000000','0.001471089189602','0.001471089189602','53.377691930406385','53.377691930406385','test'),('2019-07-30 11:59:59','2019-07-30 15:59:59','ARNBTC','4h','0.000027470000000','0.000027470000000','0.001471089189602','0.001471089189602','53.55257333825992','53.552573338259919','test'),('2019-08-21 19:59:59','2019-08-26 03:59:59','ARNBTC','4h','0.000020190000000','0.000020440000000','0.001471089189602','0.001489304756586','72.86226793472015','72.862267934720151','test'),('2019-08-30 03:59:59','2019-08-30 07:59:59','ARNBTC','4h','0.000020730000000','0.000020150000000','0.001471089189602','0.001429929916569','70.96426384958997','70.964263849589969','test'),('2019-08-30 11:59:59','2019-08-30 15:59:59','ARNBTC','4h','0.000020380000000','0.000020420000000','0.001471089189602','0.001473976508914','72.18298280677134','72.182982806771335','test'),('2019-08-31 23:59:59','2019-09-01 23:59:59','ARNBTC','4h','0.000021570000000','0.000020360000000','0.001471089189602','0.001388566337520','68.2007042003709','68.200704200370893','test'),('2019-09-10 15:59:59','2019-09-10 19:59:59','ARNBTC','4h','0.000018050000000','0.000018800000000','0.001471089189602','0.001532214779198','81.50078612753461','81.500786127534610','test'),('2019-09-15 11:59:59','2019-09-15 15:59:59','ARNBTC','4h','0.000017680000000','0.000017850000000','0.001471089189602','0.001485234277964','83.20640212680995','83.206402126809948','test'),('2019-09-17 03:59:59','2019-09-17 07:59:59','ARNBTC','4h','0.000017760000000','0.000017780000000','0.001471089189602','0.001472745821572','82.83159851362613','82.831598513626133','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','ARNBTC','4h','0.000019900000000','0.000018970000000','0.001471089189602','0.001402339795314','73.92407987949748','73.924079879497484','test'),('2019-09-26 19:59:59','2019-09-26 23:59:59','ARNBTC','4h','0.000019670000000','0.000020030000000','0.001471089189602','0.001498013038522','74.78846922226741','74.788469222267409','test'),('2019-10-11 23:59:59','2019-10-12 03:59:59','ARNBTC','4h','0.000024010000000','0.000023610000000','0.001471089189602','0.001446581248084','61.269853794335695','61.269853794335695','test'),('2019-10-13 11:59:59','2019-10-13 15:59:59','ARNBTC','4h','0.000024080000000','0.000023340000000','0.001471089189602','0.001425881299224','61.09174375423588','61.091743754235878','test'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ARNBTC','4h','0.000023940000000','0.000023860000000','0.001471089189602','0.001466173269169','61.44900541361737','61.449005413617371','test'),('2019-10-21 23:59:59','2019-10-23 03:59:59','ARNBTC','4h','0.000023040000000','0.000022380000000','0.001471089189602','0.001428948613858','63.849357187586804','63.849357187586804','test'),('2019-10-23 07:59:59','2019-10-23 11:59:59','ARNBTC','4h','0.000022960000000','0.000022620000000','0.001471089189602','0.001449304767805','64.07182881541812','64.071828815418115','test'),('2019-10-24 11:59:59','2019-10-25 15:59:59','ARNBTC','4h','0.000023340000000','0.000021590000000','0.001471089189602','0.001360789014718','63.02867136255355','63.028671362553553','test'),('2019-11-03 15:59:59','2019-11-03 19:59:59','ARNBTC','4h','0.000020670000000','0.000020600000000','0.001471089189602','0.001466107271688','71.17025590720851','71.170255907208514','test'),('2019-11-07 15:59:59','2019-11-08 07:59:59','ARNBTC','4h','0.000020590000000','0.000020240000000','0.001471089189602','0.001446082816782','71.44677948528411','71.446779485284111','test'),('2019-11-09 23:59:59','2019-11-10 03:59:59','ARNBTC','4h','0.000020340000000','0.000020310000000','0.001471089189602','0.001468919441535','72.32493557531957','72.324935575319572','test'),('2019-11-10 11:59:59','2019-11-10 15:59:59','ARNBTC','4h','0.000020360000000','0.000020340000000','0.001471089189602','0.001469644111813','72.25388946964635','72.253889469646353','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','ARNBTC','4h','0.000020350000000','0.000020350000000','0.001471089189602','0.001471089189602','72.28939506643735','72.289395066437351','test'),('2019-11-19 19:59:59','2019-11-19 23:59:59','ARNBTC','4h','0.000021170000000','0.000020970000000','0.001471089189602','0.001457191322908','69.48933347198867','69.489333471988672','test'),('2019-11-26 03:59:59','2019-11-26 07:59:59','ARNBTC','4h','0.000020630000000','0.000020570000000','0.001471089189602','0.001466810694625','71.30824961715948','71.308249617159476','test'),('2019-11-30 19:59:59','2019-11-30 23:59:59','ARNBTC','4h','0.000021170000000','0.000021270000000','0.001471089189602','0.001478038122949','69.48933347198867','69.489333471988672','test'),('2019-12-04 11:59:59','2019-12-04 15:59:59','ARNBTC','4h','0.000021210000000','0.000020810000000','0.001471089189602','0.001443345876267','69.35828333814239','69.358283338142385','test'),('2019-12-05 11:59:59','2019-12-05 15:59:59','ARNBTC','4h','0.000021430000000','0.000021370000000','0.001471089189602','0.001466970414456','68.64625243126459','68.646252431264585','test'),('2019-12-07 15:59:59','2019-12-10 03:59:59','ARNBTC','4h','0.000021700000000','0.000020670000000','0.001471089189602','0.001401263297192','67.79212855308757','67.792128553087565','test'),('2019-12-10 07:59:59','2019-12-10 11:59:59','ARNBTC','4h','0.000021670000000','0.000020430000000','0.001471089189602','0.001386910574230','67.88598013853253','67.885980138532531','test'),('2019-12-12 07:59:59','2019-12-12 15:59:59','ARNBTC','4h','0.000021550000000','0.000019770000000','0.001471089189602','0.001349579270461','68.2639995174942','68.263999517494199','test'),('2019-12-27 15:59:59','2019-12-27 19:59:59','ARNBTC','4h','0.000018670000000','0.000018610000000','0.001471089189602','0.001466361532860','78.79427903599357','78.794279035993569','test'),('2019-12-27 23:59:59','2019-12-28 11:59:59','ARNBTC','4h','0.000018760000000','0.000018650000000','0.001471089189602','0.001462463400111','78.41626810245202','78.416268102452023','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:48:07
