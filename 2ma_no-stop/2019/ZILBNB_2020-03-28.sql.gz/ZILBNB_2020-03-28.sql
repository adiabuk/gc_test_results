-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-15 15:59:59','2019-01-18 07:59:59','ZILBNB','4h','0.003470000000000','0.003438000000000','0.711908500000000','0.705343349567723','205.16095100864555','205.160951008645554','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','ZILBNB','4h','0.003498000000000','0.003390000000000','0.711908500000000','0.689928477701544','203.51872498570614','203.518724985706143','test'),('2019-01-22 15:59:59','2019-01-23 07:59:59','ZILBNB','4h','0.003450000000000','0.003393000000000','0.711908500000000','0.700146533478261','206.35028985507248','206.350289855072475','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','ZILBNB','4h','0.003455000000000','0.003400000000000','0.711908500000000','0.700575658465991','206.05166425470333','206.051664254703326','test'),('2019-01-24 19:59:59','2019-01-24 23:59:59','ZILBNB','4h','0.003436000000000','0.003403000000000','0.711908500000000','0.705071194848661','207.19106519208384','207.191065192083840','test'),('2019-01-28 23:59:59','2019-01-29 03:59:59','ZILBNB','4h','0.003397000000000','0.003228000000000','0.711908500000000','0.676491209302326','209.56976744186048','209.569767441860478','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ZILBNB','4h','0.003344000000000','0.003335000000000','0.711908500000000','0.709992478319378','212.89129784688996','212.891297846889955','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','ZILBNB','4h','0.001851000000000','0.001842000000000','0.711908500000000','0.708447032414911','384.60750945434904','384.607509454349042','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','ZILBNB','4h','0.001249000000000','0.001240000000000','0.711908500000000','0.706778654923939','569.9827862289833','569.982786228983286','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','ZILBNB','4h','0.001195000000000','0.001179000000000','0.711908500000000','0.702376670711297','595.7393305439331','595.739330543933079','test'),('2019-04-10 03:59:59','2019-04-10 11:59:59','ZILBNB','4h','0.001274000000000','0.001245000000000','0.711908500000000','0.695703361459969','558.7978806907379','558.797880690737884','test'),('2019-05-08 07:59:59','2019-05-08 19:59:59','ZILBNB','4h','0.000780000000000','0.000776000000000','0.711908500000000','0.708257687179487','912.7032051282052','912.703205128205241','test'),('2019-05-09 19:59:59','2019-05-10 03:59:59','ZILBNB','4h','0.000769000000000','0.000801000000000','0.711908500000000','0.741532780884265','925.75877763329','925.758777633290038','test'),('2019-05-11 19:59:59','2019-05-11 23:59:59','ZILBNB','4h','0.000776000000000','0.000780000000000','0.711908500000000','0.715578131443299','917.4078608247423','917.407860824742329','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','ZILBNB','4h','0.000786000000000','0.000756000000000','0.711908500000000','0.684736419847328','905.7360050890586','905.736005089058608','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','ZILBNB','4h','0.000721000000000','0.000644000000000','0.711908500000000','0.635879436893204','987.3904299583912','987.390429958391223','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','ZILBNB','4h','0.000715000000000','0.000702000000000','0.711908500000000','0.698964709090909','995.6762237762238','995.676223776223765','test'),('2019-05-23 11:59:59','2019-05-23 15:59:59','ZILBNB','4h','0.000704000000000','0.000658000000000','0.711908500000000','0.665391751420455','1011.2336647727274','1011.233664772727366','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','ZILBNB','4h','0.000651000000000','0.000634000000000','0.711908500000000','0.693317955453149','1093.5614439324117','1093.561443932411748','test'),('2019-05-29 15:59:59','2019-05-29 19:59:59','ZILBNB','4h','0.000642000000000','0.000634000000000','0.711908500000000','0.703037366043614','1108.8917445482866','1108.891744548286624','test'),('2019-05-30 11:59:59','2019-05-30 19:59:59','ZILBNB','4h','0.000662000000000','0.000629000000000','0.711908500000000','0.676420614048338','1075.3904833836857','1075.390483383685705','test'),('2019-06-02 15:59:59','2019-06-09 23:59:59','ZILBNB','4h','0.000641000000000','0.000727000000000','0.711908500000000','0.807421964898596','1110.6216848673948','1110.621684867394833','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','ZILBNB','4h','0.000727000000000','0.000713000000000','0.711908500000000','0.698199120357634','979.2414030261349','979.241403026134890','test'),('2019-06-16 15:59:59','2019-06-18 03:59:59','ZILBNB','4h','0.000706000000000','0.000721000000000','0.711908500000000','0.727034034702550','1008.3689801699717','1008.368980169971678','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','ZILBNB','4h','0.000518000000000','0.000520000000000','0.711908500000000','0.714657181467181','1374.3407335907336','1374.340733590733635','test'),('2019-07-09 23:59:59','2019-07-10 03:59:59','ZILBNB','4h','0.000519000000000','0.000516000000000','0.711908500000000','0.707793421965318','1371.6926782273604','1371.692678227360375','test'),('2019-07-30 03:59:59','2019-07-30 11:59:59','ZILBNB','4h','0.000387000000000','0.000380000000000','0.711908500000000','0.699031602067184','1839.5568475452199','1839.556847545219853','test'),('2019-08-23 23:59:59','2019-08-28 19:59:59','ZILBNB','4h','0.000280900000000','0.000302500000000','0.711908500000000','0.766651197045212','2534.3841224635103','2534.384122463510266','test'),('2019-09-03 19:59:59','2019-09-05 15:59:59','ZILBNB','4h','0.000317800000000','0.000313300000000','0.711908500000000','0.701827983165513','2240.114852108244','2240.114852108244122','test'),('2019-09-08 19:59:59','2019-09-08 23:59:59','ZILBNB','4h','0.000311400000000','0.000306900000000','0.711908500000000','0.701620804913295','2286.1544637122674','2286.154463712267443','test'),('2019-09-09 19:59:59','2019-09-10 11:59:59','ZILBNB','4h','0.000311500000000','0.000311200000000','0.711908500000000','0.711222873836276','2285.4205457463886','2285.420545746388598','test'),('2019-09-21 15:59:59','2019-09-21 19:59:59','ZILBNB','4h','0.000332700000000','0.000331900000000','0.711908500000000','0.710196667117523','2139.791103095882','2139.791103095882136','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','ZILBNB','4h','0.000336900000000','0.000326800000000','0.711908500000000','0.690566036806174','2113.115167705551','2113.115167705550903','test'),('2019-09-23 07:59:59','2019-09-23 11:59:59','ZILBNB','4h','0.000331900000000','0.000332800000000','0.711908500000000','0.713838953901778','2144.9487797529378','2144.948779752937753','test'),('2019-09-28 19:59:59','2019-09-29 07:59:59','ZILBNB','4h','0.000329300000000','0.000323500000000','0.711908500000000','0.699369571059824','2161.8843000303677','2161.884300030367740','test'),('2019-09-29 19:59:59','2019-09-29 23:59:59','ZILBNB','4h','0.000327100000000','0.000329300000000','0.711908500000000','0.716696634209722','2176.4246407826354','2176.424640782635379','test'),('2019-10-03 11:59:59','2019-10-03 15:59:59','ZILBNB','4h','0.000325100000000','0.000322800000000','0.711908500000000','0.706871928022147','2189.813903414334','2189.813903414334163','test'),('2019-10-11 19:59:59','2019-10-12 07:59:59','ZILBNB','4h','0.000351400000000','0.000348100000000','0.711908500000000','0.705222962009107','2025.9206033010817','2025.920603301081655','test'),('2019-10-27 19:59:59','2019-10-28 03:59:59','ZILBNB','4h','0.000295100000000','0.000286300000000','0.711908500000000','0.690679103863097','2412.4313791934937','2412.431379193493740','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','ZILBNB','4h','0.000292100000000','0.000292100000000','0.711908500000000','0.711908500000000','2437.208147894557','2437.208147894556987','test'),('2019-11-01 03:59:59','2019-11-03 07:59:59','ZILBNB','4h','0.000307900000000','0.000293500000000','0.711908500000000','0.678613656219552','2312.141929197792','2312.141929197791796','test'),('2019-11-04 11:59:59','2019-11-04 23:59:59','ZILBNB','4h','0.000293800000000','0.000293900000000','0.711908500000000','0.712150810585432','2423.1058543226686','2423.105854322668620','test'),('2019-11-09 11:59:59','2019-11-09 15:59:59','ZILBNB','4h','0.000303500000000','0.000299800000000','0.711908500000000','0.703229549588138','2345.662273476112','2345.662273476112205','test'),('2019-11-09 19:59:59','2019-11-10 03:59:59','ZILBNB','4h','0.000305100000000','0.000296900000000','0.711908500000000','0.692774938216978','2333.361193051459','2333.361193051458940','test'),('2019-11-15 07:59:59','2019-11-19 11:59:59','ZILBNB','4h','0.000295000000000','0.000310500000000','0.711908500000000','0.749313861864407','2413.249152542373','2413.249152542372940','test'),('2019-11-21 23:59:59','2019-11-22 03:59:59','ZILBNB','4h','0.000313900000000','0.000309400000000','0.711908500000000','0.701702739407455','2267.946798343422','2267.946798343421960','test'),('2019-11-22 19:59:59','2019-11-22 23:59:59','ZILBNB','4h','0.000313900000000','0.000306700000000','0.711908500000000','0.695579283051927','2267.946798343422','2267.946798343421960','test'),('2019-11-25 11:59:59','2019-11-25 15:59:59','ZILBNB','4h','0.000318800000000','0.000316100000000','0.711908500000000','0.705879162013802','2233.0881430363866','2233.088143036386555','test'),('2019-12-10 23:59:59','2019-12-11 03:59:59','ZILBNB','4h','0.000376800000000','0.000374300000000','0.711908500000000','0.707185115578556','1889.3537685774947','1889.353768577494748','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','ZILBNB','4h','0.000374400000000','0.000367400000000','0.711908500000000','0.698598244925214','1901.465010683761','1901.465010683760966','test'),('2019-12-18 19:59:59','2019-12-19 07:59:59','ZILBNB','4h','0.000374800000000','0.000375700000000','0.711908500000000','0.713617992129136','1899.4356990394879','1899.435699039487872','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:26:43
