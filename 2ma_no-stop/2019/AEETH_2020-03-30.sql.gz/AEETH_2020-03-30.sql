-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-11 07:59:59','AEETH','4h','0.002845000000000','0.002840000000000','0.072144500000000','0.072017708260105','25.35834797891037','25.358347978910370','test'),('2019-01-15 03:59:59','2019-01-27 07:59:59','AEETH','4h','0.002940000000000','0.003500000000000','0.072144500000000','0.085886309523810','24.538945578231292','24.538945578231292','test'),('2019-01-28 15:59:59','2019-01-28 19:59:59','AEETH','4h','0.003486000000000','0.003491000000000','0.075548254445979','0.075656613961822','21.671903168668603','21.671903168668603','test'),('2019-01-29 07:59:59','2019-01-29 11:59:59','AEETH','4h','0.003490000000000','0.003515000000000','0.075575344324940','0.076116714986293','21.654826454137396','21.654826454137396','test'),('2019-02-01 07:59:59','2019-02-01 11:59:59','AEETH','4h','0.003503000000000','0.003453000000000','0.075710686990278','0.074630032023246','21.613099340644517','21.613099340644517','test'),('2019-02-02 07:59:59','2019-02-02 11:59:59','AEETH','4h','0.003482000000000','0.003470000000000','0.075710686990278','0.075449765610645','21.743448302779438','21.743448302779438','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','AEETH','4h','0.003483000000000','0.003447000000000','0.075710686990278','0.074928147589862','21.737205567119723','21.737205567119723','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','AEETH','4h','0.003473000000000','0.003464000000000','0.075710686990278','0.075514488837985','21.799794699187444','21.799794699187444','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','AEETH','4h','0.003474000000000','0.003485000000000','0.075710686990278','0.075950415705561','21.79351957117962','21.793519571179619','test'),('2019-02-16 03:59:59','2019-02-16 11:59:59','AEETH','4h','0.003340000000000','0.003339000000000','0.075710686990278','0.075688019119922','22.667870356370656','22.667870356370656','test'),('2019-02-23 07:59:59','2019-02-23 11:59:59','AEETH','4h','0.003116000000000','0.003034000000000','0.075710686990278','0.073718300490534','24.29739633834339','24.297396338343390','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','AEETH','4h','0.003174000000000','0.003090000000000','0.075710686990278','0.073707001512274','23.853398547661623','23.853398547661623','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','AEETH','4h','0.003091000000000','0.003122000000000','0.075710686990278','0.076469998312406','24.49391361704238','24.493913617042381','test'),('2019-02-26 11:59:59','2019-03-05 15:59:59','AEETH','4h','0.003083000000000','0.003274000000000','0.075710686990278','0.080401164192725','24.557472264118715','24.557472264118715','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','AEETH','4h','0.003240000000000','0.003207000000000','0.075710686990278','0.074939559622784','23.367495984653704','23.367495984653704','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','AEETH','4h','0.003213000000000','0.003191000000000','0.075710686990278','0.075192282037341','23.563861497129782','23.563861497129782','test'),('2019-03-09 23:59:59','2019-03-10 11:59:59','AEETH','4h','0.003217000000000','0.003226000000000','0.075710686990278','0.075922498051177','23.534562322125584','23.534562322125584','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','AEETH','4h','0.003226000000000','0.003187000000000','0.075710686990278','0.074795399701803','23.468904832696218','23.468904832696218','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','AEETH','4h','0.003260000000000','0.003309000000000','0.075710686990278','0.076848669708844','23.22413711358221','23.224137113582209','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','AEETH','4h','0.003323000000000','0.003299000000000','0.075710686990278','0.075163874926550','22.78383598864821','22.783835988648210','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','AEETH','4h','0.003338000000000','0.003303000000000','0.075710686990278','0.074916836168031','22.68145206419353','22.681452064193529','test'),('2019-03-27 11:59:59','2019-03-27 19:59:59','AEETH','4h','0.003443000000000','0.003452000000000','0.075710686990278','0.075908594682091','21.989743534788847','21.989743534788847','test'),('2019-03-28 15:59:59','2019-03-29 03:59:59','AEETH','4h','0.003429000000000','0.003405000000000','0.075710686990278','0.075180778419917','22.07952376502712','22.079523765027119','test'),('2019-03-30 11:59:59','2019-04-02 19:59:59','AEETH','4h','0.003454000000000','0.003524000000000','0.075710686990278','0.077245066865588','21.919712504423277','21.919712504423277','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','AEETH','4h','0.003411000000000','0.003287000000000','0.075710686990278','0.072958378228392','22.196038402309586','22.196038402309586','test'),('2019-05-02 23:59:59','2019-05-03 03:59:59','AEETH','4h','0.003018000000000','0.002963000000000','0.075710686990278','0.074330936233331','25.08637739903181','25.086377399031811','test'),('2019-05-06 07:59:59','2019-05-06 15:59:59','AEETH','4h','0.002991000000000','0.002922000000000','0.075710686990278','0.073964101432829','25.312834165923768','25.312834165923768','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','AEETH','4h','0.002305000000000','0.002303000000000','0.075710686990278','0.075644994420221','32.84628502832017','32.846285028320167','test'),('2019-05-24 07:59:59','2019-05-24 11:59:59','AEETH','4h','0.002285000000000','0.002246000000000','0.075710686990278','0.074418469575564','33.13377986445426','33.133779864454262','test'),('2019-05-25 03:59:59','2019-05-25 11:59:59','AEETH','4h','0.002252000000000','0.002388000000000','0.075710686990278','0.080282913202835','33.61931038644671','33.619310386446713','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','AEETH','4h','0.002290000000000','0.002186000000000','0.075710686990278','0.072272297712117','33.06143536693362','33.061435366933623','test'),('2019-06-09 19:59:59','2019-06-11 11:59:59','AEETH','4h','0.002084000000000','0.002082000000000','0.075710686990278','0.075638027981650','36.329504313952974','36.329504313952974','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','AEETH','4h','0.002064000000000','0.002049000000000','0.075710686990278','0.075160463974360','36.681534394514536','36.681534394514536','test'),('2019-06-24 03:59:59','2019-06-24 11:59:59','AEETH','4h','0.002014000000000','0.001909000000000','0.075710686990278','0.071763506188898','37.59219810838033','37.592198108380330','test'),('2019-07-22 15:59:59','2019-07-23 07:59:59','AEETH','4h','0.001418000000000','0.001421000000000','0.075710686990278','0.075870864748367','53.392586029815234','53.392586029815234','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','AEETH','4h','0.001424000000000','0.001427000000000','0.075710686990278','0.075870189842083','53.167617268453654','53.167617268453654','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','AEETH','4h','0.001416000000000','0.001401000000000','0.075710686990278','0.074908667000974','53.46799928691949','53.467999286919493','test'),('2019-07-27 11:59:59','2019-07-27 23:59:59','AEETH','4h','0.001435000000000','0.001421000000000','0.075710686990278','0.074972046141592','52.76006062040278','52.760060620402783','test'),('2019-07-28 15:59:59','2019-07-28 23:59:59','AEETH','4h','0.001423000000000','0.001409000000000','0.075710686990278','0.074965817265848','53.20498031642867','53.204980316428667','test'),('2019-08-19 23:59:59','2019-08-20 03:59:59','AEETH','4h','0.001279000000000','0.001243000000000','0.075710686990278','0.073579659053101','59.19522047715246','59.195220477152461','test'),('2019-08-22 15:59:59','2019-08-22 19:59:59','AEETH','4h','0.001259000000000','0.001251000000000','0.075710686990278','0.075229602402572','60.13557346328674','60.135573463286740','test'),('2019-08-24 03:59:59','2019-08-27 03:59:59','AEETH','4h','0.001272000000000','0.001257000000000','0.075710686990278','0.074817872285204','59.52098033826887','59.520980338268870','test'),('2019-08-27 07:59:59','2019-08-27 11:59:59','AEETH','4h','0.001278000000000','0.001273000000000','0.075710686990278','0.075414479294698','59.24153911602347','59.241539116023468','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','AEETH','4h','0.001291000000000','0.001260000000000','0.075710686990278','0.073892692182611','58.64499379572269','58.644993795722691','test'),('2019-10-06 07:59:59','2019-10-09 15:59:59','AEETH','4h','0.000940000000000','0.000924000000000','0.075710686990278','0.074421994445763','80.54328403221064','80.543284032210636','test'),('2019-10-10 19:59:59','2019-10-11 03:59:59','AEETH','4h','0.000966000000000','0.000927000000000','0.075710686990278','0.072654044347813','78.3754523708882','78.375452370888198','test'),('2019-10-11 15:59:59','2019-10-12 11:59:59','AEETH','4h','0.000957000000000','0.000954000000000','0.075710686990278','0.075473349413506','79.11252559067712','79.112525590677123','test'),('2019-10-30 19:59:59','2019-10-31 03:59:59','AEETH','4h','0.001207000000000','0.001159000000000','0.075710686990278','0.072699822884617','62.72633553461309','62.726335534613092','test'),('2019-10-31 11:59:59','2019-10-31 15:59:59','AEETH','4h','0.001159000000000','0.001181000000000','0.075710686990278','0.077147818235995','65.32414753259533','65.324147532595333','test'),('2019-11-09 15:59:59','2019-11-09 19:59:59','AEETH','4h','0.001258000000000','0.001259000000000','0.075710686990278','0.075770870366264','60.183375985912555','60.183375985912555','test'),('2019-11-11 03:59:59','2019-11-11 07:59:59','AEETH','4h','0.001244000000000','0.001223000000000','0.075710686990278','0.074432612692211','60.86068086035208','60.860680860352083','test'),('2019-11-11 19:59:59','2019-11-11 23:59:59','AEETH','4h','0.001272000000000','0.001238000000000','0.075710686990278','0.073686973658777','59.52098033826887','59.520980338268870','test'),('2019-11-12 07:59:59','2019-11-12 11:59:59','AEETH','4h','0.001240000000000','0.001251000000000','0.075710686990278','0.076382314052289','61.05700563732096','61.057005637320962','test'),('2019-11-29 03:59:59','2019-11-29 11:59:59','AEETH','4h','0.001113000000000','0.001106000000000','0.075710686990278','0.075234519147572','68.02397752945014','68.023977529450136','test'),('2019-12-05 19:59:59','2019-12-06 07:59:59','AEETH','4h','0.001098000000000','0.001085000000000','0.075710686990278','0.074814294521359','68.95326683996174','68.953266839961742','test'),('2019-12-06 15:59:59','2019-12-06 19:59:59','AEETH','4h','0.001095000000000','0.001095000000000','0.075710686990278','0.075710686990278','69.14217989979726','69.142179899797256','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','AEETH','4h','0.001093000000000','0.001086000000000','0.075710686990278','0.075225806103789','69.26869806978773','69.268698069787732','test'),('2019-12-09 07:59:59','2019-12-09 11:59:59','AEETH','4h','0.001107000000000','0.001095000000000','0.075710686990278','0.074889974936183','68.3926711745962','68.392671174596202','test'),('2019-12-17 23:59:59','2019-12-18 03:59:59','AEETH','4h','0.001071000000000','0.001062000000000','0.075710686990278','0.075074462729856','70.69158449138936','70.691584491389364','test'),('2019-12-19 07:59:59','2019-12-19 11:59:59','AEETH','4h','0.001067000000000','0.001072000000000','0.075710686990278','0.076065469965865','70.95659511741142','70.956595117411425','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  3:18:21
