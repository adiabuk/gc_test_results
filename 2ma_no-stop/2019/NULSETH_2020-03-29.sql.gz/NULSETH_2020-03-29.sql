-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 03:59:59','2019-01-10 07:59:59','NULSETH','4h','0.003000000000000','0.002915530000000','0.072144500000000','0.070113151361667','24.048166666666667','24.048166666666667','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','NULSETH','4h','0.002962680000000','0.002901590000000','0.072144500000000','0.070656891650465','24.35109427950369','24.351094279503691','test'),('2019-01-11 15:59:59','2019-01-14 15:59:59','NULSETH','4h','0.003000000000000','0.003000090000000','0.072144500000000','0.072146664335000','24.048166666666667','24.048166666666667','test'),('2019-01-15 19:59:59','2019-01-31 11:59:59','NULSETH','4h','0.003055700000000','0.003616280000000','0.072144500000000','0.085379687947115','23.60981117256275','23.609811172562750','test'),('2019-02-01 19:59:59','2019-02-02 19:59:59','NULSETH','4h','0.003804500000000','0.003768920000000','0.074574098823562','0.073876675657274','19.601550485888225','19.601550485888225','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','NULSETH','4h','0.003088870000000','0.003079630000000','0.074574098823562','0.074351018968104','24.142841499824208','24.142841499824208','test'),('2019-02-28 19:59:59','2019-03-01 19:59:59','NULSETH','4h','0.003081690000000','0.003087340000000','0.074574098823562','0.074710823691525','24.19909167488034','24.199091674880339','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','NULSETH','4h','0.003171020000000','0.003138760000000','0.074574098823562','0.073815427976942','23.51738520209964','23.517385202099639','test'),('2019-03-07 15:59:59','2019-03-07 23:59:59','NULSETH','4h','0.003149990000000','0.003158570000000','0.074574098823562','0.074777225109012','23.67439224364585','23.674392243645851','test'),('2019-04-15 07:59:59','2019-04-15 23:59:59','NULSETH','4h','0.005302640000000','0.005274420000000','0.074574098823562','0.074177224612075','14.063579429031954','14.063579429031954','test'),('2019-04-17 03:59:59','2019-04-17 11:59:59','NULSETH','4h','0.005312600000000','0.005192210000000','0.074574098823562','0.072884158726930','14.037213195716223','14.037213195716223','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','NULSETH','4h','0.005218180000000','0.005123170000000','0.074574098823562','0.073216291095728','14.291208586818009','14.291208586818009','test'),('2019-04-22 11:59:59','2019-04-22 15:59:59','NULSETH','4h','0.005202090000000','0.005074600000000','0.074574098823562','0.072746477260110','14.33541111813944','14.335411118139440','test'),('2019-04-23 07:59:59','2019-04-24 07:59:59','NULSETH','4h','0.005217480000000','0.005087380000000','0.074574098823562','0.072714563136421','14.293125958041431','14.293125958041431','test'),('2019-05-23 23:59:59','2019-05-24 03:59:59','NULSETH','4h','0.003132390000000','0.003088070000000','0.074574098823562','0.073518954330105','23.80741185598281','23.807411855982810','test'),('2019-05-24 11:59:59','2019-05-24 15:59:59','NULSETH','4h','0.003329990000000','0.003120120000000','0.074574098823562','0.069874124913700','22.394691522665834','22.394691522665834','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','NULSETH','4h','0.003204000000000','0.003068850000000','0.074574098823562','0.071428440441538','23.27531174268477','23.275311742684771','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','NULSETH','4h','0.003001860000000','0.002918290000000','0.074574098823562','0.072498000191819','24.84263051027097','24.842630510270968','test'),('2019-06-03 15:59:59','2019-06-03 19:59:59','NULSETH','4h','0.002989830000000','0.003044810000000','0.074574098823562','0.075945442329152','24.94258831557714','24.942588315577140','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','NULSETH','4h','0.003002340000000','0.003030000000000','0.074574098823562','0.075261136125620','24.838658787333213','24.838658787333213','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','NULSETH','4h','0.003120590000000','0.003082880000000','0.074574098823562','0.073672926523889','23.897435684778202','23.897435684778202','test'),('2019-07-01 19:59:59','2019-07-02 03:59:59','NULSETH','4h','0.003046530000000','0.003043530000000','0.074574098823562','0.074500663703451','24.478373370215294','24.478373370215294','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','NULSETH','4h','0.003083670000000','0.003155680000000','0.074574098823562','0.076315556520490','24.183553630434513','24.183553630434513','test'),('2019-07-08 03:59:59','2019-07-08 11:59:59','NULSETH','4h','0.003218180000000','0.002950000000000','0.074574098823562','0.068359629209525','23.172755664245628','23.172755664245628','test'),('2019-07-22 15:59:59','2019-07-22 19:59:59','NULSETH','4h','0.002709990000000','0.002716540000000','0.074574098823562','0.074754343159259','27.518219190315097','27.518219190315097','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','NULSETH','4h','0.002688390000000','0.002677370000000','0.074574098823562','0.074268411565004','27.73931565865146','27.739315658651460','test'),('2019-08-04 15:59:59','2019-08-04 19:59:59','NULSETH','4h','0.002518910000000','0.002586370000000','0.074574098823562','0.076571299480448','29.605701999500578','29.605701999500578','test'),('2019-08-16 07:59:59','2019-08-16 11:59:59','NULSETH','4h','0.002174440000000','0.002168510000000','0.074574098823562','0.074370724894631','34.295772163666044','34.295772163666044','test'),('2019-08-19 19:59:59','2019-08-19 23:59:59','NULSETH','4h','0.002301620000000','0.002224560000000','0.074574098823562','0.072077300891956','32.40069986512196','32.400699865121958','test'),('2019-08-21 15:59:59','2019-08-22 03:59:59','NULSETH','4h','0.002299620000000','0.002271200000000','0.074574098823562','0.073652470081176','32.42887904243397','32.428879042433969','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','NULSETH','4h','0.002310250000000','0.002354310000000','0.074574098823562','0.075996340916048','32.27966619351239','32.279666193512391','test'),('2019-08-24 03:59:59','2019-08-31 23:59:59','NULSETH','4h','0.002269740000000','0.002542950000000','0.074574098823562','0.083550628972207','32.85578913160186','32.855789131601860','test'),('2019-09-01 19:59:59','2019-09-01 23:59:59','NULSETH','4h','0.002516660000000','0.002491630000000','0.074574098823562','0.073832405589850','29.63217074358952','29.632170743589519','test'),('2019-09-02 11:59:59','2019-09-02 23:59:59','NULSETH','4h','0.002528860000000','0.002489520000000','0.074574098823562','0.073413993065347','29.48921601969346','29.489216019693458','test'),('2019-09-03 15:59:59','2019-09-03 19:59:59','NULSETH','4h','0.002522480000000','0.002477810000000','0.074574098823562','0.073253483796109','29.56380182342853','29.563801823428530','test'),('2019-09-05 11:59:59','2019-09-05 23:59:59','NULSETH','4h','0.002557570000000','0.002510890000000','0.074574098823562','0.073212994754823','29.158184848728286','29.158184848728286','test'),('2019-09-09 07:59:59','2019-09-09 11:59:59','NULSETH','4h','0.002500000000000','0.002406570000000','0.074574098823562','0.071787115602328','29.8296395294248','29.829639529424799','test'),('2019-09-09 23:59:59','2019-09-10 03:59:59','NULSETH','4h','0.002464870000000','0.002458030000000','0.074574098823562','0.074367156130457','30.254779693680398','30.254779693680398','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','NULSETH','4h','0.002169640000000','0.002024850000000','0.074574098823562','0.069597428146093','34.37164636693737','34.371646366937370','test'),('2019-10-01 07:59:59','2019-10-02 03:59:59','NULSETH','4h','0.002074530000000','0.002040930000000','0.074574098823562','0.073366263930612','35.947467052085045','35.947467052085045','test'),('2019-10-09 11:59:59','2019-10-09 15:59:59','NULSETH','4h','0.002146490000000','0.002014170000000','0.074574098823562','0.069976991566443','34.74234625996953','34.742346259969530','test'),('2019-10-27 15:59:59','2019-11-04 23:59:59','NULSETH','4h','0.002060230000000','0.002203410000000','0.074574098823562','0.079756782052890','36.196977436287206','36.196977436287206','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','NULSETH','4h','0.002216960000000','0.002178940000000','0.074574098823562','0.073295182091969','33.63799925283361','33.637999252833609','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','NULSETH','4h','0.002185130000000','0.002178110000000','0.074574098823562','0.074334520320800','34.127991846508905','34.127991846508905','test'),('2019-11-07 19:59:59','2019-11-07 23:59:59','NULSETH','4h','0.002199700000000','0.002193370000000','0.074574098823562','0.074359499539317','33.90194063897895','33.901940638978949','test'),('2019-11-10 03:59:59','2019-11-10 11:59:59','NULSETH','4h','0.002266790000000','0.002176770000000','0.074574098823562','0.071612571564267','32.89854764824356','32.898547648243557','test'),('2019-11-12 03:59:59','2019-11-12 07:59:59','NULSETH','4h','0.002208390000000','0.002290870000000','0.074574098823562','0.077359327732843','33.768536727462994','33.768536727462994','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','NULSETH','4h','0.002072420000000','0.002060410000000','0.074574098823562','0.074141930186475','35.9840663685749','35.984066368574901','test'),('2019-11-28 23:59:59','2019-11-29 03:59:59','NULSETH','4h','0.002029550000000','0.002009980000000','0.074574098823562','0.073855015719437','36.744154528620626','36.744154528620626','test'),('2019-11-29 15:59:59','2019-11-30 11:59:59','NULSETH','4h','0.002053640000000','0.002016670000000','0.074574098823562','0.073231602361910','36.31313123213514','36.313131232135142','test'),('2019-11-30 23:59:59','2019-12-01 03:59:59','NULSETH','4h','0.002025660000000','0.002029160000000','0.074574098823562','0.074702950331654','36.81471659783083','36.814716597830831','test'),('2019-12-07 19:59:59','2019-12-08 03:59:59','NULSETH','4h','0.002048050000000','0.001997430000000','0.074574098823562','0.072730910970507','36.41224522036181','36.412245220361811','test'),('2019-12-08 15:59:59','2019-12-08 19:59:59','NULSETH','4h','0.002023120000000','0.002030230000000','0.074574098823562','0.074836180085492','36.860936980288855','36.860936980288855','test'),('2019-12-16 23:59:59','2019-12-17 11:59:59','NULSETH','4h','0.001998520000000','0.001973310000000','0.074574098823562','0.073633396187941','37.31466226185477','37.314662261854771','test'),('2019-12-20 11:59:59','2019-12-20 15:59:59','NULSETH','4h','0.001993290000000','0.001982350000000','0.074574098823562','0.074164805323304','37.41256857936477','37.412568579364773','test'),('2019-12-21 03:59:59','2019-12-21 07:59:59','NULSETH','4h','0.001978200000000','0.001977640000000','0.074574098823562','0.074552987967561','37.69795714465777','37.697957144657771','test'),('2019-12-27 07:59:59','2019-12-29 07:59:59','NULSETH','4h','0.001992670000000','0.001947120000000','0.074574098823562','0.072869426097314','37.424209138272765','37.424209138272765','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:08:46
