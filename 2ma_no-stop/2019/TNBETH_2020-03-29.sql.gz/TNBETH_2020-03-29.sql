-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-10 19:59:59','TNBETH','4h','0.000022230000000','0.000022110000000','0.072144500000000','0.071755056005398','3245.3666216824113','3245.366621682411278','test'),('2019-01-11 11:59:59','2019-01-14 07:59:59','TNBETH','4h','0.000022750000000','0.000023300000000','0.072144500000000','0.073888652747253','3171.186813186813','3171.186813186813197','test'),('2019-01-15 19:59:59','2019-01-18 11:59:59','TNBETH','4h','0.000022520000000','0.000024740000000','0.072483177188163','0.079628499273319','3218.6135518722353','3218.613551872235348','test'),('2019-02-01 03:59:59','2019-02-01 07:59:59','TNBETH','4h','0.000025720000000','0.000025560000000','0.074269507709452','0.073807488998973','2887.616940491903','2887.616940491902824','test'),('2019-02-01 15:59:59','2019-02-01 19:59:59','TNBETH','4h','0.000025950000000','0.000025850000000','0.074269507709452','0.073983305367604','2862.023418475992','2862.023418475992003','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','TNBETH','4h','0.000020250000000','0.000020260000000','0.074269507709452','0.074306184009555','3667.630010343308','3667.630010343308186','test'),('2019-03-02 15:59:59','2019-03-07 03:59:59','TNBETH','4h','0.000019930000000','0.000022160000000','0.074269507709452','0.082579643293600','3726.5181991696936','3726.518199169693617','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','TNBETH','4h','0.000023330000000','0.000023160000000','0.076169155417433','0.075614129424250','3264.858783430466','3264.858783430465792','test'),('2019-03-17 03:59:59','2019-03-18 11:59:59','TNBETH','4h','0.000023880000000','0.000023380000000','0.076169155417433','0.074574323855091','3189.663124683124','3189.663124683123897','test'),('2019-03-20 19:59:59','2019-03-21 15:59:59','TNBETH','4h','0.000023800000000','0.000023320000000','0.076169155417433','0.074632970770359','3200.384681404748','3200.384681404747880','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','TNBETH','4h','0.000023370000000','0.000023460000000','0.076169155417433','0.076462489777192','3259.2706639894304','3259.270663989430432','test'),('2019-04-04 03:59:59','2019-04-04 07:59:59','TNBETH','4h','0.000027680000000','0.000027810000000','0.076169155417433','0.076526886277414','2751.7758460055275','2751.775846005527455','test'),('2019-04-06 03:59:59','2019-04-06 11:59:59','TNBETH','4h','0.000028430000000','0.000028150000000','0.076169155417433','0.075418984347546','2679.182392452796','2679.182392452796194','test'),('2019-04-12 11:59:59','2019-04-14 07:59:59','TNBETH','4h','0.000033390000000','0.000034850000000','0.076169155417433','0.079499702494685','2281.1966282549565','2281.196628254956522','test'),('2019-04-16 03:59:59','2019-04-16 07:59:59','TNBETH','4h','0.000033710000000','0.000033220000000','0.076169155417433','0.075061979915963','2259.5418397339954','2259.541839733995403','test'),('2019-04-16 19:59:59','2019-04-16 23:59:59','TNBETH','4h','0.000033290000000','0.000033110000000','0.076169155417433','0.075757306574683','2288.049126387293','2288.049126387293200','test'),('2019-04-17 03:59:59','2019-04-17 07:59:59','TNBETH','4h','0.000033350000000','0.000032870000000','0.076169155417433','0.075072867723269','2283.9326961749025','2283.932696174902503','test'),('2019-04-18 03:59:59','2019-04-18 23:59:59','TNBETH','4h','0.000035600000000','0.000034080000000','0.076169155417433','0.072916989231071','2139.5830173436234','2139.583017343623396','test'),('2019-04-20 23:59:59','2019-04-23 19:59:59','TNBETH','4h','0.000034310000000','0.000034920000000','0.076169155417433','0.077523372403869','2220.0278466171085','2220.027846617108480','test'),('2019-04-25 11:59:59','2019-04-25 15:59:59','TNBETH','4h','0.000034930000000','0.000035090000000','0.076169155417433','0.076518055070075','2180.622829013255','2180.622829013254886','test'),('2019-04-27 19:59:59','2019-04-28 15:59:59','TNBETH','4h','0.000035170000000','0.000034370000000','0.076169155417433','0.074436561606402','2165.742263788257','2165.742263788256878','test'),('2019-04-30 03:59:59','2019-04-30 07:59:59','TNBETH','4h','0.000035040000000','0.000034330000000','0.076169155417433','0.074625773558233','2173.777266479252','2173.777266479251921','test'),('2019-05-29 15:59:59','2019-05-29 19:59:59','TNBETH','4h','0.000021210000000','0.000020340000000','0.076169155417433','0.073044819480933','3591.190731609288','3591.190731609287923','test'),('2019-06-07 07:59:59','2019-06-10 11:59:59','TNBETH','4h','0.000020120000000','0.000020340000000','0.076169155417433','0.077002018945854','3785.743311005616','3785.743311005615851','test'),('2019-06-15 23:59:59','2019-06-17 03:59:59','TNBETH','4h','0.000020690000000','0.000020740000000','0.076169155417433','0.076353227808485','3681.4478210455773','3681.447821045577257','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','TNBETH','4h','0.000020460000000','0.000020010000000','0.076169155417433','0.074493880738164','3722.832620597898','3722.832620597897858','test'),('2019-06-24 07:59:59','2019-06-24 11:59:59','TNBETH','4h','0.000019330000000','0.000018910000000','0.076169155417433','0.074514160835161','3940.4632911243143','3940.463291124314310','test'),('2019-06-24 15:59:59','2019-06-25 11:59:59','TNBETH','4h','0.000023160000000','0.000021050000000','0.076169155417433','0.069229737544774','3288.823636331304','3288.823636331303987','test'),('2019-06-27 19:59:59','2019-06-27 23:59:59','TNBETH','4h','0.000020470000000','0.000019510000000','0.076169155417433','0.072596982031955','3721.013943206302','3721.013943206301974','test'),('2019-06-29 03:59:59','2019-06-29 07:59:59','TNBETH','4h','0.000019750000000','0.000018940000000','0.076169155417433','0.073045255878794','3856.666097085215','3856.666097085214915','test'),('2019-06-29 19:59:59','2019-06-29 23:59:59','TNBETH','4h','0.000020540000000','0.000019630000000','0.076169155417433','0.072794572582483','3708.3327856588603','3708.332785658860303','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','TNBETH','4h','0.000020270000000','0.000020410000000','0.076169155417433','0.076695237398609','3757.7284369725203','3757.728436972520285','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','TNBETH','4h','0.000020080000000','0.000020180000000','0.076169155417433','0.076548483880667','3793.2846323422805','3793.284632342280474','test'),('2019-07-06 19:59:59','2019-07-06 23:59:59','TNBETH','4h','0.000020470000000','0.000020110000000','0.076169155417433','0.074829590397879','3721.013943206302','3721.013943206301974','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','TNBETH','4h','0.000020070000000','0.000019230000000','0.076169155417433','0.072981208703400','3795.1746595631785','3795.174659563178466','test'),('2019-07-11 03:59:59','2019-07-11 07:59:59','TNBETH','4h','0.000019660000000','0.000019270000000','0.076169155417433','0.074658170137026','3874.321231812461','3874.321231812461065','test'),('2019-07-11 15:59:59','2019-07-11 19:59:59','TNBETH','4h','0.000019630000000','0.000018830000000','0.076169155417433','0.073064961615398','3880.242252543708','3880.242252543708219','test'),('2019-07-12 19:59:59','2019-07-13 07:59:59','TNBETH','4h','0.000019600000000','0.000019700000000','0.076169155417433','0.076557773557318','3886.1813988486224','3886.181398848622393','test'),('2019-07-14 07:59:59','2019-07-14 15:59:59','TNBETH','4h','0.000020490000000','0.000019140000000','0.076169155417433','0.071150689833561','3717.3819139791603','3717.381913979160345','test'),('2019-07-15 15:59:59','2019-07-15 19:59:59','TNBETH','4h','0.000019890000000','0.000019100000000','0.076169155417433','0.073143834513473','3829.520131595424','3829.520131595424118','test'),('2019-07-22 07:59:59','2019-07-22 15:59:59','TNBETH','4h','0.000019300000000','0.000018830000000','0.076169155417433','0.074314258886542','3946.5883635975642','3946.588363597564239','test'),('2019-07-22 19:59:59','2019-07-22 23:59:59','TNBETH','4h','0.000018960000000','0.000019100000000','0.076169155417433','0.076731585889925','4017.3605177970985','4017.360517797098510','test'),('2019-08-01 11:59:59','2019-08-01 15:59:59','TNBETH','4h','0.000018650000000','0.000018700000000','0.076169155417433','0.076373362268418','4084.1370197015012','4084.137019701501231','test'),('2019-08-03 03:59:59','2019-08-03 07:59:59','TNBETH','4h','0.000018450000000','0.000017580000000','0.076169155417433','0.072577439145717','4128.409507719945','4128.409507719945395','test'),('2019-08-14 19:59:59','2019-08-15 11:59:59','TNBETH','4h','0.000015760000000','0.000016510000000','0.076169155417433','0.079793956595293','4833.068237146763','4833.068237146762840','test'),('2019-08-16 19:59:59','2019-08-16 23:59:59','TNBETH','4h','0.000015840000000','0.000015920000000','0.076169155417433','0.076553848121561','4808.6588016056185','4808.658801605618464','test'),('2019-08-21 23:59:59','2019-08-22 03:59:59','TNBETH','4h','0.000015730000000','0.000015650000000','0.076169155417433','0.075781772554534','4842.285786232231','4842.285786232230748','test'),('2019-08-24 07:59:59','2019-08-28 23:59:59','TNBETH','4h','0.000016880000000','0.000017060000000','0.076169155417433','0.076981385747714','4512.390723781575','4512.390723781574707','test'),('2019-08-30 19:59:59','2019-08-30 23:59:59','TNBETH','4h','0.000017180000000','0.000016920000000','0.076169155417433','0.075016420818566','4433.594611026367','4433.594611026366692','test'),('2019-08-31 07:59:59','2019-08-31 11:59:59','TNBETH','4h','0.000017080000000','0.000017180000000','0.076169155417433','0.076615110659924','4459.5524249082555','4459.552424908255489','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','TNBETH','4h','0.000017180000000','0.000016330000000','0.076169155417433','0.072400599998061','4433.594611026367','4433.594611026366692','test'),('2019-09-04 03:59:59','2019-09-04 07:59:59','TNBETH','4h','0.000017010000000','0.000016710000000','0.076169155417433','0.074825784069683','4477.904492500469','4477.904492500469132','test'),('2019-09-04 11:59:59','2019-09-04 15:59:59','TNBETH','4h','0.000016890000000','0.000016750000000','0.076169155417433','0.075537794744938','4509.719089250029','4509.719089250029356','test'),('2019-09-04 19:59:59','2019-09-08 03:59:59','TNBETH','4h','0.000017280000000','0.000017700000000','0.076169155417433','0.078020489056051','4407.93723480515','4407.937234805150183','test'),('2019-09-21 23:59:59','2019-09-22 23:59:59','TNBETH','4h','0.000018950000000','0.000017010000000','0.076169155417433','0.068371363253326','4019.480496962163','4019.480496962163215','test'),('2019-09-29 07:59:59','2019-09-30 03:59:59','TNBETH','4h','0.000018180000000','0.000015880000000','0.076169155417433','0.066532793620948','4189.722520210836','4189.722520210835683','test'),('2019-10-07 23:59:59','2019-10-08 03:59:59','TNBETH','4h','0.000016500000000','0.000016190000000','0.076169155417433','0.074738098558075','4616.312449541393','4616.312449541393107','test'),('2019-10-08 07:59:59','2019-10-08 11:59:59','TNBETH','4h','0.000016360000000','0.000016250000000','0.076169155417433','0.075657015619394','4655.816345808863','4655.816345808862934','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','TNBETH','4h','0.000016720000000','0.000015740000000','0.076169155417433','0.071704695351100','4555.571496257954','4555.571496257954095','test'),('2019-10-14 07:59:59','2019-10-14 15:59:59','TNBETH','4h','0.000016320000000','0.000015890000000','0.076169155417433','0.074162247523469','4667.227660381924','4667.227660381923670','test'),('2019-10-15 15:59:59','2019-10-15 19:59:59','TNBETH','4h','0.000016050000000','0.000015520000000','0.050779436944955','0.049102608186025','3163.827847037715','3163.827847037714946','test'),('2019-10-22 15:59:59','2019-10-22 19:59:59','TNBETH','4h','0.000015570000000','0.000015420000000','0.056517894296032','0.055973405911677','3629.9225623655657','3629.922562365565682','test'),('2019-10-27 19:59:59','2019-10-28 03:59:59','TNBETH','4h','0.000015000000000','0.000015260000000','0.056517894296032','0.057497537797163','3767.8596197354664','3767.859619735466367','test'),('2019-11-06 19:59:59','2019-11-08 15:59:59','TNBETH','4h','0.000014910000000','0.000014520000000','0.056626683075226','0.055145502230200','3797.899602630842','3797.899602630841855','test'),('2019-11-16 07:59:59','2019-11-18 15:59:59','TNBETH','4h','0.000014330000000','0.000014500000000','0.056626683075226','0.057298458101241','3951.617800085555','3951.617800085554791','test'),('2019-11-19 07:59:59','2019-11-19 11:59:59','TNBETH','4h','0.000014660000000','0.000013870000000','0.056626683075226','0.053575176961350','3862.6659669321966','3862.665966932196625','test'),('2019-11-22 07:59:59','2019-11-25 03:59:59','TNBETH','4h','0.000015170000000','0.000014690000000','0.056626683075226','0.054834935687216','3732.8070583537246','3732.807058353724642','test'),('2019-11-25 15:59:59','2019-11-27 07:59:59','TNBETH','4h','0.000015110000000','0.000015050000000','0.056626683075226','0.056401825299944','3747.6295880361354','3747.629588036135374','test'),('2019-11-29 23:59:59','2019-11-30 07:59:59','TNBETH','4h','0.000014930000000','0.000014630000000','0.056626683075226','0.055488839476929','3792.8119943219026','3792.811994321902603','test'),('2019-12-07 11:59:59','2019-12-07 15:59:59','TNBETH','4h','0.000014480000000','0.000014360000000','0.056626683075226','0.056157401171288','3910.6825328194755','3910.682532819475455','test'),('2019-12-07 19:59:59','2019-12-07 23:59:59','TNBETH','4h','0.000014580000000','0.000014580000000','0.056626683075226','0.056626683075226','3883.8602932253775','3883.860293225377518','test'),('2019-12-09 11:59:59','2019-12-09 19:59:59','TNBETH','4h','0.000014660000000','0.000014440000000','0.056626683075226','0.055776896562501','3862.6659669321966','3862.665966932196625','test'),('2019-12-20 11:59:59','2019-12-21 03:59:59','TNBETH','4h','0.000014180000000','0.000013530000000','0.056626683075226','0.054030960649352','3993.4191167296194','3993.419116729619418','test'),('2019-12-22 15:59:59','2019-12-22 19:59:59','TNBETH','4h','0.000013480000000','0.000013280000000','0.056626683075226','0.055786524572626','4200.792512998962','4200.792512998961683','test'),('2019-12-27 03:59:59','2019-12-27 11:59:59','TNBETH','4h','0.000013140000000','0.000013060000000','0.056626683075226','0.056281923969745','4309.48881851035','4309.488818510350029','test'),('2019-12-28 03:59:59','2019-12-28 11:59:59','TNBETH','4h','0.000013210000000','0.000012900000000','0.056626683075226','0.055297820716913','4286.652768752914','4286.652768752914199','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  9:58:37
